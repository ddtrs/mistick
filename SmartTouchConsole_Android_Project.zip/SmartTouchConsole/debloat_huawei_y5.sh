#!/usr/bin/env bash
# ==============================================================================
# Скрипт очистки Huawei Y5 (Android 8.1 Go / 9 Pie) под выделенный пульт-консоль
# Отключает системный мусор Huawei, рекламу и фоновые сервисы, освобождая ~700 МБ ОЗУ,
# при этом сохраняя Wi-Fi, звук, Google Speech (для голосового ассистента "Эхо")
# и WebView/браузер для скачивания обновлений пульта.
# ==============================================================================

echo "Подключение к Huawei Y5 по ADB..."
adb wait-for-device

PACKAGES=(
  "com.huawei.appmarket"            # Huawei AppGallery
  "com.huawei.hicloud"              # Huawei Cloud
  "com.huawei.himovie"              # Huawei Video
  "com.huawei.himovie.overseas"
  "com.huawei.music"                # Huawei Music
  "com.huawei.bd"                   # Телеметрия Huawei User Experience
  "com.huawei.hiview"               # Фоновые логи Huawei
  "com.huawei.hiviewtunnel"
  "com.huawei.iaware"               # Агрессивный киллер фоновых сокетов Huawei
  "com.huawei.powergenie"           # PowerGenie (усыпляет Wi-Fi и микрофон в фоне!)
  "com.huawei.android.thememanager" # Темы Huawei
  "com.huawei.android.tips"         # Советы Huawei
  "com.huawei.phoneservice"         # HiCare / Поддержка
  "com.huawei.hifolder"             # Рекламные папки
  "com.huawei.gameassistant"        # Игровой центр
  "com.huawei.magazine"             # Разблокировка Журнал
  "com.huawei.compass"
  "com.android.email"
  "com.android.calendar"
  "com.android.mediacenter"
  "com.google.android.youtube"
  "com.google.android.apps.maps"
  "com.google.android.apps.photos"
  "com.google.android.gm"
  "com.google.android.music"
  "com.google.android.videos"
)

for pkg in "${PACKAGES[@]}"; do
  echo "Отключение $pkg ..."
  adb shell pm uninstall -k --user 0 "$pkg" 2>/dev/null || adb shell pm disable-user --user 0 "$pkg" 2>/dev/null
done

# Назначаем Smart Touch Console главным домашним экраном (Home Launcher)
echo "Установка Smart Touch Console как системного лаунчера по умолчанию..."
adb shell cmd package set-home-activity com.smartconsole.touch/.MainActivity

# Отключаем засыпание Wi-Fi в режиме сна
adb shell settings put global wifi_sleep_policy 2

echo "Готово! Huawei Y5 оптимизирован под Smart Touch Console."
