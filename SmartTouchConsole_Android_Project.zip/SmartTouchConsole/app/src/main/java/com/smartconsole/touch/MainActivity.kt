package com.smartconsole.touch

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.speech.RecognizerIntent
import android.text.InputFilter
import android.text.InputType
import android.view.GestureDetector
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.smartconsole.touch.databinding.ActivityMainBinding
import com.smartconsole.touch.network.MiTvController
import com.smartconsole.touch.network.TuyaController
import com.smartconsole.touch.ui.PressEffect
import com.smartconsole.touch.ui.TouchClickpadView
import com.smartconsole.touch.voice.VoiceAssistantEngine
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    enum class ConsoleMode {
        TV_REMOTE,
        LIGHT_STRIP,
        LIGHT_SCONCE
    }

    private lateinit var binding: ActivityMainBinding
    private lateinit var miTvController: MiTvController
    private val tuyaController = TuyaController()
    private var voiceEngine: VoiceAssistantEngine? = null

    private var clockAndStatusJob: Job? = null
    private var tvLightSyncJob: Job? = null
    private var neonPulseAnimator: ObjectAnimator? = null

    private var currentMode: ConsoleMode = ConsoleMode.TV_REMOTE
    private var isHubOpen: Boolean = false

    // Tuya & TV synchronized light state
    private var isStripOn: Boolean = true
    private var isSconceOn: Boolean = false
    private var currentHue: Float = 271f
    private var currentSatPercent: Int = 95
    private var currentBrightPercent: Int = 100
    private var activePreset: TuyaController.LightPreset? = TuyaController.LightPreset.VIOLET

    // Real TV Volume % (synchronized from AtvRemoteClient / TV status)
    private var tvVolumePercent: Int = 45

    private val timeFormat = SimpleDateFormat("HH:mm", Locale("ru", "RU"))
    private val dateFormat = SimpleDateFormat("EE · d MMM", Locale("ru", "RU"))

    private val batteryReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
            val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
            if (level >= 0 && scale > 0) {
                val pct = (level * 100) / scale
                updateBatteryAmbientUi(pct)
            }
        }
    }

    private val speechDialogLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == RESULT_OK && result.data != null) {
            val matches = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
            val spokenText = matches?.firstOrNull()?.trim().orEmpty()
            if (spokenText.isNotEmpty()) {
                animateTopNeonVoiceLine(true)
                voiceEngine?.handleRecognizedCommand(spokenText, fromDirectTap = true)
                binding.root.postDelayed({ animateTopNeonVoiceLine(false) }, 800L)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Disable Huawei speakerphone noise-suppression filter for far-field voice recognition
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            am?.setParameters("noise_suppression=off;ec_supported=off")
        } catch (_: Exception) {
        }

        miTvController = MiTvController(context = this, initialIp = "192.168.0.3", tvPort = 8765)

        lockImmersiveFullscreen()
        registerReceiver(batteryReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        setupTopPowerAndPairingActions()
        setupTvClickpadAndButtons()
        setupLightColorWheelAndSliders()
        setupBottomSwipeHubDrawer()
        setupVoiceIslandFallback()
        setupPressEffects()
        setupBackendCallbacks()
        startClockAndTvPolling()
        checkAudioPermissionAndStartVoiceEngine()
    }

    private fun setupPressEffects() {
        PressEffect.attachAll(
            binding.btnBack, binding.btnHome, binding.btnPlayPause,
            binding.btnQuickTvSettings, binding.btnQuickYoutube, binding.btnQuickKick, binding.btnQuickBrowser,
            binding.btnTvPowerToggle,
            binding.cardHubTv, binding.cardHubStrip, binding.cardHubSconce
        )
    }

    private var lastErrorToastAtMs = 0L
    private var pairingDialogShowing = false

    private fun setupBackendCallbacks() {
        tuyaController.onError = { message ->
            runOnUiThread {
                val now = System.currentTimeMillis()
                if (now - lastErrorToastAtMs > 5000L) {
                    lastErrorToastAtMs = now
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                }
            }
        }
        miTvController.onPairingRequired = { runOnUiThread { showPairingFlow() } }

        // Listen for real-time volume updates directly from the Android TV Remote protocol (field 50)
        miTvController.remote.onVolumeUpdated = { realPct ->
            runOnUiThread {
                tvVolumePercent = realPct.coerceIn(0, 100)
                binding.touchClickpad.volumePercent = tvVolumePercent
            }
        }

        lifecycleScope.launch { tuyaController.warmUp() }
        lifecycleScope.launch { miTvController.warmUpRemote() }
    }

    private fun showPairingFlow() {
        if (pairingDialogShowing || isFinishing || isDestroyed) return
        pairingDialogShowing = true
        AlertDialog.Builder(this)
            .setTitle("Сопряжение с ТВ")
            .setMessage("Кнопки работают через Google Remote. Один раз нужно сопрячься: на экране ТВ появится код из 6 символов.")
            .setPositiveButton("Показать код на ТВ") { _, _ -> startPairingOnTv() }
            .setNegativeButton("Позже") { _, _ -> pairingDialogShowing = false }
            .setOnCancelListener { pairingDialogShowing = false }
            .show()
    }

    private fun startPairingOnTv() {
        lifecycleScope.launch {
            val started = miTvController.beginPairing()
            if (!started) {
                pairingDialogShowing = false
                Toast.makeText(
                    this@MainActivity,
                    "ТВ не отвечает на сопряжение. Он включён и в той же Wi-Fi сети?",
                    Toast.LENGTH_LONG
                ).show()
                return@launch
            }
            val input = EditText(this@MainActivity).apply {
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
                filters = arrayOf(InputFilter.LengthFilter(6))
                hint = "Код с экрана ТВ"
            }
            AlertDialog.Builder(this@MainActivity)
                .setTitle("Введите код с экрана ТВ")
                .setView(input)
                .setCancelable(false)
                .setPositiveButton("Подтвердить") { _, _ ->
                    lifecycleScope.launch {
                        val ok = miTvController.finishPairing(input.text.toString())
                        pairingDialogShowing = false
                        Toast.makeText(
                            this@MainActivity,
                            if (ok) "ТВ сопряжён" else "Неверный код. Попробуйте снова через долгое нажатие на кнопку ТВ.",
                            Toast.LENGTH_LONG
                        ).show()
                        if (ok) miTvController.warmUpRemote()
                    }
                }
                .setNegativeButton("Отмена") { _, _ ->
                    miTvController.remote.closePairing()
                    pairingDialogShowing = false
                }
                .show()
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) {
            lockImmersiveFullscreen()
        }
    }

    private fun lockImmersiveFullscreen() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            window.insetsController?.let { controller ->
                controller.hide(WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars())
                controller.systemBarsBehavior =
                    WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            }
        } else {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = (
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    or View.SYSTEM_UI_FLAG_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                    or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                )
        }
    }

    private fun updateBatteryAmbientUi(percent: Int) {
        val clamped = percent.coerceIn(1, 100)
        binding.tvBatterySubtle.text = "$clamped%"
        binding.batteryAmbientBarTrack.post {
            val totalWidth = binding.batteryAmbientBarTrack.width
            if (totalWidth > 0) {
                val params = binding.batteryAmbientBarFill.layoutParams
                params.width = (totalWidth * clamped) / 100
                binding.batteryAmbientBarFill.layoutParams = params
            }
        }
    }

    private fun setupTopPowerAndPairingActions() {
        binding.btnTvPowerToggle.setOnClickListener { view ->
            performLightHaptic(view)
            lifecycleScope.launch {
                miTvController.toggleTvPower()
                delay(400L)
                val status = miTvController.pollScreenStatus()
                updatePowerPillUi(status.isReachable && status.isInteractive)
            }
        }

        binding.btnTvPowerToggle.setOnLongClickListener { view ->
            performLightHaptic(view)
            showManualIpDialog()
            true
        }
    }

    private fun showManualIpDialog() {
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_PHONE
            setText(miTvController.tvIp)
            setSelection(text.length)
        }
        AlertDialog.Builder(this)
            .setTitle("Пульт и Система (${miTvController.tvIp})")
            .setMessage("Укажите IP телевизора, запустите сопряжение или проверьте обновление APK на GitHub:")
            .setView(input)
            .setPositiveButton("Сохранить IP") { _, _ ->
                val entered = input.text.toString().trim()
                if (entered.isNotEmpty()) {
                    miTvController.setManualIp(entered)
                    lifecycleScope.launch { miTvController.warmUpRemote() }
                }
            }
            .setNeutralButton("Обновить пульт") { _, _ ->
                showUpdateChoiceDialog()
            }
            .setNegativeButton("Сопряжение ТВ") { _, _ ->
                pairingDialogShowing = false
                showPairingFlow()
            }
            .show()
    }

    private fun setupVoiceIslandFallback() {
        binding.neonVoiceContainer.setOnClickListener { view ->
            performLightHaptic(view)
            try {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                    putExtra(
                        "android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES",
                        arrayOf("uk-UA", "en-US", "ru-RU")
                    )
                    putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.voice_dialog_prompt))
                }
                speechDialogLauncher.launch(intent)
            } catch (_: Exception) {
                Toast.makeText(this, "Голосовой ввод недоступен", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupTvClickpadAndButtons() {
        binding.touchClickpad.volumePercent = tvVolumePercent

        binding.touchClickpad.onZonePressedHaptic = {
            performLightHaptic(binding.touchClickpad)
        }

        // Directional taps + Center OK
        binding.touchClickpad.onZoneClicked = { zone ->
            lifecycleScope.launch {
                when (zone) {
                    TouchClickpadView.Zone.UP -> miTvController.sendKey(MiTvController.TvKey.DPAD_UP)
                    TouchClickpadView.Zone.DOWN -> miTvController.sendKey(MiTvController.TvKey.DPAD_DOWN)
                    TouchClickpadView.Zone.LEFT -> miTvController.sendKey(MiTvController.TvKey.DPAD_LEFT)
                    TouchClickpadView.Zone.RIGHT -> miTvController.sendKey(MiTvController.TvKey.DPAD_RIGHT)
                    TouchClickpadView.Zone.CENTER -> miTvController.sendKey(MiTvController.TvKey.DPAD_CENTER)
                    TouchClickpadView.Zone.NONE -> {}
                }
            }
        }

        // Rotary Jog Dial Volume (+1 = Clockwise Vol Up, -1 = Counter-Clockwise Vol Down)
        // Follows exact 15-step / 25-step Android TV volume scale so phone percentage matches TV 1:1!
        binding.touchClickpad.onVolumeRotaryStep = { direction ->
            val maxSteps = miTvController.remote.tvVolumeMax.coerceIn(15, 30)
            val stepPct = Math.round(100f / maxSteps)
            tvVolumePercent = (tvVolumePercent + direction * stepPct).coerceIn(0, 100)
            binding.touchClickpad.volumePercent = tvVolumePercent

            lifecycleScope.launch {
                if (direction > 0) {
                    miTvController.sendKey(MiTvController.TvKey.VOLUME_UP)
                } else {
                    miTvController.sendKey(MiTvController.TvKey.VOLUME_DOWN)
                }
            }
        }

        // Row under disc: 1. TV Control Center (`GET /key?k=MENU`), 2. YouTube, 3. Kick, 4. Browser
        bindRemoteAction(binding.btnQuickTvSettings) {
            miTvController.openTvControlPanel()
        }
        bindRemoteAction(binding.btnQuickYoutube) {
            miTvController.launchApp(MiTvController.TvApp.YOUTUBE)
        }
        bindRemoteAction(binding.btnQuickKick) {
            miTvController.launchApp(MiTvController.TvApp.KICK)
        }
        bindRemoteAction(binding.btnQuickBrowser) {
            miTvController.launchApp(MiTvController.TvApp.BROWSER)
        }

        // 3 Lifted Matte Capsules: Back, Home, Play/Pause
        bindRemoteAction(binding.btnBack) { miTvController.sendKey(MiTvController.TvKey.BACK) }
        bindRemoteAction(binding.btnHome) { miTvController.sendKey(MiTvController.TvKey.HOME) }
        bindRemoteAction(binding.btnPlayPause) { miTvController.sendKey(MiTvController.TvKey.PLAY_PAUSE) }
    }

    private fun bindRemoteAction(target: View, action: suspend () -> Unit) {
        target.setOnClickListener { view ->
            performLightHaptic(view)
            lifecycleScope.launch {
                action()
            }
        }
    }

    /**
     * Mode B: Tuya Color Wheel + Brightness & Saturation SeekBars + Bidirectional TV Sync.
     */
    private fun setupLightColorWheelAndSliders() {
        renderColorPresetSwatches()

        binding.tuyaColorWheel.hue = currentHue
        binding.tuyaColorWheel.saturation = currentSatPercent / 100f
        binding.tuyaColorWheel.brightness = currentBrightPercent / 100f

        binding.tuyaColorWheel.onHapticTick = {
            performLightHaptic(binding.tuyaColorWheel)
        }

        binding.tuyaColorWheel.onCenterPowerToggle = {
            val targetDevice = activeLightDeviceId()
            if (currentMode == ConsoleMode.LIGHT_SCONCE) {
                isSconceOn = !isSconceOn
                binding.tuyaColorWheel.isLightOn = isSconceOn
                updateHubCardsUi()
                tuyaController.requestPower(lifecycleScope, targetDevice, isSconceOn)
            } else {
                isStripOn = !isStripOn
                binding.tuyaColorWheel.isLightOn = isStripOn
                updateHubCardsUi()
                tuyaController.requestPower(lifecycleScope, targetDevice, isStripOn)
                lifecycleScope.launch { miTvController.syncLightToTv(power = isStripOn) }
            }
        }

        binding.tuyaColorWheel.onHueChanged = { newHue, isFinal ->
            currentHue = newHue
            activePreset = null
            renderColorPresetSwatches()
            if (currentMode == ConsoleMode.LIGHT_SCONCE) isSconceOn = true else isStripOn = true
            updateHubCardsUi()
            dispatchLightHsvUpdate(isFinal = isFinal)
        }

        binding.seekLightBrightness.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val clamped = progress.coerceAtLeast(1)
                currentBrightPercent = clamped
                binding.tvBrightnessPercent.text = "$clamped%"
                binding.tuyaColorWheel.brightness = clamped / 100f
                if (fromUser) dispatchLightHsvUpdate(isFinal = false)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                performLightHaptic(binding.seekLightBrightness)
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                dispatchLightHsvUpdate(isFinal = true)
            }
        })

        binding.seekLightSaturation.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                val clamped = progress.coerceAtLeast(5)
                currentSatPercent = clamped
                binding.tvSaturationPercent.text = "$clamped%"
                binding.tuyaColorWheel.saturation = clamped / 100f
                if (fromUser) dispatchLightHsvUpdate(isFinal = false)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                performLightHaptic(binding.seekLightSaturation)
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                dispatchLightHsvUpdate(isFinal = true)
            }
        })

        val presetMap = listOf(
            binding.presetCyber to TuyaController.LightPreset.CYBER,
            binding.presetSapphire to TuyaController.LightPreset.SAPPHIRE,
            binding.presetViolet to TuyaController.LightPreset.VIOLET,
            binding.presetRaspberry to TuyaController.LightPreset.RASPBERRY,
            binding.presetSunset to TuyaController.LightPreset.SUNSET,
            binding.presetWarm to TuyaController.LightPreset.WARM
        )

        presetMap.forEach { (container, preset) ->
            container.setOnClickListener { view ->
                performLightHaptic(view)
                applyPresetToUiAndDevice(preset)
            }
        }
    }

    private fun applyPresetToUiAndDevice(preset: TuyaController.LightPreset) {
        activePreset = preset
        currentHue = preset.hue.toFloat()
        currentSatPercent = (preset.satPromille / 10).coerceIn(5, 100)
        currentBrightPercent = (preset.valPromille / 10).coerceIn(1, 100)

        binding.tuyaColorWheel.hue = currentHue
        binding.tuyaColorWheel.saturation = currentSatPercent / 100f
        binding.tuyaColorWheel.brightness = currentBrightPercent / 100f
        binding.tuyaColorWheel.isLightOn = true

        binding.seekLightBrightness.progress = currentBrightPercent
        binding.tvBrightnessPercent.text = "$currentBrightPercent%"
        binding.seekLightSaturation.progress = currentSatPercent
        binding.tvSaturationPercent.text = "$currentSatPercent%"

        if (currentMode == ConsoleMode.LIGHT_SCONCE) isSconceOn = true else isStripOn = true
        updateHubCardsUi()
        renderColorPresetSwatches()

        val targetDevice = activeLightDeviceId()
        tuyaController.requestPreset(lifecycleScope, targetDevice, preset)

        // Immediately sync preset & power to TV dashboard so TV shows the exact preset and spectrum
        if (currentMode != ConsoleMode.LIGHT_SCONCE) {
            lifecycleScope.launch {
                miTvController.syncLightToTv(
                    power = true,
                    presetId = preset.id,
                    hue = preset.hue,
                    satPercent = currentSatPercent,
                    brightPercent = currentBrightPercent,
                    colorName = preset.titleRu
                )
            }
        }
    }

    /**
     * Sends color/brightness to Tuya via the conflated sender AND syncs to the TV dashboard (`/light?...`).
     */
    private fun dispatchLightHsvUpdate(isFinal: Boolean) {
        val sPromille = (currentSatPercent * 10).coerceIn(10, 1000)
        val vPromille = (currentBrightPercent * 10).coerceIn(10, 1000)
        tuyaController.requestHsv(
            lifecycleScope, activeLightDeviceId(), currentHue.toInt(), sPromille, vPromille
        )

        if (currentMode != ConsoleMode.LIGHT_SCONCE) {
            miTvController.lastLocalLightChangeMs = System.currentTimeMillis()
            if (isFinal) {
                tvLightSyncJob?.cancel()
                val h = currentHue.toInt()
                val colorName = miTvController.getFriendlyColorName(h, currentSatPercent)
                tvLightSyncJob = lifecycleScope.launch {
                    miTvController.syncLightToTv(
                        power = true,
                        presetId = activePreset?.id,
                        hue = h,
                        satPercent = currentSatPercent,
                        brightPercent = currentBrightPercent,
                        colorName = colorName
                    )
                }
            }
        }
    }

    private fun applyHsvToUi(hue: Int, satPercent: Int, brightPercent: Int) {
        currentHue = hue.toFloat()
        currentSatPercent = satPercent.coerceIn(5, 100)
        currentBrightPercent = brightPercent.coerceIn(1, 100)
        activePreset = null
        isStripOn = true
        binding.tuyaColorWheel.hue = currentHue
        binding.tuyaColorWheel.saturation = currentSatPercent / 100f
        binding.tuyaColorWheel.brightness = currentBrightPercent / 100f
        if (currentMode == ConsoleMode.LIGHT_STRIP) binding.tuyaColorWheel.isLightOn = true
        binding.seekLightBrightness.progress = currentBrightPercent
        binding.tvBrightnessPercent.text = "$currentBrightPercent%"
        binding.seekLightSaturation.progress = currentSatPercent
        binding.tvSaturationPercent.text = "$currentSatPercent%"
        renderColorPresetSwatches()
        updateHubCardsUi()
    }

    /**
     * Synchronizes the phone UI from the TV's `/status` response (`ledOn`, `ledMode`, `ledBright`)
     * when the user changes lighting from the TV screen!
     */
    private fun syncUiFromTvLightState(ledOn: Boolean?, ledMode: String?, ledBright: Int?) {
        // Ignore TV status echoes for 2.5 seconds right after the user touched the phone's light controls
        if (System.currentTimeMillis() - miTvController.lastLocalLightChangeMs < 2500L) {
            return
        }

        var changed = false
        if (ledOn != null && ledOn != isStripOn) {
            isStripOn = ledOn
            if (currentMode == ConsoleMode.LIGHT_STRIP) {
                binding.tuyaColorWheel.isLightOn = isStripOn
            }
            changed = true
        }

        if (ledBright != null && ledBright in 5..100 && ledBright != currentBrightPercent) {
            currentBrightPercent = ledBright
            binding.seekLightBrightness.progress = currentBrightPercent
            binding.tvBrightnessPercent.text = "$currentBrightPercent%"
            binding.tuyaColorWheel.brightness = currentBrightPercent / 100f
            changed = true
        }

        if (!ledMode.isNullOrBlank()) {
            val m = ledMode.trim().lowercase(Locale("ru", "RU"))
            val matchedPreset = when {
                m.contains("кибер") || m.contains("cyber") -> TuyaController.LightPreset.CYBER
                m.contains("сапфир") || m.contains("sapphire") || m.contains("индиго") -> TuyaController.LightPreset.SAPPHIRE
                m.contains("фиолет") || m.contains("violet") || m.contains("фукси") -> TuyaController.LightPreset.VIOLET
                m.contains("малин") || m.contains("raspberry") -> TuyaController.LightPreset.RASPBERRY
                m.contains("закат") || m.contains("sunset") || m.contains("янтар") -> TuyaController.LightPreset.SUNSET
                m.contains("тёпл") || m.contains("тепл") || m.contains("warm") -> TuyaController.LightPreset.WARM
                else -> null
            }

            if (matchedPreset != null && activePreset != null && matchedPreset != activePreset) {
                activePreset = matchedPreset
                currentHue = matchedPreset.hue.toFloat()
                currentSatPercent = (matchedPreset.satPromille / 10).coerceIn(5, 100)
                binding.tuyaColorWheel.hue = currentHue
                binding.tuyaColorWheel.saturation = currentSatPercent / 100f
                binding.seekLightSaturation.progress = currentSatPercent
                binding.tvSaturationPercent.text = "$currentSatPercent%"
                changed = true
            } else if (matchedPreset == null) {
                // If TV selected a custom color like Lime or Green, keep it as custom without forcing preset selection
                val customHue = when {
                    m.contains("лайм") -> 100f
                    m.contains("зелен") -> 125f
                    m.contains("изумр") -> 160f
                    m.contains("океан") -> 175f
                    m.contains("янтар") -> 45f
                    else -> null
                }
                if (customHue != null && kotlin.math.abs(currentHue - customHue) > 5f) {
                    activePreset = null
                    currentHue = customHue
                    binding.tuyaColorWheel.hue = currentHue
                    changed = true
                }
            }
        }

        if (changed) {
            renderColorPresetSwatches()
            updateHubCardsUi()
        }
    }

    private fun activeLightDeviceId(): String {
        return if (currentMode == ConsoleMode.LIGHT_SCONCE) {
            tuyaController.sconceDeviceId
        } else {
            tuyaController.stripDeviceId
        }
    }

    private fun setupBottomSwipeHubDrawer() {
        val gestureDetector = GestureDetector(
            this,
            object : GestureDetector.SimpleOnGestureListener() {
                override fun onSingleTapUp(e: MotionEvent): Boolean {
                    openHubDrawer()
                    return true
                }

                override fun onFling(
                    e1: MotionEvent?,
                    e2: MotionEvent,
                    velocityX: Float,
                    velocityY: Float
                ): Boolean {
                    if (velocityY < -150f) {
                        openHubDrawer()
                        return true
                    }
                    return false
                }
            }
        )

        binding.bottomSwipeHandleArea.setOnTouchListener { view, event ->
            if (event.actionMasked == MotionEvent.ACTION_DOWN) {
                performLightHaptic(view)
            }
            gestureDetector.onTouchEvent(event)
            true
        }

        binding.hubScrimOverlay.setOnClickListener {
            closeHubDrawer()
        }

        binding.sheetTopDragPill.setOnClickListener {
            closeHubDrawer()
        }

        binding.cardHubTv.setOnClickListener { view ->
            performLightHaptic(view)
            switchConsoleMode(ConsoleMode.TV_REMOTE)
            closeHubDrawer()
        }

        binding.cardHubStrip.setOnClickListener { view ->
            performLightHaptic(view)
            isStripOn = !isStripOn
            if (currentMode == ConsoleMode.LIGHT_STRIP) {
                binding.tuyaColorWheel.isLightOn = isStripOn
            }
            updateHubCardsUi()
            tuyaController.requestPower(lifecycleScope, tuyaController.stripDeviceId, isStripOn)
            lifecycleScope.launch { miTvController.syncLightToTv(power = isStripOn) }
        }

        binding.cardHubStrip.setOnLongClickListener { view ->
            performLightHaptic(view)
            isStripOn = true
            switchConsoleMode(ConsoleMode.LIGHT_STRIP)
            closeHubDrawer()
            true
        }

        binding.cardHubSconce.setOnClickListener { view ->
            performLightHaptic(view)
            isSconceOn = !isSconceOn
            if (currentMode == ConsoleMode.LIGHT_SCONCE) {
                binding.tuyaColorWheel.isLightOn = isSconceOn
            }
            updateHubCardsUi()
            tuyaController.requestPower(lifecycleScope, tuyaController.sconceDeviceId, isSconceOn)
        }

        binding.cardHubSconce.setOnLongClickListener { view ->
            performLightHaptic(view)
            isSconceOn = true
            switchConsoleMode(ConsoleMode.LIGHT_SCONCE)
            closeHubDrawer()
            true
        }

        updateHubCardsUi()
    }

    private fun switchConsoleMode(newMode: ConsoleMode) {
        currentMode = newMode
        when (newMode) {
            ConsoleMode.TV_REMOTE -> {
                binding.lightControlModeContainer.visibility = View.GONE
                binding.tvRemoteModeContainer.visibility = View.VISIBLE
            }
            ConsoleMode.LIGHT_STRIP -> {
                binding.tvRemoteModeContainer.visibility = View.GONE
                binding.lightControlModeContainer.visibility = View.VISIBLE
                binding.tvActiveLightTitle.text = "SMART LED STRIP"
                binding.tuyaColorWheel.isLightOn = isStripOn
            }
            ConsoleMode.LIGHT_SCONCE -> {
                binding.tvRemoteModeContainer.visibility = View.GONE
                binding.lightControlModeContainer.visibility = View.VISIBLE
                binding.tvActiveLightTitle.text = "SMART LAMP / БРА"
                binding.tuyaColorWheel.isLightOn = isSconceOn
            }
        }
        updateHubCardsUi()
    }

    private fun openHubDrawer() {
        if (isHubOpen) return
        isHubOpen = true
        updateHubCardsUi()
        binding.hubScrimOverlay.visibility = View.VISIBLE
        binding.hubBottomSheet.visibility = View.VISIBLE

        binding.hubScrimOverlay.animate()
            .alpha(1f)
            .setDuration(200L)
            .start()

        binding.hubBottomSheet.animate()
            .translationY(0f)
            .setDuration(240L)
            .start()
    }

    private fun closeHubDrawer() {
        if (!isHubOpen) return
        isHubOpen = false

        binding.hubScrimOverlay.animate()
            .alpha(0f)
            .setDuration(180L)
            .withEndAction {
                binding.hubScrimOverlay.visibility = View.GONE
            }
            .start()

        binding.hubBottomSheet.animate()
            .translationY(420f)
            .setDuration(220L)
            .withEndAction {
                binding.hubBottomSheet.visibility = View.GONE
            }
            .start()
    }

    private fun updateHubCardsUi() {
        binding.cardHubTv.isSelected = (currentMode == ConsoleMode.TV_REMOTE)
        binding.cardHubStrip.isSelected = (currentMode == ConsoleMode.LIGHT_STRIP)
        binding.cardHubSconce.isSelected = (currentMode == ConsoleMode.LIGHT_SCONCE)

        binding.tvHubTvSub.text = if (currentMode == ConsoleMode.TV_REMOTE) "На экране" else "Выбрать"
        binding.tvHubTvSub.setTextColor(
            ContextCompat.getColor(
                this,
                if (currentMode == ConsoleMode.TV_REMOTE) R.color.preset_cyber else R.color.text_secondary
            )
        )

        binding.tvHubStripSub.text = if (isStripOn) "ВКЛ · Зажми" else "ВЫКЛ · Зажми"
        binding.tvHubStripSub.setTextColor(
            ContextCompat.getColor(
                this,
                if (isStripOn) R.color.status_online else R.color.text_secondary
            )
        )

        binding.tvHubSconceSub.text = if (isSconceOn) "ВКЛ · Зажми" else "ВЫКЛ · Зажми"
        binding.tvHubSconceSub.setTextColor(
            ContextCompat.getColor(
                this,
                if (isSconceOn) R.color.status_online else R.color.text_secondary
            )
        )
    }

    private fun renderColorPresetSwatches() {
        val swatches = listOf(
            binding.swatchCyber to TuyaController.LightPreset.CYBER,
            binding.swatchSapphire to TuyaController.LightPreset.SAPPHIRE,
            binding.swatchViolet to TuyaController.LightPreset.VIOLET,
            binding.swatchRaspberry to TuyaController.LightPreset.RASPBERRY,
            binding.swatchSunset to TuyaController.LightPreset.SUNSET,
            binding.swatchWarm to TuyaController.LightPreset.WARM
        )

        val density = resources.displayMetrics.density
        swatches.forEach { (view, preset) ->
            val isSelected = (preset == activePreset)
            val drawable = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(preset.previewHexColor)
                if (isSelected) {
                    setStroke((2.5f * density).toInt(), Color.WHITE)
                } else {
                    setStroke((1f * density).toInt(), Color.parseColor("#33FFFFFF"))
                }
            }
            view.background = drawable
            view.scaleX = if (isSelected) 1.15f else 1.0f
            view.scaleY = if (isSelected) 1.15f else 1.0f
        }
    }

    private fun updatePowerPillUi(isOnline: Boolean) {
        val colorRes = if (isOnline) R.color.status_online else R.color.status_sleeping
        val resolvedColor = ContextCompat.getColor(this, colorRes)
        (binding.statusDotView.background as? GradientDrawable)?.setColor(resolvedColor)
        binding.tvPowerStatusLabel.text = getString(
            if (isOnline) R.string.tv_power_on else R.string.tv_power_sleep
        )
    }

    private fun startClockAndTvPolling() {
        clockAndStatusJob?.cancel()
        clockAndStatusJob = lifecycleScope.launch {
            while (isActive) {
                val now = Date()
                binding.tvClock.text = timeFormat.format(now)
                binding.tvDate.text = dateFormat.format(now).uppercase(Locale("ru", "RU"))

                val status = miTvController.pollScreenStatus()
                updatePowerPillUi(status.isReachable && status.isInteractive)

                // Bidirectional sync: update phone light controls & volume if changed on TV
                syncUiFromTvLightState(status.ledOn, status.ledMode, status.ledBright)
                if (status.volumePercent != null) {
                    tvVolumePercent = status.volumePercent
                    binding.touchClickpad.volumePercent = tvVolumePercent
                }

                delay(2200L)
            }
        }
    }

    private fun animateTopNeonVoiceLine(active: Boolean) {
        runOnUiThread {
            if (active) {
                if (neonPulseAnimator == null) {
                    val alphaHolder = PropertyValuesHolder.ofFloat(View.ALPHA, 0.35f, 1.0f)
                    val scaleXHolder = PropertyValuesHolder.ofFloat(View.SCALE_X, 0.7f, 1.35f)
                    neonPulseAnimator = ObjectAnimator.ofPropertyValuesHolder(
                        binding.neonVoiceLine,
                        alphaHolder,
                        scaleXHolder
                    ).apply {
                        duration = 480L
                        repeatCount = ObjectAnimator.INFINITE
                        repeatMode = ObjectAnimator.REVERSE
                    }
                }
                if (neonPulseAnimator?.isRunning != true) {
                    neonPulseAnimator?.start()
                }
            } else {
                neonPulseAnimator?.cancel()
                binding.neonVoiceLine.animate()
                    .alpha(0.28f)
                    .scaleX(1.0f)
                    .setDuration(220L)
                    .start()
            }
        }
    }

    private fun checkAudioPermissionAndStartVoiceEngine() {
        initVoiceEngine()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.RECORD_AUDIO),
                1001
            )
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 1001 && grantResults.isNotEmpty() &&
            grantResults[0] == PackageManager.PERMISSION_GRANTED
        ) {
            initVoiceEngine()
        }
    }

    private fun initVoiceEngine() {
        voiceEngine?.stop()
        voiceEngine = VoiceAssistantEngine(
            context = this,
            scope = lifecycleScope,
            miTvController = miTvController,
            tuyaController = tuyaController,
            onVoiceActivityChanged = { active -> animateTopNeonVoiceLine(active) },
            onWakeWordTriggeredHaptic = {
                runOnUiThread { performLightHaptic(binding.neonVoiceContainer) }
            },
            onLocalPresetChanged = { preset ->
                runOnUiThread {
                    applyPresetToUiAndDevice(preset)
                }
            },
            onLocalStripPowerChanged = { enabled ->
                runOnUiThread {
                    isStripOn = enabled
                    binding.tuyaColorWheel.isLightOn = enabled
                    updateHubCardsUi()
                }
            },
            getLightState = { intArrayOf(currentHue.toInt(), currentSatPercent, currentBrightPercent) },
            onLocalColorChanged = { h, sat, bright ->
                runOnUiThread { applyHsvToUi(h, sat, bright) }
            }
        ).also { it.start() }
    }

    private fun performLightHaptic(view: View) {
        view.performHapticFeedback(
            HapticFeedbackConstants.KEYBOARD_TAP,
            HapticFeedbackConstants.FLAG_IGNORE_GLOBAL_SETTING
        )
        try {
            val vibrator = getSystemService(Vibrator::class.java)
            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator.vibrate(VibrationEffect.createOneShot(14L, 90))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(14L)
                }
            }
        } catch (_: Exception) {
        }
    }

    /**
     * In-App OTA Update: Downloads APK directly in the background and opens the native installer,
     * so you never leave the console and never get stuck in a browser without navigation buttons.
     */
    /**
     * In-App OTA Update with permanent signature (`console-signing-key.jks`):
     * Downloads the signed APK directly in the background and launches the system package installer
     * on top of the console, without ever opening an external browser!
     */
    private fun showUpdateChoiceDialog() {
        val prefs = getSharedPreferences("smart_console_prefs", Context.MODE_PRIVATE)
        val defaultUrl = prefs.getString(
            "ota_apk_url",
            "https://github.com/ddtrs/echo/releases/download/latest-ota/app-debug.apk"
        ) ?: "https://github.com/ddtrs/echo/releases/download/latest-ota/app-debug.apk"

        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setText(defaultUrl)
            setSelection(text.length)
        }
        AlertDialog.Builder(this)
            .setTitle("Обновление пульта (OTA)")
            .setMessage("APK подписан единым ключом и ставится поверх как обновление без потери настроек:")
            .setView(input)
            .setPositiveButton("Скачать и установить") { _, _ ->
                val url = input.text.toString().trim().ifEmpty { defaultUrl }
                prefs.edit().putString("ota_apk_url", url).apply()
                downloadAndInstallOtaApk(url)
            }
            .setNeutralButton("С локального ТВ") { _, _ ->
                val tvUrl = "http://${miTvController.tvIp}:${miTvController.tvPort}/update.apk"
                downloadAndInstallOtaApk(tvUrl)
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun downloadAndInstallOtaApk(primaryUrl: String) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !packageManager.canRequestPackageInstalls()) {
            try {
                val permIntent = Intent(
                    android.provider.Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:$packageName")
                )
                startActivity(permIntent)
                Toast.makeText(this, "Разрешите установку обновлений и нажмите снова", Toast.LENGTH_LONG).show()
                return
            } catch (_: Exception) {
            }
        }

        Toast.makeText(this, "Скачивание обновления...", Toast.LENGTH_SHORT).show()
        lifecycleScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val candidateUrls = listOf(
                primaryUrl,
                "https://github.com/ddtrs/echo/releases/download/latest-ota/app-debug.apk",
                "https://github.com/ddtrs/echo/releases/latest/download/app-debug.apk",
                "https://raw.githubusercontent.com/ddtrs/echo/main/app-debug.apk"
            ).distinct()

            val destFile = java.io.File(externalCacheDir ?: cacheDir, "update.apk")
            val client = okhttp3.OkHttpClient.Builder()
                .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
                .readTimeout(45, java.util.concurrent.TimeUnit.SECONDS)
                .followRedirects(true)
                .followSslRedirects(true)
                .build()

            var downloadedOk = false
            var lastErr = "Файл не найден в релизах GitHub"

            for (url in candidateUrls) {
                try {
                    val req = okhttp3.Request.Builder().url(url).build()
                    client.newCall(req).execute().use { resp ->
                        if (resp.isSuccessful) {
                            val body = resp.body
                            if (body != null) {
                                if (destFile.exists()) destFile.delete()
                                body.byteStream().use { inp ->
                                    destFile.outputStream().use { out ->
                                        inp.copyTo(out)
                                    }
                                }
                                // Verify it is a valid APK/ZIP header (starts with 'PK' and > 50KB)
                                if (destFile.length() > 50_000L) {
                                    downloadedOk = true
                                } else {
                                    lastErr = "Файл слишком мал (${destFile.length()} байт)"
                                }
                            }
                        } else {
                            lastErr = "HTTP ${resp.code}"
                        }
                    }
                } catch (e: Exception) {
                    lastErr = e.javaClass.simpleName
                }
                if (downloadedOk) break
            }

            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                if (downloadedOk) {
                    promptInstallDownloadedApk(destFile)
                } else {
                    Toast.makeText(
                        this@MainActivity,
                        "Не удалось скачать APK ($lastErr). Проверьте, что сборка на GitHub завершилась.",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private fun promptInstallDownloadedApk(apkFile: java.io.File) {
        try {
            val contentUri = androidx.core.content.FileProvider.getUriForFile(
                this,
                "com.smartconsole.touch.fileprovider",
                apkFile
            )
            val installIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(contentUri, "application/vnd.android.package-archive")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
            }
            startActivity(installIntent)
        } catch (e: Exception) {
            Toast.makeText(this, "Ошибка запуска установщика: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroy() {
        try {
            unregisterReceiver(batteryReceiver)
        } catch (_: Exception) {
        }
        clockAndStatusJob?.cancel()
        tvLightSyncJob?.cancel()
        miTvController.stopMdnsAutoDiscovery()
        voiceEngine?.stop()
        super.onDestroy()
    }
}
