package com.smartconsole.touch.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.OvershootInterpolator
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

/**
 * Ergonomic Brushed-Metal Touch Clickpad View (222dp) with Infinite Mechanical Knurled Bezel:
 * 1. 3D Mechanical Pivot Tilt: directional presses tilt the disc physically in 3D.
 * 2. Infinite Rotating Outer Bezel: rotating your thumb turns the mechanical knurled outer teeth
 *    and brushed titanium reflection continuously, while the 4 directional arrows (Up, Down, Left, Right)
 *    and the central button STAY STRICTLY FIXED IN PLACE!
 * 3. Exact TV Volume: Displays real synchronized TV volume percentage (e.g. "60% · ЗВУК") in the center.
 */
class TouchClickpadView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    enum class Zone { NONE, CENTER, UP, DOWN, LEFT, RIGHT }

    var onZoneClicked: ((Zone) -> Unit)? = null
    var onZonePressedHaptic: (() -> Unit)? = null
    var onVolumeRotaryStep: ((Int) -> Unit)? = null // +1 for Vol Up (CW), -1 for Vol Down (CCW)

    /** Real synchronized TV volume percentage (0..100). */
    var volumePercent: Int = 45
        set(value) {
            field = value.coerceIn(0, 100)
            if (isRotatingVolume) invalidate()
        }

    private var activeZone: Zone = Zone.NONE
    private var isRotatingVolume: Boolean = false
    private var lastTouchAngleDeg: Float = 0f
    private var accumulatedRotationDeg: Float = 0f
    private var bezelContinuousRotationDeg: Float = 0f

    private val outerRect = RectF()

    private val discPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
        color = Color.parseColor("#33FFFFFF")
    }
    private val groovePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.2f
        color = Color.parseColor("#14FFFFFF")
    }
    // Knurled mechanical rim ridges/teeth
    private val knurlToothPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f
        strokeCap = Paint.Cap.ROUND
        color = Color.parseColor("#44F5F7FA")
    }
    private val centerPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val centerBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.2f
        color = Color.parseColor("#38FFFFFF")
    }
    private val chevronPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4.2f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        color = Color.parseColor("#B8C0D4")
    }
    private val okTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F5F7FA")
        textSize = 40f
        textAlign = Paint.Align.CENTER
        isFakeBoldText = true
    }
    private val volSubPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#8C93A4")
        textSize = 20f
        textAlign = Paint.Align.CENTER
        letterSpacing = 0.12f
    }

    init {
        val density = resources.displayMetrics.density
        cameraDistance = 4200f * density
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val cx = w / 2f
        val cy = h / 2f
        val r = min(cx, cy) - 6f
        outerRect.set(cx - r, cy - r, cx + r, cy + r)

        centerPaint.shader = RadialGradient(
            cx, cy, r * 0.40f,
            Color.parseColor("#2A3042"),
            Color.parseColor("#171A24"),
            Shader.TileMode.CLAMP
        )
        okTextPaint.textSize = r * 0.155f
        volSubPaint.textSize = r * 0.075f
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val cx = width / 2f
        val cy = height / 2f
        val outerR = min(cx, cy) - 6f
        val centerR = outerR * 0.39f

        // 1. ROTATING BEZEL LAYER: The brushed titanium gradient and outer knurled teeth turn with finger
        canvas.save()
        canvas.rotate(bezelContinuousRotationDeg, cx, cy)

        discPaint.shader = SweepGradient(
            cx, cy,
            intArrayOf(
                Color.parseColor("#141720"),
                Color.parseColor("#252A3B"),
                Color.parseColor("#141720"),
                Color.parseColor("#252A3B"),
                Color.parseColor("#141720")
            ),
            null
        )
        canvas.drawCircle(cx, cy, outerR, discPaint)
        canvas.drawCircle(cx, cy, outerR, borderPaint)

        // Machine grooves
        canvas.drawCircle(cx, cy, outerR * 0.84f, groovePaint)
        canvas.drawCircle(cx, cy, outerR * 0.68f, groovePaint)

        // Precision mechanical knurled teeth along the outer perimeter bevel (72 radial tick ridges)
        val numTeeth = 72
        val toothInner = outerR * 0.94f
        val toothOuter = outerR * 0.99f
        for (i in 0 until numTeeth) {
            val rad = Math.toRadians((i * (360.0 / numTeeth)))
            val x1 = cx + toothInner * cos(rad).toFloat()
            val y1 = cy + toothInner * sin(rad).toFloat()
            val x2 = cx + toothOuter * cos(rad).toFloat()
            val y2 = cy + toothOuter * sin(rad).toFloat()
            canvas.drawLine(x1, y1, x2, y2, knurlToothPaint)
        }
        canvas.restore()

        // 2. FIXED ARROW LAYER: 4 directional chevrons stay strictly fixed in Up, Down, Left, Right positions!
        val chevDist = outerR * 0.69f
        val chevSize = outerR * 0.062f
        val pressOffset = outerR * 0.018f
        drawChevron(
            canvas,
            cx,
            cy - chevDist - (if (activeZone == Zone.UP) pressOffset else 0f),
            chevSize,
            0f,
            activeZone == Zone.UP
        )
        drawChevron(
            canvas,
            cx,
            cy + chevDist + (if (activeZone == Zone.DOWN) pressOffset else 0f),
            chevSize,
            180f,
            activeZone == Zone.DOWN
        )
        drawChevron(
            canvas,
            cx - chevDist - (if (activeZone == Zone.LEFT) pressOffset else 0f),
            cy,
            chevSize,
            270f,
            activeZone == Zone.LEFT
        )
        drawChevron(
            canvas,
            cx + chevDist + (if (activeZone == Zone.RIGHT) pressOffset else 0f),
            cy,
            chevSize,
            90f,
            activeZone == Zone.RIGHT
        )

        // 3. FIXED CENTER OK BUTTON (Displays real volume % while rotating, or OK in idle)
        val okScale = if (!isRotatingVolume && activeZone == Zone.CENTER) 0.90f else 1.0f
        canvas.save()
        canvas.scale(okScale, okScale, cx, cy)
        canvas.drawCircle(cx, cy, centerR, centerPaint)
        canvas.drawCircle(cx, cy, centerR, centerBorderPaint)

        if (isRotatingVolume) {
            val pctText = "$volumePercent%"
            val textY = cy - (okTextPaint.descent() + okTextPaint.ascent()) / 2f - outerR * 0.025f
            canvas.drawText(pctText, cx, textY, okTextPaint)
            canvas.drawText("ЗВУК", cx, textY + outerR * 0.12f, volSubPaint)
        } else {
            val textY = cy - (okTextPaint.descent() + okTextPaint.ascent()) / 2f
            canvas.drawText("OK", cx, textY, okTextPaint)
        }
        canvas.restore()
    }

    private fun drawChevron(
        canvas: Canvas,
        x: Float,
        y: Float,
        size: Float,
        rotationDeg: Float,
        highlighted: Boolean
    ) {
        chevronPaint.color = if (highlighted) Color.WHITE else Color.parseColor("#9BA3B8")
        canvas.save()
        canvas.translate(x, y)
        canvas.rotate(rotationDeg)
        val path = Path().apply {
            moveTo(-size, size * 0.45f)
            lineTo(0f, -size * 0.55f)
            lineTo(size, size * 0.45f)
        }
        canvas.drawPath(path, chevronPaint)
        canvas.restore()
    }

    private fun apply3dMechanicalTilt(zone: Zone) {
        val density = resources.displayMetrics.density
        val shift = 3.2f * density
        animate().cancel()
        when (zone) {
            Zone.UP -> animate()
                .rotationX(8.5f)
                .rotationY(0f)
                .translationX(0f)
                .translationY(-shift)
                .scaleX(0.985f)
                .scaleY(0.985f)
                .setDuration(65L)
                .setInterpolator(DecelerateInterpolator())
                .start()
            Zone.DOWN -> animate()
                .rotationX(-8.5f)
                .rotationY(0f)
                .translationX(0f)
                .translationY(shift)
                .scaleX(0.985f)
                .scaleY(0.985f)
                .setDuration(65L)
                .setInterpolator(DecelerateInterpolator())
                .start()
            Zone.LEFT -> animate()
                .rotationX(0f)
                .rotationY(-8.5f)
                .translationX(-shift)
                .translationY(0f)
                .scaleX(0.985f)
                .scaleY(0.985f)
                .setDuration(65L)
                .setInterpolator(DecelerateInterpolator())
                .start()
            Zone.RIGHT -> animate()
                .rotationX(0f)
                .rotationY(8.5f)
                .translationX(shift)
                .translationY(0f)
                .scaleX(0.985f)
                .scaleY(0.985f)
                .setDuration(65L)
                .setInterpolator(DecelerateInterpolator())
                .start()
            Zone.CENTER -> animate()
                .rotationX(0f)
                .rotationY(0f)
                .translationX(0f)
                .translationY(1.8f * density)
                .scaleX(0.965f)
                .scaleY(0.965f)
                .setDuration(65L)
                .setInterpolator(DecelerateInterpolator())
                .start()
            Zone.NONE -> reset3dMechanicalTilt()
        }
    }

    private fun reset3dMechanicalTilt() {
        animate().cancel()
        animate()
            .rotationX(0f)
            .rotationY(0f)
            .translationX(0f)
            .translationY(0f)
            .scaleX(1f)
            .scaleY(1f)
            .setDuration(260L)
            .setInterpolator(OvershootInterpolator(2.3f))
            .start()
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val cx = width / 2f
        val cy = height / 2f
        val outerR = min(cx, cy) - 6f
        val centerR = outerR * 0.39f

        val dx = event.x - cx
        val dy = event.y - cy
        val dist = hypot(dx, dy)
        val angleDeg = computeAngleDeg(dx, dy)

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                if (dist > outerR * 1.08f) return false
                isRotatingVolume = false
                accumulatedRotationDeg = 0f
                lastTouchAngleDeg = angleDeg
                activeZone = detectZone(dx, dy, dist, centerR)
                apply3dMechanicalTilt(activeZone)
                onZonePressedHaptic?.invoke()
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (dist > centerR * 0.95f) {
                    var delta = angleDeg - lastTouchAngleDeg
                    if (delta > 180f) delta -= 360f
                    if (delta < -180f) delta += 360f

                    if (abs(delta) < 45f) {
                        accumulatedRotationDeg += delta
                        bezelContinuousRotationDeg += delta
                    }
                    lastTouchAngleDeg = angleDeg

                    if (!isRotatingVolume && abs(accumulatedRotationDeg) >= 15f) {
                        isRotatingVolume = true
                        activeZone = Zone.NONE
                        reset3dMechanicalTilt()
                    }

                    val stepThreshold = 18f
                    while (accumulatedRotationDeg >= stepThreshold) {
                        accumulatedRotationDeg -= stepThreshold
                        onZonePressedHaptic?.invoke()
                        onVolumeRotaryStep?.invoke(1)
                    }
                    while (accumulatedRotationDeg <= -stepThreshold) {
                        accumulatedRotationDeg += stepThreshold
                        onZonePressedHaptic?.invoke()
                        onVolumeRotaryStep?.invoke(-1)
                    }
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP -> {
                val wasRotating = isRotatingVolume
                val triggered = activeZone
                isRotatingVolume = false
                activeZone = Zone.NONE
                accumulatedRotationDeg = 0f
                reset3dMechanicalTilt()
                invalidate()
                if (!wasRotating && triggered != Zone.NONE) {
                    onZoneClicked?.invoke(triggered)
                }
                return true
            }
            MotionEvent.ACTION_CANCEL -> {
                isRotatingVolume = false
                activeZone = Zone.NONE
                accumulatedRotationDeg = 0f
                reset3dMechanicalTilt()
                invalidate()
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun computeAngleDeg(dx: Float, dy: Float): Float {
        var deg = Math.toDegrees(atan2(dy.toDouble(), dx.toDouble())).toFloat()
        if (deg < 0f) deg += 360f
        return deg
    }

    private fun detectZone(dx: Float, dy: Float, dist: Float, centerR: Float): Zone {
        if (dist <= centerR) return Zone.CENTER
        val deg = computeAngleDeg(dx, dy)
        return when {
            deg >= 315f || deg < 45f -> Zone.RIGHT
            deg >= 45f && deg < 135f -> Zone.DOWN
            deg >= 135f && deg < 225f -> Zone.LEFT
            else -> Zone.UP
        }
    }
}
