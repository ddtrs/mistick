package com.smartconsole.touch.network

import android.graphics.Color
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec

/**
 * Tuya OpenAPI v2.0 controller (https://openapi.tuyaeu.com).
 *
 * What was wrong before: power on/off worked, colour did not. The old code sent colour as a
 * 12-char hex string, which the cloud API does not accept for most strips. Tuya strips use
 * either `colour_data_v2` (h 0-360, s/v 0-1000) or `colour_data` (h 0-360, s/v 0-255), both as JSON.
 *
 * Now:
 *  1. The device specification is read once, so the right DP code and value ranges are used.
 *     If the specification is not available for the project, several known formats are tried
 *     and the first one that works is remembered.
 *  2. Commands are conflated per device: while one request is in flight only the LATEST wanted
 *     state is kept, so dragging the wheel/sliders is live but never builds up a queue (no lag,
 *     no out-of-order results).
 *  3. The last error is reported through [onError] so a failure is visible, not silent.
 */
class TuyaController(
    private val clientId: String = "dvrtg3uh53ty5wfv4dam",
    private val clientSecret: String = "891832be155644d2921fa5921b64ff27",
    val stripDeviceId: String = "bf4adac28e8e4f5b0bsfuq",
    val sconceDeviceId: String = "bf4adac28e8e4f5b0bsfuq_sconce"
) {
    companion object {
        private const val BASE_URL = "https://openapi.tuyaeu.com"
        private val JSON_MEDIA_TYPE = "application/json; charset=utf-8".toMediaType()
    }

    enum class LightPreset(
        val id: String,
        val titleRu: String,
        val hue: Int,
        val satPromille: Int,
        val valPromille: Int,
        val previewHexColor: Int
    ) {
        CYBER("cyber", "Кибер", 184, 1000, 1000, Color.parseColor("#00F0FF")),
        SAPPHIRE("sapphire", "Сапфир", 224, 1000, 1000, Color.parseColor("#1E5BFF")),
        VIOLET("violet", "Фиолет", 271, 850, 1000, Color.parseColor("#8A2BE2")),
        RASPBERRY("raspberry", "Малина", 336, 1000, 1000, Color.parseColor("#FF0066")),
        SUNSET("sunset", "Закат", 20, 1000, 1000, Color.parseColor("#FF5500")),
        WARM("warm", "Тёплый", 34, 280, 1000, Color.parseColor("#FFCF96"))
    }

    /** Called when a command definitively failed (message is short and human readable). */
    @Volatile
    var onError: ((String) -> Unit)? = null

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.SECONDS)
        .readTimeout(4, TimeUnit.SECONDS)
        .writeTimeout(3, TimeUnit.SECONDS)
        .build()

    @Volatile private var cachedAccessToken: String? = null
    @Volatile private var tokenExpiresAtMs: Long = 0L
    @Volatile private var serverTimeOffsetMs: Long = 0L

    // ------------------------------------------------------------------ Capabilities

    private class Caps(
        val switchCode: String,
        val colourCode: String?,   // colour_data_v2 | colour_data | null (unknown)
        val sMax: Int,
        val vMax: Int,
        val hasWorkMode: Boolean
    )

    private val capsCache = ConcurrentHashMap<String, Caps>()

    /** Formats tried when the specification could not be read. */
    private enum class ColourFormat { V2_OBJECT, V2_STRING, V1_OBJECT, V1_STRING, HEX12 }

    private val learnedFormat = ConcurrentHashMap<String, Pair<ColourFormat, Boolean>>()

    private class Result(val ok: Boolean, val code: Int, val msg: String)

    private fun loadCaps(deviceId: String): Caps? {
        capsCache[deviceId]?.let { return it }
        val resp = signedRequest("GET", "/v1.0/devices/$deviceId/specifications", null)
        if (!resp.ok) return null
        return try {
            val json = JSONObject(resp.msg).getJSONObject("result")
            val functions = json.optJSONArray("functions") ?: JSONArray()
            var switchCode = "switch_led"
            var colourCode: String? = null
            var sMax = 1000
            var vMax = 1000
            var hasWorkMode = false
            for (i in 0 until functions.length()) {
                val f = functions.getJSONObject(i)
                when (val code = f.optString("code")) {
                    "switch_led", "switch_led_1", "switch" -> switchCode = code
                    "work_mode" -> hasWorkMode = true
                    "colour_data_v2", "colour_data" -> {
                        if (colourCode == null || code == "colour_data_v2") {
                            colourCode = code
                            val values = JSONObject(f.optString("values", "{}"))
                            sMax = values.optJSONObject("s")?.optInt("max", if (code == "colour_data_v2") 1000 else 255)
                                ?: if (code == "colour_data_v2") 1000 else 255
                            vMax = values.optJSONObject("v")?.optInt("max", if (code == "colour_data_v2") 1000 else 255)
                                ?: if (code == "colour_data_v2") 1000 else 255
                        }
                    }
                }
            }
            val caps = Caps(switchCode, colourCode, sMax, vMax, hasWorkMode)
            capsCache[deviceId] = caps
            caps
        } catch (_: Exception) {
            null
        }
    }

    /** Fetch token and capabilities in advance so the first tap is not slow. */
    suspend fun warmUp(deviceId: String = stripDeviceId) {
        withContext(Dispatchers.IO) {
            getValidAccessToken()
            loadCaps(deviceId)
        }
    }

    // ------------------------------------------------------------------ Public API

    /** Real on/off state from Tuya cloud (null if unknown). */
    suspend fun fetchPower(deviceId: String): Boolean? = withContext(Dispatchers.IO) {
        val r = signedRequest("GET", "/v1.0/iot-03/devices/$deviceId/status", null)
        if (!r.ok) return@withContext null
        try {
            val arr = JSONObject(r.msg).getJSONArray("result")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val c = o.optString("code")
                if (c == "switch_led" || c == "switch_led_1" || c == "switch") return@withContext o.getBoolean("value")
            }
            null
        } catch (_: Exception) { null }
    }

    suspend fun setPower(deviceId: String, enabled: Boolean): Boolean = withContext(Dispatchers.IO) {
        val code = loadCaps(deviceId)?.switchCode ?: "switch_led"
        val commands = JSONArray().put(JSONObject().put("code", code).put("value", enabled))
        val r = sendDeviceCommands(deviceId, commands)
        if (!r.ok) reportError(deviceId, r)
        r.ok
    }

    suspend fun applyPreset(deviceId: String = stripDeviceId, preset: LightPreset): Boolean =
        setHsvColor(deviceId, preset.hue, preset.satPromille, preset.valPromille)

    /**
     * Sets colour + brightness. [satPromille]/[valPromille] are 0..1000 and are scaled to the
     * range the device actually reports.
     */
    suspend fun setHsvColor(
        deviceId: String = stripDeviceId,
        hue: Int,
        satPromille: Int,
        valPromille: Int
    ): Boolean = withContext(Dispatchers.IO) {
        val h = hue.coerceIn(0, 360)
        val s = satPromille.coerceIn(10, 1000)
        val v = valPromille.coerceIn(10, 1000)

        val caps = loadCaps(deviceId)
        if (caps != null && caps.colourCode != null) {
            val isV2 = caps.colourCode == "colour_data_v2"
            val format = if (isV2) ColourFormat.V2_OBJECT else ColourFormat.V1_OBJECT
            val sDev = (s * caps.sMax / 1000).coerceAtLeast(1)
            val vDev = (v * caps.vMax / 1000).coerceAtLeast(1)
            var r = sendDeviceCommands(deviceId, buildColour(caps.switchCode, format, h, sDev, vDev, caps.hasWorkMode))
            if (!r.ok) {
                // Some firmwares want the JSON as a string
                val stringFormat = if (isV2) ColourFormat.V2_STRING else ColourFormat.V1_STRING
                r = sendDeviceCommands(deviceId, buildColour(caps.switchCode, stringFormat, h, sDev, vDev, caps.hasWorkMode))
            }
            if (!r.ok) reportError(deviceId, r)
            return@withContext r.ok
        }

        // Specification unavailable: use what worked last time, otherwise probe known formats.
        learnedFormat[deviceId]?.let { (format, withMode) ->
            val r = sendDeviceCommands(deviceId, buildGuess(format, h, s, v, withMode))
            if (r.ok) return@withContext true
            learnedFormat.remove(deviceId)
        }
        var last = Result(false, -1, "no response")
        for (format in ColourFormat.values()) {
            for (withMode in listOf(true, false)) {
                val r = sendDeviceCommands(deviceId, buildGuess(format, h, s, v, withMode))
                if (r.ok) {
                    learnedFormat[deviceId] = format to withMode
                    return@withContext true
                }
                last = r
                if (r.code == 1004 || r.code == -2) break // token/network problem: probing will not help
            }
        }
        reportError(deviceId, last)
        false
    }

    // ------------------------------------------------------------------ Conflated sender

    private class Slot {
        var power: Boolean? = null
        var hsv: IntArray? = null
        var running = false
    }

    private val slots = ConcurrentHashMap<String, Slot>()

    /** Power command; always the latest wins, never queued behind older ones. */
    fun requestPower(scope: CoroutineScope, deviceId: String, enabled: Boolean) {
        val slot = slots.getOrPut(deviceId) { Slot() }
        val start: Boolean
        synchronized(slot) {
            slot.power = enabled
            if (!enabled) slot.hsv = null
            start = !slot.running
            if (start) slot.running = true
        }
        if (start) launchWorker(scope, deviceId, slot)
    }

    /** Colour command (also switches the light on). Safe to call on every touch move. */
    fun requestHsv(scope: CoroutineScope, deviceId: String, hue: Int, satPromille: Int, valPromille: Int) {
        val slot = slots.getOrPut(deviceId) { Slot() }
        val start: Boolean
        synchronized(slot) {
            slot.hsv = intArrayOf(hue, satPromille, valPromille)
            slot.power = null
            start = !slot.running
            if (start) slot.running = true
        }
        if (start) launchWorker(scope, deviceId, slot)
    }

    fun requestPreset(scope: CoroutineScope, deviceId: String, preset: LightPreset) =
        requestHsv(scope, deviceId, preset.hue, preset.satPromille, preset.valPromille)

    private fun launchWorker(scope: CoroutineScope, deviceId: String, slot: Slot) {
        scope.launch(Dispatchers.IO) {
            try {
                while (true) {
                    var power: Boolean? = null
                    var hsv: IntArray? = null
                    synchronized(slot) {
                        power = slot.power
                        hsv = slot.hsv
                        slot.power = null
                        slot.hsv = null
                        if (power == null && hsv == null) slot.running = false
                    }
                    val c = hsv
                    val p = power
                    when {
                        c != null -> setHsvColor(deviceId, c[0], c[1], c[2])
                        p != null -> setPower(deviceId, p)
                        else -> return@launch
                    }
                }
            } catch (t: Throwable) {
                synchronized(slot) { slot.running = false }
                throw t
            }
        }
    }

    // ------------------------------------------------------------------ Command building

    private fun buildColour(
        switchCode: String,
        format: ColourFormat,
        h: Int, s: Int, v: Int,
        withMode: Boolean
    ): JSONArray {
        val arr = JSONArray()
        arr.put(JSONObject().put("code", switchCode).put("value", true))
        if (withMode) arr.put(JSONObject().put("code", "work_mode").put("value", "colour"))
        val hsv = JSONObject().put("h", h).put("s", s).put("v", v)
        when (format) {
            ColourFormat.V2_OBJECT -> arr.put(JSONObject().put("code", "colour_data_v2").put("value", hsv))
            ColourFormat.V2_STRING -> arr.put(JSONObject().put("code", "colour_data_v2").put("value", hsv.toString()))
            ColourFormat.V1_OBJECT -> arr.put(JSONObject().put("code", "colour_data").put("value", hsv))
            ColourFormat.V1_STRING -> arr.put(JSONObject().put("code", "colour_data").put("value", hsv.toString()))
            ColourFormat.HEX12 -> arr.put(
                JSONObject().put("code", "colour_data").put("value", String.format("%04x%04x%04x", h, s, v))
            )
        }
        return arr
    }

    /** s/v come in promille (0..1000); v1 formats need 0..255. */
    private fun buildGuess(format: ColourFormat, h: Int, sP: Int, vP: Int, withMode: Boolean): JSONArray {
        val v1 = format == ColourFormat.V1_OBJECT || format == ColourFormat.V1_STRING
        val s = if (v1) (sP * 255 / 1000).coerceAtLeast(1) else sP
        val v = if (v1) (vP * 255 / 1000).coerceAtLeast(1) else vP
        return buildColour("switch_led", format, h, s, v, withMode)
    }

    private fun reportError(deviceId: String, r: Result) {
        val who = if (deviceId == sconceDeviceId) "Бра" else "Лента"
        onError?.invoke("$who: Tuya ${r.code} ${r.msg}".trim())
    }

    // ------------------------------------------------------------------ HTTP / signing

    private fun sendDeviceCommands(deviceId: String, commands: JSONArray): Result {
        val payload = JSONObject().put("commands", commands).toString()
        val path = "/v1.0/iot-03/devices/$deviceId/commands"
        val r = signedRequest("POST", path, payload)
        if (r.ok) return Result(true, 0, "")
        return Result(false, r.code, r.msg.take(80))
    }

    /**
     * Executes a signed request. On success Result.msg holds the raw response body.
     * On failure Result.code/msg hold the Tuya error code and message.
     */
    private fun signedRequest(method: String, path: String, body: String?, isRetry: Boolean = false): Result {
        val token = getValidAccessToken() ?: return Result(false, -2, "нет токена (сеть/ключи)")
        val timestamp = getCalibratedTimestamp().toString()
        val contentSha256 = sha256Hex(body ?: "")
        val stringToSign = "$method\n$contentSha256\n\n$path"
        val signature = hmacSha256(clientId + token + timestamp + stringToSign, clientSecret)

        val builder = Request.Builder()
            .url(BASE_URL + path)
            .addHeader("client_id", clientId)
            .addHeader("access_token", token)
            .addHeader("sign", signature)
            .addHeader("t", timestamp)
            .addHeader("sign_method", "HMAC-SHA256")
        if (method == "POST") builder.post((body ?: "").toRequestBody(JSON_MEDIA_TYPE)) else builder.get()

        return try {
            httpClient.newCall(builder.build()).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (bodyStr.isEmpty()) return Result(response.isSuccessful, response.code, "пустой ответ")
                val json = JSONObject(bodyStr)
                val serverT = json.optLong("t", 0L)
                if (serverT > 0L) serverTimeOffsetMs = serverT - System.currentTimeMillis()
                val code = json.optInt("code", 0)
                if ((code == 1004 || code == 1010 || code == 1013) && !isRetry) {
                    cachedAccessToken = null
                    return signedRequest(method, path, body, isRetry = true)
                }
                if (json.optBoolean("success", false)) Result(true, 0, bodyStr)
                else Result(false, code, json.optString("msg", "ошибка"))
            }
        } catch (e: Exception) {
            if (!isRetry) signedRequest(method, path, body, isRetry = true)
            else Result(false, -2, "сеть: ${e.javaClass.simpleName}")
        }
    }

    private fun getCalibratedTimestamp(): Long = System.currentTimeMillis() + serverTimeOffsetMs

    private fun getValidAccessToken(): String? {
        val now = getCalibratedTimestamp()
        val existing = cachedAccessToken
        if (existing != null && now < tokenExpiresAtMs) return existing
        return requestTokenInternal(isRetry = false)
    }

    private fun requestTokenInternal(isRetry: Boolean): String? {
        val path = "/v1.0/token?grant_type=1"
        val timestamp = getCalibratedTimestamp().toString()
        val stringToSign = "GET\n${sha256Hex("")}\n\n$path"
        val signature = hmacSha256(clientId + timestamp + stringToSign, clientSecret)

        val request = Request.Builder()
            .url(BASE_URL + path)
            .get()
            .addHeader("client_id", clientId)
            .addHeader("sign", signature)
            .addHeader("t", timestamp)
            .addHeader("sign_method", "HMAC-SHA256")
            .build()

        return try {
            httpClient.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (bodyStr.isEmpty()) return null
                val json = JSONObject(bodyStr)
                val serverT = json.optLong("t", 0L)
                if (serverT > 0L) serverTimeOffsetMs = serverT - System.currentTimeMillis()

                val code = json.optInt("code", 0)
                if ((code == 1004 || code == 1013) && !isRetry) return requestTokenInternal(isRetry = true)
                if (!json.optBoolean("success", false)) return null

                val result = json.getJSONObject("result")
                val token = result.getString("access_token")
                val expireTimeSec = result.optLong("expire_time", 7200L)
                cachedAccessToken = token
                tokenExpiresAtMs = getCalibratedTimestamp() + (expireTimeSec - 120) * 1000L
                token
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun sha256Hex(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        return digest.digest(input.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    }

    private fun hmacSha256(data: String, secret: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        mac.init(SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256"))
        return mac.doFinal(data.toByteArray(Charsets.UTF_8)).joinToString("") { "%02X".format(it) }
    }
}
