@echo off
chcp 65001 >nul
echo ============================================================================
echo Оптимизация Huawei Y5 под систему Smart Touch Console (удаление мусора EMUI)
echo ============================================================================
adb wait-for-device

for %%P in (
  com.huawei.appmarket
  com.huawei.hicloud
  com.huawei.himovie
  com.huawei.himovie.overseas
  com.huawei.music
  com.huawei.bd
  com.huawei.hiview
  com.huawei.hiviewtunnel
  com.huawei.iaware
  com.huawei.powergenie
  com.huawei.android.thememanager
  com.huawei.android.tips
  com.huawei.phoneservice
  com.huawei.hifolder
  com.huawei.gameassistant
  com.huawei.magazine
  com.huawei.compass
  com.android.email
  com.android.calendar
  com.android.mediacenter
  com.google.android.youtube
  com.google.android.apps.maps
  com.google.android.apps.photos
  com.google.android.gm
  com.google.android.music
  com.google.android.videos
) do (
  echo Отключение %%P ...
  adb shell pm uninstall -k --user 0 %%P >nul 2>&1
  adb shell pm disable-user --user 0 %%P >nul 2>&1
)

echo Назначение Smart Touch Console главным домашним лаунчером...
adb shell cmd package set-home-activity com.smartconsole.touch/.MainActivity
adb shell settings put global wifi_sleep_policy 2

echo Готово! Телефон полностью очищен и переведен в режим консоли.
pause
