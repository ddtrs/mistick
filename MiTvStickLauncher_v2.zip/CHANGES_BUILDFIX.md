# Исправление сборки (AssistantEngine.kt)

CI падал на compileDebugKotlin / compileReleaseKotlin. Исправлено:

1. restorePreviousLightsState: вместо PendingLedAction(turnOn = ..., hue = ...) (sealed-класс, конструктор недоступен)
   теперь PendingLedAction.ColorHsv / PendingLedAction.WhiteCct.
   Лента и лампа в цветном режиме -> ColorHsv(hue, sat, bright); лампа в белом режиме -> WhiteCct(bright, temp).
   Включение отдельной командой Power не добавлено: как и раньше, цветовая/белая команда сама включает устройство.
2. restoreSessionWithRefreshTokenBlocking: удалены два лишних оператора с несуществующей здесь переменной appCtx
   и дубль put("refresh_token", ...). Остался один put("refresh_token", refreshToken).

Сборка локально не проверялась (нет Android SDK) — проверяйте CI.
