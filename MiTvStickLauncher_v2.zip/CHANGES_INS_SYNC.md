# Синхронизация бота отметок с Эхо (этап 2), versionCode 96

Сделано по `TZ_Insulin_Echo_Sync_v2.md`.

## Воркер (cloudflare_worker/worker.js)
- Новые защищённые маршруты `/ins/mark` (POST), `/ins/last` (GET), `/ins/undo` (POST), `/ins/pending` (GET).
  Требуют заголовок `x-app-secret`, равный секрету Воркера `GATEWAY_APP_SECRET`: не настроен — 503, неверный — 401.
- В Durable Object `InsulinBot` добавлены внутренние маршруты `/api/*` и методы `apiMark`, `apiLast`, `apiUndo`, `apiPending`.
  Тексты для озвучки формирует Воркер, склонения через `insPlural`, `insFmtRelSpoken`.
- Сообщение в Telegram после голосовой отметки и пересчёт цепочки не задерживают ответ приложению дольше 3,5 с.

## Приложение
- `data/InsulinSync.kt`: `markByVoice`, `askLast`, `undoByVoice`, `onTick` (опрос `/ins/pending` раз в минуту).
- `GeminiCloudClient.kt`: теги `INS_MARK`, `INS_LAST`, `INS_UNDO` и раздел промпта «УКОЛ: ОТМЕТКИ И ВОПРОСЫ».
- `ScheduledTaskManager.kt`: вызов `InsulinSync.onTick` в цикле.

## Нужно один раз
В Cloudflare добавить секрет Воркера `GATEWAY_APP_SECRET` со значением, которое приложение отправляет в `x-app-secret`.
