plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.mitv.customlauncher"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.mitv.customlauncher"
        minSdk = 28
        targetSdk = 30
        versionCode = 76
        versionName = "0.8.0"

        ndk {
            abiFilters += listOf("armeabi-v7a", "arm64-v8a")
        }
    }

    signingConfigs {
        create("permanentRelease") {
            storeFile = file("mitv-release-key.jks")
            storePassword = "mitvpass123"
            keyAlias = "mitvkey"
            keyPassword = "mitvpass123"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            signingConfig = signingConfigs.getByName("permanentRelease")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("permanentRelease")
        }
    }

    buildFeatures {
        viewBinding = true
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.activity:activity-ktx:1.8.2")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.7.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")

    testImplementation("junit:junit:4.13.2")
    testImplementation("org.jetbrains.kotlinx:kotlinx-coroutines-test:1.7.3")
}


tasks.register("buildRustNative") {
    description = "Compiles rust_core into liblauncher_native.so for armeabi-v7a and arm64-v8a if cargo and NDK are available"
    doLast {
        val rustDir = file("../rust_core")
        if (!rustDir.exists()) return@doLast
        try {
            val ndkDir = System.getenv("ANDROID_NDK_HOME")
                ?: System.getenv("ANDROID_NDK_ROOT")
                ?: System.getenv("ANDROID_HOME")?.let { "$it/ndk" }?.let { base ->
                    file(base).listFiles()?.sortedByDescending { it.name }?.firstOrNull()?.absolutePath
                }
            if (ndkDir != null && file(ndkDir).exists()) {
                val prebuiltDir = file("$ndkDir/toolchains/llvm/prebuilt")
                val hostDir = prebuiltDir.listFiles()?.firstOrNull()
                val binDir = hostDir?.resolve("bin")
                if (binDir != null && binDir.exists()) {
                    val clangArm64 = binDir.resolve("aarch64-linux-android28-clang").absolutePath
                    val clangArmv7 = binDir.resolve("armv7a-linux-androideabi28-clang").absolutePath
                    val arBin = binDir.resolve("llvm-ar").absolutePath

                    ProcessBuilder("rustup", "target", "add", "aarch64-linux-android", "armv7-linux-androideabi")
                        .directory(rustDir)
                        .redirectErrorStream(true)
                        .start()
                        .waitFor()

                    val pb = ProcessBuilder(
                        "cargo", "build", "--release",
                        "--target", "aarch64-linux-android",
                        "--target", "armv7-linux-androideabi"
                    ).directory(rustDir).redirectErrorStream(true)
                    val env = pb.environment()
                    env["CARGO_TARGET_AARCH64_LINUX_ANDROID_LINKER"] = clangArm64
                    env["CARGO_TARGET_ARMV7_LINUX_ANDROIDEABI_LINKER"] = clangArmv7
                    env["AR"] = arBin
                    val proc = pb.start()
                    proc.inputStream.bufferedReader().use { r -> println(r.readText()) }
                    proc.waitFor()

                    val soArm64 = rustDir.resolve("target/aarch64-linux-android/release/liblauncher_native.so")
                    if (soArm64.exists()) {
                        val dst64 = file("src/main/jniLibs/arm64-v8a/liblauncher_native.so")
                        dst64.parentFile.mkdirs()
                        soArm64.copyTo(dst64, overwrite = true)
                        println("Packaged Rust native library: ${dst64.absolutePath} (${dst64.length()} bytes)")
                    }
                    val soArmv7 = rustDir.resolve("target/armv7-linux-androideabi/release/liblauncher_native.so")
                    if (soArmv7.exists()) {
                        val dst32 = file("src/main/jniLibs/armeabi-v7a/liblauncher_native.so")
                        dst32.parentFile.mkdirs()
                        soArmv7.copyTo(dst32, overwrite = true)
                        println("Packaged Rust native library: ${dst32.absolutePath} (${dst32.length()} bytes)")
                    }
                }
            }
        } catch (e: Exception) {
            println("Rust native build skipped or fallback active: ${e.message}")
        }
    }
}

tasks.matching { it.name == "preBuild" }.configureEach {
    dependsOn("buildRustNative")
}
