package com.mitv.customlauncher.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class OutageInterval(
    val startMinuteOfDay: Int,
    val endMinuteOfDay: Int,
    val isMaybe: Boolean = false
) {
    fun formatTimeRange(): String {
        val sh = startMinuteOfDay / 60
        val sm = startMinuteOfDay % 60
        val eh = endMinuteOfDay / 60
        val em = endMinuteOfDay % 60
        return String.format(Locale.US, "%02d:%02d – %02d:%02d", sh, sm, eh, em)
    }

    fun formatDurationUk(): String {
        val totalMin = (endMinuteOfDay - startMinuteOfDay).coerceAtLeast(0)
        val hours = totalMin / 60
        val mins = totalMin % 60
        return when {
            hours > 0 && mins > 0 -> "${hours} год ${mins} хв"
            hours > 0 -> "${hours} год"
            else -> "${mins} хв"
        }
    }
}

data class DayOutageSchedule(
    val dateLabelUk: String = "",
    val halfHourPowerOn: List<Boolean> = List(48) { true },
    val hourStatusCodes: List<String> = List(24) { "yes" },
    val intervals: List<OutageInterval> = emptyList(),
    val isAvailable: Boolean = false
)

data class OutageUiSnapshot(
    val groupCode: String = "2.1",
    val isPowerOnNow: Boolean = true,
    val pillText: String = "Світло є",
    val headerTitle: String = "Світло є",
    val headerSubtitle: String = "Оновлення графіка ДТЕК...",
    val updateTimestamp: String = "—",
    val currentHourKyiv: Int = 0,
    val currentMinuteOfDayKyiv: Int = 0,
    val todaySchedule: DayOutageSchedule = DayOutageSchedule(),
    val tomorrowSchedule: DayOutageSchedule = DayOutageSchedule(),
    val availableGroups: List<String> = DEFAULT_GROUPS
) {
    companion object {
        val DEFAULT_GROUPS = listOf(
            "1.1", "1.2",
            "2.1", "2.2",
            "3.1", "3.2",
            "4.1", "4.2",
            "5.1", "5.2",
            "6.1", "6.2"
        )
    }
}

object OutageRepository {

    private const val OUTAGE_JSON_URL =
        "https://raw.githubusercontent.com/Baskerville42/outage-data-ua/main/data/kyiv-region.json"
    private const val PREF_OUTAGE_GROUP = "pref_outage_group"
    private const val PREF_CACHED_JSON = "pref_cached_outage_json"
    private const val PREF_LAST_FETCH_MS = "pref_outage_last_fetch_ms"

    private val _state = MutableStateFlow(OutageUiSnapshot())
    val state: StateFlow<OutageUiSnapshot> = _state.asStateFlow()

    @Volatile
    private var lastNetworkFetchRealtimeMs: Long = 0L

    @Volatile
    var onOpenScheduleRequested: (() -> Unit)? = null

    @Volatile
    var onGroupChangedCallback: (() -> Unit)? = null

    fun getSelectedGroup(context: Context): String {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(PREF_OUTAGE_GROUP, "2.1") ?: "2.1"
    }

    fun setSelectedGroup(context: Context, groupCode: String) {
        val clean = groupCode.trim().removePrefix("GPV").removePrefix("gpv").trim()
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(PREF_OUTAGE_GROUP, clean).apply()
        recomputeFromCachedJson(context)
        onGroupChangedCallback?.invoke()
    }

    fun cycleNextGroup(context: Context): String {
        val current = getSelectedGroup(context)
        val groups = _state.value.availableGroups.ifEmpty { OutageUiSnapshot.DEFAULT_GROUPS }
        val idx = groups.indexOf(current)
        val nextGroup = if (idx >= 0) groups[(idx + 1) % groups.size] else groups.first()
        setSelectedGroup(context, nextGroup)
        return nextGroup
    }

    fun recomputeFromCachedJson(context: Context) {
        val appCtx = context.applicationContext
        val prefs = appCtx.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val cached = prefs.getString(PREF_CACHED_JSON, null)
        val group = getSelectedGroup(appCtx)
        if (!cached.isNullOrBlank()) {
            val parsed = parseOutageJson(cached, group)
            if (parsed != null) {
                _state.value = parsed
                return
            }
        }
        _state.value = _state.value.copy(groupCode = group)
    }

    suspend fun refreshIfNeeded(context: Context, force: Boolean = false) {
        val appCtx = context.applicationContext
        recomputeFromCachedJson(appCtx)
        val now = System.currentTimeMillis()
        if (!force && (now - lastNetworkFetchRealtimeMs) < 8 * 60 * 1000L && _state.value.todaySchedule.isAvailable) {
            return
        }
        withContext(Dispatchers.IO) {
            var conn: HttpURLConnection? = null
            try {
                val connection = (URL(OUTAGE_JSON_URL).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 7000
                    readTimeout = 9000
                    doInput = true
                    setRequestProperty("Accept", "application/json")
                }
                conn = connection
                if (connection.responseCode in 200..299) {
                    val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    if (body.isNotBlank() && body.contains("fact")) {
                        lastNetworkFetchRealtimeMs = System.currentTimeMillis()
                        val prefs = appCtx.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
                        prefs.edit()
                            .putString(PREF_CACHED_JSON, body)
                            .putLong(PREF_LAST_FETCH_MS, lastNetworkFetchRealtimeMs)
                            .apply()
                        val parsed = parseOutageJson(body, getSelectedGroup(appCtx))
                        if (parsed != null) {
                            _state.value = parsed
                        }
                    }
                }
            } catch (_: Exception) {
            } finally {
                try {
                    conn?.disconnect()
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun parseOutageJson(rawJson: String, selectedGroup: String): OutageUiSnapshot? {
        return try {
            val root = JSONObject(rawJson)
            val fact = root.optJSONObject("fact") ?: return null
            val dataObj = fact.optJSONObject("data") ?: return null

            val updateStr = fact.optString("update", "")
                .ifBlank { fact.optString("updateFact", "") }
                .ifBlank { root.optString("lastUpdated", "—") }

            val kyivTz = TimeZone.getTimeZone("Europe/Kyiv")
            val nowCal = Calendar.getInstance(kyivTz)
            val curHour = nowCal.get(Calendar.HOUR_OF_DAY)
            val curMin = nowCal.get(Calendar.MINUTE)
            val curMinOfDay = curHour * 60 + curMin

            // Определяем начало сегодняшнего дня в Europe/Kyiv
            val todayMidnightCal = (nowCal.clone() as Calendar).apply {
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val todayMidnightSec = todayMidnightCal.timeInMillis / 1000L

            val dayKeys = mutableListOf<Long>()
            val iter = dataObj.keys()
            while (iter.hasNext()) {
                val k = iter.next()
                val ts = k.toLongOrNull()
                if (ts != null) {
                    dayKeys.add(ts)
                }
            }
            dayKeys.sort()
            if (dayKeys.isEmpty()) return null

            val factTodaySec = fact.optLong("today", -1L)
            val chosenTodayKey: Long = when {
                dayKeys.any { kotlin.math.abs(it - todayMidnightSec) < 43200L } ->
                    dayKeys.minByOrNull { kotlin.math.abs(it - todayMidnightSec) } ?: dayKeys.first()
                factTodaySec > 0L && dayKeys.contains(factTodaySec) -> factTodaySec
                else -> dayKeys.first()
            }

            val todayIndex = dayKeys.indexOf(chosenTodayKey).coerceAtLeast(0)
            val tomorrowKey: Long? = dayKeys.getOrNull(todayIndex + 1)

            val todayDayObj = dataObj.optJSONObject(chosenTodayKey.toString())
            val availableGroups = extractAvailableGroups(todayDayObj)

            val todaySched = parseSingleDaySchedule(todayDayObj, selectedGroup, chosenTodayKey, kyivTz)
            val tomorrowSched = if (tomorrowKey != null) {
                parseSingleDaySchedule(dataObj.optJSONObject(tomorrowKey.toString()), selectedGroup, tomorrowKey, kyivTz)
            } else {
                DayOutageSchedule(isAvailable = false)
            }

            val curSlot = (curMinOfDay / 30).coerceIn(0, 47)
            val isPowerOn = if (todaySched.isAvailable) todaySched.halfHourPowerOn[curSlot] else true

            var pillText = "Світло є"
            var headerTitle = "Світло є · Черга $selectedGroup"
            var headerSubtitle = "За графіком сьогодні без відключень"

            if (todaySched.isAvailable) {
                if (isPowerOn) {
                    val nextOffMin = findNextTransitionMinute(
                        todaySched = todaySched,
                        tomorrowSched = tomorrowSched,
                        fromSlot = curSlot + 1,
                        targetPowerOn = false
                    )
                    if (nextOffMin != null) {
                        val clockStr = formatClockMinute(nextOffMin % 1440)
                        val diffMin = (nextOffMin - curMinOfDay).coerceAtLeast(1)
                        val remStr = formatDurationMinutesUk(diffMin)
                        pillText = "до $clockStr"
                        headerTitle = "Світло є · до $clockStr"
                        headerSubtitle = "Залишилось $remStr (Черга $selectedGroup)"
                    } else {
                        pillText = "Світло є"
                        headerTitle = "Світло є · без відключень"
                        headerSubtitle = "За графіком ДТЕК відключень немає"
                    }
                } else {
                    val nextOnMin = findNextTransitionMinute(
                        todaySched = todaySched,
                        tomorrowSched = tomorrowSched,
                        fromSlot = curSlot + 1,
                        targetPowerOn = true
                    )
                    if (nextOnMin != null) {
                        val clockStr = formatClockMinute(nextOnMin % 1440)
                        val diffMin = (nextOnMin - curMinOfDay).coerceAtLeast(1)
                        val remStr = formatDurationMinutesUk(diffMin)
                        pillText = "увімк. $clockStr"
                        headerTitle = "Відключення · до $clockStr"
                        headerSubtitle = "Увімкнення через $remStr"
                    } else {
                        pillText = "Відключення"
                        headerTitle = "Планове відключення"
                        headerSubtitle = "Черга $selectedGroup"
                    }
                }
            }

            OutageUiSnapshot(
                groupCode = selectedGroup,
                isPowerOnNow = isPowerOn,
                pillText = pillText,
                headerTitle = headerTitle,
                headerSubtitle = headerSubtitle,
                updateTimestamp = updateStr,
                currentHourKyiv = curHour,
                currentMinuteOfDayKyiv = curMinOfDay,
                todaySchedule = todaySched,
                tomorrowSchedule = tomorrowSched,
                availableGroups = availableGroups
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun extractAvailableGroups(dayObj: JSONObject?): List<String> {
        if (dayObj == null) return OutageUiSnapshot.DEFAULT_GROUPS
        val list = mutableListOf<String>()
        val iter = dayObj.keys()
        while (iter.hasNext()) {
            val k = iter.next().removePrefix("GPV").removePrefix("gpv").trim()
            if (k.isNotEmpty()) {
                list.add(k)
            }
        }
        return if (list.isNotEmpty()) {
            list.sortedBy { (it.substringBefore('.').toIntOrNull() ?: 99) * 100 + (it.substringAfter('.', "0").toIntOrNull() ?: 0) }
        } else {
            OutageUiSnapshot.DEFAULT_GROUPS
        }
    }

    private fun parseSingleDaySchedule(
        dayObj: JSONObject?,
        groupCode: String,
        dayTimestampSec: Long,
        kyivTz: TimeZone
    ): DayOutageSchedule {
        if (dayObj == null) return DayOutageSchedule(isAvailable = false)
        var groupObj = dayObj.optJSONObject("GPV$groupCode") ?: dayObj.optJSONObject(groupCode)
        if (groupObj == null) {
            val iter = dayObj.keys()
            if (iter.hasNext()) {
                groupObj = dayObj.optJSONObject(iter.next())
            }
        }
        if (groupObj == null) return DayOutageSchedule(isAvailable = false)

        val halfHours = BooleanArray(48) { true }
        val hourCodes = Array(24) { "yes" }
        val usesZeroIndex = groupObj.has("0") && !groupObj.has("24")

        for (h in 0 until 24) {
            val key = if (usesZeroIndex) h.toString() else (h + 1).toString()
            val rawVal = groupObj.optString(key, "yes").lowercase(Locale.US).trim()
            hourCodes[h] = rawVal
            when (rawVal) {
                "no", "off", "false", "outage", "maybe" -> {
                    halfHours[h * 2] = false
                    halfHours[h * 2 + 1] = false
                }
                "first", "mfirst" -> {
                    halfHours[h * 2] = false
                    halfHours[h * 2 + 1] = true
                }
                "second", "msecond" -> {
                    halfHours[h * 2] = true
                    halfHours[h * 2 + 1] = false
                }
                else -> {
                    halfHours[h * 2] = true
                    halfHours[h * 2 + 1] = true
                }
            }
        }

        // Проверяем, не пустой ли график на завтра (если все "yes", но в объекте меньше 12 ключей)
        if (groupObj.length() == 0) {
            return DayOutageSchedule(isAvailable = false)
        }

        val intervals = mutableListOf<OutageInterval>()
        var slot = 0
        while (slot < 48) {
            if (!halfHours[slot]) {
                val startMin = slot * 30
                var endSlot = slot + 1
                var hasMaybe = hourCodes[slot / 2] == "maybe"
                while (endSlot < 48 && !halfHours[endSlot]) {
                    if (hourCodes[endSlot / 2] == "maybe") hasMaybe = true
                    endSlot++
                }
                val endMin = endSlot * 30
                intervals.add(OutageInterval(startMin, endMin, isMaybe = hasMaybe))
                slot = endSlot
            } else {
                slot++
            }
        }

        val fmt = SimpleDateFormat("d MMMM", Locale("uk", "UA")).apply { timeZone = kyivTz }
        val dateLabel = fmt.format(Date(dayTimestampSec * 1000L))

        return DayOutageSchedule(
            dateLabelUk = dateLabel,
            halfHourPowerOn = halfHours.toList(),
            hourStatusCodes = hourCodes.toList(),
            intervals = intervals,
            isAvailable = true
        )
    }

    private fun findNextTransitionMinute(
        todaySched: DayOutageSchedule,
        tomorrowSched: DayOutageSchedule,
        fromSlot: Int,
        targetPowerOn: Boolean
    ): Int? {
        for (s in fromSlot.coerceAtLeast(0) until 48) {
            if (todaySched.halfHourPowerOn[s] == targetPowerOn) {
                return s * 30
            }
        }
        if (tomorrowSched.isAvailable) {
            for (s in 0 until 48) {
                if (tomorrowSched.halfHourPowerOn[s] == targetPowerOn) {
                    return 1440 + s * 30
                }
            }
        } else if (targetPowerOn) {
            // Если сейчас 21:00–24:00 отключение, а на завтра ещё нет графика — свет включат в 24:00
            return 1440
        }
        return null
    }

    private fun formatClockMinute(minOfDay: Int): String {
        val h = (minOfDay / 60).coerceIn(0, 24)
        val m = (minOfDay % 60).coerceIn(0, 59)
        return String.format(Locale.US, "%02d:%02d", h, m)
    }

    private fun formatDurationMinutesUk(totalMinutes: Int): String {
        val h = totalMinutes / 60
        val m = totalMinutes % 60
        return when {
            h > 0 && m > 0 -> "${h} год ${m} хв"
            h > 0 -> "${h} год"
            else -> "${m} хв"
        }
    }

    /**
     * Формирует актуальную сводку по графику света для голосового ассистента Gemini:
     */
    fun getSummaryForAi(context: Context): String {
        recomputeFromCachedJson(context)
        val snap = _state.value
        val todaySlots = if (!snap.todaySchedule.isAvailable) {
            "дані ще завантажуються"
        } else if (snap.todaySchedule.intervals.isEmpty()) {
            "без відключень весь день"
        } else {
            snap.todaySchedule.intervals.joinToString(", ") { "${it.formatTimeRange()} (${it.formatDurationUk()})" }
        }

        val tomorrowSlots = if (!snap.tomorrowSchedule.isAvailable) {
            "графік на завтра ще не опубліковано"
        } else if (snap.tomorrowSchedule.intervals.isEmpty()) {
            "без відключень"
        } else {
            snap.tomorrowSchedule.intervals.joinToString(", ") { "${it.formatTimeRange()} (${it.formatDurationUk()})" }
        }

        return "ДТЕК Київська область, обрана черга: ${snap.groupCode}. " +
            "Поточний статус: ${snap.headerTitle} (${snap.headerSubtitle}). " +
            "Відключення сьогодні: $todaySlots. " +
            "Відключення завтра: $tomorrowSlots. " +
            "Оновлено ДТЕК: ${snap.updateTimestamp}."
    }
}
