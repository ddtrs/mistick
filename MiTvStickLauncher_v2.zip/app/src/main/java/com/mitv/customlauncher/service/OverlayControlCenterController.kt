package com.mitv.customlauncher.service

import android.app.ActivityManager
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.ContextThemeWrapper
import android.view.FocusFinder
import android.view.Gravity
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.core.graphics.ColorUtils
import com.mitv.customlauncher.R
import com.mitv.customlauncher.data.LauncherConfig
import com.mitv.customlauncher.data.SmartLightTarget
import com.mitv.customlauncher.data.TuyaSmartHomeController
import com.mitv.customlauncher.databinding.OverlayControlCenterBinding
import com.mitv.customlauncher.ui.LauncherActivity
import com.mitv.customlauncher.data.NativeCore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.Calendar

class OverlayControlCenterController(
    private val service: KeyMapperAccessibilityService
) {
    private enum class CapsuleState { NEUTRAL, ACCENT, DANGER }
    private enum class NightModeSetting { AUTO, ALWAYS_DAY, ALWAYS_NIGHT }

    private val themedContext = ContextThemeWrapper(service, R.style.Theme_MiTvLauncher)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val uiScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var binding: OverlayControlCenterBinding? = null
    private var isWindowAdded: Boolean = false

    @Volatile
    var isVisible: Boolean = false
        private set

    private var isSmartHomeTabActive: Boolean = false
    private var isSmartHomeDetailOpen: Boolean = false
    private var isSwitchingCcTab: Boolean = false
    private var smartHomeLongPressConsumed: Boolean = false

    private val capsuleShapeCache = HashMap<String, Drawable.ConstantState>()

    private val okHoldHandler = Handler(Looper.getMainLooper())
    private var okHoldTriggered: Boolean = false
    private val okHoldRunnable = Runnable {
        val b = binding ?: return@Runnable
        okHoldTriggered = true
        if (isVisible && isSmartHomeTabActive && !isSmartHomeDetailOpen) {
            val fid = b.root.findFocus()?.id
            if (fid == R.id.tileLedPower ||
                fid == R.id.tileLedSyncTheme ||
                fid == R.id.tileHomeAmbilineQuick ||
                fid == R.id.tileHomeStudioOpen
            ) {
                smartHomeLongPressConsumed = true
                NavSoundPlayer.playClick(service)
                TuyaSmartHomeController.activeStudioTarget = when (fid) {
                    R.id.tileLedPower -> SmartLightTarget.STRIP
                    R.id.tileLedSyncTheme -> SmartLightTarget.BULB
                    else -> SmartLightTarget.BOTH
                }
                openSmartHomeDeviceDetail()
            }
        }
    }

    private fun getAccentColor(): Int {
        val prefs = service.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val hex = prefs.getString("pref_accent_color", "#00F0FF") ?: "#00F0FF"
        return try {
            Color.parseColor(hex)
        } catch (_: Exception) {
            Color.parseColor("#00F0FF")
        }
    }

    private fun dpPx(dpVal: Float): Int =
        (dpVal * service.resources.displayMetrics.density + 0.5f).toInt()

    fun toggle() {
        mainHandler.post {
            if (isVisible) {
                hide(immediate = false)
            } else {
                show()
            }
        }
    }

    fun show() {
        mainHandler.post {
            ensureWindowCreated()
            val b = binding ?: return@post
            isVisible = true
            isSmartHomeDetailOpen = false
            refreshControlCenterToggles()

            b.root.visibility = View.VISIBLE
            b.vCcOverlayDimBackdrop.animate().cancel()
            b.vCcOverlayDimBackdrop.alpha = 0f
            b.vCcOverlayDimBackdrop.visibility = View.VISIBLE
            b.vCcOverlayDimBackdrop.animate().alpha(1f).setDuration(170L).start()

            val panel = b.controlCenterPanel
            panel.background = null
            panel.animate().cancel()
            panel.alpha = 0f
            panel.translationY = 20f * service.resources.displayMetrics.density
            panel.visibility = View.VISIBLE
            panel.setLayerType(View.LAYER_TYPE_HARDWARE, null)
            panel.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(170L)
                .setInterpolator(NativeCore.SpringInterpolator(0.78f, 11.5f))
                .withEndAction {
                    panel.setLayerType(View.LAYER_TYPE_NONE, null)
                }
                .start()

            switchControlCenterTab(
                showSmartHome = isSmartHomeTabActive,
                openDetailDirectly = false,
                requestFocusInside = true
            )
        }
    }

    fun hide(immediate: Boolean = false) {
        mainHandler.post {
            okHoldHandler.removeCallbacks(okHoldRunnable)
            val b = binding ?: return@post
            if (!isVisible && b.root.visibility != View.VISIBLE) return@post
            isVisible = false
            isSmartHomeDetailOpen = false
            val panel = b.controlCenterPanel
            panel.animate().cancel()
            panel.setLayerType(View.LAYER_TYPE_NONE, null)
            b.vCcOverlayDimBackdrop.animate().cancel()

            if (immediate) {
                panel.visibility = View.GONE
                b.root.visibility = View.GONE
            } else {
                b.vCcOverlayDimBackdrop.animate().alpha(0f).setDuration(140L).start()
                panel.animate()
                    .alpha(0f)
                    .translationY(14f * service.resources.displayMetrics.density)
                    .setDuration(140L)
                    .withEndAction {
                        panel.visibility = View.GONE
                        b.root.visibility = View.GONE
                    }
                    .start()
            }
        }
    }

    fun destroy() {
        mainHandler.post {
            okHoldHandler.removeCallbacks(okHoldRunnable)
            if (TuyaSmartHomeController.onStateUpdatedOverlayCallback != null) {
                TuyaSmartHomeController.onStateUpdatedOverlayCallback = null
            }
            val b = binding
            if (b != null && isWindowAdded) {
                try {
                    val wm = service.getSystemService(Context.WINDOW_SERVICE) as? WindowManager
                    wm?.removeViewImmediate(b.root)
                } catch (_: Exception) {
                }
            }
            binding = null
            isWindowAdded = false
            isVisible = false
        }
    }

    private fun ensureWindowCreated() {
        if (binding != null && isWindowAdded) return
        val wm = service.getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
        val b = OverlayControlCenterBinding.inflate(LayoutInflater.from(themedContext))
        binding = b

        setupControlCenterPanel(b)

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.START or Gravity.BOTTOM
        }

        try {
            b.root.visibility = View.GONE
            wm.addView(b.root, lp)
            isWindowAdded = true
        } catch (_: Exception) {
        }
    }

    fun handleKeyEvent(event: KeyEvent): Boolean {
        val b = binding ?: return false
        if (!isVisible) return false
        val keyCode = event.keyCode

        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                if (isSmartHomeTabActive && isSmartHomeDetailOpen) {
                    closeSmartHomeDeviceDetail()
                } else {
                    hide(immediate = false)
                }
            }
            return true
        }

        if (keyCode == KeyEvent.KEYCODE_HOME) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                hide(immediate = true)
            }
            return false
        }

        val currentFocus = b.root.findFocus()

        if (event.action == KeyEvent.ACTION_DOWN) {
            if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT && currentFocus?.id == R.id.tabCcControls) {
                switchControlCenterTab(showSmartHome = true, openDetailDirectly = false, requestFocusInside = false)
                b.tabCcSmartHome.requestFocus()
                return true
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT && currentFocus?.id == R.id.tabCcSmartHome) {
                switchControlCenterTab(showSmartHome = false, openDetailDirectly = false, requestFocusInside = false)
                b.tabCcControls.requestFocus()
                return true
            }
            if (!isSmartHomeTabActive && keyCode == KeyEvent.KEYCODE_DPAD_DOWN &&
                (currentFocus?.id == R.id.tabCcControls || currentFocus?.id == R.id.tabCcSmartHome)
            ) {
                b.tileCcWifi.requestFocus()
                return true
            }
            if (isSmartHomeTabActive && !isSmartHomeDetailOpen) {
                when (keyCode) {
                    KeyEvent.KEYCODE_DPAD_RIGHT -> {
                        when (currentFocus?.id) {
                            R.id.tileLedPower -> { b.tileLedSyncTheme.requestFocus(); return true }
                            R.id.tileHomeAmbilineQuick -> { b.tileHomeStudioOpen.requestFocus(); return true }
                        }
                    }
                    KeyEvent.KEYCODE_DPAD_LEFT -> {
                        when (currentFocus?.id) {
                            R.id.tileLedSyncTheme -> { b.tileLedPower.requestFocus(); return true }
                            R.id.tileHomeStudioOpen -> { b.tileHomeAmbilineQuick.requestFocus(); return true }
                        }
                    }
                    KeyEvent.KEYCODE_DPAD_DOWN -> {
                        when (currentFocus?.id) {
                            R.id.tabCcControls, R.id.tabCcSmartHome -> { b.tileLedPower.requestFocus(); return true }
                            R.id.tileLedPower -> { b.tileHomeAmbilineQuick.requestFocus(); return true }
                            R.id.tileLedSyncTheme -> { b.tileHomeStudioOpen.requestFocus(); return true }
                        }
                    }
                    KeyEvent.KEYCODE_DPAD_UP -> {
                        when (currentFocus?.id) {
                            R.id.tileHomeAmbilineQuick -> { b.tileLedPower.requestFocus(); return true }
                            R.id.tileHomeStudioOpen -> { b.tileLedSyncTheme.requestFocus(); return true }
                            R.id.tileLedPower, R.id.tileLedSyncTheme -> { b.tabCcSmartHome.requestFocus(); return true }
                        }
                    }
                }
            } else if (isSmartHomeTabActive && isSmartHomeDetailOpen) {
                if (keyCode == KeyEvent.KEYCODE_DPAD_DOWN &&
                    (currentFocus?.id == R.id.tabCcControls || currentFocus?.id == R.id.tabCcSmartHome)
                ) {
                    if (b.llBulbModeSwitchRow.visibility == View.VISIBLE) {
                        val modeTarget = if (TuyaSmartHomeController.isStudioInWhiteMode(service)) {
                            b.btnBulbModeWhite
                        } else {
                            b.btnBulbModeColor
                        }
                        modeTarget.requestFocus()
                    } else {
                        b.barLedHueSpectrum.requestFocus()
                    }
                    return true
                }
                if (keyCode == KeyEvent.KEYCODE_DPAD_UP && currentFocus?.id == R.id.barLedHueSpectrum) {
                    if (b.llBulbModeSwitchRow.visibility == View.VISIBLE) {
                        val modeTarget = if (TuyaSmartHomeController.isStudioInWhiteMode(service)) {
                            b.btnBulbModeWhite
                        } else {
                            b.btnBulbModeColor
                        }
                        modeTarget.requestFocus()
                    } else {
                        b.tabCcSmartHome.requestFocus()
                    }
                    return true
                }
                if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
                    val dir = if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) 1 else -1
                    when (currentFocus?.id) {
                        R.id.btnBulbModeColor -> {
                            if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) {
                                NavSoundPlayer.playClick(service)
                                TuyaSmartHomeController.setStudioBulbWorkMode(service, whiteMode = true)
                                refreshSmartHomeUiState()
                                b.btnBulbModeWhite.requestFocus()
                            }
                            return true
                        }
                        R.id.btnBulbModeWhite -> {
                            if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT) {
                                NavSoundPlayer.playClick(service)
                                TuyaSmartHomeController.setStudioBulbWorkMode(service, whiteMode = false)
                                refreshSmartHomeUiState()
                                b.btnBulbModeColor.requestFocus()
                            }
                            return true
                        }
                        R.id.barLedHueSpectrum -> {
                            NavSoundPlayer.playClick(service)
                            TuyaSmartHomeController.stepHueByDelta(service, dir * 10)
                            return true
                        }
                        R.id.btnLedBrightness -> {
                            NavSoundPlayer.playClick(service)
                            TuyaSmartHomeController.stepBrightnessByDelta(service, dir * 10)
                            return true
                        }
                        R.id.btnLedSaturation -> {
                            NavSoundPlayer.playClick(service)
                            TuyaSmartHomeController.stepSaturationByDelta(service, dir * 15)
                            return true
                        }
                    }
                }
            }
        }

        val isCenter = keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
            keyCode == KeyEvent.KEYCODE_ENTER ||
            keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER

        if (!isCenter && event.action == KeyEvent.ACTION_DOWN) {
            okHoldHandler.removeCallbacks(okHoldRunnable)
        }

        val isSmartHomeHoldTarget = isSmartHomeTabActive &&
            !isSmartHomeDetailOpen &&
            (currentFocus?.id == R.id.tileLedPower ||
                currentFocus?.id == R.id.tileLedSyncTheme ||
                currentFocus?.id == R.id.tileHomeAmbilineQuick ||
                currentFocus?.id == R.id.tileHomeStudioOpen)

        if (isCenter && isSmartHomeHoldTarget) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                if (event.repeatCount == 0) {
                    okHoldTriggered = false
                    smartHomeLongPressConsumed = false
                    okHoldHandler.removeCallbacks(okHoldRunnable)
                    okHoldHandler.postDelayed(okHoldRunnable, 420L)
                } else if (!okHoldTriggered && (event.isLongPress || event.repeatCount >= 2)) {
                    okHoldHandler.removeCallbacks(okHoldRunnable)
                    okHoldRunnable.run()
                    return true
                } else if (okHoldTriggered) {
                    return true
                }
            } else if (event.action == KeyEvent.ACTION_UP) {
                okHoldHandler.removeCallbacks(okHoldRunnable)
                if (okHoldTriggered || smartHomeLongPressConsumed) {
                    okHoldTriggered = false
                    smartHomeLongPressConsumed = false
                    return true
                }
            }
        }

        if (b.root.dispatchKeyEvent(event)) {
            return true
        }

        if (event.action == KeyEvent.ACTION_DOWN) {
            val direction = when (keyCode) {
                KeyEvent.KEYCODE_DPAD_LEFT -> View.FOCUS_LEFT
                KeyEvent.KEYCODE_DPAD_RIGHT -> View.FOCUS_RIGHT
                KeyEvent.KEYCODE_DPAD_UP -> View.FOCUS_UP
                KeyEvent.KEYCODE_DPAD_DOWN -> View.FOCUS_DOWN
                else -> 0
            }
            if (direction != 0) {
                val focused = b.root.findFocus()
                val next = focused?.focusSearch(direction)
                    ?: FocusFinder.getInstance().findNextFocus(b.root, focused, direction)
                if (next != null && next != focused) {
                    next.requestFocus(direction)
                    return true
                }
            }
        }
        return true
    }

    private fun setupControlCenterPanel(b: OverlayControlCenterBinding) {
        b.vCcOverlayDimBackdrop.setOnClickListener {
            hide(immediate = false)
        }

        b.tileCcWifi.setOnClickListener {
            toggleWifiDirectly()
        }
        b.tileCcWifi.setOnLongClickListener {
            hide(immediate = true)
            openSettingsIntent(Settings.ACTION_WIFI_SETTINGS)
            true
        }

        b.tileCcBluetooth.setOnClickListener {
            hide(immediate = true)
            openSettingsIntent(Settings.ACTION_BLUETOOTH_SETTINGS)
        }
        b.tileCcBluetooth.setOnLongClickListener {
            toggleBluetoothDirectly()
            true
        }

        b.tileCcSound.setOnClickListener {
            try {
                val am = service.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    AudioManager.ADJUST_TOGGLE_MUTE,
                    0
                )
            } catch (_: Exception) {
            }
            refreshSoundTileState()
        }

        b.tileCcBoost.setOnLongClickListener {
            hide(immediate = true)
            launchHomeWithExtra("EXTRA_OPEN_RECENT_APPS")
            true
        }
        b.tileCcBoost.setOnClickListener {
            silentCleanBackgroundProcesses()
            refreshRamTileState(cleanedBonusPct = 14)
            Toast.makeText(themedContext, R.string.toast_boost_done, Toast.LENGTH_SHORT).show()
        }

        b.tileCcNightQuick.setOnClickListener {
            val cur = getNightModeSetting()
            val nextSetting = when (cur) {
                NightModeSetting.AUTO -> NightModeSetting.ALWAYS_NIGHT
                NightModeSetting.ALWAYS_NIGHT -> NightModeSetting.ALWAYS_DAY
                NightModeSetting.ALWAYS_DAY -> NightModeSetting.AUTO
            }
            service.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
                .edit()
                .putString("pref_night_mode_setting", nextSetting.name)
                .apply()
            refreshControlCenterToggles()
        }

        b.tileCcLedQuick.setOnClickListener {
            TuyaSmartHomeController.togglePower(service)
            refreshControlCenterToggles()
        }
        b.tileCcLedQuick.setOnLongClickListener {
            switchControlCenterTab(showSmartHome = true, openDetailDirectly = true, requestFocusInside = true)
            true
        }

        b.btnCcQuickLedStudio.setOnClickListener {
            switchControlCenterTab(showSmartHome = true, openDetailDirectly = true, requestFocusInside = true)
        }

        val allCcInteractive = listOf(
            b.tileCcWifi,
            b.tileCcBluetooth,
            b.tileCcBoost,
            b.tileCcNightQuick,
            b.tileCcSound,
            b.tileCcLedQuick,
            b.btnCcQuickLedStudio,
            b.btnMenuBindKey,
            b.btnMenuAssignCurrent,
            b.btnMenuSystemSettings
        )
        for (v in allCcInteractive) {
            v.setOnFocusChangeListener { view, hasFocus ->
                val targetScale = if (hasFocus) 1.038f else 1.0f
                view.animate()
                    .scaleX(targetScale)
                    .scaleY(targetScale)
                    .setDuration(150L)
                    .setInterpolator(NativeCore.SpringInterpolator(0.78f, 11.5f))
                    .start()
                refreshControlCenterBottomIconsTint()
            }
        }

        b.btnMenuAssignCurrent.setOnClickListener {
            hide(immediate = true)
            launchHomeWithExtra("EXTRA_OPEN_LAUNCHER_SETTINGS")
        }

        b.btnMenuBindKey.setOnClickListener {
            hide(immediate = true)
            launchHomeWithExtra("EXTRA_OPEN_KEY_BIND")
        }

        b.btnMenuSystemSettings.setOnClickListener {
            hide(immediate = true)
            openSettingsIntent(Settings.ACTION_SETTINGS)
        }

        setupSmartHomeTabAndControls(b)
    }

    private fun setupSmartHomeTabAndControls(b: OverlayControlCenterBinding) {
        TuyaSmartHomeController.onStateUpdatedOverlayCallback = {
            if (isVisible) {
                refreshSmartHomeUiState()
            }
        }

        b.vLedRainbowStrip.background = createRainbowSpectrumDrawable()

        b.tabCcControls.setOnClickListener {
            switchControlCenterTab(showSmartHome = false, openDetailDirectly = false, requestFocusInside = true)
        }
        b.tabCcControls.setOnFocusChangeListener { _, _ ->
            if (!isSwitchingCcTab) {
                refreshControlCenterTabHeaderStyle()
            }
        }

        b.tabCcSmartHome.setOnClickListener {
            switchControlCenterTab(showSmartHome = true, openDetailDirectly = false, requestFocusInside = true)
        }
        b.tabCcSmartHome.setOnFocusChangeListener { _, _ ->
            if (!isSwitchingCcTab) {
                refreshControlCenterTabHeaderStyle()
            }
        }

        b.tileLedPower.isLongClickable = true
        b.tileLedPower.setOnClickListener {
            if (smartHomeLongPressConsumed) {
                smartHomeLongPressConsumed = false
                return@setOnClickListener
            }
            TuyaSmartHomeController.toggleStripPower(service)
            refreshSmartHomeUiState()
        }
        b.tileLedPower.setOnLongClickListener {
            smartHomeLongPressConsumed = true
            NavSoundPlayer.playClick(service)
            TuyaSmartHomeController.activeStudioTarget = SmartLightTarget.STRIP
            openSmartHomeDeviceDetail()
            true
        }

        b.tileLedSyncTheme.isLongClickable = true
        b.tileLedSyncTheme.setOnClickListener {
            if (smartHomeLongPressConsumed) {
                smartHomeLongPressConsumed = false
                return@setOnClickListener
            }
            TuyaSmartHomeController.toggleBulbPower(service)
            refreshSmartHomeUiState()
        }
        b.tileLedSyncTheme.setOnLongClickListener {
            smartHomeLongPressConsumed = true
            NavSoundPlayer.playClick(service)
            TuyaSmartHomeController.activeStudioTarget = SmartLightTarget.BULB
            openSmartHomeDeviceDetail()
            true
        }

        b.tileHomeAmbilineQuick.isLongClickable = true
        b.tileHomeAmbilineQuick.setOnClickListener {
            if (smartHomeLongPressConsumed) {
                smartHomeLongPressConsumed = false
                return@setOnClickListener
            }
            TuyaSmartHomeController.activateDynamicScene(service, "AMBILINE")
            refreshSmartHomeUiState()
        }
        b.tileHomeAmbilineQuick.setOnLongClickListener {
            smartHomeLongPressConsumed = true
            NavSoundPlayer.playClick(service)
            TuyaSmartHomeController.activeStudioTarget = SmartLightTarget.BOTH
            openSmartHomeDeviceDetail()
            true
        }

        b.tileHomeStudioOpen.isLongClickable = true
        b.tileHomeStudioOpen.setOnClickListener {
            if (smartHomeLongPressConsumed) {
                smartHomeLongPressConsumed = false
                return@setOnClickListener
            }
            TuyaSmartHomeController.toggleDevicesLinked(service)
            refreshSmartHomeUiState()
        }
        b.tileHomeStudioOpen.setOnLongClickListener {
            smartHomeLongPressConsumed = true
            NavSoundPlayer.playClick(service)
            TuyaSmartHomeController.activeStudioTarget = SmartLightTarget.BOTH
            openSmartHomeDeviceDetail()
            true
        }

        b.btnBulbModeColor.setOnClickListener {
            TuyaSmartHomeController.setStudioBulbWorkMode(service, whiteMode = false)
            refreshSmartHomeUiState()
        }
        b.btnBulbModeWhite.setOnClickListener {
            TuyaSmartHomeController.setStudioBulbWorkMode(service, whiteMode = true)
            refreshSmartHomeUiState()
        }

        for (shCapsule in listOf(
            b.tileLedPower,
            b.tileLedSyncTheme,
            b.tileHomeAmbilineQuick,
            b.tileHomeStudioOpen,
            b.btnBulbModeColor,
            b.btnBulbModeWhite,
            b.barLedHueSpectrum,
            b.btnLedBrightness,
            b.btnLedSaturation
        )) {
            shCapsule.setOnFocusChangeListener { v, hasFocus ->
                val s = if (hasFocus) 1.036f else 1.0f
                v.animate()
                    .scaleX(s)
                    .scaleY(s)
                    .setDuration(150L)
                    .setInterpolator(NativeCore.SpringInterpolator(0.78f, 11.5f))
                    .start()
            }
        }

        b.barLedHueSpectrum.setOnClickListener {
            TuyaSmartHomeController.stepHueByDelta(service, 24, immediate = true)
            refreshSmartHomeUiState()
        }

        b.btnLedBrightness.setOnClickListener {
            TuyaSmartHomeController.cycleBrightnessPreset(service)
            refreshSmartHomeUiState()
        }

        b.btnLedSaturation.setOnClickListener {
            TuyaSmartHomeController.cycleSaturationPreset(service)
            refreshSmartHomeUiState()
        }

        val swatchButtons = listOf(
            b.btnLedSwatch1,
            b.btnLedSwatch2,
            b.btnLedSwatch3,
            b.btnLedSwatch4,
            b.btnLedSwatch5,
            b.btnLedSwatch6,
            b.btnLedSwatch7,
            b.btnLedSwatch8,
            b.btnLedSwatch9,
            b.btnLedSwatch10,
            b.btnLedSwatch11,
            b.btnLedSwatch12
        )

        val presets = TuyaSmartHomeController.CURATED_SWATCHES
        val accent = getAccentColor()
        for (i in swatchButtons.indices) {
            val btn = swatchButtons[i]
            val preset = presets[i]
            btn.text = preset.name
            btn.background = createColorSwatchDrawable(preset.hexColor, accent)
            btn.setOnClickListener {
                TuyaSmartHomeController.applySwatchPreset(service, preset)
                refreshSmartHomeUiState()
            }
        }

        b.btnLedSceneRainbow.setOnClickListener {
            TuyaSmartHomeController.activateDynamicScene(service, "RAINBOW")
            refreshSmartHomeUiState()
        }
        b.btnLedSceneBreathe.setOnClickListener {
            TuyaSmartHomeController.activateDynamicScene(service, "BREATHE")
            refreshSmartHomeUiState()
        }
        b.btnLedSceneParty.setOnClickListener {
            TuyaSmartHomeController.activateDynamicScene(service, "PARTY")
            refreshSmartHomeUiState()
        }
        b.btnLedSceneNight.setOnClickListener {
            TuyaSmartHomeController.activateDynamicScene(service, "NIGHT")
            refreshSmartHomeUiState()
        }
        b.btnLedSceneAmbiline.setOnClickListener {
            TuyaSmartHomeController.activateDynamicScene(service, "AMBILINE")
            refreshSmartHomeUiState()
        }
    }

    private fun openSmartHomeDeviceDetail() {
        val b = binding ?: return
        isSwitchingCcTab = true
        try {
            isSmartHomeTabActive = true
            isSmartHomeDetailOpen = true
            b.controlCenterPanel.background = null
            b.llCcSystemPage.visibility = View.GONE
            b.llCcSmartHomePage.visibility = View.VISIBLE
            b.llSmartHomeDevicesView.visibility = View.GONE
            b.llSmartHomeDetailView.alpha = 0f
            b.llSmartHomeDetailView.scaleX = 0.96f
            b.llSmartHomeDetailView.scaleY = 0.96f
            b.llSmartHomeDetailView.visibility = View.VISIBLE
            b.llSmartHomeDetailView.animate()
                .alpha(1f)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(160L)
                .setInterpolator(NativeCore.SpringInterpolator(0.78f, 11.5f))
                .start()
            refreshControlCenterToggles()
            b.barLedHueSpectrum.requestFocus()
            b.barLedHueSpectrum.post { b.barLedHueSpectrum.requestFocus() }
        } finally {
            isSwitchingCcTab = false
        }
    }

    private fun closeSmartHomeDeviceDetail() {
        val b = binding ?: return
        isSwitchingCcTab = true
        try {
            isSmartHomeTabActive = true
            isSmartHomeDetailOpen = false
            b.controlCenterPanel.background = null
            b.llCcSystemPage.visibility = View.GONE
            b.llCcSmartHomePage.visibility = View.VISIBLE
            b.llSmartHomeDetailView.visibility = View.GONE
            b.llSmartHomeDevicesView.alpha = 0f
            b.llSmartHomeDevicesView.visibility = View.VISIBLE
            b.llSmartHomeDevicesView.animate()
                .alpha(1f)
                .setDuration(140L)
                .start()
            refreshControlCenterToggles()
            val returnTile = when (TuyaSmartHomeController.activeStudioTarget) {
                SmartLightTarget.BULB -> b.tileLedSyncTheme
                SmartLightTarget.BOTH -> b.tileHomeStudioOpen
                SmartLightTarget.STRIP -> b.tileLedPower
            }
            returnTile.requestFocus()
            returnTile.post { returnTile.requestFocus() }
        } finally {
            isSwitchingCcTab = false
        }
    }

    private fun switchControlCenterTab(
        showSmartHome: Boolean,
        openDetailDirectly: Boolean = false,
        requestFocusInside: Boolean = false
    ) {
        val b = binding ?: return
        if (isSwitchingCcTab) return
        isSwitchingCcTab = true
        try {
            isSmartHomeTabActive = showSmartHome
            isSmartHomeDetailOpen = showSmartHome && openDetailDirectly
            b.controlCenterPanel.background = null
            if (showSmartHome) {
                b.llCcSystemPage.visibility = View.GONE
                b.llCcSmartHomePage.visibility = View.VISIBLE
                b.llSmartHomeDevicesView.visibility = if (isSmartHomeDetailOpen) View.GONE else View.VISIBLE
                b.llSmartHomeDetailView.visibility = if (isSmartHomeDetailOpen) View.VISIBLE else View.GONE
            } else {
                b.llCcSmartHomePage.visibility = View.GONE
                b.llSmartHomeDevicesView.visibility = View.GONE
                b.llSmartHomeDetailView.visibility = View.GONE
                b.llCcSystemPage.visibility = View.VISIBLE
            }
            refreshControlCenterToggles()
            if (showSmartHome) {
                TuyaSmartHomeController.refreshStatusFromCloudAsync(service)
                if (requestFocusInside) {
                    val target = if (isSmartHomeDetailOpen) b.barLedHueSpectrum else b.tileLedPower
                    target.requestFocus()
                    target.post { target.requestFocus() }
                }
            } else if (requestFocusInside) {
                b.tileCcWifi.requestFocus()
                b.tileCcWifi.post { b.tileCcWifi.requestFocus() }
            }
        } finally {
            isSwitchingCcTab = false
        }
    }

    fun refreshControlCenterToggles() {
        val b = binding ?: return
        val accent = getAccentColor()
        val wm = service.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        val wifiEnabled = try {
            wm?.isWifiEnabled == true
        } catch (_: Exception) {
            true
        }
        b.tileCcWifi.background = createToggleDrawable(accent, isActive = wifiEnabled)
        b.ivCcWifi.setColorFilter(
            if (wifiEnabled) accent else service.getColor(R.color.text_secondary),
            PorterDuff.Mode.SRC_IN
        )
        b.tvCcWifiState.text = if (wifiEnabled) "Подключено" else "Выкл."
        b.tvCcWifiState.setTextColor(if (wifiEnabled) accent else service.getColor(R.color.text_secondary))

        val btEnabled = try {
            @Suppress("DEPRECATION", "MissingPermission")
            BluetoothAdapter.getDefaultAdapter()?.isEnabled == true
        } catch (_: Exception) {
            true
        }
        b.tileCcBluetooth.background = createToggleDrawable(accent, isActive = btEnabled)
        b.ivCcBt.setColorFilter(
            if (btEnabled) accent else service.getColor(R.color.text_secondary),
            PorterDuff.Mode.SRC_IN
        )
        b.tvCcBtState.text = if (btEnabled) "Вкл." else "Выкл."
        b.tvCcBtState.setTextColor(if (btEnabled) accent else service.getColor(R.color.text_secondary))

        refreshSoundTileState()
        refreshRamTileState(cleanedBonusPct = 0)

        val nightSetting = getNightModeSetting()
        val nightActive = isNightModeActive(nightSetting)
        b.tileCcNightQuick.background = createToggleDrawable(accent, isActive = nightActive)
        b.ivCcNightQuick.setColorFilter(
            if (nightActive) accent else service.getColor(R.color.text_primary),
            PorterDuff.Mode.SRC_IN
        )
        b.tvCcNightQuickState.text = when (nightSetting) {
            NightModeSetting.AUTO -> if (nightActive) "Авто · Активен" else "Авто (23:00)"
            NightModeSetting.ALWAYS_NIGHT -> "Вкл."
            NightModeSetting.ALWAYS_DAY -> "Выкл."
        }
        b.tvCcNightQuickState.setTextColor(if (nightActive) accent else service.getColor(R.color.text_secondary))

        val ledOn = TuyaSmartHomeController.isLedOn(service)
        val ledMode = TuyaSmartHomeController.getCurrentModeLabel(service).removePrefix("Режим: ")
        b.tileCcLedQuick.background = createToggleDrawable(accent, isActive = ledOn)
        b.ivCcLedQuick.setColorFilter(
            if (ledOn) accent else service.getColor(R.color.text_primary),
            PorterDuff.Mode.SRC_IN
        )
        b.tvCcLedQuickState.text = if (ledOn) "ВКЛ · $ledMode" else "Выкл."
        b.tvCcLedQuickState.setTextColor(if (ledOn) accent else service.getColor(R.color.text_secondary))

        b.btnCcQuickLedStudio.background = createSquircleIconDrawable(accent)
        b.btnMenuBindKey.background = createSquircleIconDrawable(accent)
        b.btnMenuAssignCurrent.background = createSquircleIconDrawable(accent)
        b.btnMenuSystemSettings.background = createSquircleIconDrawable(accent)
        refreshControlCenterBottomIconsTint()

        refreshControlCenterTabHeaderStyle()
        refreshSmartHomeUiState()
    }

    private fun refreshSoundTileState() {
        val b = binding ?: return
        val accent = getAccentColor()
        val am = service.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val isMuted = try {
            am.isStreamMute(AudioManager.STREAM_MUSIC)
        } catch (_: Exception) {
            false
        }
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val curVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val pct = ((curVol * 100f) / maxVol).toInt().coerceIn(0, 100)
        val soundActive = !isMuted && pct > 0
        b.tileCcSound.background = createToggleDrawable(accent, isActive = soundActive)
        b.ivCcSound.setColorFilter(
            if (soundActive) accent else service.getColor(R.color.text_secondary),
            PorterDuff.Mode.SRC_IN
        )
        b.tvCcSoundState.text = if (isMuted || pct == 0) "Без звука" else "Динамики ТВ · $pct%"
        b.tvCcSoundState.setTextColor(if (soundActive) accent else service.getColor(R.color.text_secondary))
    }

    private fun refreshRamTileState(cleanedBonusPct: Int = 0) {
        val b = binding ?: return
        val accent = getAccentColor()
        val usedPct = try {
            val am = service.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            am?.getMemoryInfo(memInfo)
            if (memInfo.totalMem > 0L) {
                val raw = (((memInfo.totalMem - memInfo.availMem) * 100L) / memInfo.totalMem).toInt()
                (raw - cleanedBonusPct).coerceIn(22, 95)
            } else {
                (58 - cleanedBonusPct).coerceAtLeast(25)
            }
        } catch (_: Exception) {
            (58 - cleanedBonusPct).coerceAtLeast(25)
        }

        b.tileCcBoost.background = createToggleDrawable(accent, isActive = cleanedBonusPct > 0)
        b.ivCcBoost.setColorFilter(
            if (cleanedBonusPct > 0) accent else service.getColor(R.color.text_primary),
            PorterDuff.Mode.SRC_IN
        )
        b.tvCcBoostState.text = if (cleanedBonusPct > 0) "$usedPct% · Очищено" else "$usedPct% занято"
        b.tvCcBoostState.setTextColor(if (cleanedBonusPct > 0) accent else service.getColor(R.color.text_secondary))

        b.flCcRamTrack.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(99f).toFloat()
            setColor(Color.parseColor("#38FFFFFF"))
        }
        b.vCcRamFill.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(99f).toFloat()
            setColor(if (cleanedBonusPct > 0) accent else Color.WHITE)
        }
        b.flCcRamTrack.post {
            val totalW = b.flCcRamTrack.width
            if (totalW > 0) {
                val lp = b.vCcRamFill.layoutParams
                lp.width = ((totalW * usedPct) / 100).coerceAtLeast(dpPx(6f))
                b.vCcRamFill.layoutParams = lp
            }
        }
    }

    private fun refreshControlCenterBottomIconsTint() {
        val b = binding ?: return
        val accent = getAccentColor()
        val white = service.getColor(R.color.text_primary)
        b.ivCcQuickLedStudio.setColorFilter(if (b.btnCcQuickLedStudio.hasFocus()) accent else white, PorterDuff.Mode.SRC_IN)
        b.ivCcQuickRemote.setColorFilter(if (b.btnMenuBindKey.hasFocus()) accent else white, PorterDuff.Mode.SRC_IN)
        b.ivCcQuickLauncherSettings.setColorFilter(if (b.btnMenuAssignCurrent.hasFocus()) accent else white, PorterDuff.Mode.SRC_IN)
        b.ivCcQuickSysSettings.setColorFilter(if (b.btnMenuSystemSettings.hasFocus()) accent else white, PorterDuff.Mode.SRC_IN)
    }

    private fun refreshControlCenterTabHeaderStyle() {
        val b = binding ?: return
        val accent = getAccentColor()
        val controlsActive = !isSmartHomeTabActive
        val homeActive = isSmartHomeTabActive

        b.tabCcControls.background = createToggleDrawable(accent, isActive = controlsActive)
        b.ivTabCcControls.setColorFilter(
            if (controlsActive) accent else service.getColor(R.color.text_secondary),
            PorterDuff.Mode.SRC_IN
        )
        b.tvTabCcControls.setTextColor(
            if (controlsActive) service.getColor(R.color.text_primary) else service.getColor(R.color.text_secondary)
        )

        b.tabCcSmartHome.background = createToggleDrawable(accent, isActive = homeActive)
        b.ivTabCcSmartHome.setColorFilter(
            if (homeActive) accent else service.getColor(R.color.text_secondary),
            PorterDuff.Mode.SRC_IN
        )
        b.tvTabCcSmartHome.setTextColor(
            if (homeActive) service.getColor(R.color.text_primary) else service.getColor(R.color.text_secondary)
        )
    }

    private fun refreshSmartHomeUiState() {
        val b = binding ?: return
        val accent = getAccentColor()

        val stripOn = TuyaSmartHomeController.isLedOn(service)
        val stripColor = TuyaSmartHomeController.getStripPreviewColorInt(service)
        val stripMode = TuyaSmartHomeController.getStripModeLabel(service).removePrefix("Режим: ")
        b.tileLedPower.background = createToggleDrawable(stripColor, isActive = stripOn)
        b.ivLedPower.setColorFilter(
            if (stripOn) stripColor else service.getColor(R.color.text_secondary),
            PorterDuff.Mode.SRC_IN
        )
        b.tvLedPowerState.text = if (stripOn) "ВКЛ · $stripMode" else service.getString(R.string.cc_state_off)
        b.tvLedPowerState.setTextColor(
            if (stripOn) stripColor else service.getColor(R.color.text_secondary)
        )

        val bulbOn = TuyaSmartHomeController.isBulbOn(service)
        val bulbColor = TuyaSmartHomeController.getBulbPreviewColorInt(service)
        val bulbMode = TuyaSmartHomeController.getBulbModeLabel(service).removePrefix("Режим: ")
        b.tileLedSyncTheme.background = createToggleDrawable(bulbColor, isActive = bulbOn)
        b.ivLedSyncTheme.setColorFilter(
            if (bulbOn) bulbColor else service.getColor(R.color.text_secondary),
            PorterDuff.Mode.SRC_IN
        )
        b.tvLedSyncState.text = if (bulbOn) "ВКЛ · $bulbMode" else service.getString(R.string.cc_state_off)
        b.tvLedSyncState.setTextColor(
            if (bulbOn) bulbColor else service.getColor(R.color.text_secondary)
        )

        val ambilineActive = (stripOn && stripMode.contains("Амбилайн", ignoreCase = true)) ||
            (bulbOn && bulbMode.contains("Амбилайн", ignoreCase = true))
        b.tileHomeAmbilineQuick.background = createToggleDrawable(stripColor, isActive = ambilineActive)
        b.ivHomeAmbilineQuick.setColorFilter(
            if (ambilineActive) stripColor else service.getColor(R.color.text_primary),
            PorterDuff.Mode.SRC_IN
        )
        b.tvHomeAmbilineState.text = if (ambilineActive) "АКТИВЕН · Обложка" else "Под тон обложки"
        b.tvHomeAmbilineState.setTextColor(
            if (ambilineActive) stripColor else service.getColor(R.color.text_secondary)
        )

        val linkedOn = TuyaSmartHomeController.isDevicesLinked(service)
        b.tileHomeStudioOpen.background = createToggleDrawable(accent, isActive = linkedOn)
        b.ivHomeStudioOpen.setColorFilter(
            if (linkedOn) accent else service.getColor(R.color.text_primary),
            PorterDuff.Mode.SRC_IN
        )
        b.tvHomeStudioSub.text = if (linkedOn) "Лента + Лампа · ВКЛ" else "Раздельно · Выкл."
        b.tvHomeStudioSub.setTextColor(
            if (linkedOn) accent else service.getColor(R.color.text_secondary)
        )

        val showBulbModes = TuyaSmartHomeController.isStudioShowingBulb(service)
        val whiteModeActive = TuyaSmartHomeController.isStudioInWhiteMode(service)
        b.llBulbModeSwitchRow.visibility = if (showBulbModes) View.VISIBLE else View.GONE

        val colorTitle = if (TuyaSmartHomeController.isDevicesLinked(service)) "Color · Лента + Лампа" else "Color · Цветной (RGB)"
        val whiteTitle = if (TuyaSmartHomeController.isDevicesLinked(service)) "White · Тёплый/Дневной" else "White · Белый свет"
        b.btnBulbModeColor.text = colorTitle
        b.btnBulbModeWhite.text = whiteTitle

        b.btnBulbModeColor.background = createSceneSelectorDrawable(accent, isSelected = !whiteModeActive)
        b.btnBulbModeColor.setTextColor(if (!whiteModeActive) accent else service.getColor(R.color.text_primary))
        b.btnBulbModeWhite.background = createSceneSelectorDrawable(accent, isSelected = whiteModeActive)
        b.btnBulbModeWhite.setTextColor(if (whiteModeActive) accent else service.getColor(R.color.text_primary))

        val hue = TuyaSmartHomeController.getHue(service)
        val sat = TuyaSmartHomeController.getSaturationPct(service)
        val bright = TuyaSmartHomeController.getBrightnessPct(service)
        val modeLabel = TuyaSmartHomeController.getCurrentModeLabel(service)
        val previewColor = TuyaSmartHomeController.getCurrentPreviewColorInt(service)
        val targetDeviceOn = if (TuyaSmartHomeController.activeStudioTarget == SmartLightTarget.BULB) bulbOn else stripOn
        val activeSwatchIdx = if (targetDeviceOn) TuyaSmartHomeController.findActiveSwatchIndex(service) else -1

        b.barLedHueSpectrum.background = createToggleDrawable(previewColor, isActive = false)
        b.btnLedBrightness.background = createToggleDrawable(previewColor, isActive = false)
        b.btnLedSaturation.background = createToggleDrawable(previewColor, isActive = false)

        b.vLedHuePreviewDot.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(previewColor)
            setStroke(dpPx(1.5f), Color.WHITE)
        }

        if (whiteModeActive) {
            val tempPct = TuyaSmartHomeController.getBulbTempPct(service)
            val tempTitle = TuyaSmartHomeController.describeWhiteTempLabel(tempPct)
            b.vLedRainbowStrip.background = createWhiteCctSpectrumDrawable()
            b.tvLedHueValue.text = "Температура: ${tempPct}% · $tempTitle"
            b.tvLedBrightValue.text = "Яркость: ${bright}%"
            b.tvLedSatValue.text = "Режим: $tempTitle"
        } else {
            val activeTitle = if (activeSwatchIdx in TuyaSmartHomeController.CURATED_SWATCHES.indices) {
                TuyaSmartHomeController.CURATED_SWATCHES[activeSwatchIdx].name
            } else {
                TuyaSmartHomeController.describeHueName(hue)
            }
            b.vLedRainbowStrip.background = createRainbowSpectrumDrawable()
            b.tvLedHueValue.text = "Спектр: ${hue}° · $activeTitle"
            b.tvLedBrightValue.text = "Яркость: ${bright}%"
            b.tvLedSatValue.text = "Насыщенность: ${sat}%"
        }
        b.ivLedBrightIcon.setColorFilter(previewColor, PorterDuff.Mode.SRC_IN)
        b.ivLedSatIcon.setColorFilter(previewColor, PorterDuff.Mode.SRC_IN)

        val swatchButtons = listOf(
            b.btnLedSwatch1,
            b.btnLedSwatch2,
            b.btnLedSwatch3,
            b.btnLedSwatch4,
            b.btnLedSwatch5,
            b.btnLedSwatch6,
            b.btnLedSwatch7,
            b.btnLedSwatch8,
            b.btnLedSwatch9,
            b.btnLedSwatch10,
            b.btnLedSwatch11,
            b.btnLedSwatch12
        )
        val presets = TuyaSmartHomeController.CURATED_SWATCHES
        for (i in swatchButtons.indices) {
            val btn = swatchButtons[i]
            val preset = presets[i]
            val isSelected = (i == activeSwatchIdx)
            btn.background = createColorSwatchDrawable(preset.hexColor, accent, isSelected)
            btn.setTextColor(if (isSelected) Color.WHITE else Color.parseColor(preset.hexColor))
        }

        val scenePairs = listOf(
            b.btnLedSceneRainbow to "Радуга",
            b.btnLedSceneBreathe to "Дыхание",
            b.btnLedSceneParty to "Вечеринка",
            b.btnLedSceneNight to "Ночник",
            b.btnLedSceneAmbiline to "Амбилайн"
        )
        for ((sceneBtn, keyword) in scenePairs) {
            val sceneActive = targetDeviceOn && modeLabel.contains(keyword, ignoreCase = true)
            sceneBtn.background = createSceneSelectorDrawable(accent, isSelected = sceneActive)
            sceneBtn.setTextColor(if (sceneActive) accent else service.getColor(R.color.text_primary))
        }
    }

    private fun toggleWifiDirectly() {
        val wm = service.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        if (wm == null) {
            hide(immediate = true)
            openSettingsIntent(Settings.ACTION_WIFI_SETTINGS)
            return
        }
        val targetState = !wm.isWifiEnabled
        @Suppress("DEPRECATION")
        val changed = try {
            wm.setWifiEnabled(targetState)
        } catch (_: Exception) {
            false
        }
        if (!changed) {
            hide(immediate = true)
            openSettingsIntent(Settings.ACTION_WIFI_SETTINGS)
        } else {
            uiScope.launch {
                delay(350L)
                refreshControlCenterToggles()
            }
        }
    }

    private fun toggleBluetoothDirectly() {
        try {
            @Suppress("DEPRECATION")
            val adapter = BluetoothAdapter.getDefaultAdapter()
            if (adapter != null) {
                @Suppress("MissingPermission", "DEPRECATION")
                if (adapter.isEnabled) adapter.disable() else adapter.enable()
                uiScope.launch {
                    delay(400L)
                    refreshControlCenterToggles()
                }
            }
        } catch (_: Exception) {
            hide(immediate = true)
            openSettingsIntent(Settings.ACTION_BLUETOOTH_SETTINGS)
        }
    }

    private fun silentCleanBackgroundProcesses() {
        ioScope.launch {
            try {
                val am = service.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return@launch
                val activeMusicPkg = MediaStateBus.state.value.sourcePackage
                val ctrlPkg = MediaStateBus.activeController?.packageName.orEmpty()
                val pm = service.packageManager
                val apps = pm.getInstalledApplications(0)
                for (app in apps) {
                    val pkg = app.packageName
                    if (pkg != service.packageName &&
                        pkg != activeMusicPkg &&
                        pkg != ctrlPkg &&
                        !isProtectedMediaPackage(pkg)
                    ) {
                        am.killBackgroundProcesses(pkg)
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun isProtectedMediaPackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("spotify") ||
            p.contains("soundcloud") ||
            p.contains("mediashell") ||
            p.contains("chromecast") ||
            p.contains("music") ||
            p.contains("youtube") ||
            p.contains("kick") ||
            p.contains("twitch") ||
            p.contains("remote") ||
            p.contains("katniss") ||
            p.contains("bluetooth") ||
            p.contains("google.android.gms")
    }

    private fun openSettingsIntent(action: String) {
        val intent = Intent(action).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            service.startActivity(intent)
        } catch (_: Exception) {
            try {
                service.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: Exception) {
            }
        }
    }

    private fun launchHomeWithExtra(extraKey: String) {
        val intent = Intent(service, LauncherActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra(extraKey, true)
        }
        try {
            service.startActivity(intent)
        } catch (_: Exception) {
        }
    }

    private fun getNightModeSetting(): NightModeSetting {
        val prefs = service.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString("pref_night_mode_setting", "AUTO") ?: "AUTO"
        return try { NightModeSetting.valueOf(saved) } catch (_: Exception) { NightModeSetting.AUTO }
    }

    private fun isNightModeActive(setting: NightModeSetting): Boolean {
        return when (setting) {
            NightModeSetting.ALWAYS_DAY -> false
            NightModeSetting.ALWAYS_NIGHT -> true
            NightModeSetting.AUTO -> {
                val cal = Calendar.getInstance()
                if (cal.get(Calendar.YEAR) < 2024) false
                else {
                    val h = cal.get(Calendar.HOUR_OF_DAY)
                    h >= 23 || h < 6
                }
            }
        }
    }

    private fun createCapsuleShape(
        accent: Int,
        state: CapsuleState,
        radiusDp: Float,
        focused: Boolean
    ): GradientDrawable {
        val tint = if (state == CapsuleState.DANGER) Color.parseColor("#EF4444") else accent
        val key = "$tint|${state.ordinal}|$radiusDp|$focused|${service.resources.displayMetrics.density}"
        capsuleShapeCache[key]?.let { return it.newDrawable().mutate() as GradientDrawable }

        val active = state != CapsuleState.NEUTRAL
        val top = when {
            active && focused -> ColorUtils.blendARGB(Color.parseColor("#2D3446"), tint, 0.36f)
            active -> ColorUtils.blendARGB(Color.parseColor("#252A38"), tint, 0.24f)
            focused -> Color.parseColor("#F22B3040")
            else -> Color.parseColor("#E6222632")
        }
        val bottom = when {
            active && focused -> ColorUtils.blendARGB(Color.parseColor("#1E2330"), tint, 0.22f)
            active -> ColorUtils.blendARGB(Color.parseColor("#181C26"), tint, 0.14f)
            focused -> Color.parseColor("#F21C202B")
            else -> Color.parseColor("#E6161922")
        }
        val shape = GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(top, bottom)).apply {
            this.shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(radiusDp).toFloat()
            if (focused) {
                setStroke(dpPx(2f), tint)
            } else {
                setStroke(
                    dpPx(1f),
                    if (active) ColorUtils.setAlphaComponent(tint, 155) else Color.parseColor("#36FFFFFF")
                )
            }
        }
        capsuleShapeCache[key] = shape.constantState!!
        return shape.constantState!!.newDrawable().mutate() as GradientDrawable
    }

    private fun createCapsuleDrawable(
        accent: Int,
        state: CapsuleState,
        radiusDp: Float
    ): StateListDrawable {
        val focused = createCapsuleShape(accent, state, radiusDp, focused = true)
        val idle = createCapsuleShape(accent, state, radiusDp, focused = false)
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(android.R.attr.state_selected), focused)
            addState(intArrayOf(), idle)
        }
    }

    private fun createToggleDrawable(accent: Int, isActive: Boolean): StateListDrawable =
        createCapsuleDrawable(accent, if (isActive) CapsuleState.ACCENT else CapsuleState.NEUTRAL, 28f)

    private fun createSquircleIconDrawable(accent: Int): StateListDrawable {
        val focused = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(
                ColorUtils.blendARGB(Color.parseColor("#2C3242"), accent, 0.30f),
                ColorUtils.blendARGB(Color.parseColor("#1B1F2A"), accent, 0.16f)
            )
        ).apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(16f).toFloat()
            setStroke(dpPx(2f), accent)
        }
        val idle = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#E6222632"), Color.parseColor("#E6151820"))
        ).apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(16f).toFloat()
            setStroke(dpPx(1f), Color.parseColor("#33FFFFFF"))
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(android.R.attr.state_selected), focused)
            addState(intArrayOf(), idle)
        }
    }

    private fun createSceneSelectorDrawable(accent: Int, isSelected: Boolean = false): StateListDrawable {
        val topIdle = if (isSelected) ColorUtils.blendARGB(Color.parseColor("#252A38"), accent, 0.28f) else Color.parseColor("#E6222632")
        val botIdle = if (isSelected) ColorUtils.blendARGB(Color.parseColor("#181C26"), accent, 0.16f) else Color.parseColor("#E6161922")
        val focused = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(
                ColorUtils.blendARGB(Color.parseColor("#2D3446"), accent, 0.36f),
                ColorUtils.blendARGB(Color.parseColor("#1E2330"), accent, 0.22f)
            )
        ).apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(18f).toFloat()
            setStroke(dpPx(2f), accent)
        }
        val idle = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(topIdle, botIdle)
        ).apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(18f).toFloat()
            if (isSelected) {
                setStroke(dpPx(2f), accent)
            } else {
                setStroke(dpPx(1f), Color.parseColor("#36FFFFFF"))
            }
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(android.R.attr.state_selected), focused)
            addState(intArrayOf(), idle)
        }
    }

    private fun createColorSwatchDrawable(hexColor: String, accent: Int, isSelected: Boolean = false): StateListDrawable {
        val baseColor = try { Color.parseColor(hexColor) } catch (_: Exception) { accent }
        val focused = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(17f).toFloat()
            setColor(ColorUtils.setAlphaComponent(baseColor, if (isSelected) 125 else 92))
            setStroke(dpPx(2f), Color.WHITE)
        }
        val idle = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(17f).toFloat()
            setColor(ColorUtils.setAlphaComponent(baseColor, if (isSelected) 88 else 36))
            if (isSelected) {
                setStroke(dpPx(2f), Color.WHITE)
            } else {
                setStroke(dpPx(1f), ColorUtils.setAlphaComponent(baseColor, 145))
            }
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(android.R.attr.state_selected), focused)
            addState(intArrayOf(), idle)
        }
    }

    private fun createRainbowSpectrumDrawable(): GradientDrawable {
        return GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(
                Color.parseColor("#EF4444"),
                Color.parseColor("#F59E0B"),
                Color.parseColor("#10B981"),
                Color.parseColor("#00F0FF"),
                Color.parseColor("#3B82F6"),
                Color.parseColor("#A855F7"),
                Color.parseColor("#EC4899"),
                Color.parseColor("#EF4444")
            )
        ).apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(5f).toFloat()
        }
    }

    private fun createWhiteCctSpectrumDrawable(): GradientDrawable {
        return GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(
                Color.parseColor("#F59E0B"),
                Color.parseColor("#FDE68A"),
                Color.parseColor("#FFFFFF"),
                Color.parseColor("#BAE6FD"),
                Color.parseColor("#38BDF8")
            )
        ).apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(5f).toFloat()
        }
    }
}
