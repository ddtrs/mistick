package com.mitv.customlauncher.ui

import android.app.ActivityManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.mitv.customlauncher.service.MediaStateBus
import java.util.Locale

/**
 * Список недавно открытых приложений. Заполняется из KeyMapperAccessibilityService
 * (событие смены окна), поэтому дополнительные разрешения не нужны.
 */
object RecentAppsTracker {
    private const val MAX = 15
    private val lock = Any()
    private val order = ArrayList<String>()
    private val launchableCache = HashMap<String, Boolean>()

    private fun isBlocked(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p == "android" ||
            p.contains("systemui") ||
            p.contains("katniss") ||
            p.contains("inputmethod") ||
            p.contains("patchwall") ||
            p.contains("mitv.tvhome")
    }

    fun onForegroundPackage(context: Context, pkg: String) {
        if (pkg == context.packageName || isBlocked(pkg)) return
        synchronized(lock) {
            if (order.firstOrNull() == pkg) return
            val ok = launchableCache.getOrPut(pkg) {
                try {
                    val pm = context.packageManager
                    (pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg)) != null
                } catch (_: Exception) {
                    false
                }
            }
            if (!ok) return
            order.remove(pkg)
            order.add(0, pkg)
            while (order.size > MAX) order.removeAt(order.size - 1)
        }
    }

    fun snapshot(context: Context): List<String> {
        val pm = context.packageManager
        synchronized(lock) {
            val it = order.iterator()
            while (it.hasNext()) {
                val p = it.next()
                val exists = try {
                    pm.getApplicationInfo(p, 0)
                    true
                } catch (_: Exception) {
                    false
                }
                if (!exists) it.remove()
            }
            return ArrayList(order)
        }
    }

    fun remove(pkg: String) {
        synchronized(lock) { order.remove(pkg) }
    }
}

class RecentAppsOverlay(
    private val context: Context,
    private val parent: FrameLayout,
    private val accentProvider: () -> Int,
    private val blurProvider: () -> Bitmap?,
    private val onOpenApp: (String) -> Unit,
    private val onBack: () -> Unit
) {
    private var root: FrameLayout? = null
    private var cardsRow: LinearLayout? = null
    private var scroll: HorizontalScrollView? = null
    private var closeAllBtn: TextView? = null
    private var emptyText: TextView? = null
    private var ramText: TextView? = null
    private var ramFill: View? = null
    private var ramTrackWidthPx = 0

    private class Item(val pkg: String, val view: LinearLayout)

    private val items = ArrayList<Item>()
    private var sel = 0
    private var onCloseAllRow = false

    val isVisible: Boolean get() = root != null

    private fun dp(v: Float): Int = (v * context.resources.displayMetrics.density + 0.5f).toInt()

    private fun rounded(fill: Int, stroke: Int, strokeDp: Float, radiusDp: Float): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radiusDp).toFloat()
            setColor(fill)
            if (strokeDp > 0f) setStroke(dp(strokeDp), stroke)
        }

    fun show() {
        if (root != null) return
        val accent = accentProvider()
        val r = FrameLayout(context).apply {
            isClickable = true
            isFocusable = false
            translationZ = dp(120f).toFloat()
            alpha = 0f
        }

        blurProvider()?.let { bmp ->
            r.addView(
                ImageView(context).apply {
                    setImageBitmap(bmp)
                    scaleType = ImageView.ScaleType.FIT_XY
                },
                FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
            )
        }
        r.addView(
            View(context).apply { setBackgroundColor(Color.parseColor("#8A05070C")) },
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        r.addView(
            TextView(context).apply {
                text = "Недавние приложения"
                setTextColor(Color.WHITE)
                setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 26f)
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            },
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.TOP or Gravity.START
                leftMargin = dp(56f)
                topMargin = dp(36f)
            }
        )

        // Плашка ОЗУ
        ramTrackWidthPx = dp(130f)
        val fill = View(context).apply {
            background = rounded(Color.WHITE, 0, 0f, 99f)
        }
        ramFill = fill
        val track = FrameLayout(context).apply {
            background = rounded(Color.parseColor("#38FFFFFF"), 0, 0f, 99f)
            addView(fill, FrameLayout.LayoutParams(dp(60f), ViewGroup.LayoutParams.MATCH_PARENT))
        }
        val ramLabel = TextView(context).apply {
            setTextColor(Color.WHITE)
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        ramText = ramLabel
        val pill = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18f), dp(10f), dp(18f), dp(10f))
            background = rounded(Color.parseColor("#33FFFFFF"), Color.parseColor("#66FFFFFF"), 1.5f, 99f)
            addView(ramLabel, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(
                track,
                LinearLayout.LayoutParams(ramTrackWidthPx, dp(6f)).apply { leftMargin = dp(14f) }
            )
        }
        r.addView(
            pill,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.TOP or Gravity.END
                rightMargin = dp(56f)
                topMargin = dp(28f)
            }
        )

        // Карточки
        val row = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(56f), dp(24f), dp(56f), dp(24f))
            clipChildren = false
            clipToPadding = false
        }
        cardsRow = row
        val sv = HorizontalScrollView(context).apply {
            isHorizontalScrollBarEnabled = false
            isFocusable = false
            overScrollMode = View.OVER_SCROLL_NEVER
            clipChildren = false
            clipToPadding = false
            addView(row, FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        scroll = sv
        r.addView(
            sv,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.CENTER_VERTICAL
            }
        )

        val empty = TextView(context).apply {
            text = "Пока нет недавних приложений"
            setTextColor(Color.parseColor("#B3FFFFFF"))
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 20f)
            visibility = View.GONE
        }
        emptyText = empty
        r.addView(
            empty,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.CENTER
            }
        )

        // Низ: «Закрыть все» + подсказка
        val closeAll = TextView(context).apply {
            text = "Закрыть все"
            setTextColor(Color.WHITE)
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 16f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            gravity = Gravity.CENTER
            setPadding(dp(28f), dp(12f), dp(28f), dp(12f))
        }
        closeAllBtn = closeAll
        val hint = TextView(context).apply {
            text = "OK — открыть   ·   ↑ — закрыть приложение   ·   Назад — выход"
            setTextColor(Color.parseColor("#80FFFFFF"))
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 13f)
            gravity = Gravity.CENTER
        }
        val bottom = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            addView(closeAll, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            addView(
                hint,
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    topMargin = dp(14f)
                }
            )
        }
        r.addView(
            bottom,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                gravity = Gravity.BOTTOM
                bottomMargin = dp(32f)
            }
        )

        parent.addView(r, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        root = r

        items.clear()
        val pm = context.packageManager
        for (pkg in RecentAppsTracker.snapshot(context)) {
            val icon = try {
                pm.getApplicationIcon(pkg)
            } catch (_: Exception) {
                null
            }
            val label = try {
                pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
            } catch (_: Exception) {
                pkg
            }
            val card = buildCard(icon, label)
            row.addView(
                card,
                LinearLayout.LayoutParams(dp(168f), dp(208f)).apply { rightMargin = dp(20f) }
            )
            items.add(Item(pkg, card))
        }

        sel = 0
        onCloseAllRow = false
        refreshRam()
        updateEmptyState()
        applySelection(animate = false)
        r.animate().alpha(1f).setDuration(170L).start()
    }

    private fun buildCard(icon: android.graphics.drawable.Drawable?, label: String): LinearLayout {
        return LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(14f), dp(18f), dp(14f), dp(18f))
            background = rounded(Color.parseColor("#26FFFFFF"), Color.parseColor("#33FFFFFF"), 1f, 24f)
            addView(
                ImageView(context).apply {
                    setImageDrawable(icon)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                },
                LinearLayout.LayoutParams(dp(88f), dp(88f))
            )
            addView(
                TextView(context).apply {
                    text = label
                    setTextColor(Color.WHITE)
                    setTextSize(android.util.TypedValue.COMPLEX_UNIT_SP, 16f)
                    typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                    gravity = Gravity.CENTER
                    maxLines = 2
                    ellipsize = android.text.TextUtils.TruncateAt.END
                },
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
                    topMargin = dp(16f)
                }
            )
        }
    }

    private fun refreshRam() {
        try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val mi = ActivityManager.MemoryInfo()
            am.getMemoryInfo(mi)
            if (mi.totalMem <= 0L) return
            val gb = 1024.0 * 1024.0 * 1024.0
            val used = (mi.totalMem - mi.availMem).coerceAtLeast(0L)
            ramText?.text = String.format(
                Locale.US, "ОЗУ %.1f ГБ из %.1f ГБ", used / gb, mi.totalMem / gb
            )
            val frac = (used.toFloat() / mi.totalMem.toFloat()).coerceIn(0.03f, 1f)
            ramFill?.let { f ->
                val lp = f.layoutParams
                lp.width = (ramTrackWidthPx * frac).toInt()
                f.layoutParams = lp
            }
        } catch (_: Exception) {
        }
    }

    private fun updateEmptyState() {
        val none = items.isEmpty()
        emptyText?.visibility = if (none) View.VISIBLE else View.GONE
        closeAllBtn?.visibility = if (none) View.INVISIBLE else View.VISIBLE
        scroll?.visibility = if (none) View.GONE else View.VISIBLE
    }

    private fun applySelection(animate: Boolean) {
        val accent = accentProvider()
        for ((i, it) in items.withIndex()) {
            val selected = !onCloseAllRow && i == sel
            it.view.background = if (selected) {
                rounded(Color.parseColor("#40FFFFFF"), accent, 2.5f, 24f)
            } else {
                rounded(Color.parseColor("#26FFFFFF"), Color.parseColor("#33FFFFFF"), 1f, 24f)
            }
            val s = if (selected) 1.07f else 1f
            if (animate) {
                it.view.animate().scaleX(s).scaleY(s).setDuration(120L).start()
            } else {
                it.view.scaleX = s
                it.view.scaleY = s
            }
        }
        closeAllBtn?.background = if (onCloseAllRow) {
            rounded(Color.parseColor("#40FFFFFF"), accent, 2.5f, 99f)
        } else {
            rounded(Color.parseColor("#26FFFFFF"), Color.parseColor("#33FFFFFF"), 1f, 99f)
        }
        if (!onCloseAllRow && sel in items.indices) {
            val v = items[sel].view
            scroll?.post {
                val sv = scroll ?: return@post
                val target = v.left - (sv.width - v.width) / 2
                sv.smoothScrollTo(target.coerceAtLeast(0), 0)
            }
        }
    }

    private fun killPackage(pkg: String) {
        try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            am.killBackgroundProcesses(pkg)
        } catch (_: Exception) {
        }
        RecentAppsTracker.remove(pkg)
    }

    private fun closeSelected() {
        if (sel !in items.indices) return
        val item = items[sel]
        killPackage(item.pkg)
        items.removeAt(sel)
        val v = item.view
        v.animate().alpha(0f).translationY(-dp(40f).toFloat()).setDuration(160L).withEndAction {
            cardsRow?.removeView(v)
            if (sel >= items.size) sel = (items.size - 1).coerceAtLeast(0)
            updateEmptyState()
            applySelection(animate = false)
            refreshRam()
        }.start()
        v.postDelayed({ refreshRam() }, 600L)
    }

    private fun closeAll() {
        // Играющую сейчас музыку не трогаем
        val st = MediaStateBus.state.value
        val keep = if (st.isPlaying) st.sourcePackage else ""
        val toRemove = items.filter { it.pkg != keep }
        for (it in toRemove) {
            killPackage(it.pkg)
            items.remove(it)
            val v = it.view
            v.animate().alpha(0f).setDuration(160L).withEndAction { cardsRow?.removeView(v) }.start()
        }
        sel = 0
        onCloseAllRow = items.isEmpty()
        updateEmptyState()
        applySelection(animate = true)
        closeAllBtn?.postDelayed({ refreshRam() }, 600L)
    }

    /** Возвращает true — событие поглощено (пока панель открыта, поглощается всё). */
    fun handleKey(event: KeyEvent): Boolean {
        if (root == null) return false
        val down = event.action == KeyEvent.ACTION_DOWN
        if (!down) return true
        val code = event.keyCode
        when (code) {
            KeyEvent.KEYCODE_BACK, KeyEvent.KEYCODE_ESCAPE -> {
                if (event.repeatCount == 0) {
                    dismiss()
                    onBack()
                }
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> if (!onCloseAllRow && sel > 0) {
                sel--
                applySelection(animate = true)
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> if (!onCloseAllRow && sel < items.size - 1) {
                sel++
                applySelection(animate = true)
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> if (!onCloseAllRow && items.isNotEmpty()) {
                onCloseAllRow = true
                applySelection(animate = true)
            }
            KeyEvent.KEYCODE_DPAD_UP -> {
                if (onCloseAllRow) {
                    onCloseAllRow = false
                    applySelection(animate = true)
                } else if (event.repeatCount == 0) {
                    closeSelected()
                }
            }
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER, KeyEvent.KEYCODE_NUMPAD_ENTER,
            KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_SELECT -> if (event.repeatCount == 0) {
                if (items.isEmpty()) {
                    dismiss()
                    onBack()
                } else if (onCloseAllRow) {
                    closeAll()
                } else if (sel in items.indices) {
                    val pkg = items[sel].pkg
                    dismiss()
                    onOpenApp(pkg)
                }
            }
        }
        return true
    }

    fun dismiss() {
        val r = root ?: return
        root = null
        r.animate().cancel()
        parent.removeView(r)
        items.clear()
        cardsRow = null
        scroll = null
        closeAllBtn = null
        emptyText = null
        ramText = null
        ramFill = null
    }
}
