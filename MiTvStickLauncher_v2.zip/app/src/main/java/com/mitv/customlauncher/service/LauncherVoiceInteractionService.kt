package com.mitv.customlauncher.service

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.service.voice.VoiceInteractionService
import android.service.voice.VoiceInteractionSession
import android.service.voice.VoiceInteractionSessionService
import android.speech.RecognitionService
import android.speech.SpeechRecognizer
import android.util.Log

/**
 * Лаунчер как настоящий системный ассистент.
 *
 * Система сама вызывает showSession() этого сервиса по кнопке ассистента — без Katniss,
 * без перехвата чужого окна и без костыльного BACK.
 * Прописывается через WRITE_SECURE_SETTINGS в KeyMapperAccessibilityService.ensureServicesActive().
 */
class LauncherVoiceInteractionService : VoiceInteractionService() {
    override fun onReady() {
        super.onReady()
        Log.i("AssistKey", "LauncherVoiceInteractionService ready")
    }
}

class LauncherVoiceInteractionSessionService : VoiceInteractionSessionService() {
    override fun onNewSession(args: Bundle?): VoiceInteractionSession =
        LauncherVoiceInteractionSession(this)
}

class LauncherVoiceInteractionSession(context: Context) : VoiceInteractionSession(context) {

    override fun onCreate() {
        super.onCreate()
        // Своего окна у сессии нет: интерфейс ассистента рисует сам лаунчер (Dynamic Island).
        setUiEnabled(false)
    }

    override fun onShow(args: Bundle?, showFlags: Int) {
        super.onShow(args, showFlags)
        Log.i("AssistKey", "VoiceInteractionSession.onShow flags=$showFlags")
        // Кнопку мог уже поймать onKeyEvent в сервисе доступности — второй раз не запускаем.
        if (!DynamicIslandBus.isAssistKeyRecentlyTriggered()) {
            DynamicIslandBus.markAssistKeyTriggered()
            DynamicIslandBus.triggerAssistant(context)
        }
        hide()
        finish()
    }
}

/**
 * Заглушка: схема voice-interaction-service на Android 9 требует recognitionService.
 * Не регистрируется как обычный распознаватель (нет intent-filter), всегда возвращает ошибку.
 */
class LauncherStubRecognitionService : RecognitionService() {
    override fun onStartListening(recognizerIntent: Intent?, listener: Callback?) {
        try {
            listener?.error(SpeechRecognizer.ERROR_CLIENT)
        } catch (_: Exception) {
        }
    }

    override fun onCancel(listener: Callback?) {}

    override fun onStopListening(listener: Callback?) {}
}
