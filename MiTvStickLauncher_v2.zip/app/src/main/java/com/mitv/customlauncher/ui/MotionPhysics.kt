package com.mitv.customlauncher.ui

import android.os.Handler
import android.os.Looper
import android.view.Choreographer
import android.view.View
import android.view.ViewGroup
import com.mitv.customlauncher.data.NativeCore
import java.lang.ref.WeakReference
import kotlin.math.abs

/**
 * Централизованный физический движок анимаций лаунчера (Apple TV / tvOS + PS5 feel).
 *
 * Работает на едином 60 FPS цикле [Choreographer] и пакетном аналитическом интеграторе пружин
 * в Rust ([NativeCore.stepSpringsBatch]) с сохранением скорости при прерывании, нулевыми аллокациями
 * в кадре и автоматическим управлением [View.LAYER_TYPE_HARDWARE] для экономии ОЗУ на Mi TV Stick.
 */
object MotionPhysics : Choreographer.FrameCallback {

    data class Preset(
        val stiffness: Float,
        val damping: Float
    )

    // Откалиброванные физические пресеты (быстрые и отзывчивые на 60Hz Mi TV Stick)
    val FOCUS_CARD = Preset(stiffness = 420f, damping = 0.72f)
    val FOCUS_ICON = Preset(stiffness = 320f, damping = 0.66f)
    val PRESS = Preset(stiffness = 700f, damping = 0.62f)
    val SHEET = Preset(stiffness = 820f, damping = 0.88f)
    val EXIT = Preset(stiffness = 1200f, damping = 1.0f)
    val STRIP = Preset(stiffness = 780f, damping = 0.86f)

    enum class Prop(val posTol: Float, val velTol: Float) {
        SCALE_X(0.002f, 0.03f),
        SCALE_Y(0.002f, 0.03f),
        TRANSLATION_X(0.6f, 8.0f),
        TRANSLATION_Y(0.6f, 8.0f),
        ALPHA(0.015f, 0.08f),
        CUSTOM(0.006f, 0.05f)
    }

    private class Track {
        var viewRef: WeakReference<View>? = null
        var viewIdentity: Int = 0
        var prop: Prop = Prop.SCALE_X
        var pos: Float = 0f
        var vel: Float = 0f
        var target: Float = 0f
        var stiffness: Float = 420f
        var damping: Float = 0.72f
        var customKey: Int = 0
        var onUpdate: ((Float) -> Unit)? = null
        var onEnd: (() -> Unit)? = null
        var active: Boolean = false
    }

    private const val STRIDE = 5
    private val tracks = ArrayList<Track>(48)
    private var batchBuf = FloatArray(64 * STRIDE)
    private val mainHandler = Handler(Looper.getMainLooper())
    private var isLoopRunning = false
    private var lastFrameNanos = 0L

    // Отслеживаем количество активных пружин на каждом View для безопасного LAYER_TYPE_HARDWARE
    private val hwLayerCounts = HashMap<Int, Int>(32)
    private val pendingEndCallbacks = ArrayList<() -> Unit>(16)
    private val sheetTokens = HashMap<Int, Int>(8)
    private val exitingSheets = HashSet<Int>(8)

    fun isSheetExiting(panel: View): Boolean = exitingSheets.contains(System.identityHashCode(panel))

    // ───────────────────────── Базовое API ─────────────────────────

    fun springTo(
        view: View,
        prop: Prop,
        target: Float,
        preset: Preset,
        initialVelocity: Float = Float.NaN,
        onEnd: (() -> Unit)? = null
    ) {
        val id = System.identityHashCode(view)
        val existing = findTrack(id, prop)
        if (existing != null) {
            existing.target = target
            existing.stiffness = preset.stiffness
            existing.damping = preset.damping
            if (!initialVelocity.isNaN()) {
                existing.vel = initialVelocity
            }
            existing.onEnd = onEnd
            ensureLoopRunning()
            return
        }

        val current = readProp(view, prop)
        val startVel = if (initialVelocity.isNaN()) 0f else initialVelocity
        if (abs(current - target) <= prop.posTol && abs(startVel) <= prop.velTol) {
            writeProp(view, prop, target)
            onEnd?.invoke()
            return
        }

        val t = obtainTrack()
        t.viewRef = WeakReference(view)
        t.viewIdentity = id
        t.prop = prop
        t.pos = current
        t.vel = startVel
        t.target = target
        t.stiffness = preset.stiffness
        t.damping = preset.damping
        t.customKey = 0
        t.onUpdate = null
        t.onEnd = onEnd
        t.active = true
        acquireHardwareLayer(view, id)
        ensureLoopRunning()
    }

    /**
     * Запускает или перенаправляет скалярную пружину (например, прогресс прокрутки ленты).
     */
    fun springValue(
        key: Int,
        startValue: Float,
        targetValue: Float,
        preset: Preset,
        initialVelocity: Float = Float.NaN,
        onUpdate: (Float) -> Unit,
        onEnd: (() -> Unit)? = null
    ) {
        val existing = findCustomTrack(key)
        if (existing != null) {
            existing.target = targetValue
            existing.stiffness = preset.stiffness
            existing.damping = preset.damping
            if (!initialVelocity.isNaN()) {
                existing.vel = initialVelocity
            }
            existing.onUpdate = onUpdate
            existing.onEnd = onEnd
            ensureLoopRunning()
            return
        }
        val t = obtainTrack()
        t.viewRef = null
        t.viewIdentity = 0
        t.prop = Prop.CUSTOM
        t.pos = startValue
        t.vel = if (initialVelocity.isNaN()) 0f else initialVelocity
        t.target = targetValue
        t.stiffness = preset.stiffness
        t.damping = preset.damping
        t.customKey = key
        t.onUpdate = onUpdate
        t.onEnd = onEnd
        t.active = true
        ensureLoopRunning()
    }

    fun cancelCustom(key: Int): Float {
        val existing = findCustomTrack(key) ?: return 0f
        val lastVel = existing.vel
        existing.active = false
        existing.onUpdate = null
        existing.onEnd = null
        return lastVel
    }

    /**
     * Импульсный толчок: придаёт мгновенную скорость и возвращает View в target по пружине.
     */
    fun impulse(
        view: View,
        prop: Prop,
        velocity: Float,
        target: Float,
        preset: Preset
    ) {
        val id = System.identityHashCode(view)
        val existing = findTrack(id, prop)
        if (existing != null) {
            existing.vel += velocity
            existing.target = target
            existing.stiffness = preset.stiffness
            existing.damping = preset.damping
            ensureLoopRunning()
            return
        }
        springTo(view, prop, target, preset, initialVelocity = velocity)
    }

    fun cancelView(view: View) {
        val id = System.identityHashCode(view)
        var changed = false
        for (i in 0 until tracks.size) {
            val t = tracks[i]
            if (t.active && t.viewIdentity == id) {
                t.active = false
                t.onEnd = null
                t.onUpdate = null
                changed = true
            }
        }
        if (changed) {
            hwLayerCounts.remove(id)
            if (view.layerType == View.LAYER_TYPE_HARDWARE) {
                view.setLayerType(View.LAYER_TYPE_NONE, null)
            }
        }
    }

    // ───────────────────────── Высокоуровневая хореография ─────────────────────────

    /**
     * Двухслойный фокус в стиле Apple TV / tvOS:
     * карточка мягко поднимается и масштабируется, а иконка внутри догоняет с чуть большей лёгкостью.
     */
    fun animateCardFocus(
        card: View,
        iconView: View?,
        hasFocus: Boolean,
        density: Float,
        focusScale: Float = 1.055f,
        iconFocusScale: Float = 1.11f,
        unfocusedAlpha: Float = 0.88f,
        liftDp: Float = 3f
    ) {
        card.animate().cancel()
        iconView?.animate()?.cancel()

        val cardPreset = if (hasFocus) FOCUS_CARD else EXIT
        val targetScale = if (hasFocus) focusScale else 1.0f
        val targetLift = if (hasFocus) -liftDp * density else 0f
        val targetAlpha = if (hasFocus) 1.0f else unfocusedAlpha

        springTo(card, Prop.SCALE_X, targetScale, cardPreset)
        springTo(card, Prop.SCALE_Y, targetScale, cardPreset)
        springTo(card, Prop.TRANSLATION_Y, targetLift, cardPreset)
        springTo(card, Prop.ALPHA, targetAlpha, cardPreset)

        if (iconView != null) {
            val iconPreset = if (hasFocus) FOCUS_ICON else EXIT
            val targetIconScale = if (hasFocus) iconFocusScale else 1.0f
            val targetIconLift = if (hasFocus) -(liftDp * 0.5f) * density else 0f
            springTo(iconView, Prop.SCALE_X, targetIconScale, iconPreset)
            springTo(iconView, Prop.SCALE_Y, targetIconScale, iconPreset)
            springTo(iconView, Prop.TRANSLATION_Y, targetIconLift, iconPreset)
        }
    }

    /**
     * Простой пружинный фокус для кнопок Пункта управления, фильтров и мини-плиток.
     */
    fun animateTileFocus(
        view: View,
        hasFocus: Boolean,
        focusScale: Float = 1.055f,
        unfocusedScale: Float = 1.0f,
        liftDp: Float = 0f,
        density: Float = 1f
    ) {
        view.animate().cancel()
        val preset = if (hasFocus) FOCUS_CARD else EXIT
        val targetScale = if (hasFocus) focusScale else unfocusedScale
        springTo(view, Prop.SCALE_X, targetScale, preset)
        springTo(view, Prop.SCALE_Y, targetScale, preset)
        if (liftDp != 0f) {
            springTo(view, Prop.TRANSLATION_Y, if (hasFocus) -liftDp * density else 0f, preset)
        }
    }

    /**
     * Тактильное вдавливание по нажатию OK: короткий упругий импульс внутрь с отскоком.
     */
    fun pressSquish(view: View, restScale: Float = 1.055f) {
        view.animate().cancel()
        impulse(view, Prop.SCALE_X, velocity = -2.2f, target = restScale, preset = PRESS)
        impulse(view, Prop.SCALE_Y, velocity = -2.2f, target = restScale, preset = PRESS)
    }

    /**
     * Упругий упор в край (Edge Rubber-Band): при попытке уйти за границы ленты.
     * directionX = +1 (упор в правый край -> толчок влево), -1 (упор в левый край -> толчок вправо).
     */
    fun edgeBump(views: List<View>, directionX: Int, density: Float) {
        val kick = -directionX.toFloat() * 170f * density
        for (v in views) {
            if (v.visibility != View.VISIBLE) continue
            impulse(v, Prop.TRANSLATION_X, velocity = kick, target = 0f, preset = PRESS)
        }
    }

    /**
     * Выезд стеклянной панели (Пункт управления / График света / Ассистент) с опциональным каскадом плиток.
     */
    fun sheetEnter(
        panel: View,
        backdrop: View?,
        density: Float,
        staggerChildren: List<View>? = null
    ) {
        val panelId = System.identityHashCode(panel)
        val wasExiting = exitingSheets.remove(panelId)
        val token = (sheetTokens[panelId] ?: 0) + 1
        sheetTokens[panelId] = token

        panel.animate().cancel()
        if (backdrop != null) {
            backdrop.animate().cancel()
            if (!wasExiting) {
                cancelView(backdrop)
                backdrop.alpha = 0f
            }
            backdrop.visibility = View.VISIBLE
            springTo(backdrop, Prop.ALPHA, 1f, SHEET)
        }
        if (!wasExiting) {
            cancelView(panel)
            panel.alpha = 0f
            panel.translationY = 22f * density
            panel.scaleX = 0.965f
            panel.scaleY = 0.965f
        }
        panel.visibility = View.VISIBLE

        springTo(panel, Prop.ALPHA, 1f, SHEET)
        springTo(panel, Prop.TRANSLATION_Y, 0f, SHEET)
        springTo(panel, Prop.SCALE_X, 1f, SHEET)
        springTo(panel, Prop.SCALE_Y, 1f, SHEET)

        if (!wasExiting && !staggerChildren.isNullOrEmpty()) {
            val offsetPx = 12f * density
            staggerChildren.forEachIndexed { idx, child ->
                if (child.visibility != View.VISIBLE) return@forEachIndexed
                cancelView(child)
                val targetTy = child.translationY
                child.alpha = 0.01f
                child.translationY = targetTy + offsetPx
                val delayMs = (idx * 20L).coerceAtMost(140L)
                mainHandler.postDelayed({
                    if (sheetTokens[panelId] == token && panel.visibility == View.VISIBLE && child.visibility == View.VISIBLE) {
                        springTo(child, Prop.ALPHA, 1f, SHEET)
                        springTo(child, Prop.TRANSLATION_Y, targetTy, SHEET)
                    }
                }, delayMs)
            }
        }
    }

    /**
     * Критически затухающее закрытие панели без отскока.
     */
    fun sheetExit(
        panel: View,
        backdrop: View?,
        density: Float,
        immediate: Boolean = false,
        onEnd: (() -> Unit)? = null
    ) {
        val panelId = System.identityHashCode(panel)
        val token = (sheetTokens[panelId] ?: 0) + 1
        sheetTokens[panelId] = token

        panel.animate().cancel()
        if (backdrop != null) {
            backdrop.animate().cancel()
        }
        if (immediate || panel.visibility != View.VISIBLE) {
            exitingSheets.remove(panelId)
            cancelView(panel)
            if (backdrop != null) cancelView(backdrop)
            panel.alpha = 1f
            panel.translationY = 0f
            panel.scaleX = 1f
            panel.scaleY = 1f
            panel.visibility = View.GONE
            backdrop?.visibility = View.GONE
            onEnd?.invoke()
            return
        }
        exitingSheets.add(panelId)
        if (backdrop != null && backdrop.visibility == View.VISIBLE) {
            springTo(backdrop, Prop.ALPHA, 0f, EXIT) {
                if (sheetTokens[panelId] == token) {
                    backdrop.visibility = View.GONE
                }
            }
        }
        springTo(panel, Prop.TRANSLATION_Y, 14f * density, EXIT)
        springTo(panel, Prop.SCALE_X, 0.97f, EXIT)
        springTo(panel, Prop.SCALE_Y, 0.97f, EXIT)
        springTo(panel, Prop.ALPHA, 0f, EXIT) {
            if (sheetTokens[panelId] == token) {
                exitingSheets.remove(panelId)
                panel.visibility = View.GONE
                panel.alpha = 1f
                panel.translationY = 0f
                panel.scaleX = 1f
                panel.scaleY = 1f
                onEnd?.invoke()
            }
        }
    }

    /**
     * Собирает видимых прямых детей контейнера для мягкого каскада (не более 6 элементов).
     */
    fun collectVisibleChildren(container: ViewGroup?, maxCount: Int = 6): List<View> {
        if (container == null) return emptyList()
        val result = ArrayList<View>(maxCount)
        for (i in 0 until container.childCount) {
            val c = container.getChildAt(i)
            if (c.visibility == View.VISIBLE) {
                result.add(c)
                if (result.size >= maxCount) break
            }
        }
        return result
    }

    // ───────────────────────── Цикл Choreographer ─────────────────────────

    override fun doFrame(frameTimeNanos: Long) {
        val dt = if (lastFrameNanos == 0L) {
            0.016f
        } else {
            ((frameTimeNanos - lastFrameNanos) * 1e-9f).coerceIn(0.001f, 0.05f)
        }
        lastFrameNanos = frameTimeNanos

        // 1. Собираем активные треки в плоский буфер
        var activeCount = 0
        for (i in 0 until tracks.size) {
            if (tracks[i].active) activeCount++
        }
        if (activeCount == 0) {
            stopLoop()
            return
        }

        val neededFloats = activeCount * STRIDE
        if (batchBuf.size < neededFloats) {
            batchBuf = FloatArray(neededFloats + 32 * STRIDE)
        }

        var slotIdx = 0
        for (i in 0 until tracks.size) {
            val t = tracks[i]
            if (!t.active) continue
            val base = slotIdx * STRIDE
            batchBuf[base] = t.pos
            batchBuf[base + 1] = t.vel
            batchBuf[base + 2] = t.target
            batchBuf[base + 3] = t.stiffness
            batchBuf[base + 4] = t.damping
            slotIdx++
        }

        // 2. Один батч-шаг в Rust (или Kotlin-резерв)
        NativeCore.stepSpringsBatch(batchBuf, activeCount, dt)

        // 3. Применяем новые координаты и завершаем успокоившиеся пружины
        pendingEndCallbacks.clear()
        slotIdx = 0
        var stillActive = 0

        for (i in 0 until tracks.size) {
            val t = tracks[i]
            if (!t.active) continue
            val base = slotIdx * STRIDE
            slotIdx++

            val newPos = batchBuf[base]
            val newVel = batchBuf[base + 1]
            t.pos = newPos
            t.vel = newVel

            val settled = abs(newPos - t.target) <= t.prop.posTol && abs(newVel) <= t.prop.velTol
            val finalPos = if (settled) t.target else newPos

            if (t.prop == Prop.CUSTOM) {
                t.onUpdate?.invoke(finalPos)
                if (settled) {
                    t.active = false
                    t.onUpdate = null
                    t.onEnd?.let { pendingEndCallbacks.add(it) }
                    t.onEnd = null
                } else {
                    stillActive++
                }
            } else {
                val view = t.viewRef?.get()
                if (view == null) {
                    t.active = false
                    t.onEnd = null
                    hwLayerCounts.remove(t.viewIdentity)
                } else {
                    writeProp(view, t.prop, finalPos)
                    if (settled) {
                        t.active = false
                        releaseHardwareLayer(view, t.viewIdentity)
                        t.onEnd?.let { pendingEndCallbacks.add(it) }
                        t.onEnd = null
                    } else {
                        stillActive++
                    }
                }
            }
        }

        // Вызываем onEnd после завершения прохода по tracks, чтобы колбэки могли запускать новые пружины
        if (pendingEndCallbacks.isNotEmpty()) {
            val snapshot = ArrayList(pendingEndCallbacks)
            pendingEndCallbacks.clear()
            for (cb in snapshot) {
                cb.invoke()
            }
            // Перепроверяем, не добавили ли колбэки новые активные треки
            if (stillActive == 0) {
                for (i in 0 until tracks.size) {
                    if (tracks[i].active) {
                        stillActive++
                        break
                    }
                }
            }
        }

        if (stillActive > 0) {
            Choreographer.getInstance().postFrameCallback(this)
        } else {
            stopLoop()
        }
    }

    private fun ensureLoopRunning() {
        if (!isLoopRunning) {
            isLoopRunning = true
            lastFrameNanos = 0L
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    private fun stopLoop() {
        isLoopRunning = false
        lastFrameNanos = 0L
        Choreographer.getInstance().removeFrameCallback(this)
    }

    private fun findTrack(viewId: Int, prop: Prop): Track? {
        for (i in 0 until tracks.size) {
            val t = tracks[i]
            if (t.active && t.viewIdentity == viewId && t.prop == prop) return t
        }
        return null
    }

    private fun findCustomTrack(key: Int): Track? {
        for (i in 0 until tracks.size) {
            val t = tracks[i]
            if (t.active && t.prop == Prop.CUSTOM && t.customKey == key) return t
        }
        return null
    }

    private fun obtainTrack(): Track {
        for (i in 0 until tracks.size) {
            if (!tracks[i].active) return tracks[i]
        }
        val t = Track()
        tracks.add(t)
        return t
    }

    private fun acquireHardwareLayer(view: View, id: Int) {
        val count = (hwLayerCounts[id] ?: 0) + 1
        hwLayerCounts[id] = count
        if (count == 1 && view.layerType == View.LAYER_TYPE_NONE) {
            view.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        }
    }

    private fun releaseHardwareLayer(view: View, id: Int) {
        val next = (hwLayerCounts[id] ?: 1) - 1
        if (next <= 0) {
            hwLayerCounts.remove(id)
            if (view.layerType == View.LAYER_TYPE_HARDWARE) {
                view.setLayerType(View.LAYER_TYPE_NONE, null)
            }
        } else {
            hwLayerCounts[id] = next
        }
    }

    private fun readProp(view: View, prop: Prop): Float = when (prop) {
        Prop.SCALE_X -> view.scaleX
        Prop.SCALE_Y -> view.scaleY
        Prop.TRANSLATION_X -> view.translationX
        Prop.TRANSLATION_Y -> view.translationY
        Prop.ALPHA -> view.alpha
        Prop.CUSTOM -> 0f
    }

    private fun writeProp(view: View, prop: Prop, value: Float) {
        when (prop) {
            Prop.SCALE_X -> view.scaleX = value
            Prop.SCALE_Y -> view.scaleY = value
            Prop.TRANSLATION_X -> view.translationX = value
            Prop.TRANSLATION_Y -> view.translationY = value
            Prop.ALPHA -> view.alpha = value.coerceIn(0f, 1f)
            Prop.CUSTOM -> {}
        }
    }
}
