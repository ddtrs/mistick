package com.mitv.customlauncher.data

import android.app.ActivityManager
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.isActive
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import android.graphics.Color
import kotlinx.coroutines.delay
import java.nio.ByteOrder
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import kotlin.math.sqrt
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.speech.tts.TextToSpeech
import com.mitv.customlauncher.service.DynamicIslandBus
import com.mitv.customlauncher.service.RemoteConsoleServer
import com.mitv.customlauncher.service.ShellKeyController
import android.util.Base64
import android.util.Log
import android.widget.Toast
import android.view.KeyEvent
import com.mitv.customlauncher.service.TvUiControllerBus
import com.mitv.customlauncher.service.MediaStateBus
import com.mitv.customlauncher.service.NavSoundPlayer
import com.mitv.customlauncher.service.VolumeHudBus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


/**
 * 100% Gemini-ассистент (2.5 & 3.8):
 * - Слушает живой голос напрямую в формате WAV (идеально понимает украинский, русский, суржик и английский!)
 * - Использует рабочий ключ XOR_PROTECTED_KEY (без ошибки 401!)
 * - Сам управляет Spotify, Kick, YouTube, цветами лаунчера, приложениями и звуком ТВ
 */
/**
 * Голосовой синтезатор речи ассистента (TTS) с мгновенным откликом,
 * автоопределением украинского/русского/английского языка и приглушением фоновой музыки (Audio Ducking).
 */
/**
 * Облачный голосовой синтезатор речи Gemini TTS (gemini-2.5-flash-preview-tts):
 * - 0 МБ фонового потребления ОЗУ (работает без системного com.google.android.tts напрямую через легковесный AudioTrack)
 * - 5 живых нейронных голосов на выбор: Puck, Charon, Fenrir (мужские) и Kore, Aoede (женские)
 * - Вычисляет реальную амплитуду звуковой волны (currentVoiceWaveLevel) каждые 40 мс для 60 FPS анимации полосок Dynamic Island
 */
/**
 * Контроллер умной Wi-Fi LED-ленты Tuya Smart Life (OpenAPI v2.0 HMAC-SHA256):
 * - 360° полный цветовой спектр HSV (Оттенок 0..360°, Насыщенность 10..100%, Яркость 10..100%)
 * - Автоопределение поддерживаемых датапоинтов ленты (v2 `colour_data_v2` / `bright_value_v2` и v1 `colour_data` / `bright_value`)
 * - 12 выверенных студийных пресетов оттенков + режим тёплого белого света
 * - 4 динамических режима (Радуга, Дыхание, Вечеринка, Ночник)
 * - Режим синхронизации с акцентным цветом темы лаунчера (Ambilight)
 */
data class LedSwatchPreset(
    val name: String,
    val hexColor: String,
    val hue: Int,
    val satPct: Int,
    val brightPct: Int = 100,
    val isWarmWhite: Boolean = false
)

enum class SmartLightTarget {
    STRIP,
    BULB,
    BOTH
}

object TuyaSmartHomeController {

    private const val TAG = "TuyaLauncher"

    // LED Strip preferences
    private const val PREF_LED_IS_ON = "pref_tuya_led_is_on"
    private const val PREF_LED_HUE = "pref_tuya_led_hue"
    private const val PREF_LED_SAT = "pref_tuya_led_sat"
    private const val PREF_LED_BRIGHT = "pref_tuya_led_bright"
    private const val PREF_LED_SYNC_THEME = "pref_tuya_led_sync_theme"
    private const val PREF_LED_MODE_LABEL = "pref_tuya_led_mode_label"
    private const val PREF_LEARNED_FMT_NAME = "pref_tuya_learned_fmt_v58"
    private const val PREF_LEARNED_WITH_MODE = "pref_tuya_learned_mode_v58"
    private const val PREF_DISCOVERED_SWITCH_CODE = "pref_tuya_switch_code_v58"

    // LED Bulb (LED BULB W5K) preferences
    private const val PREF_BULB_IS_ON = "pref_tuya_bulb_is_on"
    private const val PREF_BULB_WORK_MODE = "pref_tuya_bulb_work_mode" // "white" or "colour"
    private const val PREF_BULB_HUE = "pref_tuya_bulb_hue"
    private const val PREF_BULB_SAT = "pref_tuya_bulb_sat"
    private const val PREF_BULB_BRIGHT = "pref_tuya_bulb_bright"
    private const val PREF_BULB_TEMP = "pref_tuya_bulb_temp" // 0..100 (0 = 2700K Warm, 50 = 4500K Neutral/Day, 100 = 6500K Cool)
    private const val PREF_BULB_MODE_LABEL = "pref_tuya_bulb_mode_label"
    private const val PREF_BULB_LEARNED_FMT_NAME = "pref_tuya_bulb_learned_fmt_v85"
    private const val PREF_BULB_LEARNED_WITH_MODE = "pref_tuya_bulb_learned_mode_v85"
    private const val PREF_BULB_DISCOVERED_SWITCH_CODE = "pref_tuya_bulb_switch_code_v85"

    // Synchronization between LED Strip and LED Bulb
    private const val PREF_DEVICES_LINKED = "pref_tuya_devices_linked_v85"

    @Volatile
    var activeStudioTarget: SmartLightTarget = SmartLightTarget.STRIP

    private val apiHosts = listOf(
        "${LauncherConfig.CLOUDFLARE_GATEWAY_URL}/tuya",
        "https://openapi.tuyaeu.com",
        "https://openapi-weaz.tuyaeu.com"
    )

    val CURATED_SWATCHES: List<LedSwatchPreset> = listOf(
        // Ряд 1: Неон и киберпанк (выверенные углы круга Tuya Smart Life)
        LedSwatchPreset("Кибер", "#00F0FF", hue = 184, satPct = 100),
        LedSwatchPreset("Океан", "#38BDF8", hue = 200, satPct = 98),
        LedSwatchPreset("Сапфир", "#3B82F6", hue = 224, satPct = 100),
        LedSwatchPreset("Индиго", "#818CF8", hue = 248, satPct = 94),
        LedSwatchPreset("Фиолет", "#C084FC", hue = 271, satPct = 85),
        LedSwatchPreset("Фуксия", "#F472B6", hue = 324, satPct = 95),
        // Ряд 2: Уют, природа и кино
        LedSwatchPreset("Малина", "#FB7185", hue = 336, satPct = 100),
        LedSwatchPreset("Закат", "#FB923C", hue = 20, satPct = 100),
        LedSwatchPreset("Янтарь", "#FBBF24", hue = 38, satPct = 100),
        LedSwatchPreset("Лайм", "#A3E635", hue = 85, satPct = 95),
        LedSwatchPreset("Изумруд", "#34D399", hue = 145, satPct = 96),
        LedSwatchPreset("Тёплый", "#FDE68A", hue = 34, satPct = 28, isWarmWhite = true)
    )

    private enum class ColourFormat {
        V2_OBJECT,
        V2_STRING,
        V1_OBJECT,
        V1_STRING,
        HEX12_LOWER,
        HEX12_UPPER
    }

    private class DeviceCaps(
        val switchCode: String,
        val colourCode: String?,
        val sMax: Int,
        val vMax: Int,
        val hasWorkMode: Boolean,
        val brightCode: String? = null,
        val brightMin: Int = 10,
        val brightMax: Int = 1000,
        val tempCode: String? = null,
        val tempMin: Int = 0,
        val tempMax: Int = 1000
    )

    private sealed class PendingLedAction {
        data class Power(val turnOn: Boolean) : PendingLedAction()
        data class ColorHsv(val hue: Int, val satPct: Int, val brightPct: Int) : PendingLedAction()
        data class WhiteCct(val brightPct: Int, val tempPct: Int) : PendingLedAction()
    }

    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val tokenLock = Any()
    private val queueLock = Any()

    @Volatile
    private var cachedHost: String = "https://openapi.tuyaeu.com"

    @Volatile
    private var cachedAccessToken: String = ""

    @Volatile
    private var tokenExpiresAtWallMs: Long = 0L

    @Volatile
    private var serverTimeOffsetMs: Long = 0L

    @Volatile
    private var discoveredSwitchCode: String = "switch_led"

    @Volatile
    private var discoveredBulbSwitchCode: String = "switch_led"

    private val deviceCapsMap = java.util.concurrent.ConcurrentHashMap<String, DeviceCaps>()

    @Volatile
    private var learnedFormatPair: Pair<ColourFormat, Boolean>? = null

    @Volatile
    private var learnedBulbFormatPair: Pair<ColourFormat, Boolean>? = null

    @Volatile
    private var prefsLoadedIntoRam: Boolean = false

    @Volatile
    private var pendingStripAction: PendingLedAction? = null

    @Volatile
    private var pendingBulbAction: PendingLedAction? = null

    @Volatile
    private var isQueueWorkerRunning: Boolean = false

    @Volatile
    private var effectCycleJob: Job? = null

    @Volatile
    private var warmupStarted: Boolean = false

    @Volatile
    private var lastUserCommandWallMs: Long = 0L

    @Volatile
    var onStateUpdatedUiCallback: (() -> Unit)? = null

    @Volatile
    var onStateUpdatedOverlayCallback: (() -> Unit)? = null

    private fun notifyUi() {
        mainHandler.post {
            onStateUpdatedUiCallback?.invoke()
            onStateUpdatedOverlayCallback?.invoke()
        }
    }

    private fun loadCachedRoutingPrefsIfNeeded(context: Context) {
        if (prefsLoadedIntoRam) return
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val savedFmtName = prefs.getString(PREF_LEARNED_FMT_NAME, "").orEmpty()
        val savedWithMode = prefs.getBoolean(PREF_LEARNED_WITH_MODE, true)
        val savedSw = prefs.getString(PREF_DISCOVERED_SWITCH_CODE, "").orEmpty()
        if (savedSw.isNotEmpty()) discoveredSwitchCode = savedSw
        if (savedFmtName.isNotEmpty()) {
            try {
                val fmt = ColourFormat.valueOf(savedFmtName)
                learnedFormatPair = fmt to savedWithMode
            } catch (_: Exception) {
            }
        }
        val savedBulbFmtName = prefs.getString(PREF_BULB_LEARNED_FMT_NAME, "").orEmpty()
        val savedBulbWithMode = prefs.getBoolean(PREF_BULB_LEARNED_WITH_MODE, true)
        val savedBulbSw = prefs.getString(PREF_BULB_DISCOVERED_SWITCH_CODE, "").orEmpty()
        if (savedBulbSw.isNotEmpty()) discoveredBulbSwitchCode = savedBulbSw
        if (savedBulbFmtName.isNotEmpty()) {
            try {
                val fmt = ColourFormat.valueOf(savedBulbFmtName)
                learnedBulbFormatPair = fmt to savedBulbWithMode
            } catch (_: Exception) {
            }
        }
        prefsLoadedIntoRam = true
    }

    private fun saveLearnedFormatForDevice(context: Context?, devId: String, fmt: ColourFormat, withMode: Boolean) {
        val isBulb = devId == LauncherConfig.TUYA_BULB_DEVICE_ID
        if (isBulb) {
            learnedBulbFormatPair = fmt to withMode
        } else {
            learnedFormatPair = fmt to withMode
        }
        if (context != null) {
            val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit()
                .putString(if (isBulb) PREF_BULB_LEARNED_FMT_NAME else PREF_LEARNED_FMT_NAME, fmt.name)
                .putBoolean(if (isBulb) PREF_BULB_LEARNED_WITH_MODE else PREF_LEARNED_WITH_MODE, withMode)
                .apply()
        }
    }

    fun ensureWarmupStarted(context: Context? = null) {
        if (context != null) {
            loadCachedRoutingPrefsIfNeeded(context)
            ScheduledTaskManager.ensureStarted(context)
        }
        if (warmupStarted) return
        warmupStarted = true
        ioScope.launch {
            try {
                ensureAccessToken(forceRefresh = false)
                loadDeviceSpecifications(LauncherConfig.TUYA_LED_DEVICE_ID)
                loadDeviceSpecifications(LauncherConfig.TUYA_BULB_DEVICE_ID)
                inspectDeviceStatus(context)
            } catch (_: Exception) {
            }
            while (isActive) {
                delay(10 * 60 * 1000L)
                try {
                    val now = System.currentTimeMillis()
                    if (cachedAccessToken.isEmpty() || now > tokenExpiresAtWallMs - 300_000L) {
                        ensureAccessToken(forceRefresh = false)
                    }
                    loadDeviceSpecifications(LauncherConfig.TUYA_LED_DEVICE_ID)
                    loadDeviceSpecifications(LauncherConfig.TUYA_BULB_DEVICE_ID)
                } catch (_: Exception) {
                }
            }
        }
    }

    /**
     * Чтение спецификаций Tuya-устройства (LED Strip или LED Bulb W5K):
     * определяет switchCode, colourCode (colour_data_v2 / colour_data), brightCode (bright_value_v2 / bright_value),
     * tempCode (temp_value_v2 / temp_value), диапазоны и наличие work_mode.
     */
    private suspend fun loadDeviceSpecifications(devId: String = LauncherConfig.TUYA_LED_DEVICE_ID): DeviceCaps? {
        if (devId.isBlank()) return null
        deviceCapsMap[devId]?.let { return it }
        val isBulb = devId == LauncherConfig.TUYA_BULB_DEVICE_ID
        val paths = listOf(
            "/v1.0/devices/$devId/specifications",
            "/v1.0/iot-03/devices/$devId/specification"
        )
        for (path in paths) {
            val resp = executeSignedTuyaRequest("GET", path, "") ?: continue
            if (!resp.optBoolean("success", false)) continue
            try {
                val resObj = resp.optJSONObject("result") ?: continue
                val functions = resObj.optJSONArray("functions") ?: JSONArray()
                var swCode = if (isBulb) discoveredBulbSwitchCode else discoveredSwitchCode
                var colCode: String? = null
                var sMax = 1000
                var vMax = 1000
                var hasWorkMode = false
                var brCode: String? = null
                var brMin = 10
                var brMax = 1000
                var tmpCode: String? = null
                var tmpMin = 0
                var tmpMax = 1000
                for (i in 0 until functions.length()) {
                    val f = functions.optJSONObject(i) ?: continue
                    val code = f.optString("code", "")
                    when (code) {
                        "switch_led", "switch_led_1", "led_switch", "switch_1", "switch" -> {
                            swCode = code
                            if (isBulb) discoveredBulbSwitchCode = code else discoveredSwitchCode = code
                        }
                        "work_mode" -> hasWorkMode = true
                        "colour_data_v2", "colour_data" -> {
                            if (colCode == null || code == "colour_data_v2") {
                                colCode = code
                                val valuesStr = f.optString("values", "{}")
                                val valuesJson = try { JSONObject(valuesStr) } catch (_: Exception) { JSONObject() }
                                val defMax = if (code == "colour_data_v2") 1000 else 255
                                sMax = valuesJson.optJSONObject("s")?.optInt("max", defMax) ?: defMax
                                vMax = valuesJson.optJSONObject("v")?.optInt("max", defMax) ?: defMax
                            }
                        }
                        "bright_value_v2", "bright_value" -> {
                            if (brCode == null || code == "bright_value_v2") {
                                brCode = code
                                val valuesStr = f.optString("values", "{}")
                                val valuesJson = try { JSONObject(valuesStr) } catch (_: Exception) { JSONObject() }
                                val defMax = if (code == "bright_value_v2") 1000 else 255
                                val defMin = if (code == "bright_value_v2") 10 else 25
                                brMin = valuesJson.optInt("min", defMin)
                                brMax = valuesJson.optInt("max", defMax)
                            }
                        }
                        "temp_value_v2", "temp_value" -> {
                            if (tmpCode == null || code == "temp_value_v2") {
                                tmpCode = code
                                val valuesStr = f.optString("values", "{}")
                                val valuesJson = try { JSONObject(valuesStr) } catch (_: Exception) { JSONObject() }
                                val defMax = if (code == "temp_value_v2") 1000 else 255
                                tmpMin = valuesJson.optInt("min", 0)
                                tmpMax = valuesJson.optInt("max", defMax)
                            }
                        }
                    }
                }
                if (colCode != null || brCode != null || functions.length() > 0) {
                    val caps = DeviceCaps(
                        switchCode = swCode,
                        colourCode = colCode,
                        sMax = sMax,
                        vMax = vMax,
                        hasWorkMode = hasWorkMode,
                        brightCode = brCode,
                        brightMin = brMin,
                        brightMax = brMax,
                        tempCode = tmpCode,
                        tempMin = tmpMin,
                        tempMax = tmpMax
                    )
                    deviceCapsMap[devId] = caps
                    return caps
                }
            } catch (_: Exception) {
            }
        }
        return null
    }

    // --- Геттеры состояния LED Strip ---
    fun isLedOn(context: Context): Boolean {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(PREF_LED_IS_ON, true)
    }

    fun getStripHue(context: Context): Int {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(PREF_LED_HUE, 184).coerceIn(0, 360)
    }

    fun getStripSaturationPct(context: Context): Int {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(PREF_LED_SAT, 100).coerceIn(10, 100)
    }

    fun getStripBrightnessPct(context: Context): Int {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(PREF_LED_BRIGHT, 100).coerceIn(10, 100)
    }

    fun getStripModeLabel(context: Context): String {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(PREF_LED_MODE_LABEL, "")?.takeIf { it.isNotBlank() } ?: describeHueName(getStripHue(context))
    }

    // --- Геттеры состояния LED Bulb (LED BULB W5K) ---
    fun isBulbOn(context: Context): Boolean {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(PREF_BULB_IS_ON, true)
    }

    fun getBulbWorkMode(context: Context): String {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(PREF_BULB_WORK_MODE, "white") ?: "white"
    }

    fun isBulbInWhiteMode(context: Context): Boolean = getBulbWorkMode(context) == "white"

    fun getBulbHue(context: Context): Int {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(PREF_BULB_HUE, 184).coerceIn(0, 360)
    }

    fun getBulbSaturationPct(context: Context): Int {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(PREF_BULB_SAT, 100).coerceIn(10, 100)
    }

    fun getBulbBrightnessPct(context: Context): Int {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(PREF_BULB_BRIGHT, 100).coerceIn(10, 100)
    }

    fun getBulbTempPct(context: Context): Int {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(PREF_BULB_TEMP, 50).coerceIn(0, 100)
    }

    fun describeWhiteTempLabel(tempPct: Int): String {
        return when (tempPct.coerceIn(0, 100)) {
            in 0..22 -> "Тёплый 2700K"
            in 23..44 -> "Мягкий 3500K"
            in 45..74 -> "Дневной 4500K"
            else -> "Холодный 6500K"
        }
    }

    fun describeWhiteTempShort(tempPct: Int): String {
        return when (tempPct.coerceIn(0, 100)) {
            in 0..22 -> "Тёплый"
            in 23..44 -> "Мягкий"
            in 45..74 -> "Дневной"
            else -> "Холодный"
        }
    }

    fun getBulbModeLabel(context: Context): String {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        if (isBulbInWhiteMode(context)) {
            return "${describeWhiteTempShort(getBulbTempPct(context))} ${getBulbBrightnessPct(context)}%"
        }
        return prefs.getString(PREF_BULB_MODE_LABEL, "")?.takeIf { it.isNotBlank() } ?: describeHueName(getBulbHue(context))
    }

    fun getBulbPreviewColorInt(context: Context): Int {
        if (isBulbInWhiteMode(context)) {
            val t = getBulbTempPct(context) / 100f
            return if (t <= 0.5f) {
                val f = t / 0.5f
                val r = 253
                val g = (196 + (244 - 196) * f).toInt()
                val b = (108 + (228 - 108) * f).toInt()
                Color.rgb(r, g, b)
            } else {
                val f = (t - 0.5f) / 0.5f
                val r = (253 - (253 - 186) * f).toInt()
                val g = (244 - (244 - 230) * f).toInt()
                val b = (228 + (253 - 228) * f).toInt()
                Color.rgb(r, g, b)
            }
        }
        val h = getBulbHue(context).toFloat()
        val s = (getBulbSaturationPct(context) / 100f).coerceIn(0.25f, 1f)
        return Color.HSVToColor(floatArrayOf(h, s, 0.96f))
    }

    // --- Синхронизация LED Strip + LED Bulb ---
    fun isDevicesLinked(context: Context): Boolean {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(PREF_DEVICES_LINKED, false)
    }

    fun setDevicesLinked(context: Context, linked: Boolean) {
        val appCtx = context.applicationContext
        val prefs = appCtx.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(PREF_DEVICES_LINKED, linked).apply()
        if (linked) {
            // При включении Sync Lights синхронизируем лампу с текущим цветом и яркостью ленты
            val stripOn = isLedOn(appCtx)
            val h = getStripHue(appCtx)
            val s = getStripSaturationPct(appCtx)
            val b = getStripBrightnessPct(appCtx)
            val lbl = getStripModeLabel(appCtx)
            saveBulbState(appCtx, isOn = stripOn, workMode = "colour", hue = h, satPct = s, brightPct = b, modeLabel = lbl)
            if (stripOn) {
                enqueueBulbAction(appCtx, PendingLedAction.ColorHsv(h, s, b))
            } else {
                enqueueBulbAction(appCtx, PendingLedAction.Power(false))
            }
        }
        notifyUi()
    }

    fun toggleDevicesLinked(context: Context): Boolean {
        val next = !isDevicesLinked(context)
        setDevicesLinked(context, next)
        return next
    }

    private fun resolveEffectiveStudioTarget(context: Context): SmartLightTarget {
        return if (isDevicesLinked(context)) SmartLightTarget.BOTH else activeStudioTarget
    }

    fun isStudioShowingBulb(context: Context): Boolean {
        return activeStudioTarget == SmartLightTarget.BULB || activeStudioTarget == SmartLightTarget.BOTH || isDevicesLinked(context)
    }

    fun isStudioInWhiteMode(context: Context): Boolean {
        return isStudioShowingBulb(context) && isBulbInWhiteMode(context)
    }

    fun setStudioBulbWorkMode(context: Context, whiteMode: Boolean) {
        val appCtx = context.applicationContext
        effectCycleJob?.cancel()
        effectCycleJob = null
        if (whiteMode) {
            val bright = getBulbBrightnessPct(appCtx)
            val temp = getBulbTempPct(appCtx)
            saveBulbState(appCtx, isOn = true, workMode = "white")
            enqueueBulbAction(appCtx, PendingLedAction.WhiteCct(bright, temp))
            if (isDevicesLinked(appCtx)) {
                val (stripH, stripS) = approximateWhiteHsvForStrip(temp)
                saveStripState(appCtx, isOn = true, hue = stripH, satPct = stripS, brightPct = bright, modeLabel = describeWhiteTempShort(temp))
                enqueueStripAction(appCtx, PendingLedAction.ColorHsv(stripH, stripS, bright))
            }
        } else {
            val h = getBulbHue(appCtx)
            val s = getBulbSaturationPct(appCtx).coerceAtLeast(80)
            val b = getBulbBrightnessPct(appCtx)
            saveBulbState(appCtx, isOn = true, workMode = "colour", hue = h, satPct = s, modeLabel = describeHueName(h))
            enqueueBulbAction(appCtx, PendingLedAction.ColorHsv(h, s, b))
            if (isDevicesLinked(appCtx)) {
                saveStripState(appCtx, isOn = true, hue = h, satPct = s, brightPct = b, modeLabel = describeHueName(h))
                enqueueStripAction(appCtx, PendingLedAction.ColorHsv(h, s, b))
            }
        }
    }

    private fun approximateWhiteHsvForStrip(tempPct: Int): Pair<Int, Int> {
        val t = tempPct.coerceIn(0, 100)
        return when {
            t <= 30 -> 34 to 28 // Тёплый белый
            t <= 65 -> 42 to 14 // Дневной нейтральный
            else -> 202 to 20   // Холодный белый
        }
    }

    // --- Универсальные геттеры для открытой студии (адаптируются под выбранное устройство STRIP / BULB) ---
    fun getHue(context: Context): Int {
        return if (activeStudioTarget == SmartLightTarget.BULB) getBulbHue(context) else getStripHue(context)
    }

    fun getSaturationPct(context: Context): Int {
        return if (activeStudioTarget == SmartLightTarget.BULB) getBulbSaturationPct(context) else getStripSaturationPct(context)
    }

    fun getBrightnessPct(context: Context): Int {
        return if (activeStudioTarget == SmartLightTarget.BULB) getBulbBrightnessPct(context) else getStripBrightnessPct(context)
    }

    fun isThemeSyncEnabled(context: Context): Boolean {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(PREF_LED_SYNC_THEME, false)
    }

    fun getCurrentModeLabel(context: Context): String {
        return if (activeStudioTarget == SmartLightTarget.BULB) getBulbModeLabel(context) else getStripModeLabel(context)
    }

    fun findActiveSwatchIndex(context: Context): Int {
        if (isStudioInWhiteMode(context)) {
            return if (getBulbTempPct(context) <= 30) CURATED_SWATCHES.indexOfFirst { it.isWarmWhite } else -1
        }
        val mode = getCurrentModeLabel(context)
        if (mode.startsWith("Режим:")) return -1
        val byName = CURATED_SWATCHES.indexOfFirst { it.name.equals(mode, ignoreCase = true) }
        if (byName >= 0) return byName
        val h = getHue(context)
        val s = getSaturationPct(context)
        if (s <= 42 && h in 20..52) {
            return CURATED_SWATCHES.indexOfFirst { it.isWarmWhite }
        }
        var bestIdx = -1
        var bestDist = 999
        for (i in CURATED_SWATCHES.indices) {
            val p = CURATED_SWATCHES[i]
            if (p.isWarmWhite) continue
            val rawDiff = kotlin.math.abs(h - p.hue)
            val dist = kotlin.math.min(rawDiff, 360 - rawDiff)
            if (dist <= 9 && dist < bestDist) {
                bestDist = dist
                bestIdx = i
            }
        }
        return bestIdx
    }

    fun getStripPreviewColorInt(context: Context): Int {
        val mode = getStripModeLabel(context)
        val byName = CURATED_SWATCHES.indexOfFirst { it.name.equals(mode, ignoreCase = true) }
        if (byName in CURATED_SWATCHES.indices) {
            return try {
                Color.parseColor(CURATED_SWATCHES[byName].hexColor)
            } catch (_: Exception) {
                Color.parseColor("#00F0FF")
            }
        }
        val h = getStripHue(context).toFloat()
        val s = (getStripSaturationPct(context) / 100f).coerceIn(0.25f, 1f)
        return Color.HSVToColor(floatArrayOf(h, s, 0.96f))
    }

    fun getCurrentPreviewColorInt(context: Context): Int {
        if (isStudioInWhiteMode(context)) {
            return getBulbPreviewColorInt(context)
        }
        if (activeStudioTarget == SmartLightTarget.BULB) {
            return getBulbPreviewColorInt(context)
        }
        return getStripPreviewColorInt(context)
    }

    fun describeHueName(hue: Int): String {
        val h = ((hue % 360) + 360) % 360
        return when (h) {
            in 0..12 -> "Алый"
            in 13..28 -> "Закат"
            in 29..48 -> "Янтарь"
            in 49..68 -> "Золото"
            in 69..105 -> "Лайм"
            in 106..158 -> "Изумруд"
            in 159..174 -> "Мята"
            in 175..194 -> "Кибер"
            in 195..214 -> "Океан"
            in 215..236 -> "Сапфир"
            in 237..264 -> "Индиго"
            in 265..298 -> "Фиолет"
            in 299..338 -> "Фуксия"
            else -> "Малина"
        }
    }

    @Volatile
    private var lastSnapshotSavedMs: Long = 0L

    private fun snapshotLightsBeforeChange(context: Context) {
        val now = System.currentTimeMillis()
        if (now - lastSnapshotSavedMs < 1500L) return
        lastSnapshotSavedMs = now
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit()
            .putBoolean("prev_strip_on", isLedOn(context))
            .putInt("prev_strip_hue", getStripHue(context))
            .putInt("prev_strip_sat", getStripSaturationPct(context))
            .putInt("prev_strip_bright", getStripBrightnessPct(context))
            .putBoolean("prev_bulb_on", isBulbOn(context))
            .putString("prev_bulb_mode", getBulbWorkMode(context))
            .putInt("prev_bulb_hue", getBulbHue(context))
            .putInt("prev_bulb_sat", getBulbSaturationPct(context))
            .putInt("prev_bulb_bright", getBulbBrightnessPct(context))
            .putInt("prev_bulb_temp", getBulbTempPct(context))
            .putBoolean("prev_lights_valid", true)
            .apply()
    }

    fun restorePreviousLightsState(context: Context) {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        if (!prefs.getBoolean("prev_lights_valid", false)) return
        val sOn = prefs.getBoolean("prev_strip_on", true)
        val sHue = prefs.getInt("prev_strip_hue", 184)
        val sSat = prefs.getInt("prev_strip_sat", 100)
        val sBri = prefs.getInt("prev_strip_bright", 80)
        val bOn = prefs.getBoolean("prev_bulb_on", true)
        val bMode = prefs.getString("prev_bulb_mode", "colour") ?: "colour"
        val bHue = prefs.getInt("prev_bulb_hue", 184)
        val bSat = prefs.getInt("prev_bulb_sat", 100)
        val bBri = prefs.getInt("prev_bulb_bright", 80)
        val bTmp = prefs.getInt("prev_bulb_temp", 50)

        lastSnapshotSavedMs = System.currentTimeMillis()
        if (!sOn) {
            setStripPower(context, false, respectLink = false)
        } else {
            saveStripState(context, isOn = true, hue = sHue, satPct = sSat, brightPct = sBri, modeLabel = "Режим: Восстановлен")
            enqueueStripAction(context, PendingLedAction.ColorHsv(sHue, sSat, sBri))
        }
        if (!bOn) {
            setBulbPower(context, false, respectLink = false)
        } else if (bMode == "white") {
            saveBulbState(context, isOn = true, workMode = "white", brightPct = bBri, tempPct = bTmp, modeLabel = "Режим: Белый ${describeWhiteTempShort(bTmp)}")
            enqueueBulbAction(context, PendingLedAction.WhiteCct(bBri, bTmp))
        } else {
            saveBulbState(context, isOn = true, workMode = "colour", hue = bHue, satPct = bSat, brightPct = bBri, modeLabel = "Режим: Восстановлен")
            enqueueBulbAction(context, PendingLedAction.ColorHsv(bHue, bSat, bBri))
        }
    }

    private fun saveStripState(
        context: Context,
        isOn: Boolean? = null,
        hue: Int? = null,
        satPct: Int? = null,
        brightPct: Int? = null,
        syncTheme: Boolean? = null,
        modeLabel: String? = null
    ) {
        snapshotLightsBeforeChange(context)
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val ed = prefs.edit()
        if (isOn != null) ed.putBoolean(PREF_LED_IS_ON, isOn)
        if (hue != null) ed.putInt(PREF_LED_HUE, ((hue % 360) + 360) % 360)
        if (satPct != null) ed.putInt(PREF_LED_SAT, satPct.coerceIn(10, 100))
        if (brightPct != null) ed.putInt(PREF_LED_BRIGHT, brightPct.coerceIn(10, 100))
        if (syncTheme != null) ed.putBoolean(PREF_LED_SYNC_THEME, syncTheme)
        if (modeLabel != null) ed.putString(PREF_LED_MODE_LABEL, modeLabel)
        ed.apply()
        notifyUi()
    }

    private fun saveBulbState(
        context: Context,
        isOn: Boolean? = null,
        workMode: String? = null,
        hue: Int? = null,
        satPct: Int? = null,
        brightPct: Int? = null,
        tempPct: Int? = null,
        modeLabel: String? = null
    ) {
        snapshotLightsBeforeChange(context)
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val ed = prefs.edit()
        if (isOn != null) ed.putBoolean(PREF_BULB_IS_ON, isOn)
        if (workMode != null) ed.putString(PREF_BULB_WORK_MODE, workMode)
        if (hue != null) ed.putInt(PREF_BULB_HUE, ((hue % 360) + 360) % 360)
        if (satPct != null) ed.putInt(PREF_BULB_SAT, satPct.coerceIn(10, 100))
        if (brightPct != null) ed.putInt(PREF_BULB_BRIGHT, brightPct.coerceIn(10, 100))
        if (tempPct != null) ed.putInt(PREF_BULB_TEMP, tempPct.coerceIn(0, 100))
        if (modeLabel != null) ed.putString(PREF_BULB_MODE_LABEL, modeLabel)
        ed.apply()
        notifyUi()
    }

    private fun enqueueStripAction(context: Context, action: PendingLedAction) {
        enqueueDeviceAction(context, isBulb = false, action = action)
    }

    private fun enqueueBulbAction(context: Context, action: PendingLedAction) {
        enqueueDeviceAction(context, isBulb = true, action = action)
    }

    private fun enqueueDeviceAction(context: Context, isBulb: Boolean, action: PendingLedAction) {
        val appCtx = context.applicationContext
        loadCachedRoutingPrefsIfNeeded(appCtx)
        lastUserCommandWallMs = System.currentTimeMillis()
        var shouldLaunchWorker = false
        synchronized(queueLock) {
            if (isBulb) {
                pendingBulbAction = action
            } else {
                pendingStripAction = action
            }
            if (!isQueueWorkerRunning) {
                isQueueWorkerRunning = true
                shouldLaunchWorker = true
            }
        }
        if (shouldLaunchWorker) {
            ioScope.launch {
                try {
                    while (true) {
                        var nextStrip: PendingLedAction? = null
                        var nextBulb: PendingLedAction? = null
                        synchronized(queueLock) {
                            nextStrip = pendingStripAction
                            nextBulb = pendingBulbAction
                            pendingStripAction = null
                            pendingBulbAction = null
                            if (nextStrip == null && nextBulb == null) {
                                isQueueWorkerRunning = false
                            }
                        }
                        if (nextStrip == null && nextBulb == null) break

                        val sAct = nextStrip
                        val bAct = nextBulb
                        if (sAct != null && bAct != null) {
                            val job1 = async { executeSingleDeviceAction(appCtx, LauncherConfig.TUYA_LED_DEVICE_ID, sAct) }
                            val job2 = async { executeSingleDeviceAction(appCtx, LauncherConfig.TUYA_BULB_DEVICE_ID, bAct) }
                            job1.await()
                            job2.await()
                        } else if (sAct != null) {
                            executeSingleDeviceAction(appCtx, LauncherConfig.TUYA_LED_DEVICE_ID, sAct)
                        } else if (bAct != null) {
                            executeSingleDeviceAction(appCtx, LauncherConfig.TUYA_BULB_DEVICE_ID, bAct)
                        }
                    }
                } finally {
                    synchronized(queueLock) {
                        isQueueWorkerRunning = false
                    }
                }
            }
        }
    }

    private suspend fun executeSingleDeviceAction(context: Context, devId: String, action: PendingLedAction) {
        when (action) {
            is PendingLedAction.Power -> sendSwitchCommandForDevice(context, devId, action.turnOn)
            is PendingLedAction.ColorHsv -> sendHsvColorCommandForDevice(context, devId, action.hue, action.satPct, action.brightPct)
            is PendingLedAction.WhiteCct -> sendWhiteCommandForDevice(context, devId, action.brightPct, action.tempPct)
        }
    }

    fun setThemeSyncEnabled(context: Context, enabled: Boolean, currentThemeHex: String? = null) {
        saveStripState(context, syncTheme = enabled)
        if (enabled && !currentThemeHex.isNullOrBlank()) {
            setHexColor(context, currentThemeHex, modeTitle = "Синхр. с темой")
        }
    }

    fun syncWithLauncherThemeIfNeeded(context: Context, hexColor: String) {
        if (isThemeSyncEnabled(context)) {
            setHexColor(context, hexColor, modeTitle = "Синхр. с темой")
        }
    }

    // --- Управление питанием LED Strip, LED Bulb и обоих устройств ---
    fun togglePower(context: Context): Boolean {
        return toggleStripPower(context)
    }

    fun toggleStripPower(context: Context): Boolean {
        val target = !isLedOn(context)
        setStripPower(context, target, respectLink = true)
        return target
    }

    fun toggleBulbPower(context: Context): Boolean {
        val target = !isBulbOn(context)
        setBulbPower(context, target, respectLink = true)
        return target
    }

    fun setPower(context: Context, turnOn: Boolean) {
        setStripPower(context, turnOn, respectLink = true)
    }

    fun setStripPower(context: Context, turnOn: Boolean, respectLink: Boolean = false) {
        val appCtx = context.applicationContext
        if (!turnOn) {
            effectCycleJob?.cancel()
            effectCycleJob = null
        }
        saveStripState(appCtx, isOn = turnOn)
        enqueueStripAction(appCtx, PendingLedAction.Power(turnOn))
        if (respectLink && isDevicesLinked(appCtx)) {
            saveBulbState(appCtx, isOn = turnOn)
            enqueueBulbAction(appCtx, PendingLedAction.Power(turnOn))
        }
    }

    fun setBulbPower(context: Context, turnOn: Boolean, respectLink: Boolean = false) {
        val appCtx = context.applicationContext
        saveBulbState(appCtx, isOn = turnOn)
        enqueueBulbAction(appCtx, PendingLedAction.Power(turnOn))
        if (respectLink && isDevicesLinked(appCtx)) {
            if (!turnOn) {
                effectCycleJob?.cancel()
                effectCycleJob = null
            }
            saveStripState(appCtx, isOn = turnOn)
            enqueueStripAction(appCtx, PendingLedAction.Power(turnOn))
        }
    }

    fun setAllLightsPower(context: Context, turnOn: Boolean) {
        val appCtx = context.applicationContext
        if (!turnOn) {
            effectCycleJob?.cancel()
            effectCycleJob = null
        }
        saveStripState(appCtx, isOn = turnOn)
        saveBulbState(appCtx, isOn = turnOn)
        enqueueStripAction(appCtx, PendingLedAction.Power(turnOn))
        enqueueBulbAction(appCtx, PendingLedAction.Power(turnOn))
    }

    // --- Управление режимами White / Color специально для LED Bulb (и голоса) ---
    fun setBulbWhitePreset(context: Context, tempSpec: String, brightOverride: Int? = null) {
        val appCtx = context.applicationContext
        val upper = tempSpec.trim().uppercase(Locale.US)
        val tempPct = when {
            upper.contains("WARM") || upper.contains("ТЕПЛ") || upper.contains("ТЁПЛ") || upper.contains("УЮТ") -> 12
            upper.contains("SOFT") || upper.contains("МЯГК") -> 30
            upper.contains("COOL") || upper.contains("ХОЛОД") || upper.contains("ЛЕД") -> 95
            upper.contains("NEUTRAL") || upper.contains("DAY") || upper.contains("ДНЕВ") || upper.contains("НЕЙТР") || upper.contains("БЕЛ") -> 55
            else -> upper.toIntOrNull()?.coerceIn(0, 100) ?: 55
        }
        val bright = (brightOverride ?: getBulbBrightnessPct(appCtx)).coerceIn(10, 100)
        saveBulbState(appCtx, isOn = true, workMode = "white", brightPct = bright, tempPct = tempPct)
        enqueueBulbAction(appCtx, PendingLedAction.WhiteCct(bright, tempPct))
        if (isDevicesLinked(appCtx)) {
            val (stripH, stripS) = approximateWhiteHsvForStrip(tempPct)
            saveStripState(appCtx, isOn = true, hue = stripH, satPct = stripS, brightPct = bright, modeLabel = describeWhiteTempShort(tempPct))
            enqueueStripAction(appCtx, PendingLedAction.ColorHsv(stripH, stripS, bright))
        }
    }

    fun setBulbHexColor(context: Context, rawHex: String, respectLink: Boolean = true) {
        val appCtx = context.applicationContext
        val cleanHex = if (rawHex.trim().startsWith("#")) rawHex.trim() else "#${rawHex.trim()}"
        val parsedColor = try {
            Color.parseColor(cleanHex)
        } catch (_: Exception) {
            Color.parseColor("#00F0FF")
        }
        val hsv = FloatArray(3)
        Color.colorToHSV(parsedColor, hsv)
        val h = hsv[0].toInt().coerceIn(0, 360)
        val s = (hsv[1] * 100f).toInt().coerceIn(15, 100)
        val b = getBulbBrightnessPct(appCtx).coerceAtLeast(30)
        val label = describeHueName(h)
        saveBulbState(appCtx, isOn = true, workMode = "colour", hue = h, satPct = s, brightPct = b, modeLabel = label)
        enqueueBulbAction(appCtx, PendingLedAction.ColorHsv(h, s, b))
        if (respectLink && isDevicesLinked(appCtx)) {
            saveStripState(appCtx, isOn = true, hue = h, satPct = s, brightPct = b, modeLabel = label)
            enqueueStripAction(appCtx, PendingLedAction.ColorHsv(h, s, b))
        }
    }

    fun setBulbBrightnessPercent(context: Context, pct: Int, respectLink: Boolean = true) {
        val appCtx = context.applicationContext
        val cleanPct = pct.coerceIn(10, 100)
        if (isBulbInWhiteMode(appCtx)) {
            val temp = getBulbTempPct(appCtx)
            saveBulbState(appCtx, isOn = true, brightPct = cleanPct)
            enqueueBulbAction(appCtx, PendingLedAction.WhiteCct(cleanPct, temp))
        } else {
            val h = getBulbHue(appCtx)
            val s = getBulbSaturationPct(appCtx)
            saveBulbState(appCtx, isOn = true, brightPct = cleanPct)
            enqueueBulbAction(appCtx, PendingLedAction.ColorHsv(h, s, cleanPct))
        }
        if (respectLink && isDevicesLinked(appCtx)) {
            val sh = getStripHue(appCtx)
            val ss = getStripSaturationPct(appCtx)
            saveStripState(appCtx, isOn = true, brightPct = cleanPct)
            enqueueStripAction(appCtx, PendingLedAction.ColorHsv(sh, ss, cleanPct))
        }
    }

    fun setAllLightsHexColor(context: Context, rawHex: String) {
        val appCtx = context.applicationContext
        effectCycleJob?.cancel()
        effectCycleJob = null
        val cleanHex = if (rawHex.trim().startsWith("#")) rawHex.trim() else "#${rawHex.trim()}"
        val parsedColor = try {
            Color.parseColor(cleanHex)
        } catch (_: Exception) {
            Color.parseColor("#00F0FF")
        }
        val hsv = FloatArray(3)
        Color.colorToHSV(parsedColor, hsv)
        val h = hsv[0].toInt().coerceIn(0, 360)
        val s = (hsv[1] * 100f).toInt().coerceIn(15, 100)
        val bStrip = getStripBrightnessPct(appCtx).coerceAtLeast(30)
        val bBulb = getBulbBrightnessPct(appCtx).coerceAtLeast(30)
        val label = describeHueName(h)
        saveStripState(appCtx, isOn = true, hue = h, satPct = s, brightPct = bStrip, modeLabel = label)
        saveBulbState(appCtx, isOn = true, workMode = "colour", hue = h, satPct = s, brightPct = bBulb, modeLabel = label)
        enqueueStripAction(appCtx, PendingLedAction.ColorHsv(h, s, bStrip))
        enqueueBulbAction(appCtx, PendingLedAction.ColorHsv(h, s, bBulb))
    }

    fun setAllLightsBrightnessPercent(context: Context, pct: Int) {
        setBrightnessPercent(context, pct)
        setBulbBrightnessPercent(context, pct, respectLink = false)
    }

    // --- Методы студийной настройки (работают в едином капсульном стиле для LED Strip, LED Bulb и Sync Lights) ---
    fun stepHueByDelta(context: Context, deltaDeg: Int, immediate: Boolean = false) {
        val appCtx = context.applicationContext
        effectCycleJob?.cancel()
        effectCycleJob = null

        // Если в студии открыт режим White для лампочки — ползунок спектра управляет цветовой температурой (Тёплый ↔ Холодный)!
        if (isStudioInWhiteMode(appCtx)) {
            val stepPct = if (immediate) 25 else (deltaDeg * 12 / 10).coerceIn(-15, 15)
            val curTemp = getBulbTempPct(appCtx)
            val nextTemp = if (immediate && curTemp >= 95) 0 else (curTemp + stepPct).coerceIn(0, 100)
            val bright = getBulbBrightnessPct(appCtx)
            saveBulbState(appCtx, isOn = true, workMode = "white", tempPct = nextTemp)
            enqueueBulbAction(appCtx, PendingLedAction.WhiteCct(bright, nextTemp))
            if (isDevicesLinked(appCtx)) {
                val (stripH, stripS) = approximateWhiteHsvForStrip(nextTemp)
                saveStripState(appCtx, isOn = true, hue = stripH, satPct = stripS, brightPct = bright, modeLabel = describeWhiteTempShort(nextTemp))
                enqueueStripAction(appCtx, PendingLedAction.ColorHsv(stripH, stripS, bright))
            }
            return
        }

        val target = resolveEffectiveStudioTarget(appCtx)
        val baseHue = if (target == SmartLightTarget.BULB) getBulbHue(appCtx) else getStripHue(appCtx)
        val nextHue = (((baseHue + deltaDeg) % 360) + 360) % 360
        val label = describeHueName(nextHue)

        if (target == SmartLightTarget.STRIP || target == SmartLightTarget.BOTH) {
            val sat = getStripSaturationPct(appCtx).coerceAtLeast(85)
            val bright = getStripBrightnessPct(appCtx)
            saveStripState(appCtx, isOn = true, hue = nextHue, satPct = sat, modeLabel = label)
            enqueueStripAction(appCtx, PendingLedAction.ColorHsv(nextHue, sat, bright))
        }
        if (target == SmartLightTarget.BULB || target == SmartLightTarget.BOTH) {
            val sat = getBulbSaturationPct(appCtx).coerceAtLeast(85)
            val bright = getBulbBrightnessPct(appCtx)
            saveBulbState(appCtx, isOn = true, workMode = "colour", hue = nextHue, satPct = sat, modeLabel = label)
            enqueueBulbAction(appCtx, PendingLedAction.ColorHsv(nextHue, sat, bright))
        }
    }

    fun stepBrightnessByDelta(context: Context, deltaPct: Int) {
        val appCtx = context.applicationContext
        if (isStudioInWhiteMode(appCtx)) {
            val nextBright = (getBulbBrightnessPct(appCtx) + deltaPct).coerceIn(10, 100)
            val temp = getBulbTempPct(appCtx)
            saveBulbState(appCtx, isOn = true, workMode = "white", brightPct = nextBright)
            enqueueBulbAction(appCtx, PendingLedAction.WhiteCct(nextBright, temp))
            if (isDevicesLinked(appCtx)) {
                val (stripH, stripS) = approximateWhiteHsvForStrip(temp)
                saveStripState(appCtx, isOn = true, brightPct = nextBright)
                enqueueStripAction(appCtx, PendingLedAction.ColorHsv(stripH, stripS, nextBright))
            }
            return
        }

        val target = resolveEffectiveStudioTarget(appCtx)
        if (target == SmartLightTarget.STRIP || target == SmartLightTarget.BOTH) {
            val nextBright = (getStripBrightnessPct(appCtx) + deltaPct).coerceIn(10, 100)
            val hue = getStripHue(appCtx)
            val sat = getStripSaturationPct(appCtx)
            saveStripState(appCtx, isOn = true, brightPct = nextBright)
            enqueueStripAction(appCtx, PendingLedAction.ColorHsv(hue, sat, nextBright))
        }
        if (target == SmartLightTarget.BULB || target == SmartLightTarget.BOTH) {
            val nextBright = (getBulbBrightnessPct(appCtx) + deltaPct).coerceIn(10, 100)
            val hue = getBulbHue(appCtx)
            val sat = getBulbSaturationPct(appCtx)
            saveBulbState(appCtx, isOn = true, brightPct = nextBright)
            enqueueBulbAction(appCtx, PendingLedAction.ColorHsv(hue, sat, nextBright))
        }
    }

    fun cycleBrightnessPreset(context: Context): Int {
        val cur = getBrightnessPct(context)
        val next = when {
            cur < 25 -> 25
            cur < 50 -> 50
            cur < 75 -> 75
            cur < 100 -> 100
            else -> 25
        }
        if (isStudioInWhiteMode(context)) {
            setBulbBrightnessPercent(context, next, respectLink = true)
            return next
        }
        val target = resolveEffectiveStudioTarget(context)
        if (target == SmartLightTarget.BULB) {
            setBulbBrightnessPercent(context, next, respectLink = true)
        } else {
            setBrightnessPercent(context, next)
        }
        return next
    }

    fun setBrightnessPercent(context: Context, pct: Int) {
        val appCtx = context.applicationContext
        val cleanPct = pct.coerceIn(5, 100)
        val hue = getStripHue(appCtx)
        val sat = getStripSaturationPct(appCtx)
        saveStripState(appCtx, isOn = true, brightPct = cleanPct)
        enqueueStripAction(appCtx, PendingLedAction.ColorHsv(hue, sat, cleanPct))
        if (isDevicesLinked(appCtx)) {
            setBulbBrightnessPercent(appCtx, cleanPct, respectLink = false)
        }
    }

    fun stepSaturationByDelta(context: Context, deltaPct: Int) {
        val appCtx = context.applicationContext
        effectCycleJob?.cancel()
        effectCycleJob = null
        if (isStudioInWhiteMode(appCtx)) {
            // В режиме White вторая капсула плавно переключает температуру белого (Тёплый ↔ Дневной ↔ Холодный)
            val nextTemp = (getBulbTempPct(appCtx) + deltaPct).coerceIn(0, 100)
            val bright = getBulbBrightnessPct(appCtx)
            saveBulbState(appCtx, isOn = true, workMode = "white", tempPct = nextTemp)
            enqueueBulbAction(appCtx, PendingLedAction.WhiteCct(bright, nextTemp))
            if (isDevicesLinked(appCtx)) {
                val (stripH, stripS) = approximateWhiteHsvForStrip(nextTemp)
                saveStripState(appCtx, isOn = true, hue = stripH, satPct = stripS, brightPct = bright, modeLabel = describeWhiteTempShort(nextTemp))
                enqueueStripAction(appCtx, PendingLedAction.ColorHsv(stripH, stripS, bright))
            }
            return
        }

        val target = resolveEffectiveStudioTarget(appCtx)
        if (target == SmartLightTarget.STRIP || target == SmartLightTarget.BOTH) {
            val nextSat = (getStripSaturationPct(appCtx) + deltaPct).coerceIn(15, 100)
            val hue = getStripHue(appCtx)
            val bright = getStripBrightnessPct(appCtx)
            saveStripState(appCtx, isOn = true, satPct = nextSat)
            enqueueStripAction(appCtx, PendingLedAction.ColorHsv(hue, nextSat, bright))
        }
        if (target == SmartLightTarget.BULB || target == SmartLightTarget.BOTH) {
            val nextSat = (getBulbSaturationPct(appCtx) + deltaPct).coerceIn(15, 100)
            val hue = getBulbHue(appCtx)
            val bright = getBulbBrightnessPct(appCtx)
            saveBulbState(appCtx, isOn = true, workMode = "colour", satPct = nextSat)
            enqueueBulbAction(appCtx, PendingLedAction.ColorHsv(hue, nextSat, bright))
        }
    }

    fun cycleSaturationPreset(context: Context): Int {
        val appCtx = context.applicationContext
        if (isStudioInWhiteMode(appCtx)) {
            val curTemp = getBulbTempPct(appCtx)
            val nextTemp = when {
                curTemp < 22 -> 35
                curTemp < 50 -> 60
                curTemp < 85 -> 100
                else -> 10
            }
            val bright = getBulbBrightnessPct(appCtx)
            saveBulbState(appCtx, isOn = true, workMode = "white", tempPct = nextTemp)
            enqueueBulbAction(appCtx, PendingLedAction.WhiteCct(bright, nextTemp))
            if (isDevicesLinked(appCtx)) {
                val (stripH, stripS) = approximateWhiteHsvForStrip(nextTemp)
                saveStripState(appCtx, isOn = true, hue = stripH, satPct = stripS, brightPct = bright, modeLabel = describeWhiteTempShort(nextTemp))
                enqueueStripAction(appCtx, PendingLedAction.ColorHsv(stripH, stripS, bright))
            }
            return nextTemp
        }

        val cur = getSaturationPct(appCtx)
        val next = when {
            cur < 45 -> 60
            cur < 80 -> 100
            else -> 30
        }
        val target = resolveEffectiveStudioTarget(appCtx)
        if (target == SmartLightTarget.STRIP || target == SmartLightTarget.BOTH) {
            val hue = getStripHue(appCtx)
            val bright = getStripBrightnessPct(appCtx)
            saveStripState(appCtx, isOn = true, satPct = next)
            enqueueStripAction(appCtx, PendingLedAction.ColorHsv(hue, next, bright))
        }
        if (target == SmartLightTarget.BULB || target == SmartLightTarget.BOTH) {
            val hue = getBulbHue(appCtx)
            val bright = getBulbBrightnessPct(appCtx)
            saveBulbState(appCtx, isOn = true, workMode = "colour", satPct = next)
            enqueueBulbAction(appCtx, PendingLedAction.ColorHsv(hue, next, bright))
        }
        return next
    }

    fun applySwatchPreset(context: Context, preset: LedSwatchPreset) {
        val appCtx = context.applicationContext
        effectCycleJob?.cancel()
        effectCycleJob = null
        val target = resolveEffectiveStudioTarget(appCtx)

        if (target == SmartLightTarget.STRIP || target == SmartLightTarget.BOTH) {
            val bright = getStripBrightnessPct(appCtx).coerceAtLeast(25)
            saveStripState(
                appCtx,
                isOn = true,
                hue = preset.hue,
                satPct = preset.satPct,
                brightPct = bright,
                modeLabel = preset.name
            )
            enqueueStripAction(appCtx, PendingLedAction.ColorHsv(preset.hue, preset.satPct, bright))
        }
        if (target == SmartLightTarget.BULB || target == SmartLightTarget.BOTH) {
            val bright = getBulbBrightnessPct(appCtx).coerceAtLeast(25)
            if (preset.isWarmWhite) {
                saveBulbState(appCtx, isOn = true, workMode = "white", brightPct = bright, tempPct = 15, modeLabel = preset.name)
                enqueueBulbAction(appCtx, PendingLedAction.WhiteCct(bright, 15))
            } else {
                saveBulbState(
                    appCtx,
                    isOn = true,
                    workMode = "colour",
                    hue = preset.hue,
                    satPct = preset.satPct,
                    brightPct = bright,
                    modeLabel = preset.name
                )
                enqueueBulbAction(appCtx, PendingLedAction.ColorHsv(preset.hue, preset.satPct, bright))
            }
        }
    }

    fun setHexColor(context: Context, rawHex: String, modeTitle: String? = null) {
        val appCtx = context.applicationContext
        effectCycleJob?.cancel()
        effectCycleJob = null
        val cleanHex = if (rawHex.trim().startsWith("#")) rawHex.trim() else "#${rawHex.trim()}"
        val parsedColor = try {
            Color.parseColor(cleanHex)
        } catch (_: Exception) {
            Color.parseColor("#00F0FF")
        }
        val hsv = FloatArray(3)
        Color.colorToHSV(parsedColor, hsv)
        val h = hsv[0].toInt().coerceIn(0, 360)
        val s = (hsv[1] * 100f).toInt().coerceIn(15, 100)
        val b = getStripBrightnessPct(appCtx).coerceAtLeast(30)
        val label = modeTitle ?: describeHueName(h)
        saveStripState(appCtx, isOn = true, hue = h, satPct = s, brightPct = b, modeLabel = label)
        enqueueStripAction(appCtx, PendingLedAction.ColorHsv(h, s, b))
        if (isDevicesLinked(appCtx)) {
            val bBulb = getBulbBrightnessPct(appCtx).coerceAtLeast(30)
            saveBulbState(appCtx, isOn = true, workMode = "colour", hue = h, satPct = s, brightPct = bBulb, modeLabel = label)
            enqueueBulbAction(appCtx, PendingLedAction.ColorHsv(h, s, bBulb))
        }
    }

    fun activateDynamicScene(context: Context, sceneCode: String) {
        val appCtx = context.applicationContext
        loadCachedRoutingPrefsIfNeeded(appCtx)
        lastUserCommandWallMs = System.currentTimeMillis()
        effectCycleJob?.cancel()
        effectCycleJob = null

        val target = resolveEffectiveStudioTarget(appCtx)
        val upper = sceneCode.trim().uppercase(Locale.US)
        when {
            upper.contains("AMBI") || upper.contains("АМБИ") || upper.contains("МУЗЫК") || upper.contains("MUSIC") || upper.contains("SPOTIFY") -> {
                if (target == SmartLightTarget.STRIP || target == SmartLightTarget.BOTH) {
                    saveStripState(appCtx, isOn = true, modeLabel = "Режим: Амбилайн")
                }
                if (target == SmartLightTarget.BULB || target == SmartLightTarget.BOTH) {
                    saveBulbState(appCtx, isOn = true, workMode = "colour", modeLabel = "Режим: Амбилайн")
                }
                startSoftwareSceneLoop(appCtx, "AMBILINE", target)
            }
            upper.contains("NIGHT") || upper.contains("НОЧ") -> {
                if (target == SmartLightTarget.STRIP || target == SmartLightTarget.BOTH) {
                    saveStripState(appCtx, isOn = true, hue = 30, satPct = 85, brightPct = 15, modeLabel = "Режим: Ночник")
                    enqueueStripAction(appCtx, PendingLedAction.ColorHsv(30, 85, 15))
                }
                if (target == SmartLightTarget.BULB || target == SmartLightTarget.BOTH) {
                    saveBulbState(appCtx, isOn = true, workMode = "white", brightPct = 12, tempPct = 5, modeLabel = "Режим: Ночник")
                    enqueueBulbAction(appCtx, PendingLedAction.WhiteCct(12, 5))
                }
            }
            upper.contains("BREATH") || upper.contains("ДЫХ") -> {
                if (target == SmartLightTarget.STRIP || target == SmartLightTarget.BOTH) {
                    saveStripState(appCtx, isOn = true, modeLabel = "Режим: Дыхание")
                }
                if (target == SmartLightTarget.BULB || target == SmartLightTarget.BOTH) {
                    saveBulbState(appCtx, isOn = true, workMode = "colour", modeLabel = "Режим: Дыхание")
                }
                startSoftwareSceneLoop(appCtx, "BREATHE", target)
            }
            upper.contains("PARTY") || upper.contains("ВЕЧЕР") -> {
                if (target == SmartLightTarget.STRIP || target == SmartLightTarget.BOTH) {
                    saveStripState(appCtx, isOn = true, modeLabel = "Режим: Вечеринка")
                }
                if (target == SmartLightTarget.BULB || target == SmartLightTarget.BOTH) {
                    saveBulbState(appCtx, isOn = true, workMode = "colour", modeLabel = "Режим: Вечеринка")
                }
                startSoftwareSceneLoop(appCtx, "PARTY", target)
            }
            else -> {
                if (target == SmartLightTarget.STRIP || target == SmartLightTarget.BOTH) {
                    saveStripState(appCtx, isOn = true, modeLabel = "Режим: Радуга")
                }
                if (target == SmartLightTarget.BULB || target == SmartLightTarget.BOTH) {
                    saveBulbState(appCtx, isOn = true, workMode = "colour", modeLabel = "Режим: Радуга")
                }
                startSoftwareSceneLoop(appCtx, "RAINBOW", target)
            }
        }
    }

    private fun extractDominantCoverHsv(bmp: android.graphics.Bitmap?): Pair<Int, Int>? {
        NativeCore.extractDominantCoverHsv(bmp)?.let { return it }
        if (bmp == null || bmp.isRecycled || bmp.width <= 0 || bmp.height <= 0) return null
        try {
            val bucketWeights = FloatArray(36)
            val bucketHueSum = FloatArray(36)
            val bucketSatSum = FloatArray(36)
            val hsv = FloatArray(3)
            val w = bmp.width
            val h = bmp.height
            val stepX = (w / 20).coerceAtLeast(1)
            val stepY = (h / 20).coerceAtLeast(1)
            var y = stepY / 2
            while (y < h) {
                var x = stepX / 2
                while (x < w) {
                    val px = bmp.getPixel(x, y)
                    val a = Color.alpha(px)
                    if (a > 140) {
                        Color.colorToHSV(px, hsv)
                        val deg = hsv[0]
                        val sat = hsv[1]
                        val bri = hsv[2]
                        if (bri > 0.18f && sat > 0.24f) {
                            val bucket = ((deg.toInt() % 360) / 10).coerceIn(0, 35)
                            val skinPenalty = if (deg in 14f..44f && sat < 0.68f) 0.22f else 1.0f
                            val weight = (sat * sat * sat * bri) * skinPenalty
                            bucketWeights[bucket] += weight
                            bucketHueSum[bucket] += deg * weight
                            bucketSatSum[bucket] += sat * weight
                        }
                    }
                    x += stepX
                }
                y += stepY
            }
            var bestBucket = -1
            var bestWeight = 0f
            for (i in 0 until 36) {
                if (bucketWeights[i] > bestWeight) {
                    bestWeight = bucketWeights[i]
                    bestBucket = i
                }
            }
            if (bestBucket >= 0 && bestWeight > 0.02f) {
                val rawHue = (bucketHueSum[bestBucket] / bestWeight).toInt().coerceIn(0, 360)
                val avgSat = (bucketSatSum[bestBucket] / bestWeight).coerceIn(0.75f, 1.0f)
                return rawHue to (avgSat * 100f).toInt().coerceIn(80, 100)
            }
            return 195 to 60
        } catch (_: Exception) {
            return null
        }
    }

    private fun dispatchSceneHsv(context: Context, target: SmartLightTarget, h: Int, s: Int, b: Int) {
        val eff = if (isDevicesLinked(context)) SmartLightTarget.BOTH else target
        if (eff == SmartLightTarget.STRIP || eff == SmartLightTarget.BOTH) {
            enqueueStripAction(context, PendingLedAction.ColorHsv(h, s, b))
        }
        if (eff == SmartLightTarget.BULB || eff == SmartLightTarget.BOTH) {
            enqueueBulbAction(context, PendingLedAction.ColorHsv(h, s, b))
        }
    }

    private fun startSoftwareSceneLoop(context: Context, mode: String, initialTarget: SmartLightTarget) {
        effectCycleJob?.cancel()
        effectCycleJob = ioScope.launch {
            var step = 0
            var lastAmbilineSig = 0
            var lastAmbilineHue = -1
            while (isActive && (isLedOn(context) || isBulbOn(context))) {
                val effTarget = if (isDevicesLinked(context)) SmartLightTarget.BOTH else initialTarget
                when (mode) {
                    "AMBILINE" -> {
                        try {
                            com.mitv.customlauncher.service.MediaStateBus.pollActiveControllerLight(context)
                        } catch (_: Exception) {
                        }
                        val snap = com.mitv.customlauncher.service.MediaStateBus.state.value
                        val bmp = snap.coverBitmap
                        val sig = if (bmp != null && !bmp.isRecycled) bmp.generationId else 0
                        if (bmp != null && sig != 0 && sig != lastAmbilineSig) {
                            val extracted = extractDominantCoverHsv(bmp)
                            if (extracted != null) {
                                lastAmbilineSig = sig
                                val (targetHue, targetSat) = extracted
                                val curBright = getBrightnessPct(context).coerceAtLeast(45)
                                if (kotlin.math.abs(targetHue - lastAmbilineHue) >= 5 || lastAmbilineHue == -1) {
                                    lastAmbilineHue = targetHue
                                    if (effTarget == SmartLightTarget.STRIP || effTarget == SmartLightTarget.BOTH) {
                                        saveStripState(
                                            context,
                                            isOn = true,
                                            hue = targetHue,
                                            satPct = targetSat,
                                            brightPct = curBright,
                                            modeLabel = "Режим: Амбилайн"
                                        )
                                    }
                                    if (effTarget == SmartLightTarget.BULB || effTarget == SmartLightTarget.BOTH) {
                                        saveBulbState(
                                            context,
                                            isOn = true,
                                            workMode = "colour",
                                            hue = targetHue,
                                            satPct = targetSat,
                                            brightPct = curBright,
                                            modeLabel = "Режим: Амбилайн"
                                        )
                                    }
                                    dispatchSceneHsv(context, effTarget, targetHue, targetSat, curBright)
                                }
                            }
                        } else if (step == 0 && lastAmbilineHue == -1) {
                            val curH = getHue(context)
                            val curS = getSaturationPct(context).coerceAtLeast(80)
                            val curB = getBrightnessPct(context).coerceAtLeast(45)
                            lastAmbilineHue = curH
                            dispatchSceneHsv(context, effTarget, curH, curS, curB)
                        }
                        delay(1100L)
                    }
                    "BREATHE" -> {
                        val h = getHue(context)
                        val b = if (step % 2 == 0) 95 else 22
                        dispatchSceneHsv(context, effTarget, h, 95, b)
                        delay(2400L)
                    }
                    "PARTY" -> {
                        val partyHues = intArrayOf(184, 324, 271, 145, 20, 224)
                        val h = partyHues[step % partyHues.size]
                        dispatchSceneHsv(context, effTarget, h, 100, 100)
                        delay(1400L)
                    }
                    else -> {
                        val h = (step * 36) % 360
                        dispatchSceneHsv(context, effTarget, h, 100, 95)
                        delay(2000L)
                    }
                }
                step++
            }
        }
    }

    fun refreshStatusFromCloudAsync(context: Context) {
        val appCtx = context.applicationContext
        loadCachedRoutingPrefsIfNeeded(appCtx)
        ensureWarmupStarted(appCtx)
        ioScope.launch {
            inspectDeviceStatus(appCtx)
        }
    }

    private suspend fun inspectDeviceStatus(context: Context?) {
        inspectSingleDeviceStatus(context, LauncherConfig.TUYA_LED_DEVICE_ID, isBulb = false)
        inspectSingleDeviceStatus(context, LauncherConfig.TUYA_BULB_DEVICE_ID, isBulb = true)
    }

    private suspend fun inspectSingleDeviceStatus(context: Context?, devId: String, isBulb: Boolean) {
        if (devId.isBlank()) return
        val resp = executeSignedTuyaRequest("GET", "/v1.0/iot-03/devices/$devId/status", "") ?: return
        if (!resp.optBoolean("success", false)) return
        val arr = resp.optJSONArray("result") ?: return
        var foundSwitch: Boolean? = null
        var foundWorkMode: String? = null
        var foundBrightPct: Int? = null
        var foundTempPct: Int? = null

        for (i in 0 until arr.length()) {
            val item = arr.optJSONObject(i) ?: continue
            val code = item.optString("code", "")
            val rawVal = item.opt("value")
            when (code) {
                "switch_led", "switch_led_1", "led_switch", "switch_1", "switch" -> {
                    if (isBulb) discoveredBulbSwitchCode = code else discoveredSwitchCode = code
                    if (rawVal is Boolean) foundSwitch = rawVal
                }
                "work_mode" -> {
                    val m = rawVal?.toString().orEmpty()
                    if (m == "white" || m == "colour") foundWorkMode = m
                }
                "bright_value_v2" -> {
                    val num = (rawVal as? Number)?.toInt()
                    if (num != null) foundBrightPct = (num / 10).coerceIn(10, 100)
                }
                "temp_value_v2" -> {
                    val num = (rawVal as? Number)?.toInt()
                    if (num != null) foundTempPct = (num / 10).coerceIn(0, 100)
                }
            }
        }
        val sinceUserClickMs = System.currentTimeMillis() - lastUserCommandWallMs
        if (context != null && sinceUserClickMs > 8_000L) {
            if (isBulb) {
                if (foundSwitch != null || foundWorkMode != null || foundBrightPct != null || foundTempPct != null) {
                    saveBulbState(
                        context,
                        isOn = foundSwitch,
                        workMode = foundWorkMode,
                        brightPct = foundBrightPct,
                        tempPct = foundTempPct
                    )
                }
            } else if (foundSwitch != null) {
                saveStripState(context, isOn = foundSwitch)
            }
        }
    }

    private suspend fun sendSwitchCommandForDevice(context: Context, devId: String, turnOn: Boolean): Boolean {
        val isBulb = devId == LauncherConfig.TUYA_BULB_DEVICE_ID
        val caps = loadDeviceSpecifications(devId)
        val defaultSw = if (isBulb) discoveredBulbSwitchCode else discoveredSwitchCode
        val swCode = caps?.switchCode ?: defaultSw
        val commands = JSONArray().put(JSONObject().put("code", swCode).put("value", turnOn))
        if (postDeviceCommandsForId(devId, commands)) {
            if (defaultSw != swCode) {
                if (isBulb) discoveredBulbSwitchCode = swCode else discoveredSwitchCode = swCode
                context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
                    .edit()
                    .putString(if (isBulb) PREF_BULB_DISCOVERED_SWITCH_CODE else PREF_DISCOVERED_SWITCH_CODE, swCode)
                    .apply()
            }
            return true
        }
        for (altCode in listOf("switch_led", "switch_led_1", "switch_1", "switch", "led_switch")) {
            if (altCode == swCode) continue
            val altCmds = JSONArray().put(JSONObject().put("code", altCode).put("value", turnOn))
            if (postDeviceCommandsForId(devId, altCmds)) {
                if (isBulb) discoveredBulbSwitchCode = altCode else discoveredSwitchCode = altCode
                return true
            }
        }
        return false
    }

    /**
     * Отправка команды белого режима (White: яркость + цветовая температура CCT) для умной лампочки LED BULB W5K.
     */
    private suspend fun sendWhiteCommandForDevice(
        context: Context,
        devId: String,
        brightPct: Int,
        tempPct: Int
    ): Boolean {
        val isBulb = devId == LauncherConfig.TUYA_BULB_DEVICE_ID
        val caps = loadDeviceSpecifications(devId)
        val swCode = caps?.switchCode ?: if (isBulb) discoveredBulbSwitchCode else discoveredSwitchCode

        val bClamped = brightPct.coerceIn(10, 100)
        val tClamped = tempPct.coerceIn(0, 100)
        val bPromille = (bClamped * 10).coerceIn(10, 1000)
        val tPromille = (tClamped * 10).coerceIn(0, 1000)
        val b255 = (25 + (bClamped - 10) * 230 / 90).coerceIn(25, 255)
        val t255 = (tClamped * 255 / 100).coerceIn(0, 255)

        // 1. По спецификации устройства (если загружена)
        if (caps != null && (caps.brightCode != null || caps.tempCode != null)) {
            val arr = JSONArray()
            arr.put(JSONObject().put("code", swCode).put("value", true))
            if (caps.hasWorkMode) {
                arr.put(JSONObject().put("code", "work_mode").put("value", "white"))
            }
            if (caps.brightCode != null) {
                val scaledB = (caps.brightMin + (bClamped - 10) * (caps.brightMax - caps.brightMin) / 90)
                    .coerceIn(caps.brightMin, caps.brightMax)
                arr.put(JSONObject().put("code", caps.brightCode).put("value", scaledB))
            }
            if (caps.tempCode != null) {
                val scaledT = (caps.tempMin + tClamped * (caps.tempMax - caps.tempMin) / 100)
                    .coerceIn(caps.tempMin, caps.tempMax)
                arr.put(JSONObject().put("code", caps.tempCode).put("value", scaledT))
            }
            if (postDeviceCommandsForId(devId, arr)) return true
        }

        // 2. Стандарт Tuya v2 (10..1000 / 0..1000, как на скриншоте LED BULB W5K)
        val v2Arr = JSONArray()
            .put(JSONObject().put("code", swCode).put("value", true))
            .put(JSONObject().put("code", "work_mode").put("value", "white"))
            .put(JSONObject().put("code", "bright_value_v2").put("value", bPromille))
            .put(JSONObject().put("code", "temp_value_v2").put("value", tPromille))
        if (postDeviceCommandsForId(devId, v2Arr)) return true

        // 3. Tuya v2 только яркость (если у модели фиксированная температура белого)
        val v2BrightOnly = JSONArray()
            .put(JSONObject().put("code", swCode).put("value", true))
            .put(JSONObject().put("code", "work_mode").put("value", "white"))
            .put(JSONObject().put("code", "bright_value_v2").put("value", bPromille))
        if (postDeviceCommandsForId(devId, v2BrightOnly)) return true

        // 4. Tuya v1 (10..1000 и 25..255)
        val v1PromilleArr = JSONArray()
            .put(JSONObject().put("code", swCode).put("value", true))
            .put(JSONObject().put("code", "work_mode").put("value", "white"))
            .put(JSONObject().put("code", "bright_value").put("value", bPromille))
            .put(JSONObject().put("code", "temp_value").put("value", tPromille))
        if (postDeviceCommandsForId(devId, v1PromilleArr)) return true

        val v1ByteArr = JSONArray()
            .put(JSONObject().put("code", swCode).put("value", true))
            .put(JSONObject().put("code", "work_mode").put("value", "white"))
            .put(JSONObject().put("code", "bright_value").put("value", b255))
            .put(JSONObject().put("code", "temp_value").put("value", t255))
        if (postDeviceCommandsForId(devId, v1ByteArr)) return true

        // 5. Fallback через HSV тёплый/холодный белый
        val (approxH, approxS) = approximateWhiteHsvForStrip(tClamped)
        return sendHsvColorCommandForDevice(context, devId, approxH, approxS, bClamped)
    }

    private fun buildColourPayload(
        switchCode: String,
        format: ColourFormat,
        h: Int,
        s: Int,
        v: Int,
        withMode: Boolean
    ): JSONArray {
        val arr = JSONArray()
        arr.put(JSONObject().put("code", switchCode).put("value", true))
        if (withMode) {
            arr.put(JSONObject().put("code", "work_mode").put("value", "colour"))
        }
        val hsv = JSONObject().put("h", h).put("s", s).put("v", v)
        when (format) {
            ColourFormat.V2_OBJECT -> arr.put(JSONObject().put("code", "colour_data_v2").put("value", hsv))
            ColourFormat.V2_STRING -> arr.put(JSONObject().put("code", "colour_data_v2").put("value", hsv.toString()))
            ColourFormat.V1_OBJECT -> arr.put(JSONObject().put("code", "colour_data").put("value", hsv))
            ColourFormat.V1_STRING -> arr.put(JSONObject().put("code", "colour_data").put("value", hsv.toString()))
            ColourFormat.HEX12_LOWER -> arr.put(
                JSONObject().put("code", "colour_data").put("value", String.format(Locale.US, "%04x%04x%04x", h, s, v))
            )
            ColourFormat.HEX12_UPPER -> arr.put(
                JSONObject().put("code", "colour_data").put("value", String.format(Locale.US, "%04X%04X%04X", h, s, v))
            )
        }
        return arr
    }

    private fun buildGuessPayload(
        switchCode: String,
        format: ColourFormat,
        h: Int,
        sPromille: Int,
        vPromille: Int,
        withMode: Boolean
    ): JSONArray {
        val isV1 = format == ColourFormat.V1_OBJECT || format == ColourFormat.V1_STRING
        val s = if (isV1) (sPromille * 255 / 1000).coerceAtLeast(1) else sPromille
        val v = if (isV1) (vPromille * 255 / 1000).coerceAtLeast(1) else vPromille
        return buildColourPayload(switchCode, format, h, s, v, withMode)
    }

    private suspend fun sendHsvColorCommandForDevice(
        context: Context,
        devId: String,
        hue: Int,
        satPct: Int,
        brightPct: Int
    ): Boolean {
        val isBulb = devId == LauncherConfig.TUYA_BULB_DEVICE_ID
        val h = ((hue % 360) + 360) % 360
        val sPromille = (satPct * 10).coerceIn(10, 1000)
        val vPromille = (brightPct * 10).coerceIn(10, 1000)
        val learnedPair = if (isBulb) learnedBulbFormatPair else learnedFormatPair

        val caps = loadDeviceSpecifications(devId)
        if (caps != null && caps.colourCode != null) {
            val isV2 = caps.colourCode == "colour_data_v2"
            val objFormat = if (isV2) ColourFormat.V2_OBJECT else ColourFormat.V1_OBJECT
            val strFormat = if (isV2) ColourFormat.V2_STRING else ColourFormat.V1_STRING
            val sDev = (sPromille * caps.sMax / 1000).coerceAtLeast(1)
            val vDev = (vPromille * caps.vMax / 1000).coerceAtLeast(1)

            learnedPair?.let { (fmt, modeFlag) ->
                val learnedScaleS = if (fmt == ColourFormat.V1_OBJECT || fmt == ColourFormat.V1_STRING) (sPromille * 255 / 1000).coerceAtLeast(1) else sPromille
                val learnedScaleV = if (fmt == ColourFormat.V1_OBJECT || fmt == ColourFormat.V1_STRING) (vPromille * 255 / 1000).coerceAtLeast(1) else vPromille
                if (postDeviceCommandsForId(devId, buildColourPayload(caps.switchCode, fmt, h, learnedScaleS, learnedScaleV, modeFlag))) {
                    return true
                }
            }

            if (postDeviceCommandsForId(devId, buildColourPayload(caps.switchCode, objFormat, h, sDev, vDev, caps.hasWorkMode))) {
                saveLearnedFormatForDevice(context, devId, objFormat, caps.hasWorkMode)
                return true
            }
            if (postDeviceCommandsForId(devId, buildColourPayload(caps.switchCode, strFormat, h, sDev, vDev, caps.hasWorkMode))) {
                saveLearnedFormatForDevice(context, devId, strFormat, caps.hasWorkMode)
                return true
            }
            if (postDeviceCommandsForId(devId, buildColourPayload(caps.switchCode, objFormat, h, sDev, vDev, !caps.hasWorkMode))) {
                saveLearnedFormatForDevice(context, devId, objFormat, !caps.hasWorkMode)
                return true
            }
            if (postDeviceCommandsForId(devId, buildColourPayload(caps.switchCode, strFormat, h, sDev, vDev, !caps.hasWorkMode))) {
                saveLearnedFormatForDevice(context, devId, strFormat, !caps.hasWorkMode)
                return true
            }
        }

        val sw = caps?.switchCode ?: if (isBulb) discoveredBulbSwitchCode else discoveredSwitchCode
        learnedPair?.let { (fmt, withMode) ->
            if (postDeviceCommandsForId(devId, buildGuessPayload(sw, fmt, h, sPromille, vPromille, withMode))) {
                return true
            }
            if (isBulb) learnedBulbFormatPair = null else learnedFormatPair = null
        }

        for (fmt in ColourFormat.values()) {
            for (withMode in listOf(true, false)) {
                if (postDeviceCommandsForId(devId, buildGuessPayload(sw, fmt, h, sPromille, vPromille, withMode))) {
                    saveLearnedFormatForDevice(context, devId, fmt, withMode)
                    return true
                }
            }
        }
        return false
    }

    private suspend fun postDeviceCommandsForId(devId: String, commandsArray: JSONArray): Boolean {
        if (devId.isBlank()) return false
        val body = JSONObject().put("commands", commandsArray).toString()
        val res = executeSignedTuyaRequest("POST", "/v1.0/iot-03/devices/$devId/commands", body)
        if (res != null && res.optBoolean("success", false)) {
            return true
        }
        val fallbackRes = executeSignedTuyaRequest("POST", "/v1.0/devices/$devId/commands", body)
        return fallbackRes != null && fallbackRes.optBoolean("success", false)
    }

    private suspend fun ensureAccessToken(forceRefresh: Boolean = false): String = withContext(Dispatchers.IO) {
        synchronized(tokenLock) {
            val nowWall = System.currentTimeMillis()
            if (!forceRefresh && cachedAccessToken.isNotEmpty() && nowWall < tokenExpiresAtWallMs) {
                return@withContext cachedAccessToken
            }

            val orderedHosts = mutableListOf<String>()
            orderedHosts.add(cachedHost)
            for (h in apiHosts) {
                if (h != cachedHost) orderedHosts.add(h)
            }

            val secret = LauncherConfig.TUYA_CLIENT_SECRET

            for (host in orderedHosts) {
                var tokenJson = executeRawSignedCall(
                    host = host,
                    method = "GET",
                    pathWithQuery = "/v1.0/token?grant_type=1",
                    body = "",
                    accessToken = "",
                    secretOverride = secret
                ) ?: continue

                val serverT = tokenJson.optLong("t", 0L)
                if (serverT > 1_600_000_000_000L) {
                    serverTimeOffsetMs = serverT - System.currentTimeMillis()
                }

                if (!tokenJson.optBoolean("success", false)) {
                    val retryJson = executeRawSignedCall(
                        host = host,
                        method = "GET",
                        pathWithQuery = "/v1.0/token?grant_type=1",
                        body = "",
                        accessToken = "",
                        secretOverride = secret
                    )
                    if (retryJson != null) {
                        tokenJson = retryJson
                    }
                }

                if (tokenJson.optBoolean("success", false)) {
                    val resObj = tokenJson.optJSONObject("result")
                    val tok = resObj?.optString("access_token", "").orEmpty()
                    val expSec = resObj?.optLong("expire_time", 7200L) ?: 7200L
                    if (tok.isNotEmpty()) {
                        cachedHost = host
                        cachedAccessToken = tok
                        val safeTtlMs = ((expSec - 120L).coerceIn(300L, 7000L)) * 1000L
                        tokenExpiresAtWallMs = System.currentTimeMillis() + safeTtlMs
                        return@withContext tok
                    }
                }
            }
            cachedAccessToken
        }
    }

    private suspend fun executeSignedTuyaRequest(
        method: String,
        pathWithQuery: String,
        body: String
    ): JSONObject? = withContext(Dispatchers.IO) {
        var token = ensureAccessToken(forceRefresh = false)
        if (token.isEmpty()) return@withContext null

        val secret = LauncherConfig.TUYA_CLIENT_SECRET
        var res = executeRawSignedCall(cachedHost, method, pathWithQuery, body, token, secret)

        if (res == null) {
            res = executeRawSignedCall(cachedHost, method, pathWithQuery, body, token, secret)
        } else if (!res.optBoolean("success", false)) {
            val serverT = res.optLong("t", 0L)
            if (serverT > 1_600_000_000_000L) {
                serverTimeOffsetMs = serverT - System.currentTimeMillis()
            }
            val code = res.optInt("code", 0)
            val msg = res.optString("msg", "").lowercase(Locale.US)
            if (code == 1010 || code == 1013 || code == 1004 || msg.contains("token") || msg.contains("sign")) {
                token = ensureAccessToken(forceRefresh = true)
                if (token.isNotEmpty()) {
                    res = executeRawSignedCall(cachedHost, method, pathWithQuery, body, token, secret)
                }
            }
        }
        res
    }

    private fun executeRawSignedCall(
        host: String,
        method: String,
        pathWithQuery: String,
        body: String,
        accessToken: String,
        secretOverride: String = ""
    ): JSONObject? {
        val clientId = LauncherConfig.TUYA_CLIENT_ID
        val secret = if (secretOverride.isNotEmpty()) secretOverride else LauncherConfig.TUYA_CLIENT_SECRET
        val timestamp = (System.currentTimeMillis() + serverTimeOffsetMs).toString()

        val bodyBytes = body.toByteArray(Charsets.UTF_8)
        val contentSha256 = sha256HexLower(bodyBytes)
        val stringToSign = "$method\n$contentSha256\n\n$pathWithQuery"
        val payloadToSign = if (accessToken.isEmpty()) {
            "$clientId$timestamp$stringToSign"
        } else {
            "$clientId$accessToken$timestamp$stringToSign"
        }
        val signUpper = hmacSha256HexUpper(payloadToSign, secret)

        var conn: HttpURLConnection? = null
        return try {
            val connObj = (URL("$host$pathWithQuery").openConnection() as HttpURLConnection).apply {
                requestMethod = method
                connectTimeout = 2800
                readTimeout = 3500
                doInput = true
                useCaches = false
                setRequestProperty("Connection", "keep-alive")
                setRequestProperty("client_id", clientId)
                setRequestProperty("sign", signUpper)
                setRequestProperty("t", timestamp)
                setRequestProperty("sign_method", "HMAC-SHA256")
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("x-app-secret", LauncherConfig.GATEWAY_APP_SECRET)
                if (accessToken.isNotEmpty()) {
                    setRequestProperty("access_token", accessToken)
                }
                if (method == "POST" || method == "PUT") {
                    doOutput = true
                }
            }
            conn = connObj
            if (method == "POST" || method == "PUT") {
                connObj.outputStream.use { os ->
                    os.write(bodyBytes)
                    os.flush()
                }
            }
            val code = connObj.responseCode
            val stream = if (code in 200..299) connObj.inputStream else connObj.errorStream
            val respText = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (respText.isNotBlank()) JSONObject(respText) else null
        } catch (e: Exception) {
            try {
                conn?.disconnect()
            } catch (_: Exception) {
            }
            null
        }
    }

    private fun sha256HexLower(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        val sb = StringBuilder(digest.size * 2)
        for (b in digest) {
            sb.append(String.format(Locale.US, "%02x", b.toInt() and 0xFF))
        }
        return sb.toString()
    }

    private fun hmacSha256HexUpper(data: String, secret: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        val keySpec = SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256")
        mac.init(keySpec)
        val raw = mac.doFinal(data.toByteArray(Charsets.UTF_8))
        val sb = StringBuilder(raw.size * 2)
        for (b in raw) {
            sb.append(String.format(Locale.US, "%02X", b.toInt() and 0xFF))
        }
        return sb.toString()
    }
}
