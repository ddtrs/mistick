package com.mitv.customlauncher.data

import com.mitv.customlauncher.service.MediaStateBus

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.provider.Settings

class AppLauncher(private val appContext: Context) {

    companion object {
        @Volatile
        private var cachedApps: List<InstalledAppInfo>? = null
        @Volatile
        private var lastCacheRealtimeMs: Long = 0L
    }

    private val prefs: SharedPreferences =
        appContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)

    fun getInstalledApps(): List<InstalledAppInfo> {
        val now = android.os.SystemClock.elapsedRealtime()
        val existing = cachedApps
        if (existing != null && existing.isNotEmpty() && (now - lastCacheRealtimeMs) < 60_000L) {
            return existing
        }
        val pm = appContext.packageManager
        val resultMap = linkedMapOf<String, InstalledAppInfo>()

        val categories = listOf(
            Intent.CATEGORY_LEANBACK_LAUNCHER,
            Intent.CATEGORY_LAUNCHER
        )

        for (category in categories) {
            val queryIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(category)
            }
            @Suppress("DEPRECATION")
            val resolveInfos = pm.queryIntentActivities(queryIntent, 0)
            for (ri in resolveInfos) {
                val pkg = ri.activityInfo?.packageName ?: continue
                if (pkg == appContext.packageName) continue
                if (!resultMap.containsKey(pkg)) {
                    val label = ri.loadLabel(pm)?.toString()?.trim().takeUnless { it.isNullOrEmpty() } ?: pkg
                    resultMap[pkg] = InstalledAppInfo(packageName = pkg, label = label)
                }
            }
        }

        val sorted = resultMap.values.sortedBy { it.label.lowercase() }
        cachedApps = sorted
        lastCacheRealtimeMs = android.os.SystemClock.elapsedRealtime()
        return sorted
    }

    fun getBoundAppForSlot(slot: CardSlot, allApps: List<InstalledAppInfo>): InstalledAppInfo? {
        val savedPkg = prefs.getString(slot.prefKey, null)
        if (!savedPkg.isNullOrEmpty()) {
            val matched = allApps.firstOrNull { it.packageName == savedPkg }
            if (matched != null) return matched
        }

        val autoPicked = when (slot) {
            CardSlot.SLOT_1 -> pickBestCandidate(
                allApps,
                keywords = listOf("youtube", "smarttube", "video", "kino", "lampa", "netflix", "tv"),
                fallbackIndex = 0
            )
            CardSlot.SLOT_2 -> pickBestCandidate(
                allApps,
                keywords = listOf("browser", "chrome", "vending", "play", "store", "market"),
                fallbackIndex = 1
            )
            CardSlot.SLOT_3 -> pickBestCandidate(
                allApps,
                keywords = listOf("airscreen", "aircast", "cast", "vlc", "kodi", "player", "files"),
                fallbackIndex = 2
            )
            CardSlot.SLOT_4 -> pickBestCandidate(
                allApps,
                keywords = listOf("spotify", "music", "soundcloud", "deezer", "lampa", "media", "settings"),
                fallbackIndex = 3
            )
        }

        if (autoPicked != null) {
            bindAppToSlot(slot, autoPicked.packageName)
        }
        return autoPicked
    }

    fun bindAppToSlot(slot: CardSlot, packageName: String) {
        prefs.edit().putString(slot.prefKey, packageName).apply()
    }

    fun savePresetBinding(presetId: String, targetActionOrPkg: String?) {
        val editor = prefs.edit()
        if (targetActionOrPkg.isNullOrEmpty()) {
            editor.remove("preset_bind_$presetId")
        } else {
            editor.putString("preset_bind_$presetId", targetActionOrPkg)
        }
        editor.apply()
    }

    fun getPresetBinding(presetId: String): String? {
        val defaultVal = if (presetId == "PATCHWALL") "ACTION_CONTROL_CENTER" else null
        return prefs.getString("preset_bind_$presetId", defaultVal)
    }

    fun getAccentColorHex(): String {
        return prefs.getString("pref_accent_color", "#00F0FF") ?: "#00F0FF"
    }

    fun getGeminiApiKey(): String {
        return GeminiKeyPool.acquire(appContext, GeminiKeyPool.Kind.TEXT)?.apiKey ?: LauncherConfig.DEFAULT_GEMINI_API_KEY
    }

    fun saveAccentColorHex(hex: String) {
        prefs.edit().putString("pref_accent_color", hex).apply()
    }

    fun saveKeyBinding(keyCode: Int, scanCode: Int, targetActionOrPkg: String?) {
        val editor = prefs.edit()
        if (targetActionOrPkg.isNullOrEmpty()) {
            if (keyCode > 0) editor.remove("key_bind_$keyCode")
            if (scanCode > 0) editor.remove("scan_bind_$scanCode")
        } else {
            if (keyCode > 0) editor.putString("key_bind_$keyCode", targetActionOrPkg)
            if (scanCode > 0) editor.putString("scan_bind_$scanCode", targetActionOrPkg)
        }
        editor.apply()
    }

    fun getKeyBinding(keyCode: Int, scanCode: Int): String? {
        return prefs.getString("key_bind_$keyCode", null)
            ?: if (scanCode > 0) prefs.getString("scan_bind_$scanCode", null) else null
    }

    fun launchPackage(packageName: String): Boolean {
        MediaStateBus.onMediaAppOpened(packageName)
        val pm = appContext.packageManager
        val intent = pm.getLeanbackLaunchIntentForPackage(packageName)
            ?: pm.getLaunchIntentForPackage(packageName)
            ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            appContext.startActivity(intent)
            true
        } catch (_: ActivityNotFoundException) {
            false
        } catch (_: SecurityException) {
            false
        }
    }

    fun launchSystemSettings(): Boolean {
        val intent = Intent(Settings.ACTION_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            appContext.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    fun launchAccessibilitySettings(): Boolean {
        val accessIntent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            appContext.startActivity(accessIntent)
            true
        } catch (_: Exception) {
            launchSystemSettings()
        }
    }

    private fun pickBestCandidate(
        allApps: List<InstalledAppInfo>,
        keywords: List<String>,
        fallbackIndex: Int
    ): InstalledAppInfo? {
        for (kw in keywords) {
            val found = allApps.firstOrNull {
                it.packageName.lowercase().contains(kw) || it.label.lowercase().contains(kw)
            }
            if (found != null) return found
        }
        return allApps.getOrNull(fallbackIndex)
    }
}
