package com.mitv.customlauncher.data

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.provider.Settings

class AppLauncher(private val appContext: Context) {

    private val prefs: SharedPreferences =
        appContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)

    /**
     * Сканирует все реально установленные на приставке приложения (и Android TV Leanback, и обычные APK).
     */
    fun getInstalledApps(): List<InstalledAppInfo> {
        val pm = appContext.packageManager
        val resultMap = linkedMapOf<String, InstalledAppInfo>()

        val categories = listOf(
            Intent.CATEGORY_LEANBACK_LAUNCHER,
            Intent.CATEGORY_LAUNCHER
        )

        for (category in categories) {
            val queryIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(category)
            }
            @Suppress("DEPRECATION")
            val resolveInfos = pm.queryIntentActivities(queryIntent, 0)
            for (ri in resolveInfos) {
                val pkg = ri.activityInfo?.packageName ?: continue
                if (pkg == appContext.packageName) continue
                if (!resultMap.containsKey(pkg)) {
                    val label = ri.loadLabel(pm)?.toString()?.trim().takeUnless { it.isNullOrEmpty() } ?: pkg
                    resultMap[pkg] = InstalledAppInfo(packageName = pkg, label = label)
                }
            }
        }

        return resultMap.values.sortedBy { it.label.lowercase() }
    }

    /**
     * Возвращает привязанное к карточке приложение (или автоматически находит лучшее реальное приложение на стике).
     */
    fun getBoundAppForSlot(slot: CardSlot, allApps: List<InstalledAppInfo>): InstalledAppInfo? {
        val savedPkg = prefs.getString(slot.prefKey, null)
        if (!savedPkg.isNullOrEmpty()) {
            val matched = allApps.firstOrNull { it.packageName == savedPkg }
            if (matched != null) return matched
        }

        // Автоматический подбор реальных установленных приложений при первом старте
        val autoPicked = when (slot) {
            CardSlot.SLOT_1 -> pickBestCandidate(
                allApps,
                keywords = listOf("youtube", "smarttube", "video", "kino", "lampa", "netflix", "tv"),
                fallbackIndex = 0
            )
            CardSlot.SLOT_2 -> pickBestCandidate(
                allApps,
                keywords = listOf("browser", "chrome", "vending", "play", "store", "market"),
                fallbackIndex = 1
            )
            CardSlot.SLOT_3 -> pickBestCandidate(
                allApps,
                keywords = listOf("airscreen", "cast", "vlc", "kodi", "player", "files", "music"),
                fallbackIndex = 2
            )
        }

        if (autoPicked != null) {
            bindAppToSlot(slot, autoPicked.packageName)
        }
        return autoPicked
    }

    fun bindAppToSlot(slot: CardSlot, packageName: String) {
        prefs.edit().putString(slot.prefKey, packageName).apply()
    }

    fun launchPackage(packageName: String): Boolean {
        val pm = appContext.packageManager
        val intent = pm.getLeanbackLaunchIntentForPackage(packageName)
            ?: pm.getLaunchIntentForPackage(packageName)
            ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try {
            appContext.startActivity(intent)
            true
        } catch (_: ActivityNotFoundException) {
            false
        } catch (_: SecurityException) {
            false
        }
    }

    fun launchSystemSettings(): Boolean {
        val intent = Intent(Settings.ACTION_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            appContext.startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun pickBestCandidate(
        allApps: List<InstalledAppInfo>,
        keywords: List<String>,
        fallbackIndex: Int
    ): InstalledAppInfo? {
        for (kw in keywords) {
            val found = allApps.firstOrNull {
                it.packageName.lowercase().contains(kw) || it.label.lowercase().contains(kw)
            }
            if (found != null) return found
        }
        return allApps.getOrNull(fallbackIndex)
    }
}
