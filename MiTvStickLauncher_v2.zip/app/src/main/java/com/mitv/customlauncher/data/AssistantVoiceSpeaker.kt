package com.mitv.customlauncher.data

import android.app.ActivityManager
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.isActive
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import android.graphics.Color
import kotlinx.coroutines.delay
import java.nio.ByteOrder
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import kotlin.math.sqrt
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.speech.tts.TextToSpeech
import com.mitv.customlauncher.service.DynamicIslandBus
import com.mitv.customlauncher.service.RemoteConsoleServer
import com.mitv.customlauncher.service.ShellKeyController
import android.util.Base64
import android.util.Log
import android.widget.Toast
import android.view.KeyEvent
import com.mitv.customlauncher.service.TvUiControllerBus
import com.mitv.customlauncher.service.MediaStateBus
import com.mitv.customlauncher.service.NavSoundPlayer
import com.mitv.customlauncher.service.VolumeHudBus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


object AssistantVoiceSpeaker {

    private const val PREF_TTS_ENABLED = "pref_assistant_tts_enabled"
    private const val PREF_TTS_VOICE = "pref_assistant_tts_voice"
    private const val PREF_CACHED_TTS_MODEL = "pref_cached_gemini_tts_model_v62"
    private const val PREF_NO_STREAM_MODELS = "pref_no_stream_tts_models_v60"
    private const val PREF_NO_STREAM_TS = "pref_no_stream_tts_ts_v60"
    private const val PREF_NO_STREAM_VER = "pref_no_stream_tts_ver_v60"
    private const val CURRENT_APP_VERSION_CODE = 60

    private const val TTS_FIRST_SOUND_BUDGET_MS = 6_000L
    private const val MAX_KEY_ATTEMPTS = 3

    val AVAILABLE_VOICES: List<Pair<String, String>> = listOf(
        "Puck" to "Puck (Живой мужской)",
        "Aoede" to "Aoede (Мягкий женский)",
        "Kore" to "Kore (Чёткий женский)",
        "Charon" to "Charon (Глубокий мужской)",
        "Fenrir" to "Fenrir (Энергичный мужской)"
    )

    private val ttsModels = listOf(
        "gemini-3.8-flash-lite-tts",
        "gemini-3.8-flash-tts",
        "gemini-3.1-flash-tts-preview",
        "gemini-2.5-flash-preview-tts",
        "gemini-2.5-pro-preview-tts"
    )

    @Volatile
    private var lastTtsError: String = ""

    @Volatile
    private var cachedTtsModel: String? = null

    @Volatile
    private var lastRateLimitToastMs: Long = 0L

    private val speakerScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    private var speakJob: Job? = null

    @Volatile
    private var activeAudioTrack: AudioTrack? = null

    @Volatile
    private var fallbackSystemTts: TextToSpeech? = null

    @Volatile
    private var fallbackTtsReady: Boolean = false

    @Volatile
    var isSpeakingNow: Boolean = false
        private set

    @Volatile
    var currentVoiceWaveLevel: Float = 0.45f

    private var currentAudioFocusRequest: AudioFocusRequest? = null

    private val noStreamModels = java.util.concurrent.CopyOnWriteArraySet<String>()
    private val unavailableTtsModels = java.util.concurrent.CopyOnWriteArraySet<String>()

    @Volatile
    private var prefsLoaded = false

    // Предзагрузка первого предложения во время потоковой генерации текста (Этап 3)
    @Volatile
    private var prefetchedSentenceText: String? = null

    @Volatile
    private var prefetchedSentenceJob: Deferred<ByteArray?>? = null

    @Synchronized
    private fun ensureTtsCacheLoaded(context: Context) {
        if (prefsLoaded) return
        prefsLoaded = true
        try {
            val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            val savedModel = prefs.getString(PREF_CACHED_TTS_MODEL, null)
            if (!savedModel.isNullOrBlank()) {
                cachedTtsModel = savedModel
            }
            val now = System.currentTimeMillis()
            val savedVer = prefs.getInt(PREF_NO_STREAM_VER, 0)
            val savedTs = prefs.getLong(PREF_NO_STREAM_TS, 0L)
            if (savedVer != CURRENT_APP_VERSION_CODE || (now - savedTs) > 24L * 3600_000L) {
                noStreamModels.clear()
                prefs.edit()
                    .remove(PREF_NO_STREAM_MODELS)
                    .putInt(PREF_NO_STREAM_VER, CURRENT_APP_VERSION_CODE)
                    .putLong(PREF_NO_STREAM_TS, now)
                    .apply()
            } else {
                val rawSet = prefs.getString(PREF_NO_STREAM_MODELS, "") ?: ""
                for (item in rawSet.split(",")) {
                    val m = item.trim()
                    if (m.isNotEmpty()) noStreamModels.add(m)
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun saveCachedTtsModel(context: Context, model: String) {
        cachedTtsModel = model
        try {
            val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit().putString(PREF_CACHED_TTS_MODEL, model).apply()
        } catch (_: Exception) {
        }
    }

    private fun markNoStreamModel(context: Context, model: String) {
        if (noStreamModels.add(model)) {
            try {
                val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
                prefs.edit()
                    .putString(PREF_NO_STREAM_MODELS, noStreamModels.joinToString(","))
                    .putLong(PREF_NO_STREAM_TS, System.currentTimeMillis())
                    .putInt(PREF_NO_STREAM_VER, CURRENT_APP_VERSION_CODE)
                    .apply()
            } catch (_: Exception) {
            }
        }
    }

    fun isTtsEnabled(context: Context): Boolean {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(PREF_TTS_ENABLED, true)
    }

    fun setTtsEnabled(context: Context, enabled: Boolean) {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(PREF_TTS_ENABLED, enabled).apply()
        if (!enabled) {
            stop(context)
        }
    }

    fun getSelectedVoiceName(context: Context): String {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString(PREF_TTS_VOICE, "Puck") ?: "Puck"
        return if (AVAILABLE_VOICES.any { it.first.equals(saved, ignoreCase = true) }) {
            AVAILABLE_VOICES.first { it.first.equals(saved, ignoreCase = true) }.first
        } else {
            "Puck"
        }
    }

    fun getSelectedVoiceDisplayLabel(context: Context): String {
        val code = getSelectedVoiceName(context)
        return AVAILABLE_VOICES.firstOrNull { it.first == code }?.second ?: code
    }

    fun setVoiceName(context: Context, rawVoice: String): String {
        val clean = rawVoice.trim()
        val matched = AVAILABLE_VOICES.firstOrNull {
            it.first.equals(clean, ignoreCase = true) || it.second.lowercase(Locale.ROOT).contains(clean.lowercase(Locale.ROOT))
        }?.first ?: when {
            clean.lowercase(Locale.ROOT).contains("жен") || clean.lowercase(Locale.ROOT).contains("жіноч") || clean.lowercase(Locale.ROOT).contains("kore") -> "Kore"
            clean.lowercase(Locale.ROOT).contains("мягк") || clean.lowercase(Locale.ROOT).contains("aoede") -> "Aoede"
            clean.lowercase(Locale.ROOT).contains("глуб") || clean.lowercase(Locale.ROOT).contains("charon") -> "Charon"
            clean.lowercase(Locale.ROOT).contains("энерг") || clean.lowercase(Locale.ROOT).contains("fenrir") -> "Fenrir"
            else -> "Puck"
        }
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(PREF_TTS_VOICE, matched).apply()
        return matched
    }

    fun cycleNextVoice(context: Context): String {
        val current = getSelectedVoiceName(context)
        val idx = AVAILABLE_VOICES.indexOfFirst { it.first == current }
        val next = if (idx >= 0) AVAILABLE_VOICES[(idx + 1) % AVAILABLE_VOICES.size].first else AVAILABLE_VOICES.first().first
        setVoiceName(context, next)
        return getSelectedVoiceDisplayLabel(context)
    }

    fun init(context: Context) {
        ensureTtsCacheLoaded(context)
        TuyaSmartHomeController.ensureWarmupStarted(context)
    }

    fun normalizeSpeechText(rawText: String): String {
        return rawText
            .removePrefix("✦")
            .replace("🔔", "")
            .replace("⚡", "")
            .replace("✓", "")
            .replace("*", "")
            .replace("#", "")
            .replace("·", ", ")
            .replace("–", " до ")
            .trim()
    }

    /**
     * Разбивает ответ на предложения для мгновенного старта озвучки:
     * - Первый кусок: по первому законченному предложению (разделители `. ! ? …` и `\n`), не короче ~40 символов и не длиннее ~120 символов.
     * - Следующие предложения ставятся в очередь и предзагружаются параллельно, пока играет предыдущее.
     */
    /**
     * Обычные ответы до 260 символов передаются ОДНИМ цельным потоком (streamGenerateContent SSE),
     * чтобы не было стыков, щелчков и пауз между словами! Только длинные тексты делятся по предложениям.
     */
    fun splitTextIntoStreamingSentences(text: String): List<String> {
        val clean = normalizeSpeechText(text)
        if (clean.isEmpty()) return emptyList()
        // Первое законченное предложение озвучиваем отдельным куском: звук начинается раньше,
        // а остаток подгружается параллельно, пока играет первый кусок.
        val firstBreak = findSentenceBreak(clean, minLen = EARLY_MIN_LEN, maxLen = EARLY_MAX_LEN)
        if (clean.length > 90 && firstBreak in 1 until clean.length && clean.length - firstBreak >= 25) {
            val first = clean.substring(0, firstBreak).trim()
            val rest = clean.substring(firstBreak).trim()
            if (first.isNotEmpty() && rest.isNotEmpty()) {
                return listOf(first) + splitLongText(rest)
            }
        }
        return splitLongText(clean)
    }

    private const val EARLY_MIN_LEN = 30
    private const val EARLY_MAX_LEN = 160

    /**
     * Первое законченное предложение из приходящего потока текста (после него уже есть пробел/перенос),
     * либо null, если оно ещё не дописано. Совпадает с первым куском splitTextIntoStreamingSentences.
     */
    fun extractFirstSentenceForEarlyTts(text: String): String? {
        val clean = normalizeSpeechText(text)
        if (clean.length < EARLY_MIN_LEN + 5) return null
        val idx = findSentenceBreak(clean, minLen = EARLY_MIN_LEN, maxLen = EARLY_MAX_LEN)
        if (idx <= 0 || idx >= clean.length) return null
        return clean.substring(0, idx).trim().takeIf { it.isNotEmpty() }
    }

    private fun splitLongText(clean: String): List<String> {
        if (clean.isEmpty()) return emptyList()
        if (clean.length <= 260) return listOf(clean)

        val result = mutableListOf<String>()
        var remaining = clean

        while (remaining.isNotEmpty()) {
            if (remaining.length <= 240) {
                result.add(remaining)
                break
            }
            var splitIdx = findSentenceBreak(remaining, minLen = 50, maxLen = 230)
            if (splitIdx == -1) {
                val spaceIdx = remaining.lastIndexOf(' ', 220)
                splitIdx = if (spaceIdx >= 50) spaceIdx + 1 else 220
            }
            val piece = remaining.substring(0, splitIdx).trim()
            if (piece.isNotEmpty()) {
                result.add(piece)
            }
            remaining = remaining.substring(splitIdx).trim()
        }

        return if (result.isEmpty()) listOf(clean) else result
    }

    private fun findSentenceBreak(s: String, minLen: Int, maxLen: Int): Int {
        val limit = minOf(s.length, maxLen)
        if (limit < minLen) return -1
        for (i in minLen - 1 until limit) {
            val ch = s[i]
            if (ch == '\n') {
                return i + 1
            }
            if (ch == '.' || ch == '!' || ch == '?' || ch == '…') {
                if (i + 1 >= s.length || s[i + 1].isWhitespace()) {
                    return i + 1
                }
            }
        }
        return -1
    }

    /**
     * Запускает фоновую предзагрузку первого предложения ещё во время прихода потокового текста (Этап 3).
     */
    @Synchronized
    fun startFirstSentencePrefetchIfReady(context: Context, firstSentence: String) {
        val appCtx = context.applicationContext
        if (!isTtsEnabled(appCtx)) return
        val normalized = normalizeSpeechText(firstSentence)
        if (normalized.length < 20) return
        if (prefetchedSentenceText == normalized && prefetchedSentenceJob?.isActive == true) return

        prefetchedSentenceJob?.cancel()
        prefetchedSentenceText = normalized
        val voiceName = getSelectedVoiceName(appCtx)
        prefetchedSentenceJob = speakerScope.async {
            val startMs = SystemClock.elapsedRealtime()
            fetchGeminiTtsPcmWithRetry(appCtx, normalized, voiceName, startMs)
        }
    }

    @Synchronized
    private fun consumeMatchingPrefetch(chunkText: String): Deferred<ByteArray?>? {
        val normalized = normalizeSpeechText(chunkText)
        val job = prefetchedSentenceJob
        return if (job != null && prefetchedSentenceText == normalized) {
            prefetchedSentenceJob = null
            prefetchedSentenceText = null
            job
        } else {
            prefetchedSentenceJob?.cancel()
            prefetchedSentenceJob = null
            prefetchedSentenceText = null
            null
        }
    }

    private fun maybeShowRateLimitToast(context: Context) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastRateLimitToastMs >= 60_000L) {
            lastRateLimitToastMs = now
            mainHandler.post {
                try {
                    Toast.makeText(context, "Лимит Gemini TTS, говорю встроенным голосом", Toast.LENGTH_SHORT).show()
                } catch (_: Exception) {
                }
            }
        }
    }

    /**
     * Надёжная озвучка с пулом ключей Gemini TTS, предзагрузкой следующих предложений и резервным встроенным голосом ТВ:
     * 1. Если сообщение — уведомление об исчерпании текстовых лимитов или пул TTS пуст — сразу озвучивает встроенным голосом ТВ без тишины.
     * 2. Иначе озвучивает первым предложением (через предзагрузку или SSE-поток) и параллельно качает следующее предложение в фоне.
     */
    fun speak(context: Context, rawText: String, onFinished: ((Boolean) -> Unit)? = null) {
        val appCtx = context.applicationContext
        ensureTtsCacheLoaded(appCtx)
        stop(appCtx, preservePrefetch = true)

        if (!isTtsEnabled(appCtx)) {
            consumeMatchingPrefetch("")
            onFinished?.let { mainHandler.post { it.invoke(false) } }
            return
        }

        val cleanText = normalizeSpeechText(rawText)
        if (cleanText.isEmpty()) {
            consumeMatchingPrefetch("")
            onFinished?.let { mainHandler.post { it.invoke(false) } }
            return
        }

        val voiceName = getSelectedVoiceName(appCtx)
        val textChunks = splitTextIntoStreamingSentences(cleanText)
        val matchedFirstPrefetch = if (textChunks.isNotEmpty()) consumeMatchingPrefetch(textChunks[0]) else null

        isSpeakingNow = true
        currentVoiceWaveLevel = 0.52f
        firstAudioLoggedThisSpeak = false
        GeminiCloudClient.logTiming("tts_speak_called")

        speakJob = speakerScope.launch {
            val selfJob = coroutineContext[Job]
            var playedSuccessfully = false
            var track: AudioTrack? = null
            var totalFramesWritten = 0L
            var isFirstSpeechChunk = true
            var nextChunkPrefetch: Deferred<ByteArray?>? = null
            val turnStartElapsedMs = SystemClock.elapsedRealtime()

            try {
                // Если это системное сообщение о лимите всех текстовых ключей (п. 3.2), не отправляем его в Gemini TTS
                val isTextQuotaMessage = cleanText.startsWith("Лимиты Gemini исчерпаны")
                if (!isTextQuotaMessage) {
                    for (idx in textChunks.indices) {
                        if (!isActive || !isSpeakingNow) break
                        val chunkText = textChunks[idx]

                        // Пока будет играть текущий кусок idx, параллельно запускаем предзагрузку куска idx + 1
                        val currentPrefetch = if (idx == 0) matchedFirstPrefetch else nextChunkPrefetch
                        nextChunkPrefetch = if (idx + 1 < textChunks.size) {
                            val nextText = textChunks[idx + 1]
                            async(Dispatchers.IO) {
                                fetchGeminiTtsPcmWithRetry(appCtx, nextText, voiceName, SystemClock.elapsedRealtime())
                            }
                        } else {
                            null
                        }

                        var chunkPlayed = false
                        if (currentPrefetch != null) {
                            val prePcm = try {
                                currentPrefetch.await()
                            } catch (_: Exception) {
                                null
                            }
                            if (prePcm != null && prePcm.size > 400 && isActive && isSpeakingNow) {
                                if (track == null) {
                                    val opened = openStreamingAudioTrack24kHz(appCtx)
                                    track = opened?.first
                                    totalFramesWritten += opened?.second ?: 0L
                                    activeAudioTrack = track
                                }
                                val activeAt = track
                                if (activeAt != null) {
                                    val preparedPcm = if (isFirstSpeechChunk) {
                                        isFirstSpeechChunk = false
                                        applyLeadingFadeIn16BitMono(prePcm)
                                    } else {
                                        prePcm
                                    }
                                    val frames = writePcmChunkWithVisualizer(activeAt, preparedPcm)
                                    if (frames > 0L) {
                                        totalFramesWritten += frames
                                        playedSuccessfully = true
                                        chunkPlayed = true
                                    }
                                }
                            }
                        }

                        if (chunkPlayed) continue
                        if (!isActive || !isSpeakingNow) break

                        // Потоковая озвучка: звук начинает играть, как только пришли первые данные
                        val budgetStart = if (playedSuccessfully) SystemClock.elapsedRealtime() else turnStartElapsedMs
                        val streamed = streamGeminiTts(appCtx, chunkText, voiceName, budgetStart) { pcm ->
                            if (!isActive || !isSpeakingNow) {
                                false
                            } else {
                                if (track == null) {
                                    val opened = openStreamingAudioTrack24kHz(appCtx)
                                    track = opened?.first
                                    totalFramesWritten += opened?.second ?: 0L
                                    activeAudioTrack = track
                                }
                                val at = track
                                if (at != null) {
                                    val preparedPcm = if (isFirstSpeechChunk) {
                                        isFirstSpeechChunk = false
                                        applyLeadingFadeIn16BitMono(pcm)
                                    } else {
                                        pcm
                                    }
                                    val frames = writePcmChunkWithVisualizer(at, preparedPcm)
                                    if (frames > 0L) {
                                        totalFramesWritten += frames
                                        playedSuccessfully = true
                                        true
                                    } else {
                                        false
                                    }
                                } else {
                                    false
                                }
                            }
                        }
                        if (streamed) continue
                        if (!isActive || !isSpeakingNow) break

                        val pcmData = fetchGeminiTtsPcmWithRetry(appCtx, chunkText, voiceName, budgetStart)
                        if (pcmData != null && pcmData.size > 400 && isActive && isSpeakingNow) {
                            if (track == null) {
                                val opened = openStreamingAudioTrack24kHz(appCtx)
                                track = opened?.first
                                totalFramesWritten += opened?.second ?: 0L
                                activeAudioTrack = track
                            }
                            val activeAt = track
                            if (activeAt != null) {
                                val preparedPcm = if (isFirstSpeechChunk) {
                                    isFirstSpeechChunk = false
                                    applyLeadingFadeIn16BitMono(pcmData)
                                } else {
                                    pcmData
                                }
                                val frames = writePcmChunkWithVisualizer(activeAt, preparedPcm)
                                if (frames > 0L) {
                                    totalFramesWritten += frames
                                    playedSuccessfully = true
                                }
                            }
                        } else if (!playedSuccessfully) {
                            // Если первый же кусок не удалось озвучить в пределах бюджета — сразу переходим на встроенный голос
                            break
                        }
                    }
                }

                // Дожидаемся, пока буфер AudioTrack полностью доиграет хвост фразы перед stop()/release()
                val finalTrack = track
                if (playedSuccessfully && finalTrack != null && isActive && isSpeakingNow) {
                    awaitAudioTrackDrain(finalTrack, totalFramesWritten)
                }

                // Если живой облачный Gemini TTS не ответил или исчерпаны лимиты — сразу подстраховываем системным голосом ТВ
                if (!playedSuccessfully && isActive && isSpeakingNow && !isTextQuotaMessage) {
                    val safeErr = GeminiKeyPool.sanitize(lastTtsError)
                    val isRateLimited = safeErr.contains("429") ||
                        safeErr.contains("RESOURCE_EXHAUSTED") ||
                        GeminiKeyPool.nextAvailableInMs(appCtx, GeminiKeyPool.Kind.TTS)?.let { it > 0L } == true
                    if (isRateLimited) {
                        maybeShowRateLimitToast(appCtx)
                    } else if (safeErr.isNotEmpty()) {
                        mainHandler.post {
                            try {
                                Toast.makeText(appCtx, "Gemini TTS: " + safeErr, Toast.LENGTH_LONG).show()
                            } catch (_: Exception) {
                            }
                        }
                    }
                    playedSuccessfully = speakWithAndroidFallbackBlocking(appCtx, cleanText)
                }
            } catch (_: Exception) {
            } finally {
                nextChunkPrefetch?.cancel()
                try {
                    track?.stop()
                } catch (_: Exception) {
                }
                try {
                    track?.release()
                } catch (_: Exception) {
                }
                // Старая (отменённая) задача не должна сбрасывать состояние новой озвучки
                if (speakJob === selfJob) {
                    activeAudioTrack = null
                    isSpeakingNow = false
                    currentVoiceWaveLevel = 0.35f
                    abandonAudioFocus(appCtx)
                }
                if (isActive) {
                    val didPlay = playedSuccessfully
                    onFinished?.let { cb ->
                        mainHandler.post { cb.invoke(didPlay) }
                    }
                }
            }
        }
    }

    private suspend fun speakWithAndroidFallbackBlocking(context: Context, text: String): Boolean {
        return try {
            requestTransientAudioDucking(context)
            var tts = fallbackSystemTts
            if (tts == null) {
                var initDone = false
                tts = TextToSpeech(context.applicationContext) { status ->
                    fallbackTtsReady = (status == TextToSpeech.SUCCESS)
                    initDone = true
                }
                fallbackSystemTts = tts
                var waited = 0
                while (!initDone && waited < 25) {
                    delay(80L)
                    waited++
                }
            }
            if (fallbackTtsReady && tts != null) {
                tts.language = Locale("ru", "RU")
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mitv_fallback_utt")
                val estMs = (1200L + text.length * 68L).coerceIn(1500L, 9000L)
                var elapsed = 0L
                while (isSpeakingNow && elapsed < estMs) {
                    currentVoiceWaveLevel = if ((elapsed / 160L) % 2L == 0L) 0.72f else 0.38f
                    delay(160L)
                    elapsed += 160L
                }
                true
            } else {
                false
            }
        } catch (_: Exception) {
            false
        }
    }

    fun stop(context: Context? = null, preservePrefetch: Boolean = false) {
        if (!preservePrefetch) {
            prefetchedSentenceJob?.cancel()
            prefetchedSentenceJob = null
            prefetchedSentenceText = null
        }
        speakJob?.cancel()
        speakJob = null
        isSpeakingNow = false
        currentVoiceWaveLevel = 0.35f
        try {
            fallbackSystemTts?.stop()
        } catch (_: Exception) {
        }
        val runningTrack = activeAudioTrack
        activeAudioTrack = null
        if (runningTrack != null) {
            try {
                runningTrack.pause()
                runningTrack.flush()
            } catch (_: Exception) {
            }
            try {
                runningTrack.release()
            } catch (_: Exception) {
            }
        }
        if (context != null) {
            abandonAudioFocus(context.applicationContext)
        }
    }

    /**
     * Вырезает WAV/RIFF заголовок любой длины (ищет секцию "data", чтобы метаданные заголовка
     * никогда не попадали в AudioTrack как щелчок или писк в начале).
     */
    /**
     * Вырезает WAV/RIFF заголовок любой длины и отсекает служебные метаданные в конце (LIST, INFO, SynthID),
     * чтобы они никогда не проигрывались как цифровой треск в конце фраз!
     */
    private fun stripWavHeaderIfPresent(rawBytes: ByteArray): ByteArray {
        if (rawBytes.size <= 44) return rawBytes
        if (rawBytes[0] == 0x52.toByte() && rawBytes[1] == 0x49.toByte() &&
            rawBytes[2] == 0x46.toByte() && rawBytes[3] == 0x46.toByte()
        ) {
            val searchLimit = minOf(rawBytes.size - 8, 512)
            var pos = 12
            while (pos <= searchLimit) {
                if (rawBytes[pos] == 0x64.toByte() &&
                    rawBytes[pos + 1] == 0x61.toByte() &&
                    rawBytes[pos + 2] == 0x74.toByte() &&
                    rawBytes[pos + 3] == 0x61.toByte()
                ) {
                    val dataSize = ByteBuffer.wrap(rawBytes, pos + 4, 4).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xFFFFFFFFL
                    val dataStart = pos + 8
                    if (dataStart < rawBytes.size) {
                        val availableData = rawBytes.size - dataStart
                        val effectiveLen = if (dataSize in 1L..availableData) dataSize.toInt() else availableData
                        val clean = rawBytes.copyOfRange(dataStart, dataStart + effectiveLen)
                        return if (clean.size % 2 == 1) clean.copyOfRange(0, clean.size - 1) else clean
                    }
                }
                pos++
            }
            val fallback = rawBytes.copyOfRange(44, rawBytes.size)
            return if (fallback.size % 2 == 1) fallback.copyOfRange(0, fallback.size - 1) else fallback
        }
        return if (rawBytes.size % 2 == 1) rawBytes.copyOfRange(0, rawBytes.size - 1) else rawBytes
    }

    /**
     * Мягкий 20 мс fade-out в конце аудиоданных предотвращает щелчок/треск при обрыве амплитуды.
     */
    private fun applyTrailingFadeOut16BitMono(pcmBytes: ByteArray): ByteArray {
        val totalSamples = pcmBytes.size / 2
        val fadeSamples = minOf(totalSamples, 480) // 20 мс при 24 кГц
        if (fadeSamples <= 0) return pcmBytes
        val out = pcmBytes.copyOf()
        val bb = ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN)
        val startSample = totalSamples - fadeSamples
        for (i in 0 until fadeSamples) {
            val idx = (startSample + i) * 2
            val orig = bb.getShort(idx).toInt()
            val factor = (fadeSamples - i).toDouble() / fadeSamples.toDouble()
            val scaled = (orig * factor).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            bb.putShort(idx, scaled)
        }
        return out
    }

    /**
     * Мягкий 15 мс fade-in на самом первом куске речи убирает любой начальный щелчок/хрип ЦАП.
     */
    private fun applyLeadingFadeIn16BitMono(pcmBytes: ByteArray): ByteArray {
        val totalSamples = pcmBytes.size / 2
        val fadeSamples = minOf(totalSamples, 360) // 15 мс при 24 кГц
        if (fadeSamples <= 0) return pcmBytes
        val out = pcmBytes.copyOf()
        val bb = ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until fadeSamples) {
            val orig = bb.getShort(i * 2).toInt()
            val scaled = ((orig * i) / fadeSamples).coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            bb.putShort(i * 2, scaled)
        }
        return out
    }

    private fun buildOrderedTtsModels(includeNoStreamFilter: Boolean): List<String> {
        val ordered = mutableListOf<String>()
        val cached = cachedTtsModel
        if (cached != null && !unavailableTtsModels.contains(cached) && (!includeNoStreamFilter || !noStreamModels.contains(cached))) {
            ordered.add(cached)
        }
        for (m in ttsModels) {
            if (m != cached && !unavailableTtsModels.contains(m) && (!includeNoStreamFilter || !noStreamModels.contains(m))) {
                ordered.add(m)
            }
        }
        return ordered
    }

    /**
     * Потоковый запрос Gemini TTS (streamGenerateContent, SSE) с двухуровневым перебором:
     * внешний цикл — по ключам пула (до 3 попыток), внутренний — по моделям.
     * При 429 меняет ключ с той же моделью; при 404/400 меняет модель с тем же ключом.
     */
    private fun streamGeminiTts(
        context: Context,
        textToSpeak: String,
        voiceName: String,
        budgetStartElapsedMs: Long,
        onPcm: (ByteArray) -> Boolean
    ): Boolean {
        val appCtx = context.applicationContext
        val orderedModels = buildOrderedTtsModels(includeNoStreamFilter = true)
        if (orderedModels.isEmpty()) return false

        val payload = JSONObject().apply {
            put("contents", JSONArray().put(
                JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", textToSpeak)))
                }
            ))
            put("generationConfig", JSONObject().apply {
                put("responseModalities", JSONArray().put("AUDIO"))
                put("speechConfig", JSONObject().apply {
                    put("voiceConfig", JSONObject().apply {
                        put("prebuiltVoiceConfig", JSONObject().apply {
                            put("voiceName", voiceName)
                        })
                    })
                })
            })
        }.toString()

        val triedFingerprints = HashSet<String>()
        var lease = GeminiKeyPool.acquire(appCtx, GeminiKeyPool.Kind.TTS, triedFingerprints)
        if (lease == null) {
            lastTtsError = "HTTP 429: все ключи TTS на паузе"
            return false
        }

        var keyAttempts = 1
        var modelIdx = 0

        while (lease != null && modelIdx < orderedModels.size) {
            if (SystemClock.elapsedRealtime() - budgetStartElapsedMs >= TTS_FIRST_SOUND_BUDGET_MS) {
                break
            }
            val currentLease = lease
            val model = orderedModels[modelIdx]
            if (noStreamModels.contains(model)) {
                modelIdx++
                continue
            }

            var conn: HttpURLConnection? = null
            var delivered = false
            try {
                val useQueryKey = currentLease.apiKey.startsWith("AIza")
                val urlStr = if (useQueryKey) {
                    "https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse&key=${Uri.encode(currentLease.apiKey)}"
                } else {
                    "https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse"
                }
                val connection = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 4000
                    readTimeout = 10000
                    doOutput = true
                    doInput = true
                    useCaches = false
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Accept-Encoding", "identity")
                    if (!useQueryKey) {
                        setRequestProperty("x-goog-api-key", currentLease.apiKey)
                    }
                }
                conn = connection
                connection.outputStream.use { os ->
                    os.write(payload.toByteArray(Charsets.UTF_8))
                    os.flush()
                }
                val code = connection.responseCode
                if (code !in 200..299) {
                    val errBody = try {
                        connection.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                    } catch (_: Exception) {
                        ""
                    }
                    val safeErrBody = GeminiKeyPool.sanitize(errBody)
                    lastTtsError = "$model (${currentLease.label} stream): HTTP $code " + safeErrBody.replace("\n", " ").take(140)
                    Log.w("GeminiTTS", lastTtsError)

                    val outcome = GeminiKeyPool.classifyHttpError(code, safeErrBody)
                    GeminiKeyPool.report(appCtx, currentLease, outcome)

                    when (outcome) {
                        is GeminiKeyPool.Outcome.ModelError -> {
                            if (code == 404 || code == 501) unavailableTtsModels.add(model)
                            markNoStreamModel(appCtx, model)
                            modelIdx++
                        }
                        is GeminiKeyPool.Outcome.RateLimited,
                        is GeminiKeyPool.Outcome.KeyDead,
                        is GeminiKeyPool.Outcome.NetworkError -> {
                            if (keyAttempts >= MAX_KEY_ATTEMPTS) break
                            triedFingerprints.add(currentLease.fingerprint)
                            lease = GeminiKeyPool.acquire(appCtx, GeminiKeyPool.Kind.TTS, triedFingerprints)
                            keyAttempts++
                        }
                        else -> modelIdx++
                    }
                    continue
                }

                connection.inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
                    var firstPiece = true
                    var carryByte: Byte? = null
                    var stopped = false
                    while (!stopped) {
                        val line = reader.readLine() ?: break
                        if (!line.startsWith("data:")) continue
                        val json = line.substring(5).trim()
                        if (json.isEmpty() || json == "[DONE]") continue
                        val parts = JSONObject(json).optJSONArray("candidates")
                            ?.optJSONObject(0)
                            ?.optJSONObject("content")
                            ?.optJSONArray("parts") ?: continue
                        for (i in 0 until parts.length()) {
                            val b64 = parts.optJSONObject(i)?.optJSONObject("inlineData")?.optString("data", "") ?: ""
                            if (b64.isBlank()) continue
                            var data = Base64.decode(b64, Base64.DEFAULT)
                            if (firstPiece) {
                                firstPiece = false
                                data = stripWavHeaderIfPresent(data)
                            }
                            val c = carryByte
                            if (c != null) {
                                data = byteArrayOf(c) + data
                                carryByte = null
                            }
                            if (data.size % 2 == 1) {
                                carryByte = data[data.size - 1]
                                data = data.copyOfRange(0, data.size - 1)
                            }
                            if (data.isEmpty()) continue
                            delivered = true
                            saveCachedTtsModel(appCtx, model)
                            if (!onPcm(data)) {
                                stopped = true
                                break
                            }
                        }
                    }
                }

                if (delivered) {
                    GeminiKeyPool.report(appCtx, currentLease, GeminiKeyPool.Outcome.Ok)
                    return true
                }
                lastTtsError = "$model (${currentLease.label} stream): нет аудио в ответе"
                markNoStreamModel(appCtx, model)
                modelIdx++
            } catch (e: Exception) {
                if (delivered) {
                    GeminiKeyPool.report(appCtx, currentLease, GeminiKeyPool.Outcome.Ok)
                    return true
                }
                val safeMsg = GeminiKeyPool.sanitize(e.message)
                lastTtsError = "$model (${currentLease.label} stream): " + e.javaClass.simpleName + " " + safeMsg.take(90)
                Log.w("GeminiTTS", lastTtsError)
                GeminiKeyPool.report(appCtx, currentLease, GeminiKeyPool.Outcome.NetworkError)
                if (keyAttempts >= MAX_KEY_ATTEMPTS) break
                triedFingerprints.add(currentLease.fingerprint)
                lease = GeminiKeyPool.acquire(appCtx, GeminiKeyPool.Kind.TTS, triedFingerprints)
                keyAttempts++
            } finally {
                try {
                    conn?.disconnect()
                } catch (_: Exception) {
                }
            }
        }
        return false
    }

    private suspend fun fetchGeminiTtsPcmWithRetry(
        context: Context,
        textToSpeak: String,
        voiceName: String,
        budgetStartElapsedMs: Long
    ): ByteArray? {
        for (attempt in 0 until 2) {
            if (SystemClock.elapsedRealtime() - budgetStartElapsedMs >= TTS_FIRST_SOUND_BUDGET_MS) break
            val pcm = fetchGeminiTtsPcmOnce(context, textToSpeak, voiceName, budgetStartElapsedMs)
            if (pcm != null && pcm.size > 400) return pcm
            if (attempt == 0 && SystemClock.elapsedRealtime() - budgetStartElapsedMs < TTS_FIRST_SOUND_BUDGET_MS - 500L) {
                delay(250L)
            }
        }
        return null
    }

    private fun fetchGeminiTtsPcmOnce(
        context: Context,
        textToSpeak: String,
        voiceName: String,
        budgetStartElapsedMs: Long
    ): ByteArray? {
        val appCtx = context.applicationContext
        val orderedModels = buildOrderedTtsModels(includeNoStreamFilter = false)
        if (orderedModels.isEmpty()) return null

        val payload = JSONObject().apply {
            put("contents", JSONArray().put(
                JSONObject().apply {
                    put("parts", JSONArray().put(
                        JSONObject().put("text", textToSpeak)
                    ))
                }
            ))
            put("generationConfig", JSONObject().apply {
                put("responseModalities", JSONArray().put("AUDIO"))
                put("speechConfig", JSONObject().apply {
                    put("voiceConfig", JSONObject().apply {
                        put("prebuiltVoiceConfig", JSONObject().apply {
                            put("voiceName", voiceName)
                        })
                    })
                })
            })
        }.toString()

        val triedFingerprints = HashSet<String>()
        var lease = GeminiKeyPool.acquire(appCtx, GeminiKeyPool.Kind.TTS, triedFingerprints)
        if (lease == null) {
            lastTtsError = "HTTP 429: все ключи TTS на паузе"
            return null
        }

        var keyAttempts = 1
        var modelIdx = 0

        while (lease != null && modelIdx < orderedModels.size) {
            if (SystemClock.elapsedRealtime() - budgetStartElapsedMs >= TTS_FIRST_SOUND_BUDGET_MS) {
                break
            }
            val currentLease = lease
            val model = orderedModels[modelIdx]
            var conn: HttpURLConnection? = null
            try {
                val useQueryKey = currentLease.apiKey.startsWith("AIza")
                val urlStr = if (useQueryKey) {
                    "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=${Uri.encode(currentLease.apiKey)}"
                } else {
                    "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
                }
                val connection = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 4000
                    readTimeout = 10000
                    doOutput = true
                    doInput = true
                    useCaches = false
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    if (!useQueryKey) {
                        setRequestProperty("x-goog-api-key", currentLease.apiKey)
                    }
                }
                conn = connection
                connection.outputStream.use { os ->
                    os.write(payload.toByteArray(Charsets.UTF_8))
                    os.flush()
                }
                val code = connection.responseCode
                if (code in 200..299) {
                    val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    val root = JSONObject(body)
                    val parts = root.optJSONArray("candidates")
                        ?.optJSONObject(0)
                        ?.optJSONObject("content")
                        ?.optJSONArray("parts")
                    if (parts != null) {
                        for (i in 0 until parts.length()) {
                            val inlineData = parts.optJSONObject(i)?.optJSONObject("inlineData") ?: continue
                            val b64 = inlineData.optString("data", "")
                            if (b64.isNotBlank()) {
                                GeminiKeyPool.report(appCtx, currentLease, GeminiKeyPool.Outcome.Ok)
                                saveCachedTtsModel(appCtx, model)
                                val rawBytes = Base64.decode(b64, Base64.DEFAULT)
                                val pcm = stripWavHeaderIfPresent(rawBytes)
                                val evenPcm = if (pcm.size % 2 == 1) pcm.copyOfRange(0, pcm.size - 1) else pcm
                                return applyTrailingFadeOut16BitMono(evenPcm)
                            }
                        }
                    }
                    lastTtsError = "$model (${currentLease.label}): нет аудио в ответе"
                    modelIdx++
                } else {
                    val errBody = try {
                        connection.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                    } catch (_: Exception) {
                        ""
                    }
                    val safeErrBody = GeminiKeyPool.sanitize(errBody)
                    lastTtsError = "$model (${currentLease.label}): HTTP $code " + safeErrBody.replace("\n", " ").take(140)
                    Log.w("GeminiTTS", lastTtsError)

                    val outcome = GeminiKeyPool.classifyHttpError(code, safeErrBody)
                    GeminiKeyPool.report(appCtx, currentLease, outcome)

                    when (outcome) {
                        is GeminiKeyPool.Outcome.ModelError -> {
                            if (code == 404 || code == 501) unavailableTtsModels.add(model)
                            modelIdx++
                        }
                        is GeminiKeyPool.Outcome.RateLimited,
                        is GeminiKeyPool.Outcome.KeyDead,
                        is GeminiKeyPool.Outcome.NetworkError -> {
                            if (keyAttempts >= MAX_KEY_ATTEMPTS) break
                            triedFingerprints.add(currentLease.fingerprint)
                            lease = GeminiKeyPool.acquire(appCtx, GeminiKeyPool.Kind.TTS, triedFingerprints)
                            keyAttempts++
                        }
                        else -> modelIdx++
                    }
                }
            } catch (e: Exception) {
                try {
                    conn?.disconnect()
                } catch (_: Exception) {
                }
                val safeMsg = GeminiKeyPool.sanitize(e.message)
                lastTtsError = "$model (${currentLease.label}): " + e.javaClass.simpleName + " " + safeMsg.take(90)
                Log.w("GeminiTTS", lastTtsError)
                GeminiKeyPool.report(appCtx, currentLease, GeminiKeyPool.Outcome.NetworkError)
                if (keyAttempts >= MAX_KEY_ATTEMPTS) break
                triedFingerprints.add(currentLease.fingerprint)
                lease = GeminiKeyPool.acquire(appCtx, GeminiKeyPool.Kind.TTS, triedFingerprints)
                keyAttempts++
            }
        }
        return null
    }

    /**
     * Открывает AudioTrack (24 кГц, 16 бит, моно) и сразу подаёт 160 мс тишины (3840 кадров = 7680 байт)
     * перед стартом воспроизведения, чтобы аудиотракт ТВ / HDMI успел проснуться без хрипа и съедания начала.
     */
    private fun openStreamingAudioTrack24kHz(context: Context): Pair<AudioTrack, Long>? {
        val sampleRate = 24000
        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(4800)

        return try {
            requestTransientAudioDucking(context)
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            val format = AudioFormat.Builder()
                .setSampleRate(sampleRate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()
            val track = AudioTrack(
                attrs,
                format,
                (minBuf * 2).coerceAtLeast(48000),
                AudioTrack.MODE_STREAM,
                AudioManager.AUDIO_SESSION_ID_GENERATE
            )
            // 160 мс тишины (3840 сэмплов = 7680 байт) до первого куска речи
            val leadInSilence = ByteArray(7680)
            val preWritten = track.write(leadInSilence, 0, leadInSilence.size).coerceAtLeast(0)
            track.play()
            Pair(track, (preWritten / 2).toLong())
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Записывает PCM-данные в AudioTrack и возвращает точное число записанных кадров (1 кадр = 2 байта).
     */
    @Volatile
    private var firstAudioLoggedThisSpeak = false

    private fun writePcmChunkWithVisualizer(at: AudioTrack, pcmBytes: ByteArray): Long {
        if (!firstAudioLoggedThisSpeak) {
            firstAudioLoggedThisSpeak = true
            GeminiCloudClient.logTiming("tts_first_audio_written")
        }
        return try {
            val chunkSize = 1920 // 40 мс при 24000 Гц (16 бит моно)
            var offset = 0
            var totalWrittenBytes = 0L
            while (offset < pcmBytes.size && isSpeakingNow) {
                val len = (pcmBytes.size - offset).coerceAtMost(chunkSize)
                val samplesCount = len / 2
                if (samplesCount > 0) {
                    var sumSq = 0.0
                    val bb = ByteBuffer.wrap(pcmBytes, offset, len).order(ByteOrder.LITTLE_ENDIAN)
                    for (s in 0 until samplesCount) {
                        val v = bb.short.toDouble()
                        sumSq += v * v
                    }
                    val rms = sqrt(sumSq / samplesCount)
                    val normalized = (0.24 + (rms / 6500.0) * 0.76).coerceIn(0.24, 1.0).toFloat()
                    currentVoiceWaveLevel = normalized
                }
                val written = at.write(pcmBytes, offset, len)
                if (written <= 0) break
                offset += written
                totalWrittenBytes += written
            }
            totalWrittenBytes / 2L
        } catch (_: Exception) {
            0L
        }
    }

    /**
     * Дожидается полного проигрывания буфера AudioTrack до targetFrames перед вызовом stop()/release(),
     * чтобы конец фразы никогда не обрезался.
     */
    private suspend fun awaitAudioTrackDrain(at: AudioTrack, speechFramesWritten: Long) {
        if (speechFramesWritten <= 0L) return
        try {
            // Плавное затухание 20 мс (480 сэмплов = 960 байт) + тишина гарантируют полное отсутствие треска в конце!
            val fadeOutChunk = ByteArray(960)
            at.write(fadeOutChunk, 0, fadeOutChunk.size)
            val tailSilence = ByteArray(7680)
            at.write(tailSilence, 0, tailSilence.size)

            val startHead = at.playbackHeadPosition.toLong() and 0xFFFFFFFFL
            val remainingFrames = (speechFramesWritten - startHead).coerceAtLeast(0L)
            val maxWaitMs = ((remainingFrames * 1000L) / 24000L + 650L).coerceIn(350L, 2400L)

            var waitedMs = 0L
            var lastHead = startHead
            var stalledMs = 0L

            while (isSpeakingNow && waitedMs < maxWaitMs) {
                val currentHead = at.playbackHeadPosition.toLong() and 0xFFFFFFFFL
                if (currentHead >= speechFramesWritten) break
                if (currentHead > lastHead) {
                    lastHead = currentHead
                    stalledMs = 0L
                } else {
                    stalledMs += 25L
                    if (stalledMs >= 350L) break
                }
                currentVoiceWaveLevel = 0.28f
                delay(25L)
                waitedMs += 25L
            }
        } catch (_: Exception) {
        }
    }

    private fun requestTransientAudioDucking(context: Context) {
        try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
                val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(attrs)
                    .setAcceptsDelayedFocusGain(false)
                    .setWillPauseWhenDucked(false)
                    .build()
                currentAudioFocusRequest = req
                am.requestAudioFocus(req)
            } else {
                @Suppress("DEPRECATION")
                am.requestAudioFocus(
                    null,
                    AudioManager.STREAM_MUSIC,
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
                )
            }
        } catch (_: Exception) {
        }
    }

    private fun abandonAudioFocus(context: Context) {
        try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                currentAudioFocusRequest?.let { am.abandonAudioFocusRequest(it) }
                currentAudioFocusRequest = null
            } else {
                @Suppress("DEPRECATION")
                am.abandonAudioFocus(null)
            }
        } catch (_: Exception) {
        }
    }
}
