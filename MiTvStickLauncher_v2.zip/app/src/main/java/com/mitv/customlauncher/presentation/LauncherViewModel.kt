package com.mitv.customlauncher.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mitv.customlauncher.R
import com.mitv.customlauncher.data.AppLauncher
import com.mitv.customlauncher.data.AssistantEngine
import com.mitv.customlauncher.data.AssistantState
import com.mitv.customlauncher.data.CardSlot
import com.mitv.customlauncher.data.ClockFormatter
import com.mitv.customlauncher.data.FakeAssistantEngine
import com.mitv.customlauncher.data.InstalledAppInfo
import com.mitv.customlauncher.data.LauncherConfig
import com.mitv.customlauncher.data.NetworkMonitor
import com.mitv.customlauncher.data.NetworkStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Calendar

data class LauncherUiState(
    val timeText: String = "00:00:00",
    val dateText: String = "",
    val networkStatus: NetworkStatus = NetworkStatus.Disconnected,
    val assistantState: AssistantState = AssistantState.Idle,
    val isOverlayVisible: Boolean = false,
    val slot1App: InstalledAppInfo? = null,
    val slot2App: InstalledAppInfo? = null,
    val slot3App: InstalledAppInfo? = null,
    val slot4App: InstalledAppInfo? = null,
    val installedApps: List<InstalledAppInfo> = emptyList()
)

sealed interface LauncherUiEvent {
    data class ShowToastRes(val stringResId: Int) : LauncherUiEvent
    data class ShowBoundToast(val appLabel: String) : LauncherUiEvent
    data class OpenAppAssignPicker(val slot: CardSlot) : LauncherUiEvent
    data object RequestAudioPermission : LauncherUiEvent
    data object RestoreFocusToAiCard : LauncherUiEvent
    data object RestoreFocusToYoutubeCard : LauncherUiEvent
}

class LauncherViewModel(
    private val appLauncher: AppLauncher,
    private val networkMonitor: NetworkMonitor,
    demoReplyText: String
) : ViewModel() {

    private val assistantEngine: AssistantEngine = FakeAssistantEngine(viewModelScope, demoReplyText)

    private val _uiState = MutableStateFlow(LauncherUiState())
    val uiState: StateFlow<LauncherUiState> = _uiState.asStateFlow()

    private val _events = MutableSharedFlow<LauncherUiEvent>(extraBufferCapacity = 4)
    val events: SharedFlow<LauncherUiEvent> = _events.asSharedFlow()

    private var lastDayOfYear: Int = -1
    private var autoHideJob: Job? = null

    init {
        refreshTimeAndDate(forceDate = true)
        reloadInstalledApps()
    }

    fun reloadInstalledApps() {
        viewModelScope.launch {
            val allApps = withContext(Dispatchers.IO) {
                appLauncher.getInstalledApps()
            }
            val s1 = appLauncher.getBoundAppForSlot(CardSlot.SLOT_1, allApps)
            val s2 = appLauncher.getBoundAppForSlot(CardSlot.SLOT_2, allApps)
            val s3 = appLauncher.getBoundAppForSlot(CardSlot.SLOT_3, allApps)
            val s4 = appLauncher.getBoundAppForSlot(CardSlot.SLOT_4, allApps)
            _uiState.update {
                it.copy(
                    installedApps = allApps,
                    slot1App = s1,
                    slot2App = s2,
                    slot3App = s3,
                    slot4App = s4
                )
            }
        }
    }

    fun refreshTimeAndDate(forceDate: Boolean = false) {
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance().apply { timeInMillis = now }
        val dayOfYear = cal.get(Calendar.DAY_OF_YEAR)
        val shouldUpdateDate = forceDate || (dayOfYear != lastDayOfYear)
        if (shouldUpdateDate) {
            lastDayOfYear = dayOfYear
        }
        _uiState.update { current ->
            current.copy(
                timeText = ClockFormatter.formatTime24(now),
                dateText = if (shouldUpdateDate) ClockFormatter.formatDate(now) else current.dateText
            )
        }
    }

    fun observeNetworkInForeground() = networkMonitor.observeNetworkStatus()

    fun updateNetworkStatus(status: NetworkStatus) {
        _uiState.update { it.copy(networkStatus = status) }
    }

    fun onSlotCardClicked(slot: CardSlot) {
        val state = _uiState.value
        val boundApp = when (slot) {
            CardSlot.SLOT_1 -> state.slot1App
            CardSlot.SLOT_2 -> state.slot2App
            CardSlot.SLOT_3 -> state.slot3App
            CardSlot.SLOT_4 -> state.slot4App
        }
        if (boundApp == null) {
            _events.tryEmit(LauncherUiEvent.OpenAppAssignPicker(slot))
            return
        }
        val launched = appLauncher.launchPackage(boundApp.packageName)
        if (!launched) {
            reloadInstalledApps()
            _events.tryEmit(LauncherUiEvent.OpenAppAssignPicker(slot))
        }
    }

    fun assignAppToSlot(slot: CardSlot, app: InstalledAppInfo) {
        appLauncher.bindAppToSlot(slot, app.packageName)
        _uiState.update { current ->
            when (slot) {
                CardSlot.SLOT_1 -> current.copy(slot1App = app)
                CardSlot.SLOT_2 -> current.copy(slot2App = app)
                CardSlot.SLOT_3 -> current.copy(slot3App = app)
                CardSlot.SLOT_4 -> current.copy(slot4App = app)
            }
        }
        _events.tryEmit(LauncherUiEvent.ShowBoundToast(app.label))
    }

    fun launchAppDirectly(app: InstalledAppInfo) {
        val ok = appLauncher.launchPackage(app.packageName)
        if (!ok) {
            _events.tryEmit(LauncherUiEvent.ShowToastRes(R.string.err_app_launch_failed))
        }
    }

    fun launchSystemSettings() {
        val opened = appLauncher.launchSystemSettings()
        if (!opened) {
            _events.tryEmit(LauncherUiEvent.ShowToastRes(R.string.err_settings_unavailable))
        }
    }

    fun onAssistantTrigger(hasAudioPermission: Boolean) {
        if (!hasAudioPermission) {
            _events.tryEmit(LauncherUiEvent.RequestAudioPermission)
            return
        }
    }

    fun closeAssistantOverlay(restoreFocusToAi: Boolean) {
        autoHideJob?.cancel()
        assistantEngine.cancelSession()
        _uiState.update { it.copy(isOverlayVisible = false) }
    }

    fun onHomeIntentReceived() {
        if (_uiState.value.isOverlayVisible) {
            closeAssistantOverlay(restoreFocusToAi = false)
        }
        _events.tryEmit(LauncherUiEvent.RestoreFocusToYoutubeCard)
    }

    class Factory(
        private val appLauncher: AppLauncher,
        private val networkMonitor: NetworkMonitor,
        private val demoReplyText: String
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return LauncherViewModel(appLauncher, networkMonitor, demoReplyText) as T
        }
    }
}
