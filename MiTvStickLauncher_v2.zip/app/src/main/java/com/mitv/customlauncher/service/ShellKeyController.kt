package com.mitv.customlauncher.service

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.SoundPool
import android.media.MediaMetadata
import android.media.MediaRecorder
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Parcelable
import android.os.SystemClock
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.TextUtils
import android.util.Log
import android.util.LruCache
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.content.ClipData
import android.content.ClipboardManager
import java.util.Locale
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import com.mitv.customlauncher.R
import com.mitv.customlauncher.data.AssistantVoiceSpeaker
import com.mitv.customlauncher.data.GeminiCloudClient
import com.mitv.customlauncher.data.GeminiTurnResult
import com.mitv.customlauncher.data.LauncherConfig
import com.mitv.customlauncher.data.NativeCore
import com.mitv.customlauncher.data.LocalVoiceCommandRouter
import com.mitv.customlauncher.ui.EchoView
import com.mitv.customlauncher.ui.LauncherActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import org.json.JSONObject
import android.net.wifi.WifiManager
import android.os.PowerManager
import java.net.InetAddress
import java.net.InetSocketAddress
import com.mitv.customlauncher.data.TuyaSmartHomeController
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.net.URLEncoder
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sin
import kotlin.math.sqrt


/**
 * Глобальный ультра-быстрый движок кастомного звука переключения (SoundPool < 1 мс)
 * Работает по всей приставке (в лаунчере и поверх всех приложений)!
 */

/**
 * Локальный сервер-приёмник команд со смартфона-пульта «Smart Touch Console» (Huawei Y5):
 * - Слушает порт 8765 по HTTP GET/POST и UDP (отклик < 2 мс в домашней Wi-Fi сети)
 * - /status или /ping -> возвращает JSON со статусом экрана ТВ (isInteractive / state) и подсветки Tuya
 * - /key?k=DPAD_UP|DPAD_DOWN|DPAD_LEFT|DPAD_RIGHT|DPAD_CENTER|BACK|HOME|VOL_UP|VOL_DOWN|PLAY_PAUSE|VOICE_ASSIST
 * - /app?pkg=com.google.android.youtube.tv (или youtube / kick / browser)
 * - /voice?text=... -> мгновенно открывает оверлей Gemini AI на экране телевизора с переданным запросом
 * - /light?power=true|false или /light?preset=cyber|sapphire|violet|raspberry|sunset|warm
 */
object ShellKeyController {
    private var process: Process? = null
    private var writer: BufferedWriter? = null

    init {
        try {
            process = ProcessBuilder("sh").start()
            writer = process?.outputStream?.bufferedWriter()
            writer?.write("settings put global wifi_sleep_policy 2\n")
            writer?.write("settings put global stay_on_while_plugged_in 7\n")
            writer?.write("settings put global adaptive_battery_management_enabled 0\n")
            writer?.write("settings put global app_standby_enabled 0\n")
            writer?.write("dumpsys deviceidle whitelist +com.mitv.customlauncher\n")
            writer?.write("dumpsys deviceidle whitelist +com.google.android.tv.remote.service\n")
            writer?.write("dumpsys deviceidle whitelist +com.google.android.tv.remote\n")
            writer?.write("cmd appops set com.google.android.tv.remote.service RUN_IN_BACKGROUND allow\n")
            writer?.write("cmd appops set com.google.android.tv.remote.service RUN_ANY_IN_BACKGROUND allow\n")
            writer?.write("dumpsys deviceidle disable\n")
            writer?.flush()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @Synchronized
    fun sendKeyEvent(keyCode: Int) {
        try {
            if (writer == null) {
                process = ProcessBuilder("sh").start()
                writer = process?.outputStream?.bufferedWriter()
            }
            writer?.write("input keyevent $keyCode\n")
            writer?.flush()
        } catch (e: Exception) {
            try {
                process?.destroy()
                process = ProcessBuilder("sh").start()
                writer = process?.outputStream?.bufferedWriter()
                writer?.write("input keyevent $keyCode\n")
                writer?.flush()
            } catch (_: Exception) {
            }
        }
    }
}
