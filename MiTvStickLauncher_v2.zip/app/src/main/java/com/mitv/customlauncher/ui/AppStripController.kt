package com.mitv.customlauncher.ui

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.graphics.PorterDuff
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.PathInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import com.mitv.customlauncher.data.InstalledAppInfo
import com.mitv.customlauncher.data.NativeCore

/**
 * Лента приложений на главном экране с плавной физикой переключения (Cubic-Bezier)
 * и мягким возвратом к первой плитке по кнопке «Домой».
 */
class AppStripController(
    private val parent: ConstraintLayout,
    private val cards: List<View>,
    private val icons: List<ImageView>,
    private val titles: List<TextView>,
    private val defaultTitleRes: List<Int>,
    private val bind: (InstalledAppInfo?, ImageView, TextView, View, Int) -> Unit,
    private val focusIconColor: () -> Int = { titles[0].currentTextColor }
) {
    private class CloneCard(val root: LinearLayout, val icon: ImageView, val title: TextView)

    private companion object {
        const val PILE_MAX = 2
        const val STRIP_SPRING_KEY = 0x53545250
        val STRIP_FAST_PRESET = MotionPhysics.Preset(stiffness = 1300f, damping = 0.92f)
        const val CARD_FOCUS_SCALE = 1.055f
        const val ICON_FOCUS_SCALE = 1.11f
        const val CARD_IDLE_ALPHA = 0.88f
    }

    private val ctx = parent.context
    private val density = ctx.resources.displayMetrics.density

    private fun dp(v: Float): Float = v * density

    private var apps: List<InstalledAppInfo?> = emptyList()
    private var viewsCreated = false
    private var lastW = -1
    private var lastH = -1
    private var animator: ValueAnimator? = null
    private var fadeAnimator: ValueAnimator? = null

    private val pile = Array(2) { arrayOfNulls<View>(PILE_MAX) }
    private val clones = Array(3) { arrayOfNulls<CloneCard>(2) }

    var offset: Int = 0
        private set

    var isAnimating: Boolean = false
        private set

    private var pendingTargetOffset: Int = 0

    private val columnCount: Int
        get() = (apps.size + 1) / 2

    private val maxOffset: Int
        get() = (columnCount - 2).coerceAtLeast(0)

    fun canScrollRight(): Boolean = offset < maxOffset

    fun canScrollLeft(): Boolean = offset > 0

    fun scrollRight(fast: Boolean = false) {
        if (isAnimating) {
            MotionPhysics.cancelCustom(STRIP_SPRING_KEY)
            finishScroll(pendingTargetOffset)
        }
        if (!canScrollRight()) return
        startScroll(1, fast)
    }

    fun scrollLeft(fast: Boolean = false) {
        if (isAnimating) {
            MotionPhysics.cancelCustom(STRIP_SPRING_KEY)
            finishScroll(pendingTargetOffset)
        }
        if (!canScrollLeft()) return
        startScroll(-1, fast)
    }

    /** Упругий отскок от края ленты (Edge Rubber-Band). */
    fun bumpEdge(directionX: Int) {
        if (isAnimating) return
        MotionPhysics.edgeBump(cards, directionX, density)
    }

    /**
     * Плавный анимированный возврат в начало ленты (к первой плитке слота 1) по нажатию Домой/Назад.
     */
    fun scrollToStart(animated: Boolean = true) {
        if (animated && isAnimating && pendingTargetOffset == 0) return

        fadeAnimator?.cancel()
        fadeAnimator = null
        MotionPhysics.cancelCustom(STRIP_SPRING_KEY)
        val runningAnim = animator
        animator = null
        isAnimating = false
        runningAnim?.cancel()

        if (!animated || offset <= 0) {
            offset = 0
            for (card in cards) {
                card.alpha = if (card.hasFocus()) 1f else CARD_IDLE_ALPHA
            }
            endFade()
            render()
            return
        }

        if (offset == 1) {
            startScroll(-1, fast = true, forceFocusSlot = 0)
            return
        }

        startRewindToZero(forceFocusSlot = 0)
    }

    fun appIndexFor(card: View): Int {
        val ci = cards.indexOf(card)
        if (ci < 0) return -1
        return (offset + ci / 2) * 2 + ci % 2
    }

    fun setApps(list: List<InstalledAppInfo?>) {
        apps = list
        if (offset > maxOffset) offset = maxOffset
        render()
    }

    fun cancelAnimation() {
        MotionPhysics.cancelCustom(STRIP_SPRING_KEY)
        animator?.cancel()
    }

    fun render() {
        if (isAnimating) return
        ensureViews()
        val hidden = BooleanArray(4)
        for (ci in 0 until 4) {
            val idx = (offset + ci / 2) * 2 + ci % 2
            hidden[ci] = idx >= 4 && apps.getOrNull(idx) == null
        }
        val focused = cards.indexOfFirst { it.hasFocus() }
        if (focused >= 0 && hidden[focused]) {
            cards[focused xor 1].requestFocus()
        }
        for (ci in 0 until 4) {
            val card = cards[ci]
            if (hidden[ci]) {
                card.visibility = View.INVISIBLE
                card.isFocusable = false
                card.isClickable = false
            } else {
                val idx = (offset + ci / 2) * 2 + ci % 2
                card.visibility = View.VISIBLE
                card.isFocusable = true
                card.isClickable = true
                card.isLongClickable = true
                bind(apps.getOrNull(idx), icons[ci], titles[ci], card, defaultTitleRes[idx.coerceIn(0, 3)])
            }
        }
        layoutPile()
    }

    private fun newLayoutParams(): ConstraintLayout.LayoutParams {
        return ConstraintLayout.LayoutParams(1, 1).apply {
            startToStart = ConstraintLayout.LayoutParams.PARENT_ID
            topToTop = ConstraintLayout.LayoutParams.PARENT_ID
        }
    }

    private fun ensureViews() {
        if (viewsCreated) return
        viewsCreated = true
        // Вместо грубых серых рамок используем деликатный полупрозрачный стеклянный каскад без резких границ
        val glassAlphas = intArrayOf(0x22FFFFFF, 0x10FFFFFF)
        for (r in 0 until 2) {
            for (k in 0 until PILE_MAX) {
                val v = View(ctx)
                v.background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(20f)
                    setColor(0x1810141D)
                    setStroke(dp(1f).toInt().coerceAtLeast(1), glassAlphas[k])
                }
                v.visibility = View.INVISIBLE
                v.isFocusable = false
                v.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                parent.addView(v, 0, newLayoutParams())
                pile[r][k] = v
            }
        }
        for (c in 0 until 3) {
            for (r in 0 until 2) {
                val cc = makeClone()
                parent.addView(cc.root, newLayoutParams())
                clones[c][r] = cc
            }
        }
        cards[0].addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> layoutPile() }
    }

    private fun makeClone(): CloneCard {
        val pad = dp(16f).toInt()
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            visibility = View.INVISIBLE
            isFocusable = false
            isClickable = false
        }
        val iconSrc = icons[0].layoutParams
        val iconW = if (iconSrc != null && iconSrc.width > 0) iconSrc.width else dp(64f).toInt()
        val iconH = if (iconSrc != null && iconSrc.height > 0) iconSrc.height else dp(64f).toInt()
        val icon = ImageView(ctx).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            layoutParams = LinearLayout.LayoutParams(iconW, iconH)
        }
        val titleTopMargin = (titles[0].layoutParams as? ViewGroup.MarginLayoutParams)?.topMargin ?: dp(14f).toInt()
        val title = TextView(ctx).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_PX, titles[0].textSize)
            typeface = titles[0].typeface
            setTextColor(titles[0].currentTextColor)
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = titleTopMargin }
        }
        root.addView(icon)
        root.addView(title)
        return CloneCard(root, icon, title)
    }

    private fun setSize(v: View, w: Int, h: Int) {
        val lp = v.layoutParams
        lp.width = w
        lp.height = h
        v.layoutParams = lp
    }

    private fun layoutPile() {
        if (!viewsCreated) return
        val cw = cards[0].width
        val ch = cards[0].height
        if (cw <= 0 || ch <= 0) return
        if (cw != lastW || ch != lastH) {
            lastW = cw
            lastH = ch
            for (r in 0 until 2) {
                for (k in 0 until PILE_MAX) {
                    pile[r][k]?.let { setSize(it, cw, ch) }
                }
            }
            for (c in 0 until 3) {
                for (r in 0 until 2) {
                    clones[c][r]?.root?.let { setSize(it, cw, ch) }
                }
            }
        }
        if (isAnimating) return
        // Убираем серую «гармошку» слева, чтобы карточки всегда выглядели чисто и аккуратно
        for (r in 0 until 2) {
            for (k in 0 until PILE_MAX) {
                val v = pile[r][k] ?: continue
                v.visibility = View.INVISIBLE
                v.alpha = 0f
            }
        }
    }

    private fun lerp(a: Float, b: Float, p: Float): Float = a + (b - a) * p

    private fun prepareCardsForStripAnim() {
        for (i in cards.indices) {
            val card = cards[i]
            val icon = icons[i]
            MotionPhysics.cancelView(card)
            MotionPhysics.cancelView(icon)
            card.animate().cancel()
            icon.animate().cancel()
            card.translationX = 0f
            card.alpha = 0f
        }
    }

    private fun startScroll(dir: Int, fast: Boolean, forceFocusSlot: Int = -1) {
        fadeAnimator?.cancel()
        fadeAnimator = null
        ensureViews()
        layoutPile()
        val cw = cards[0].width
        val ch = cards[0].height
        if (cw <= 0 || ch <= 0 || cards[2].width <= 0) {
            offset = (offset + dir).coerceIn(0, maxOffset)
            render()
            return
        }
        isAnimating = true
        val fromOffset = offset
        val colW = (cards[2].left - cards[0].left).toFloat()
        val x0 = (cards[0].left - parent.paddingLeft).toFloat()
        val focusedCi = if (forceFocusSlot in 0..3) forceFocusSlot else cards.indexOfFirst { it.hasFocus() }
        val focusedCol = if (focusedCi >= 0) focusedCi / 2 else -1
        val focusedRow = if (focusedCi >= 0) focusedCi % 2 else -1
        val idleCardIdx = cards.indices.firstOrNull { it != focusedCi } ?: 0
        val bgSrc = cards[idleCardIdx].background
        val textColor = titles[idleCardIdx].currentTextColor
        val firstCol = if (dir > 0) fromOffset else fromOffset - 1
        val slideOffset = colW * 0.38f
        val edgeScale = 0.92f
        val focusLiftPx = dp(3f)
        val steps = ArrayList<(Float) -> Unit>()

        for (c in 0 until 3) {
            // Колонка экрана (0 или 1), в которую приедет этот клон после завершения сдвига
            val destCol = if (dir > 0) c - 1 else c
            for (r in 0 until 2) {
                val cc = clones[c][r] ?: continue
                val idx = (firstCol + c) * 2 + r
                val app = apps.getOrNull(idx)
                val isEmpty = idx < 0 || (idx >= 4 && app == null)
                if (isEmpty) {
                    cc.root.visibility = View.INVISIBLE
                    continue
                }
                val isTargetFocused = (destCol == focusedCol && r == focusedRow)
                cc.root.background = bgSrc?.constantState?.newDrawable()?.mutate()
                cc.root.isSelected = isTargetFocused
                cc.title.setTextColor(textColor)
                bind(app, cc.icon, cc.title, cc.root, defaultTitleRes[idx.coerceIn(0, 3)])
                val own = cc.icon.drawable?.constantState?.newDrawable()?.mutate()
                val iconTint = if (isTargetFocused) focusIconColor() else textColor
                if (own != null) {
                    cc.icon.setImageDrawable(own)
                    cc.icon.setColorFilter(iconTint, PorterDuff.Mode.SRC_IN)
                } else {
                    cc.icon.setColorFilter(iconTint, PorterDuff.Mode.SRC_IN)
                }
                cc.icon.scaleX = if (isTargetFocused) ICON_FOCUS_SCALE else 1f
                cc.icon.scaleY = if (isTargetFocused) ICON_FOCUS_SCALE else 1f
                cc.icon.translationY = if (isTargetFocused) -focusLiftPx * 0.5f else 0f
                cc.root.setLayerType(View.LAYER_TYPE_HARDWARE, null)

                val endScale = if (isTargetFocused) CARD_FOCUS_SCALE else 1f
                val endAlpha = if (isTargetFocused) 1f else CARD_IDLE_ALPHA
                val kf: FloatArray = if (dir > 0) {
                    when (c) {
                        0 -> floatArrayOf(x0, x0 - slideOffset, 1f, edgeScale, CARD_IDLE_ALPHA, 0f)
                        1 -> floatArrayOf(x0 + colW, x0, 1f, endScale, CARD_IDLE_ALPHA, endAlpha)
                        else -> floatArrayOf(x0 + colW + slideOffset, x0 + colW, edgeScale, endScale, 0f, endAlpha)
                    }
                } else {
                    when (c) {
                        0 -> floatArrayOf(x0 - slideOffset, x0, edgeScale, endScale, 0f, endAlpha)
                        1 -> floatArrayOf(x0, x0 + colW, 1f, endScale, CARD_IDLE_ALPHA, endAlpha)
                        else -> floatArrayOf(x0 + colW, x0 + colW + slideOffset, 1f, edgeScale, CARD_IDLE_ALPHA, 0f)
                    }
                }
                val baseY = (cards[r].top - parent.paddingTop).toFloat()
                val startY = baseY
                val endY = if (isTargetFocused) baseY - focusLiftPx else baseY
                cc.root.translationY = startY
                cc.root.translationX = kf[0]
                cc.root.scaleX = kf[2]
                cc.root.scaleY = kf[2]
                cc.root.alpha = kf[4]
                cc.root.visibility = View.VISIBLE
                cc.root.bringToFront()
                val root = cc.root
                steps.add { p ->
                    val s = lerp(kf[2], kf[3], p)
                    root.translationX = lerp(kf[0], kf[1], p)
                    root.translationY = lerp(startY, endY, p)
                    root.scaleX = s
                    root.scaleY = s
                    root.alpha = lerp(kf[4], kf[5], p).coerceIn(0f, 1f)
                }
            }
        }

        prepareCardsForStripAnim()

        val targetOffset = (fromOffset + dir).coerceIn(0, maxOffset)
        pendingTargetOffset = targetOffset
        val preset = if (fast) STRIP_FAST_PRESET else MotionPhysics.STRIP
        val initVel = if (fast) 3.0f else 1.2f
        MotionPhysics.springValue(
            key = STRIP_SPRING_KEY,
            startValue = 0f,
            targetValue = 1f,
            preset = preset,
            initialVelocity = initVel,
            onUpdate = { p ->
                for (s in steps) s(p)
            },
            onEnd = {
                finishScroll(targetOffset)
            }
        )
    }

    /**
     * Красивый плавный пролёт из любого конца ленты сразу к первым 4 карточкам (offset = 0).
     */
    private fun startRewindToZero(forceFocusSlot: Int = 0) {
        ensureViews()
        layoutPile()
        val cw = cards[0].width
        val ch = cards[0].height
        if (cw <= 0 || ch <= 0 || cards[2].width <= 0) {
            offset = 0
            render()
            return
        }
        isAnimating = true
        val fromOffset = offset
        val colW = (cards[2].left - cards[0].left).toFloat()
        val x0 = (cards[0].left - parent.paddingLeft).toFloat()
        val bgSrc = cards[0].background
        val textColor = titles[0].currentTextColor
        val slideOffset = colW * 0.45f
        val edgeScale = 0.92f
        val focusLiftPx = dp(3f)
        val steps = ArrayList<(Float) -> Unit>()

        // c=0 -> целевая колонка 0 (слоты 1 и 3) выезжает слева в x0
        // c=1 -> целевая колонка 1 (слоты 2 и 4) выезжает в x0 + colW
        // c=2 -> текущая левая колонка (fromOffset) плавно уходит вправо и растворяется
        val colsToRender = intArrayOf(0, 1, fromOffset)
        for (c in 0 until 3) {
            val targetCol = colsToRender[c]
            for (r in 0 until 2) {
                val cc = clones[c][r] ?: continue
                val idx = targetCol * 2 + r
                val app = apps.getOrNull(idx)
                val isEmpty = idx < 0 || (idx >= 4 && app == null)
                if (isEmpty) {
                    cc.root.visibility = View.INVISIBLE
                    continue
                }
                val isTargetFocused = (c == 0 && r == (forceFocusSlot % 2) && forceFocusSlot in 0..1)
                cc.root.background = bgSrc?.constantState?.newDrawable()?.mutate()
                cc.root.isSelected = isTargetFocused
                cc.title.setTextColor(textColor)
                bind(app, cc.icon, cc.title, cc.root, defaultTitleRes[idx.coerceIn(0, 3)])
                val own = cc.icon.drawable?.constantState?.newDrawable()?.mutate()
                val iconTint = if (isTargetFocused) focusIconColor() else textColor
                if (own != null) {
                    cc.icon.setImageDrawable(own)
                    cc.icon.setColorFilter(iconTint, PorterDuff.Mode.SRC_IN)
                } else {
                    cc.icon.setColorFilter(iconTint, PorterDuff.Mode.SRC_IN)
                }
                cc.icon.scaleX = if (isTargetFocused) ICON_FOCUS_SCALE else 1f
                cc.icon.scaleY = if (isTargetFocused) ICON_FOCUS_SCALE else 1f
                cc.icon.translationY = if (isTargetFocused) -focusLiftPx * 0.5f else 0f
                cc.root.setLayerType(View.LAYER_TYPE_HARDWARE, null)

                val endScale = if (isTargetFocused) CARD_FOCUS_SCALE else 1f
                val endAlpha = if (isTargetFocused) 1f else CARD_IDLE_ALPHA
                val kf: FloatArray = when (c) {
                    0 -> floatArrayOf(x0 - slideOffset, x0, edgeScale, endScale, 0f, endAlpha)
                    1 -> floatArrayOf(x0 + colW - slideOffset, x0 + colW, edgeScale, endScale, 0f, endAlpha)
                    else -> floatArrayOf(x0, x0 + colW + slideOffset * 0.6f, 1f, edgeScale, 0.88f, 0f)
                }
                val baseY = (cards[r].top - parent.paddingTop).toFloat()
                val startY = baseY
                val endY = if (isTargetFocused) baseY - focusLiftPx else baseY
                cc.root.translationY = startY
                cc.root.translationX = kf[0]
                cc.root.scaleX = kf[2]
                cc.root.scaleY = kf[2]
                cc.root.alpha = kf[4]
                cc.root.visibility = View.VISIBLE
                cc.root.bringToFront()
                val root = cc.root
                steps.add { p ->
                    val s = lerp(kf[2], kf[3], p)
                    root.translationX = lerp(kf[0], kf[1], p)
                    root.translationY = lerp(startY, endY, p)
                    root.scaleX = s
                    root.scaleY = s
                    root.alpha = lerp(kf[4], kf[5], p).coerceIn(0f, 1f)
                }
            }
        }

        prepareCardsForStripAnim()

        pendingTargetOffset = 0
        MotionPhysics.springValue(
            key = STRIP_SPRING_KEY,
            startValue = 0f,
            targetValue = 1f,
            preset = MotionPhysics.STRIP,
            initialVelocity = 1.5f,
            onUpdate = { p ->
                for (s in steps) s(p)
            },
            onEnd = {
                finishScroll(0)
            }
        )
    }

    private fun finishScroll(newOffset: Int) {
        if (!isAnimating) return
        offset = newOffset.coerceIn(0, maxOffset)
        isAnimating = false
        animator = null
        fadeAnimator?.cancel()
        fadeAnimator = null
        val focusLiftPx = dp(3f)
        for (i in cards.indices) {
            val card = cards[i]
            val icon = icons[i]
            val focused = card.hasFocus()
            MotionPhysics.cancelView(card)
            MotionPhysics.cancelView(icon)
            card.translationX = 0f
            card.translationY = if (focused) -focusLiftPx else 0f
            card.scaleX = if (focused) CARD_FOCUS_SCALE else 1f
            card.scaleY = if (focused) CARD_FOCUS_SCALE else 1f
            card.alpha = if (focused) 1f else CARD_IDLE_ALPHA
            icon.scaleX = if (focused) ICON_FOCUS_SCALE else 1f
            icon.scaleY = if (focused) ICON_FOCUS_SCALE else 1f
            icon.translationY = if (focused) -focusLiftPx * 0.5f else 0f
        }
        render()
        endFade()
    }

    private fun endFade() {
        for (c in 0 until 3) {
            for (r in 0 until 2) {
                val cc = clones[c][r] ?: continue
                val root = cc.root
                root.visibility = View.INVISIBLE
                root.isSelected = false
                root.alpha = 1f
                root.scaleX = 1f
                root.scaleY = 1f
                root.setLayerType(View.LAYER_TYPE_NONE, null)
                cc.icon.scaleX = 1f
                cc.icon.scaleY = 1f
                cc.icon.translationY = 0f
            }
        }
        for (r in 0 until 2) {
            for (k in 0 until PILE_MAX) {
                pile[r][k]?.setLayerType(View.LAYER_TYPE_NONE, null)
            }
        }
    }
}
