package com.mitv.customlauncher.ui

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.graphics.PorterDuff
import android.graphics.drawable.GradientDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.animation.PathInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.constraintlayout.widget.ConstraintLayout
import com.mitv.customlauncher.data.InstalledAppInfo

/**
 * Лента приложений на главном экране с плавной физикой переключения (Cubic-Bezier)
 * и мягким возвратом к первой плитке по кнопке «Домой».
 */
class AppStripController(
    private val parent: ConstraintLayout,
    private val cards: List<View>,
    private val icons: List<ImageView>,
    private val titles: List<TextView>,
    private val defaultTitleRes: List<Int>,
    private val bind: (InstalledAppInfo?, ImageView, TextView, View, Int) -> Unit
) {
    private class CloneCard(val root: LinearLayout, val icon: ImageView, val title: TextView)

    private companion object {
        const val PILE_MAX = 2
        const val ANIM_MS = 270L
        const val ANIM_FAST_MS = 165L
        const val REWIND_MS = 250L
        const val FADE_MS = 90L
    }

    private val ctx = parent.context
    private val density = ctx.resources.displayMetrics.density

    private fun dp(v: Float): Float = v * density

    private var apps: List<InstalledAppInfo?> = emptyList()
    private var viewsCreated = false
    private var lastW = -1
    private var lastH = -1
    private var animator: ValueAnimator? = null
    private var fadeAnimator: ValueAnimator? = null

    private val pile = Array(2) { arrayOfNulls<View>(PILE_MAX) }
    private val clones = Array(3) { arrayOfNulls<CloneCard>(2) }

    var offset: Int = 0
        private set

    var isAnimating: Boolean = false
        private set

    private val columnCount: Int
        get() = (apps.size + 1) / 2

    private val maxOffset: Int
        get() = (columnCount - 2).coerceAtLeast(0)

    fun canScrollRight(): Boolean = offset < maxOffset

    fun canScrollLeft(): Boolean = offset > 0

    fun scrollRight(fast: Boolean = false) {
        if (isAnimating || !canScrollRight()) return
        startScroll(1, fast)
    }

    fun scrollLeft(fast: Boolean = false) {
        if (isAnimating || !canScrollLeft()) return
        startScroll(-1, fast)
    }

    /**
     * Плавный анимированный возврат в начало ленты (к первой плитке слота 1) по нажатию Домой/Назад.
     */
    fun scrollToStart(animated: Boolean = true) {
        fadeAnimator?.cancel()
        fadeAnimator = null
        val runningAnim = animator
        animator = null
        isAnimating = false
        runningAnim?.cancel()

        if (!animated || offset <= 0) {
            offset = 0
            for (card in cards) {
                card.alpha = 1f
            }
            endFade()
            render()
            return
        }

        if (offset == 1) {
            startScroll(-1, fast = true)
            return
        }

        startRewindToZero()
    }

    fun appIndexFor(card: View): Int {
        val ci = cards.indexOf(card)
        if (ci < 0) return -1
        return (offset + ci / 2) * 2 + ci % 2
    }

    fun setApps(list: List<InstalledAppInfo?>) {
        apps = list
        if (offset > maxOffset) offset = maxOffset
        render()
    }

    fun cancelAnimation() {
        animator?.cancel()
    }

    fun render() {
        if (isAnimating) return
        ensureViews()
        val hidden = BooleanArray(4)
        for (ci in 0 until 4) {
            val idx = (offset + ci / 2) * 2 + ci % 2
            hidden[ci] = idx >= 4 && apps.getOrNull(idx) == null
        }
        val focused = cards.indexOfFirst { it.hasFocus() }
        if (focused >= 0 && hidden[focused]) {
            cards[focused xor 1].requestFocus()
        }
        for (ci in 0 until 4) {
            val card = cards[ci]
            if (hidden[ci]) {
                card.visibility = View.INVISIBLE
                card.isFocusable = false
                card.isClickable = false
            } else {
                val idx = (offset + ci / 2) * 2 + ci % 2
                card.visibility = View.VISIBLE
                card.isFocusable = true
                card.isClickable = true
                card.isLongClickable = true
                bind(apps.getOrNull(idx), icons[ci], titles[ci], card, defaultTitleRes[idx.coerceIn(0, 3)])
            }
        }
        layoutPile()
    }

    private fun newLayoutParams(): ConstraintLayout.LayoutParams {
        return ConstraintLayout.LayoutParams(1, 1).apply {
            startToStart = ConstraintLayout.LayoutParams.PARENT_ID
            topToTop = ConstraintLayout.LayoutParams.PARENT_ID
        }
    }

    private fun ensureViews() {
        if (viewsCreated) return
        viewsCreated = true
        // Вместо грубых серых рамок используем деликатный полупрозрачный стеклянный каскад без резких границ
        val glassAlphas = intArrayOf(0x22FFFFFF, 0x10FFFFFF)
        for (r in 0 until 2) {
            for (k in 0 until PILE_MAX) {
                val v = View(ctx)
                v.background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dp(20f)
                    setColor(0x1810141D)
                    setStroke(dp(1f).toInt().coerceAtLeast(1), glassAlphas[k])
                }
                v.visibility = View.INVISIBLE
                v.isFocusable = false
                v.importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                parent.addView(v, 0, newLayoutParams())
                pile[r][k] = v
            }
        }
        for (c in 0 until 3) {
            for (r in 0 until 2) {
                val cc = makeClone()
                parent.addView(cc.root, newLayoutParams())
                clones[c][r] = cc
            }
        }
        cards[0].addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> layoutPile() }
    }

    private fun makeClone(): CloneCard {
        val pad = dp(16f).toInt()
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(pad, pad, pad, pad)
            visibility = View.INVISIBLE
            isFocusable = false
            isClickable = false
        }
        val iconSrc = icons[0].layoutParams
        val iconW = if (iconSrc != null && iconSrc.width > 0) iconSrc.width else dp(64f).toInt()
        val iconH = if (iconSrc != null && iconSrc.height > 0) iconSrc.height else dp(64f).toInt()
        val icon = ImageView(ctx).apply {
            scaleType = ImageView.ScaleType.FIT_CENTER
            importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            layoutParams = LinearLayout.LayoutParams(iconW, iconH)
        }
        val titleTopMargin = (titles[0].layoutParams as? ViewGroup.MarginLayoutParams)?.topMargin ?: dp(14f).toInt()
        val title = TextView(ctx).apply {
            setTextSize(TypedValue.COMPLEX_UNIT_PX, titles[0].textSize)
            typeface = titles[0].typeface
            setTextColor(titles[0].currentTextColor)
            gravity = Gravity.CENTER
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { topMargin = titleTopMargin }
        }
        root.addView(icon)
        root.addView(title)
        return CloneCard(root, icon, title)
    }

    private fun setSize(v: View, w: Int, h: Int) {
        val lp = v.layoutParams
        lp.width = w
        lp.height = h
        v.layoutParams = lp
    }

    private fun layoutPile() {
        if (!viewsCreated) return
        val cw = cards[0].width
        val ch = cards[0].height
        if (cw <= 0 || ch <= 0) return
        if (cw != lastW || ch != lastH) {
            lastW = cw
            lastH = ch
            for (r in 0 until 2) {
                for (k in 0 until PILE_MAX) {
                    pile[r][k]?.let { setSize(it, cw, ch) }
                }
            }
            for (c in 0 until 3) {
                for (r in 0 until 2) {
                    clones[c][r]?.root?.let { setSize(it, cw, ch) }
                }
            }
        }
        if (isAnimating) return
        // Убираем серую «гармошку» слева, чтобы карточки всегда выглядели чисто и аккуратно
        for (r in 0 until 2) {
            for (k in 0 until PILE_MAX) {
                val v = pile[r][k] ?: continue
                v.visibility = View.INVISIBLE
                v.alpha = 0f
            }
        }
    }

    private fun lerp(a: Float, b: Float, p: Float): Float = a + (b - a) * p

    private fun startScroll(dir: Int, fast: Boolean) {
        fadeAnimator?.cancel()
        fadeAnimator = null
        ensureViews()
        layoutPile()
        val cw = cards[0].width
        val ch = cards[0].height
        if (cw <= 0 || ch <= 0 || cards[2].width <= 0) {
            offset = (offset + dir).coerceIn(0, maxOffset)
            render()
            return
        }
        isAnimating = true
        val fromOffset = offset
        val colW = (cards[2].left - cards[0].left).toFloat()
        val x0 = (cards[0].left - parent.paddingLeft).toFloat()
        val bgSrc = cards[0].background
        val textColor = titles[0].currentTextColor
        val firstCol = if (dir > 0) fromOffset else fromOffset - 1
        val slideOffset = colW * 0.38f
        val edgeScale = 0.92f
        val steps = ArrayList<(Float) -> Unit>()

        for (c in 0 until 3) {
            for (r in 0 until 2) {
                val cc = clones[c][r] ?: continue
                val idx = (firstCol + c) * 2 + r
                val app = apps.getOrNull(idx)
                val isEmpty = idx < 0 || (idx >= 4 && app == null)
                if (isEmpty) {
                    cc.root.visibility = View.INVISIBLE
                    continue
                }
                cc.root.background = bgSrc?.constantState?.newDrawable()?.mutate()
                cc.title.setTextColor(textColor)
                bind(app, cc.icon, cc.title, cc.root, defaultTitleRes[idx.coerceIn(0, 3)])
                val own = cc.icon.drawable?.constantState?.newDrawable()?.mutate()
                if (own != null) {
                    cc.icon.setImageDrawable(own)
                    cc.icon.setColorFilter(textColor, PorterDuff.Mode.SRC_IN)
                }
                cc.root.setLayerType(View.LAYER_TYPE_HARDWARE, null)
                // Плавное скольжение с мягким масштабированием (scaleX + scaleY) и растворением на краях
                val kf: FloatArray = if (dir > 0) {
                    when (c) {
                        0 -> floatArrayOf(x0, x0 - slideOffset, 1f, edgeScale, 1f, 0f)
                        1 -> floatArrayOf(x0 + colW, x0, 1f, 1f, 1f, 1f)
                        else -> floatArrayOf(x0 + colW + slideOffset, x0 + colW, edgeScale, 1f, 0f, 1f)
                    }
                } else {
                    when (c) {
                        0 -> floatArrayOf(x0 - slideOffset, x0, edgeScale, 1f, 0f, 1f)
                        1 -> floatArrayOf(x0, x0 + colW, 1f, 1f, 1f, 1f)
                        else -> floatArrayOf(x0 + colW, x0 + colW + slideOffset, 1f, edgeScale, 1f, 0f)
                    }
                }
                cc.root.translationY = (cards[r].top - parent.paddingTop).toFloat()
                cc.root.translationX = kf[0]
                cc.root.scaleX = kf[2]
                cc.root.scaleY = kf[2]
                cc.root.alpha = kf[4]
                cc.root.visibility = View.VISIBLE
                cc.root.bringToFront()
                val root = cc.root
                steps.add { p ->
                    val s = lerp(kf[2], kf[3], p)
                    root.translationX = lerp(kf[0], kf[1], p)
                    root.scaleX = s
                    root.scaleY = s
                    root.alpha = lerp(kf[4], kf[5], p)
                }
            }
        }

        for (card in cards) {
            card.alpha = 0f
        }

        val va = ValueAnimator.ofFloat(0f, 1f)
        va.duration = if (fast) ANIM_FAST_MS else ANIM_MS
        va.interpolator = PathInterpolator(0.22f, 1f, 0.36f, 1f)
        va.addUpdateListener { a ->
            val p = a.animatedValue as Float
            for (s in steps) s(p)
        }
        va.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                finishScroll((fromOffset + dir).coerceIn(0, maxOffset))
            }
        })
        animator = va
        va.start()
    }

    /**
     * Красивый плавный пролёт из любого конца ленты сразу к первым 4 карточкам (offset = 0).
     */
    private fun startRewindToZero() {
        ensureViews()
        layoutPile()
        val cw = cards[0].width
        val ch = cards[0].height
        if (cw <= 0 || ch <= 0 || cards[2].width <= 0) {
            offset = 0
            render()
            return
        }
        isAnimating = true
        val fromOffset = offset
        val colW = (cards[2].left - cards[0].left).toFloat()
        val x0 = (cards[0].left - parent.paddingLeft).toFloat()
        val bgSrc = cards[0].background
        val textColor = titles[0].currentTextColor
        val slideOffset = colW * 0.45f
        val edgeScale = 0.92f
        val steps = ArrayList<(Float) -> Unit>()

        // c=0 -> целевая колонка 0 (слоты 1 и 3) выезжает слева в x0
        // c=1 -> целевая колонка 1 (слоты 2 и 4) выезжает в x0 + colW
        // c=2 -> текущая левая колонка (fromOffset) плавно уходит вправо и растворяется
        val colsToRender = intArrayOf(0, 1, fromOffset)
        for (c in 0 until 3) {
            val targetCol = colsToRender[c]
            for (r in 0 until 2) {
                val cc = clones[c][r] ?: continue
                val idx = targetCol * 2 + r
                val app = apps.getOrNull(idx)
                val isEmpty = idx < 0 || (idx >= 4 && app == null)
                if (isEmpty) {
                    cc.root.visibility = View.INVISIBLE
                    continue
                }
                cc.root.background = bgSrc?.constantState?.newDrawable()?.mutate()
                cc.title.setTextColor(textColor)
                bind(app, cc.icon, cc.title, cc.root, defaultTitleRes[idx.coerceIn(0, 3)])
                val own = cc.icon.drawable?.constantState?.newDrawable()?.mutate()
                if (own != null) {
                    cc.icon.setImageDrawable(own)
                    cc.icon.setColorFilter(textColor, PorterDuff.Mode.SRC_IN)
                }
                cc.root.setLayerType(View.LAYER_TYPE_HARDWARE, null)
                val kf: FloatArray = when (c) {
                    0 -> floatArrayOf(x0 - slideOffset, x0, edgeScale, 1f, 0f, 1f)
                    1 -> floatArrayOf(x0 + colW - slideOffset, x0 + colW, edgeScale, 1f, 0f, 1f)
                    else -> floatArrayOf(x0, x0 + colW + slideOffset * 0.6f, 1f, edgeScale, 0.9f, 0f)
                }
                cc.root.translationY = (cards[r].top - parent.paddingTop).toFloat()
                cc.root.translationX = kf[0]
                cc.root.scaleX = kf[2]
                cc.root.scaleY = kf[2]
                cc.root.alpha = kf[4]
                cc.root.visibility = View.VISIBLE
                cc.root.bringToFront()
                val root = cc.root
                steps.add { p ->
                    val s = lerp(kf[2], kf[3], p)
                    root.translationX = lerp(kf[0], kf[1], p)
                    root.scaleX = s
                    root.scaleY = s
                    root.alpha = lerp(kf[4], kf[5], p)
                }
            }
        }

        for (card in cards) {
            card.alpha = 0f
        }

        val va = ValueAnimator.ofFloat(0f, 1f)
        va.duration = REWIND_MS
        va.interpolator = PathInterpolator(0.22f, 1f, 0.36f, 1f)
        va.addUpdateListener { a ->
            val p = a.animatedValue as Float
            for (s in steps) s(p)
        }
        va.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                finishScroll(0)
            }
        })
        animator = va
        va.start()
    }

    private fun finishScroll(newOffset: Int) {
        if (!isAnimating) return
        offset = newOffset.coerceIn(0, maxOffset)
        isAnimating = false
        animator = null
        for (card in cards) {
            card.alpha = 1f
        }
        render()
        val shown = ArrayList<View>()
        for (c in 0 until 3) {
            for (r in 0 until 2) {
                val root = clones[c][r]?.root ?: continue
                if (root.visibility == View.VISIBLE) shown.add(root)
            }
        }
        val starts = FloatArray(shown.size) { shown[it].alpha }
        if (shown.isEmpty()) {
            endFade()
            return
        }
        val fa = ValueAnimator.ofFloat(1f, 0f)
        fa.duration = FADE_MS
        fa.addUpdateListener { a ->
            val f = a.animatedValue as Float
            for (i in shown.indices) shown[i].alpha = starts[i] * f
        }
        fa.addListener(object : AnimatorListenerAdapter() {
            override fun onAnimationEnd(animation: Animator) {
                endFade()
            }
        })
        fadeAnimator = fa
        fa.start()
    }

    private fun endFade() {
        for (c in 0 until 3) {
            for (r in 0 until 2) {
                val root = clones[c][r]?.root ?: continue
                root.visibility = View.INVISIBLE
                root.alpha = 1f
                root.scaleX = 1f
                root.scaleY = 1f
                root.setLayerType(View.LAYER_TYPE_NONE, null)
            }
        }
        for (r in 0 until 2) {
            for (k in 0 until PILE_MAX) {
                pile[r][k]?.setLayerType(View.LAYER_TYPE_NONE, null)
            }
        }
    }
}
