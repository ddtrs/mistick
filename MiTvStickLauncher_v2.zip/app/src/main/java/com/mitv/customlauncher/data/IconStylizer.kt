package com.mitv.customlauncher.data

import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.AdaptiveIconDrawable
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.util.LruCache
import androidx.core.content.ContextCompat
import com.mitv.customlauncher.R
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * Движок стилизации иконок в минималистичный стиль лончера (#FFFFFF / #00F0FF на тёмном стекле)
 * без потери производительности (кэш в памяти <= 1.5 МБ, 60 FPS).
 */
class IconStylizer(private val context: Context) {

    private val pm: PackageManager = context.packageManager

    // Компактный кэш уже перерисованных контурных иконок (размер 96x96)
    private val stylizedCache = object : LruCache<String, Drawable>(48) {}

    fun getStylizedIcon(packageName: String, label: String): Drawable {
        stylizedCache.get(packageName)?.let { return it }

        // 1. Сначала проверяем встроенную векторную коллекцию (0 КБ растра, 100% стиль лончера)
        val vectorRes = matchBuiltInVector(packageName, label)
        if (vectorRes != null) {
            val vec = ContextCompat.getDrawable(context, vectorRes)?.mutate()
            if (vec != null) {
                stylizedCache.put(packageName, vec)
                return vec
            }
        }

        // 2. Для любого другого приложения извлекаем чистый контур (foreground без цветного задника)
        // и перекрашиваем в белый силуэт (#FFFFFF), который при фокусе автоматически тонируется в #00F0FF
        val extracted = extractMonochromeGlyph(packageName)
        if (extracted != null) {
            stylizedCache.put(packageName, extracted)
            return extracted
        }

        val fallback = ContextCompat.getDrawable(context, R.drawable.ic_grid_apps_64)!!.mutate()
        return fallback
    }

    private fun matchBuiltInVector(packageName: String, label: String): Int? {
        val pkg = packageName.lowercase()
        val lbl = label.lowercase()
        val key = "$pkg $lbl"
        return when {
            key.contains("netflix") ->
                R.drawable.ic_netflix_64
            pkg.contains("amazonvideo") || pkg.contains("amazon.avod") || lbl.contains("prime video") || lbl == "prime" ->
                R.drawable.ic_prime_64
            key.contains("spotify") ->
                R.drawable.ic_spotify_64
            pkg.contains("kick") || lbl == "kick" ->
                R.drawable.ic_kick_64
            key.contains("twitch") ->
                R.drawable.ic_twitch_64
            key.contains("youtube") || key.contains("smarttube") ->
                R.drawable.ic_youtube_64
            key.contains("browser") || key.contains("chrome") || key.contains("firefox") || key.contains("opera") || key.contains("браузер") ->
                R.drawable.ic_browser_64
            key.contains("airscreen") || key.contains("miracast") || key.contains("dlna") || lbl.contains("cast") ->
                R.drawable.ic_cast_64
            pkg.contains("vending") || lbl.contains("play store") || lbl.contains("play маркет") || lbl.contains("google play") ->
                R.drawable.ic_store_64
            // Для всех остальных установленных приложений возвращаем null,
            // чтобы extractMonochromeGlyph() извлёк их НАСТОЯЩУЮ оригинальную иконку в белом стиле лаунчера!
            else -> null
        }
    }

    private fun extractMonochromeGlyph(packageName: String): Drawable? {
        return try {
            val rawDrawable = pm.getApplicationIcon(packageName)
            val size = 96
            val srcBitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(srcBitmap)

            if (rawDrawable is AdaptiveIconDrawable) {
                // Отбрасываем пестрый цветной background, рендерим только центральный логотип (foreground)
                val fg = rawDrawable.foreground
                if (fg != null) {
                    fg.setBounds(-size / 6, -size / 6, size + size / 6, size + size / 6)
                    fg.draw(canvas)
                } else {
                    rawDrawable.setBounds(0, 0, size, size)
                    rawDrawable.draw(canvas)
                }
            } else {
                rawDrawable.setBounds(0, 0, size, size)
                rawDrawable.draw(canvas)
            }

            val pixels = IntArray(size * size)
            srcBitmap.getPixels(pixels, 0, size, 0, 0, size, size)
            srcBitmap.recycle()

            val visibleCount = NativeCore.extractMonochromeGlyph(pixels, size)
            if (visibleCount < (size * size) / 25) {
                return null
            }

            val outBitmap = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
            outBitmap.setPixels(pixels, 0, size, 0, 0, size, size)
            BitmapDrawable(context.resources, outBitmap)
        } catch (_: Exception) {
            null
        }
    }
}
