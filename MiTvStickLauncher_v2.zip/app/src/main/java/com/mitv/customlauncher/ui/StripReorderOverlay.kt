package com.mitv.customlauncher.ui

import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import com.mitv.customlauncher.data.InstalledAppInfo

/**
 * Экран «Порядок приложений»: список приложений, которые идут после четырёх основных плиток.
 * Пультом: OK берёт или кладёт элемент, вверх и вниз двигают, Назад сохраняет и закрывает.
 * Все клавиши, пока экран открыт, обрабатывает handleKey.
 */
class StripReorderOverlay(
    private val host: FrameLayout,
    private val titleText: String,
    private val hintText: String,
    private val emptyText: String,
    private val panelBackground: () -> Drawable,
    private val rowBackground: () -> Drawable,
    private val accentColor: () -> Int,
    private val onClose: (List<String>) -> Unit
) {
    private val ctx = host.context
    private val density = ctx.resources.displayMetrics.density

    private fun dp(v: Float): Int = (v * density).toInt()

    private var overlay: FrameLayout? = null
    private var panel: LinearLayout? = null
    private var titleView: TextView? = null
    private var scroll: ScrollView? = null
    private var listBox: LinearLayout? = null

    private var items: MutableList<InstalledAppInfo> = mutableListOf()
    private var cursor = 0
    private var grabbed = false
    private val rows = ArrayList<TextView>()

    val isVisible: Boolean
        get() = overlay?.visibility == View.VISIBLE

    private fun build() {
        if (overlay != null) return
        val ov = FrameLayout(ctx).apply {
            setBackgroundColor(0xF208080A.toInt())
            isClickable = true
            visibility = View.GONE
            translationZ = dp(50f).toFloat()
        }
        val pn = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(22f), dp(20f), dp(22f), dp(20f))
        }
        val title = TextView(ctx).apply {
            text = titleText
            textSize = 20f
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        }
        val hint = TextView(ctx).apply {
            text = hintText
            textSize = 13f
            setTextColor(0x99FFFFFF.toInt())
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dp(6f)
                bottomMargin = dp(12f)
            }
        }
        val sv = ScrollView(ctx).apply {
            isFocusable = false
            isVerticalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dp(300f)
            )
        }
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
        }
        sv.addView(box, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        pn.addView(title)
        pn.addView(hint)
        pn.addView(sv)
        ov.addView(pn, FrameLayout.LayoutParams(dp(520f), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER))
        host.addView(ov, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        overlay = ov
        panel = pn
        titleView = title
        scroll = sv
        listBox = box
    }

    fun show(apps: List<InstalledAppInfo>) {
        build()
        items = apps.toMutableList()
        cursor = 0
        grabbed = false
        titleView?.setTextColor(accentColor())
        panel?.background = panelBackground()
        rebuildRows()
        overlay?.visibility = View.VISIBLE
        overlay?.bringToFront()
    }

    fun hideSilently() {
        overlay?.visibility = View.GONE
        grabbed = false
    }

    private fun rebuildRows() {
        val box = listBox ?: return
        box.removeAllViews()
        rows.clear()
        if (items.isEmpty()) {
            val empty = TextView(ctx).apply {
                text = emptyText
                textSize = 15f
                setTextColor(0x99FFFFFF.toInt())
                setPadding(dp(16f), dp(12f), dp(16f), dp(12f))
            }
            box.addView(empty)
            return
        }
        for (i in items.indices) {
            val row = TextView(ctx).apply {
                textSize = 15f
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                setTextColor(0xFFFFFFFF.toInt())
                gravity = Gravity.CENTER_VERTICAL
                maxLines = 1
                setPadding(dp(16f), 0, dp(16f), 0)
                background = rowBackground()
                tag = "row"
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    dp(40f)
                ).apply { topMargin = dp(5f) }
            }
            box.addView(row)
            rows.add(row)
        }
        refreshRows()
    }

    private fun grabbedBackground(): Drawable {
        val accent = accentColor()
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(14f).toFloat()
            setColor(ColorUtils.setAlphaComponent(accent, 90))
            setStroke(dp(2f), accent)
        }
    }

    private fun refreshRows() {
        for (i in rows.indices) {
            val row = rows[i]
            val isGrab = grabbed && i == cursor
            row.text = (if (isGrab) "\u2195 " else "") + (i + 1) + ". " + items[i].label
            if (isGrab) {
                row.background = grabbedBackground()
                row.tag = "grab"
            } else {
                if (row.tag != "row") {
                    row.background = rowBackground()
                    row.tag = "row"
                }
                row.isSelected = (i == cursor)
            }
        }
    }

    private fun ensureCursorVisible() {
        val row = rows.getOrNull(cursor) ?: return
        val sv = scroll ?: return
        sv.post {
            val target = (row.top - sv.height / 2 + row.height / 2).coerceAtLeast(0)
            sv.smoothScrollTo(0, target)
        }
    }

    private fun move(dir: Int) {
        if (items.isEmpty()) return
        val next = cursor + dir
        if (next < 0 || next >= items.size) return
        if (grabbed) {
            java.util.Collections.swap(items, cursor, next)
        }
        cursor = next
        refreshRows()
        ensureCursorVisible()
    }

    private fun close() {
        overlay?.visibility = View.GONE
        grabbed = false
        onClose(items.map { it.packageName })
    }

    fun handleKey(event: KeyEvent): Boolean {
        if (!isVisible) return false
        if (event.action != KeyEvent.ACTION_DOWN) return true
        when (event.keyCode) {
            KeyEvent.KEYCODE_DPAD_UP -> move(-1)
            KeyEvent.KEYCODE_DPAD_DOWN -> move(1)
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_NUMPAD_ENTER,
            KeyEvent.KEYCODE_BUTTON_A,
            KeyEvent.KEYCODE_BUTTON_SELECT -> {
                if (event.repeatCount == 0 && items.isNotEmpty()) {
                    grabbed = !grabbed
                    refreshRows()
                }
            }
            KeyEvent.KEYCODE_BACK,
            KeyEvent.KEYCODE_ESCAPE -> {
                if (event.repeatCount == 0) {
                    if (grabbed) {
                        grabbed = false
                        refreshRows()
                    } else {
                        close()
                    }
                }
            }
        }
        return true
    }
}
