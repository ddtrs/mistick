package com.mitv.customlauncher.data

import android.content.Context
import android.util.Log
import org.json.JSONObject
import java.security.MessageDigest
import java.time.LocalDate
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Locale

/**
 * Потокобезопасный пул из 10 ключей Gemini API с раздельным учётом лимитов для TEXT и TTS,
 * автоматической ротацией (LRU + round-robin), распознаванием 429 RetryInfo / PerDay квот,
 * подсчётом минутного (RPM) и суточного (RPD) расхода в процентах и сохранением в SharedPreferences.
 */
object GeminiKeyPool {

    private const val TAG = "GeminiKeyPool"
    private const val PREF_POOL_STATE_JSON = "pref_gemini_key_pool_state_v62"
    private const val PREF_DAILY_DATE_PACIFIC = "pref_gemini_daily_date_pacific_v61"
    private const val PREF_DAILY_TEXT_COUNT = "pref_gemini_daily_text_count_v61"
    private const val PREF_DAILY_TTS_COUNT = "pref_gemini_daily_tts_count_v61"
    private const val PREF_SHOW_QUOTA_CARD_CC = "pref_show_gemini_quota_card_cc_v61"

    private const val DEAD_KEY_DURATION_MS = 30L * 60L * 1000L
    private const val NETWORK_ERROR_PAUSE_MS = 6_000L
    private const val MAX_MINUTE_BACKOFF_MS = 15L * 60L * 1000L

    // Ориентировочная ёмкость 1 бесплатного ключа в отдельном проекте AI Studio: ~15 RPM и ~1500 RPD
    private const val PER_KEY_RPM_LIMIT = 15
    private const val PER_KEY_RPD_LIMIT = 1500

    enum class Kind {
        TEXT,
        TTS
    }

    data class KeyLease(
        val apiKey: String,
        val fingerprint: String,
        val index: Int,
        val kind: Kind
    ) {
        val label: String
            get() = "key#$index"
    }

    data class QuotaUiSummary(
        val headerText: String,
        val statsLine: String,
        val detailLine: String,
        val isAllHealthy: Boolean
    )

    sealed interface Outcome {
        data object Ok : Outcome
        data class RateLimited(val retryAfterMs: Long? = null, val isDaily: Boolean = false) : Outcome
        data object KeyDead : Outcome
        data object NetworkError : Outcome
        data object ModelError : Outcome
    }

    private class KindState(
        var blockedUntilMs: Long = 0L,
        var consecutiveErrors: Int = 0,
        var lastUsedMs: Long = 0L
    )

    private class KeyEntryState(
        var deadUntilMs: Long = 0L,
        var verifiedWorking: Boolean = false,
        val textState: KindState = KindState(),
        val ttsState: KindState = KindState()
    ) {
        fun stateFor(kind: Kind): KindState = if (kind == Kind.TEXT) textState else ttsState
    }

    private val stateByFingerprint = LinkedHashMap<String, KeyEntryState>()
    private val recentRequestTimestampsMs = ArrayDeque<Long>()
    private var dailyDatePacific: String = ""
    private var dailyTextRequests: Int = 0
    private var dailyTtsRequests: Int = 0
    private var loadedFromPrefs = false
    private var roundRobinCursor = 0

    @Volatile
    private var loggedFirst429Sample = false

    private val keyQueryRegex = Regex("(?i)(key=)[^&\\s\"')\\]]+")
    private val headerKeyRegex = Regex("(?i)(x-goog-api-key\\s*[:=]\\s*)[^\\s,\"')\\]]+")
    private val tokenPrefixRegex = Regex("\\b(AQ\\.[A-Za-z0-9._-]{10,}|AIza[A-Za-z0-9._-]{10,})")

    /**
     * Удаляет любые упоминания API-ключей, параметров key=... и заголовков x-goog-api-key
     * перед записью в Logcat, Toast или текст ошибок.
     */
    fun sanitize(raw: String?): String {
        if (raw.isNullOrEmpty()) return ""
        var out = raw
            .replace(keyQueryRegex, "$1***")
            .replace(headerKeyRegex, "$1***")
            .replace(tokenPrefixRegex, "***")
        for (k in LauncherConfig.GEMINI_KEYS) {
            if (k.length >= 6 && out.contains(k)) {
                out = out.replace(k, "***")
            }
        }
        return out
    }

    fun isQuotaCardVisibleInControlCenter(context: Context): Boolean {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(PREF_SHOW_QUOTA_CARD_CC, true)
    }

    fun setQuotaCardVisibleInControlCenter(context: Context, visible: Boolean) {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(PREF_SHOW_QUOTA_CARD_CC, visible).apply()
    }

    private fun currentPacificDateString(): String {
        return try {
            LocalDate.now(ZoneId.of("America/Los_Angeles")).toString()
        } catch (_: Exception) {
            "2026-11-07"
        }
    }

    private fun sha256Hex8(input: String): String {
        return try {
            val digest = MessageDigest.getInstance("SHA-256").digest(input.toByteArray(Charsets.UTF_8))
            val sb = StringBuilder(8)
            for (i in 0 until 4) {
                sb.append(String.format(Locale.US, "%02x", digest[i].toInt() and 0xFF))
            }
            sb.toString()
        } catch (_: Exception) {
            Integer.toHexString(input.hashCode()).take(8).padStart(8, '0')
        }
    }

    @Synchronized
    private fun ensureLoadedLocked(context: Context?) {
        val todayPacific = currentPacificDateString()
        if (!loadedFromPrefs && context != null) {
            loadedFromPrefs = true
            try {
                val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
                dailyDatePacific = prefs.getString(PREF_DAILY_DATE_PACIFIC, todayPacific) ?: todayPacific
                if (dailyDatePacific == todayPacific) {
                    dailyTextRequests = prefs.getInt(PREF_DAILY_TEXT_COUNT, 0)
                    dailyTtsRequests = prefs.getInt(PREF_DAILY_TTS_COUNT, 0)
                } else {
                    dailyDatePacific = todayPacific
                    dailyTextRequests = 0
                    dailyTtsRequests = 0
                    prefs.edit()
                        .putString(PREF_DAILY_DATE_PACIFIC, todayPacific)
                        .putInt(PREF_DAILY_TEXT_COUNT, 0)
                        .putInt(PREF_DAILY_TTS_COUNT, 0)
                        .apply()
                }

                val rawJson = prefs.getString(PREF_POOL_STATE_JSON, null)
                if (!rawJson.isNullOrBlank()) {
                    val root = JSONObject(rawJson)
                    val keysIter = root.keys()
                    while (keysIter.hasNext()) {
                        val fp = keysIter.next()
                        val obj = root.optJSONObject(fp) ?: continue
                        val entry = KeyEntryState(
                            deadUntilMs = obj.optLong("deadUntilMs", 0L),
                            textState = KindState(
                                blockedUntilMs = obj.optLong("textBlockedUntilMs", 0L),
                                consecutiveErrors = obj.optInt("textErrors", 0),
                                lastUsedMs = obj.optLong("textLastUsedMs", 0L)
                            ),
                            ttsState = KindState(
                                blockedUntilMs = obj.optLong("ttsBlockedUntilMs", 0L),
                                consecutiveErrors = obj.optInt("ttsErrors", 0),
                                lastUsedMs = obj.optLong("ttsLastUsedMs", 0L)
                            )
                        )
                        stateByFingerprint[fp] = entry
                    }
                }
            } catch (_: Exception) {
            }
        } else if (dailyDatePacific != todayPacific) {
            dailyDatePacific = todayPacific
            dailyTextRequests = 0
            dailyTtsRequests = 0
            saveCountersLocked(context)
        }
    }

    @Synchronized
    private fun saveCountersLocked(context: Context?) {
        if (context == null) return
        try {
            val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit()
                .putString(PREF_DAILY_DATE_PACIFIC, dailyDatePacific)
                .putInt(PREF_DAILY_TEXT_COUNT, dailyTextRequests)
                .putInt(PREF_DAILY_TTS_COUNT, dailyTtsRequests)
                .apply()
        } catch (_: Exception) {
        }
    }

    @Synchronized
    private fun saveStateLocked(context: Context?) {
        if (context == null) return
        try {
            val root = JSONObject()
            for ((fp, entry) in stateByFingerprint) {
                val obj = JSONObject().apply {
                    put("deadUntilMs", entry.deadUntilMs)
                    put("textBlockedUntilMs", entry.textState.blockedUntilMs)
                    put("textErrors", entry.textState.consecutiveErrors)
                    put("textLastUsedMs", entry.textState.lastUsedMs)
                    put("ttsBlockedUntilMs", entry.ttsState.blockedUntilMs)
                    put("ttsErrors", entry.ttsState.consecutiveErrors)
                    put("ttsLastUsedMs", entry.ttsState.lastUsedMs)
                }
                root.put(fp, obj)
            }
            val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit()
                .putString(PREF_POOL_STATE_JSON, root.toString())
                .putString(PREF_DAILY_DATE_PACIFIC, dailyDatePacific)
                .putInt(PREF_DAILY_TEXT_COUNT, dailyTextRequests)
                .putInt(PREF_DAILY_TTS_COUNT, dailyTtsRequests)
                .apply()
        } catch (_: Exception) {
        }
    }

    @Synchronized
    private fun pruneRollingMinuteWindowLocked(nowMs: Long) {
        val cutoff = nowMs - 60_000L
        while (recentRequestTimestampsMs.isNotEmpty() && recentRequestTimestampsMs.first() < cutoff) {
            recentRequestTimestampsMs.removeFirst()
        }
    }

    /**
     * Выбирает следующий доступный ключ для указанного типа запроса (TEXT или TTS)
     * по схеме round-robin с приоритетом давно не использовавшихся ключей.
     */
    @Synchronized
    fun acquire(
        context: Context?,
        kind: Kind,
        excludeFingerprints: Set<String> = emptySet()
    ): KeyLease? {
        ensureLoadedLocked(context)
        val keys = LauncherConfig.GEMINI_KEYS
        if (keys.isEmpty()) return null

        val now = System.currentTimeMillis()
        var bestIdx = -1
        var bestKey = ""
        var bestFp = ""
        var bestLastUsed = Long.MAX_VALUE

        val count = keys.size
        val startOffset = (roundRobinCursor % count).coerceAtLeast(0)

        var bestPriorityTier = Int.MAX_VALUE

        for (step in 0 until count) {
            val idx = (startOffset + step) % count
            val rawKey = keys[idx]
            val fp = sha256Hex8(rawKey)
            if (excludeFingerprints.contains(fp)) continue

            val entry = stateByFingerprint.getOrPut(fp) { KeyEntryState() }
            if (now < entry.deadUntilMs) continue

            val kindState = entry.stateFor(kind)
            if (now < kindState.blockedUntilMs) continue

            // Приоритет 0: уже проверенные рабочие ключи или стандартные AIza-ключи.
            // Приоритет 1: ещё не проверенные AQ.-ключи (чтобы не тратить время запроса, если AQ.-ключ не поддерживается эндпоинтом).
            val tier = if (entry.verifiedWorking || rawKey.startsWith("AIza")) 0 else 1

            if (tier < bestPriorityTier || (tier == bestPriorityTier && kindState.lastUsedMs < bestLastUsed)) {
                bestPriorityTier = tier
                bestLastUsed = kindState.lastUsedMs
                bestIdx = idx
                bestKey = rawKey
                bestFp = fp
            }
        }

        if (bestIdx == -1) return null

        roundRobinCursor = (bestIdx + 1) % count
        val chosenEntry = stateByFingerprint.getOrPut(bestFp) { KeyEntryState() }
        chosenEntry.stateFor(kind).lastUsedMs = now

        return KeyLease(
            apiKey = bestKey,
            fingerprint = bestFp,
            index = bestIdx + 1,
            kind = kind
        )
    }

    /**
     * Фиксирует результат запроса для выданного ключа и обновляет минутный/суточный счётчики.
     */
    @Synchronized
    fun report(context: Context?, lease: KeyLease, outcome: Outcome) {
        ensureLoadedLocked(context)
        val now = System.currentTimeMillis()
        val entry = stateByFingerprint.getOrPut(lease.fingerprint) { KeyEntryState() }
        val kindState = entry.stateFor(lease.kind)

        when (outcome) {
            is Outcome.Ok -> {
                entry.verifiedWorking = true
                pruneRollingMinuteWindowLocked(now)
                recentRequestTimestampsMs.addLast(now)
                if (lease.kind == Kind.TEXT) {
                    dailyTextRequests += 1
                } else {
                    dailyTtsRequests += 1
                }
                val hadPenalty = kindState.blockedUntilMs > 0L || kindState.consecutiveErrors > 0
                kindState.blockedUntilMs = 0L
                kindState.consecutiveErrors = 0
                if (hadPenalty) {
                    saveStateLocked(context)
                } else {
                    saveCountersLocked(context)
                }
            }

            is Outcome.RateLimited -> {
                pruneRollingMinuteWindowLocked(now)
                recentRequestTimestampsMs.addLast(now)
                kindState.consecutiveErrors += 1
                val blockUntil = when {
                    outcome.isDaily -> computeNextPacificMidnightPlusTwoMinMs()
                    outcome.retryAfterMs != null && outcome.retryAfterMs > 0L -> now + outcome.retryAfterMs + 1_000L
                    else -> {
                        val shift = (kindState.consecutiveErrors - 1).coerceIn(0, 5)
                        val backoffMs = (30_000L * (1L shl shift)).coerceAtMost(MAX_MINUTE_BACKOFF_MS)
                        now + backoffMs
                    }
                }
                kindState.blockedUntilMs = maxOf(kindState.blockedUntilMs, blockUntil)
                val waitSec = ((kindState.blockedUntilMs - now) / 1000L).coerceAtLeast(1L)
                Log.w(TAG, "${lease.label} (${lease.kind}) rate-limited for ${waitSec}s (daily=${outcome.isDaily})")
                saveStateLocked(context)
            }

            is Outcome.KeyDead -> {
                entry.deadUntilMs = now + DEAD_KEY_DURATION_MS
                Log.w(TAG, "${lease.label} marked DEAD for 30min (API key invalid or forbidden)")
                saveStateLocked(context)
            }

            is Outcome.NetworkError -> {
                kindState.blockedUntilMs = maxOf(kindState.blockedUntilMs, now + NETWORK_ERROR_PAUSE_MS)
                Log.w(TAG, "${lease.label} (${lease.kind}) transient network pause ${NETWORK_ERROR_PAUSE_MS / 1000}s")
            }

            is Outcome.ModelError -> {
                // Ошибка модели (404 / 400 неподдерживаемая модель) не блокирует ключ
            }
        }
    }

    /**
     * Возвращает время в миллисекундах до освобождения ближайшего ключа для указанного типа,
     * либо null, если список ключей пуст.
     */
    /**
     * Возвращает список ключей для фоновой проверки и прогрева БЕЗ изменения lastUsedMs и очереди round-robin.
     */
    @Synchronized
    fun peekKeysForBackgroundProbe(context: Context?): List<KeyLease> {
        ensureLoadedLocked(context)
        val now = System.currentTimeMillis()
        val out = mutableListOf<KeyLease>()
        val keys = LauncherConfig.GEMINI_KEYS
        for (idx in keys.indices) {
            val rawKey = keys[idx]
            val fp = sha256Hex8(rawKey)
            val entry = stateByFingerprint.getOrPut(fp) { KeyEntryState() }
            if (now < entry.deadUntilMs) continue
            out.add(KeyLease(apiKey = rawKey, fingerprint = fp, index = idx + 1, kind = Kind.TEXT))
        }
        return out
    }

    @Synchronized
    fun nextAvailableInMs(context: Context?, kind: Kind): Long? {
        ensureLoadedLocked(context)
        val keys = LauncherConfig.GEMINI_KEYS
        if (keys.isEmpty()) return null

        val now = System.currentTimeMillis()
        var minWaitMs = Long.MAX_VALUE

        for (rawKey in keys) {
            val fp = sha256Hex8(rawKey)
            val entry = stateByFingerprint[fp]
            if (entry == null) return 0L
            val availableAt = maxOf(entry.deadUntilMs, entry.stateFor(kind).blockedUntilMs)
            if (availableAt <= now) return 0L
            val wait = availableAt - now
            if (wait < minWaitMs) {
                minWaitMs = wait
            }
        }

        return if (minWaitMs == Long.MAX_VALUE) null else minWaitMs
    }

    /**
     * Возвращает полную сводку по квотам (в процентах за минуту и за день) для отображения в шторке Control Center.
     */
    @Synchronized
    fun getControlCenterQuotaSummary(context: Context): QuotaUiSummary {
        ensureLoadedLocked(context)
        val now = System.currentTimeMillis()
        pruneRollingMinuteWindowLocked(now)

        val keys = LauncherConfig.GEMINI_KEYS
        val totalKeys = keys.size.coerceAtLeast(1)
        var readyCount = 0
        var pausedCount = 0
        var deadCount = 0
        var minPauseSec = Long.MAX_VALUE

        for (rawKey in keys) {
            val fp = sha256Hex8(rawKey)
            val entry = stateByFingerprint[fp]
            if (entry == null) {
                readyCount++
                continue
            }
            if (now < entry.deadUntilMs) {
                deadCount++
                continue
            }
            val blockEnd = maxOf(entry.textState.blockedUntilMs, entry.ttsState.blockedUntilMs)
            if (now < blockEnd) {
                pausedCount++
                val sec = ((blockEnd - now + 999L) / 1000L).coerceAtLeast(1L)
                if (sec < minPauseSec) minPauseSec = sec
            } else {
                readyCount++
            }
        }

        val rpmUsed = recentRequestTimestampsMs.size
        val rpmLimit = totalKeys * PER_KEY_RPM_LIMIT
        val rpmPct = ((rpmUsed * 100.0) / rpmLimit.coerceAtLeast(1)).coerceIn(0.0, 100.0)

        val rpdUsed = dailyTextRequests + dailyTtsRequests
        val rpdLimit = totalKeys * PER_KEY_RPD_LIMIT
        val rpdPct = ((rpdUsed * 100.0) / rpdLimit.coerceAtLeast(1)).coerceIn(0.0, 100.0)

        val rpdPctStr = String.format(Locale.US, "%.1f%%", rpdPct)
        val rpmPctStr = String.format(Locale.US, "%.0f%%", rpmPct)

        val header = "Квота Gemini API · Активно $readyCount из $totalKeys ключей"
        val statsLine = "За день: $rpdPctStr ($rpdUsed / $rpdLimit)  ·  За минуту: $rpmPctStr ($rpmUsed / $rpmLimit RPM)"
        val detailLine = when {
            pausedCount > 0 && minPauseSec != Long.MAX_VALUE ->
                "На паузе: $pausedCount кл. (ближайший через ${minPauseSec} с) · Текст: $dailyTextRequests · Голос: $dailyTtsRequests"
            deadCount > 0 ->
                "Отключено: $deadCount кл. · Сегодня: Текст $dailyTextRequests · Голос $dailyTtsRequests"
            else ->
                "Все $totalKeys ключей свободны · Сегодня: Текст $dailyTextRequests · Голос $dailyTtsRequests"
        }

        return QuotaUiSummary(
            headerText = header,
            statsLine = statsLine,
            detailLine = detailLine,
            isAllHealthy = (readyCount == totalKeys)
        )
    }

    /**
     * Текстовая сводка по лимитам для голосового ответа ИИ, когда пользователь спрашивает про лимиты/квоты/ключи.
     */
    /**
     * Краткая сводка по ключам (без выдуманных процентов и таймеров разблокировки) —
     * используется только тогда, когда пользователь сам прямо спросил про ключи или лимиты.
     */
    @Synchronized
    fun getVoiceQuotaReport(context: Context): String {
        ensureLoadedLocked(context)
        val now = System.currentTimeMillis()
        val keys = LauncherConfig.GEMINI_KEYS
        val totalKeys = keys.size.coerceAtLeast(1)
        var activeCount = 0
        var inactiveCount = 0
        for (rawKey in keys) {
            val fp = sha256Hex8(rawKey)
            val entry = stateByFingerprint[fp]
            if (entry == null) {
                activeCount++
                continue
            }
            val blockEnd = maxOf(entry.deadUntilMs, maxOf(entry.textState.blockedUntilMs, entry.ttsState.blockedUntilMs))
            if (now < blockEnd) {
                inactiveCount++
            } else {
                activeCount++
            }
        }
        return if (inactiveCount == 0) {
            "Активно $activeCount из $totalKeys ключей, все ключи работают"
        } else {
            "Активно $activeCount из $totalKeys ключей, временно не работают: $inactiveCount"
        }
    }

    /**
     * Вычисляет ближайшую полночь по часовому поясу America/Los_Angeles + 2 минуты запаса (сброс суточных квот Google).
     */
    private fun computeNextPacificMidnightPlusTwoMinMs(): Long {
        return try {
            val zone = ZoneId.of("America/Los_Angeles")
            val nowPacific = ZonedDateTime.now(zone)
            val nextMidnightPlus2 = nowPacific
                .toLocalDate()
                .plusDays(1)
                .atStartOfDay(zone)
                .plusMinutes(2)
            nextMidnightPlus2.toInstant().toEpochMilli()
        } catch (_: Exception) {
            System.currentTimeMillis() + 6L * 60L * 60L * 1000L
        }
    }

    /**
     * Классифицирует HTTP-ответ Google Gemini API в Outcome для пула ключей.
     */
    fun classifyHttpError(httpCode: Int, rawErrorBody: String?): Outcome {
        val safeBody = sanitize(rawErrorBody)
        if (httpCode == 429) {
            if (!loggedFirst429Sample && safeBody.isNotBlank()) {
                loggedFirst429Sample = true
                Log.w(TAG, "First 429 sample body: " + safeBody.replace("\n", " ").take(300))
            }
            val retryMs = parseRetryDelayMs(safeBody)
            val isDaily = isDailyQuotaExhausted(safeBody)
            return Outcome.RateLimited(retryAfterMs = retryMs, isDaily = isDaily)
        }

        if (httpCode in listOf(401, 403)) {
            return Outcome.KeyDead
        }

        if (httpCode == 400) {
            val lower = safeBody.lowercase(Locale.US)
            if (lower.contains("api_key_invalid") ||
                lower.contains("api key not valid") ||
                lower.contains("api_key_expired") ||
                lower.contains("keyexpired") ||
                lower.contains("access_token_type_unsupported")
            ) {
                return Outcome.KeyDead
            }
            return Outcome.ModelError
        }

        if (httpCode == 404 || httpCode == 501) {
            return Outcome.ModelError
        }

        if (httpCode in 500..599) {
            return Outcome.NetworkError
        }

        return Outcome.NetworkError
    }

    private fun parseRetryDelayMs(safeBody: String): Long? {
        if (safeBody.isBlank()) return null
        try {
            val root = JSONObject(safeBody)
            val details = root.optJSONObject("error")?.optJSONArray("details")
            if (details != null) {
                for (i in 0 until details.length()) {
                    val item = details.optJSONObject(i) ?: continue
                    val retryDelay = item.optString("retryDelay", "").trim()
                    val parsed = parseDurationStringMs(retryDelay)
                    if (parsed != null && parsed > 0L) return parsed
                }
            }
        } catch (_: Exception) {
        }
        val regex = Regex("\"retryDelay\"\\s*:\\s*\"([0-9.]+s|[0-9]+ms)\"")
        val match = regex.find(safeBody) ?: return null
        return parseDurationStringMs(match.groupValues[1])
    }

    private fun parseDurationStringMs(raw: String): Long? {
        val clean = raw.trim().lowercase(Locale.US)
        if (clean.isEmpty()) return null
        return try {
            when {
                clean.endsWith("ms") -> clean.removeSuffix("ms").trim().toDouble().toLong()
                clean.endsWith("s") -> (clean.removeSuffix("s").trim().toDouble() * 1000.0).toLong()
                else -> null
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun isDailyQuotaExhausted(safeBody: String): Boolean {
        if (safeBody.isBlank()) return false
        val lower = safeBody.lowercase(Locale.US)
        return lower.contains("perday") ||
            lower.contains("per_day") ||
            lower.contains("requestsperday") ||
            lower.contains("generate_content_free_tier_requests") && lower.contains("day")
    }
}
