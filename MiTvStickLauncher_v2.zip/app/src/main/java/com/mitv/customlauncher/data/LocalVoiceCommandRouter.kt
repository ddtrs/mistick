package com.mitv.customlauncher.data

import android.app.ActivityManager
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.isActive
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import android.graphics.Color
import kotlinx.coroutines.delay
import java.nio.ByteOrder
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import kotlin.math.sqrt
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.speech.tts.TextToSpeech
import com.mitv.customlauncher.service.DynamicIslandBus
import com.mitv.customlauncher.service.RemoteConsoleServer
import com.mitv.customlauncher.service.ShellKeyController
import android.util.Base64
import android.util.Log
import android.widget.Toast
import android.view.KeyEvent
import com.mitv.customlauncher.service.TvUiControllerBus
import com.mitv.customlauncher.service.MediaStateBus
import com.mitv.customlauncher.service.NavSoundPlayer
import com.mitv.customlauncher.service.VolumeHudBus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


/**
 * Исполнитель глубоких действий Android TV, вызываемых напрямую ИИ Gemini:
 * - запуск треков и артистов в Spotify (MEDIA_PLAY_FROM_SEARCH + spotify:search + авто-PLAY)
 * - запуск стримов на Kick (kalatay3 и любые другие каналы)
 * - смена цвета лаунчера/ползунка/островка на любой HEX-цвет
 * - управление громкостью, плеером, памятью, приложениями и звуком щелчков пульта
 */
object LocalVoiceCommandRouter {

    data class LocalActionResult(
        val confirmationText: String,
        val isQuickCommand: Boolean = true
    )

    var onThemeColorChanged: ((String) -> Unit)? = null
    var onVolumeChangedCallback: (() -> Unit)? = null
    var onLauncherUiActionRequested: ((String) -> Unit)? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val routerIoScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    fun resolveStreamerSlug(rawInput: String): String {
        val lower = rawInput.lowercase(Locale.ROOT).trim()
            .removePrefix("https://kick.com/").removePrefix("kick.com/")
            .removePrefix("https://www.twitch.tv/").removePrefix("twitch.tv/")
            .trim('/')
        return when {
            lower.contains("kalatay") || lower.contains("калатай") -> "kalatay3"
            lower.contains("зубар") || lower.contains("zubar") -> "zubarefff"
            lower.contains("мелстр") || lower.contains("mell") -> "mellstroy"
            lower.contains("бустер") || lower.contains("buster") -> "buster"
            lower.contains("плохой") || lower.contains("plohoy") -> "plohoyparen"
            lower.contains("эвелон") || lower.contains("evelon") -> "evelone192"
            lower.contains("строго") || lower.contains("strogo") -> "strogo"
            lower.contains("хесус") || lower.contains("jesus") -> "jesusavgn"
            lower.contains("коряг") || lower.contains("korya") -> "korya_mc"
            lower.contains("братишк") || lower.contains("bratishk") -> "bratishkinoff"
            lower.contains("мазел") || lower.contains("mazel") -> "mazellovvv"
            lower.contains("дипинс") || lower.contains("deepins") -> "deepins02"
            lower.contains("парадеев") || lower.contains("paradeev") -> "paradeev1ch"
            lower.contains("кореш") || lower.contains("koresh") -> "koreshzy"
            lower.contains("фреймтейм") || lower.contains("frametamer") -> "frametamer666"
            lower.contains("рекрент") || lower.contains("recrent") -> "recrent"
            lower.contains("никс") || lower == "nix" -> "nix"
            lower.contains("сильвер") || lower.contains("silvername") -> "silvername"
            lower.contains("дред") || lower.contains("dread") -> "dreadztv"
            lower.contains("вова пейн") || lower.contains("vovapain") -> "vovapain"
            lower.contains("мокрив") || lower.contains("mokriv") -> "mokrivskyi"
            lower.contains("т2х2") || lower.contains("t2x2") -> "t2x2"
            else -> lower.replace(" ", "")
        }
    }

    fun openLauncherUiScreen(context: Context, actionCode: String) {
        val upper = actionCode.trim().uppercase(Locale.US)
        if (upper == "CONTROL_CENTER" &&
            !com.mitv.customlauncher.service.DynamicIslandBus.isLauncherInForeground &&
            com.mitv.customlauncher.service.DynamicIslandBus.onToggleControlCenterInService != null
        ) {
            mainHandler.post {
                com.mitv.customlauncher.service.DynamicIslandBus.onToggleControlCenterInService?.invoke()
            }
            return
        }
        val cb = onLauncherUiActionRequested
        if (cb != null && com.mitv.customlauncher.service.DynamicIslandBus.isLauncherInForeground) {
            mainHandler.post { cb.invoke(upper) }
            return
        }
        val intent = Intent(context, com.mitv.customlauncher.ui.LauncherActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            when (upper) {
                "SETTINGS", "LAUNCHER_SETTINGS" -> putExtra("EXTRA_OPEN_LAUNCHER_SETTINGS", true)
                "UPDATE", "LAUNCHER_UPDATE" -> putExtra("EXTRA_TRIGGER_LAUNCHER_UPDATE", true)
                "CONTROL_CENTER" -> putExtra("EXTRA_OPEN_CONTROL_CENTER", true)
                "ALL_APPS" -> putExtra("EXTRA_OPEN_ALL_APPS", true)
                "RECENT_APPS" -> putExtra("EXTRA_OPEN_RECENT_APPS", true)
                "SPOTIFY_AUTH" -> putExtra("EXTRA_OPEN_SPOTIFY_AUTH", true)
            }
        }
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
        }
    }

    /**
     * В v3.8 100% всех голосовых запросов обрабатываются напрямую через Gemini,
     * чтобы идеально понимать украинский, русский, суржик и английский без жёстких шаблонов!
     */
    fun tryExecuteLocalCommand(context: Context, rawText: String): LocalActionResult? {
        return null
    }

    fun executeSystemAudioCommand(context: Context, actionType: String) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val curVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val curPct = ((curVol * 100f) / maxVol).toInt().coerceIn(0, 100)

        when (actionType) {
            "VOL_UP" -> {
                val newPct = (curPct + 15).coerceAtMost(100)
                val targetVol = ((newPct * maxVol) / 100f + 0.5f).toInt().coerceIn((curVol + 1).coerceAtMost(maxVol), maxVol)
                try {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
                } catch (_: Exception) {
                }
                mainHandler.post {
                    onVolumeChangedCallback?.invoke()
                    VolumeHudBus.notifyVolumeChanged()
                }
            }
            "VOL_DOWN" -> {
                val newPct = (curPct - 15).coerceAtLeast(0)
                val targetVol = ((newPct * maxVol) / 100f).toInt().coerceIn(0, (curVol - 1).coerceAtLeast(0))
                try {
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
                } catch (_: Exception) {
                }
                mainHandler.post {
                    onVolumeChangedCallback?.invoke()
                    VolumeHudBus.notifyVolumeChanged()
                }
            }
            "MUTE" -> {
                try {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
                } catch (_: Exception) {
                }
                mainHandler.post {
                    onVolumeChangedCallback?.invoke()
                    VolumeHudBus.notifyVolumeChanged()
                }
            }
            "UNMUTE" -> {
                try {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
                } catch (_: Exception) {
                }
                mainHandler.post {
                    onVolumeChangedCallback?.invoke()
                    VolumeHudBus.notifyVolumeChanged()
                }
            }
            "PAUSE" -> MediaStateBus.dispatchTransportAction("PAUSE", am)
            "PLAY" -> MediaStateBus.dispatchTransportAction("PLAY", am)
            "NEXT" -> MediaStateBus.dispatchTransportAction("NEXT", am)
            "PREV" -> MediaStateBus.dispatchTransportAction("PREV", am)
        }
    }

    fun applyThemeColorEverywhere(context: Context, hex: String) {
        val cleanHex = if (hex.startsWith("#")) hex else "#$hex"
        try {
            android.graphics.Color.parseColor(cleanHex)
        } catch (_: Exception) {
            return
        }
        AppLauncher(context.applicationContext).saveAccentColorHex(cleanHex)
        mainHandler.post {
            onThemeColorChanged?.invoke(cleanHex)
            DynamicIslandBus.notifyAccentColorChanged(cleanHex)
        }
    }

    fun setVolumePercent(context: Context, targetPct: Int) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val clamped = targetPct.coerceIn(0, 100)
        val targetVol = ((clamped * maxVol) / 100f + 0.5f).toInt().coerceIn(0, maxVol)
        try {
            if (clamped > 0) {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
            }
            am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
        } catch (_: Exception) {
        }
        mainHandler.post {
            onVolumeChangedCallback?.invoke()
            VolumeHudBus.notifyVolumeChanged()
        }
    }

    fun launchKickStream(context: Context, channelSlug: String) {
        val cleanSlug = channelSlug.trim().removePrefix("https://kick.com/").removePrefix("kick.com/").trim('/')
        val url = if (cleanSlug.isNotEmpty()) "https://kick.com/$cleanSlug" else "https://kick.com"
        val appLauncher = AppLauncher(context.applicationContext)
        val pm = context.packageManager
        val allApps = appLauncher.getInstalledApps()

        val kickApp = allApps.firstOrNull {
            val p = it.packageName.lowercase()
            val l = it.label.lowercase()
            p.contains("kick") || l == "kick" || l.startsWith("kick:") || l.startsWith("kick ")
        }

        if (kickApp != null) {
            val pkg = kickApp.packageName
            // 1. Проверяем, поддерживает ли установленная версия Kick прямые ссылки (на телефоне — да, на Android TV — нет)
            val candidateUris = listOf(
                Uri.parse(url),
                Uri.parse("kick://channel/$cleanSlug"),
                Uri.parse("kick://$cleanSlug")
            )
            for (u in candidateUris) {
                try {
                    val deepIntent = Intent(Intent.ACTION_VIEW, u).apply {
                        setPackage(pkg)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    @Suppress("DEPRECATION")
                    if (pm.queryIntentActivities(deepIntent, 0).isNotEmpty()) {
                        context.startActivity(deepIntent)
                        return
                    }
                } catch (_: Exception) {
                }
            }

            // 2. Проверяем поддержку системного ACTION_SEARCH внутри Kick
            if (cleanSlug.isNotEmpty()) {
                try {
                    val searchIntent = Intent(Intent.ACTION_SEARCH).apply {
                        setPackage(pkg)
                        putExtra(SearchManager.QUERY, cleanSlug)
                        putExtra("query", cleanSlug)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    @Suppress("DEPRECATION")
                    if (pm.queryIntentActivities(searchIntent, 0).isNotEmpty()) {
                        context.startActivity(searchIntent)
                        return
                    }
                } catch (_: Exception) {
                }
            }

            // 3. ТВ-версия Kick («Kick: стриминг в прямом эфире»): запускаем само приложение Kick без белого окна ошибки
            // и включаем ИИ-автопоиск стримера через наш AccessibilityService!
            if (appLauncher.launchPackage(pkg)) {
                if (cleanSlug.isNotEmpty()) {
                    TvUiControllerBus.scheduleInAppSearch(pkg, cleanSlug)
                }
                return
            }
        }

        launchUrlInTvBrowser(context, url)
    }

    fun launchUrlInTvBrowser(context: Context, url: String) {
        val finalUrl = if (url.startsWith("http://") || url.startsWith("https://")) url else "https://$url"
        val uri = Uri.parse(finalUrl)
        val appLauncher = AppLauncher(context.applicationContext)
        val pm = context.packageManager
        val allApps = appLauncher.getInstalledApps()

        val browserCandidate = allApps.firstOrNull {
            val p = it.packageName.lowercase()
            val l = it.label.lowercase()
            p.contains("browser") || p.contains("chrome") || p.contains("tvbro") ||
                p.contains("puffin") || p.contains("firefox") || p.contains("opera") ||
                l.contains("браузер") || l.contains("browser")
        }

        if (browserCandidate != null) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                    setPackage(browserCandidate.packageName)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return
            } catch (_: Exception) {
            }
        }

        try {
            val generic = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            @Suppress("DEPRECATION")
            val handlers = pm.queryIntentActivities(generic, 0).filter {
                !it.activityInfo.packageName.lowercase().contains("tv.fw.browsable") &&
                    !it.activityInfo.name.lowercase().contains("stub")
            }
            if (handlers.isNotEmpty()) {
                context.startActivity(generic)
            }
        } catch (_: Exception) {
        }
    }

    fun launchTwitchStream(context: Context, channelInput: String) {
        val cleanSlug = resolveStreamerSlug(channelInput)
        if (cleanSlug.isNotEmpty()) {
            AiMemoryStore.recordImplicitHabit(context, "STREAM", "Twitch: $cleanSlug")
        }
        val url = if (cleanSlug.isNotEmpty()) "https://www.twitch.tv/$cleanSlug" else "https://www.twitch.tv"
        val appLauncher = AppLauncher(context.applicationContext)
        val pm = context.packageManager
        val allApps = appLauncher.getInstalledApps()

        val twitchApp = allApps.firstOrNull {
            val p = it.packageName.lowercase()
            val l = it.label.lowercase()
            p.contains("twitch") || p.contains("twire") || l.contains("twitch") || l.contains("твич")
        }

        if (twitchApp != null) {
            val pkg = twitchApp.packageName
            val candidateUris = listOf(
                Uri.parse("twitch://stream/$cleanSlug"),
                Uri.parse("twitch://open?stream=$cleanSlug"),
                Uri.parse(url)
            )
            for (u in candidateUris) {
                try {
                    val deepIntent = Intent(Intent.ACTION_VIEW, u).apply {
                        setPackage(pkg)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    }
                    @Suppress("DEPRECATION")
                    if (pm.queryIntentActivities(deepIntent, 0).isNotEmpty()) {
                        context.startActivity(deepIntent)
                        return
                    }
                } catch (_: Exception) {
                }
            }
            if (appLauncher.launchPackage(pkg)) {
                if (cleanSlug.isNotEmpty()) {
                    TvUiControllerBus.scheduleInAppSearch(pkg, cleanSlug)
                }
                return
            }
        }
        launchUrlInTvBrowser(context, url)
    }

    fun launchSpotifyTrackOrArtist(context: Context, rawQuery: String) {
        val query = rawQuery.trim()
        if (query.isEmpty()) return
        val appCtx = context.applicationContext
        val resolvedQuery = SpotifyCloudBridge.resolvePlaylistOrQuery(appCtx, query)
        AiMemoryStore.recordImplicitHabit(appCtx, "MUSIC", resolvedQuery)

        val appLauncher = AppLauncher(appCtx)
        val allApps = appLauncher.getInstalledApps()
        val spotifyApp = allApps.firstOrNull {
            val p = it.packageName.lowercase()
            p.contains("spotify") || it.label.lowercase().contains("spotify")
        }
        val spotifyPkg = spotifyApp?.packageName

        if (spotifyPkg != null) {
            // Настоящий плейлист Spotify, созданный Эхо: открываем его и запускаем целиком.
            val playlistUri = SpotifyCloudBridge.findPlaylistUri(appCtx, query)
            if (playlistUri != null) {
                try {
                    val plIntent = Intent(Intent.ACTION_VIEW, Uri.parse(playlistUri)).apply {
                        setPackage(spotifyPkg)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    }
                    appCtx.startActivity(plIntent)
                    SpotifyCloudBridge.tryCloudPlayPlaylistAsync(appCtx, playlistUri)
                    return
                } catch (_: Exception) {
                    // не удалось открыть — идём обычным путём ниже
                }
            }

            MediaStateBus.seedTrackFromQuery(appCtx, spotifyPkg, resolvedQuery)
            SpotifyCloudBridge.tryCloudPlayAsync(appCtx, resolvedQuery)

            val lowerQ = resolvedQuery.lowercase(Locale.ROOT)
            if (lowerQ == "liked" || lowerQ.contains("любимые") || lowerQ.contains("избранн") || lowerQ.contains("лайкн")) {
                try {
                    val likedIntent = Intent(Intent.ACTION_VIEW, Uri.parse("spotify:collection:tracks")).apply {
                        setPackage(spotifyPkg)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    }
                    appCtx.startActivity(likedIntent)
                    scheduleSpotifyAutoPlayKick(appCtx, spotifyPkg, resolvedQuery)
                    return
                } catch (_: Exception) {
                }
            }

            try {
                val playIntent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
                    setPackage(spotifyPkg)
                    putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                    putExtra(SearchManager.QUERY, resolvedQuery)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                appCtx.startActivity(playIntent)
                scheduleSpotifyAutoPlayKick(appCtx, spotifyPkg, resolvedQuery)
                return
            } catch (_: Exception) {
            }

            try {
                val uriIntent = Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:${Uri.encode(resolvedQuery)}")).apply {
                    setPackage(spotifyPkg)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                appCtx.startActivity(uriIntent)
                scheduleSpotifyAutoPlayKick(appCtx, spotifyPkg, resolvedQuery)
                return
            } catch (_: Exception) {
            }

            try {
                val searchIntent = Intent(Intent.ACTION_SEARCH).apply {
                    setPackage(spotifyPkg)
                    putExtra(SearchManager.QUERY, resolvedQuery)
                    putExtra("query", resolvedQuery)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                appCtx.startActivity(searchIntent)
                scheduleSpotifyAutoPlayKick(appCtx, spotifyPkg, resolvedQuery)
                return
            } catch (_: Exception) {
            }

            appLauncher.launchPackage(spotifyPkg)
            scheduleSpotifyAutoPlayKick(appCtx, spotifyPkg, resolvedQuery)
            return
        }

        launchYouTubeSearch(appCtx, resolvedQuery)
    }

    private fun scheduleSpotifyAutoPlayKick(context: Context, spotifyPkg: String, query: String) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        TvUiControllerBus.scheduleYouTubeAutoPlay(spotifyPkg, query)
        mainHandler.postDelayed({
            try {
                val now = SystemClock.uptimeMillis()
                val down = KeyEvent(now, now, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY, 0)
                val up = KeyEvent(now, now, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY, 0)
                am.dispatchMediaKeyEvent(down)
                am.dispatchMediaKeyEvent(up)
            } catch (_: Exception) {
            }
        }, 1900L)
    }

    /** [CMD:SPOTIFY_SEARCH] — только открыть экран результатов поиска Spotify, ничего не запуская. */
    fun searchSpotifyOnly(context: Context, rawQuery: String) {
        val query = rawQuery.trim()
        if (query.isEmpty()) return
        val appCtx = context.applicationContext
        val appLauncher = AppLauncher(appCtx)
        val spotifyPkg = appLauncher.getInstalledApps().firstOrNull {
            it.packageName.lowercase().contains("spotify") || it.label.lowercase().contains("spotify")
        }?.packageName
        if (spotifyPkg == null) {
            launchYouTubeSearchOnly(appCtx, query)
            return
        }
        SpotifyCloudBridge.searchAndOpenInSpotify(appCtx, spotifyPkg, query)
    }

    private fun resolveTopYouTubeVideoIdBlocking(query: String): String? {
        val encoded = Uri.encode(query)
        // 1. Сначала пробуем наш сверхбыстрый Cloudflare Worker резолвер (<200ms)
        try {
            val workerUrl = "${LauncherConfig.CLOUDFLARE_GATEWAY_URL}/yt/resolve?q=$encoded"
            val conn = (URL(workerUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 1300
                readTimeout = 1500
                setRequestProperty("x-app-secret", LauncherConfig.GATEWAY_APP_SECRET)
            }
            if (conn.responseCode == 200) {
                val body = conn.inputStream.bufferedReader().use { it.readText() }
                val json = JSONObject(body)
                val vid = json.optString("videoId", "").trim()
                if (vid.length == 11) return vid
            }
        } catch (_: Exception) {
        }

        // 2. Прямой резолв первого videoId из поисковой выдачи YouTube (фильтр sp=EgIQAQ%3D%3D = только видео)
        try {
            val ytUrl = "https://www.youtube.com/results?search_query=$encoded&hl=ru&sp=EgIQAQ%253D%253D"
            val conn = (URL(ytUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 1600
                readTimeout = 1900
                setRequestProperty(
                    "User-Agent",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
                )
                setRequestProperty("Accept-Language", "ru-RU,ru;q=0.9,en-US;q=0.8")
            }
            if (conn.responseCode in 200..299) {
                val html = conn.inputStream.bufferedReader().use { it.readText() }
                val m = Regex("\"videoId\":\"([a-zA-Z0-9_-]{11})\"").find(html)
                val vid = m?.groupValues?.getOrNull(1).orEmpty()
                if (vid.length == 11) return vid
            }
        } catch (_: Exception) {
        }
        return null
    }

    /** [CMD:YT_SEARCH] — открыть только результаты поиска YouTube/SmartTube, без автозапуска. */
    fun launchYouTubeSearchOnly(context: Context, query: String) {
        val cleanQuery = query.trim()
        val appCtx = context.applicationContext
        val appLauncher = AppLauncher(appCtx)
        val ytApp = appLauncher.getInstalledApps().firstOrNull {
            val p = it.packageName.lowercase()
            p.contains("youtube.tv") || p.contains("smarttube") || p.contains("teamsmart") || p.contains("youtube")
        }
        val targetPkg = ytApp?.packageName ?: "com.google.android.youtube.tv"
        if (cleanQuery.isEmpty()) {
            appLauncher.launchPackage(targetPkg)
            return
        }
        AiMemoryStore.recordImplicitHabit(appCtx, "YOUTUBE", cleanQuery)
        try {
            val searchIntent = Intent(Intent.ACTION_SEARCH).apply {
                if (ytApp != null) setPackage(ytApp.packageName)
                putExtra(SearchManager.QUERY, cleanQuery)
                putExtra("query", cleanQuery)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            appCtx.startActivity(searchIntent)
            return
        } catch (_: Exception) {
        }
        try {
            val webUri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(cleanQuery))
            val viewIntent = Intent(Intent.ACTION_VIEW, webUri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            appCtx.startActivity(viewIntent)
        } catch (_: Exception) {
        }
    }

    /** [CMD:YT_PLAY] — сразу запустить первое видео по запросу. */
    fun launchYouTubePlay(context: Context, query: String) = launchYouTubeSearch(context, query)

    fun launchYouTubeSearch(context: Context, query: String) {
        val cleanQuery = query.trim()
        val appCtx = context.applicationContext
        val appLauncher = AppLauncher(appCtx)
        val apps = appLauncher.getInstalledApps()
        val ytApp = apps.firstOrNull {
            val p = it.packageName.lowercase()
            p.contains("youtube.tv") || p.contains("smarttube") || p.contains("teamsmart") || p.contains("youtube")
        }
        val targetPkg = ytApp?.packageName ?: "com.google.android.youtube.tv"
        if (cleanQuery.isEmpty()) {
            appLauncher.launchPackage(targetPkg)
            return
        }
        AiMemoryStore.recordImplicitHabit(appCtx, "YOUTUBE", cleanQuery)

        routerIoScope.launch {
            val videoId = resolveTopYouTubeVideoIdBlocking(cleanQuery)
            withContext(Dispatchers.Main) {
                if (!videoId.isNullOrBlank()) {
                    // Прямой запуск конкретного видео по videoId — сразу открывает плеер и включает ролик со 100% надёжностью!
                    val candidateWatchUris = listOf(
                        Uri.parse("https://www.youtube.com/watch?v=$videoId"),
                        Uri.parse("vnd.youtube://$videoId"),
                        Uri.parse("vnd.youtube:$videoId")
                    )
                    for (watchUri in candidateWatchUris) {
                        try {
                            val watchIntent = Intent(Intent.ACTION_VIEW, watchUri).apply {
                                if (ytApp != null) setPackage(ytApp.packageName)
                                putExtra("force_fullscreen", true)
                                putExtra("finish_on_ended", false)
                                putExtra(Intent.EXTRA_REFERRER, Uri.parse("android-app://com.google.android.katniss"))
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                            }
                            appCtx.startActivity(watchIntent)
                            return@withContext
                        } catch (_: Exception) {
                        }
                    }
                }

                // Резервный путь, если сеть не отдала videoId: открываем поиск и дожимаем автозапуск
                try {
                    val searchIntent = Intent(Intent.ACTION_SEARCH).apply {
                        if (ytApp != null) setPackage(ytApp.packageName)
                        putExtra(SearchManager.QUERY, cleanQuery)
                        putExtra("query", cleanQuery)
                        putExtra("va_play_first_result", true)
                        putExtra(Intent.EXTRA_REFERRER, Uri.parse("android-app://com.google.android.katniss"))
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    }
                    appCtx.startActivity(searchIntent)
                    TvUiControllerBus.scheduleYouTubeAutoPlay(targetPkg, cleanQuery)
                    return@withContext
                } catch (_: Exception) {
                }
                try {
                    val webUri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(cleanQuery))
                    val viewIntent = Intent(Intent.ACTION_VIEW, webUri).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    appCtx.startActivity(viewIntent)
                    TvUiControllerBus.scheduleYouTubeAutoPlay(targetPkg, cleanQuery)
                } catch (_: Exception) {
                }
            }
        }
    }

    fun launchPlayStoreSearch(context: Context, query: String) {
        val cleanQuery = query.trim()
        val appLauncher = AppLauncher(context.applicationContext)
        val marketPkg = "com.android.vending"
        if (cleanQuery.isEmpty()) {
            if (!appLauncher.launchPackage(marketPkg)) {
                launchUrlInTvBrowser(context, "https://play.google.com/store")
            }
            return
        }
        try {
            val marketUri = Uri.parse("market://search?q=" + Uri.encode(cleanQuery))
            val viewIntent = Intent(Intent.ACTION_VIEW, marketUri).apply {
                setPackage(marketPkg)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            context.startActivity(viewIntent)
            TvUiControllerBus.scheduleInAppSearch(marketPkg, cleanQuery)
            return
        } catch (_: Exception) {
        }
        if (appLauncher.launchPackage(marketPkg)) {
            TvUiControllerBus.scheduleInAppSearch(marketPkg, cleanQuery)
        } else {
            launchUrlInTvBrowser(context, "https://play.google.com/store/search?q=" + Uri.encode(cleanQuery))
        }
    }

    fun executeVideoSeek(spec: String) {
        val upper = spec.trim().uppercase(Locale.US)
        val isRewind = upper.contains("REW") || upper.contains("BACK") || upper.startsWith("-")
        val digits = Regex("[0-9]+").find(upper)?.value?.toIntOrNull() ?: 30
        val presses = (digits / 10).coerceIn(1, 12)
        val keyCode = if (isRewind) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT
        Thread {
            try {
                for (i in 0 until presses) {
                    ShellKeyController.sendKeyEvent(keyCode)
                    Thread.sleep(140L)
                }
                ShellKeyController.sendKeyEvent(KeyEvent.KEYCODE_DPAD_CENTER)
            } catch (_: Exception) {
            }
        }.start()
    }

    fun openSystemSettingsAction(context: Context, action: String) {
        try {
            val intent = Intent(action).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            try {
                val fallback = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(fallback)
            } catch (_: Exception) {
            }
        }
    }

    fun cleanRamBackground(context: Context) {
        try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return
            val apps = AppLauncher(context.applicationContext).getInstalledApps()
            for (app in apps) {
                val p = app.packageName.lowercase()
                if (app.packageName != context.packageName &&
                    !p.contains("spotify") &&
                    !p.contains("mediashell") &&
                    !p.contains("soundcloud") &&
                    !p.contains("remote") &&
                    !p.contains("katniss") &&
                    !p.contains("bluetooth") &&
                    !p.contains("google.android.gms")
                ) {
                    am.killBackgroundProcesses(app.packageName)
                }
            }
        } catch (_: Exception) {
        }
    }
}
