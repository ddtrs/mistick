package com.mitv.customlauncher.data

import android.app.ActivityManager
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.isActive
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import android.graphics.Color
import kotlinx.coroutines.delay
import java.nio.ByteOrder
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import kotlin.math.sqrt
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.speech.tts.TextToSpeech
import com.mitv.customlauncher.service.DynamicIslandBus
import com.mitv.customlauncher.service.RemoteConsoleServer
import com.mitv.customlauncher.service.ShellKeyController
import android.util.Base64
import android.util.Log
import android.widget.Toast
import android.view.KeyEvent
import com.mitv.customlauncher.service.TvUiControllerBus
import com.mitv.customlauncher.service.MediaStateBus
import com.mitv.customlauncher.service.NavSoundPlayer
import com.mitv.customlauncher.service.VolumeHudBus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


object ScheduledTaskManager {
    private const val PREF_TASKS_JSON = "pref_ai_scheduled_tasks_v58"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val lock = Any()
    @Volatile
    private var loopStarted = false

    fun ensureStarted(context: Context) {
        if (loopStarted) return
        loopStarted = true
        val appCtx = context.applicationContext
        scope.launch {
            while (isActive) {
                try {
                    checkAndFireDueTasks(appCtx)
                } catch (_: Exception) {
                }
                delay(2000L)
            }
        }
    }

    fun scheduleVoiceReminder(context: Context, delaySeconds: Long, reminderText: String) {
        val cleanText = reminderText.trim()
        if (cleanText.isEmpty()) return
        val triggerAtMs = System.currentTimeMillis() + (delaySeconds.coerceAtLeast(3L) * 1000L)
        addTask(context, type = "REMIND", triggerAtMs = triggerAtMs, payload = cleanText)
    }

    /**
     * Планирует напоминание на конкретную дату и время ("yyyy-MM-dd HH:mm" или "HH:mm") в постоянную память,
     * чтобы оно никогда не терялось при сбросе контекстного окна диалога или перезапуске!
     */
    fun scheduleVoiceReminderAt(context: Context, dateTimeSpec: String, reminderText: String) {
        val cleanText = reminderText.trim().ifEmpty { "Напоминание" }
        val rawSpec = dateTimeSpec.trim()
        val now = System.currentTimeMillis()
        var targetMs = 0L
        for (pattern in listOf("yyyy-MM-dd HH:mm", "yyyy-MM-dd H:mm", "dd.MM.yyyy HH:mm")) {
            try {
                val sdf = SimpleDateFormat(pattern, Locale.US)
                val parsed = sdf.parse(rawSpec)
                if (parsed != null && parsed.time > now) {
                    targetMs = parsed.time
                    break
                }
            } catch (_: Exception) {
            }
        }
        if (targetMs <= now) {
            // Если передано только время "HH:mm"
            val hmMatch = Regex("(\\d{1,2}):(\\d{2})").find(rawSpec)
            if (hmMatch != null) {
                val h = hmMatch.groupValues[1].toIntOrNull() ?: 10
                val m = hmMatch.groupValues[2].toIntOrNull() ?: 0
                val cal = java.util.Calendar.getInstance()
                cal.set(java.util.Calendar.HOUR_OF_DAY, h.coerceIn(0, 23))
                cal.set(java.util.Calendar.MINUTE, m.coerceIn(0, 59))
                cal.set(java.util.Calendar.SECOND, 0)
                cal.set(java.util.Calendar.MILLISECOND, 0)
                if (cal.timeInMillis <= now) {
                    cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
                }
                targetMs = cal.timeInMillis
            }
        }
        if (targetMs <= now) {
            targetMs = now + 60_000L
        }
        addTask(context, type = "REMIND", triggerAtMs = targetMs, payload = cleanText)
    }

    fun getPendingRemindersSummaryForAi(context: Context): String {
        val appCtx = context.applicationContext
        synchronized(lock) {
            val prefs = appCtx.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            val raw = prefs.getString(PREF_TASKS_JSON, "[]") ?: "[]"
            if (raw == "[]") return ""
            val arr = try { JSONArray(raw) } catch (_: Exception) { return "" }
            if (arr.length() == 0) return ""
            val sdf = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
            val items = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val t = obj.optString("type", "")
                val p = obj.optString("payload", "")
                val trig = obj.optLong("triggerAtMs", 0L)
                if (trig > System.currentTimeMillis()) {
                    items.add("$t в ${sdf.format(Date(trig))}: $p")
                }
            }
            if (items.isEmpty()) return ""
            return "\nАктивные запланированные напоминания и таймеры в памяти приставки: " + items.joinToString("; ") + "\n"
        }
    }

    fun cancelReminder(context: Context, keywordOrAll: String) {
        val kw = keywordOrAll.trim().lowercase(Locale.ROOT)
        val appCtx = context.applicationContext
        synchronized(lock) {
            val prefs = appCtx.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            if (kw.isEmpty() || kw == "all" || kw == "все" || kw == "всё") {
                prefs.edit().putString(PREF_TASKS_JSON, "[]").apply()
                return
            }
            val raw = prefs.getString(PREF_TASKS_JSON, "[]") ?: "[]"
            val arr = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
            val remaining = JSONArray()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val p = obj.optString("payload", "").lowercase(Locale.ROOT)
                if (!p.contains(kw)) {
                    remaining.put(obj)
                }
            }
            prefs.edit().putString(PREF_TASKS_JSON, remaining.toString()).apply()
        }
    }

    fun registerSmartWatcher(context: Context, watchSpec: String) {
        val code = watchSpec.trim().uppercase(Locale.US)
        val (posMs, durMs) = MediaStateBus.getLivePositionAndDuration()
        val remainingTrackSec = if (durMs > posMs && durMs > 5_000L) {
            ((durMs - posMs) / 1000L).coerceIn(5L, 900L)
        } else {
            160L
        }
        when {
            code.contains("AFTER_TRACK_SLEEP") || code.contains("TRACK_SLEEP") -> {
                scheduleDelayedCommand(context, remainingTrackSec, "SLEEP")
            }
            code.contains("AFTER_TRACK_PAUSE") || code.contains("TRACK_PAUSE") -> {
                scheduleDelayedCommand(context, remainingTrackSec, "PAUSE")
            }
            code.contains("OUTAGE_WARN") -> {
                val snap = OutageRepository.state.value
                val cal = java.util.Calendar.getInstance()
                val nowMin = cal.get(java.util.Calendar.HOUR_OF_DAY) * 60 + cal.get(java.util.Calendar.MINUTE)
                val nextSlot = snap.todaySchedule.intervals.firstOrNull { it.startMinuteOfDay > nowMin + 15 }
                if (nextSlot != null) {
                    val waitMin = (nextSlot.startMinuteOfDay - 15 - nowMin).coerceAtLeast(1)
                    scheduleVoiceReminder(context, waitMin * 60L, "Через 15 минут отключение света по графику ДТЭК")
                } else {
                    scheduleVoiceReminder(context, 900L, "Проверьте график отключений света ДТЭК")
                }
            }
        }
    }

    fun scheduleDelayedCommand(context: Context, delaySeconds: Long, commandSpec: String) {
        val cleanSpec = commandSpec.trim()
        if (cleanSpec.isEmpty()) return
        val triggerAtMs = System.currentTimeMillis() + (delaySeconds.coerceAtLeast(3L) * 1000L)
        addTask(context, type = "CMD", triggerAtMs = triggerAtMs, payload = cleanSpec)
    }

    private fun addTask(context: Context, type: String, triggerAtMs: Long, payload: String) {
        val appCtx = context.applicationContext
        ensureStarted(appCtx)
        synchronized(lock) {
            val prefs = appCtx.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            val arr = try {
                JSONArray(prefs.getString(PREF_TASKS_JSON, "[]") ?: "[]")
            } catch (_: Exception) {
                JSONArray()
            }
            arr.put(
                JSONObject().apply {
                    put("type", type)
                    put("triggerAtMs", triggerAtMs)
                    put("payload", payload)
                }
            )
            prefs.edit().putString(PREF_TASKS_JSON, arr.toString()).apply()
        }
    }

    private fun checkAndFireDueTasks(context: Context) {
        val now = System.currentTimeMillis()
        val dueList = mutableListOf<Pair<String, String>>()
        synchronized(lock) {
            val prefs = context.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            val raw = prefs.getString(PREF_TASKS_JSON, "[]") ?: "[]"
            if (raw == "[]") return
            val arr = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
            if (arr.length() == 0) return
            val remaining = JSONArray()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val triggerAt = obj.optLong("triggerAtMs", 0L)
                val t = obj.optString("type", "")
                val p = obj.optString("payload", "")
                if (now >= triggerAt) {
                    dueList.add(t to p)
                } else {
                    remaining.put(obj)
                }
            }
            if (dueList.isNotEmpty()) {
                prefs.edit().putString(PREF_TASKS_JSON, remaining.toString()).apply()
            }
        }

        for ((type, payload) in dueList) {
            mainHandler.post {
                if (type == "REMIND") {
                    DynamicIslandBus.showAnnouncement(context, "Напоминание: $payload", speakText = "Напоминаю: $payload")
                } else if (type == "CMD") {
                    executeDelayedAction(context, payload)
                }
            }
        }
    }

    private fun executeDelayedAction(context: Context, commandSpec: String) {
        val parts = commandSpec.split(":", limit = 2)
        val act = parts[0].trim().uppercase(Locale.US)
        val arg = parts.getOrNull(1)?.trim().orEmpty()
        when (act) {
            "LED_ON" -> {
                TuyaSmartHomeController.setPower(context, true)
                DynamicIslandBus.showAnnouncement(context, "Таймер: подсветка включена", speakText = "Включаю подсветку по таймеру.")
            }
            "LED_OFF" -> {
                TuyaSmartHomeController.setPower(context, false)
                DynamicIslandBus.showAnnouncement(context, "Таймер: подсветка выключена", speakText = "Выключаю подсветку по таймеру.")
            }
            "LED_COLOR" -> if (arg.isNotEmpty()) {
                TuyaSmartHomeController.setHexColor(context, arg)
                DynamicIslandBus.showAnnouncement(context, "Таймер: цвет ленты изменён", speakText = "Меняю цвет ленты по таймеру.")
            }
            "BULB_ON" -> {
                TuyaSmartHomeController.setBulbPower(context, true)
                DynamicIslandBus.showAnnouncement(context, "Таймер: лампочка включена", speakText = "Включаю лампочку по таймеру.")
            }
            "BULB_OFF" -> {
                TuyaSmartHomeController.setBulbPower(context, false)
                DynamicIslandBus.showAnnouncement(context, "Таймер: лампочка выключена", speakText = "Выключаю лампочку по таймеру.")
            }
            "BULB_COLOR" -> if (arg.isNotEmpty()) {
                TuyaSmartHomeController.setBulbHexColor(context, arg)
                DynamicIslandBus.showAnnouncement(context, "Таймер: цвет лампочки изменён", speakText = "Меняю цвет лампочки по таймеру.")
            }
            "LIGHTS_ON" -> {
                TuyaSmartHomeController.setAllLightsPower(context, true)
                DynamicIslandBus.showAnnouncement(context, "Таймер: весь свет включён", speakText = "Включаю весь свет по таймеру.")
            }
            "LIGHTS_OFF" -> {
                TuyaSmartHomeController.setAllLightsPower(context, false)
                DynamicIslandBus.showAnnouncement(context, "Таймер: весь свет выключен", speakText = "Выключаю весь свет по таймеру.")
            }
            "SLEEP", "TV_OFF" -> {
                ShellKeyController.sendKeyEvent(223)
            }
            "WAKEUP", "TV_ON" -> {
                ShellKeyController.sendKeyEvent(224)
            }
            "PAUSE" -> LocalVoiceCommandRouter.executeSystemAudioCommand(context, "PAUSE")
            "PLAY" -> LocalVoiceCommandRouter.executeSystemAudioCommand(context, "PLAY")
            "MUTE" -> LocalVoiceCommandRouter.executeSystemAudioCommand(context, "MUTE")
            "YT" -> if (arg.isNotEmpty()) LocalVoiceCommandRouter.launchYouTubeSearch(context, arg)
            "KICK" -> if (arg.isNotEmpty()) LocalVoiceCommandRouter.launchKickStream(context, arg)
            "SPOTIFY" -> if (arg.isNotEmpty()) LocalVoiceCommandRouter.launchSpotifyTrackOrArtist(context, arg)
        }
    }
}
