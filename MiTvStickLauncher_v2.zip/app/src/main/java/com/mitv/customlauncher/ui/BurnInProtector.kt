package com.mitv.customlauncher.ui

import android.view.View
import com.mitv.customlauncher.data.LauncherConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class BurnInProtector(
    private val targetView: View,
    private val density: Float
) {
    private var idleJob: Job? = null
    private var stepIndex: Int = 0

    fun onUserInteraction(scope: CoroutineScope) {
        resetShiftImmediately()
        idleJob?.cancel()
        idleJob = scope.launch {
            delay(LauncherConfig.BURN_IN_IDLE_THRESHOLD_MS)
            while (isActive) {
                val (dxDp, dyDp) = LauncherConfig.BURN_IN_OFFSETS_DP[stepIndex]
                stepIndex = (stepIndex + 1) % LauncherConfig.BURN_IN_OFFSETS_DP.size
                targetView.animate()
                    .translationX(dxDp * density)
                    .translationY(dyDp * density)
                    .setDuration(LauncherConfig.BURN_IN_ANIM_DURATION_MS)
                    .start()
                delay(LauncherConfig.BURN_IN_PERIOD_MS)
            }
        }
    }

    fun stop() {
        idleJob?.cancel()
        idleJob = null
        resetShiftImmediately()
    }

    private fun resetShiftImmediately() {
        targetView.animate().cancel()
        targetView.translationX = 0f
        targetView.translationY = 0f
    }
}
