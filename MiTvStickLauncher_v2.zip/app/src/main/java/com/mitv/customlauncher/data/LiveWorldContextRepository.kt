package com.mitv.customlauncher.data

import android.app.ActivityManager
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.isActive
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import android.graphics.Color
import kotlinx.coroutines.delay
import java.nio.ByteOrder
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import kotlin.math.sqrt
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.speech.tts.TextToSpeech
import com.mitv.customlauncher.service.DynamicIslandBus
import com.mitv.customlauncher.service.RemoteConsoleServer
import com.mitv.customlauncher.service.ShellKeyController
import android.util.Base64
import android.util.Log
import android.widget.Toast
import android.view.KeyEvent
import com.mitv.customlauncher.service.TvUiControllerBus
import com.mitv.customlauncher.service.MediaStateBus
import com.mitv.customlauncher.service.NavSoundPlayer
import com.mitv.customlauncher.service.VolumeHudBus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


/**
 * Планировщик отложенных голосовых напоминаний и умных команд через время (0 МБ лишней ОЗУ):
 * - Работает поверх любого приложения (YouTube, Kick, фильм) и в режиме ожидания
 * - При наступлении времени напоминания выдвигает Dynamic Island, приглушает звук ТВ и озвучивает напоминание живым голосом Gemini TTS!
 * - При наступлении времени отложенной команды (например, «включи ленту через 20 минут») сам выполняет команду.
 */
object LiveWorldContextRepository {
    private const val PREF_WORLD_WEATHER = "pref_world_weather_v93"
    private const val PREF_WORLD_FX = "pref_world_fx_v93"
    private const val PREF_WORLD_TS = "pref_world_ts_v93"
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile
    private var lastFetchMs: Long = 0L

    fun refreshAsyncIfNeeded(context: Context, force: Boolean = false) {
        val now = System.currentTimeMillis()
        val appCtx = context.applicationContext
        val prefs = appCtx.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val savedTs = prefs.getLong(PREF_WORLD_TS, 0L)
        if (!force && (now - lastFetchMs < 15 * 60 * 1000L || now - savedTs < 25 * 60 * 1000L)) {
            return
        }
        lastFetchMs = now
        ioScope.launch {
            var weatherStr = ""
            var fxStr = ""
            try {
                val conn = (URL("${LauncherConfig.CLOUDFLARE_GATEWAY_URL}/world/context?lat=50.3075&lon=31.4744").openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 2800
                    readTimeout = 3200
                    setRequestProperty("x-app-secret", LauncherConfig.GATEWAY_APP_SECRET)
                }
                if (conn.responseCode == 200) {
                    val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                    weatherStr = json.optString("weatherSummary", "").trim()
                    fxStr = json.optString("fxSummary", "").trim()
                }
            } catch (_: Exception) {
            }
            if (weatherStr.isEmpty()) {
                try {
                    val wUrl = "https://api.open-meteo.com/v1/forecast?latitude=50.3075&longitude=31.4744&current=temperature_2m,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=Europe%2FKyiv&forecast_days=2"
                    val conn = (URL(wUrl).openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 3000
                        readTimeout = 3500
                    }
                    if (conn.responseCode == 200) {
                        val wJson = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                        val cur = wJson.optJSONObject("current")
                        val daily = wJson.optJSONObject("daily")
                        val curT = Math.round(cur?.optDouble("temperature_2m", 0.0) ?: 0.0)
                        val wind = Math.round(cur?.optDouble("wind_speed_10m", 0.0) ?: 0.0)
                        val max0 = Math.round(daily?.optJSONArray("temperature_2m_max")?.optDouble(0, curT.toDouble()) ?: curT.toDouble())
                        val min0 = Math.round(daily?.optJSONArray("temperature_2m_min")?.optDouble(0, curT.toDouble()) ?: curT.toDouble())
                        val max1 = Math.round(daily?.optJSONArray("temperature_2m_max")?.optDouble(1, curT.toDouble()) ?: curT.toDouble())
                        val min1 = Math.round(daily?.optJSONArray("temperature_2m_min")?.optDouble(1, curT.toDouble()) ?: curT.toDouble())
                        val rain1 = daily?.optJSONArray("precipitation_probability_max")?.optInt(1, 0) ?: 0
                        weatherStr = "сейчас ${if (curT >= 0) "+$curT" else "$curT"}°C (ветер $wind км/ч), сегодня $min0..$max0°C, завтра $min1..$max1°C (вероятность осадков $rain1%)"
                    }
                } catch (_: Exception) {
                }
            }
            if (fxStr.isEmpty()) {
                try {
                    val conn = (URL("https://bank.gov.ua/NBUStatService/v1/statdirectory/exchange?json").openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 3000
                        readTimeout = 3500
                    }
                    if (conn.responseCode == 200) {
                        val arr = JSONArray(conn.inputStream.bufferedReader().use { it.readText() })
                        val parts = mutableListOf<String>()
                        for (i in 0 until arr.length()) {
                            val o = arr.optJSONObject(i) ?: continue
                            val cc = o.optString("cc", "")
                            if (cc == "USD" || cc == "EUR") {
                                val r = o.optDouble("rate", 0.0)
                                if (r > 0.0) parts.add("1 $cc = ${String.format(Locale.US, "%.2f", r)} грн")
                            }
                        }
                        fxStr = parts.joinToString(", ")
                    }
                } catch (_: Exception) {
                }
            }
            val ed = prefs.edit().putLong(PREF_WORLD_TS, System.currentTimeMillis())
            if (weatherStr.isNotEmpty()) ed.putString(PREF_WORLD_WEATHER, weatherStr)
            if (fxStr.isNotEmpty()) ed.putString(PREF_WORLD_FX, fxStr)
            ed.apply()
        }
    }

    fun getPromptSummary(context: Context): String {
        refreshAsyncIfNeeded(context, force = false)
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val w = prefs.getString(PREF_WORLD_WEATHER, "").orEmpty()
        val fx = prefs.getString(PREF_WORLD_FX, "").orEmpty()
        val sb = StringBuilder()
        if (w.isNotEmpty()) sb.append("Погода (Березань): $w.\n")
        if (fx.isNotEmpty()) sb.append("Курс валют НБУ: $fx.\n")
        return sb.toString()
    }

    fun searchWebBlocking(query: String): String {
        val clean = query.trim()
        if (clean.isEmpty()) return ""
        val snippets = mutableListOf<String>()
        try {
            val url = "${LauncherConfig.CLOUDFLARE_GATEWAY_URL}/web/search?q=${Uri.encode(clean)}"
            val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 2800
                readTimeout = 3200
                setRequestProperty("x-app-secret", LauncherConfig.GATEWAY_APP_SECRET)
            }
            if (conn.responseCode == 200) {
                val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                val arr = json.optJSONArray("snippets")
                if (arr != null) {
                    for (i in 0 until arr.length()) {
                        val s = arr.optString(i, "").trim()
                        if (s.isNotEmpty()) snippets.add(s)
                    }
                }
            }
        } catch (_: Exception) {
        }
        if (snippets.isEmpty()) {
            try {
                val wikiUrl = "https://ru.wikipedia.org/w/api.php?action=query&list=search&srsearch=${Uri.encode(clean)}&utf8=&format=json&srlimit=3"
                val conn = (URL(wikiUrl).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 2800
                    readTimeout = 3200
                    setRequestProperty("User-Agent", "MiTvEchoAgent/1.0")
                }
                if (conn.responseCode == 200) {
                    val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                    val arr = json.optJSONObject("query")?.optJSONArray("search")
                    if (arr != null) {
                        for (i in 0 until arr.length()) {
                            val item = arr.optJSONObject(i) ?: continue
                            val title = item.optString("title", "")
                            val snip = item.optString("snippet", "").replace(Regex("<[^>]+>"), "").trim()
                            if (snip.isNotEmpty()) snippets.add("$title: $snip")
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }
        return snippets.joinToString(" | ").take(900)
    }
}
