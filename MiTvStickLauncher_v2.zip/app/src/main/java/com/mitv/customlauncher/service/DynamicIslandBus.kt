package com.mitv.customlauncher.service

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.SoundPool
import android.media.MediaMetadata
import android.media.MediaRecorder
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Parcelable
import android.os.SystemClock
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.TextUtils
import android.util.Log
import android.util.LruCache
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.content.ClipData
import android.content.ClipboardManager
import java.util.Locale
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import com.mitv.customlauncher.R
import com.mitv.customlauncher.data.AssistantVoiceSpeaker
import com.mitv.customlauncher.data.GeminiCloudClient
import com.mitv.customlauncher.data.GeminiTurnResult
import com.mitv.customlauncher.data.LauncherConfig
import com.mitv.customlauncher.data.NativeCore
import com.mitv.customlauncher.data.LocalVoiceCommandRouter
import com.mitv.customlauncher.ui.EchoView
import com.mitv.customlauncher.ui.LauncherActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import org.json.JSONObject
import android.net.wifi.WifiManager
import android.os.PowerManager
import java.net.InetAddress
import java.net.InetSocketAddress
import com.mitv.customlauncher.data.TuyaSmartHomeController
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.net.URLEncoder
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sin
import kotlin.math.sqrt


object DynamicIslandBus {
    @Volatile
    var onTriggerIslandInService: (() -> Unit)? = null

    @Volatile
    var onTriggerIslandInActivity: (() -> Unit)? = null

    @Volatile
    var onTriggerVoiceTextInService: ((String) -> Unit)? = null

    @Volatile
    var onTriggerVoiceTextInActivity: ((String) -> Unit)? = null

    @Volatile
    var onDispatchKeyInActivity: ((Int) -> Boolean)? = null

    @Volatile
    var onHomePressedInActivity: (() -> Unit)? = null

    @Volatile
    var onRequestAudioPermissionInActivity: (() -> Unit)? = null

    @Volatile
    var onAccentColorUpdated: ((String) -> Unit)? = null

    @Volatile
    var onIslandVisibilityChanged: ((Boolean) -> Unit)? = null

    @Volatile
    var onShowAnnouncementInService: ((displayText: String, speakText: String) -> Unit)? = null

    @Volatile
    var isLauncherInForeground: Boolean = false

    @Volatile
    var onToggleControlCenterInActivity: (() -> Unit)? = null

    @Volatile
    var onToggleControlCenterInService: (() -> Unit)? = null

    @Volatile
    var onHideControlCenterOverlayInService: (() -> Unit)? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    private var lastAssistKeyTriggerMs: Long = 0L

    /** Кнопка ассистента уже обработана (onKeyEvent) — нужно, чтобы интент ASSIST/Katniss не запустил ассистента второй раз. */
    fun markAssistKeyTriggered() {
        lastAssistKeyTriggerMs = SystemClock.elapsedRealtime()
    }

    fun isAssistKeyRecentlyTriggered(windowMs: Long = 1500L): Boolean {
        val t = lastAssistKeyTriggerMs
        return t != 0L && SystemClock.elapsedRealtime() - t < windowMs
    }

    fun showAnnouncement(context: Context, displayText: String, speakText: String = displayText) {
        val srv = onShowAnnouncementInService
        if (srv != null && KeyMapperAccessibilityService.isServiceConnectedAlive) {
            mainHandler.post { srv.invoke(displayText, speakText) }
        } else {
            AssistantVoiceSpeaker.speak(context, speakText)
        }
    }

    fun triggerAssistant(context: Context) {
        val serviceTrigger = onTriggerIslandInService
        if (serviceTrigger != null && KeyMapperAccessibilityService.isServiceConnectedAlive) {
            mainHandler.post { serviceTrigger.invoke() }
            return
        }
        val activityTrigger = onTriggerIslandInActivity
        if (activityTrigger != null) {
            mainHandler.post { activityTrigger.invoke() }
            return
        }
        val intent = Intent(context, LauncherActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra("EXTRA_OPEN_AI", true)
        }
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
        }
    }

    fun triggerVoiceText(context: Context, rawText: String) {
        val clean = rawText.trim()
        if (clean.isEmpty()) {
            triggerAssistant(context)
            return
        }
        val serviceVoice = onTriggerVoiceTextInService
        if (serviceVoice != null && KeyMapperAccessibilityService.isServiceConnectedAlive) {
            mainHandler.post { serviceVoice.invoke(clean) }
            return
        }
        val activityVoice = onTriggerVoiceTextInActivity
        if (activityVoice != null) {
            mainHandler.post { activityVoice.invoke(clean) }
            return
        }
        val intent = Intent(context, LauncherActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra("EXTRA_VOICE_QUERY", clean)
        }
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
        }
    }

    fun notifyAccentColorChanged(hex: String) {
        mainHandler.post {
            onAccentColorUpdated?.invoke(hex)
        }
    }

    fun notifyIslandVisibility(visible: Boolean) {
        mainHandler.post {
            onIslandVisibilityChanged?.invoke(visible)
        }
    }
}
