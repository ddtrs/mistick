package com.mitv.customlauncher.data

import android.graphics.Bitmap
import android.graphics.Color
import android.view.animation.Interpolator
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Гибридный нативный движок ядра лаунчера (Rust JNI `liblauncher_native.so` + безотказный резерв).
 *
 * Объединяет 6 высокопроизводительных подсистем:
 * 1. [blurAndTint] — 3-проходное размытие со скользящим окном O(1) и матовой тонировкой без вызовов GC.
 * 2. [extractDominantCoverHsv] — спектральный анализатор обложек Spotify/музыки для режима «Амбилайн».
 * 3. [extractMonochromeGlyph] — векторизация иконок сторонних приложений в монохромный стиль лаунчера.
 * 4. [SpringInterpolator] — физика упругих пружин Apple TV / tvOS для карточек и Пункта управления.
 * 5. [computePcmRms] / [trimPcmSilence] — нативный голосовой детектор активности (VAD) для Gemini AI.
 * 6. [classifyRemoteKey] — мгновенный классификатор аппаратных сканкодов пульта Xiaomi (Микрофон, Netflix, Prime, Mi).
 */
object NativeCore {

    const val KEY_CLASS_NORMAL = 0
    const val KEY_CLASS_VOICE_ASSIST = 1
    const val KEY_CLASS_PATCHWALL = 2
    const val KEY_CLASS_NETFLIX = 3
    const val KEY_CLASS_PRIME = 4

    @Volatile
    var isRustLoaded: Boolean = false
        private set

    init {
        try {
            System.loadLibrary("launcher_native")
            isRustLoaded = true
        } catch (_: Throwable) {
            isRustLoaded = false
        }
    }

    @JvmStatic
    private external fun nativeBlurAndTint(
        pixels: IntArray,
        width: Int,
        height: Int,
        radius: Int,
        tintArgb: Int
    )

    @JvmStatic
    private external fun nativeExtractDominantCoverHsv(
        pixels: IntArray,
        width: Int,
        height: Int
    ): Int

    @JvmStatic
    private external fun nativeExtractMonochromeGlyph(
        pixels: IntArray,
        size: Int
    ): Int

    @JvmStatic
    private external fun nativeEvaluateSpring(
        progress: Float,
        dampingRatio: Float,
        angularFreq: Float
    ): Float

    @JvmStatic
    private external fun nativeComputePcmRms(
        pcmBytes: ByteArray,
        validLen: Int
    ): Int

    @JvmStatic
    private external fun nativeTrimPcmSilenceBounds(
        pcmBytes: ByteArray,
        sampleRate: Int
    ): Long

    @JvmStatic
    private external fun nativeClassifyRemoteKey(
        keyCode: Int,
        scanCode: Int
    ): Int

    @JvmStatic
    private external fun nativeReadVaultEntry(
        slot: Int,
        outBuf: ByteArray
    ): Int

    /**
     * 1. Быстрое размытие экрана со скользящим сумматором O(1) и наложением матового стекла.
     */
    fun blurAndTint(pixels: IntArray, width: Int, height: Int, radius: Int = 5, tintArgb: Int = 0x8807090F.toInt()) {
        if (width < 4 || height < 4 || pixels.size < width * height) return
        if (isRustLoaded) {
            try {
                nativeBlurAndTint(pixels, width, height, radius, tintArgb)
                return
            } catch (_: Throwable) {
            }
        }
        // Оптимизированный O(1) скользящий сумматор (без вложенного цикла по радиусу!)
        val total = width * height
        val r = radius.coerceIn(1, 16)
        val tmp = IntArray(total)
        repeat(3) {
            for (y in 0 until height) {
                val row = y * width
                var rSum = 0
                var gSum = 0
                var bSum = 0
                var count = 0
                val maxInit = min(r, width - 1)
                for (dx in 0..maxInit) {
                    val c = pixels[row + dx]
                    rSum += (c ushr 16) and 0xFF
                    gSum += (c ushr 8) and 0xFF
                    bSum += c and 0xFF
                    count++
                }
                for (x in 0 until width) {
                    if (x > 0) {
                        val addX = x + r
                        if (addX < width) {
                            val c = pixels[row + addX]
                            rSum += (c ushr 16) and 0xFF
                            gSum += (c ushr 8) and 0xFF
                            bSum += c and 0xFF
                            count++
                        }
                        if (x > r) {
                            val remX = x - r - 1
                            val c = pixels[row + remX]
                            rSum -= (c ushr 16) and 0xFF
                            gSum -= (c ushr 8) and 0xFF
                            bSum -= c and 0xFF
                            count--
                        }
                    }
                    val inv = count.coerceAtLeast(1)
                    tmp[row + x] = (0xFF shl 24) or ((rSum / inv) shl 16) or ((gSum / inv) shl 8) or (bSum / inv)
                }
            }
            for (x in 0 until width) {
                var rSum = 0
                var gSum = 0
                var bSum = 0
                var count = 0
                val maxInit = min(r, height - 1)
                for (dy in 0..maxInit) {
                    val c = tmp[dy * width + x]
                    rSum += (c ushr 16) and 0xFF
                    gSum += (c ushr 8) and 0xFF
                    bSum += c and 0xFF
                    count++
                }
                for (y in 0 until height) {
                    if (y > 0) {
                        val addY = y + r
                        if (addY < height) {
                            val c = tmp[addY * width + x]
                            rSum += (c ushr 16) and 0xFF
                            gSum += (c ushr 8) and 0xFF
                            bSum += c and 0xFF
                            count++
                        }
                        if (y > r) {
                            val remY = y - r - 1
                            val c = tmp[remY * width + x]
                            rSum -= (c ushr 16) and 0xFF
                            gSum -= (c ushr 8) and 0xFF
                            bSum -= c and 0xFF
                            count--
                        }
                    }
                    val inv = count.coerceAtLeast(1)
                    pixels[y * width + x] = (0xFF shl 24) or ((rSum / inv) shl 16) or ((gSum / inv) shl 8) or (bSum / inv)
                }
            }
        }
        val ta = (tintArgb ushr 24) and 0xFF
        if (ta > 0) {
            val tr = (tintArgb ushr 16) and 0xFF
            val tg = (tintArgb ushr 8) and 0xFF
            val tb = tintArgb and 0xFF
            val invA = 255 - ta
            for (i in 0 until total) {
                val c = pixels[i]
                val rCh = (((c ushr 16) and 0xFF) * invA + tr * ta) / 255
                val gCh = (((c ushr 8) and 0xFF) * invA + tg * ta) / 255
                val bCh = ((c and 0xFF) * invA + tb * ta) / 255
                pixels[i] = (0xFF shl 24) or (rCh shl 16) or (gCh shl 8) or bCh
            }
        }
    }

    /**
     * 2. Извлечение доминирующего оттенка обложки альбома для режима «Амбилайн».
     */
    fun extractDominantCoverHsv(bmp: Bitmap?): Pair<Int, Int>? {
        if (bmp == null || bmp.isRecycled || bmp.width <= 0 || bmp.height <= 0) return null
        return try {
            val w = bmp.width
            val h = bmp.height
            if (isRustLoaded) {
                val pixels = IntArray(w * h)
                bmp.getPixels(pixels, 0, w, 0, 0, w, h)
                val packed = nativeExtractDominantCoverHsv(pixels, w, h)
                val hue = (packed ushr 16) and 0xFFFF
                val sat = packed and 0xFFFF
                return hue.coerceIn(0, 360) to sat.coerceIn(60, 100)
            }
            val bucketWeights = FloatArray(36)
            val bucketHueSum = FloatArray(36)
            val bucketSatSum = FloatArray(36)
            val hsv = FloatArray(3)
            val stepX = (w / 20).coerceAtLeast(1)
            val stepY = (h / 20).coerceAtLeast(1)
            var y = stepY / 2
            while (y < h) {
                var x = stepX / 2
                while (x < w) {
                    val px = bmp.getPixel(x, y)
                    if (Color.alpha(px) > 140) {
                        Color.colorToHSV(px, hsv)
                        val deg = hsv[0]
                        val sat = hsv[1]
                        val bri = hsv[2]
                        if (bri > 0.18f && sat > 0.24f) {
                            val bucket = ((deg.toInt() % 360) / 10).coerceIn(0, 35)
                            val skinPenalty = if (deg in 14f..44f && sat < 0.68f) 0.22f else 1.0f
                            val weight = (sat * sat * sat * bri) * skinPenalty
                            bucketWeights[bucket] += weight
                            bucketHueSum[bucket] += deg * weight
                            bucketSatSum[bucket] += sat * weight
                        }
                    }
                    x += stepX
                }
                y += stepY
            }
            var bestBucket = -1
            var bestWeight = 0f
            for (i in 0 until 36) {
                if (bucketWeights[i] > bestWeight) {
                    bestWeight = bucketWeights[i]
                    bestBucket = i
                }
            }
            if (bestBucket >= 0 && bestWeight > 0.02f) {
                val rawHue = (bucketHueSum[bestBucket] / bestWeight).toInt().coerceIn(0, 360)
                val avgSat = (bucketSatSum[bestBucket] / bestWeight).coerceIn(0.75f, 1.0f)
                rawHue to (avgSat * 100f).toInt().coerceIn(80, 100)
            } else {
                195 to 60
            }
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * 3. Монохромная векторизация растровой иконки в фирменный стиль лаунчера.
     */
    fun extractMonochromeGlyph(pixels: IntArray, size: Int): Int {
        if (isRustLoaded) {
            try {
                return nativeExtractMonochromeGlyph(pixels, size)
            } catch (_: Throwable) {
            }
        }
        val cornerColor = pixels[5 * size + 5]
        val cornerA = Color.alpha(cornerColor)
        val cornerR = Color.red(cornerColor)
        val cornerG = Color.green(cornerColor)
        val cornerB = Color.blue(cornerColor)
        val hasSolidBackground = cornerA > 200
        var visibleCount = 0
        for (i in pixels.indices) {
            val c = pixels[i]
            val a = Color.alpha(c)
            if (a < 30) {
                pixels[i] = Color.TRANSPARENT
                continue
            }
            val r = Color.red(c)
            val g = Color.green(c)
            val b = Color.blue(c)
            val outAlpha: Int = if (hasSolidBackground) {
                val diff = (abs(r - cornerR) + abs(g - cornerG) + abs(b - cornerB)) / 3
                if (diff < 24) 0 else min(255, diff * 2)
            } else {
                val lum = (0.299f * r + 0.587f * g + 0.114f * b).toInt()
                val boost = max(140, lum)
                (a * boost) / 255
            }
            if (outAlpha > 35) {
                visibleCount++
                pixels[i] = Color.argb(outAlpha, 255, 255, 255)
            } else {
                pixels[i] = Color.TRANSPARENT
            }
        }
        return visibleCount
    }

    /**
     * 4. Физика упругой пружины (Rust Spring Dynamics) для анимаций фокуса и скролла.
     */
    fun evaluateSpring(progress: Float, dampingRatio: Float = 0.78f, angularFreq: Float = 11.5f): Float {
        if (isRustLoaded) {
            try {
                return nativeEvaluateSpring(progress, dampingRatio, angularFreq)
            } catch (_: Throwable) {
            }
        }
        val t = progress.coerceIn(0f, 1f)
        if (t <= 0f) return 0f
        if (t >= 1f) return 1f
        val zeta = dampingRatio.coerceIn(0.45f, 0.99f).toDouble()
        val omega = angularFreq.coerceIn(6f, 22f).toDouble()
        val omegaD = omega * sqrt(1.0 - zeta * zeta)
        val decay = exp(-zeta * omega * t)
        val raw = 1.0 - decay * (cos(omegaD * t) + ((zeta * omega) / omegaD) * sin(omegaD * t))
        return raw.toFloat().coerceIn(0f, 1.06f)
    }

    class SpringInterpolator(
        private val dampingRatio: Float = 0.78f,
        private val angularFreq: Float = 11.5f
    ) : Interpolator {
        override fun getInterpolation(input: Float): Float {
            return evaluateSpring(input, dampingRatio, angularFreq)
        }
    }

    /**
     * 5. Нативный расчёт RMS энергии и обрезка тишины для микрофона Gemini AI.
     */
    fun computePcmRms(pcmBytes: ByteArray, validLen: Int = pcmBytes.size): Double {
        if (isRustLoaded) {
            try {
                return nativeComputePcmRms(pcmBytes, validLen).toDouble()
            } catch (_: Throwable) {
            }
        }
        val samples = validLen / 2
        if (samples <= 0) return 0.0
        var sumSq = 0.0
        var i = 0
        while (i + 1 < validLen) {
            val lo = pcmBytes[i].toInt() and 0xFF
            val hi = pcmBytes[i + 1].toInt()
            val sample = ((hi shl 8) or lo).toShort().toDouble()
            sumSq += sample * sample
            i += 2
        }
        return sqrt(sumSq / samples)
    }

    fun trimPcmSilence(pcmData: ByteArray, sampleRate: Int): ByteArray {
        if (pcmData.size < 3200) return pcmData
        if (isRustLoaded) {
            try {
                val packed = nativeTrimPcmSilenceBounds(pcmData, sampleRate)
                val startByte = ((packed ushr 32) and 0xFFFFFFFFL).toInt().coerceIn(0, pcmData.size)
                val endByte = (packed and 0xFFFFFFFFL).toInt().coerceIn(0, pcmData.size)
                if (endByte > startByte && (startByte > 0 || endByte < pcmData.size)) {
                    return pcmData.copyOfRange(startByte, endByte)
                }
                return pcmData
            } catch (_: Throwable) {
            }
        }
        val totalSamples = pcmData.size / 2
        val frameSamples = 320
        val totalFrames = totalSamples / frameSamples
        var firstSpeechFrame = -1
        var lastSpeechFrame = -1
        for (f in 0 until totalFrames) {
            var sumSq = 0.0
            val baseIdx = f * frameSamples * 2
            for (s in 0 until frameSamples) {
                val idx = baseIdx + s * 2
                val lo = pcmData[idx].toInt() and 0xFF
                val hi = pcmData[idx + 1].toInt()
                val sample = ((hi shl 8) or lo).toShort().toDouble()
                sumSq += sample * sample
            }
            val rms = sqrt(sumSq / frameSamples)
            if (rms > 240.0) {
                if (firstSpeechFrame == -1) firstSpeechFrame = f
                lastSpeechFrame = f
            }
        }
        if (firstSpeechFrame == -1 || lastSpeechFrame == -1) return pcmData
        val preRollFrames = (0.12 * sampleRate / frameSamples).toInt()
        val postRollFrames = (0.16 * sampleRate / frameSamples).toInt()
        val startFrame = (firstSpeechFrame - preRollFrames).coerceAtLeast(0)
        val endFrame = (lastSpeechFrame + postRollFrames + 1).coerceAtMost(totalFrames)
        val startByte = startFrame * frameSamples * 2
        val endByte = (endFrame * frameSamples * 2).coerceAtMost(pcmData.size)
        return if (endByte > startByte) pcmData.copyOfRange(startByte, endByte) else pcmData
    }

    /**
     * 6. Мгновенная нативная классификация аппаратных кнопок пульта Xiaomi.
     */
    fun classifyRemoteKey(keyCode: Int, scanCode: Int): Int {
        if (isRustLoaded) {
            try {
                return nativeClassifyRemoteKey(keyCode, scanCode)
            } catch (_: Throwable) {
            }
        }
        if (keyCode == 231 || keyCode == 219 || keyCode == 84 || scanCode == 582 || scanCode == 217 || scanCode == 221) {
            return KEY_CLASS_VOICE_ASSIST
        }
        if (keyCode == 284 || keyCode == 82 || keyCode == 172 || keyCode == 176 || keyCode == 178 || keyCode == 188 ||
            scanCode == 139 || scanCode == 362 || scanCode == 172 || scanCode == 256
        ) {
            return KEY_CLASS_PATCHWALL
        }
        if (keyCode == 189 || keyCode == 183 || keyCode == 309 || scanCode == 412 || scanCode == 398 || scanCode == 393) {
            return KEY_CLASS_NETFLIX
        }
        if (keyCode == 190 || keyCode == 186 || keyCode == 310 || scanCode == 413 || scanCode == 401 || scanCode == 400) {
            return KEY_CLASS_PRIME
        }
        return KEY_CLASS_NORMAL
    }
    private val FALLBACK_VAULT_KEYS: Array<IntArray> = arrayOf(
        intArrayOf(27, 54, 222, 168, 189, 106, 124, 52, 238, 193, 156, 165, 64, 80, 25, 211, 206, 246, 144, 65, 113, 59, 240, 250, 188, 184, 122, 5, 54, 250, 254, 179, 171, 82, 54, 8, 233, 198, 224),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 237, 141, 192, 99, 92, 1, 231, 157, 188, 130, 113, 112, 32, 193, 232, 151, 184, 45, 57, 75, 254, 239, 178, 184, 106, 39, 4, 216, 235, 224, 175, 65, 53, 33, 244, 238, 180, 95, 109, 15, 61, 199, 245, 169),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 237, 132, 160, 108, 115, 54, 206, 203, 144, 165, 74, 73, 83, 255, 212, 231, 165, 87, 54, 63, 193, 239, 186, 215, 70, 125, 12, 221, 248, 139, 171, 20, 48, 92, 227, 220, 154, 51, 110, 62, 34, 193, 141, 185),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 235, 185, 159, 85, 104, 38, 196, 152, 132, 182, 122, 77, 87, 208, 255, 130, 129, 69, 15, 85, 196, 214, 190, 170, 120, 13, 56, 234, 219, 171, 162, 116, 32, 88, 245, 222, 182, 57, 100, 124, 35, 242, 143, 143),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 237, 131, 168, 119, 73, 82, 196, 253, 140, 217, 114, 71, 16, 242, 202, 159, 147, 93, 5, 81, 190, 211, 147, 201, 120, 42, 68, 254, 196, 168, 180, 100, 38, 41, 161, 217, 172, 84, 71, 124, 54, 214, 233, 159),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 237, 141, 171, 83, 119, 87, 208, 245, 171, 163, 88, 123, 12, 209, 213, 138, 160, 76, 11, 86, 229, 241, 177, 151, 80, 12, 80, 248, 210, 151, 159, 111, 5, 63, 218, 218, 140, 68, 110, 14, 2, 226, 225, 159),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 237, 175, 200, 89, 83, 2, 192, 230, 185, 128, 83, 76, 40, 204, 199, 138, 165, 74, 45, 85, 228, 130, 182, 142, 64, 38, 0, 209, 210, 187, 172, 125, 19, 20, 212, 193, 154, 120, 84, 47, 39, 242, 209, 159),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 236, 189, 146, 47, 3, 89, 208, 204, 150, 185, 119, 12, 26, 237, 254, 152, 177, 44, 120, 36, 227, 252, 132, 182, 40, 10, 59, 250, 221, 179, 149, 71, 6, 27, 194, 209, 143, 48, 115, 44, 30, 193, 248, 159),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 238, 130, 182, 98, 124, 83, 211, 152, 164, 166, 112, 7, 53, 205, 202, 184, 147, 111, 38, 45, 206, 200, 190, 195, 84, 62, 29, 192, 214, 143, 146, 84, 36, 36, 252, 217, 158, 65, 102, 24, 89, 167, 246, 169),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 237, 188, 139, 123, 89, 2, 232, 210, 167, 164, 91, 112, 57, 188, 152, 160, 142, 117, 47, 16, 207, 200, 167, 159, 39, 19, 36, 198, 138, 151, 158, 125, 116, 51, 240, 243, 144, 89, 77, 27, 5, 252, 243, 185),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 235, 170, 200, 83, 87, 58, 247, 248, 170, 193, 92, 97, 33, 189, 221, 159, 153, 41, 117, 18, 179, 193, 162, 200, 125, 45, 7, 199, 193, 187, 204, 22, 63, 29, 255, 212, 173, 74, 99, 43, 60, 243, 246, 169),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 236, 132, 132, 81, 11, 46, 231, 152, 249, 167, 92, 91, 1, 197, 198, 152, 154, 41, 32, 11, 223, 133, 229, 144, 94, 113, 25, 239, 198, 177, 207, 88, 43, 21, 225, 243, 172, 117, 125, 63, 41, 243, 201, 185),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 235, 136, 161, 78, 14, 42, 182, 152, 182, 195, 120, 89, 14, 236, 224, 159, 175, 37, 119, 50, 218, 251, 226, 155, 103, 105, 43, 187, 244, 171, 152, 85, 46, 51, 162, 250, 170, 78, 97, 28, 31, 205, 237, 169),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 238, 128, 146, 33, 14, 37, 207, 217, 155, 174, 76, 73, 11, 217, 226, 156, 143, 75, 4, 48, 237, 223, 159, 136, 108, 33, 14, 232, 131, 225, 168, 106, 10, 37, 225, 196, 168, 67, 110, 30, 27, 163, 255, 159),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 236, 182, 166, 64, 94, 2, 220, 252, 182, 176, 78, 105, 80, 234, 221, 163, 159, 36, 120, 57, 185, 255, 151, 183, 45, 29, 27, 216, 210, 234, 186, 17, 5, 89, 200, 197, 172, 116, 106, 14, 1, 248, 208, 159),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 236, 173, 133, 36, 9, 23, 199, 146, 247, 196, 79, 14, 16, 186, 234, 134, 145, 82, 4, 19, 199, 222, 152, 187, 40, 51, 11, 203, 192, 148, 188, 119, 40, 51, 211, 221, 153, 69, 8, 11, 32, 185, 218, 143),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 238, 152, 196, 87, 74, 87, 252, 227, 163, 204, 46, 119, 46, 188, 154, 158, 180, 47, 13, 5, 230, 215, 237, 170, 105, 62, 95, 209, 135, 156, 203, 119, 34, 92, 163, 226, 147, 108, 96, 26, 59, 166, 215, 169),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 237, 132, 199, 59, 92, 10, 201, 158, 166, 134, 125, 116, 14, 191, 196, 131, 150, 127, 45, 95, 191, 232, 132, 143, 105, 35, 2, 229, 246, 154, 191, 101, 22, 37, 240, 240, 184, 56, 73, 25, 94, 221, 241, 143),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 238, 157, 146, 80, 81, 33, 168, 249, 153, 146, 94, 93, 12, 220, 192, 150, 186, 77, 43, 44, 178, 197, 176, 183, 47, 51, 17, 198, 221, 187, 165, 114, 55, 47, 201, 142, 137, 102, 17, 60, 26, 248, 242, 159),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 237, 156, 150, 127, 78, 36, 238, 239, 158, 162, 41, 14, 37, 254, 198, 131, 161, 70, 44, 83, 232, 231, 180, 171, 70, 37, 56, 212, 194, 180, 145, 79, 24, 28, 163, 231, 236, 78, 125, 123, 39, 165, 234, 143),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 237, 169, 139, 65, 114, 10, 206, 153, 163, 198, 97, 112, 59, 192, 244, 139, 177, 120, 119, 20, 197, 193, 226, 189, 121, 33, 40, 215, 222, 176, 177, 125, 114, 10, 223, 244, 145, 109, 104, 18, 43, 237, 218, 143),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 238, 254, 188, 73, 89, 16, 195, 208, 140, 157, 44, 107, 9, 235, 200, 181, 189, 87, 35, 45, 237, 245, 177, 190, 103, 38, 68, 186, 231, 189, 204, 68, 23, 94, 254, 198, 191, 71, 99, 40, 94, 198, 211, 143),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 238, 182, 194, 123, 87, 12, 245, 147, 162, 196, 113, 73, 45, 208, 152, 227, 150, 40, 108, 50, 210, 222, 182, 194, 47, 12, 42, 193, 220, 148, 167, 114, 36, 22, 168, 132, 176, 81, 81, 126, 86, 164, 250, 169),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 238, 245, 132, 96, 74, 49, 214, 154, 133, 217, 113, 13, 27, 253, 200, 224, 150, 119, 23, 4, 251, 136, 226, 203, 50, 39, 39, 204, 247, 154, 154, 104, 31, 2, 210, 192, 236, 79, 87, 46, 91, 211, 245, 143),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 237, 161, 192, 125, 76, 81, 230, 226, 160, 171, 82, 104, 11, 223, 224, 190, 146, 84, 6, 62, 250, 137, 152, 131, 73, 27, 26, 204, 217, 154, 164, 102, 2, 92, 225, 219, 141, 89, 108, 57, 0, 166, 232, 143),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 235, 141, 148, 119, 108, 11, 214, 219, 140, 204, 93, 15, 43, 219, 218, 167, 143, 119, 116, 34, 229, 129, 138, 160, 102, 17, 54, 187, 210, 182, 174, 106, 41, 34, 227, 226, 169, 95, 76, 0, 92, 210, 219, 143),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 235, 173, 182, 47, 22, 8, 193, 230, 161, 152, 79, 119, 8, 229, 193, 159, 191, 83, 10, 16, 219, 134, 158, 187, 80, 46, 42, 207, 234, 158, 156, 96, 116, 20, 243, 198, 142, 107, 16, 60, 21, 196, 218, 185),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 236, 174, 193, 66, 114, 14, 198, 237, 129, 155, 80, 106, 32, 251, 201, 138, 179, 102, 42, 62, 232, 234, 165, 147, 64, 27, 12, 203, 249, 233, 156, 86, 127, 56, 168, 204, 237, 74, 95, 124, 60, 222, 242, 143),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 235, 164, 182, 37, 108, 33, 228, 235, 160, 197, 86, 84, 82, 252, 252, 176, 181, 82, 0, 32, 197, 255, 152, 151, 41, 22, 32, 186, 220, 159, 208, 112, 61, 88, 211, 228, 234, 116, 117, 7, 93, 252, 140, 185),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 236, 255, 200, 32, 113, 43, 246, 229, 169, 187, 76, 70, 15, 191, 216, 138, 186, 83, 3, 41, 188, 198, 162, 144, 77, 39, 1, 220, 220, 154, 196, 111, 36, 57, 162, 128, 129, 119, 125, 24, 12, 213, 250, 159),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 238, 244, 152, 122, 90, 51, 207, 207, 168, 158, 67, 116, 27, 225, 199, 149, 165, 79, 48, 81, 200, 217, 182, 181, 85, 114, 15, 218, 203, 150, 191, 73, 53, 26, 245, 204, 233, 88, 66, 51, 40, 249, 210, 185),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 238, 158, 137, 120, 115, 47, 245, 240, 161, 194, 96, 68, 53, 226, 236, 176, 188, 112, 16, 53, 206, 224, 163, 142, 103, 16, 45, 214, 198, 178, 140, 110, 63, 61, 215, 253, 227, 89, 82, 27, 55, 172, 251, 169),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 237, 175, 174, 81, 97, 37, 168, 205, 135, 132, 97, 79, 36, 223, 221, 255, 147, 70, 113, 53, 242, 230, 158, 183, 122, 19, 39, 187, 193, 234, 206, 90, 45, 10, 165, 248, 163, 105, 117, 124, 4, 160, 246, 185),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 236, 141, 190, 124, 121, 2, 231, 232, 170, 128, 107, 121, 57, 223, 235, 170, 166, 44, 16, 41, 233, 219, 134, 146, 103, 48, 56, 191, 135, 135, 152, 65, 51, 8, 212, 216, 130, 90, 92, 15, 28, 252, 243, 185),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 236, 186, 190, 126, 22, 16, 235, 227, 159, 176, 110, 80, 10, 201, 229, 135, 144, 82, 21, 30, 230, 229, 128, 137, 38, 113, 4, 212, 214, 148, 165, 115, 1, 6, 196, 192, 172, 85, 106, 30, 41, 209, 214, 169),
        intArrayOf(27, 46, 138, 136, 140, 43, 106, 19, 180, 235, 180, 191, 79, 119, 44, 204, 238, 158, 197, 96, 79, 50, 253, 193, 226, 207, 89, 120, 95, 234, 137, 190, 148, 87, 38, 38, 255, 138, 149, 190, 122, 18, 35, 254, 193, 246, 116, 108, 35, 87, 254, 252, 143),
    )
    private val FB_TUYA_CID = intArrayOf(47, 40, 3, 240, 240, 153, 200, 184, 214, 197, 125, 101, 26, 53, 51, 30, 79, 234, 192, 217)
    private val FB_TUYA_SEC = intArrayOf(95, 67, 188, 152, 128, 244, 187, 137, 206, 39, 16, 14, 127, 106, 21, 182, 174, 152, 140, 182, 130, 195, 48, 46, 30, 32, 99, 92, 29, 232, 147, 131)
    private val FB_TUYA_SEC_ALT = intArrayOf(95, 67, 188, 152, 128, 244, 187, 137, 206, 39, 16, 14, 127, 106, 21, 182, 174, 152, 140, 225, 133, 151, 60, 37, 29, 115, 55, 94, 79, 232, 199, 134, 240)
    private val FB_TUYA_STRIP = intArrayOf(79, 38, 103, 7, 29, 237, 252, 128, 253, 189, 211, 155, 37, 66, 2, 40, 109, 18, 240, 240, 220, 205)
    private val FB_TUYA_BULB = intArrayOf(79, 38, 96, 4, 27, 234, 251, 139, 163, 235, 223, 198, 115, 17, 81, 114, 63, 21, 235, 251, 192, 219)
    private val FB_GW_SECRET = intArrayOf(62, 15, 13, 250, 192, 213, 178, 135, 157, 198, 36, 123, 15, 124, 56, 64, 176, 161, 202, 142, 169, 213, 147, 107, 47, 23, 112, 54)

    const val VAULT_GEMINI_COUNT = 36

    /**
     * 7. Чтение защищённого ключа из нативного C/Rust-хранилища (liblauncher_native.so).
     */
    fun readVaultEntry(slot: Int): String {
        if (isRustLoaded) {
            try {
                val buf = ByteArray(128)
                val len = nativeReadVaultEntry(slot, buf)
                if (len > 0) {
                    return String(buf, 0, len, Charsets.UTF_8).trim()
                }
            } catch (_: Throwable) {
            }
        }
        if (slot in 0 until FALLBACK_VAULT_KEYS.size) {
            val bytes = FALLBACK_VAULT_KEYS[slot]
            val out = CharArray(bytes.size)
            for (i in bytes.indices) {
                out[i] = (bytes[i] xor ((i * 37 + 0x5A) and 0xFF)).toChar()
            }
            return String(out).trim()
        }
        val pair: Pair<IntArray, Int> = when (slot) {
            100 -> FB_TUYA_CID to 0x4B
            101 -> FB_TUYA_SEC to 0x67
            102 -> FB_TUYA_SEC_ALT to 0x67
            103 -> FB_TUYA_STRIP to 0x2D
            104 -> FB_TUYA_BULB to 0x2D
            105 -> FB_GW_SECRET to 0x53
            else -> return ""
        }
        val (arr, salt) = pair
        val chars = CharArray(arr.size)
        for (i in arr.indices) {
            chars[i] = (arr[i] xor ((salt + i * 19) and 0xFF)).toChar()
        }
        return String(chars)
    }
}
