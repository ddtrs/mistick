package com.mitv.customlauncher.data

import android.graphics.Bitmap
import android.graphics.Color
import android.view.animation.Interpolator
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Гибридный нативный движок ядра лаунчера (Rust JNI `liblauncher_native.so` + безотказный резерв).
 *
 * Объединяет 6 высокопроизводительных подсистем:
 * 1. [blurAndTint] — 3-проходное размытие со скользящим окном O(1) и матовой тонировкой без вызовов GC.
 * 2. [extractDominantCoverHsv] — спектральный анализатор обложек Spotify/музыки для режима «Амбилайн».
 * 3. [extractMonochromeGlyph] — векторизация иконок сторонних приложений в монохромный стиль лаунчера.
 * 4. [SpringInterpolator] — физика упругих пружин Apple TV / tvOS для карточек и Пункта управления.
 * 5. [computePcmRms] / [trimPcmSilence] — нативный голосовой детектор активности (VAD) для Gemini AI.
 * 6. [classifyRemoteKey] — мгновенный классификатор аппаратных сканкодов пульта Xiaomi (Микрофон, Netflix, Prime, Mi).
 */
object NativeCore {

    const val KEY_CLASS_NORMAL = 0
    const val KEY_CLASS_VOICE_ASSIST = 1
    const val KEY_CLASS_PATCHWALL = 2
    const val KEY_CLASS_NETFLIX = 3
    const val KEY_CLASS_PRIME = 4

    @Volatile
    var isRustLoaded: Boolean = false
        private set

    init {
        try {
            System.loadLibrary("launcher_native")
            isRustLoaded = true
        } catch (_: Throwable) {
            isRustLoaded = false
        }
    }

    @JvmStatic
    private external fun nativeBlurAndTint(
        pixels: IntArray,
        width: Int,
        height: Int,
        radius: Int,
        tintArgb: Int
    )

    @JvmStatic
    private external fun nativeExtractDominantCoverHsv(
        pixels: IntArray,
        width: Int,
        height: Int
    ): Int

    @JvmStatic
    private external fun nativeExtractMonochromeGlyph(
        pixels: IntArray,
        size: Int
    ): Int

    @JvmStatic
    private external fun nativeEvaluateSpring(
        progress: Float,
        dampingRatio: Float,
        angularFreq: Float
    ): Float

    @JvmStatic
    private external fun nativeComputePcmRms(
        pcmBytes: ByteArray,
        validLen: Int
    ): Int

    @JvmStatic
    private external fun nativeTrimPcmSilenceBounds(
        pcmBytes: ByteArray,
        sampleRate: Int
    ): Long

    @JvmStatic
    private external fun nativeClassifyRemoteKey(
        keyCode: Int,
        scanCode: Int
    ): Int

    /**
     * 1. Быстрое размытие экрана со скользящим сумматором O(1) и наложением матового стекла.
     */
    fun blurAndTint(pixels: IntArray, width: Int, height: Int, radius: Int = 5, tintArgb: Int = 0x8807090F.toInt()) {
        if (width < 4 || height < 4 || pixels.size < width * height) return
        if (isRustLoaded) {
            try {
                nativeBlurAndTint(pixels, width, height, radius, tintArgb)
                return
            } catch (_: Throwable) {
            }
        }
        // Оптимизированный O(1) скользящий сумматор (без вложенного цикла по радиусу!)
        val total = width * height
        val r = radius.coerceIn(1, 16)
        val tmp = IntArray(total)
        repeat(3) {
            for (y in 0 until height) {
                val row = y * width
                var rSum = 0
                var gSum = 0
                var bSum = 0
                var count = 0
                val maxInit = min(r, width - 1)
                for (dx in 0..maxInit) {
                    val c = pixels[row + dx]
                    rSum += (c ushr 16) and 0xFF
                    gSum += (c ushr 8) and 0xFF
                    bSum += c and 0xFF
                    count++
                }
                for (x in 0 until width) {
                    if (x > 0) {
                        val addX = x + r
                        if (addX < width) {
                            val c = pixels[row + addX]
                            rSum += (c ushr 16) and 0xFF
                            gSum += (c ushr 8) and 0xFF
                            bSum += c and 0xFF
                            count++
                        }
                        if (x > r) {
                            val remX = x - r - 1
                            val c = pixels[row + remX]
                            rSum -= (c ushr 16) and 0xFF
                            gSum -= (c ushr 8) and 0xFF
                            bSum -= c and 0xFF
                            count--
                        }
                    }
                    val inv = count.coerceAtLeast(1)
                    tmp[row + x] = (0xFF shl 24) or ((rSum / inv) shl 16) or ((gSum / inv) shl 8) or (bSum / inv)
                }
            }
            for (x in 0 until width) {
                var rSum = 0
                var gSum = 0
                var bSum = 0
                var count = 0
                val maxInit = min(r, height - 1)
                for (dy in 0..maxInit) {
                    val c = tmp[dy * width + x]
                    rSum += (c ushr 16) and 0xFF
                    gSum += (c ushr 8) and 0xFF
                    bSum += c and 0xFF
                    count++
                }
                for (y in 0 until height) {
                    if (y > 0) {
                        val addY = y + r
                        if (addY < height) {
                            val c = tmp[addY * width + x]
                            rSum += (c ushr 16) and 0xFF
                            gSum += (c ushr 8) and 0xFF
                            bSum += c and 0xFF
                            count++
                        }
                        if (y > r) {
                            val remY = y - r - 1
                            val c = tmp[remY * width + x]
                            rSum -= (c ushr 16) and 0xFF
                            gSum -= (c ushr 8) and 0xFF
                            bSum -= c and 0xFF
                            count--
                        }
                    }
                    val inv = count.coerceAtLeast(1)
                    pixels[y * width + x] = (0xFF shl 24) or ((rSum / inv) shl 16) or ((gSum / inv) shl 8) or (bSum / inv)
                }
            }
        }
        val ta = (tintArgb ushr 24) and 0xFF
        if (ta > 0) {
            val tr = (tintArgb ushr 16) and 0xFF
            val tg = (tintArgb ushr 8) and 0xFF
            val tb = tintArgb and 0xFF
            val invA = 255 - ta
            for (i in 0 until total) {
                val c = pixels[i]
                val rCh = (((c ushr 16) and 0xFF) * invA + tr * ta) / 255
                val gCh = (((c ushr 8) and 0xFF) * invA + tg * ta) / 255
                val bCh = ((c and 0xFF) * invA + tb * ta) / 255
                pixels[i] = (0xFF shl 24) or (rCh shl 16) or (gCh shl 8) or bCh
            }
        }
    }

    /**
     * 2. Извлечение доминирующего оттенка обложки альбома для режима «Амбилайн».
     */
    fun extractDominantCoverHsv(bmp: Bitmap?): Pair<Int, Int>? {
        if (bmp == null || bmp.isRecycled || bmp.width <= 0 || bmp.height <= 0) return null
        return try {
            val w = bmp.width
            val h = bmp.height
            if (isRustLoaded) {
                val pixels = IntArray(w * h)
                bmp.getPixels(pixels, 0, w, 0, 0, w, h)
                val packed = nativeExtractDominantCoverHsv(pixels, w, h)
                val hue = (packed ushr 16) and 0xFFFF
                val sat = packed and 0xFFFF
                return hue.coerceIn(0, 360) to sat.coerceIn(60, 100)
            }
            val bucketWeights = FloatArray(36)
            val bucketHueSum = FloatArray(36)
            val bucketSatSum = FloatArray(36)
            val hsv = FloatArray(3)
            val stepX = (w / 20).coerceAtLeast(1)
            val stepY = (h / 20).coerceAtLeast(1)
            var y = stepY / 2
            while (y < h) {
                var x = stepX / 2
                while (x < w) {
                    val px = bmp.getPixel(x, y)
                    if (Color.alpha(px) > 140) {
                        Color.colorToHSV(px, hsv)
                        val deg = hsv[0]
                        val sat = hsv[1]
                        val bri = hsv[2]
                        if (bri > 0.18f && sat > 0.24f) {
                            val bucket = ((deg.toInt() % 360) / 10).coerceIn(0, 35)
                            val skinPenalty = if (deg in 14f..44f && sat < 0.68f) 0.22f else 1.0f
                            val weight = (sat * sat * sat * bri) * skinPenalty
                            bucketWeights[bucket] += weight
                            bucketHueSum[bucket] += deg * weight
                            bucketSatSum[bucket] += sat * weight
                        }
                    }
                    x += stepX
                }
                y += stepY
            }
            var bestBucket = -1
            var bestWeight = 0f
            for (i in 0 until 36) {
                if (bucketWeights[i] > bestWeight) {
                    bestWeight = bucketWeights[i]
                    bestBucket = i
                }
            }
            if (bestBucket >= 0 && bestWeight > 0.02f) {
                val rawHue = (bucketHueSum[bestBucket] / bestWeight).toInt().coerceIn(0, 360)
                val avgSat = (bucketSatSum[bestBucket] / bestWeight).coerceIn(0.75f, 1.0f)
                rawHue to (avgSat * 100f).toInt().coerceIn(80, 100)
            } else {
                195 to 60
            }
        } catch (_: Throwable) {
            null
        }
    }

    /**
     * 3. Монохромная векторизация растровой иконки в фирменный стиль лаунчера.
     */
    fun extractMonochromeGlyph(pixels: IntArray, size: Int): Int {
        if (isRustLoaded) {
            try {
                return nativeExtractMonochromeGlyph(pixels, size)
            } catch (_: Throwable) {
            }
        }
        val cornerColor = pixels[5 * size + 5]
        val cornerA = Color.alpha(cornerColor)
        val cornerR = Color.red(cornerColor)
        val cornerG = Color.green(cornerColor)
        val cornerB = Color.blue(cornerColor)
        val hasSolidBackground = cornerA > 200
        var visibleCount = 0
        for (i in pixels.indices) {
            val c = pixels[i]
            val a = Color.alpha(c)
            if (a < 30) {
                pixels[i] = Color.TRANSPARENT
                continue
            }
            val r = Color.red(c)
            val g = Color.green(c)
            val b = Color.blue(c)
            val outAlpha: Int = if (hasSolidBackground) {
                val diff = (abs(r - cornerR) + abs(g - cornerG) + abs(b - cornerB)) / 3
                if (diff < 24) 0 else min(255, diff * 2)
            } else {
                val lum = (0.299f * r + 0.587f * g + 0.114f * b).toInt()
                val boost = max(140, lum)
                (a * boost) / 255
            }
            if (outAlpha > 35) {
                visibleCount++
                pixels[i] = Color.argb(outAlpha, 255, 255, 255)
            } else {
                pixels[i] = Color.TRANSPARENT
            }
        }
        return visibleCount
    }

    /**
     * 4. Физика упругой пружины (Rust Spring Dynamics) для анимаций фокуса и скролла.
     */
    fun evaluateSpring(progress: Float, dampingRatio: Float = 0.78f, angularFreq: Float = 11.5f): Float {
        if (isRustLoaded) {
            try {
                return nativeEvaluateSpring(progress, dampingRatio, angularFreq)
            } catch (_: Throwable) {
            }
        }
        val t = progress.coerceIn(0f, 1f)
        if (t <= 0f) return 0f
        if (t >= 1f) return 1f
        val zeta = dampingRatio.coerceIn(0.45f, 0.99f).toDouble()
        val omega = angularFreq.coerceIn(6f, 22f).toDouble()
        val omegaD = omega * sqrt(1.0 - zeta * zeta)
        val decay = exp(-zeta * omega * t)
        val raw = 1.0 - decay * (cos(omegaD * t) + ((zeta * omega) / omegaD) * sin(omegaD * t))
        return raw.toFloat().coerceIn(0f, 1.06f)
    }

    class SpringInterpolator(
        private val dampingRatio: Float = 0.78f,
        private val angularFreq: Float = 11.5f
    ) : Interpolator {
        override fun getInterpolation(input: Float): Float {
            return evaluateSpring(input, dampingRatio, angularFreq)
        }
    }

    /**
     * 5. Нативный расчёт RMS энергии и обрезка тишины для микрофона Gemini AI.
     */
    fun computePcmRms(pcmBytes: ByteArray, validLen: Int = pcmBytes.size): Double {
        if (isRustLoaded) {
            try {
                return nativeComputePcmRms(pcmBytes, validLen).toDouble()
            } catch (_: Throwable) {
            }
        }
        val samples = validLen / 2
        if (samples <= 0) return 0.0
        var sumSq = 0.0
        var i = 0
        while (i + 1 < validLen) {
            val lo = pcmBytes[i].toInt() and 0xFF
            val hi = pcmBytes[i + 1].toInt()
            val sample = ((hi shl 8) or lo).toShort().toDouble()
            sumSq += sample * sample
            i += 2
        }
        return sqrt(sumSq / samples)
    }

    fun trimPcmSilence(pcmData: ByteArray, sampleRate: Int): ByteArray {
        if (pcmData.size < 3200) return pcmData
        if (isRustLoaded) {
            try {
                val packed = nativeTrimPcmSilenceBounds(pcmData, sampleRate)
                val startByte = ((packed ushr 32) and 0xFFFFFFFFL).toInt().coerceIn(0, pcmData.size)
                val endByte = (packed and 0xFFFFFFFFL).toInt().coerceIn(0, pcmData.size)
                if (endByte > startByte && (startByte > 0 || endByte < pcmData.size)) {
                    return pcmData.copyOfRange(startByte, endByte)
                }
                return pcmData
            } catch (_: Throwable) {
            }
        }
        val totalSamples = pcmData.size / 2
        val frameSamples = 320
        val totalFrames = totalSamples / frameSamples
        var firstSpeechFrame = -1
        var lastSpeechFrame = -1
        for (f in 0 until totalFrames) {
            var sumSq = 0.0
            val baseIdx = f * frameSamples * 2
            for (s in 0 until frameSamples) {
                val idx = baseIdx + s * 2
                val lo = pcmData[idx].toInt() and 0xFF
                val hi = pcmData[idx + 1].toInt()
                val sample = ((hi shl 8) or lo).toShort().toDouble()
                sumSq += sample * sample
            }
            val rms = sqrt(sumSq / frameSamples)
            if (rms > 240.0) {
                if (firstSpeechFrame == -1) firstSpeechFrame = f
                lastSpeechFrame = f
            }
        }
        if (firstSpeechFrame == -1 || lastSpeechFrame == -1) return pcmData
        val preRollFrames = (0.12 * sampleRate / frameSamples).toInt()
        val postRollFrames = (0.16 * sampleRate / frameSamples).toInt()
        val startFrame = (firstSpeechFrame - preRollFrames).coerceAtLeast(0)
        val endFrame = (lastSpeechFrame + postRollFrames + 1).coerceAtMost(totalFrames)
        val startByte = startFrame * frameSamples * 2
        val endByte = (endFrame * frameSamples * 2).coerceAtMost(pcmData.size)
        return if (endByte > startByte) pcmData.copyOfRange(startByte, endByte) else pcmData
    }

    /**
     * 6. Мгновенная нативная классификация аппаратных кнопок пульта Xiaomi.
     */
    fun classifyRemoteKey(keyCode: Int, scanCode: Int): Int {
        if (isRustLoaded) {
            try {
                return nativeClassifyRemoteKey(keyCode, scanCode)
            } catch (_: Throwable) {
            }
        }
        if (keyCode == 231 || keyCode == 219 || keyCode == 84 || scanCode == 582 || scanCode == 217 || scanCode == 221) {
            return KEY_CLASS_VOICE_ASSIST
        }
        if (keyCode == 284 || keyCode == 82 || keyCode == 172 || keyCode == 176 || keyCode == 178 || keyCode == 188 ||
            scanCode == 139 || scanCode == 362 || scanCode == 172 || scanCode == 256
        ) {
            return KEY_CLASS_PATCHWALL
        }
        if (keyCode == 189 || keyCode == 183 || keyCode == 309 || scanCode == 412 || scanCode == 398 || scanCode == 393) {
            return KEY_CLASS_NETFLIX
        }
        if (keyCode == 190 || keyCode == 186 || keyCode == 310 || scanCode == 413 || scanCode == 401 || scanCode == 400) {
            return KEY_CLASS_PRIME
        }
        return KEY_CLASS_NORMAL
    }
}
