package com.mitv.customlauncher.service

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.SoundPool
import android.media.MediaMetadata
import android.media.MediaRecorder
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Parcelable
import android.os.SystemClock
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.TextUtils
import android.util.Log
import android.util.LruCache
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.content.ClipData
import android.content.ClipboardManager
import java.util.Locale
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import com.mitv.customlauncher.R
import com.mitv.customlauncher.data.AssistantVoiceSpeaker
import com.mitv.customlauncher.data.GeminiCloudClient
import com.mitv.customlauncher.data.GeminiTurnResult
import com.mitv.customlauncher.data.LauncherConfig
import com.mitv.customlauncher.data.NativeCore
import com.mitv.customlauncher.data.LocalVoiceCommandRouter
import com.mitv.customlauncher.ui.EchoView
import com.mitv.customlauncher.ui.LauncherActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import org.json.JSONObject
import android.net.wifi.WifiManager
import android.os.PowerManager
import java.net.InetAddress
import java.net.InetSocketAddress
import com.mitv.customlauncher.data.TuyaSmartHomeController
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.net.URLEncoder
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sin
import kotlin.math.sqrt


data class NowPlayingSnapshot(
    val hasActiveSession: Boolean = false,
    val isPlaying: Boolean = false,
    val title: String = "",
    val artist: String = "",
    val sourcePackage: String = "",
    val sourceAppName: String = "",
    val coverBitmap: Bitmap? = null,
    val durationMs: Long = 0L,
    val basePositionMs: Long = 0L,
    val baseElapsedRealtime: Long = 0L,
    val playbackSpeed: Float = 1.0f
)

object MediaStateBus {
    private val _state = MutableStateFlow(NowPlayingSnapshot())
    val state: StateFlow<NowPlayingSnapshot> = _state.asStateFlow()

    @Volatile
    var activeController: MediaController? = null

    @Volatile
    var lastForegroundMediaPkg: String = ""

    private val mainHandler = Handler(Looper.getMainLooper())
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val artUriCache = object : LruCache<String, Bitmap>(24) {}
    private var currentArtUri: String = ""
    private var lastFetchedArtUri: String = ""

    private var trackStartRealtime: Long = SystemClock.elapsedRealtime()
    private var lastPausedRealtime: Long = 0L
    private var lastLauncherPauseRealtime: Long = 0L
    private var currentTrackIdentity: String = ""
    private var currentCoverSignature: Int = 0
    private var currentControllerCallback: MediaController.Callback? = null
    private var sessionListenerRegistered = false

    private var lastObservedRawPos: Long = -1L
    private var lastObservedRawRealtime: Long = 0L

    private var dismissedTrackIdentity: String = ""
    private var dismissedAtRealtime: Long = 0L
    private var pausedByLauncherControl: Boolean = false

    private val catalogLookupCache = object : LruCache<String, Pair<String, Long>>(40) {}
    private var lastCatalogLookupKey: String = ""

    val UNIVERSAL_MEDIA_BROADCAST_ACTIONS = listOf(
        "com.android.music.metachanged",
        "com.android.music.playstatechanged",
        "com.android.music.playbackcomplete",
        "com.android.music.queuechanged",
        "com.spotify.music.metadatachanged",
        "com.spotify.music.playbackstatechanged",
        "com.spotify.tv.android.metadatachanged",
        "com.spotify.tv.android.playbackstatechanged",
        "com.soundcloud.android.metachanged",
        "com.soundcloud.android.playstatechanged",
        "deezer.android.app.metachanged",
        "deezer.android.app.playstatechanged",
        "com.aspiro.tidal.metachanged",
        "ru.yandex.music.metachanged",
        "ru.yandex.music.playstatechanged",
        "org.videolan.vlc.remote.PlayPause",
        "com.maxmpz.audioplayer.TRACK_CHANGED",
        "com.maxmpz.audioplayer.STATUS_CHANGED",
        "com.aimp.player.metachanged",
        "com.miui.player.metachanged",
        "com.miui.player.playstatechanged",
        "com.sec.android.app.music.metachanged",
        "com.htc.music.metachanged",
        "com.sonyericsson.music.metachanged",
        "fm.last.android.metachanged",
        "com.amazon.mp3.metachanged"
    )

    @Volatile
    private var hasObservedActivePlaybackSinceBoot: Boolean = false

    fun isExcludedVideoPackage(pkg: String): Boolean {
        val p = pkg.lowercase(Locale.ROOT)
        return p.contains("youtube") ||
            p.contains("smarttube") ||
            p.contains("newpipe") ||
            p.contains("revanced") ||
            p.contains("videomanager") ||
            p.contains("kick") ||
            p.contains("twitch") ||
            p.contains("netflix") ||
            p.contains("kinopoisk") ||
            p.contains("hdvideobox") ||
            p.contains("lampa")
    }

    fun isKnownMediaPackage(pkg: String): Boolean {
        if (pkg.isBlank() || isExcludedVideoPackage(pkg)) return false
        val p = pkg.lowercase(Locale.ROOT)
        return p.contains("spotify") ||
            p.contains("soundcloud") ||
            p.contains("music") ||
            p.contains("deezer") ||
            p.contains("tidal") ||
            p.contains("tunein") ||
            p.contains("vlc") ||
            p.contains("aimp") ||
            p.contains("audioplayer") ||
            p.contains("poweramp") ||
            p.contains("yandex") ||
            p.contains("vkontakte") ||
            p.contains("apple") ||
            p.contains("audio") ||
            p.contains("radio")
    }

    fun onMediaAppOpened(pkg: String) {
        if (pkg.isBlank()) return
        if (isKnownMediaPackage(pkg)) {
            lastForegroundMediaPkg = pkg
            pausedByLauncherControl = false
            dismissedTrackIdentity = ""
            val ctrl = activeController
            if (ctrl != null && ctrl.packageName != pkg && !isActivelyPlayingState(ctrl.playbackState?.state)) {
                unregisterCurrentCallback()
                activeController = null
            }
        }
    }

    /**
     * Мгновенно подставляет трек, обложку и длительность из каталога Deezer / iTunes,
     * когда пользователь запускает песню голосом или выбирает карточку трека внутри приложения!
     */
    fun seedTrackFromQuery(context: Context, pkg: String, rawQuery: String) {
        val clean = rawQuery.trim()
        if (clean.length < 2) return
        onMediaAppOpened(pkg)
        val appLabel = resolveAppLabel(context, pkg)
        updatePlayingFlag(true)
        updateMetadata(
            context = context,
            title = clean,
            artist = appLabel,
            sourcePackage = pkg,
            sourceAppName = appLabel,
            cover = null,
            durationMs = -1L,
            positionMs = 0L
        )
    }

    fun resolveActiveMediaPackage(context: Context): String {
        try {
            val mbr = Settings.Secure.getString(context.contentResolver, "media_button_receiver").orEmpty()
            if (mbr.contains("/")) {
                val mbrPkg = mbr.substringBefore("/").trim()
                if (mbrPkg.isNotEmpty() && mbrPkg != context.packageName && !isExcludedVideoPackage(mbrPkg)) {
                    return mbrPkg
                }
            }
        } catch (_: Exception) {
        }
        if (lastForegroundMediaPkg.isNotEmpty()) {
            return lastForegroundMediaPkg
        }
        val curPkg = _state.value.sourcePackage
        if (curPkg.isNotEmpty()) {
            return curPkg
        }
        return ""
    }

    private fun normalizeArtUri(rawUri: String): String {
        val trimmed = rawUri.trim()
        if (trimmed.startsWith("spotify:image:")) {
            val imageId = trimmed.removePrefix("spotify:image:").trim()
            if (imageId.isNotEmpty()) {
                return "https://i.scdn.co/image/$imageId"
            }
        }
        return trimmed
    }

    fun computeBitmapSignature(bmp: Bitmap?): Int {
        if (bmp == null || bmp.isRecycled) return 0
        val w = bmp.width
        val h = bmp.height
        if (w <= 0 || h <= 0) return 0
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && bmp.config == Bitmap.Config.HARDWARE) {
            val gen = bmp.generationId
            val hash = ((w * 31) xor h) xor (gen * 31)
            return if (hash == 0) 1 else hash
        }
        return try {
            var hash = (w * 31) xor h
            hash = (hash * 31) xor bmp.getPixel(w / 2, h / 2)
            hash = (hash * 31) xor bmp.getPixel(w / 4, h / 4)
            hash = (hash * 31) xor bmp.getPixel((w * 3) / 4, h / 4)
            hash = (hash * 31) xor bmp.getPixel(w / 4, (h * 3) / 4)
            hash = (hash * 31) xor bmp.getPixel((w * 3) / 4, (h * 3) / 4)
            if (hash == 0) 1 else hash
        } catch (_: Exception) {
            val gen = bmp.generationId
            if (gen == 0) 1 else gen
        }
    }

    fun safeScaleBitmap(raw: Bitmap?): Bitmap? {
        if (raw == null || raw.isRecycled) return null
        return try {
            val src = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && raw.config == Bitmap.Config.HARDWARE) {
                raw.copy(Bitmap.Config.ARGB_8888, false) ?: raw
            } else {
                raw
            }
            val scaled = Bitmap.createScaledBitmap(src, 112, 112, true)
            if (src !== raw && src !== scaled && !src.isRecycled) {
                src.recycle()
            }
            scaled
        } catch (_: Exception) {
            raw
        }
    }

    fun getCurrentCoverSignature(): Int = currentCoverSignature

    private fun isActivelyPlayingState(stateCode: Int?): Boolean {
        return stateCode == PlaybackState.STATE_PLAYING ||
            stateCode == PlaybackState.STATE_BUFFERING ||
            stateCode == PlaybackState.STATE_CONNECTING ||
            stateCode == PlaybackState.STATE_FAST_FORWARDING ||
            stateCode == PlaybackState.STATE_REWINDING ||
            stateCode == PlaybackState.STATE_SKIPPING_TO_NEXT ||
            stateCode == PlaybackState.STATE_SKIPPING_TO_PREVIOUS
    }

    private fun unregisterCurrentCallback() {
        val prev = activeController
        val prevCb = currentControllerCallback
        if (prev != null && prevCb != null) {
            try {
                prev.unregisterCallback(prevCb)
            } catch (_: Exception) {
            }
        }
        currentControllerCallback = null
    }

    fun queryMediaSessionManagerDirect(context: Context) {
        try {
            val appCtx = context.applicationContext
            ServiceAutoActivator.ensureNotificationListenerInSecureSettings(appCtx)
            val msm = appCtx.getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager ?: return
            val comp = ComponentName(appCtx, MediaSessionListenerService::class.java)

            if (!sessionListenerRegistered) {
                try {
                    val sessionListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
                        selectAndBindBestController(appCtx, list)
                    }
                    msm.addOnActiveSessionsChangedListener(sessionListener, comp, mainHandler)
                    sessionListenerRegistered = true
                } catch (_: Exception) {
                }
            }

            val sessions = msm.getActiveSessions(comp)
            selectAndBindBestController(appCtx, sessions)
        } catch (_: Exception) {
        }
    }

    private fun selectAndBindBestController(context: Context, controllers: List<MediaController>?) {
        if (controllers.isNullOrEmpty()) return
        val others = controllers.filter { it.packageName != context.packageName && !isExcludedVideoPackage(it.packageName) }
        if (others.isEmpty()) return

        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        val musicActive = am?.isMusicActive == true
        val activeMediaPkg = resolveActiveMediaPackage(context)

        val playing = others.firstOrNull {
            it.playbackState?.state == PlaybackState.STATE_PLAYING && it.packageName == activeMediaPkg
        } ?: others.firstOrNull {
            it.playbackState?.state == PlaybackState.STATE_PLAYING
        } ?: others.firstOrNull {
            isActivelyPlayingState(it.playbackState?.state)
        }

        if (playing != null) {
            bindController(context, playing)
            return
        }

        if (musicActive) {
            val byActivePkg = if (activeMediaPkg.isNotEmpty()) {
                others.firstOrNull { it.packageName == activeMediaPkg }
            } else null

            val byKnownMedia = others.firstOrNull {
                isKnownMediaPackage(it.packageName) && it.metadata != null
            } ?: others.firstOrNull {
                isKnownMediaPackage(it.packageName)
            }

            val byMetadata = others.firstOrNull { it.metadata != null } ?: others.firstOrNull()
            val candidate = byActivePkg ?: byKnownMedia ?: byMetadata
            if (candidate != null) {
                bindController(context, candidate)
                return
            }
        }

        val cur = _state.value
        if (cur.hasActiveSession && cur.sourcePackage.isNotEmpty()) {
            val matching = others.firstOrNull { it.packageName == cur.sourcePackage }
            if (matching != null) {
                bindController(context, matching)
                return
            }
        }
// Не привязываем спящие сессии с метаданными, если музыка сейчас реально не играет
    }

    fun bindController(context: Context, controller: MediaController) {
        val appCtx = context.applicationContext
        val prev = activeController
        if (prev != null && prev.sessionToken == controller.sessionToken) {
            syncControllerImmediate(appCtx, prev)
            return
        }
        unregisterCurrentCallback()
        activeController = controller

        val cb = object : MediaController.Callback() {
            override fun onPlaybackStateChanged(state: PlaybackState?) {
                if (state != null) {
                    val am = appCtx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    val musicActive = am?.isMusicActive == true
                    val playing = isActivelyPlayingState(state.state) || (musicActive && !pausedByLauncherControl)
                    if (playing) pausedByLauncherControl = false
                    updatePositionOnly(
                        positionMs = state.position,
                        positionUpdateRealtime = state.lastPositionUpdateTime,
                        speed = state.playbackSpeed,
                        isPlaying = playing
                    )
                }
            }

            override fun onMetadataChanged(metadata: MediaMetadata?) {
                syncControllerImmediate(appCtx, controller)
            }
        }
        currentControllerCallback = cb
        try {
            controller.registerCallback(cb, mainHandler)
        } catch (_: Exception) {
        }

        syncControllerImmediate(appCtx, controller)
    }

    fun syncControllerImmediate(context: Context, controller: MediaController) {
        try {
            val meta = controller.metadata
            val pb = controller.playbackState
            val cur = _state.value
            val pkg = controller.packageName.orEmpty().ifEmpty { cur.sourcePackage }
            if (isExcludedVideoPackage(pkg)) return

            val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            val musicActive = am?.isMusicActive == true
            val pbPlaying = isActivelyPlayingState(pb?.state)
            val now = SystemClock.elapsedRealtime()

            if (musicActive && pausedByLauncherControl && (now - lastLauncherPauseRealtime) > 2500L) {
                pausedByLauncherControl = false
                dismissedTrackIdentity = ""
            }

            if (!pbPlaying && musicActive) {
                val activePkg = resolveActiveMediaPackage(context)
                if (activePkg.isNotEmpty() && pkg.isNotEmpty() && activePkg != pkg) {
                    if (activeController === controller) {
                        unregisterCurrentCallback()
                        activeController = null
                    }
                    return
                }
            }

            val effectivePlaying = pbPlaying || (musicActive && !pausedByLauncherControl)

            if (!cur.hasActiveSession && !effectivePlaying) {
                return
            }

            val appName = resolveAppLabel(context, pkg)
            var title = ""
            var artist = ""
            var dur = -1L
            var artUri = ""
            var newCover: Bitmap? = null
            var newSig = 0

            if (meta != null) {
                val desc = meta.description
                title = (meta.getString(MediaMetadata.METADATA_KEY_TITLE)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
                    ?: desc?.title?.toString()).orEmpty().trim()
                artist = (meta.getString(MediaMetadata.METADATA_KEY_ARTIST)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_AUTHOR)
                    ?: desc?.subtitle?.toString()).orEmpty().trim()
                val d = meta.getLong(MediaMetadata.METADATA_KEY_DURATION)
                if (d > 0L) dur = d

                val rawUriStr = (meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_ART_URI)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)
                    ?: desc?.iconUri?.toString()).orEmpty()
                artUri = normalizeArtUri(rawUriStr)

                val rawArt = meta.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                    ?: meta.getBitmap(MediaMetadata.METADATA_KEY_ART)
                    ?: meta.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                    ?: desc?.iconBitmap
                if (rawArt != null) {
                    val sig = computeBitmapSignature(rawArt)
                    if (sig != 0 && (sig != currentCoverSignature || cur.coverBitmap == null)) {
                        newCover = safeScaleBitmap(rawArt)
                        newSig = sig
                    }
                }
            }

            var pos = -1L
            var posTime = 0L
            var spd = 1.0f
            if (pb != null) {
                pos = pb.position
                posTime = pb.lastPositionUpdateTime
                spd = pb.playbackSpeed
            }
            updatePlayingFlag(effectivePlaying)

            if (title.isNotEmpty() || artist.isNotEmpty() || newCover != null || artUri.isNotEmpty() || pos >= 0L || dur > 0L || effectivePlaying) {
                updateMetadata(
                    context = context,
                    title = title,
                    artist = artist,
                    sourcePackage = pkg,
                    sourceAppName = appName,
                    cover = newCover,
                    coverSignature = newSig,
                    artUri = artUri,
                    durationMs = dur,
                    positionMs = pos,
                    positionUpdateRealtime = posTime,
                    speed = spd
                )
            }
        } catch (_: Exception) {
        }
    }

    fun ingestNotification(
        context: Context,
        pkg: String,
        notif: Notification,
        requireActivePlaybackOrSession: Boolean = false,
        eventTexts: List<CharSequence>? = null
    ) {
        try {
            val appCtx = context.applicationContext
            val p = pkg.lowercase()
            if (pkg == appCtx.packageName || isExcludedVideoPackage(pkg) ||
                p.startsWith("com.android.packageinstaller") ||
                p.startsWith("com.google.android.packageinstaller") ||
                p.startsWith("com.android.vending") ||
                p.startsWith("com.android.systemui") ||
                p.startsWith("com.android.settings")
            ) {
                return
            }

            val extras = notif.extras ?: Bundle()
            @Suppress("DEPRECATION")
            var sessionToken: MediaSession.Token? = (extras.getParcelable<Parcelable>(Notification.EXTRA_MEDIA_SESSION) as? MediaSession.Token)
                ?: (extras.getParcelable<Parcelable>("android.support.v4.media.session.EXTRA_SESSION_TOKEN") as? MediaSession.Token)
            if (sessionToken == null) {
                try {
                    for (k in extras.keySet()) {
                        @Suppress("DEPRECATION")
                        val v = extras.get(k)
                        if (v is MediaSession.Token) {
                            sessionToken = v
                            break
                        }
                    }
                } catch (_: Exception) {
                }
            }

            val isKnownMedia = isKnownMediaPackage(p) || notif.category == Notification.CATEGORY_TRANSPORT
            if (sessionToken == null && !isKnownMedia) {
                return
            }

            if (isKnownMediaPackage(p)) {
                lastForegroundMediaPkg = pkg
            }

            if (sessionToken != null) {
                val curCtrl = activeController
                if (curCtrl == null || curCtrl.sessionToken != sessionToken) {
                    bindController(appCtx, MediaController(appCtx, sessionToken))
                }
            }

            val ctrl = activeController?.takeIf { it.packageName == pkg || sessionToken != null }
            val pb = ctrl?.playbackState
            val am = appCtx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            val isMusicCurrentlyActive = am?.isMusicActive == true
            val isCtrlPlaying = isActivelyPlayingState(pb?.state)
            val effectivePlaying = isCtrlPlaying || (isMusicCurrentlyActive && !pausedByLauncherControl)

            if (requireActivePlaybackOrSession && !_state.value.hasActiveSession && !effectivePlaying) {
                return
            }

            var notifTitle = (extras.getCharSequence(Notification.EXTRA_TITLE)
                ?: extras.getCharSequence(Notification.EXTRA_TITLE_BIG)
                ?: extras.getCharSequence("android.conversationTitle"))?.toString()?.trim().orEmpty()
            var notifArtist = (extras.getCharSequence(Notification.EXTRA_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_SUB_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_SUMMARY_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_INFO_TEXT))?.toString()?.trim().orEmpty()
            val appName = resolveAppLabel(appCtx, pkg)

            if (notifTitle.isBlank()) {
                val rvStrings = extractStringsFromRemoteViews(appCtx, notif)
                val filtered = rvStrings.filter { s ->
                    s.isNotBlank() && !s.equals(appName, ignoreCase = true) && !s.matches(Regex("^[0-9]{1,2}:[0-9]{2}( / [0-9]{1,2}:[0-9]{2})?$"))
                }
                if (filtered.isNotEmpty()) {
                    notifTitle = filtered[0]
                    if (notifArtist.isBlank() && filtered.size >= 2) {
                        notifArtist = filtered[1]
                    }
                }
            }
            if (notifTitle.isBlank() && !eventTexts.isNullOrEmpty()) {
                val cleaned = eventTexts.map { it.toString().trim() }
                    .filter { it.isNotBlank() && !it.equals(appName, ignoreCase = true) }
                if (cleaned.isNotEmpty()) {
                    notifTitle = cleaned[0]
                    if (notifArtist.isBlank() && cleaned.size >= 2) {
                        notifArtist = cleaned[1]
                    }
                }
            }
            if (notifTitle.isBlank() && !notif.tickerText.isNullOrBlank()) {
                notifTitle = notif.tickerText.toString().trim()
            }

            var durationMs = -1L
            var posMs = -1L
            var posRealtime = 0L
            var speed = 1.0f
            var artUri = ""
            var metaRawArt: Bitmap? = null

            if (ctrl != null) {
                val meta = ctrl.metadata
                if (meta != null) {
                    val desc = meta.description
                    val metaTitle = (meta.getString(MediaMetadata.METADATA_KEY_TITLE)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
                        ?: desc?.title?.toString())?.trim()
                    val metaArtist = (meta.getString(MediaMetadata.METADATA_KEY_ARTIST)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
                        ?: desc?.subtitle?.toString())?.trim()

                    if (notifTitle.isBlank() && !metaTitle.isNullOrBlank()) notifTitle = metaTitle
                    if (notifArtist.isBlank() && !metaArtist.isNullOrBlank()) notifArtist = metaArtist

                    val d = meta.getLong(MediaMetadata.METADATA_KEY_DURATION)
                    if (d > 0L) durationMs = d

                    val rawUriStr = (meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_ART_URI)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)
                        ?: desc?.iconUri?.toString()).orEmpty()
                    artUri = normalizeArtUri(rawUriStr)

                    metaRawArt = meta.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                        ?: meta.getBitmap(MediaMetadata.METADATA_KEY_ART)
                        ?: meta.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                        ?: desc?.iconBitmap
                }

                if (pb != null) {
                    posMs = pb.position
                    posRealtime = pb.lastPositionUpdateTime
                    speed = pb.playbackSpeed
                }
                updatePlayingFlag(effectivePlaying)
            } else if (isMusicCurrentlyActive) {
                updatePlayingFlag(true)
            }

            if (durationMs <= 0L) {
                val progMax = extras.getInt(Notification.EXTRA_PROGRESS_MAX, 0)
                if (progMax > 1000) {
                    durationMs = progMax.toLong()
                    val progCur = extras.getInt(Notification.EXTRA_PROGRESS, -1)
                    if (posMs < 0L && progCur >= 0) {
                        posMs = progCur.toLong()
                    }
                }
            }

            @Suppress("DEPRECATION")
            var rawCandidate: Bitmap? = (extras.getParcelable<Parcelable>(Notification.EXTRA_LARGE_ICON_BIG) as? Bitmap)
                ?: (extras.getParcelable<Parcelable>(Notification.EXTRA_LARGE_ICON) as? Bitmap)
                ?: (extras.getParcelable<Parcelable>(Notification.EXTRA_PICTURE) as? Bitmap)

            if (rawCandidate == null) {
                val largeIcon = notif.getLargeIcon()
                if (largeIcon != null) {
                    val d = largeIcon.loadDrawable(appCtx)
                    if (d is BitmapDrawable && d.bitmap != null) {
                        rawCandidate = d.bitmap
                    } else if (d != null) {
                        rawCandidate = drawableToSmallBitmap(d)
                    }
                }
            }

            if (rawCandidate == null) {
                rawCandidate = metaRawArt
            }

            var coverBmp: Bitmap? = null
            var sig = 0
            if (rawCandidate != null) {
                sig = computeBitmapSignature(rawCandidate)
                val curCover = _state.value.coverBitmap
                if (sig != 0 && sig == currentCoverSignature && curCover != null) {
                    coverBmp = curCover
                } else {
                    coverBmp = safeScaleBitmap(rawCandidate)
                }
            }

            if (notifTitle.isEmpty() && notifArtist.isEmpty() && coverBmp == null && artUri.isEmpty()) return

            updateMetadata(
                context = appCtx,
                title = notifTitle,
                artist = notifArtist,
                sourcePackage = pkg,
                sourceAppName = appName,
                cover = coverBmp,
                coverSignature = sig,
                artUri = artUri,
                durationMs = durationMs,
                positionMs = posMs,
                positionUpdateRealtime = posRealtime,
                speed = speed
            )
        } catch (_: Exception) {
        }
    }

    @Suppress("DEPRECATION")
    private fun extractStringsFromRemoteViews(context: Context, notif: Notification): List<String> {
        val result = mutableListOf<String>()
        val viewsToTry = listOfNotNull(notif.bigContentView, notif.contentView)
        for (rv in viewsToTry) {
            try {
                val container = FrameLayout(context)
                val applied = rv.apply(context, container)
                collectTextViewsFromViewTree(applied, result)
                if (result.isNotEmpty()) break
            } catch (_: Exception) {
            }
        }
        return result
    }

    private fun collectTextViewsFromViewTree(view: View?, out: MutableList<String>) {
        if (view == null) return
        if (view is TextView) {
            val t = view.text?.toString()?.trim().orEmpty()
            if (t.isNotEmpty() && !out.contains(t)) {
                out.add(t)
            }
        } else if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                collectTextViewsFromViewTree(view.getChildAt(i), out)
            }
        }
    }

    fun handleMediaBroadcastIntent(context: Context, intent: Intent) {
        try {
            val act = intent.action.orEmpty()
            val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            val musicActive = am?.isMusicActive == true
            val explicitPlayFlag: Boolean? = when {
                intent.hasExtra("playing") -> intent.getBooleanExtra("playing", false)
                intent.hasExtra("playstate") -> intent.getBooleanExtra("playstate", false)
                intent.hasExtra("isPlaying") -> intent.getBooleanExtra("isPlaying", false)
                else -> null
            }
            if (explicitPlayFlag != null) {
                updatePlayingFlag(explicitPlayFlag)
            }
            val effectivelyPlaying = (explicitPlayFlag == true) || (explicitPlayFlag == null && musicActive && !pausedByLauncherControl)
            if (!effectivelyPlaying && !_state.value.hasActiveSession) {
                return
            }
            val rawTrack = (intent.getStringExtra("track")
                ?: intent.getStringExtra("title")
                ?: intent.getStringExtra("android.intent.extra.TITLE")
                ?: intent.getStringExtra("name")).orEmpty().trim()
            val rawArtist = (intent.getStringExtra("artist")
                ?: intent.getStringExtra("author")
                ?: intent.getStringExtra("albumArtist")
                ?: intent.getStringExtra("album")
                ?: intent.getStringExtra("android.intent.extra.ARTIST")).orEmpty().trim()
            val duration = when {
                intent.hasExtra("duration") -> intent.getLongExtra("duration", -1L).let { if (it in 1..1000) it * 1000L else it }
                intent.hasExtra("length") -> intent.getLongExtra("length", -1L).let { if (it in 1..1000) it * 1000L else it }
                else -> -1L
            }
            val position = when {
                intent.hasExtra("position") -> intent.getLongExtra("position", -1L)
                intent.hasExtra("elapsed") -> intent.getLongExtra("elapsed", -1L)
                else -> -1L
            }
            val pkg = intent.`package` ?: when {
                act.contains("spotify") -> "com.spotify.tv.android"
                act.contains("soundcloud") -> "com.soundcloud.android"
                act.contains("deezer") -> "deezer.android.app"
                act.contains("yandex") -> "ru.yandex.music"
                act.contains("vlc") -> "org.videolan.vlc"
                act.contains("maxmpz") -> "com.maxmpz.audioplayer"
                act.contains("aimp") -> "com.aimp.player"
                act.contains("miui") -> "com.miui.player"
                else -> resolveActiveMediaPackage(context)
            }
            if (rawTrack.isNotEmpty() || rawArtist.isNotEmpty()) {
                val appLabel = resolveAppLabel(context, pkg)
                updateMetadata(
                    context = context,
                    title = rawTrack,
                    artist = rawArtist,
                    sourcePackage = pkg,
                    sourceAppName = appLabel,
                    cover = null,
                    durationMs = duration,
                    positionMs = position
                )
            }
        } catch (_: Exception) {
        }
    }

    private fun drawableToSmallBitmap(d: Drawable): Bitmap? {
        return try {
            if (d is BitmapDrawable && d.bitmap != null) {
                safeScaleBitmap(d.bitmap)
            } else {
                val bmp = Bitmap.createBitmap(112, 112, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bmp)
                d.setBounds(0, 0, 112, 112)
                d.draw(canvas)
                bmp
            }
        } catch (_: Exception) {
            null
        }
    }

    @Volatile
    private var lastDumpsysPollRealtime: Long = 0L

    @Volatile
    private var isDumpsysPolling: Boolean = false

    @Volatile
    private var lastDumpsysValidMetadataRealtime: Long = 0L

    private data class DumpedMediaSession(
        val pkg: String,
        val isActive: Boolean,
        val stateCode: Int,
        val positionMs: Long,
        val speed: Float,
        val updatedRealtime: Long,
        val title: String,
        val artist: String
    )

    fun hasRealControllerMetadata(): Boolean {
        val now = SystemClock.elapsedRealtime()
        if (lastDumpsysValidMetadataRealtime > 0L && (now - lastDumpsysValidMetadataRealtime) < 8000L && _state.value.title.isNotBlank()) {
            return true
        }
        return try {
            val meta = activeController?.metadata ?: return false
            val t = (meta.getString(MediaMetadata.METADATA_KEY_TITLE)
                ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
                ?: meta.description?.title?.toString()).orEmpty().trim()
            t.isNotEmpty()
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Обход системной блокировки NotificationListenerService на 1 ГБ ОЗУ (ActivityManager.isLowRamDevice() == true):
     * При выданном через ADB разрешении `pm grant com.mitv.customlauncher android.permission.DUMP`
     * напрямую читает системный стек `/system/bin/dumpsys media_session` за ~10 мс и получает точный трек,
     * исполнителя, статус воспроизведения и секунду трека из ядра Android!
     */
    fun pollDumpsysMediaSessionAsync(context: Context, force: Boolean = false) {
        val now = SystemClock.elapsedRealtime()
        if (!force && (now - lastDumpsysPollRealtime) < 1200L) return
        if (isDumpsysPolling) return
        lastDumpsysPollRealtime = now
        isDumpsysPolling = true

        val appCtx = context.applicationContext
        ioScope.launch {
            try {
                val proc = ProcessBuilder("/system/bin/dumpsys", "media_session")
                    .redirectErrorStream(true)
                    .start()
                val output = proc.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                proc.waitFor()
                if (output.isBlank() || output.contains("Permission Denial")) {
                    return@launch
                }

                val parsedSessions = parseDumpsysMediaSessionOutput(output, appCtx.packageName)
                if (parsedSessions.isEmpty()) return@launch

                val am = appCtx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                val musicActive = am?.isMusicActive == true
                val activePkg = resolveActiveMediaPackage(appCtx)

                val best = parsedSessions.firstOrNull {
                    isActivelyPlayingState(it.stateCode) && it.title.isNotEmpty() && it.pkg == activePkg
                } ?: parsedSessions.firstOrNull {
                    isActivelyPlayingState(it.stateCode) && it.title.isNotEmpty()
                } ?: parsedSessions.firstOrNull {
                    isActivelyPlayingState(it.stateCode)
                } ?: if (musicActive) {
                    parsedSessions.firstOrNull { it.pkg == activePkg && it.title.isNotEmpty() }
                        ?: parsedSessions.firstOrNull { it.isActive && it.title.isNotEmpty() }
                        ?: parsedSessions.firstOrNull { it.title.isNotEmpty() }
                } else {
                    null
                }

                if (best != null) {
                    val appLabel = resolveAppLabel(appCtx, best.pkg)
                    val hasRealTitle = best.title.isNotBlank() && !best.title.equals(appLabel, ignoreCase = true)
                    val activelyPlaying = isActivelyPlayingState(best.stateCode)
                    if (activelyPlaying && hasRealTitle) {
                        hasObservedActivePlaybackSinceBoot = true
                    }
                    val isPlayingNow = activelyPlaying || (hasObservedActivePlaybackSinceBoot && musicActive && best.pkg == activePkg && best.stateCode != PlaybackState.STATE_PAUSED && !pausedByLauncherControl)
                    // После перезагрузки приставки не показываем старую/спящую сессию без реального воспроизведения и без названия трека!
                    if (!hasRealTitle || (!isPlayingNow && !hasObservedActivePlaybackSinceBoot)) {
                        return@launch
                    }
                    lastDumpsysValidMetadataRealtime = SystemClock.elapsedRealtime()
                    if (isKnownMediaPackage(best.pkg)) {
                        lastForegroundMediaPkg = best.pkg
                    }
                    mainHandler.post {
                        updatePlayingFlag(isPlayingNow)
                        updateMetadata(
                            context = appCtx,
                            title = best.title,
                            artist = best.artist.ifEmpty { appLabel },
                            sourcePackage = best.pkg,
                            sourceAppName = appLabel,
                            cover = null,
                            durationMs = -1L,
                            positionMs = best.positionMs,
                            positionUpdateRealtime = best.updatedRealtime,
                            speed = best.speed
                        )
                    }
                }
            } catch (_: Exception) {
            } finally {
                isDumpsysPolling = false
            }
        }
    }

    private fun parseDumpsysMediaSessionOutput(rawDump: String, ownPkg: String): List<DumpedMediaSession> {
        val results = mutableListOf<DumpedMediaSession>()
        var curPkg = ""
        var curActive = false
        var curStateCode = 0
        var curPosMs = -1L
        var curSpeed = 1.0f
        var curUpdated = 0L
        var curTitle = ""
        var curArtist = ""

        fun flushCurrent() {
            if (curPkg.isNotEmpty() && curPkg != ownPkg && !isExcludedVideoPackage(curPkg) && (curTitle.isNotEmpty() || curStateCode != 0)) {
                results.add(
                    DumpedMediaSession(
                        pkg = curPkg,
                        isActive = curActive,
                        stateCode = curStateCode,
                        positionMs = curPosMs,
                        speed = curSpeed,
                        updatedRealtime = curUpdated,
                        title = curTitle,
                        artist = curArtist
                    )
                )
            }
            curPkg = ""
            curActive = false
            curStateCode = 0
            curPosMs = -1L
            curSpeed = 1.0f
            curUpdated = 0L
            curTitle = ""
            curArtist = ""
        }

        val stateRegex = Regex("state=(\\d+)")
        val posRegex = Regex("position=(-?\\d+)")
        val speedRegex = Regex("speed=([0-9.]+)")
        val updatedRegex = Regex("updated=(\\d+)")

        for (rawLine in rawDump.lineSequence()) {
            val line = rawLine.trim()
            if (line.isEmpty()) continue

            if (line.startsWith("package=")) {
                val newPkg = line.removePrefix("package=").trim()
                if (curPkg.isNotEmpty() && curPkg != newPkg) {
                    flushCurrent()
                }
                curPkg = newPkg
            } else if (line.startsWith("active=")) {
                curActive = line.removePrefix("active=").trim().equals("true", ignoreCase = true)
            } else if (line.startsWith("state=PlaybackState")) {
                curStateCode = stateRegex.find(line)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0
                curPosMs = posRegex.find(line)?.groupValues?.getOrNull(1)?.toLongOrNull() ?: -1L
                curSpeed = speedRegex.find(line)?.groupValues?.getOrNull(1)?.toFloatOrNull() ?: 1.0f
                curUpdated = updatedRegex.find(line)?.groupValues?.getOrNull(1)?.toLongOrNull() ?: 0L
            } else if (line.startsWith("metadata:") && line.contains("description=")) {
                val descRaw = line.substringAfter("description=").trim()
                if (descRaw.isNotEmpty() && !descRaw.startsWith("null, null")) {
                    val parts = descRaw.split(", ")
                    val rawT = parts.getOrNull(0)?.trim().orEmpty()
                    val rawA = parts.getOrNull(1)?.trim().orEmpty()
                    if (rawT.isNotEmpty() && !rawT.equals("null", ignoreCase = true)) {
                        curTitle = rawT
                    }
                    if (rawA.isNotEmpty() && !rawA.equals("null", ignoreCase = true)) {
                        curArtist = rawA
                    }
                }
            }
        }
        flushCurrent()
        return results
    }

    fun resolveAppLabel(context: Context, pkg: String): String {
        if (pkg.isBlank()) return ""
        return try {
            val ai = context.packageManager.getApplicationInfo(pkg, 0)
            context.packageManager.getApplicationLabel(ai).toString()
        } catch (_: Exception) {
            when {
                pkg.lowercase().contains("spotify") -> "Spotify"
                pkg.lowercase().contains("mediashell") -> "Chromecast"
                pkg.lowercase().contains("soundcloud") -> "SoundCloud"
                pkg.lowercase().contains("youtube") -> "YouTube"
                else -> pkg.substringAfterLast('.')
            }
        }
    }

    fun dismissPlayerByUser(audioManager: AudioManager) {
        val now = SystemClock.elapsedRealtime()
        dismissedTrackIdentity = currentTrackIdentity.ifEmpty { "DISMISSED_SESSION" }
        dismissedAtRealtime = now
        lastLauncherPauseRealtime = now
        pausedByLauncherControl = true

        dispatchTransportAction("PAUSE", audioManager)

        _state.value = NowPlayingSnapshot(
            hasActiveSession = false,
            isPlaying = false
        )
    }

    fun onContinuousBackgroundMusicDetected(context: Context? = null) {
        val now = SystemClock.elapsedRealtime()
        val am = context?.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        val musicActiveNow = am?.isMusicActive == true
        if (pausedByLauncherControl) {
            if (musicActiveNow && (now - lastLauncherPauseRealtime) > 5500L) {
                pausedByLauncherControl = false
                dismissedTrackIdentity = ""
            } else {
                return
            }
        }
        if (dismissedTrackIdentity.isNotEmpty() && !musicActiveNow) return

        if (context != null) {
            queryMediaSessionManagerDirect(context)
            pollDumpsysMediaSessionAsync(context, force = false)
        }

        val cur = _state.value
        val hasRealTrack = cur.title.isNotBlank() && !cur.title.equals(cur.sourceAppName, ignoreCase = true)
        if (hasRealTrack && (!cur.hasActiveSession || !cur.isPlaying)) {
            updatePlayingFlag(true)
        }
    }

    private fun resolveRealtimeDeltaMs(reportedUpdateTime: Long, nowElapsed: Long): Long {
        if (reportedUpdateTime <= 0L) return -1L
        if (reportedUpdateTime in 1L..(nowElapsed + 2000L) && (nowElapsed - reportedUpdateTime) in 0L..14_400_000L) {
            return (nowElapsed - reportedUpdateTime).coerceAtLeast(0L)
        }
        val nowWall = System.currentTimeMillis()
        if (reportedUpdateTime in (nowWall - 14_400_000L)..(nowWall + 2000L)) {
            return (nowWall - reportedUpdateTime).coerceAtLeast(0L)
        }
        return -1L
    }

    fun updateMetadata(
        context: Context? = null,
        title: String,
        artist: String,
        sourcePackage: String,
        sourceAppName: String,
        cover: Bitmap?,
        coverSignature: Int = 0,
        artUri: String = "",
        durationMs: Long = -1L,
        positionMs: Long = -1L,
        positionUpdateRealtime: Long = 0L,
        speed: Float = 1.0f
    ) {
        val current = _state.value
        val now = SystemClock.elapsedRealtime()
        val resolvedPkg = if (sourcePackage.isNotBlank()) sourcePackage else current.sourcePackage
        val pkgChanged = resolvedPkg.isNotBlank() && current.sourcePackage.isNotBlank() && resolvedPkg != current.sourcePackage
        var resolvedTitle = if (title.isNotBlank()) title else if (!pkgChanged) current.title else ""
        var resolvedArtist = if (artist.isNotBlank()) artist else if (!pkgChanged) current.artist else ""
        val resolvedAppName = if (sourceAppName.isNotBlank()) sourceAppName else if (!pkgChanged) current.sourceAppName else ""

        // Если плеер (например SoundCloud или YouTube) передал "Artist - Track Title" в одной строке заголовка:
        if (resolvedTitle.isNotBlank() && (resolvedArtist.isBlank() || resolvedArtist.equals(resolvedAppName, ignoreCase = true))) {
            val separators = listOf(" — ", " – ", " - ")
            for (sep in separators) {
                if (resolvedTitle.contains(sep)) {
                    val left = resolvedTitle.substringBefore(sep).trim()
                    val right = resolvedTitle.substringAfter(sep).trim()
                    if (left.length in 2..45 && right.length >= 2) {
                        resolvedArtist = left
                        resolvedTitle = right
                        break
                    }
                }
            }
        }

        val newIdentity = "$resolvedPkg|$resolvedTitle"
        if (dismissedTrackIdentity.isNotEmpty()) {
            if ((now - dismissedAtRealtime) < 2500L) return
            if (newIdentity == dismissedTrackIdentity && !current.isPlaying) return
            if (newIdentity != dismissedTrackIdentity) {
                dismissedTrackIdentity = ""
                pausedByLauncherControl = false
            }
        }

        val trackChanged = (resolvedTitle.isNotBlank() && newIdentity != currentTrackIdentity) || pkgChanged
        if (trackChanged) {
            currentTrackIdentity = newIdentity
            trackStartRealtime = now
            lastObservedRawPos = -1L
            lastObservedRawRealtime = 0L
            pausedByLauncherControl = false
        }

        val posActuallyChanged = positionMs >= 0L && positionMs != lastObservedRawPos
        if (posActuallyChanged) {
            lastObservedRawPos = positionMs
            lastObservedRawRealtime = now
        }

        var resolvedCover: Bitmap? = when {
            cover != null -> {
                val incomingSig = if (coverSignature != 0) coverSignature else computeBitmapSignature(cover)
                if (trackChanged && incomingSig != 0 && incomingSig == currentCoverSignature && artUri.isNotBlank() && artUri != currentArtUri) {
                    null
                } else {
                    currentCoverSignature = incomingSig
                    cover
                }
            }
            !trackChanged && !pkgChanged -> current.coverBitmap
            else -> {
                currentCoverSignature = 0
                null
            }
        }

        val normalizedUri = normalizeArtUri(artUri)
        if (normalizedUri.isNotBlank() && (resolvedCover == null || normalizedUri != currentArtUri)) {
            currentArtUri = normalizedUri
            val cached = artUriCache.get(normalizedUri)
            if (cached != null) {
                resolvedCover = cached
                currentCoverSignature = computeBitmapSignature(cached)
            } else if (normalizedUri != lastFetchedArtUri) {
                lastFetchedArtUri = normalizedUri
                fetchArtFromUriAsync(context, normalizedUri, newIdentity)
            }
        }

        val saneIncomingDur = sanitizeTrackDurationMs(durationMs)
        val resolvedDuration = if (saneIncomingDur > 0L) saneIncomingDur else if (trackChanged) 0L else current.durationMs
        val deltaFromReport = resolveRealtimeDeltaMs(positionUpdateRealtime, now)

        val resolvedPos = when {
            positionMs > 0L -> if (resolvedDuration > 0L) positionMs.coerceAtMost(resolvedDuration) else positionMs
            trackChanged -> 0L
            positionMs == 0L && deltaFromReport >= 0L -> 0L
            else -> current.basePositionMs
        }
        val resolvedRealtime = when {
            deltaFromReport >= 0L -> (now - deltaFromReport).coerceAtLeast(1L)
            posActuallyChanged && positionMs > 0L -> now
            trackChanged -> now
            current.baseElapsedRealtime > 0L -> current.baseElapsedRealtime
            else -> trackStartRealtime
        }

        val hasValidTrackTitle = resolvedTitle.isNotBlank() &&
            !resolvedTitle.equals(resolvedAppName, ignoreCase = true) &&
            !isExcludedVideoPackage(resolvedPkg)
        val playingNow = if (trackChanged) !pausedByLauncherControl else current.isPlaying
        if (hasValidTrackTitle && playingNow) {
            hasObservedActivePlaybackSinceBoot = true
        }
        if (dismissedTrackIdentity.isNotEmpty() && newIdentity == dismissedTrackIdentity && !playingNow) {
            return
        }
        val hasSession = hasValidTrackTitle

        var finalDuration = resolvedDuration
        val lookupKey = "${resolvedArtist.lowercase()}|${resolvedTitle.lowercase()}"
        val cachedCat = catalogLookupCache.get(lookupKey)
        if (cachedCat != null) {
            if (finalDuration <= 0L && cachedCat.second > 0L) {
                finalDuration = cachedCat.second
            }
            if (resolvedCover == null && cachedCat.first.isNotBlank()) {
                val bmp = artUriCache.get(cachedCat.first)
                if (bmp != null) {
                    resolvedCover = bmp
                }
            }
        }

        _state.value = current.copy(
            hasActiveSession = hasSession,
            isPlaying = playingNow,
            title = resolvedTitle,
            artist = resolvedArtist,
            sourcePackage = resolvedPkg,
            sourceAppName = resolvedAppName,
            coverBitmap = resolvedCover,
            durationMs = finalDuration,
            basePositionMs = resolvedPos,
            baseElapsedRealtime = resolvedRealtime,
            playbackSpeed = if (speed > 0f) speed else 1.0f
        )

        if (resolvedTitle.isNotBlank() && (resolvedCover == null || finalDuration <= 0L) && lookupKey != lastCatalogLookupKey) {
            lastCatalogLookupKey = lookupKey
            fetchTrackArtAndDurationFromCatalog(context, resolvedTitle, resolvedArtist, resolvedAppName, lookupKey, newIdentity)
        }
    }

    /**
     * Если плеер не отдал картинку обложки или длительность трека (например SoundCloud / Bluetooth / локальный плеер),
     * за 150 мс находим официальную обложку и длительность через бесплатный открытый каталог Deezer / iTunes API!
     */
    private fun fetchTrackArtAndDurationFromCatalog(
        context: Context?,
        trackTitle: String,
        trackArtist: String,
        appName: String,
        lookupKey: String,
        expectedIdentity: String
    ) {
        val cleanArtist = if (trackArtist.equals(appName, ignoreCase = true)) "" else trackArtist
        val query = if (cleanArtist.isNotBlank()) "$cleanArtist $trackTitle" else trackTitle
        if (query.length < 3) return

        ioScope.launch {
            var foundArtUrl = ""
            var foundDurationMs = 0L
            var foundArtistName = ""
            var foundOfficialTitle = ""

            // 1. Быстрый запрос к публичному каталогу Deezer API (без ключа)
            try {
                val encoded = URLEncoder.encode(query, "UTF-8")
                val conn = (URL("https://api.deezer.com/search?q=$encoded&limit=1").openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 3000
                    readTimeout = 3500
                    doInput = true
                }
                if (conn.responseCode in 200..299) {
                    val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    val root = JSONObject(body)
                    val dataArr = root.optJSONArray("data")
                    if (dataArr != null && dataArr.length() > 0) {
                        val item = dataArr.optJSONObject(0)
                        if (item != null) {
                            val durSec = item.optLong("duration", 0L)
                            if (durSec > 0L) foundDurationMs = durSec * 1000L
                            foundOfficialTitle = item.optString("title_short", "").ifEmpty { item.optString("title", "") }
                            foundArtistName = item.optJSONObject("artist")?.optString("name", "").orEmpty()
                            val albumObj = item.optJSONObject("album")
                            foundArtUrl = albumObj?.optString("cover_medium", "").orEmpty()
                                .ifEmpty { albumObj?.optString("cover", "").orEmpty() }
                        }
                    }
                }
                conn.disconnect()
            } catch (_: Exception) {
            }

            // 2. Резервный запрос к iTunes Search API (если в Deezer не нашлось)
            if (foundArtUrl.isBlank() && foundDurationMs <= 0L) {
                try {
                    val encoded = URLEncoder.encode(query, "UTF-8")
                    val conn = (URL("https://itunes.apple.com/search?term=$encoded&entity=song&limit=1").openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 3000
                        readTimeout = 3500
                        doInput = true
                    }
                    if (conn.responseCode in 200..299) {
                        val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                        val root = JSONObject(body)
                        val resultsArr = root.optJSONArray("results")
                        if (resultsArr != null && resultsArr.length() > 0) {
                            val item = resultsArr.optJSONObject(0)
                            if (item != null) {
                                val tMillis = item.optLong("trackTimeMillis", 0L)
                                if (tMillis > 0L) foundDurationMs = tMillis
                                foundOfficialTitle = item.optString("trackName", "")
                                foundArtistName = item.optString("artistName", "")
                                foundArtUrl = item.optString("artworkUrl100", "").replace("100x100bb", "300x300bb")
                            }
                        }
                    }
                    conn.disconnect()
                } catch (_: Exception) {
                }
            }

            if (foundArtUrl.isNotBlank() || foundDurationMs > 0L) {
                catalogLookupCache.put(lookupKey, foundArtUrl to foundDurationMs)
                var downloadedBmp: Bitmap? = null
                if (foundArtUrl.isNotBlank()) {
                    downloadedBmp = artUriCache.get(foundArtUrl)
                    if (downloadedBmp == null) {
                        try {
                            val c = (URL(foundArtUrl).openConnection() as HttpURLConnection).apply {
                                connectTimeout = 3500
                                readTimeout = 3500
                                doInput = true
                            }
                            if (c.responseCode in 200..299) {
                                val raw = c.inputStream.use { BitmapFactory.decodeStream(it) }
                                if (raw != null) {
                                    downloadedBmp = safeScaleBitmap(raw)
                                    if (downloadedBmp != null) {
                                        artUriCache.put(foundArtUrl, downloadedBmp)
                                    }
                                }
                            }
                            c.disconnect()
                        } catch (_: Exception) {
                        }
                    }
                }

                val cur = _state.value
                if (currentTrackIdentity == expectedIdentity || cur.title.equals(trackTitle, ignoreCase = true) || cur.title.isBlank()) {
                    val betterTitle = if (foundOfficialTitle.isNotBlank() && (cur.artist.isBlank() || cur.artist.equals(appName, ignoreCase = true))) {
                        foundOfficialTitle
                    } else {
                        cur.title.ifBlank { foundOfficialTitle }
                    }
                    val betterArtist = if (cur.artist.isBlank() || cur.artist.equals(appName, ignoreCase = true)) {
                        foundArtistName.ifBlank { cur.artist }
                    } else {
                        cur.artist
                    }
                    currentTrackIdentity = "${cur.sourcePackage}|$betterTitle"
                    _state.value = cur.copy(
                        title = betterTitle,
                        artist = betterArtist,
                        coverBitmap = downloadedBmp ?: cur.coverBitmap,
                        durationMs = if (cur.durationMs > 0L) cur.durationMs else foundDurationMs
                    )
                }
            }
        }
    }

    fun updatePositionOnly(positionMs: Long, positionUpdateRealtime: Long, speed: Float, isPlaying: Boolean) {
        val cur = _state.value
        val now = SystemClock.elapsedRealtime()
        if (dismissedTrackIdentity.isNotEmpty() && (now - dismissedAtRealtime) < 2500L && !isPlaying) return
        if (isPlaying) {
            dismissedTrackIdentity = ""
            pausedByLauncherControl = false
            lastPausedRealtime = 0L
        } else if (cur.isPlaying) {
            lastPausedRealtime = now
        }
        val posActuallyChanged = positionMs >= 0L && positionMs != lastObservedRawPos
        if (posActuallyChanged) {
            lastObservedRawPos = positionMs
            lastObservedRawRealtime = now
        }
        val deltaFromReport = resolveRealtimeDeltaMs(positionUpdateRealtime, now)
        val validPos = if (positionMs > 0L || (positionMs == 0L && deltaFromReport >= 0L)) {
            if (cur.durationMs > 0L) positionMs.coerceAtMost(cur.durationMs) else positionMs
        } else {
            cur.basePositionMs
        }
        val validRealtime = when {
            deltaFromReport >= 0L -> (now - deltaFromReport).coerceAtLeast(1L)
            posActuallyChanged && positionMs > 0L -> now
            cur.baseElapsedRealtime > 0L -> cur.baseElapsedRealtime
            else -> trackStartRealtime
        }
        _state.value = cur.copy(
            hasActiveSession = cur.hasActiveSession || isPlaying,
            isPlaying = isPlaying,
            basePositionMs = validPos,
            baseElapsedRealtime = validRealtime,
            playbackSpeed = if (speed > 0f) speed else 1.0f
        )
    }

    private fun fetchArtFromUriAsync(context: Context?, uriString: String, expectedIdentity: String) {
        val appCtx = context?.applicationContext
        val normalized = normalizeArtUri(uriString)
        ioScope.launch {
            try {
                val raw: Bitmap? = when {
                    normalized.startsWith("http://") || normalized.startsWith("https://") -> {
                        val conn = (URL(normalized).openConnection() as HttpURLConnection).apply {
                            connectTimeout = 3500
                            readTimeout = 3500
                            doInput = true
                        }
                        conn.connect()
                        val decoded = conn.inputStream.use { BitmapFactory.decodeStream(it) }
                        conn.disconnect()
                        decoded
                    }
                    (normalized.startsWith("content://") || normalized.startsWith("android.resource://") || normalized.startsWith("file://")) && appCtx != null -> {
                        appCtx.contentResolver.openInputStream(Uri.parse(normalized))?.use {
                            BitmapFactory.decodeStream(it)
                        }
                    }
                    else -> null
                }

                if (raw != null) {
                    val scaled = safeScaleBitmap(raw)
                    if (scaled != null && scaled !== raw && !raw.isRecycled) raw.recycle()
                    if (scaled != null) {
                        artUriCache.put(normalized, scaled)
                        if (currentTrackIdentity == expectedIdentity || _state.value.coverBitmap == null || currentArtUri == normalized) {
                            currentCoverSignature = computeBitmapSignature(scaled)
                            _state.value = _state.value.copy(coverBitmap = scaled)
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    fun updatePlayingFlag(isPlaying: Boolean) {
        val cur = _state.value
        val now = SystemClock.elapsedRealtime()
        if (isPlaying) {
            if (dismissedTrackIdentity.isNotEmpty() && (now - dismissedAtRealtime) < 2500L) return
            dismissedTrackIdentity = ""
            pausedByLauncherControl = false
            lastPausedRealtime = 0L
            if (!cur.isPlaying && cur.basePositionMs == 0L) {
                trackStartRealtime = now
            }
            if (!cur.isPlaying || !cur.hasActiveSession) {
                _state.value = cur.copy(
                    hasActiveSession = true,
                    isPlaying = true,
                    baseElapsedRealtime = if (cur.baseElapsedRealtime > 0L) cur.baseElapsedRealtime else now
                )
            }
        } else {
            if (cur.isPlaying) {
                val (frozenPos, _) = getLivePositionAndDuration()
                lastPausedRealtime = now
                _state.value = cur.copy(
                    isPlaying = false,
                    basePositionMs = frozenPos,
                    baseElapsedRealtime = now
                )
            } else if (cur.hasActiveSession && lastPausedRealtime > 0L && (now - lastPausedRealtime) > 20 * 60 * 1000L) {
                _state.value = cur.copy(hasActiveSession = false)
            }
        }
    }

    fun pollActiveControllerLight(context: Context? = null) {
        if (context != null) {
            queryMediaSessionManagerDirect(context)
            MediaSessionListenerService.instance?.pollActiveMediaNotifications(context)
            pollDumpsysMediaSessionAsync(context, force = false)
        }
        val ctrl = activeController ?: return
        if (context != null) {
            syncControllerImmediate(context, ctrl)
        }
    }

    private fun sanitizeTrackDurationMs(rawMs: Long): Long {
        if (rawMs <= 0L) return 0L
        // Обычный музыкальный трек: до 25 минут (1 500 000 мс). Значения вроде 1251:27 (75 087 000 мс) отсекаем.
        if (rawMs in 5_000L..(25L * 60L * 1000L)) return rawMs
        val fromMicros = rawMs / 1000L
        if (fromMicros in 10_000L..(15L * 60L * 1000L)) return fromMicros
        return 0L
    }

    fun getLivePositionAndDuration(): Pair<Long, Long> {
        val ctrl = activeController
        val snap = _state.value
        val now = SystemClock.elapsedRealtime()

        var dur = sanitizeTrackDurationMs(snap.durationMs)
        if (ctrl != null) {
            try {
                val rawMetaDur = ctrl.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
                val cleanMetaDur = sanitizeTrackDurationMs(rawMetaDur)
                if (cleanMetaDur > 0L) dur = cleanMetaDur
            } catch (_: Exception) {
            }
        }

        if (!snap.isPlaying) {
            val frozen = if (dur > 0L) snap.basePositionMs.coerceIn(0L, dur) else snap.basePositionMs.coerceAtLeast(0L)
            return frozen to dur
        }

        if (ctrl != null) {
            try {
                val pb = ctrl.playbackState
                if (pb != null && pb.position >= 0L) {
                    val speed = if (pb.playbackSpeed > 0f) pb.playbackSpeed else 1.0f
                    val deltaReport = resolveRealtimeDeltaMs(pb.lastPositionUpdateTime, now)
                    if (pb.position > 0L || (pb.position == 0L && isActivelyPlayingState(pb.state) && deltaReport >= 0L)) {
                        var pos = pb.position
                        val delta = when {
                            deltaReport >= 0L -> deltaReport
                            lastObservedRawRealtime in 1L..now -> (now - lastObservedRawRealtime).coerceAtLeast(0L)
                            else -> 0L
                        }
                        pos += (delta * speed).toLong().coerceAtLeast(0L)
                        if (dur > 0L) pos = pos.coerceAtMost(dur)
                        return pos.coerceAtLeast(0L) to dur
                    }
                }
            } catch (_: Exception) {
            }
        }

        if (snap.basePositionMs > 0L && snap.baseElapsedRealtime > 0L) {
            val delta = (now - snap.baseElapsedRealtime).coerceAtLeast(0L)
            var pos = snap.basePositionMs + (delta * snap.playbackSpeed).toLong().coerceAtLeast(0L)
            if (dur > 0L) pos = pos.coerceAtMost(dur)
            return pos to dur
        }

        var elapsed = (now - trackStartRealtime).coerceAtLeast(0L)
        if (dur > 0L) elapsed = elapsed.coerceAtMost(dur)
        return elapsed to dur
    }

    fun dispatchTransportAction(action: String, audioManager: AudioManager) {
        val ctrl = activeController
        val now = SystemClock.elapsedRealtime()

        if (action == "PREV" || action == "NEXT") {
            pausedByLauncherControl = false
            var handledByCtrl = false
            if (ctrl != null) {
                try {
                    if (action == "PREV") ctrl.transportControls.skipToPrevious()
                    else ctrl.transportControls.skipToNext()
                    handledByCtrl = true
                } catch (_: Exception) {
                }
            }
            if (!handledByCtrl) {
                try {
                    val keyCode = if (action == "PREV") KeyEvent.KEYCODE_MEDIA_PREVIOUS else KeyEvent.KEYCODE_MEDIA_NEXT
                    val upNow = SystemClock.uptimeMillis()
                    audioManager.dispatchMediaKeyEvent(KeyEvent(upNow, upNow, KeyEvent.ACTION_DOWN, keyCode, 0))
                    audioManager.dispatchMediaKeyEvent(KeyEvent(upNow, upNow, KeyEvent.ACTION_UP, keyCode, 0))
                } catch (_: Exception) {
                }
            }
            return
        }

        val pbState = ctrl?.playbackState?.state
        val actuallyPlaying = try {
            audioManager.isMusicActive || (isActivelyPlayingState(pbState) && !pausedByLauncherControl)
        } catch (_: Exception) {
            _state.value.isPlaying
        }

        val targetPlay = when (action) {
            "PLAY" -> true
            "PAUSE" -> false
            else -> !actuallyPlaying
        }

        pausedByLauncherControl = !targetPlay
        if (!targetPlay) {
            lastLauncherPauseRealtime = now
        } else {
            dismissedTrackIdentity = ""
        }
        updatePlayingFlag(targetPlay)

        val specificKeyCode = if (targetPlay) KeyEvent.KEYCODE_MEDIA_PLAY else KeyEvent.KEYCODE_MEDIA_PAUSE

        // Этап 1 (0 мс): TransportControls активной сессии или прямой медиа-ключ
        if (ctrl != null) {
            try {
                if (targetPlay) ctrl.transportControls.play() else ctrl.transportControls.pause()
            } catch (_: Exception) {
                try {
                    val t0 = SystemClock.uptimeMillis()
                    audioManager.dispatchMediaKeyEvent(KeyEvent(t0, t0, KeyEvent.ACTION_DOWN, specificKeyCode, 0))
                    audioManager.dispatchMediaKeyEvent(KeyEvent(t0, t0, KeyEvent.ACTION_UP, specificKeyCode, 0))
                } catch (_: Exception) {
                }
            }
        } else {
            try {
                val t0 = SystemClock.uptimeMillis()
                audioManager.dispatchMediaKeyEvent(KeyEvent(t0, t0, KeyEvent.ACTION_DOWN, specificKeyCode, 0))
                audioManager.dispatchMediaKeyEvent(KeyEvent(t0, t0, KeyEvent.ACTION_UP, specificKeyCode, 0))
            } catch (_: Exception) {
            }
        }

        // Этап 2 (160 мс): если звук не переключился в нужное состояние — отправляем KEYCODE_MEDIA_PLAY / PAUSE
        mainHandler.postDelayed({
            try {
                if (audioManager.isMusicActive != targetPlay) {
                    val t1 = SystemClock.uptimeMillis()
                    audioManager.dispatchMediaKeyEvent(KeyEvent(t1, t1, KeyEvent.ACTION_DOWN, specificKeyCode, 0))
                    audioManager.dispatchMediaKeyEvent(KeyEvent(t1, t1, KeyEvent.ACTION_UP, specificKeyCode, 0))
                }
            } catch (_: Exception) {
            }
        }, 160L)

        // Этап 3 (340 мс): контрольный KEYCODE_MEDIA_PLAY_PAUSE, если плеер игнорирует раздельные PLAY/PAUSE
        mainHandler.postDelayed({
            try {
                if (audioManager.isMusicActive != targetPlay) {
                    val t2 = SystemClock.uptimeMillis()
                    audioManager.dispatchMediaKeyEvent(KeyEvent(t2, t2, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, 0))
                    audioManager.dispatchMediaKeyEvent(KeyEvent(t2, t2, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, 0))
                }
            } catch (_: Exception) {
            }
        }, 340L)
    }
}
