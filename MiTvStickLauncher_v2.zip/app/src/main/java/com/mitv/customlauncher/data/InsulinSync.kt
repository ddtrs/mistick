package com.mitv.customlauncher.data

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.util.Log
import com.mitv.customlauncher.service.DynamicIslandBus
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * Синхронизация Эхо с ботом отметок (этап 2).
 *
 * Журнал, время и тексты живут в Cloudflare Worker (маршруты под адресом /ins). Приложение ничего не считает и не
 * форматирует: оно отправляет запрос и произносит готовый текст из ответа Воркера.
 *
 *  - markByVoice / askLast / undoByVoice вызываются тегами [CMD:INS_MARK] / [CMD:INS_LAST] / [CMD:INS_UNDO];
 *  - onTick вызывается из цикла ScheduledTaskManager каждые 2 секунды и сам ограничивает опрос до раза в минуту.
 */
object InsulinSync {
    private const val TAG = "InsulinSync"
    private const val PREF_LAST_SEQ = "pref_ins_last_seq_v1"
    private const val CONNECT_TIMEOUT_MS = 5000
    private const val READ_TIMEOUT_MS = 6000
    private const val POLL_INTERVAL_MS = 60_000L
    private const val DEDUP_MS = 5_000L
    private const val RETRY_DELAY_MS = 1_500L

    private const val ERR_MARK = "Не получилось записать отметку. Проверьте связь и повторите или отметьте в Telegram."
    private const val ERR_LAST = "Не получилось узнать. Спросите у бота: когда колол."
    private const val ERR_UNDO = "Не получилось удалить отметку. Отправьте /undo в Telegram."

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())

    private val lastCallMs = HashMap<String, Long>()

    @Volatile
    private var lastPollElapsedMs = 0L

    @Volatile
    private var pollInFlight = false

    private class Reply(val status: Int, val json: JSONObject?)

    // ---------------------------------------------------------------- голосовые команды

    fun markByVoice(context: Context) {
        if (!dedupAllowed("mark")) return
        val appCtx = context.applicationContext
        scope.launch {
            val reply = requestWithRetry("POST", "/ins/mark", true)
            speakFromReply(appCtx, reply, ERR_MARK)
        }
    }

    fun askLast(context: Context) {
        if (!dedupAllowed("last")) return
        val appCtx = context.applicationContext
        scope.launch {
            val reply = requestWithRetry("GET", "/ins/last", true)
            speakFromReply(appCtx, reply, ERR_LAST)
        }
    }

    /** Без повтора: повтор после потерянного ответа удалил бы предыдущую отметку. */
    fun undoByVoice(context: Context) {
        if (!dedupAllowed("undo")) return
        val appCtx = context.applicationContext
        scope.launch {
            val reply = requestWithRetry("POST", "/ins/undo", false)
            speakFromReply(appCtx, reply, ERR_UNDO)
        }
    }

    // ---------------------------------------------------------------- опрос напоминаний

    fun onTick(context: Context) {
        if (pollInFlight) return
        val now = SystemClock.elapsedRealtime()
        if (lastPollElapsedMs != 0L && now - lastPollElapsedMs < POLL_INTERVAL_MS) return
        lastPollElapsedMs = now
        pollInFlight = true
        val appCtx = context.applicationContext
        scope.launch {
            try {
                val reply = requestWithRetry("GET", "/ins/pending", false)
                if (reply == null || reply.status !in 200..299) {
                    Log.d(TAG, "pending: no reply, status=" + (reply?.status ?: -1))
                    return@launch
                }
                val j = reply.json ?: return@launch
                if (!j.optBoolean("ok", false)) return@launch
                if (!j.optBoolean("active", false)) return@launch
                val seq = j.optString("seq", "")
                val text = j.optString("text", "").trim()
                if (seq.isEmpty() || text.isEmpty()) return@launch
                val prefs = appCtx.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
                if (prefs.getString(PREF_LAST_SEQ, "") == seq) return@launch
                prefs.edit().putString(PREF_LAST_SEQ, seq).apply()
                announce(appCtx, text)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                Log.d(TAG, "pending failed: " + e.javaClass.simpleName)
            } finally {
                pollInFlight = false
            }
        }
    }

    // ---------------------------------------------------------------- сеть

    private suspend fun requestWithRetry(method: String, path: String, retryOnNetworkError: Boolean): Reply? {
        var attempt = 0
        while (true) {
            try {
                return request(method, path)
            } catch (e: IOException) {
                Log.w(TAG, "network error on " + path + ": " + e.javaClass.simpleName)
                if (!retryOnNetworkError || attempt >= 1) return null
                attempt++
                delay(RETRY_DELAY_MS)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Throwable) {
                Log.w(TAG, "error on " + path + ": " + e.javaClass.simpleName)
                return null
            }
        }
    }

    private fun request(method: String, path: String): Reply {
        val url = URL(LauncherConfig.CLOUDFLARE_GATEWAY_URL + path)
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = method
            connectTimeout = CONNECT_TIMEOUT_MS
            readTimeout = READ_TIMEOUT_MS
            setRequestProperty("x-app-secret", LauncherConfig.GATEWAY_APP_SECRET)
            setRequestProperty("Accept", "application/json")
            if (method == "POST") {
                doOutput = true
                setRequestProperty("Content-Type", "application/json")
            }
        }
        try {
            if (method == "POST") {
                conn.outputStream.use { it.write("{}".toByteArray(Charsets.UTF_8)) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            val json = try {
                if (text.isNotBlank()) JSONObject(text) else null
            } catch (_: Exception) {
                null
            }
            return Reply(code, json)
        } finally {
            conn.disconnect()
        }
    }

    // ---------------------------------------------------------------- озвучка и защита от повторов

    private fun speakFromReply(context: Context, reply: Reply?, errorText: String) {
        if (reply == null || reply.status !in 200..299) {
            announce(context, errorText)
            return
        }
        val j = reply.json
        if (j == null || !j.optBoolean("ok", false)) {
            announce(context, errorText)
            return
        }
        val text = j.optString("text", "").trim()
        if (text.isEmpty()) {
            Log.w(TAG, "reply without text")
            return
        }
        announce(context, text)
    }

    private fun announce(context: Context, text: String) {
        val clean = text.trim()
        if (clean.isEmpty()) return
        mainHandler.post {
            try {
                DynamicIslandBus.showAnnouncement(context, clean, clean)
            } catch (e: Exception) {
                Log.w(TAG, "announce failed: " + e.javaClass.simpleName)
            }
        }
    }

    /** Модель иногда дублирует тег: повторный вызов той же функции в течение 5 секунд игнорируется. */
    private fun dedupAllowed(kind: String): Boolean {
        synchronized(lastCallMs) {
            val now = SystemClock.elapsedRealtime()
            val prev = lastCallMs[kind]
            if (prev != null && now - prev < DEDUP_MS) return false
            lastCallMs[kind] = now
            return true
        }
    }
}
