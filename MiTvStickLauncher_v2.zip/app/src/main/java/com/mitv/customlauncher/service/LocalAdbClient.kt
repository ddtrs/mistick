package com.mitv.customlauncher.service

import android.content.Context
import android.content.pm.PackageManager
import android.util.Base64
import android.util.Log
import java.io.ByteArrayOutputStream
import java.io.DataInputStream
import java.io.File
import java.io.OutputStream
import java.math.BigInteger
import java.net.InetSocketAddress
import java.net.Socket
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.security.KeyFactory
import java.security.KeyPair
import java.security.KeyPairGenerator
import java.security.interfaces.RSAPrivateKey
import java.security.interfaces.RSAPublicKey
import java.security.spec.PKCS8EncodedKeySpec
import java.security.spec.X509EncodedKeySpec
import javax.crypto.Cipher

/**
 * Лёгкий встроенный локальный ADB TCP-клиент (127.0.0.1:5555) без внешних библиотек.
 *
 * Позволяет лаунчеру выполнять системные команды с правами shell (uid 2000) без root:
 * - Включать / отключать Chromecast (com.google.android.apps.mediashell) в 1 клик
 * - Реально выгружать фоновые приложения через `am force-stop` и очищать кэш (`pm trim-caches`)
 *
 * При первом подключении adbd покажет системное окно «Разрешить отладку» (нужно отметить «Всегда разрешать»).
 */
object LocalAdbClient {

    private const val TAG = "LocalAdbClient"
    const val CHROMECAST_PACKAGE = "com.google.android.apps.mediashell"

    private const val ADB_HOST = "127.0.0.1"
    private const val ADB_PORT = 5555
    private const val CONNECT_TIMEOUT_MS = 1200
    private const val CMD_TIMEOUT_MS = 4000
    private const val AUTH_PROMPT_TIMEOUT_MS = 15000

    private const val A_CNXN = 0x4e584e43
    private const val A_AUTH = 0x48545541
    private const val A_OPEN = 0x4e45504f
    private const val A_OKAY = 0x59414b4f
    private const val A_CLSE = 0x45534c43
    private const val A_WRTE = 0x45545257

    private const val ADB_VERSION = 0x01000000
    private const val ADB_MAXDATA = 4096

    private const val AUTH_TOKEN = 1
    private const val AUTH_SIGNATURE = 2
    private const val AUTH_RSAPUBLICKEY = 3

    // DER-префикс DigestInfo для SHA-1 (требуется adbd при проверке 20-байтного токена)
    private val SHA1_DIGEST_INFO_PREFIX = byteArrayOf(
        0x30, 0x21, 0x30, 0x09, 0x06, 0x05, 0x2b, 0x0e,
        0x03, 0x02, 0x1a, 0x05, 0x00, 0x04, 0x14
    )

    private val lock = Any()
    @Volatile
    private var cachedKeyPair: KeyPair? = null

    data class ShellResult(val ok: Boolean, val output: String = "", val error: String = "")

    // ───────────────────────── Высокоуровневые команды ─────────────────────────

    fun isChromecastEnabled(context: Context): Boolean {
        return try {
            val state = context.packageManager.getApplicationEnabledSetting(CHROMECAST_PACKAGE)
            state == PackageManager.COMPONENT_ENABLED_STATE_DEFAULT ||
                state == PackageManager.COMPONENT_ENABLED_STATE_ENABLED
        } catch (_: Exception) {
            false
        }
    }

    fun toggleChromecast(context: Context): Pair<Boolean, Boolean> {
        val currentlyEnabled = isChromecastEnabled(context)
        val cmd = if (currentlyEnabled) {
            "pm disable-user --user 0 $CHROMECAST_PACKAGE"
        } else {
            "pm enable --user 0 $CHROMECAST_PACKAGE"
        }
        val res = execShell(context, cmd, allowAuthPrompt = true)
        val newState = isChromecastEnabled(context)
        val success = res.ok && (newState != currentlyEnabled)
        return Pair(success, newState)
    }

    fun forceStopPackage(context: Context, packageName: String): Boolean {
        val safe = sanitizePackageName(packageName) ?: return false
        val res = execShell(context, "am force-stop $safe", allowAuthPrompt = false)
        return res.ok
    }

    fun forceStopPackagesAndTrim(context: Context, packages: List<String>): Boolean {
        val valid = packages.mapNotNull { sanitizePackageName(it) }.distinct()
        val sb = StringBuilder()
        for (pkg in valid) {
            sb.append("am force-stop ").append(pkg).append("; ")
        }
        sb.append("am kill-all; pm trim-caches 999G")
        val res = execShell(context, sb.toString(), allowAuthPrompt = false)
        return res.ok
    }

    private fun sanitizePackageName(pkg: String): String? {
        val trimmed = pkg.trim()
        if (trimmed.isEmpty() || trimmed.length > 128) return null
        for (ch in trimmed) {
            if (!(ch.isLetterOrDigit() || ch == '.' || ch == '_')) return null
        }
        return trimmed
    }

    // ───────────────────────── ADB TCP-протокол ─────────────────────────

    fun execShell(context: Context, command: String, allowAuthPrompt: Boolean = false): ShellResult {
        synchronized(lock) {
            var socket: Socket? = null
            return try {
                val keyPair = loadOrCreateKeyPair(context.applicationContext)
                socket = Socket()
                socket.tcpNoDelay = true
                socket.connect(InetSocketAddress(ADB_HOST, ADB_PORT), CONNECT_TIMEOUT_MS)
                socket.soTimeout = CMD_TIMEOUT_MS

                val inp = DataInputStream(socket.getInputStream())
                val out = socket.getOutputStream()

                // 1. Handshake CNXN
                writePacket(out, A_CNXN, ADB_VERSION, ADB_MAXDATA, "host::\u0000".toByteArray(Charsets.UTF_8))

                var connected = false
                var sentSignature = false
                var sentPubKey = false

                for (attempt in 0 until 6) {
                    val pkt = readPacket(inp) ?: return ShellResult(false, error = "EOF during handshake")
                    when (pkt.command) {
                        A_CNXN -> {
                            connected = true
                            break
                        }
                        A_AUTH -> {
                            if (pkt.arg0 != AUTH_TOKEN) {
                                return ShellResult(false, error = "Unexpected AUTH type ${pkt.arg0}")
                            }
                            if (!sentSignature) {
                                sentSignature = true
                                val sig = signToken(keyPair.private as RSAPrivateKey, pkt.data)
                                writePacket(out, A_AUTH, AUTH_SIGNATURE, 0, sig)
                            } else if (!sentPubKey && allowAuthPrompt) {
                                sentPubKey = true
                                socket.soTimeout = AUTH_PROMPT_TIMEOUT_MS
                                val pubBytes = encodeAndroidAdbPublicKey(keyPair.public as RSAPublicKey)
                                writePacket(out, A_AUTH, AUTH_RSAPUBLICKEY, 0, pubBytes)
                            } else {
                                return ShellResult(false, error = "ADB authorization required")
                            }
                        }
                        else -> {
                            return ShellResult(false, error = "Unexpected handshake cmd 0x${pkt.command.toString(16)}")
                        }
                    }
                }

                if (!connected) {
                    return ShellResult(false, error = "ADB handshake failed")
                }

                // 2. Open shell stream
                socket.soTimeout = CMD_TIMEOUT_MS
                val localId = 1
                var remoteId = 0
                val openPayload = "shell:$command\u0000".toByteArray(Charsets.UTF_8)
                writePacket(out, A_OPEN, localId, 0, openPayload)

                val resultBuf = ByteArrayOutputStream()
                var guard = 0
                while (guard++ < 512) {
                    val pkt = readPacket(inp) ?: break
                    when (pkt.command) {
                        A_OKAY -> {
                            if (remoteId == 0 && pkt.arg1 == localId) {
                                remoteId = pkt.arg0
                            }
                        }
                        A_WRTE -> {
                            if (pkt.arg1 == localId) {
                                if (remoteId == 0) remoteId = pkt.arg0
                                if (pkt.data.isNotEmpty()) {
                                    resultBuf.write(pkt.data)
                                }
                                writePacket(out, A_OKAY, localId, remoteId, ByteArray(0))
                            }
                        }
                        A_CLSE -> {
                            if (pkt.arg1 == localId) {
                                val rid = if (remoteId != 0) remoteId else pkt.arg0
                                try {
                                    writePacket(out, A_CLSE, localId, rid, ByteArray(0))
                                } catch (_: Exception) {
                                }
                                break
                            }
                        }
                    }
                }

                ShellResult(true, output = resultBuf.toString("UTF-8").trim())
            } catch (e: Exception) {
                Log.w(TAG, "ADB shell error ($command): ${e.javaClass.simpleName}: ${e.message}")
                ShellResult(false, error = e.message ?: e.javaClass.simpleName)
            } finally {
                try {
                    socket?.close()
                } catch (_: Exception) {
                }
            }
        }
    }

    private class AdbPacket(
        val command: Int,
        val arg0: Int,
        val arg1: Int,
        val data: ByteArray
    )

    private fun writePacket(out: OutputStream, cmd: Int, arg0: Int, arg1: Int, data: ByteArray) {
        var crc = 0
        for (b in data) {
            crc += (b.toInt() and 0xFF)
        }
        val hdr = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN)
        hdr.putInt(cmd)
        hdr.putInt(arg0)
        hdr.putInt(arg1)
        hdr.putInt(data.size)
        hdr.putInt(crc)
        hdr.putInt(cmd xor -1)
        out.write(hdr.array())
        if (data.isNotEmpty()) {
            out.write(data)
        }
        out.flush()
    }

    private fun readPacket(inp: DataInputStream): AdbPacket? {
        val hdrBytes = ByteArray(24)
        try {
            inp.readFully(hdrBytes)
        } catch (_: Exception) {
            return null
        }
        val bb = ByteBuffer.wrap(hdrBytes).order(ByteOrder.LITTLE_ENDIAN)
        val cmd = bb.int
        val arg0 = bb.int
        val arg1 = bb.int
        val dataLen = bb.int
        bb.int // crc
        val magic = bb.int
        if ((cmd xor -1) != magic || dataLen < 0 || dataLen > 256 * 1024) {
            return null
        }
        val data = if (dataLen > 0) {
            ByteArray(dataLen).also { inp.readFully(it) }
        } else {
            ByteArray(0)
        }
        return AdbPacket(cmd, arg0, arg1, data)
    }

    // ───────────────────────── RSA-2048 ключи Android ADB ─────────────────────────

    private fun loadOrCreateKeyPair(context: Context): KeyPair {
        cachedKeyPair?.let { return it }
        val privFile = File(context.filesDir, "local_adb_priv.pk8")
        val pubFile = File(context.filesDir, "local_adb_pub.x509")
        if (privFile.exists() && pubFile.exists()) {
            try {
                val kf = KeyFactory.getInstance("RSA")
                val priv = kf.generatePrivate(PKCS8EncodedKeySpec(privFile.readBytes()))
                val pub = kf.generatePublic(X509EncodedKeySpec(pubFile.readBytes()))
                val kp = KeyPair(pub, priv)
                cachedKeyPair = kp
                return kp
            } catch (_: Exception) {
            }
        }
        val kpg = KeyPairGenerator.getInstance("RSA")
        kpg.initialize(2048)
        val kp = kpg.generateKeyPair()
        try {
            privFile.writeBytes(kp.private.encoded)
            pubFile.writeBytes(kp.public.encoded)
        } catch (_: Exception) {
        }
        cachedKeyPair = kp
        return kp
    }

    private fun signToken(privateKey: RSAPrivateKey, token: ByteArray): ByteArray {
        val digestInfo = ByteArray(SHA1_DIGEST_INFO_PREFIX.size + token.size)
        System.arraycopy(SHA1_DIGEST_INFO_PREFIX, 0, digestInfo, 0, SHA1_DIGEST_INFO_PREFIX.size)
        System.arraycopy(token, 0, digestInfo, SHA1_DIGEST_INFO_PREFIX.size, token.size)
        val cipher = Cipher.getInstance("RSA/ECB/PKCS1Padding")
        cipher.init(Cipher.ENCRYPT_MODE, privateKey)
        return cipher.doFinal(digestInfo)
    }

    /**
     * Формирует 524-байтную структуру Android RSAPublicKey (Montgomery format) в Base64 + " mitv@launcher\0".
     */
    private fun encodeAndroidAdbPublicKey(pubKey: RSAPublicKey): ByteArray {
        val keySizeWords = 64 // 2048 / 32
        val n = pubKey.modulus
        val r32 = BigInteger.ONE.shiftLeft(32)
        val n0inv = r32.subtract(n.modInverse(r32))
        val r = BigInteger.ONE.shiftLeft(2048)
        val rr = r.multiply(r).mod(n)

        val buf = ByteBuffer.allocate(524).order(ByteOrder.LITTLE_ENDIAN)
        buf.putInt(keySizeWords)
        buf.putInt(n0inv.toInt())

        var remN = n
        for (i in 0 until keySizeWords) {
            val divRem = remN.divideAndRemainder(r32)
            buf.putInt(divRem[1].toInt())
            remN = divRem[0]
        }

        var remRR = rr
        for (i in 0 until keySizeWords) {
            val divRem = remRR.divideAndRemainder(r32)
            buf.putInt(divRem[1].toInt())
            remRR = divRem[0]
        }

        buf.putInt(pubKey.publicExponent.toInt())

        val b64 = Base64.encodeToString(buf.array(), Base64.NO_WRAP)
        return "$b64 mitv@launcher\u0000".toByteArray(Charsets.UTF_8)
    }
}
