package com.mitv.customlauncher.service

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.SoundPool
import android.media.MediaMetadata
import android.media.MediaRecorder
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Parcelable
import android.os.SystemClock
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.TextUtils
import android.util.Log
import android.util.LruCache
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.content.ClipData
import android.content.ClipboardManager
import java.util.Locale
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import com.mitv.customlauncher.R
import com.mitv.customlauncher.data.AssistantVoiceSpeaker
import com.mitv.customlauncher.data.GeminiCloudClient
import com.mitv.customlauncher.data.GeminiTurnResult
import com.mitv.customlauncher.data.LauncherConfig
import com.mitv.customlauncher.data.NativeCore
import com.mitv.customlauncher.data.LocalVoiceCommandRouter
import com.mitv.customlauncher.ui.EchoView
import com.mitv.customlauncher.ui.LauncherActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import org.json.JSONObject
import android.net.wifi.WifiManager
import android.os.PowerManager
import java.net.InetAddress
import java.net.InetSocketAddress
import com.mitv.customlauncher.data.TuyaSmartHomeController
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.net.URLEncoder
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sin
import kotlin.math.sqrt


/**
 * Шина ИИ-управления всем телевизором через AccessibilityService:
 * - Автоматический поиск стримера/контента внутри открытого ТВ-приложения (например Kick на ТВ)
 * - Голосовой ввод текста в любое поле поиска на экране ТВ (без пульта!)
 * - Нажатие на любую кнопку или карточку на экране по её названию
 * - Глобальная навигация (Назад, Домой, стрелки, ОК)
 */
object TvUiControllerBus {
    @Volatile
    var onScheduleInAppSearch: ((targetPkg: String, query: String) -> Unit)? = null

    @Volatile
    var onScheduleYouTubeAutoPlay: ((targetPkg: String, query: String) -> Unit)? = null

    fun scheduleYouTubeAutoPlay(targetPkg: String, query: String) {
        mainHandler.post {
            onScheduleYouTubeAutoPlay?.invoke(targetPkg, query)
        }
    }

    @Volatile
    var onTypeTextOnScreen: ((text: String) -> Boolean)? = null

    @Volatile
    var onClickNodeByText: ((text: String) -> Boolean)? = null

    @Volatile
    var onGlobalNavAction: ((action: String) -> Unit)? = null

    @Volatile
    var onInjectDpadAction: ((directionOrCenter: String) -> Boolean)? = null

    @Volatile
    var onGetScreenSummary: (() -> String)? = null

    fun getCleanScreenSummary(): String {
        return try {
            onGetScreenSummary?.invoke().orEmpty()
        } catch (_: Exception) {
            ""
        }
    }

    private val mainHandler = Handler(Looper.getMainLooper())

    fun scheduleInAppSearch(targetPkg: String, query: String) {
        mainHandler.post {
            onScheduleInAppSearch?.invoke(targetPkg, query)
        }
    }

    fun typeText(text: String) {
        mainHandler.post {
            onTypeTextOnScreen?.invoke(text)
        }
    }

    fun clickByText(text: String) {
        mainHandler.post {
            onClickNodeByText?.invoke(text)
        }
    }

    fun performNav(action: String) {
        mainHandler.post {
            onGlobalNavAction?.invoke(action)
        }
    }
}
