package com.mitv.customlauncher.service

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.SoundPool
import android.media.MediaMetadata
import android.media.MediaRecorder
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Parcelable
import android.os.SystemClock
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.TextUtils
import android.util.Log
import android.util.LruCache
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.content.ClipData
import android.content.ClipboardManager
import java.util.Locale
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import com.mitv.customlauncher.R
import com.mitv.customlauncher.data.AssistantVoiceSpeaker
import com.mitv.customlauncher.data.GeminiCloudClient
import com.mitv.customlauncher.data.GeminiTurnResult
import com.mitv.customlauncher.data.LauncherConfig
import com.mitv.customlauncher.data.NativeCore
import com.mitv.customlauncher.data.LocalVoiceCommandRouter
import com.mitv.customlauncher.ui.EchoView
import com.mitv.customlauncher.ui.LauncherActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import org.json.JSONObject
import android.net.wifi.WifiManager
import android.os.PowerManager
import java.net.InetAddress
import java.net.InetSocketAddress
import com.mitv.customlauncher.data.TuyaSmartHomeController
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.net.URLEncoder
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sin
import kotlin.math.sqrt


object RemoteConsoleServer {
    const val PORT = 8765

    @Volatile
    private var isRunning = false
    private var tcpServerSocket: ServerSocket? = null
    private var udpSocket: DatagramSocket? = null
    private var highPerfWifiLock: WifiManager.WifiLock? = null
    private var multicastArpLock: WifiManager.MulticastLock? = null
    private var partialWakeLock: PowerManager.WakeLock? = null
    private var screenStateReceiverRegistered = false
    @Volatile
    private var lastPhoneAddress: InetAddress? = null
    @Volatile
    private var forcedScreenStateOverride: Boolean? = null
    @Volatile
    private var forcedScreenStateUntilMs: Long = 0L
    private val serverScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())

    @Suppress("DEPRECATION")
    private fun acquireLocks(context: Context) {
        val appCtx = context.applicationContext
        try {
            val cr = appCtx.contentResolver
            Settings.Global.putInt(cr, Settings.Global.WIFI_SLEEP_POLICY, Settings.Global.WIFI_SLEEP_POLICY_NEVER)
            Settings.Global.putInt(cr, Settings.Global.STAY_ON_WHILE_PLUGGED_IN, 7)
            Settings.Global.putInt(cr, "wifi_wakeup_enabled", 1)
            Settings.Global.putInt(cr, "wifi_scan_always_enabled", 1)
            Settings.Global.putInt(cr, "adaptive_battery_management_enabled", 0)
            Settings.Global.putInt(cr, "app_standby_enabled", 0)
        } catch (_: Exception) {
        }
        try {
            val wm = appCtx.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            if (highPerfWifiLock?.isHeld != true) {
                val lock = wm?.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "MiTvLauncher:RemoteConsoleWifiLock")
                lock?.setReferenceCounted(false)
                lock?.acquire()
                highPerfWifiLock = lock
            }
            // MulticastLock запрещает Wi-Fi чипу включать аппаратный фильтр Broadcast/ARP пакетов при выключении экрана!
            if (multicastArpLock?.isHeld != true) {
                val mLock = wm?.createMulticastLock("MiTvLauncher:ArpMulticastLock")
                mLock?.setReferenceCounted(false)
                mLock?.acquire()
                multicastArpLock = mLock
            }
        } catch (_: Exception) {
        }
        try {
            if (partialWakeLock?.isHeld != true) {
                val pm = appCtx.getSystemService(Context.POWER_SERVICE) as? PowerManager
                val wl = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MiTvLauncher:RemoteConsoleWakeLock")
                wl?.setReferenceCounted(false)
                wl?.acquire()
                partialWakeLock = wl
            }
        } catch (_: Exception) {
        }
    }

    private fun registerScreenOffWakeGuard(context: Context) {
        if (screenStateReceiverRegistered) return
        screenStateReceiverRegistered = true
        val appCtx = context.applicationContext
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_DREAMING_STARTED)
        }
        try {
            appCtx.registerReceiver(object : BroadcastReceiver() {
                override fun onReceive(ctx: Context?, intent: Intent?) {
                    acquireLocks(appCtx)
                    serverScope.launch {
                        sendArpKeepAliveBurst()
                    }
                }
            }, filter)
        } catch (_: Exception) {
        }
    }

    private fun sendArpKeepAliveBurst() {
        val keepAlivePayload = "KA".toByteArray(Charsets.UTF_8)
        try {
            DatagramSocket().use { ks ->
                ks.soTimeout = 400
                ks.broadcast = true
                val targets = mutableListOf<InetAddress>()
                lastPhoneAddress?.let { targets.add(it) }
                for (ip in listOf("192.168.0.1", "192.168.1.1", "192.168.0.255", "255.255.255.255")) {
                    try {
                        targets.add(InetAddress.getByName(ip))
                    } catch (_: Exception) {
                    }
                }
                for (addr in targets) {
                    try {
                        ks.send(DatagramPacket(keepAlivePayload, keepAlivePayload.size, addr, 9))
                    } catch (_: Exception) {
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    @Synchronized
    fun ensureStarted(context: Context) {
        val appCtx = context.applicationContext
        acquireLocks(appCtx)
        registerScreenOffWakeGuard(appCtx)
        TuyaSmartHomeController.ensureWarmupStarted()
        if (isRunning) return
        isRunning = true

        // 1. Постоянный TCP/HTTP сервер на порту 8765
        serverScope.launch {
            while (isActive && isRunning) {
                try {
                    val server = ServerSocket()
                    server.reuseAddress = true
                    server.bind(InetSocketAddress(PORT))
                    tcpServerSocket = server
                    while (isActive && !server.isClosed) {
                        val client = try {
                            server.accept()
                        } catch (_: Exception) {
                            break
                        }
                        client.inetAddress?.let { lastPhoneAddress = it }
                        serverScope.launch {
                            handleTcpClient(appCtx, client)
                        }
                    }
                } catch (_: Exception) {
                    delay(1500L)
                } finally {
                    try {
                        tcpServerSocket?.close()
                    } catch (_: Exception) {
                    }
                }
            }
        }

        // 2. Постоянный UDP сервер на порту 8765 с reuseAddress = true
        serverScope.launch {
            while (isActive && isRunning) {
                try {
                    val ds = DatagramSocket(null)
                    ds.reuseAddress = true
                    ds.bind(InetSocketAddress(PORT))
                    udpSocket = ds
                    val buf = ByteArray(1024)
                    while (isActive && !ds.isClosed) {
                        val packet = DatagramPacket(buf, buf.size)
                        ds.receive(packet)
                        packet.address?.let { lastPhoneAddress = it }
                        val msg = String(packet.data, 0, packet.length, Charsets.UTF_8).trim()
                        if (msg.isNotEmpty()) {
                            val reply = processIncomingCommand(appCtx, msg)
                            val replyBytes = reply.toByteArray(Charsets.UTF_8)
                            val outPacket = DatagramPacket(replyBytes, replyBytes.size, packet.address, packet.port)
                            try {
                                ds.send(outPacket)
                            } catch (_: Exception) {
                            }
                        }
                    }
                } catch (_: Exception) {
                    delay(1500L)
                } finally {
                    try {
                        udpSocket?.close()
                    } catch (_: Exception) {
                    }
                }
            }
        }

        // 3. Активный анти-сон (ARP & Wi-Fi Radio Keep-Alive каждые 8 секунд напрямую на IP телефона и роутер):
        serverScope.launch {
            while (isActive && isRunning) {
                acquireLocks(appCtx)
                sendArpKeepAliveBurst()
                delay(8_000L)
            }
        }
    }

    private fun handleTcpClient(context: Context, client: Socket) {
        try {
            client.soTimeout = 750
            client.tcpNoDelay = true
            val reader = BufferedReader(InputStreamReader(client.getInputStream(), Charsets.UTF_8))
            val firstLine = reader.readLine().orEmpty().trim()
            if (firstLine.isEmpty()) {
                client.close()
                return
            }

            val isHttp = firstLine.startsWith("GET ") || firstLine.startsWith("POST ")
            val targetPath = if (isHttp) {
                firstLine.split(" ").getOrNull(1).orEmpty()
            } else {
                firstLine
            }

            var contentLength = 0
            if (isHttp) {
                while (true) {
                    val headerLine = reader.readLine() ?: break
                    if (headerLine.isEmpty()) break
                    if (headerLine.lowercase(Locale.US).startsWith("content-length:")) {
                        contentLength = headerLine.substringAfter(":").trim().toIntOrNull() ?: 0
                    }
                }
            }

            val bodyStr = if (contentLength in 1..4096) {
                val chars = CharArray(contentLength)
                val readCount = reader.read(chars, 0, contentLength)
                if (readCount > 0) String(chars, 0, readCount) else ""
            } else ""

            val combinedCmd = if (bodyStr.isNotEmpty() && !targetPath.contains("?")) {
                "$targetPath?$bodyStr"
            } else {
                targetPath
            }

            val responseJson = processIncomingCommand(context, combinedCmd)
            val out = client.getOutputStream()
            if (isHttp) {
                val bodyBytes = responseJson.toByteArray(Charsets.UTF_8)
                val headers = "HTTP/1.1 200 OK\r\n" +
                    "Content-Type: application/json; charset=utf-8\r\n" +
                    "Access-Control-Allow-Origin: *\r\n" +
                    "Content-Length: ${bodyBytes.size}\r\n" +
                    "Connection: close\r\n\r\n"
                out.write(headers.toByteArray(Charsets.UTF_8))
                out.write(bodyBytes)
            } else {
                out.write((responseJson + "\n").toByteArray(Charsets.UTF_8))
            }
            out.flush()
        } catch (_: Exception) {
        } finally {
            try {
                client.close()
            } catch (_: Exception) {
            }
        }
    }

    private fun parseQueryParams(rawQuery: String): Map<String, String> {
        val map = mutableMapOf<String, String>()
        for (pair in rawQuery.split("&")) {
            if (pair.isBlank()) continue
            val idx = pair.indexOf('=')
            if (idx > 0) {
                val k = pair.substring(0, idx).trim()
                val v = try {
                    URLDecoder.decode(pair.substring(idx + 1).trim(), "UTF-8")
                } catch (_: Exception) {
                    pair.substring(idx + 1).trim()
                }
                map[k] = v
            } else {
                map[pair.trim()] = ""
            }
        }
        return map
    }

    private fun isScreenInteractive(context: Context): Boolean {
        val now = System.currentTimeMillis()
        val overrideVal = forcedScreenStateOverride
        if (overrideVal != null && now < forcedScreenStateUntilMs) {
            return overrideVal
        }
        return try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            pm?.isInteractive != false
        } catch (_: Exception) {
            true
        }
    }

    private fun executeHdmiSleepOrWakeup(context: Context, sleep: Boolean) {
        acquireLocks(context)
        forcedScreenStateOverride = !sleep
        forcedScreenStateUntilMs = System.currentTimeMillis() + 2500L
        val code = if (sleep) 223 else 224
        serverScope.launch {
            ShellKeyController.sendKeyEvent(code)
            delay(300L)
            acquireLocks(context)
            sendArpKeepAliveBurst()
        }
    }

    private fun buildStatusJson(context: Context, ok: Boolean = true, action: String = "status"): String {
        val interactive = isScreenInteractive(context)
        return JSONObject().apply {
            put("ok", ok)
            put("success", ok)
            put("action", action)
            put("isReachable", true)
            put("isInteractive", interactive)
            put("screenState", if (interactive) "ON" else "SLEEP")
            put("ledOn", TuyaSmartHomeController.isLedOn(context))
            put("ledMode", TuyaSmartHomeController.getCurrentModeLabel(context))
            put("ledBright", TuyaSmartHomeController.getBrightnessPct(context))
        }.toString()
    }

    private fun processIncomingCommand(context: Context, rawCmd: String): String {
        val trimmed = rawCmd.trim()
        val path = trimmed.substringBefore("?").lowercase(Locale.US)
        val query = if (trimmed.contains("?")) trimmed.substringAfter("?") else ""
        val params = parseQueryParams(query)

        return when {
            path == "/status" || path == "/ping" || path == "/" || trimmed.equals("PING", ignoreCase = true) || trimmed.equals("STATUS", ignoreCase = true) -> {
                buildStatusJson(context, ok = true, action = "status")
            }
            path == "/sleep" || trimmed.equals("SLEEP", ignoreCase = true) -> {
                executeHdmiSleepOrWakeup(context, sleep = true)
                buildStatusJson(context, ok = true, action = "key:SLEEP")
            }
            path == "/wakeup" || path == "/wake" || trimmed.equals("WAKEUP", ignoreCase = true) || trimmed.equals("WAKE", ignoreCase = true) -> {
                executeHdmiSleepOrWakeup(context, sleep = false)
                buildStatusJson(context, ok = true, action = "key:WAKEUP")
            }
            path == "/power" || trimmed.equals("POWER", ignoreCase = true) -> {
                val targetState = (params["state"] ?: params["action"] ?: params["power"] ?: "").lowercase(Locale.US)
                val shouldSleep = when (targetState) {
                    "sleep", "off", "0", "false", "223" -> true
                    "wakeup", "wake", "on", "1", "true", "224" -> false
                    else -> isScreenInteractive(context)
                }
                executeHdmiSleepOrWakeup(context, sleep = shouldSleep)
                buildStatusJson(context, ok = true, action = if (shouldSleep) "key:SLEEP" else "key:WAKEUP")
            }
            path.startsWith("/key") || trimmed.uppercase(Locale.US).startsWith("KEY:") -> {
                val keyName = if (trimmed.uppercase(Locale.US).startsWith("KEY:")) {
                    trimmed.substringAfter(":").trim()
                } else {
                    params["k"] ?: params["key"] ?: params["code"] ?: ""
                }
                handleRemoteKeyCommand(context, keyName)
                buildStatusJson(context, ok = true, action = "key:$keyName")
            }
            path.startsWith("/app") || trimmed.uppercase(Locale.US).startsWith("APP:") -> {
                val appTarget = if (trimmed.uppercase(Locale.US).startsWith("APP:")) {
                    trimmed.substringAfter(":").trim()
                } else {
                    params["pkg"] ?: params["app"] ?: params["name"] ?: ""
                }
                handleRemoteAppLaunch(context, appTarget)
                buildStatusJson(context, ok = true, action = "app:$appTarget")
            }
            path.startsWith("/voice") || trimmed.uppercase(Locale.US).startsWith("VOICE:") -> {
                val spoken = if (trimmed.uppercase(Locale.US).startsWith("VOICE:")) {
                    trimmed.substringAfter(":").trim()
                } else {
                    params["text"] ?: params["q"] ?: params["query"] ?: ""
                }
                mainHandler.post {
                    DynamicIslandBus.triggerVoiceText(context, spoken)
                }
                buildStatusJson(context, ok = true, action = "voice")
            }
            path.startsWith("/light") || trimmed.uppercase(Locale.US).startsWith("LIGHT:") -> {
                val presetName = params["preset"] ?: params["color"] ?: params["swatch"] ?: ""
                val powerStr = params["power"] ?: params["state"] ?: params["on"] ?: ""
                val toggleStr = params["toggle"] ?: ""
                val brightStr = params["bright"] ?: params["brightness"] ?: params["b"] ?: ""
                val sceneStr = params["scene"] ?: params["mode"] ?: ""
                val hueStr = params["hue"] ?: params["h"] ?: ""

                if (toggleStr.equals("1", ignoreCase = true) || toggleStr.equals("true", ignoreCase = true) || powerStr.equals("toggle", ignoreCase = true)) {
                    TuyaSmartHomeController.togglePower(context)
                } else if (powerStr.isNotEmpty()) {
                    val turnOn = powerStr.equals("true", ignoreCase = true) || powerStr == "1" || powerStr.equals("on", ignoreCase = true)
                    TuyaSmartHomeController.setPower(context, turnOn)
                }

                if (presetName.isNotEmpty()) {
                    val p = TuyaSmartHomeController.CURATED_SWATCHES.firstOrNull {
                        it.name.equals(presetName, ignoreCase = true) ||
                            (presetName.equals("cyber", ignoreCase = true) && it.name == "Кибер") ||
                            (presetName.equals("ocean", ignoreCase = true) && it.name == "Океан") ||
                            (presetName.equals("sapphire", ignoreCase = true) && it.name == "Сапфир") ||
                            (presetName.equals("indigo", ignoreCase = true) && it.name == "Индиго") ||
                            (presetName.equals("violet", ignoreCase = true) && it.name == "Фиолет") ||
                            (presetName.equals("fuchsia", ignoreCase = true) && it.name == "Фуксия") ||
                            (presetName.equals("raspberry", ignoreCase = true) && it.name == "Малина") ||
                            (presetName.equals("sunset", ignoreCase = true) && it.name == "Закат") ||
                            (presetName.equals("amber", ignoreCase = true) && it.name == "Янтарь") ||
                            (presetName.equals("lime", ignoreCase = true) && it.name == "Лайм") ||
                            (presetName.equals("emerald", ignoreCase = true) && it.name == "Изумруд") ||
                            (presetName.equals("warm", ignoreCase = true) && it.name == "Тёплый")
                    }
                    if (p != null) {
                        TuyaSmartHomeController.applySwatchPreset(context, p)
                    } else if (presetName.startsWith("#") || presetName.length == 6) {
                        TuyaSmartHomeController.setHexColor(context, presetName)
                    }
                }

                val hVal = hueStr.toIntOrNull()
                if (hVal != null) {
                    val curHue = TuyaSmartHomeController.getHue(context)
                    TuyaSmartHomeController.stepHueByDelta(context, hVal - curHue, immediate = true)
                }

                if (sceneStr.isNotEmpty()) {
                    TuyaSmartHomeController.activateDynamicScene(context, sceneStr)
                }

                val bVal = brightStr.toIntOrNull()
                if (bVal != null) {
                    TuyaSmartHomeController.setBrightnessPercent(context, bVal)
                }

                buildStatusJson(context, ok = true, action = "light")
            }
            else -> buildStatusJson(context, ok = true, action = "noop")
        }
    }

    private fun resolveAndroidKeyCode(context: Context, rawKey: String): Int? {
        val k = rawKey.trim().uppercase(Locale.US).removePrefix("KEYCODE_")
        when (k) {
            "SLEEP", "223", "SCREEN_OFF", "HDMI_OFF" -> return 223
            "WAKEUP", "WAKE", "224", "SCREEN_ON", "HDMI_ON" -> return 224
            "POWER", "26", "TOGGLE_POWER" -> {
                return if (isScreenInteractive(context)) 223 else 224
            }
        }
        val numeric = k.toIntOrNull()
        if (numeric != null && numeric > 0) return numeric
        return when (k) {
            "UP", "DPAD_UP" -> 19
            "DOWN", "DPAD_DOWN" -> 20
            "LEFT", "DPAD_LEFT" -> 21
            "RIGHT", "DPAD_RIGHT" -> 22
            "OK", "CENTER", "DPAD_CENTER", "ENTER" -> 23
            "BACK", "ESCAPE" -> 4
            "HOME" -> 3
            "MENU", "PATCHWALL", "ALL_APPS", "SETTINGS" -> 82
            "VOL_UP", "VOLUME_UP" -> 24
            "VOL_DOWN", "VOLUME_DOWN" -> 25
            "MUTE", "VOLUME_MUTE" -> 164
            "PLAY_PAUSE", "MEDIA_PLAY_PAUSE" -> 85
            "NEXT", "MEDIA_NEXT" -> 87
            "PREV", "MEDIA_PREVIOUS" -> 88
            else -> null
        }
    }

    private fun handleRemoteKeyCommand(context: Context, rawKey: String) {
        val k = rawKey.trim().uppercase(Locale.US).removePrefix("KEYCODE_")
        if (k == "ASSIST" || k == "VOICE_ASSIST" || k == "AI" || k == "219" || k == "231") {
            mainHandler.post {
                NavSoundPlayer.playClick(context)
                DynamicIslandBus.triggerAssistant(context)
            }
            return
        }

        val androidKeyCode = resolveAndroidKeyCode(context, rawKey) ?: return

        if (androidKeyCode == 223 || androidKeyCode == 224) {
            executeHdmiSleepOrWakeup(context, sleep = (androidKeyCode == 223))
            return
        }

        mainHandler.post {
            NavSoundPlayer.playClick(context)
            when (androidKeyCode) {
                24 -> {
                    val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    am?.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0)
                    VolumeHudBus.notifyVolumeChanged()
                    return@post
                }
                25 -> {
                    val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    am?.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0)
                    VolumeHudBus.notifyVolumeChanged()
                    return@post
                }
                164 -> {
                    val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    am?.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, 0)
                    VolumeHudBus.notifyVolumeChanged()
                    return@post
                }
                85 -> {
                    val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    if (am != null) {
                        MediaStateBus.dispatchTransportAction("PLAY_PAUSE", am)
                        return@post
                    }
                }
                87 -> {
                    val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    if (am != null) {
                        MediaStateBus.dispatchTransportAction("NEXT", am)
                        return@post
                    }
                }
                88 -> {
                    val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    if (am != null) {
                        MediaStateBus.dispatchTransportAction("PREV", am)
                        return@post
                    }
                }
                82 -> {
                    val intent = Intent(context, LauncherActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        putExtra("EXTRA_OPEN_CONTROL_CENTER", true)
                    }
                    try {
                        context.startActivity(intent)
                        return@post
                    } catch (_: Exception) {
                    }
                }
            }

            if (androidKeyCode == 3) {
                DynamicIslandBus.onHomePressedInActivity?.invoke()
            }
            val handledInLauncher = if (androidKeyCode == 3) {
                false
            } else {
                DynamicIslandBus.onDispatchKeyInActivity?.invoke(androidKeyCode) == true
            }
            if (!handledInLauncher) {
                serverScope.launch {
                    ShellKeyController.sendKeyEvent(androidKeyCode)
                }
                if (androidKeyCode == 4) {
                    TvUiControllerBus.performNav("BACK")
                } else if (androidKeyCode == 3) {
                    TvUiControllerBus.performNav("HOME")
                } else {
                    val dirName = when (androidKeyCode) {
                        19 -> "UP"
                        20 -> "DOWN"
                        21 -> "LEFT"
                        22 -> "RIGHT"
                        23 -> "CENTER"
                        else -> ""
                    }
                    if (dirName.isNotEmpty()) {
                        val a11yOk = TvUiControllerBus.onInjectDpadAction?.invoke(dirName) == true
                        if (!a11yOk && dirName == "CENTER") {
                            ShellKeyController.sendKeyEvent(66)
                        }
                    }
                }
            }
        }
    }

    private fun handleRemoteAppLaunch(context: Context, rawTarget: String) {
        val t = rawTarget.trim()
        if (t.isEmpty()) return
        mainHandler.post {
            val lower = t.lowercase(Locale.US)
            val pm = context.packageManager
            val candidates = when {
                lower.contains("youtube") || lower == "yt" -> listOf(
                    "com.google.android.youtube.tv",
                    "com.liskovsoft.smarttubetv.beta",
                    "com.liskovsoft.smarttubetv",
                    "com.google.android.youtube"
                )
                lower.contains("kick") -> listOf(
                    "com.kick.mobile",
                    "com.kick.tv",
                    "tv.kick.android"
                )
                lower.contains("browser") || lower.contains("chrome") -> listOf(
                    "com.android.chrome",
                    "com.tvwebbrowser.v22",
                    "org.mozilla.tv.firefox",
                    "com.opera.browser"
                )
                else -> listOf(t)
            }

            for (pkg in candidates) {
                val intent = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg)
                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        context.startActivity(intent)
                        return@post
                    } catch (_: Exception) {
                    }
                }
            }

            if (lower.contains("browser") || lower.contains("chrome")) {
                try {
                    val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(webIntent)
                } catch (_: Exception) {
                }
            }
        }
    }
}
