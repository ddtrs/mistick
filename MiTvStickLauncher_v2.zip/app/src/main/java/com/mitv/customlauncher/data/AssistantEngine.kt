package com.mitv.customlauncher.data

import android.app.ActivityManager
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.isActive
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import android.graphics.Color
import kotlinx.coroutines.delay
import java.nio.ByteOrder
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import kotlin.math.sqrt
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.util.Log
import android.view.KeyEvent
import com.mitv.customlauncher.service.DynamicIslandBus
import com.mitv.customlauncher.service.TvUiControllerBus
import com.mitv.customlauncher.service.MediaStateBus
import com.mitv.customlauncher.service.NavSoundPlayer
import com.mitv.customlauncher.service.VolumeHudBus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

sealed interface AssistantState {
    data object Idle : AssistantState
    data object Listening : AssistantState
    data object Processing : AssistantState
    data class Result(val text: String) : AssistantState
    data class Error(val code: String) : AssistantState
}

interface AssistantEngine {
    val state: StateFlow<AssistantState>
    fun startSession()
    fun cancelSession()
}

class FakeAssistantEngine(
    private val scope: CoroutineScope,
    private val demoReplyText: String
) : AssistantEngine {
    private val _state = MutableStateFlow<AssistantState>(AssistantState.Idle)
    override val state: StateFlow<AssistantState> = _state.asStateFlow()
    override fun startSession() {}
    override fun cancelSession() {
        _state.value = AssistantState.Idle
    }
}

/**
 * Исполнитель глубоких действий Android TV, вызываемых напрямую ИИ Gemini:
 * - запуск треков и артистов в Spotify (MEDIA_PLAY_FROM_SEARCH + spotify:search + авто-PLAY)
 * - запуск стримов на Kick (kalatay3 и любые другие каналы)
 * - смена цвета лаунчера/ползунка/островка на любой HEX-цвет
 * - управление громкостью, плеером, памятью, приложениями и звуком щелчков пульта
 */
object LocalVoiceCommandRouter {

    data class LocalActionResult(
        val confirmationText: String,
        val isQuickCommand: Boolean = true
    )

    var onThemeColorChanged: ((String) -> Unit)? = null
    var onVolumeChangedCallback: (() -> Unit)? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    /**
     * В v3.8 100% всех голосовых запросов обрабатываются напрямую через Gemini,
     * чтобы идеально понимать украинский, русский, суржик и английский без жёстких шаблонов!
     */
    fun tryExecuteLocalCommand(context: Context, rawText: String): LocalActionResult? {
        return null
    }

    fun executeSystemAudioCommand(context: Context, actionType: String) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val curVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val curPct = ((curVol * 100f) / maxVol).toInt().coerceIn(0, 100)

        when (actionType) {
            "VOL_UP" -> {
                val newPct = (curPct + 15).coerceAtMost(100)
                val targetVol = ((newPct * maxVol) / 100f + 0.5f).toInt().coerceIn((curVol + 1).coerceAtMost(maxVol), maxVol)
                try {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
                } catch (_: Exception) {
                }
                mainHandler.post {
                    onVolumeChangedCallback?.invoke()
                    VolumeHudBus.notifyVolumeChanged()
                }
            }
            "VOL_DOWN" -> {
                val newPct = (curPct - 15).coerceAtLeast(0)
                val targetVol = ((newPct * maxVol) / 100f).toInt().coerceIn(0, (curVol - 1).coerceAtLeast(0))
                try {
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
                } catch (_: Exception) {
                }
                mainHandler.post {
                    onVolumeChangedCallback?.invoke()
                    VolumeHudBus.notifyVolumeChanged()
                }
            }
            "MUTE" -> {
                try {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
                } catch (_: Exception) {
                }
                mainHandler.post {
                    onVolumeChangedCallback?.invoke()
                    VolumeHudBus.notifyVolumeChanged()
                }
            }
            "UNMUTE" -> {
                try {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
                } catch (_: Exception) {
                }
                mainHandler.post {
                    onVolumeChangedCallback?.invoke()
                    VolumeHudBus.notifyVolumeChanged()
                }
            }
            "PAUSE", "PLAY" -> MediaStateBus.dispatchTransportAction("PLAY_PAUSE", am)
            "NEXT" -> MediaStateBus.dispatchTransportAction("NEXT", am)
            "PREV" -> MediaStateBus.dispatchTransportAction("PREV", am)
        }
    }

    fun applyThemeColorEverywhere(context: Context, hex: String) {
        val cleanHex = if (hex.startsWith("#")) hex else "#$hex"
        try {
            android.graphics.Color.parseColor(cleanHex)
        } catch (_: Exception) {
            return
        }
        AppLauncher(context.applicationContext).saveAccentColorHex(cleanHex)
        mainHandler.post {
            onThemeColorChanged?.invoke(cleanHex)
            DynamicIslandBus.notifyAccentColorChanged(cleanHex)
        }
    }

    fun setVolumePercent(context: Context, targetPct: Int) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val clamped = targetPct.coerceIn(0, 100)
        val targetVol = ((clamped * maxVol) / 100f + 0.5f).toInt().coerceIn(0, maxVol)
        try {
            if (clamped > 0) {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
            }
            am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
        } catch (_: Exception) {
        }
        mainHandler.post {
            onVolumeChangedCallback?.invoke()
            VolumeHudBus.notifyVolumeChanged()
        }
    }

    fun launchKickStream(context: Context, channelSlug: String) {
        val cleanSlug = channelSlug.trim().removePrefix("https://kick.com/").removePrefix("kick.com/").trim('/')
        val url = if (cleanSlug.isNotEmpty()) "https://kick.com/$cleanSlug" else "https://kick.com"
        val appLauncher = AppLauncher(context.applicationContext)
        val pm = context.packageManager
        val allApps = appLauncher.getInstalledApps()

        val kickApp = allApps.firstOrNull {
            val p = it.packageName.lowercase()
            val l = it.label.lowercase()
            p.contains("kick") || l == "kick" || l.startsWith("kick:") || l.startsWith("kick ")
        }

        if (kickApp != null) {
            val pkg = kickApp.packageName
            // 1. Проверяем, поддерживает ли установленная версия Kick прямые ссылки (на телефоне — да, на Android TV — нет)
            val candidateUris = listOf(
                Uri.parse(url),
                Uri.parse("kick://channel/$cleanSlug"),
                Uri.parse("kick://$cleanSlug")
            )
            for (u in candidateUris) {
                try {
                    val deepIntent = Intent(Intent.ACTION_VIEW, u).apply {
                        setPackage(pkg)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    @Suppress("DEPRECATION")
                    if (pm.queryIntentActivities(deepIntent, 0).isNotEmpty()) {
                        context.startActivity(deepIntent)
                        return
                    }
                } catch (_: Exception) {
                }
            }

            // 2. Проверяем поддержку системного ACTION_SEARCH внутри Kick
            if (cleanSlug.isNotEmpty()) {
                try {
                    val searchIntent = Intent(Intent.ACTION_SEARCH).apply {
                        setPackage(pkg)
                        putExtra(SearchManager.QUERY, cleanSlug)
                        putExtra("query", cleanSlug)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    @Suppress("DEPRECATION")
                    if (pm.queryIntentActivities(searchIntent, 0).isNotEmpty()) {
                        context.startActivity(searchIntent)
                        return
                    }
                } catch (_: Exception) {
                }
            }

            // 3. ТВ-версия Kick («Kick: стриминг в прямом эфире»): запускаем само приложение Kick без белого окна ошибки
            // и включаем ИИ-автопоиск стримера через наш AccessibilityService!
            if (appLauncher.launchPackage(pkg)) {
                if (cleanSlug.isNotEmpty()) {
                    TvUiControllerBus.scheduleInAppSearch(pkg, cleanSlug)
                }
                return
            }
        }

        launchUrlInTvBrowser(context, url)
    }

    fun launchUrlInTvBrowser(context: Context, url: String) {
        val finalUrl = if (url.startsWith("http://") || url.startsWith("https://")) url else "https://$url"
        val uri = Uri.parse(finalUrl)
        val appLauncher = AppLauncher(context.applicationContext)
        val pm = context.packageManager
        val allApps = appLauncher.getInstalledApps()

        val browserCandidate = allApps.firstOrNull {
            val p = it.packageName.lowercase()
            val l = it.label.lowercase()
            p.contains("browser") || p.contains("chrome") || p.contains("tvbro") ||
                p.contains("puffin") || p.contains("firefox") || p.contains("opera") ||
                l.contains("браузер") || l.contains("browser")
        }

        if (browserCandidate != null) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                    setPackage(browserCandidate.packageName)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return
            } catch (_: Exception) {
            }
        }

        try {
            val generic = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            @Suppress("DEPRECATION")
            val handlers = pm.queryIntentActivities(generic, 0).filter {
                !it.activityInfo.packageName.lowercase().contains("tv.fw.browsable") &&
                    !it.activityInfo.name.lowercase().contains("stub")
            }
            if (handlers.isNotEmpty()) {
                context.startActivity(generic)
            }
        } catch (_: Exception) {
        }
    }

    fun launchSpotifyTrackOrArtist(context: Context, rawQuery: String) {
        val query = rawQuery.trim()
        if (query.isEmpty()) return
        val appLauncher = AppLauncher(context.applicationContext)
        val allApps = appLauncher.getInstalledApps()
        val spotifyApp = allApps.firstOrNull {
            val p = it.packageName.lowercase()
            p.contains("spotify") || it.label.lowercase().contains("spotify")
        }
        val spotifyPkg = spotifyApp?.packageName

        if (spotifyPkg != null) {
            MediaStateBus.seedTrackFromQuery(context, spotifyPkg, query)

            try {
                val playIntent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
                    setPackage(spotifyPkg)
                    putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                    putExtra(SearchManager.QUERY, query)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                context.startActivity(playIntent)
                scheduleSpotifyAutoPlayKick(context)
                return
            } catch (_: Exception) {
            }

            try {
                val uriIntent = Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:${Uri.encode(query)}")).apply {
                    setPackage(spotifyPkg)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                context.startActivity(uriIntent)
                scheduleSpotifyAutoPlayKick(context)
                return
            } catch (_: Exception) {
            }

            try {
                val searchIntent = Intent(Intent.ACTION_SEARCH).apply {
                    setPackage(spotifyPkg)
                    putExtra(SearchManager.QUERY, query)
                    putExtra("query", query)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                context.startActivity(searchIntent)
                scheduleSpotifyAutoPlayKick(context)
                return
            } catch (_: Exception) {
            }

            appLauncher.launchPackage(spotifyPkg)
            scheduleSpotifyAutoPlayKick(context)
            return
        }

        launchYouTubeSearch(context, query)
    }

    private fun scheduleSpotifyAutoPlayKick(context: Context) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        mainHandler.postDelayed({
            try {
                val now = SystemClock.uptimeMillis()
                val down = KeyEvent(now, now, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY, 0)
                val up = KeyEvent(now, now, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY, 0)
                am.dispatchMediaKeyEvent(down)
                am.dispatchMediaKeyEvent(up)
            } catch (_: Exception) {
            }
        }, 2000L)
    }

    fun launchYouTubeSearch(context: Context, query: String) {
        val appLauncher = AppLauncher(context.applicationContext)
        val apps = appLauncher.getInstalledApps()
        val ytApp = apps.firstOrNull {
            val p = it.packageName.lowercase()
            p.contains("youtube.tv") || p.contains("smarttube") || p.contains("youtube")
        }
        try {
            val searchIntent = Intent(Intent.ACTION_SEARCH).apply {
                if (ytApp != null) setPackage(ytApp.packageName)
                putExtra(SearchManager.QUERY, query)
                putExtra("query", query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(searchIntent)
            return
        } catch (_: Exception) {
        }
        try {
            val webUri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query))
            val viewIntent = Intent(Intent.ACTION_VIEW, webUri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(viewIntent)
        } catch (_: Exception) {
        }
    }

    fun openSystemSettingsAction(context: Context, action: String) {
        try {
            val intent = Intent(action).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            try {
                val fallback = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(fallback)
            } catch (_: Exception) {
            }
        }
    }

    fun cleanRamBackground(context: Context) {
        try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return
            val apps = AppLauncher(context.applicationContext).getInstalledApps()
            for (app in apps) {
                val p = app.packageName.lowercase()
                if (app.packageName != context.packageName &&
                    !p.contains("spotify") &&
                    !p.contains("mediashell") &&
                    !p.contains("soundcloud")
                ) {
                    am.killBackgroundProcesses(app.packageName)
                }
            }
        } catch (_: Exception) {
        }
    }
}

/**
 * 100% Gemini-ассистент (2.5 & 3.8):
 * - Слушает живой голос напрямую в формате WAV (идеально понимает украинский, русский, суржик и английский!)
 * - Использует рабочий ключ XOR_PROTECTED_KEY (без ошибки 401!)
 * - Сам управляет Spotify, Kick, YouTube, цветами лаунчера, приложениями и звуком ТВ
 */
/**
 * Голосовой синтезатор речи ассистента (TTS) с мгновенным откликом,
 * автоопределением украинского/русского/английского языка и приглушением фоновой музыки (Audio Ducking).
 */
/**
 * Облачный голосовой синтезатор речи Gemini TTS (gemini-2.5-flash-preview-tts):
 * - 0 МБ фонового потребления ОЗУ (работает без системного com.google.android.tts напрямую через легковесный AudioTrack)
 * - 5 живых нейронных голосов на выбор: Puck, Charon, Fenrir (мужские) и Kore, Aoede (женские)
 * - Вычисляет реальную амплитуду звуковой волны (currentVoiceWaveLevel) каждые 40 мс для 60 FPS анимации полосок Dynamic Island
 */
/**
 * Контроллер умной Wi-Fi LED-ленты Tuya Smart Life (OpenAPI v2.0 HMAC-SHA256):
 * - 360° полный цветовой спектр HSV (Оттенок 0..360°, Насыщенность 10..100%, Яркость 10..100%)
 * - Автоопределение поддерживаемых датапоинтов ленты (v2 `colour_data_v2` / `bright_value_v2` и v1 `colour_data` / `bright_value`)
 * - 12 выверенных студийных пресетов оттенков + режим тёплого белого света
 * - 4 динамических режима (Радуга, Дыхание, Вечеринка, Ночник)
 * - Режим синхронизации с акцентным цветом темы лаунчера (Ambilight)
 */
data class LedSwatchPreset(
    val name: String,
    val hexColor: String,
    val hue: Int,
    val satPct: Int,
    val brightPct: Int = 100,
    val isWarmWhite: Boolean = false
)

object TuyaSmartHomeController {

    private const val TAG = "TuyaLauncher"
    private const val PREF_LED_IS_ON = "pref_tuya_led_is_on"
    private const val PREF_LED_HUE = "pref_tuya_led_hue"
    private const val PREF_LED_SAT = "pref_tuya_led_sat"
    private const val PREF_LED_BRIGHT = "pref_tuya_led_bright"
    private const val PREF_LED_SYNC_THEME = "pref_tuya_led_sync_theme"
    private const val PREF_LED_MODE_LABEL = "pref_tuya_led_mode_label"
    private const val PREF_WINNING_COLOR_FMT = "pref_tuya_winning_color_fmt_v54"
    private const val PREF_WINNING_CMD_PATH = "pref_tuya_winning_cmd_path_v54"
    private const val PREF_DISCOVERED_SWITCH_CODE = "pref_tuya_switch_code_v54"

    private val apiHosts = listOf(
        "https://openapi.tuyaeu.com",
        "https://openapi-weaz.tuyaeu.com"
    )

    val CURATED_SWATCHES: List<LedSwatchPreset> = listOf(
        // Ряд 1: Неон и киберпанк (выверенные углы круга Tuya Smart Life)
        LedSwatchPreset("Кибер", "#00F0FF", hue = 182, satPct = 100),
        LedSwatchPreset("Океан", "#38BDF8", hue = 200, satPct = 98),
        LedSwatchPreset("Сапфир", "#3B82F6", hue = 224, satPct = 100),
        LedSwatchPreset("Индиго", "#818CF8", hue = 248, satPct = 94),
        LedSwatchPreset("Фиолет", "#C084FC", hue = 282, satPct = 95),
        LedSwatchPreset("Фуксия", "#F472B6", hue = 324, satPct = 95),
        // Ряд 2: Уют, природа и кино
        LedSwatchPreset("Малина", "#FB7185", hue = 350, satPct = 96),
        LedSwatchPreset("Закат", "#FB923C", hue = 20, satPct = 100),
        LedSwatchPreset("Янтарь", "#FBBF24", hue = 38, satPct = 100),
        LedSwatchPreset("Лайм", "#A3E635", hue = 85, satPct = 95),
        LedSwatchPreset("Изумруд", "#34D399", hue = 145, satPct = 96),
        LedSwatchPreset("Тёплый", "#FDE68A", hue = 34, satPct = 28, isWarmWhite = true)
    )

    private sealed class PendingLedAction {
        data class Power(val turnOn: Boolean) : PendingLedAction()
        data class ColorHsv(val hue: Int, val satPct: Int, val brightPct: Int) : PendingLedAction()
    }

    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val tokenLock = Any()
    private val queueLock = Any()

    @Volatile
    private var cachedHost: String = "https://openapi.tuyaeu.com"

    @Volatile
    private var cachedAccessToken: String = ""

    @Volatile
    private var tokenExpiresAtWallMs: Long = 0L

    @Volatile
    private var serverTimeOffsetMs: Long = 0L

    @Volatile
    private var discoveredSwitchCode: String = "switch_led"

    @Volatile
    private var discoveredColorCode: String = "colour_data"

    @Volatile
    private var winningColorFormatIdx: Int = -1

    @Volatile
    private var winningCommandPath: String = ""

    @Volatile
    private var prefsLoadedIntoRam: Boolean = false

    @Volatile
    private var pendingAction: PendingLedAction? = null

    @Volatile
    private var isQueueWorkerRunning: Boolean = false

    @Volatile
    private var effectCycleJob: Job? = null

    @Volatile
    private var warmupStarted: Boolean = false

    @Volatile
    private var lastUserCommandWallMs: Long = 0L

    @Volatile
    var onStateUpdatedUiCallback: (() -> Unit)? = null

    private fun notifyUi() {
        mainHandler.post {
            onStateUpdatedUiCallback?.invoke()
        }
    }

    private fun loadCachedRoutingPrefsIfNeeded(context: Context) {
        if (prefsLoadedIntoRam) return
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val savedFmt = prefs.getInt(PREF_WINNING_COLOR_FMT, -1)
        val savedPath = prefs.getString(PREF_WINNING_CMD_PATH, "").orEmpty()
        val savedSw = prefs.getString(PREF_DISCOVERED_SWITCH_CODE, "").orEmpty()
        if (savedFmt >= 0) winningColorFormatIdx = savedFmt
        if (savedPath.isNotEmpty()) winningCommandPath = savedPath
        if (savedSw.isNotEmpty()) discoveredSwitchCode = savedSw
        prefsLoadedIntoRam = true
    }

    private fun persistWinningRoute(
        context: Context?,
        colorFmtIdx: Int? = null,
        cmdPath: String? = null,
        switchCode: String? = null
    ) {
        if (colorFmtIdx != null && colorFmtIdx >= 0) winningColorFormatIdx = colorFmtIdx
        if (!cmdPath.isNullOrEmpty()) winningCommandPath = cmdPath
        if (!switchCode.isNullOrEmpty()) discoveredSwitchCode = switchCode
        if (context != null) {
            val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            val ed = prefs.edit()
            if (colorFmtIdx != null && colorFmtIdx >= 0) ed.putInt(PREF_WINNING_COLOR_FMT, colorFmtIdx)
            if (!cmdPath.isNullOrEmpty()) ed.putString(PREF_WINNING_CMD_PATH, cmdPath)
            if (!switchCode.isNullOrEmpty()) ed.putString(PREF_DISCOVERED_SWITCH_CODE, switchCode)
            ed.apply()
        }
    }

    /**
     * Фоновый прогрев токена Tuya и статуса устройства:
     * держит свежий access_token и открытую TLS-сессию наготове.
     */
    fun ensureWarmupStarted() {
        if (warmupStarted) return
        warmupStarted = true
        ioScope.launch {
            try {
                ensureAccessToken(forceRefresh = false)
                inspectDeviceStatus(null)
            } catch (_: Exception) {
            }
            while (isActive) {
                delay(10 * 60 * 1000L)
                try {
                    val now = System.currentTimeMillis()
                    if (cachedAccessToken.isEmpty() || now > tokenExpiresAtWallMs - 300_000L) {
                        ensureAccessToken(forceRefresh = false)
                    }
                } catch (_: Exception) {
                }
            }
        }
    }

    fun isLedOn(context: Context): Boolean {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(PREF_LED_IS_ON, true)
    }

    fun getHue(context: Context): Int {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(PREF_LED_HUE, 182).coerceIn(0, 360)
    }

    fun getSaturationPct(context: Context): Int {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(PREF_LED_SAT, 100).coerceIn(10, 100)
    }

    fun getBrightnessPct(context: Context): Int {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(PREF_LED_BRIGHT, 100).coerceIn(10, 100)
    }

    fun isThemeSyncEnabled(context: Context): Boolean {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(PREF_LED_SYNC_THEME, false)
    }

    fun getCurrentModeLabel(context: Context): String {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(PREF_LED_MODE_LABEL, "")?.takeIf { it.isNotBlank() } ?: describeHueName(getHue(context))
    }

    fun findActiveSwatchIndex(context: Context): Int {
        val mode = getCurrentModeLabel(context)
        if (mode.startsWith("Режим:")) return -1
        val byName = CURATED_SWATCHES.indexOfFirst { it.name.equals(mode, ignoreCase = true) }
        if (byName >= 0) return byName
        val h = getHue(context)
        val s = getSaturationPct(context)
        if (s <= 42 && h in 20..52) {
            return CURATED_SWATCHES.indexOfFirst { it.isWarmWhite }
        }
        var bestIdx = -1
        var bestDist = 999
        for (i in CURATED_SWATCHES.indices) {
            val p = CURATED_SWATCHES[i]
            if (p.isWarmWhite) continue
            val rawDiff = kotlin.math.abs(h - p.hue)
            val dist = kotlin.math.min(rawDiff, 360 - rawDiff)
            if (dist <= 9 && dist < bestDist) {
                bestDist = dist
                bestIdx = i
            }
        }
        return bestIdx
    }

    fun getCurrentPreviewColorInt(context: Context): Int {
        val idx = findActiveSwatchIndex(context)
        if (idx in CURATED_SWATCHES.indices) {
            return try {
                Color.parseColor(CURATED_SWATCHES[idx].hexColor)
            } catch (_: Exception) {
                Color.parseColor("#00F0FF")
            }
        }
        val h = getHue(context).toFloat()
        val s = (getSaturationPct(context) / 100f).coerceIn(0.25f, 1f)
        return Color.HSVToColor(floatArrayOf(h, s, 0.96f))
    }

    fun describeHueName(hue: Int): String {
        val h = ((hue % 360) + 360) % 360
        return when (h) {
            in 0..12 -> "Алый"
            in 13..28 -> "Закат"
            in 29..48 -> "Янтарь"
            in 49..68 -> "Золото"
            in 69..105 -> "Лайм"
            in 106..158 -> "Изумруд"
            in 159..174 -> "Мята"
            in 175..194 -> "Кибер"
            in 195..214 -> "Океан"
            in 215..236 -> "Сапфир"
            in 237..264 -> "Индиго"
            in 265..298 -> "Фиолет"
            in 299..338 -> "Фуксия"
            else -> "Малина"
        }
    }

    private fun saveState(
        context: Context,
        isOn: Boolean? = null,
        hue: Int? = null,
        satPct: Int? = null,
        brightPct: Int? = null,
        syncTheme: Boolean? = null,
        modeLabel: String? = null
    ) {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val ed = prefs.edit()
        if (isOn != null) ed.putBoolean(PREF_LED_IS_ON, isOn)
        if (hue != null) ed.putInt(PREF_LED_HUE, ((hue % 360) + 360) % 360)
        if (satPct != null) ed.putInt(PREF_LED_SAT, satPct.coerceIn(10, 100))
        if (brightPct != null) ed.putInt(PREF_LED_BRIGHT, brightPct.coerceIn(10, 100))
        if (syncTheme != null) ed.putBoolean(PREF_LED_SYNC_THEME, syncTheme)
        if (modeLabel != null) ed.putString(PREF_LED_MODE_LABEL, modeLabel)
        ed.apply()
        notifyUi()
    }

    /**
     * Однопоточный неблокирующий диспетчер последней команды:
     * - Никогда не обрывает активный TLS-сокет посреди запроса (никаких InterruptedIOException и сбоев пула)
     * - Если пользователь быстро нажимает несколько цветов подряд, промежуточные клики схлопываются,
     *   и сразу после завершения текущего запроса (< 100 мс) отправляется самый последний выбранный цвет!
     */
    private fun enqueueLatestAction(context: Context, action: PendingLedAction) {
        val appCtx = context.applicationContext
        loadCachedRoutingPrefsIfNeeded(appCtx)
        lastUserCommandWallMs = System.currentTimeMillis()
        var shouldLaunchWorker = false
        synchronized(queueLock) {
            pendingAction = action
            if (!isQueueWorkerRunning) {
                isQueueWorkerRunning = true
                shouldLaunchWorker = true
            }
        }
        if (shouldLaunchWorker) {
            ioScope.launch {
                try {
                    while (true) {
                        val next = synchronized(queueLock) {
                            val a = pendingAction
                            pendingAction = null
                            if (a == null) {
                                isQueueWorkerRunning = false
                            }
                            a
                        } ?: break

                        when (next) {
                            is PendingLedAction.Power -> {
                                sendSwitchCommandWithRetry(appCtx, next.turnOn)
                            }
                            is PendingLedAction.ColorHsv -> {
                                sendHsvColorCommandWithRetry(appCtx, next.hue, next.satPct, next.brightPct)
                            }
                        }
                    }
                } finally {
                    synchronized(queueLock) {
                        isQueueWorkerRunning = false
                    }
                }
            }
        }
    }

    fun setThemeSyncEnabled(context: Context, enabled: Boolean, currentThemeHex: String? = null) {
        saveState(context, syncTheme = enabled)
        if (enabled && !currentThemeHex.isNullOrBlank()) {
            setHexColor(context, currentThemeHex, modeTitle = "Синхр. с темой")
        }
    }

    fun syncWithLauncherThemeIfNeeded(context: Context, hexColor: String) {
        if (isThemeSyncEnabled(context)) {
            setHexColor(context, hexColor, modeTitle = "Синхр. с темой")
        }
    }

    fun togglePower(context: Context): Boolean {
        val target = !isLedOn(context)
        setPower(context, target)
        return target
    }

    fun setPower(context: Context, turnOn: Boolean) {
        val appCtx = context.applicationContext
        effectCycleJob?.cancel()
        effectCycleJob = null
        saveState(appCtx, isOn = turnOn)
        enqueueLatestAction(appCtx, PendingLedAction.Power(turnOn))
    }

    fun stepHueByDelta(context: Context, deltaDeg: Int, immediate: Boolean = false) {
        val appCtx = context.applicationContext
        effectCycleJob?.cancel()
        effectCycleJob = null
        val nextHue = (((getHue(appCtx) + deltaDeg) % 360) + 360) % 360
        val sat = getSaturationPct(appCtx).coerceAtLeast(85)
        val bright = getBrightnessPct(appCtx)
        saveState(appCtx, isOn = true, hue = nextHue, satPct = sat, modeLabel = describeHueName(nextHue))
        enqueueLatestAction(appCtx, PendingLedAction.ColorHsv(nextHue, sat, bright))
    }

    fun stepBrightnessByDelta(context: Context, deltaPct: Int) {
        val appCtx = context.applicationContext
        val nextBright = (getBrightnessPct(appCtx) + deltaPct).coerceIn(10, 100)
        val hue = getHue(appCtx)
        val sat = getSaturationPct(appCtx)
        saveState(appCtx, isOn = true, brightPct = nextBright)
        enqueueLatestAction(appCtx, PendingLedAction.ColorHsv(hue, sat, nextBright))
    }

    fun cycleBrightnessPreset(context: Context): Int {
        val cur = getBrightnessPct(context)
        val next = when {
            cur < 25 -> 25
            cur < 50 -> 50
            cur < 75 -> 75
            cur < 100 -> 100
            else -> 25
        }
        setBrightnessPercent(context, next)
        return next
    }

    fun setBrightnessPercent(context: Context, pct: Int) {
        val appCtx = context.applicationContext
        val cleanPct = pct.coerceIn(5, 100)
        val hue = getHue(appCtx)
        val sat = getSaturationPct(appCtx)
        saveState(appCtx, isOn = true, brightPct = cleanPct)
        enqueueLatestAction(appCtx, PendingLedAction.ColorHsv(hue, sat, cleanPct))
    }

    fun stepSaturationByDelta(context: Context, deltaPct: Int) {
        val appCtx = context.applicationContext
        effectCycleJob?.cancel()
        effectCycleJob = null
        val nextSat = (getSaturationPct(appCtx) + deltaPct).coerceIn(15, 100)
        val hue = getHue(appCtx)
        val bright = getBrightnessPct(appCtx)
        saveState(appCtx, isOn = true, satPct = nextSat)
        enqueueLatestAction(appCtx, PendingLedAction.ColorHsv(hue, nextSat, bright))
    }

    fun cycleSaturationPreset(context: Context): Int {
        val cur = getSaturationPct(context)
        val next = when {
            cur < 45 -> 60
            cur < 80 -> 100
            else -> 30
        }
        val appCtx = context.applicationContext
        val hue = getHue(appCtx)
        val bright = getBrightnessPct(appCtx)
        saveState(appCtx, isOn = true, satPct = next)
        enqueueLatestAction(appCtx, PendingLedAction.ColorHsv(hue, next, bright))
        return next
    }

    fun applySwatchPreset(context: Context, preset: LedSwatchPreset) {
        val appCtx = context.applicationContext
        effectCycleJob?.cancel()
        effectCycleJob = null
        val bright = getBrightnessPct(appCtx).coerceAtLeast(25)
        saveState(
            appCtx,
            isOn = true,
            hue = preset.hue,
            satPct = preset.satPct,
            brightPct = bright,
            modeLabel = preset.name
        )
        enqueueLatestAction(appCtx, PendingLedAction.ColorHsv(preset.hue, preset.satPct, bright))
    }

    fun setHexColor(context: Context, rawHex: String, modeTitle: String? = null) {
        val appCtx = context.applicationContext
        effectCycleJob?.cancel()
        effectCycleJob = null
        val cleanHex = if (rawHex.trim().startsWith("#")) rawHex.trim() else "#${rawHex.trim()}"
        val parsedColor = try {
            Color.parseColor(cleanHex)
        } catch (_: Exception) {
            Color.parseColor("#00F0FF")
        }
        val hsv = FloatArray(3)
        Color.colorToHSV(parsedColor, hsv)
        val h = hsv[0].toInt().coerceIn(0, 360)
        val s = (hsv[1] * 100f).toInt().coerceIn(15, 100)
        val b = getBrightnessPct(appCtx).coerceAtLeast(30)
        val label = modeTitle ?: describeHueName(h)
        saveState(appCtx, isOn = true, hue = h, satPct = s, brightPct = b, modeLabel = label)
        enqueueLatestAction(appCtx, PendingLedAction.ColorHsv(h, s, b))
    }

    fun activateDynamicScene(context: Context, sceneCode: String) {
        val appCtx = context.applicationContext
        loadCachedRoutingPrefsIfNeeded(appCtx)
        lastUserCommandWallMs = System.currentTimeMillis()
        effectCycleJob?.cancel()
        effectCycleJob = null

        val upper = sceneCode.trim().uppercase(Locale.US)
        when {
            upper.contains("NIGHT") || upper.contains("НОЧ") -> {
                saveState(appCtx, isOn = true, hue = 30, satPct = 85, brightPct = 15, modeLabel = "Режим: Ночник")
                enqueueLatestAction(appCtx, PendingLedAction.ColorHsv(30, 85, 15))
            }
            upper.contains("BREATH") || upper.contains("ДЫХ") -> {
                saveState(appCtx, isOn = true, modeLabel = "Режим: Дыхание")
                startSoftwareSceneLoop(appCtx, "BREATHE")
            }
            upper.contains("PARTY") || upper.contains("ВЕЧЕР") -> {
                saveState(appCtx, isOn = true, modeLabel = "Режим: Вечеринка")
                startSoftwareSceneLoop(appCtx, "PARTY")
            }
            else -> {
                saveState(appCtx, isOn = true, modeLabel = "Режим: Радуга")
                startSoftwareSceneLoop(appCtx, "RAINBOW")
            }
        }
    }

    private fun startSoftwareSceneLoop(context: Context, mode: String) {
        effectCycleJob?.cancel()
        effectCycleJob = ioScope.launch {
            var step = 0
            while (isActive && isLedOn(context)) {
                when (mode) {
                    "BREATHE" -> {
                        val h = getHue(context)
                        val b = if (step % 2 == 0) 95 else 22
                        enqueueLatestAction(context, PendingLedAction.ColorHsv(h, 95, b))
                        delay(2400L)
                    }
                    "PARTY" -> {
                        val partyHues = intArrayOf(182, 324, 282, 145, 20, 224)
                        val h = partyHues[step % partyHues.size]
                        enqueueLatestAction(context, PendingLedAction.ColorHsv(h, 100, 100))
                        delay(1400L)
                    }
                    else -> {
                        val h = (step * 36) % 360
                        enqueueLatestAction(context, PendingLedAction.ColorHsv(h, 100, 95))
                        delay(2000L)
                    }
                }
                step++
            }
        }
    }

    fun refreshStatusFromCloudAsync(context: Context) {
        val appCtx = context.applicationContext
        loadCachedRoutingPrefsIfNeeded(appCtx)
        ensureWarmupStarted()
        ioScope.launch {
            inspectDeviceStatus(appCtx)
        }
    }

    private suspend fun inspectDeviceStatus(context: Context?) {
        val devId = LauncherConfig.TUYA_LED_DEVICE_ID
        val paths = listOf(
            "/v1.0/iot-03/devices/$devId/status",
            "/v1.0/devices/$devId/status"
        )
        for (path in paths) {
            val resp = executeSignedTuyaRequest("GET", path, "") ?: continue
            if (resp.optBoolean("success", false)) {
                val arr = resp.optJSONArray("result") ?: continue
                var foundSwitch: Boolean? = null
                var foundHue: Int? = null
                var foundSatPct: Int? = null
                var foundBrightPct: Int? = null
                for (i in 0 until arr.length()) {
                    val item = arr.optJSONObject(i) ?: continue
                    val code = item.optString("code", "")
                    val rawVal = item.opt("value")
                    when {
                        code == "switch_led" || code == "led_switch" || code == "switch_1" || code == "switch" -> {
                            discoveredSwitchCode = code
                            persistWinningRoute(context, switchCode = code)
                            if (rawVal is Boolean) foundSwitch = rawVal
                        }
                        code == "colour_data" || code == "colour_data_v2" -> {
                            discoveredColorCode = code
                            val strVal = rawVal?.toString().orEmpty().trim()
                            if (strVal.length == 12 && strVal.all { it.isDigit() || it.lowercaseChar() in 'a'..'f' }) {
                                if (winningColorFormatIdx < 0) {
                                    // Если в статусе лента отдаёт нижний регистр — выбираем формат 0 (hexLower без work_mode)
                                    val hasLowerHex = strVal.any { it in 'a'..'f' }
                                    persistWinningRoute(context, colorFmtIdx = if (hasLowerHex) 0 else 1)
                                }
                                try {
                                    val h = strVal.substring(0, 4).toInt(16).coerceIn(0, 360)
                                    val sRaw = strVal.substring(4, 8).toInt(16)
                                    val vRaw = strVal.substring(8, 12).toInt(16)
                                    val sPct = (sRaw / 10).coerceIn(10, 100)
                                    val vPct = (vRaw / 10).coerceIn(10, 100)
                                    foundHue = h
                                    foundSatPct = sPct
                                    foundBrightPct = vPct
                                } catch (_: Exception) {
                                }
                            } else if (strVal.firstOrNull()?.code == 123) {
                                if (winningColorFormatIdx < 0) {
                                    persistWinningRoute(context, colorFmtIdx = if (code == "colour_data_v2") 3 else 2)
                                }
                                try {
                                    val j = JSONObject(strVal)
                                    val h = j.optInt("h", -1)
                                    val sRaw = j.optInt("s", -1)
                                    val vRaw = j.optInt("v", -1)
                                    if (h in 0..360) foundHue = h
                                    if (sRaw >= 0) foundSatPct = (if (code.endsWith("_v2") || sRaw > 255) sRaw / 10 else (sRaw * 100) / 255).coerceIn(10, 100)
                                    if (vRaw >= 0) foundBrightPct = (if (code.endsWith("_v2") || vRaw > 255) vRaw / 10 else (vRaw * 100) / 255).coerceIn(10, 100)
                                } catch (_: Exception) {
                                }
                            }
                        }
                    }
                }
                // Не перезаписываем локальный выбор пользователя, если он недавно нажимал кнопки!
                val sinceUserClickMs = System.currentTimeMillis() - lastUserCommandWallMs
                if (context != null && sinceUserClickMs > 10_000L) {
                    val matchedLabel = if (foundHue != null) {
                        val sVal = foundSatPct ?: getSaturationPct(context)
                        if (sVal <= 42 && foundHue in 20..52) {
                            "Тёплый"
                        } else {
                            val presetMatch = CURATED_SWATCHES.firstOrNull { p ->
                                !p.isWarmWhite && kotlin.math.min(kotlin.math.abs(foundHue - p.hue), 360 - kotlin.math.abs(foundHue - p.hue)) <= 8
                            }
                            presetMatch?.name ?: describeHueName(foundHue)
                        }
                    } else null
                    saveState(
                        context,
                        isOn = foundSwitch,
                        hue = foundHue,
                        satPct = foundSatPct,
                        brightPct = foundBrightPct,
                        modeLabel = matchedLabel
                    )
                }
                return
            }
        }
    }

    private suspend fun sendSwitchCommandWithRetry(context: Context, turnOn: Boolean): Boolean {
        for (attempt in 0 until 2) {
            if (sendSwitchCommandOnce(context, turnOn)) return true
            if (attempt == 0) delay(150L)
        }
        return false
    }

    private suspend fun sendSwitchCommandOnce(context: Context, turnOn: Boolean): Boolean {
        val candidates = listOf(discoveredSwitchCode, "switch_led", "led_switch", "switch_1").distinct()
        for (code in candidates) {
            val cmds = JSONArray().put(
                JSONObject().apply {
                    put("code", code)
                    put("value", turnOn)
                }
            )
            if (postDeviceCommands(context, cmds)) {
                persistWinningRoute(context, switchCode = code)
                return true
            }
        }
        return false
    }

    private suspend fun sendHsvColorCommandWithRetry(context: Context, hue: Int, satPct: Int, brightPct: Int): Boolean {
        for (attempt in 0 until 2) {
            if (sendHsvColorCommandOnce(context, hue, satPct, brightPct)) return true
            if (attempt == 0) delay(150L)
        }
        return false
    }

    private fun buildColorCommandCandidate(
        fmtIdx: Int,
        switchCode: String,
        hexLower: String,
        hexUpper: String,
        v1JsonStr: String,
        v2JsonStr: String
    ): JSONArray {
        return when (fmtIdx) {
            // 0: Чистый 12-значный hex в нижнем регистре БЕЗ work_mode (рабочий вариант из v5.0 hexLowerCmds!)
            0 -> JSONArray()
                .put(JSONObject().put("code", switchCode).put("value", true))
                .put(JSONObject().put("code", "colour_data").put("value", hexLower))
            // 1: Чистый 12-значный hex в верхнем регистре БЕЗ work_mode (рабочий вариант из v5.0 altCmds!)
            1 -> JSONArray()
                .put(JSONObject().put("code", switchCode).put("value", true))
                .put(JSONObject().put("code", "colour_data").put("value", hexUpper))
            // 2: JSONObject {h, s(0..255), v(0..255)} на colour_data БЕЗ work_mode (рабочий вариант из v5.0 objCmds!)
            2 -> JSONArray()
                .put(JSONObject().put("code", switchCode).put("value", true))
                .put(JSONObject().put("code", "colour_data").put("value", JSONObject(v1JsonStr)))
            // 3: Строка JSON {h, s(0..1000), v(0..1000)} на colour_data_v2 БЕЗ work_mode (рабочий вариант из v5.0 altCmds!)
            3 -> JSONArray()
                .put(JSONObject().put("code", switchCode).put("value", true))
                .put(JSONObject().put("code", "colour_data_v2").put("value", v2JsonStr))
            // 4: Строка JSON {h, s(0..255), v(0..255)} на colour_data БЕЗ work_mode
            4 -> JSONArray()
                .put(JSONObject().put("code", switchCode).put("value", true))
                .put(JSONObject().put("code", "colour_data").put("value", v1JsonStr))
            // 5: 12-значный hex в нижнем регистре С work_mode="colour"
            5 -> JSONArray()
                .put(JSONObject().put("code", switchCode).put("value", true))
                .put(JSONObject().put("code", "work_mode").put("value", "colour"))
                .put(JSONObject().put("code", "colour_data").put("value", hexLower))
            // 6: 12-значный hex в верхнем регистре С work_mode="colour"
            6 -> JSONArray()
                .put(JSONObject().put("code", switchCode).put("value", true))
                .put(JSONObject().put("code", "work_mode").put("value", "colour"))
                .put(JSONObject().put("code", "colour_data").put("value", hexUpper))
            // 7: Строка JSON {h, s(0..255), v(0..255)} С work_mode="colour" (primaryCmds из v5.0)
            else -> JSONArray()
                .put(JSONObject().put("code", switchCode).put("value", true))
                .put(JSONObject().put("code", "work_mode").put("value", "colour"))
                .put(JSONObject().put("code", "colour_data").put("value", v1JsonStr))
        }
    }

    private suspend fun sendHsvColorCommandOnce(context: Context, hue: Int, satPct: Int, brightPct: Int): Boolean {
        val h = ((hue % 360) + 360) % 360
        val s1000 = (satPct * 10).coerceIn(10, 1000)
        val v1000 = (brightPct * 10).coerceIn(10, 1000)
        val s255 = ((satPct / 100.0) * 255.0).toInt().coerceIn(5, 255)
        val v255 = ((brightPct / 100.0) * 255.0).toInt().coerceIn(5, 255)

        val hexLower = String.format(Locale.US, "%04x%04x%04x", h, s1000, v1000)
        val hexUpper = String.format(Locale.US, "%04X%04X%04X", h, s1000, v1000)

        val v1JsonStr = JSONObject().apply {
            put("h", h)
            put("s", s255)
            put("v", v255)
        }.toString()

        val v2JsonStr = JSONObject().apply {
            put("h", h)
            put("s", s1000)
            put("v", v1000)
        }.toString()

        val sw = discoveredSwitchCode

        // 1. Если рабочий формат уже найден и закэширован — бьём ровно 1 прямым запросом за ~80 мс без перебора!
        val cachedFmt = winningColorFormatIdx
        if (cachedFmt in 0..7) {
            val fastCmds = buildColorCommandCandidate(cachedFmt, sw, hexLower, hexUpper, v1JsonStr, v2JsonStr)
            if (postDeviceCommands(context, fastCmds)) {
                return true
            }
        }

        // 2. Если формат ещё не закэширован (первый запуск) — пробуем сначала чистые форматы БЕЗ work_mode,
        //    и как только один срабатывает — навсегда запоминаем его в ОЗУ и SharedPreferences!
        val candidateOrder = listOf(0, 1, 2, 3, 4, 5, 6, 7)
        for (fmtIdx in candidateOrder) {
            if (fmtIdx == cachedFmt) continue
            val cmds = buildColorCommandCandidate(fmtIdx, sw, hexLower, hexUpper, v1JsonStr, v2JsonStr)
            if (postDeviceCommands(context, cmds)) {
                persistWinningRoute(context, colorFmtIdx = fmtIdx)
                return true
            }
        }

        return false
    }

    private suspend fun postDeviceCommands(context: Context?, commandsArray: JSONArray): Boolean {
        val devId = LauncherConfig.TUYA_LED_DEVICE_ID
        val body = JSONObject().put("commands", commandsArray).toString()
        val defaultPaths = listOf(
            "/v1.0/iot-03/devices/$devId/commands",
            "/v1.0/devices/$devId/commands"
        )
        val orderedPaths = mutableListOf<String>()
        if (winningCommandPath.isNotEmpty()) {
            orderedPaths.add(winningCommandPath)
        }
        for (p in defaultPaths) {
            if (!orderedPaths.contains(p)) orderedPaths.add(p)
        }

        for (path in orderedPaths) {
            val res = executeSignedTuyaRequest("POST", path, body) ?: continue
            if (res.optBoolean("success", false)) {
                if (winningCommandPath != path) {
                    persistWinningRoute(context, cmdPath = path)
                }
                return true
            }
        }
        return false
    }

    private suspend fun ensureAccessToken(forceRefresh: Boolean = false): String = withContext(Dispatchers.IO) {
        synchronized(tokenLock) {
            val nowWall = System.currentTimeMillis()
            if (!forceRefresh && cachedAccessToken.isNotEmpty() && nowWall < tokenExpiresAtWallMs) {
                return@withContext cachedAccessToken
            }

            val orderedHosts = mutableListOf<String>()
            orderedHosts.add(cachedHost)
            for (h in apiHosts) {
                if (h != cachedHost) orderedHosts.add(h)
            }

            // Используем проверенный 32-символьный секрет Tuya (без ложного перебора 33-символьного alt)
            val secret = LauncherConfig.TUYA_CLIENT_SECRET

            for (host in orderedHosts) {
                var tokenJson = executeRawSignedCall(
                    host = host,
                    method = "GET",
                    pathWithQuery = "/v1.0/token?grant_type=1",
                    body = "",
                    accessToken = "",
                    secretOverride = secret
                ) ?: continue

                val serverT = tokenJson.optLong("t", 0L)
                if (serverT > 1_600_000_000_000L) {
                    serverTimeOffsetMs = serverT - System.currentTimeMillis()
                }

                if (!tokenJson.optBoolean("success", false)) {
                    val retryJson = executeRawSignedCall(
                        host = host,
                        method = "GET",
                        pathWithQuery = "/v1.0/token?grant_type=1",
                        body = "",
                        accessToken = "",
                        secretOverride = secret
                    )
                    if (retryJson != null) {
                        tokenJson = retryJson
                    }
                }

                if (tokenJson.optBoolean("success", false)) {
                    val resObj = tokenJson.optJSONObject("result")
                    val tok = resObj?.optString("access_token", "").orEmpty()
                    val expSec = resObj?.optLong("expire_time", 3600L) ?: 3600L
                    if (tok.isNotEmpty()) {
                        cachedHost = host
                        cachedAccessToken = tok
                        val safeTtlMs = ((expSec - 180L).coerceIn(300L, 2700L)) * 1000L
                        tokenExpiresAtWallMs = System.currentTimeMillis() + safeTtlMs
                        Log.d(TAG, "Obtained fresh Tuya token on $host (ttl=${safeTtlMs / 1000}s)")
                        return@withContext tok
                    }
                }
            }
            Log.e(TAG, "Failed to obtain Tuya access_token")
            cachedAccessToken
        }
    }

    private suspend fun executeSignedTuyaRequest(
        method: String,
        pathWithQuery: String,
        body: String
    ): JSONObject? = withContext(Dispatchers.IO) {
        var token = ensureAccessToken(forceRefresh = false)
        if (token.isEmpty()) return@withContext null

        val secret = LauncherConfig.TUYA_CLIENT_SECRET
        var res = executeRawSignedCall(cachedHost, method, pathWithQuery, body, token, secret)

        // При обычном сетевом таймауте (res == null) повторяем запрос с ТЕКУЩИМ валидным токеном,
        // а полный сброс токена (forceRefresh = true) делаем ТОЛЬКО при кодах ошибки авторизации (1010, 1013, 1004)!
        if (res == null) {
            res = executeRawSignedCall(cachedHost, method, pathWithQuery, body, token, secret)
        } else if (!res.optBoolean("success", false)) {
            val serverT = res.optLong("t", 0L)
            if (serverT > 1_600_000_000_000L) {
                serverTimeOffsetMs = serverT - System.currentTimeMillis()
            }
            val code = res.optInt("code", 0)
            val msg = res.optString("msg", "").lowercase(Locale.US)
            if (code == 1010 || code == 1013 || code == 1004 || msg.contains("token") || msg.contains("sign")) {
                token = ensureAccessToken(forceRefresh = true)
                if (token.isNotEmpty()) {
                    res = executeRawSignedCall(cachedHost, method, pathWithQuery, body, token, secret)
                }
            }
        }
        res
    }

    private fun executeRawSignedCall(
        host: String,
        method: String,
        pathWithQuery: String,
        body: String,
        accessToken: String,
        secretOverride: String = ""
    ): JSONObject? {
        val clientId = LauncherConfig.TUYA_CLIENT_ID
        val secret = if (secretOverride.isNotEmpty()) secretOverride else LauncherConfig.TUYA_CLIENT_SECRET
        val timestamp = (System.currentTimeMillis() + serverTimeOffsetMs).toString()

        val bodyBytes = body.toByteArray(Charsets.UTF_8)
        val contentSha256 = sha256HexLower(bodyBytes)
        val stringToSign = "$method\n$contentSha256\n\n$pathWithQuery"
        val payloadToSign = if (accessToken.isEmpty()) {
            "$clientId$timestamp$stringToSign"
        } else {
            "$clientId$accessToken$timestamp$stringToSign"
        }
        val signUpper = hmacSha256HexUpper(payloadToSign, secret)

        var conn: HttpURLConnection? = null
        return try {
            val connObj = (URL("$host$pathWithQuery").openConnection() as HttpURLConnection).apply {
                requestMethod = method
                connectTimeout = 2200
                readTimeout = 2500
                doInput = true
                useCaches = false
                setRequestProperty("Connection", "keep-alive")
                setRequestProperty("client_id", clientId)
                setRequestProperty("sign", signUpper)
                setRequestProperty("t", timestamp)
                setRequestProperty("sign_method", "HMAC-SHA256")
                setRequestProperty("Content-Type", "application/json")
                if (accessToken.isNotEmpty()) {
                    setRequestProperty("access_token", accessToken)
                }
                if (method == "POST" || method == "PUT") {
                    doOutput = true
                }
            }
            conn = connObj
            if (method == "POST" || method == "PUT") {
                connObj.outputStream.use { os ->
                    os.write(bodyBytes)
                    os.flush()
                }
            }
            val code = connObj.responseCode
            val stream = if (code in 200..299) connObj.inputStream else connObj.errorStream
            // Закрытие stream через .use возвращает TLS-соединение в Keep-Alive пул Android (не вызываем disconnect при успехе!)
            val respText = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            Log.d(TAG, "HTTP $code $method $host$pathWithQuery -> $respText")
            if (respText.isNotBlank()) JSONObject(respText) else null
        } catch (e: Exception) {
            Log.e(TAG, "Exception in $method $host$pathWithQuery: ${e.javaClass.simpleName}: ${e.message}")
            try {
                conn?.disconnect()
            } catch (_: Exception) {
            }
            null
        }
    }

    private fun sha256HexLower(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        val sb = StringBuilder(digest.size * 2)
        for (b in digest) {
            sb.append(String.format(Locale.US, "%02x", b.toInt() and 0xFF))
        }
        return sb.toString()
    }

    private fun hmacSha256HexUpper(data: String, secret: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        val keySpec = SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256")
        mac.init(keySpec)
        val raw = mac.doFinal(data.toByteArray(Charsets.UTF_8))
        val sb = StringBuilder(raw.size * 2)
        for (b in raw) {
            sb.append(String.format(Locale.US, "%02X", b.toInt() and 0xFF))
        }
        return sb.toString()
    }
}

object AssistantVoiceSpeaker {

    private const val PREF_TTS_ENABLED = "pref_assistant_tts_enabled"
    private const val PREF_TTS_VOICE = "pref_assistant_tts_voice"

    val AVAILABLE_VOICES: List<Pair<String, String>> = listOf(
        "Puck" to "Puck (Мужской · Бодрый)",
        "Charon" to "Charon (Мужской · Глубокий)",
        "Fenrir" to "Fenrir (Мужской · Энергичный)",
        "Kore" to "Kore (Женский · Чёткий)",
        "Aoede" to "Aoede (Женский · Мягкий)"
    )

    private val ttsModels = listOf(
        "gemini-2.5-flash-preview-tts",
        "gemini-2.5-pro-preview-tts"
    )

    @Volatile
    private var cachedTtsModel: String? = null

    private val speakerScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    private var speakJob: Job? = null

    @Volatile
    private var activeAudioTrack: AudioTrack? = null

    @Volatile
    var isSpeakingNow: Boolean = false
        private set

    @Volatile
    var currentVoiceWaveLevel: Float = 0.45f
        private set

    private var currentAudioFocusRequest: AudioFocusRequest? = null

    fun isTtsEnabled(context: Context): Boolean {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(PREF_TTS_ENABLED, true)
    }

    fun setTtsEnabled(context: Context, enabled: Boolean) {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(PREF_TTS_ENABLED, enabled).apply()
        if (!enabled) {
            stop(context)
        }
    }

    fun getSelectedVoiceName(context: Context): String {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString(PREF_TTS_VOICE, "Puck") ?: "Puck"
        return if (AVAILABLE_VOICES.any { it.first.equals(saved, ignoreCase = true) }) {
            AVAILABLE_VOICES.first { it.first.equals(saved, ignoreCase = true) }.first
        } else {
            "Puck"
        }
    }

    fun getSelectedVoiceDisplayLabel(context: Context): String {
        val code = getSelectedVoiceName(context)
        return AVAILABLE_VOICES.firstOrNull { it.first == code }?.second ?: code
    }

    fun setVoiceName(context: Context, rawVoice: String): String {
        val clean = rawVoice.trim()
        val matched = AVAILABLE_VOICES.firstOrNull {
            it.first.equals(clean, ignoreCase = true) || it.second.lowercase(Locale.ROOT).contains(clean.lowercase(Locale.ROOT))
        }?.first ?: when {
            clean.lowercase(Locale.ROOT).contains("жен") || clean.lowercase(Locale.ROOT).contains("жіноч") || clean.lowercase(Locale.ROOT).contains("kore") -> "Kore"
            clean.lowercase(Locale.ROOT).contains("мягк") || clean.lowercase(Locale.ROOT).contains("aoede") -> "Aoede"
            clean.lowercase(Locale.ROOT).contains("глуб") || clean.lowercase(Locale.ROOT).contains("charon") -> "Charon"
            clean.lowercase(Locale.ROOT).contains("энерг") || clean.lowercase(Locale.ROOT).contains("fenrir") -> "Fenrir"
            else -> "Puck"
        }
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(PREF_TTS_VOICE, matched).apply()
        return matched
    }

    fun cycleNextVoice(context: Context): String {
        val current = getSelectedVoiceName(context)
        val idx = AVAILABLE_VOICES.indexOfFirst { it.first == current }
        val next = if (idx >= 0) AVAILABLE_VOICES[(idx + 1) % AVAILABLE_VOICES.size].first else AVAILABLE_VOICES.first().first
        setVoiceName(context, next)
        return getSelectedVoiceDisplayLabel(context)
    }

    fun init(context: Context) {
        // 0 МБ фонового потребления ОЗУ в простое
    }

    /**
     * Разбивает ответ на короткую первую фразу (~20–62 символа) для мгновенного старта голоса за ~1 секунду
     * и последующие предложения, которые догружаются параллельно в фоне во время звучания первой фразы!
     */
    private fun splitTextForFastStart(text: String): List<String> {
        val clean = text.trim()
        if (clean.length <= 68) return listOf(clean)

        val chunks = mutableListOf<String>()
        var remaining = clean

        // 1. Выделяем короткую первую фразу (до первой точки, восклицательного/вопросительного знака, тире или запятой в диапазоне 18..68 символов)
        var firstSplitIdx = -1
        val strongDelims = listOf(". ", "! ", "? ", "; ", ": ", " — ", " - ")
        for (d in strongDelims) {
            val idx = remaining.indexOf(d)
            if (idx in 14..68) {
                val candidate = idx + d.length
                if (firstSplitIdx == -1 || candidate < firstSplitIdx) {
                    firstSplitIdx = candidate
                }
            }
        }
        if (firstSplitIdx == -1) {
            val commaIdx = remaining.indexOf(", ")
            if (commaIdx in 20..65) {
                firstSplitIdx = commaIdx + 2
            }
        }
        if (firstSplitIdx == -1) {
            val spaceIdx = remaining.lastIndexOf(' ', 58)
            if (spaceIdx >= 22) {
                firstSplitIdx = spaceIdx + 1
            }
        }

        if (firstSplitIdx > 0 && firstSplitIdx < remaining.length) {
            val firstPart = remaining.substring(0, firstSplitIdx).trim()
            if (firstPart.isNotEmpty()) {
                chunks.add(firstPart)
            }
            remaining = remaining.substring(firstSplitIdx).trim()
        }

        // 2. Остаток разбиваем по предложениям (до ~130 символов на чанк)
        while (remaining.isNotEmpty()) {
            if (remaining.length <= 135) {
                chunks.add(remaining)
                break
            }
            var splitAt = -1
            for (d in listOf(". ", "! ", "? ", "; ")) {
                val idx = remaining.lastIndexOf(d, 135)
                if (idx >= 25 && idx + d.length > splitAt) {
                    splitAt = idx + d.length
                }
            }
            if (splitAt == -1) {
                val commaIdx = remaining.lastIndexOf(", ", 130)
                if (commaIdx >= 30) {
                    splitAt = commaIdx + 2
                }
            }
            if (splitAt == -1) {
                val spIdx = remaining.lastIndexOf(' ', 125)
                splitAt = if (spIdx >= 30) spIdx + 1 else 125
            }
            val piece = remaining.substring(0, splitAt).trim()
            if (piece.isNotEmpty()) {
                chunks.add(piece)
            }
            remaining = remaining.substring(splitAt).trim()
        }

        return if (chunks.isEmpty()) listOf(clean) else chunks
    }

    /**
     * Потоково-конвейерный синтез и воспроизведение речи через Gemini 2.5 Flash TTS:
     * Первая короткая фраза синтезируется за ~1 сек и сразу начинает звучать через единый AudioTrack(MODE_STREAM),
     * а следующие фразы параллельно синтезируются в фоне во время воспроизведения первой!
     */
    fun speak(context: Context, rawText: String, onFinished: ((Boolean) -> Unit)? = null) {
        val appCtx = context.applicationContext
        stop(appCtx)

        if (!isTtsEnabled(appCtx)) {
            onFinished?.let { mainHandler.post { it.invoke(false) } }
            return
        }

        val cleanText = rawText
            .removePrefix("✦")
            .replace("⚡", "")
            .replace("✓", "")
            .replace("·", ", ")
            .replace("–", " до ")
            .trim()

        if (cleanText.isEmpty()) {
            onFinished?.let { mainHandler.post { it.invoke(false) } }
            return
        }

        val voiceName = getSelectedVoiceName(appCtx)
        val textChunks = splitTextForFastStart(cleanText)
        isSpeakingNow = true
        currentVoiceWaveLevel = 0.52f

        speakJob = speakerScope.launch {
            var playedSuccessfully = false
            var track: AudioTrack? = null
            try {
                // Запускаем генерацию 1-й короткой фразы прямо сейчас, а 2-й фразы — параллельно с небольшой форой!
                var currentDeferred: Deferred<ByteArray?>? = async { fetchGeminiTtsPcm(textChunks[0], voiceName) }
                var nextDeferred: Deferred<ByteArray?>? = if (textChunks.size > 1) {
                    async { fetchGeminiTtsPcm(textChunks[1], voiceName) }
                } else {
                    null
                }

                for (idx in textChunks.indices) {
                    if (!isActive || !isSpeakingNow) break

                    val pcmData = currentDeferred?.await()
                    // Пока сейчас будет играть текущий кусок, заранее ставим в генерацию (idx + 2)-й кусок
                    currentDeferred = nextDeferred
                    nextDeferred = if (idx + 2 < textChunks.size) {
                        async { fetchGeminiTtsPcm(textChunks[idx + 2], voiceName) }
                    } else {
                        null
                    }

                    if (pcmData != null && pcmData.size > 400 && isActive && isSpeakingNow) {
                        if (track == null) {
                            track = openStreamingAudioTrack24kHz(appCtx)
                            activeAudioTrack = track
                        }
                        val activeAt = track
                        if (activeAt != null) {
                            val ok = writePcmChunkWithVisualizer(activeAt, pcmData)
                            if (ok) playedSuccessfully = true
                        }
                    }
                }
            } catch (_: Exception) {
            } finally {
                activeAudioTrack = null
                try {
                    track?.stop()
                } catch (_: Exception) {
                }
                try {
                    track?.release()
                } catch (_: Exception) {
                }
                isSpeakingNow = false
                currentVoiceWaveLevel = 0.35f
                abandonAudioFocus(appCtx)
                if (isActive) {
                    val didPlay = playedSuccessfully
                    onFinished?.let { cb ->
                        mainHandler.post { cb.invoke(didPlay) }
                    }
                }
            }
        }
    }

    fun stop(context: Context? = null) {
        speakJob?.cancel()
        speakJob = null
        isSpeakingNow = false
        currentVoiceWaveLevel = 0.35f
        val runningTrack = activeAudioTrack
        activeAudioTrack = null
        if (runningTrack != null) {
            try {
                runningTrack.pause()
                runningTrack.flush()
            } catch (_: Exception) {
            }
            try {
                runningTrack.release()
            } catch (_: Exception) {
            }
        }
        if (context != null) {
            abandonAudioFocus(context.applicationContext)
        }
    }

    private fun fetchGeminiTtsPcm(textToSpeak: String, voiceName: String): ByteArray? {
        val apiKey = LauncherConfig.DEFAULT_GEMINI_API_KEY
        val payload = JSONObject().apply {
            put("contents", JSONArray().put(
                JSONObject().apply {
                    put("parts", JSONArray().put(
                        JSONObject().put("text", textToSpeak)
                    ))
                }
            ))
            put("generationConfig", JSONObject().apply {
                put("responseModalities", JSONArray().put("AUDIO"))
                put("speechConfig", JSONObject().apply {
                    put("voiceConfig", JSONObject().apply {
                        put("prebuiltVoiceConfig", JSONObject().apply {
                            put("voiceName", voiceName)
                        })
                    })
                })
            })
        }.toString()

        val orderedModels = mutableListOf<String>()
        val cached = cachedTtsModel
        if (cached != null) orderedModels.add(cached)
        for (m in ttsModels) {
            if (m != cached) orderedModels.add(m)
        }

        for (model in orderedModels) {
            var conn: HttpURLConnection? = null
            try {
                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=${Uri.encode(apiKey)}")
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 4500
                    readTimeout = 9500
                    doOutput = true
                    doInput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Connection", "keep-alive")
                }
                conn = connection
                connection.outputStream.use { os ->
                    os.write(payload.toByteArray(Charsets.UTF_8))
                }
                if (connection.responseCode in 200..299) {
                    val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    val root = JSONObject(body)
                    val parts = root.optJSONArray("candidates")
                        ?.optJSONObject(0)
                        ?.optJSONObject("content")
                        ?.optJSONArray("parts")
                    if (parts != null) {
                        for (i in 0 until parts.length()) {
                            val inlineData = parts.optJSONObject(i)?.optJSONObject("inlineData") ?: continue
                            val b64 = inlineData.optString("data", "")
                            if (b64.isNotBlank()) {
                                cachedTtsModel = model
                                val rawBytes = Base64.decode(b64, Base64.DEFAULT)
                                return if (rawBytes.size > 44 &&
                                    rawBytes[0] == 0x52.toByte() &&
                                    rawBytes[1] == 0x49.toByte() &&
                                    rawBytes[2] == 0x46.toByte() &&
                                    rawBytes[3] == 0x46.toByte()
                                ) {
                                    rawBytes.copyOfRange(44, rawBytes.size)
                                } else {
                                    rawBytes
                                }
                            }
                        }
                    }
                }
            } catch (_: Exception) {
            } finally {
                try {
                    conn?.disconnect()
                } catch (_: Exception) {
                }
            }
        }
        return null
    }

    private fun openStreamingAudioTrack24kHz(context: Context): AudioTrack? {
        val sampleRate = 24000
        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(4800)

        return try {
            requestTransientAudioDucking(context)
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            val format = AudioFormat.Builder()
                .setSampleRate(sampleRate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()
            AudioTrack(
                attrs,
                format,
                minBuf * 2,
                AudioTrack.MODE_STREAM,
                AudioManager.AUDIO_SESSION_ID_GENERATE
            ).apply {
                play()
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun writePcmChunkWithVisualizer(at: AudioTrack, pcmBytes: ByteArray): Boolean {
        return try {
            val chunkSize = 1920 // 40 мс при 24000 Гц (16 бит моно)
            var offset = 0
            while (offset < pcmBytes.size && isSpeakingNow) {
                val len = (pcmBytes.size - offset).coerceAtMost(chunkSize)
                val samplesCount = len / 2
                if (samplesCount > 0) {
                    var sumSq = 0.0
                    val bb = ByteBuffer.wrap(pcmBytes, offset, len).order(ByteOrder.LITTLE_ENDIAN)
                    for (s in 0 until samplesCount) {
                        val v = bb.short.toDouble()
                        sumSq += v * v
                    }
                    val rms = sqrt(sumSq / samplesCount)
                    currentVoiceWaveLevel = (0.26f + (rms / 5500.0).toFloat()).coerceIn(0.26f, 1.0f)
                }
                val written = at.write(pcmBytes, offset, len)
                if (written <= 0) break
                offset += written
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun requestTransientAudioDucking(context: Context) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
                val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(attrs)
                    .setAcceptsDelayedFocusGain(false)
                    .setOnAudioFocusChangeListener {}
                    .build()
                currentAudioFocusRequest = req
                am.requestAudioFocus(req)
            } else {
                @Suppress("DEPRECATION")
                am.requestAudioFocus(
                    null,
                    AudioManager.STREAM_MUSIC,
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
                )
            }
        } catch (_: Exception) {
        }
    }

    private fun abandonAudioFocus(context: Context) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val req = currentAudioFocusRequest
                if (req != null) {
                    am.abandonAudioFocusRequest(req)
                    currentAudioFocusRequest = null
                }
            } else {
                @Suppress("DEPRECATION")
                am.abandonAudioFocus(null)
            }
        } catch (_: Exception) {
        }
    }
}

data class GeminiTurnResult(
    val displayText: String,
    val shouldContinueDialog: Boolean,
    val isSilence: Boolean = false
)

object GeminiCloudClient {

    private data class ChatTurn(
        val role: String,
        val text: String
    )

    private val candidateModels = listOf(
        "gemini-2.5-flash",
        "gemini-2.5-flash-lite",
        "gemini-2.0-flash",
        "gemini-2.0-flash-lite",
        "gemini-flash-latest",
        "gemini-1.5-flash"
    )

    private val conversationHistory = mutableListOf<ChatTurn>()

    @Volatile
    private var lastInteractionRealtimeMs: Long = 0L

    @Volatile
    private var cachedModelName: String? = null

    @Volatile
    private var cachedUseHeaderAuth: Boolean = false

    @Synchronized
    fun clearConversationHistory() {
        conversationHistory.clear()
    }

    @Synchronized
    private fun appendTurnToHistory(userText: String, modelText: String) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastInteractionRealtimeMs > 5 * 60 * 1000L) {
            conversationHistory.clear()
        }
        lastInteractionRealtimeMs = now
        if (userText.isNotBlank()) {
            conversationHistory.add(ChatTurn("user", userText.take(350)))
        }
        if (modelText.isNotBlank()) {
            conversationHistory.add(ChatTurn("model", modelText.take(450)))
        }
        while (conversationHistory.size > 8) {
            conversationHistory.removeAt(0)
        }
    }

    @Synchronized
    private fun formatRecentHistoryBlock(): String {
        val now = SystemClock.elapsedRealtime()
        if (now - lastInteractionRealtimeMs > 5 * 60 * 1000L) {
            conversationHistory.clear()
            return ""
        }
        if (conversationHistory.isEmpty()) return ""
        val lines = conversationHistory.joinToString("\n") { turn ->
            val who = if (turn.role == "user") "Пользователь" else "Ты (Ассистент)"
            "$who: ${turn.text}"
        }
        return "\nПредыдущий контекст текущего диалога (учитывай его при ответе на уточняющие вопросы вроде «а на завтра?», «а почему?», «расскажи подробнее»):\n$lines\n"
    }

    private fun buildCommandInstruction(context: Context): String {
        val appCtx = context.applicationContext
        val apps = AppLauncher(appCtx).getInstalledApps().take(30)
            .joinToString(", ") { "${it.label} (${it.packageName})" }
        val outageInfo = OutageRepository.getSummaryForAi(appCtx)
        val historyBlock = formatRecentHistoryBlock()
        val currentVoice = AssistantVoiceSpeaker.getSelectedVoiceName(appCtx)
        val ttsEnabled = AssistantVoiceSpeaker.isTtsEnabled(appCtx)
        return "Ты — живой, умный и сверхбыстрый голосовой ИИ-ассистент в кастомном лаунчере Android TV (Xiaomi Mi TV Stick). " +
            "Сейчас твоя голосовая озвучка: ${if (ttsEnabled) "ВКЛЮЧЕНА (голос $currentVoice)" else "ВЫКЛЮЧЕНА"}. " +
            "Отвечай естественно, дружелюбно и лаконично (1–2 предложения, без звёздочек и без разметки Markdown). " +
            "Актуальные данные по графику отключений света пользователя ($outageInfo). Если пользователь спрашивает про свет/отключения/график ДТЭК — дай точный ответ по этим данным! " +
            historyBlock +
            "Ты идеально понимаешь украинский, русский, суржик и английский языки. Отвечай на том же языке, на котором обратился пользователь.\n" +
            "ВАЖНОЕ ПРАВИЛО РЕЖИМА ДИАЛОГА:\n" +
            "- Если пользователь выполняет команду управления ТВ (включи трек/видео/стрим, открой приложение, измени громкость/цвет) ИЛИ задал простой закрытый вопрос на один факт (например «когда выключат свет?», «какая очередь?», «сколько времени?») — обязательно поставь в начале ответа тег [MODE:ONE_SHOT], чтобы после ответа микрофон НЕ включался сам.\n" +
            "- Ставь тег [MODE:DIALOG] ТОЛЬКО тогда, когда пользователь явно ведёт беседу/обсуждение (например «посоветуй фильм», «давай поговорим», «расскажи...») ИЛИ когда ты сам задаёшь пользователю встречный уточняющий вопрос в конце ответа!\n" +
            "ТЕГИ КОМАНД УПРАВЛЕНИЯ ПРИСТАВКОЙ (ставь в начале ответа, если пользователь просит выполнить действие):\n" +
            "- Включить песню, трек, альбом или исполнителя в Spotify: [CMD:SPOTIFY:Точное имя артиста и трека] (переводи транслит в оригинальное название, например «уикенд старбой» -> [CMD:SPOTIFY:The Weeknd Starboy])\n" +
            "- Запустить стрим на Kick: [CMD:KICK:channel_slug] (для стримера Калатай / Kalatay всегда используй [CMD:KICK:kalatay3])\n" +
            "- Найти или включить видео на YouTube: [CMD:YT:поисковый запрос]\n" +
            "- Изменить цвет темы лаунчера, обводки или ползунка громкости: [CMD:COLOR:#RRGGBB] (красный #EF4444, розовый #EC4899, фиолетовый #A78BFA, зелёный #34D399, синий #60A5FA, голубой/бирюзовый #00F0FF, жёлтый/золотой #F59E0B, оранжевый #F97316, белый #E2E8F0)\n" +
            "- Управление умной светодиодной LED-лентой (подсветкой ТВ): включить ленту/подсветку [CMD:LED_ON], выключить ленту/подсветку [CMD:LED_OFF], установить ЛЮБОЙ цвет или оттенок ленты [CMD:LED_COLOR:#RRGGBB] (переводи любое название оттенка — бирюзовый #00F0FF, морская волна #06B6D4, сапфир #2563EB, индиго #6366F1, лаванда #C084FC, фиолетовый #A855F7, фуксия/розовый #EC4899, малиновый #F43F5E, красный #EF4444, персиковый #FB923C, закат #F97316, янтарный/жёлтый #F59E0B, лайм #84CC16, изумрудный/зелёный #10B981, мята #2DD4BF, тёплый белый #FDE68A), изменить яркость ленты в процентах [CMD:LED_BRIGHT:10..100], включить динамический режим на ленте [CMD:LED_SCENE:RAINBOW|BREATHE|PARTY|NIGHT]\n" +
            "- Открыть установленное приложение: [CMD:LAUNCH:package_name] (список приложений: $apps)\n" +
            "- Открыть системные настройки ТВ: [CMD:SETTINGS], настройки Wi-Fi: [CMD:WIFI], настройки Bluetooth: [CMD:BLUETOOTH]\n" +
            "- Открыть сайт в браузере: [CMD:URL:https://адрес]\n" +
            "- Громкость в процентах: [CMD:VOL_SET:0..100], сделать громче: [CMD:VOL_UP], тише: [CMD:VOL_DOWN], выключить звук: [CMD:MUTE], включить звук: [CMD:UNMUTE]\n" +
            "- Управление плеером: [CMD:PAUSE], [CMD:PLAY], [CMD:NEXT], [CMD:PREV]\n" +
            "- Очистить оперативную память / ускорить приставку: [CMD:BOOST]\n" +
            "- Выключить или включить звук щелчков пульта: [CMD:NAV_SOUND:OFF] или [CMD:NAV_SOUND:ON]\n" +
            "- Выключить или включить голосовую озвучку твоих ответов: [CMD:TTS:OFF] или [CMD:TTS:ON]\n" +
            "- Сменить твой голос озвучки (доступны мужские голоса Puck, Charon, Fenrir и женские Kore, Aoede): [CMD:VOICE:имя_голоса]\n" +
            "- Показать на экране окно графика отключений света: [CMD:OUTAGE_OPEN]\n" +
            "- Изменить очередь (группу) отключений света ДТЭК (от 1.1 до 6.2): [CMD:OUTAGE_GROUP:номер_очереди]\n" +
            "- Ввести или напечатать текст в поле поиска на экране ТВ: [CMD:TYPE:текст для ввода]\n" +
            "- Нажать на кнопку, вкладку или карточку на экране ТВ по названию: [CMD:CLICK:текст кнопки]\n" +
            "- Системная навигация по ТВ: [CMD:NAV:HOME] (на главный экран), [CMD:NAV:BACK] (назад)\n" +
            "- Если пользователь прощается или говорит «спасибо, всё / хватит / пока / отбой»: [CMD:STOP_DIALOG]\n" +
            "- Если пользователь просит забыть контекст или сменить тему: [CMD:CLEAR_MEMORY]\n" +
            "После тегов напиши короткий живой ответ для пользователя."
    }

    private fun buildPayloadForModel(contentsArray: JSONArray, modelName: String, temperature: Double): String {
        val genConfig = JSONObject().apply {
            put("maxOutputTokens", 1200)
            put("temperature", temperature)
            if (modelName.startsWith("gemini-2.5-flash")) {
                put("thinkingConfig", JSONObject().apply {
                    put("thinkingBudget", 0)
                })
            }
        }
        return JSONObject().apply {
            put("contents", contentsArray)
            put("generationConfig", genConfig)
        }.toString()
    }

    suspend fun askGeminiTextTurn(context: Context, userQuery: String): GeminiTurnResult = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext
        try {
            OutageRepository.refreshIfNeeded(appCtx, force = false)
        } catch (_: Exception) {
        }
        val fullPrompt = "${buildCommandInstruction(appCtx)}\n\nЗапрос пользователя: $userQuery"

        val contentsArray = JSONArray().put(
            JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", fullPrompt)))
            }
        )

        val rawReply = executeWithEndpointFallback(contentsArray, temperature = 0.35)
        processCommandTags(appCtx, rawReply, userTranscript = userQuery)
    }

    suspend fun askGeminiText(context: Context, userQuery: String): String {
        return askGeminiTextTurn(context, userQuery).displayText
    }

    suspend fun askGeminiAudioTurn(context: Context, wavBytes: ByteArray): GeminiTurnResult = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext
        try {
            OutageRepository.refreshIfNeeded(appCtx, force = false)
        } catch (_: Exception) {
        }
        val audioPrompt = buildCommandInstruction(appCtx) +
            "\n\nПрослушай голосовую реплику пользователя (на украинском, русском, суржике или английском). " +
            "Если на записи только тишина или фоновый шум без речи — ответь ровно одним словом: [SILENCE]. " +
            "Иначе в самом начале ответа напиши тег [USER_SAID:точная краткая расшифровка слов пользователя], затем тег режима ([MODE:ONE_SHOT] или [MODE:DIALOG]), теги команд [CMD:...] (если нужны) и свой ответ."

        val b64Audio = Base64.encodeToString(wavBytes, Base64.NO_WRAP)
        val partsArray = JSONArray()
            .put(JSONObject().put("text", audioPrompt))
            .put(JSONObject().put("inlineData", JSONObject().apply {
                put("mimeType", "audio/wav")
                put("data", b64Audio)
            }))

        val contentsArray = JSONArray().put(
            JSONObject().apply {
                put("role", "user")
                put("parts", partsArray)
            }
        )

        val rawReply = executeWithEndpointFallback(contentsArray, temperature = 0.3)
        if (rawReply.contains("[SILENCE]")) {
            return@withContext GeminiTurnResult(
                displayText = "✦ Не расслышал речь. Скажите запрос в микрофон.",
                shouldContinueDialog = false,
                isSilence = true
            )
        }
        processCommandTags(appCtx, rawReply, userTranscript = "")
    }

    suspend fun askGeminiAudio(context: Context, wavBytes: ByteArray): String {
        return askGeminiAudioTurn(context, wavBytes).displayText
    }

    private fun processCommandTags(context: Context, reply: String, userTranscript: String): GeminiTurnResult {
        var clean = reply.trim()
        var extractedUserSaid = userTranscript.trim()

        val saidRegex = Regex("\\[USER_SAID:([^\\]]+)\\]")
        val saidMatch = saidRegex.find(clean)
        if (saidMatch != null) {
            if (extractedUserSaid.isEmpty()) {
                extractedUserSaid = saidMatch.groupValues[1].trim()
            }
            clean = clean.replace(saidMatch.value, "").trim()
        }

        var modeIsDialog = false
        var modeExplicitlyOneShot = false
        val modeRegex = Regex("\\[MODE:([^\\]]+)\\]")
        for (mm in modeRegex.findAll(clean).toList()) {
            val modeVal = mm.groupValues[1].trim().uppercase(Locale.US)
            if (modeVal.contains("DIALOG")) {
                modeIsDialog = true
            } else if (modeVal.contains("ONE_SHOT") || modeVal.contains("SINGLE")) {
                modeExplicitlyOneShot = true
            }
            clean = clean.replace(mm.value, "").trim()
        }

        val cmdRegex = Regex("\\[CMD:([^\\]]+)\\]")
        val matches = cmdRegex.findAll(clean).toList()

        var hasAnyCommand = false
        var explicitStopDialog = false
        val isErrorReply = clean.startsWith("Ошибка ответа Gemini") || clean.startsWith("Не удалось связаться")

        if (matches.isNotEmpty()) {
            hasAnyCommand = true
            val handler = Handler(Looper.getMainLooper())
            for (m in matches) {
                clean = clean.replace(m.value, "").trim()
                val tagContent = m.groupValues[1]
                val parts = tagContent.split(":", limit = 2)
                val action = parts[0].trim().uppercase(Locale.US)
                val arg = parts.getOrNull(1)?.trim().orEmpty()

                if (action == "STOP_DIALOG") {
                    explicitStopDialog = true
                }
                if (action == "CLEAR_MEMORY") {
                    clearConversationHistory()
                }

                handler.post {
                    when (action) {
                        "SPOTIFY" -> if (arg.isNotEmpty()) {
                            LocalVoiceCommandRouter.launchSpotifyTrackOrArtist(context, arg)
                        }
                        "KICK" -> {
                            val slug = if (arg.lowercase().contains("kalatay") || arg.lowercase().contains("калатай")) {
                                "kalatay3"
                            } else {
                                arg
                            }
                            LocalVoiceCommandRouter.launchKickStream(context, slug)
                        }
                        "YT" -> if (arg.isNotEmpty()) {
                            LocalVoiceCommandRouter.launchYouTubeSearch(context, arg)
                        }
                        "COLOR" -> if (arg.isNotEmpty()) {
                            LocalVoiceCommandRouter.applyThemeColorEverywhere(context, arg)
                            TuyaSmartHomeController.syncWithLauncherThemeIfNeeded(context, arg)
                        }
                        "LED_ON" -> {
                            TuyaSmartHomeController.setPower(context, true)
                        }
                        "LED_OFF" -> {
                            TuyaSmartHomeController.setPower(context, false)
                        }
                        "LED_COLOR" -> if (arg.isNotEmpty()) {
                            TuyaSmartHomeController.setHexColor(context, arg)
                        }
                        "LED_BRIGHT" -> {
                            val pct = arg.toIntOrNull()
                            if (pct != null) {
                                TuyaSmartHomeController.setBrightnessPercent(context, pct)
                            }
                        }
                        "LED_SCENE" -> if (arg.isNotEmpty()) {
                            TuyaSmartHomeController.activateDynamicScene(context, arg)
                        }
                        "LAUNCH" -> if (arg.isNotEmpty()) {
                            MediaStateBus.onMediaAppOpened(arg)
                            AppLauncher(context).launchPackage(arg)
                        }
                        "SETTINGS" -> LocalVoiceCommandRouter.openSystemSettingsAction(context, Settings.ACTION_SETTINGS)
                        "WIFI" -> LocalVoiceCommandRouter.openSystemSettingsAction(context, Settings.ACTION_WIFI_SETTINGS)
                        "BLUETOOTH" -> LocalVoiceCommandRouter.openSystemSettingsAction(context, Settings.ACTION_BLUETOOTH_SETTINGS)
                        "URL" -> if (arg.isNotEmpty()) {
                            LocalVoiceCommandRouter.launchUrlInTvBrowser(context, arg)
                        }
                        "VOL_SET" -> {
                            val pct = arg.toIntOrNull()
                            if (pct != null) {
                                LocalVoiceCommandRouter.setVolumePercent(context, pct)
                            }
                        }
                        "VOL_UP", "VOL_DOWN", "MUTE", "UNMUTE", "PAUSE", "PLAY", "NEXT", "PREV" -> {
                            LocalVoiceCommandRouter.executeSystemAudioCommand(context, action)
                        }
                        "BOOST" -> LocalVoiceCommandRouter.cleanRamBackground(context)
                        "NAV_SOUND" -> {
                            val enable = !arg.uppercase(Locale.US).contains("OFF")
                            NavSoundPlayer.setSoundEnabled(context, enable)
                        }
                        "TTS" -> {
                            val enable = !arg.uppercase(Locale.US).contains("OFF")
                            AssistantVoiceSpeaker.setTtsEnabled(context, enable)
                        }
                        "VOICE" -> if (arg.isNotEmpty()) {
                            AssistantVoiceSpeaker.setVoiceName(context, arg)
                            AssistantVoiceSpeaker.setTtsEnabled(context, true)
                        }
                        "OUTAGE_OPEN" -> {
                            OutageRepository.onOpenScheduleRequested?.invoke()
                        }
                        "OUTAGE_GROUP" -> if (arg.isNotEmpty()) {
                            OutageRepository.setSelectedGroup(context, arg)
                        }
                        "TYPE" -> if (arg.isNotEmpty()) {
                            TvUiControllerBus.typeText(arg)
                        }
                        "CLICK" -> if (arg.isNotEmpty()) {
                            TvUiControllerBus.clickByText(arg)
                        }
                        "NAV" -> if (arg.isNotEmpty()) {
                            TvUiControllerBus.performNav(arg)
                        }
                    }
                }
            }
            val finalClean = clean.removePrefix("✦").trim().ifEmpty { "Готово" }
            if (!isErrorReply) {
                appendTurnToHistory(extractedUserSaid, finalClean)
            }
            val continueAfterCmd = modeIsDialog && !modeExplicitlyOneShot && !explicitStopDialog && !isErrorReply && finalClean.endsWith("?")
            return GeminiTurnResult(
                displayText = "✦ $finalClean",
                shouldContinueDialog = continueAfterCmd
            )
        }

        if (!isErrorReply) {
            appendTurnToHistory(extractedUserSaid, clean)
        }
        val shouldContinue = (modeIsDialog || (!modeExplicitlyOneShot && clean.endsWith("?"))) && !hasAnyCommand && !explicitStopDialog && !isErrorReply
        return GeminiTurnResult(
            displayText = clean,
            shouldContinueDialog = shouldContinue
        )
    }

    private fun executeWithEndpointFallback(contentsArray: JSONArray, temperature: Double): String {
        val primaryKey = LauncherConfig.DEFAULT_GEMINI_API_KEY
        val endpointTemplate = "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent"

        val cModel = cachedModelName
        if (cModel != null) {
            val urlStr = String.format(Locale.US, endpointTemplate, cModel)
            val bodyStr = buildPayloadForModel(contentsArray, cModel, temperature)
            val res = trySingleRequest(urlStr, primaryKey, cachedUseHeaderAuth, bodyStr)
            val cachedTxt = res.text
            if (res.isSuccess && !cachedTxt.isNullOrBlank()) {
                return cachedTxt
            }
        }

        var firstMeaningfulError = ""
        var lastError = ""

        for (model in candidateModels) {
            val urlStr = String.format(Locale.US, endpointTemplate, model)
            val bodyStr = buildPayloadForModel(contentsArray, model, temperature)
            val res = trySingleRequest(urlStr, primaryKey, useHeaderAuth = false, jsonBody = bodyStr)
            val txt = res.text
            if (res.isSuccess && !txt.isNullOrBlank()) {
                cachedModelName = model
                cachedUseHeaderAuth = false
                return txt
            }
            if (res.errorSummary == "HTTP 400" && model.startsWith("gemini-2.5-flash")) {
                val plainBody = buildPayloadForModel(contentsArray, "gemini-2.0-flash", temperature)
                val retryRes = trySingleRequest(urlStr, primaryKey, useHeaderAuth = false, jsonBody = plainBody)
                val retryTxt = retryRes.text
                if (retryRes.isSuccess && !retryTxt.isNullOrBlank()) {
                    cachedModelName = model
                    cachedUseHeaderAuth = false
                    return retryTxt
                }
            }
            if (res.errorSummary.isNotBlank()) {
                lastError = res.errorSummary
                if (firstMeaningfulError.isBlank() && res.errorSummary != "HTTP 404") {
                    firstMeaningfulError = res.errorSummary
                }
            }
        }

        val discoveredModels = discoverAvailableModels(primaryKey)
        for (model in discoveredModels) {
            if (model in candidateModels) continue
            val urlStr = String.format(Locale.US, endpointTemplate, model)
            val bodyStr = buildPayloadForModel(contentsArray, "gemini-2.0-flash", temperature)
            val res = trySingleRequest(urlStr, primaryKey, useHeaderAuth = false, jsonBody = bodyStr)
            val txt = res.text
            if (res.isSuccess && !txt.isNullOrBlank()) {
                cachedModelName = model
                cachedUseHeaderAuth = false
                return txt
            } else if (res.errorSummary.isNotBlank() && firstMeaningfulError.isBlank() && res.errorSummary != "HTTP 404") {
                firstMeaningfulError = res.errorSummary
            }
        }

        val finalErr = firstMeaningfulError.ifBlank { lastError }
        return if (finalErr.isNotBlank()) {
            "Ошибка ответа Gemini ($finalErr)"
        } else {
            "Не удалось связаться с Gemini. Проверьте интернет-соединение."
        }
    }

    private fun discoverAvailableModels(apiKey: String): List<String> {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models?key=${Uri.encode(apiKey)}")
            val connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 5000
                readTimeout = 7000
                doInput = true
            }
            conn = connection
            if (connection.responseCode !in 200..299) return emptyList()
            val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val root = JSONObject(body)
            val modelsArr = root.optJSONArray("models") ?: return emptyList()
            val flashModels = mutableListOf<String>()
            val otherModels = mutableListOf<String>()
            for (i in 0 until modelsArr.length()) {
                val obj = modelsArr.optJSONObject(i) ?: continue
                val name = obj.optString("name", "").removePrefix("models/").trim()
                if (name.isEmpty() || name.contains("embedding") || name.contains("imagen") || name.contains("tts") || name.contains("aqa")) continue
                val methods = obj.optJSONArray("supportedGenerationMethods")
                var supportsGenerate = false
                if (methods != null) {
                    for (j in 0 until methods.length()) {
                        if (methods.optString(j) == "generateContent") {
                            supportsGenerate = true
                            break
                        }
                    }
                }
                if (supportsGenerate) {
                    if (name.contains("flash")) {
                        flashModels.add(name)
                    } else if (name.startsWith("gemini")) {
                        otherModels.add(name)
                    }
                }
            }
            flashModels + otherModels
        } catch (_: Exception) {
            emptyList()
        } finally {
            try {
                conn?.disconnect()
            } catch (_: Exception) {
            }
        }
    }

    private data class HttpResult(
        val isSuccess: Boolean,
        val text: String? = null,
        val errorSummary: String = ""
    )

    private fun trySingleRequest(
        baseUrl: String,
        apiKey: String,
        useHeaderAuth: Boolean,
        jsonBody: String
    ): HttpResult {
        var conn: HttpURLConnection? = null
        return try {
            val finalUrl = if (useHeaderAuth) {
                baseUrl
            } else {
                "$baseUrl?key=${Uri.encode(apiKey)}"
            }
            val connection = (URL(finalUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 6000
                readTimeout = 12000
                doOutput = true
                doInput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Connection", "keep-alive")
                if (useHeaderAuth) {
                    setRequestProperty("x-goog-api-key", apiKey)
                }
            }
            conn = connection
            connection.outputStream.use { os ->
                os.write(jsonBody.toByteArray(Charsets.UTF_8))
            }
            val code = connection.responseCode
            if (code in 200..299) {
                val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val parsed = extractTextFromGeminiJson(body)
                if (!parsed.isNullOrBlank()) {
                    HttpResult(isSuccess = true, text = parsed)
                } else {
                    HttpResult(isSuccess = false, errorSummary = "Empty response")
                }
            } else {
                HttpResult(isSuccess = false, errorSummary = "HTTP $code")
            }
        } catch (e: Exception) {
            HttpResult(isSuccess = false, errorSummary = e.javaClass.simpleName)
        } finally {
            try {
                conn?.disconnect()
            } catch (_: Exception) {
            }
        }
    }

    private fun extractTextFromGeminiJson(rawJson: String): String? {
        return try {
            val root = JSONObject(rawJson)
            val candidates = root.optJSONArray("candidates") ?: return null
            if (candidates.length() == 0) return null
            val content = candidates.optJSONObject(0)?.optJSONObject("content") ?: return null
            val parts = content.optJSONArray("parts") ?: return null
            val sb = StringBuilder()
            val fallbackSb = StringBuilder()
            for (i in 0 until parts.length()) {
                val partObj = parts.optJSONObject(i) ?: continue
                val t = partObj.optString("text", "")
                if (t.isNotBlank()) {
                    if (partObj.optBoolean("thought", false)) {
                        if (fallbackSb.isNotEmpty()) fallbackSb.append(" ")
                        fallbackSb.append(t.trim())
                    } else {
                        if (sb.isNotEmpty()) sb.append(" ")
                        sb.append(t.trim())
                    }
                }
            }
            val chosen = if (sb.isNotEmpty()) sb.toString() else fallbackSb.toString()
            chosen.replace("**", "").replace("*", "").trim()
        } catch (_: Exception) {
            null
        }
    }
}
