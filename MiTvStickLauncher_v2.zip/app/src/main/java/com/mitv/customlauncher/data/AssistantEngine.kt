package com.mitv.customlauncher.data

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

sealed interface AssistantState {
    data object Idle : AssistantState
    data object Listening : AssistantState
    data object Processing : AssistantState
    data class Result(val text: String) : AssistantState
    data class Error(val code: String) : AssistantState
}

interface AssistantEngine {
    val state: StateFlow<AssistantState>
    fun startSession()
    fun cancelSession()
}

class FakeAssistantEngine(
    private val scope: CoroutineScope,
    private val demoReplyText: String
) : AssistantEngine {

    private val _state = MutableStateFlow<AssistantState>(AssistantState.Idle)
    override val state: StateFlow<AssistantState> = _state.asStateFlow()

    private var sessionJob: Job? = null

    override fun startSession() {
        sessionJob?.cancel()
        sessionJob = scope.launch {
            _state.value = AssistantState.Listening
            delay(1800L)
            _state.value = AssistantState.Processing
            delay(1000L)
            _state.value = AssistantState.Result(demoReplyText)
        }
    }

    override fun cancelSession() {
        sessionJob?.cancel()
        sessionJob = null
        _state.value = AssistantState.Idle
    }
}
