package com.mitv.customlauncher.data

import android.app.ActivityManager
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.isActive
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import android.graphics.Color
import kotlinx.coroutines.delay
import java.nio.ByteOrder
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import kotlin.math.sqrt
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.speech.tts.TextToSpeech
import com.mitv.customlauncher.service.DynamicIslandBus
import com.mitv.customlauncher.service.RemoteConsoleServer
import com.mitv.customlauncher.service.ShellKeyController
import android.util.Base64
import android.util.Log
import android.view.KeyEvent
import com.mitv.customlauncher.service.TvUiControllerBus
import com.mitv.customlauncher.service.MediaStateBus
import com.mitv.customlauncher.service.NavSoundPlayer
import com.mitv.customlauncher.service.VolumeHudBus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

sealed interface AssistantState {
    data object Idle : AssistantState
    data object Listening : AssistantState
    data object Processing : AssistantState
    data class Result(val text: String) : AssistantState
    data class Error(val code: String) : AssistantState
}

interface AssistantEngine {
    val state: StateFlow<AssistantState>
    fun startSession()
    fun cancelSession()
}

class FakeAssistantEngine(
    private val scope: CoroutineScope,
    private val demoReplyText: String
) : AssistantEngine {
    private val _state = MutableStateFlow<AssistantState>(AssistantState.Idle)
    override val state: StateFlow<AssistantState> = _state.asStateFlow()
    override fun startSession() {}
    override fun cancelSession() {
        _state.value = AssistantState.Idle
    }
}

/**
 * Исполнитель глубоких действий Android TV, вызываемых напрямую ИИ Gemini:
 * - запуск треков и артистов в Spotify (MEDIA_PLAY_FROM_SEARCH + spotify:search + авто-PLAY)
 * - запуск стримов на Kick (kalatay3 и любые другие каналы)
 * - смена цвета лаунчера/ползунка/островка на любой HEX-цвет
 * - управление громкостью, плеером, памятью, приложениями и звуком щелчков пульта
 */
object LocalVoiceCommandRouter {

    data class LocalActionResult(
        val confirmationText: String,
        val isQuickCommand: Boolean = true
    )

    var onThemeColorChanged: ((String) -> Unit)? = null
    var onVolumeChangedCallback: (() -> Unit)? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    /**
     * В v3.8 100% всех голосовых запросов обрабатываются напрямую через Gemini,
     * чтобы идеально понимать украинский, русский, суржик и английский без жёстких шаблонов!
     */
    fun tryExecuteLocalCommand(context: Context, rawText: String): LocalActionResult? {
        return null
    }

    fun executeSystemAudioCommand(context: Context, actionType: String) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val curVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val curPct = ((curVol * 100f) / maxVol).toInt().coerceIn(0, 100)

        when (actionType) {
            "VOL_UP" -> {
                val newPct = (curPct + 15).coerceAtMost(100)
                val targetVol = ((newPct * maxVol) / 100f + 0.5f).toInt().coerceIn((curVol + 1).coerceAtMost(maxVol), maxVol)
                try {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
                } catch (_: Exception) {
                }
                mainHandler.post {
                    onVolumeChangedCallback?.invoke()
                    VolumeHudBus.notifyVolumeChanged()
                }
            }
            "VOL_DOWN" -> {
                val newPct = (curPct - 15).coerceAtLeast(0)
                val targetVol = ((newPct * maxVol) / 100f).toInt().coerceIn(0, (curVol - 1).coerceAtLeast(0))
                try {
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
                } catch (_: Exception) {
                }
                mainHandler.post {
                    onVolumeChangedCallback?.invoke()
                    VolumeHudBus.notifyVolumeChanged()
                }
            }
            "MUTE" -> {
                try {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
                } catch (_: Exception) {
                }
                mainHandler.post {
                    onVolumeChangedCallback?.invoke()
                    VolumeHudBus.notifyVolumeChanged()
                }
            }
            "UNMUTE" -> {
                try {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
                } catch (_: Exception) {
                }
                mainHandler.post {
                    onVolumeChangedCallback?.invoke()
                    VolumeHudBus.notifyVolumeChanged()
                }
            }
            "PAUSE", "PLAY" -> {
                MediaStateBus.dispatchTransportAction("PLAY_PAUSE", am)
                Thread { ShellKeyController.sendKeyEvent(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) }.start()
            }
            "NEXT" -> {
                MediaStateBus.dispatchTransportAction("NEXT", am)
                Thread { ShellKeyController.sendKeyEvent(KeyEvent.KEYCODE_MEDIA_NEXT) }.start()
            }
            "PREV" -> {
                MediaStateBus.dispatchTransportAction("PREV", am)
                Thread { ShellKeyController.sendKeyEvent(KeyEvent.KEYCODE_MEDIA_PREVIOUS) }.start()
            }
        }
    }

    fun applyThemeColorEverywhere(context: Context, hex: String) {
        val cleanHex = if (hex.startsWith("#")) hex else "#$hex"
        try {
            android.graphics.Color.parseColor(cleanHex)
        } catch (_: Exception) {
            return
        }
        AppLauncher(context.applicationContext).saveAccentColorHex(cleanHex)
        mainHandler.post {
            onThemeColorChanged?.invoke(cleanHex)
            DynamicIslandBus.notifyAccentColorChanged(cleanHex)
        }
    }

    fun setVolumePercent(context: Context, targetPct: Int) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val clamped = targetPct.coerceIn(0, 100)
        val targetVol = ((clamped * maxVol) / 100f + 0.5f).toInt().coerceIn(0, maxVol)
        try {
            if (clamped > 0) {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
            }
            am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
        } catch (_: Exception) {
        }
        mainHandler.post {
            onVolumeChangedCallback?.invoke()
            VolumeHudBus.notifyVolumeChanged()
        }
    }

    fun launchKickStream(context: Context, channelSlug: String) {
        val cleanSlug = channelSlug.trim().removePrefix("https://kick.com/").removePrefix("kick.com/").trim('/')
        val url = if (cleanSlug.isNotEmpty()) "https://kick.com/$cleanSlug" else "https://kick.com"
        val appLauncher = AppLauncher(context.applicationContext)
        val pm = context.packageManager
        val allApps = appLauncher.getInstalledApps()

        val kickApp = allApps.firstOrNull {
            val p = it.packageName.lowercase()
            val l = it.label.lowercase()
            p.contains("kick") || l == "kick" || l.startsWith("kick:") || l.startsWith("kick ")
        }

        if (kickApp != null) {
            val pkg = kickApp.packageName
            // 1. Проверяем, поддерживает ли установленная версия Kick прямые ссылки (на телефоне — да, на Android TV — нет)
            val candidateUris = listOf(
                Uri.parse(url),
                Uri.parse("kick://channel/$cleanSlug"),
                Uri.parse("kick://$cleanSlug")
            )
            for (u in candidateUris) {
                try {
                    val deepIntent = Intent(Intent.ACTION_VIEW, u).apply {
                        setPackage(pkg)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    @Suppress("DEPRECATION")
                    if (pm.queryIntentActivities(deepIntent, 0).isNotEmpty()) {
                        context.startActivity(deepIntent)
                        return
                    }
                } catch (_: Exception) {
                }
            }

            // 2. Проверяем поддержку системного ACTION_SEARCH внутри Kick
            if (cleanSlug.isNotEmpty()) {
                try {
                    val searchIntent = Intent(Intent.ACTION_SEARCH).apply {
                        setPackage(pkg)
                        putExtra(SearchManager.QUERY, cleanSlug)
                        putExtra("query", cleanSlug)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    @Suppress("DEPRECATION")
                    if (pm.queryIntentActivities(searchIntent, 0).isNotEmpty()) {
                        context.startActivity(searchIntent)
                        return
                    }
                } catch (_: Exception) {
                }
            }

            // 3. ТВ-версия Kick («Kick: стриминг в прямом эфире»): запускаем само приложение Kick без белого окна ошибки
            // и включаем ИИ-автопоиск стримера через наш AccessibilityService!
            if (appLauncher.launchPackage(pkg)) {
                if (cleanSlug.isNotEmpty()) {
                    TvUiControllerBus.scheduleInAppSearch(pkg, cleanSlug)
                }
                return
            }
        }

        launchUrlInTvBrowser(context, url)
    }

    fun launchUrlInTvBrowser(context: Context, url: String) {
        val finalUrl = if (url.startsWith("http://") || url.startsWith("https://")) url else "https://$url"
        val uri = Uri.parse(finalUrl)
        val appLauncher = AppLauncher(context.applicationContext)
        val pm = context.packageManager
        val allApps = appLauncher.getInstalledApps()

        val browserCandidate = allApps.firstOrNull {
            val p = it.packageName.lowercase()
            val l = it.label.lowercase()
            p.contains("browser") || p.contains("chrome") || p.contains("tvbro") ||
                p.contains("puffin") || p.contains("firefox") || p.contains("opera") ||
                l.contains("браузер") || l.contains("browser")
        }

        if (browserCandidate != null) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                    setPackage(browserCandidate.packageName)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return
            } catch (_: Exception) {
            }
        }

        try {
            val generic = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            @Suppress("DEPRECATION")
            val handlers = pm.queryIntentActivities(generic, 0).filter {
                !it.activityInfo.packageName.lowercase().contains("tv.fw.browsable") &&
                    !it.activityInfo.name.lowercase().contains("stub")
            }
            if (handlers.isNotEmpty()) {
                context.startActivity(generic)
            }
        } catch (_: Exception) {
        }
    }

    fun launchSpotifyTrackOrArtist(context: Context, rawQuery: String) {
        val query = rawQuery.trim()
        if (query.isEmpty()) return
        val appLauncher = AppLauncher(context.applicationContext)
        val allApps = appLauncher.getInstalledApps()
        val spotifyApp = allApps.firstOrNull {
            val p = it.packageName.lowercase()
            p.contains("spotify") || it.label.lowercase().contains("spotify")
        }
        val spotifyPkg = spotifyApp?.packageName

        if (spotifyPkg != null) {
            MediaStateBus.seedTrackFromQuery(context, spotifyPkg, query)

            try {
                val playIntent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
                    setPackage(spotifyPkg)
                    putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                    putExtra(SearchManager.QUERY, query)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                context.startActivity(playIntent)
                scheduleSpotifyAutoPlayKick(context)
                return
            } catch (_: Exception) {
            }

            try {
                val uriIntent = Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:${Uri.encode(query)}")).apply {
                    setPackage(spotifyPkg)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                context.startActivity(uriIntent)
                scheduleSpotifyAutoPlayKick(context)
                return
            } catch (_: Exception) {
            }

            try {
                val searchIntent = Intent(Intent.ACTION_SEARCH).apply {
                    setPackage(spotifyPkg)
                    putExtra(SearchManager.QUERY, query)
                    putExtra("query", query)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                context.startActivity(searchIntent)
                scheduleSpotifyAutoPlayKick(context)
                return
            } catch (_: Exception) {
            }

            appLauncher.launchPackage(spotifyPkg)
            scheduleSpotifyAutoPlayKick(context)
            return
        }

        launchYouTubeSearch(context, query)
    }

    private fun scheduleSpotifyAutoPlayKick(context: Context) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        mainHandler.postDelayed({
            try {
                val now = SystemClock.uptimeMillis()
                val down = KeyEvent(now, now, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY, 0)
                val up = KeyEvent(now, now, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY, 0)
                am.dispatchMediaKeyEvent(down)
                am.dispatchMediaKeyEvent(up)
            } catch (_: Exception) {
            }
        }, 2000L)
    }

    fun launchYouTubeSearch(context: Context, query: String) {
        val cleanQuery = query.trim()
        val appLauncher = AppLauncher(context.applicationContext)
        val apps = appLauncher.getInstalledApps()
        val ytApp = apps.firstOrNull {
            val p = it.packageName.lowercase()
            p.contains("youtube.tv") || p.contains("smarttube") || p.contains("youtube")
        }
        val targetPkg = ytApp?.packageName ?: "com.google.android.youtube.tv"
        if (cleanQuery.isEmpty()) {
            appLauncher.launchPackage(targetPkg)
            return
        }
        try {
            val searchIntent = Intent(Intent.ACTION_SEARCH).apply {
                if (ytApp != null) setPackage(ytApp.packageName)
                putExtra(SearchManager.QUERY, cleanQuery)
                putExtra("query", cleanQuery)
                putExtra("va_play_first_result", true)
                putExtra(Intent.EXTRA_REFERRER, Uri.parse("android-app://com.google.android.katniss"))
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            context.startActivity(searchIntent)
            TvUiControllerBus.scheduleYouTubeAutoPlay(targetPkg, cleanQuery)
            return
        } catch (_: Exception) {
        }
        try {
            val webUri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(cleanQuery))
            val viewIntent = Intent(Intent.ACTION_VIEW, webUri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(viewIntent)
            TvUiControllerBus.scheduleYouTubeAutoPlay(targetPkg, cleanQuery)
        } catch (_: Exception) {
        }
    }

    fun openSystemSettingsAction(context: Context, action: String) {
        try {
            val intent = Intent(action).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            try {
                val fallback = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(fallback)
            } catch (_: Exception) {
            }
        }
    }

    fun cleanRamBackground(context: Context) {
        try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return
            val apps = AppLauncher(context.applicationContext).getInstalledApps()
            for (app in apps) {
                val p = app.packageName.lowercase()
                if (app.packageName != context.packageName &&
                    !p.contains("spotify") &&
                    !p.contains("mediashell") &&
                    !p.contains("soundcloud")
                ) {
                    am.killBackgroundProcesses(app.packageName)
                }
            }
        } catch (_: Exception) {
        }
    }
}

/**
 * 100% Gemini-ассистент (2.5 & 3.8):
 * - Слушает живой голос напрямую в формате WAV (идеально понимает украинский, русский, суржик и английский!)
 * - Использует рабочий ключ XOR_PROTECTED_KEY (без ошибки 401!)
 * - Сам управляет Spotify, Kick, YouTube, цветами лаунчера, приложениями и звуком ТВ
 */
/**
 * Голосовой синтезатор речи ассистента (TTS) с мгновенным откликом,
 * автоопределением украинского/русского/английского языка и приглушением фоновой музыки (Audio Ducking).
 */
/**
 * Облачный голосовой синтезатор речи Gemini TTS (gemini-2.5-flash-preview-tts):
 * - 0 МБ фонового потребления ОЗУ (работает без системного com.google.android.tts напрямую через легковесный AudioTrack)
 * - 5 живых нейронных голосов на выбор: Puck, Charon, Fenrir (мужские) и Kore, Aoede (женские)
 * - Вычисляет реальную амплитуду звуковой волны (currentVoiceWaveLevel) каждые 40 мс для 60 FPS анимации полосок Dynamic Island
 */
/**
 * Контроллер умной Wi-Fi LED-ленты Tuya Smart Life (OpenAPI v2.0 HMAC-SHA256):
 * - 360° полный цветовой спектр HSV (Оттенок 0..360°, Насыщенность 10..100%, Яркость 10..100%)
 * - Автоопределение поддерживаемых датапоинтов ленты (v2 `colour_data_v2` / `bright_value_v2` и v1 `colour_data` / `bright_value`)
 * - 12 выверенных студийных пресетов оттенков + режим тёплого белого света
 * - 4 динамических режима (Радуга, Дыхание, Вечеринка, Ночник)
 * - Режим синхронизации с акцентным цветом темы лаунчера (Ambilight)
 */
data class LedSwatchPreset(
    val name: String,
    val hexColor: String,
    val hue: Int,
    val satPct: Int,
    val brightPct: Int = 100,
    val isWarmWhite: Boolean = false
)

object TuyaSmartHomeController {

    private const val TAG = "TuyaLauncher"
    private const val PREF_LED_IS_ON = "pref_tuya_led_is_on"
    private const val PREF_LED_HUE = "pref_tuya_led_hue"
    private const val PREF_LED_SAT = "pref_tuya_led_sat"
    private const val PREF_LED_BRIGHT = "pref_tuya_led_bright"
    private const val PREF_LED_SYNC_THEME = "pref_tuya_led_sync_theme"
    private const val PREF_LED_MODE_LABEL = "pref_tuya_led_mode_label"
    private const val PREF_LEARNED_FMT_NAME = "pref_tuya_learned_fmt_v58"
    private const val PREF_LEARNED_WITH_MODE = "pref_tuya_learned_mode_v58"
    private const val PREF_DISCOVERED_SWITCH_CODE = "pref_tuya_switch_code_v58"

    private val apiHosts = listOf(
        "https://openapi.tuyaeu.com",
        "https://openapi-weaz.tuyaeu.com"
    )

    val CURATED_SWATCHES: List<LedSwatchPreset> = listOf(
        // Ряд 1: Неон и киберпанк (выверенные углы круга Tuya Smart Life)
        LedSwatchPreset("Кибер", "#00F0FF", hue = 184, satPct = 100),
        LedSwatchPreset("Океан", "#38BDF8", hue = 200, satPct = 98),
        LedSwatchPreset("Сапфир", "#3B82F6", hue = 224, satPct = 100),
        LedSwatchPreset("Индиго", "#818CF8", hue = 248, satPct = 94),
        LedSwatchPreset("Фиолет", "#C084FC", hue = 271, satPct = 85),
        LedSwatchPreset("Фуксия", "#F472B6", hue = 324, satPct = 95),
        // Ряд 2: Уют, природа и кино
        LedSwatchPreset("Малина", "#FB7185", hue = 336, satPct = 100),
        LedSwatchPreset("Закат", "#FB923C", hue = 20, satPct = 100),
        LedSwatchPreset("Янтарь", "#FBBF24", hue = 38, satPct = 100),
        LedSwatchPreset("Лайм", "#A3E635", hue = 85, satPct = 95),
        LedSwatchPreset("Изумруд", "#34D399", hue = 145, satPct = 96),
        LedSwatchPreset("Тёплый", "#FDE68A", hue = 34, satPct = 28, isWarmWhite = true)
    )

    private enum class ColourFormat {
        V2_OBJECT,
        V2_STRING,
        V1_OBJECT,
        V1_STRING,
        HEX12_LOWER,
        HEX12_UPPER
    }

    private class DeviceCaps(
        val switchCode: String,
        val colourCode: String?,
        val sMax: Int,
        val vMax: Int,
        val hasWorkMode: Boolean
    )

    private sealed class PendingLedAction {
        data class Power(val turnOn: Boolean) : PendingLedAction()
        data class ColorHsv(val hue: Int, val satPct: Int, val brightPct: Int) : PendingLedAction()
    }

    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val tokenLock = Any()
    private val queueLock = Any()

    @Volatile
    private var cachedHost: String = "https://openapi.tuyaeu.com"

    @Volatile
    private var cachedAccessToken: String = ""

    @Volatile
    private var tokenExpiresAtWallMs: Long = 0L

    @Volatile
    private var serverTimeOffsetMs: Long = 0L

    @Volatile
    private var discoveredSwitchCode: String = "switch_led"

    @Volatile
    private var cachedDeviceCaps: DeviceCaps? = null

    @Volatile
    private var learnedFormatPair: Pair<ColourFormat, Boolean>? = null

    @Volatile
    private var prefsLoadedIntoRam: Boolean = false

    @Volatile
    private var pendingAction: PendingLedAction? = null

    @Volatile
    private var isQueueWorkerRunning: Boolean = false

    @Volatile
    private var effectCycleJob: Job? = null

    @Volatile
    private var warmupStarted: Boolean = false

    @Volatile
    private var lastUserCommandWallMs: Long = 0L

    @Volatile
    var onStateUpdatedUiCallback: (() -> Unit)? = null

    private fun notifyUi() {
        mainHandler.post {
            onStateUpdatedUiCallback?.invoke()
        }
    }

    private fun loadCachedRoutingPrefsIfNeeded(context: Context) {
        if (prefsLoadedIntoRam) return
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val savedFmtName = prefs.getString(PREF_LEARNED_FMT_NAME, "").orEmpty()
        val savedWithMode = prefs.getBoolean(PREF_LEARNED_WITH_MODE, true)
        val savedSw = prefs.getString(PREF_DISCOVERED_SWITCH_CODE, "").orEmpty()
        if (savedSw.isNotEmpty()) discoveredSwitchCode = savedSw
        if (savedFmtName.isNotEmpty()) {
            try {
                val fmt = ColourFormat.valueOf(savedFmtName)
                learnedFormatPair = fmt to savedWithMode
            } catch (_: Exception) {
            }
        }
        prefsLoadedIntoRam = true
    }

    private fun saveLearnedFormat(context: Context?, fmt: ColourFormat, withMode: Boolean) {
        learnedFormatPair = fmt to withMode
        if (context != null) {
            val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit()
                .putString(PREF_LEARNED_FMT_NAME, fmt.name)
                .putBoolean(PREF_LEARNED_WITH_MODE, withMode)
                .apply()
        }
    }

    fun ensureWarmupStarted(context: Context? = null) {
        if (context != null) {
            loadCachedRoutingPrefsIfNeeded(context)
            ScheduledTaskManager.ensureStarted(context)
        }
        if (warmupStarted) return
        warmupStarted = true
        ioScope.launch {
            try {
                ensureAccessToken(forceRefresh = false)
                loadDeviceSpecifications()
                inspectDeviceStatus(context)
            } catch (_: Exception) {
            }
            while (isActive) {
                delay(10 * 60 * 1000L)
                try {
                    val now = System.currentTimeMillis()
                    if (cachedAccessToken.isEmpty() || now > tokenExpiresAtWallMs - 300_000L) {
                        ensureAccessToken(forceRefresh = false)
                    }
                    if (cachedDeviceCaps == null) {
                        loadDeviceSpecifications()
                    }
                } catch (_: Exception) {
                }
            }
        }
    }

    /**
     * Точное чтение спецификаций ленты (один в один как в SmartTouchConsole TuyaController.kt):
     * определяет switchCode, colourCode (colour_data_v2 или colour_data), диапазоны sMax/vMax (1000 или 255) и наличие work_mode!
     */
    private suspend fun loadDeviceSpecifications(): DeviceCaps? {
        cachedDeviceCaps?.let { return it }
        val devId = LauncherConfig.TUYA_LED_DEVICE_ID
        val paths = listOf(
            "/v1.0/devices/$devId/specifications",
            "/v1.0/iot-03/devices/$devId/specification"
        )
        for (path in paths) {
            val resp = executeSignedTuyaRequest("GET", path, "") ?: continue
            if (!resp.optBoolean("success", false)) continue
            try {
                val resObj = resp.optJSONObject("result") ?: continue
                val functions = resObj.optJSONArray("functions") ?: JSONArray()
                var swCode = discoveredSwitchCode
                var colCode: String? = null
                var sMax = 1000
                var vMax = 1000
                var hasWorkMode = false
                for (i in 0 until functions.length()) {
                    val f = functions.optJSONObject(i) ?: continue
                    val code = f.optString("code", "")
                    when (code) {
                        "switch_led", "switch_led_1", "led_switch", "switch_1", "switch" -> {
                            swCode = code
                            discoveredSwitchCode = code
                        }
                        "work_mode" -> hasWorkMode = true
                        "colour_data_v2", "colour_data" -> {
                            if (colCode == null || code == "colour_data_v2") {
                                colCode = code
                                val valuesStr = f.optString("values", "{}")
                                val valuesJson = try { JSONObject(valuesStr) } catch (_: Exception) { JSONObject() }
                                val defMax = if (code == "colour_data_v2") 1000 else 255
                                sMax = valuesJson.optJSONObject("s")?.optInt("max", defMax) ?: defMax
                                vMax = valuesJson.optJSONObject("v")?.optInt("max", defMax) ?: defMax
                            }
                        }
                    }
                }
                if (colCode != null || functions.length() > 0) {
                    val caps = DeviceCaps(swCode, colCode, sMax, vMax, hasWorkMode)
                    cachedDeviceCaps = caps
                    return caps
                }
            } catch (_: Exception) {
            }
        }
        return null
    }

    fun isLedOn(context: Context): Boolean {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(PREF_LED_IS_ON, true)
    }

    fun getHue(context: Context): Int {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(PREF_LED_HUE, 184).coerceIn(0, 360)
    }

    fun getSaturationPct(context: Context): Int {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(PREF_LED_SAT, 100).coerceIn(10, 100)
    }

    fun getBrightnessPct(context: Context): Int {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(PREF_LED_BRIGHT, 100).coerceIn(10, 100)
    }

    fun isThemeSyncEnabled(context: Context): Boolean {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(PREF_LED_SYNC_THEME, false)
    }

    fun getCurrentModeLabel(context: Context): String {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(PREF_LED_MODE_LABEL, "")?.takeIf { it.isNotBlank() } ?: describeHueName(getHue(context))
    }

    fun findActiveSwatchIndex(context: Context): Int {
        val mode = getCurrentModeLabel(context)
        if (mode.startsWith("Режим:")) return -1
        val byName = CURATED_SWATCHES.indexOfFirst { it.name.equals(mode, ignoreCase = true) }
        if (byName >= 0) return byName
        val h = getHue(context)
        val s = getSaturationPct(context)
        if (s <= 42 && h in 20..52) {
            return CURATED_SWATCHES.indexOfFirst { it.isWarmWhite }
        }
        var bestIdx = -1
        var bestDist = 999
        for (i in CURATED_SWATCHES.indices) {
            val p = CURATED_SWATCHES[i]
            if (p.isWarmWhite) continue
            val rawDiff = kotlin.math.abs(h - p.hue)
            val dist = kotlin.math.min(rawDiff, 360 - rawDiff)
            if (dist <= 9 && dist < bestDist) {
                bestDist = dist
                bestIdx = i
            }
        }
        return bestIdx
    }

    fun getCurrentPreviewColorInt(context: Context): Int {
        val idx = findActiveSwatchIndex(context)
        if (idx in CURATED_SWATCHES.indices) {
            return try {
                Color.parseColor(CURATED_SWATCHES[idx].hexColor)
            } catch (_: Exception) {
                Color.parseColor("#00F0FF")
            }
        }
        val h = getHue(context).toFloat()
        val s = (getSaturationPct(context) / 100f).coerceIn(0.25f, 1f)
        return Color.HSVToColor(floatArrayOf(h, s, 0.96f))
    }

    fun describeHueName(hue: Int): String {
        val h = ((hue % 360) + 360) % 360
        return when (h) {
            in 0..12 -> "Алый"
            in 13..28 -> "Закат"
            in 29..48 -> "Янтарь"
            in 49..68 -> "Золото"
            in 69..105 -> "Лайм"
            in 106..158 -> "Изумруд"
            in 159..174 -> "Мята"
            in 175..194 -> "Кибер"
            in 195..214 -> "Океан"
            in 215..236 -> "Сапфир"
            in 237..264 -> "Индиго"
            in 265..298 -> "Фиолет"
            in 299..338 -> "Фуксия"
            else -> "Малина"
        }
    }

    private fun saveState(
        context: Context,
        isOn: Boolean? = null,
        hue: Int? = null,
        satPct: Int? = null,
        brightPct: Int? = null,
        syncTheme: Boolean? = null,
        modeLabel: String? = null
    ) {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val ed = prefs.edit()
        if (isOn != null) ed.putBoolean(PREF_LED_IS_ON, isOn)
        if (hue != null) ed.putInt(PREF_LED_HUE, ((hue % 360) + 360) % 360)
        if (satPct != null) ed.putInt(PREF_LED_SAT, satPct.coerceIn(10, 100))
        if (brightPct != null) ed.putInt(PREF_LED_BRIGHT, brightPct.coerceIn(10, 100))
        if (syncTheme != null) ed.putBoolean(PREF_LED_SYNC_THEME, syncTheme)
        if (modeLabel != null) ed.putString(PREF_LED_MODE_LABEL, modeLabel)
        ed.apply()
        notifyUi()
    }

    private fun enqueueLatestAction(context: Context, action: PendingLedAction) {
        val appCtx = context.applicationContext
        loadCachedRoutingPrefsIfNeeded(appCtx)
        lastUserCommandWallMs = System.currentTimeMillis()
        var shouldLaunchWorker = false
        synchronized(queueLock) {
            pendingAction = action
            if (!isQueueWorkerRunning) {
                isQueueWorkerRunning = true
                shouldLaunchWorker = true
            }
        }
        if (shouldLaunchWorker) {
            ioScope.launch {
                try {
                    while (true) {
                        val next = synchronized(queueLock) {
                            val a = pendingAction
                            pendingAction = null
                            if (a == null) {
                                isQueueWorkerRunning = false
                            }
                            a
                        } ?: break

                        when (next) {
                            is PendingLedAction.Power -> {
                                sendSwitchCommand(appCtx, next.turnOn)
                            }
                            is PendingLedAction.ColorHsv -> {
                                sendHsvColorCommand(appCtx, next.hue, next.satPct, next.brightPct)
                            }
                        }
                    }
                } finally {
                    synchronized(queueLock) {
                        isQueueWorkerRunning = false
                    }
                }
            }
        }
    }

    fun setThemeSyncEnabled(context: Context, enabled: Boolean, currentThemeHex: String? = null) {
        saveState(context, syncTheme = enabled)
        if (enabled && !currentThemeHex.isNullOrBlank()) {
            setHexColor(context, currentThemeHex, modeTitle = "Синхр. с темой")
        }
    }

    fun syncWithLauncherThemeIfNeeded(context: Context, hexColor: String) {
        if (isThemeSyncEnabled(context)) {
            setHexColor(context, hexColor, modeTitle = "Синхр. с темой")
        }
    }

    fun togglePower(context: Context): Boolean {
        val target = !isLedOn(context)
        setPower(context, target)
        return target
    }

    fun setPower(context: Context, turnOn: Boolean) {
        val appCtx = context.applicationContext
        effectCycleJob?.cancel()
        effectCycleJob = null
        saveState(appCtx, isOn = turnOn)
        enqueueLatestAction(appCtx, PendingLedAction.Power(turnOn))
    }

    fun stepHueByDelta(context: Context, deltaDeg: Int, immediate: Boolean = false) {
        val appCtx = context.applicationContext
        effectCycleJob?.cancel()
        effectCycleJob = null
        val nextHue = (((getHue(appCtx) + deltaDeg) % 360) + 360) % 360
        val sat = getSaturationPct(appCtx).coerceAtLeast(85)
        val bright = getBrightnessPct(appCtx)
        saveState(appCtx, isOn = true, hue = nextHue, satPct = sat, modeLabel = describeHueName(nextHue))
        enqueueLatestAction(appCtx, PendingLedAction.ColorHsv(nextHue, sat, bright))
    }

    fun stepBrightnessByDelta(context: Context, deltaPct: Int) {
        val appCtx = context.applicationContext
        val nextBright = (getBrightnessPct(appCtx) + deltaPct).coerceIn(10, 100)
        val hue = getHue(appCtx)
        val sat = getSaturationPct(appCtx)
        saveState(appCtx, isOn = true, brightPct = nextBright)
        enqueueLatestAction(appCtx, PendingLedAction.ColorHsv(hue, sat, nextBright))
    }

    fun cycleBrightnessPreset(context: Context): Int {
        val cur = getBrightnessPct(context)
        val next = when {
            cur < 25 -> 25
            cur < 50 -> 50
            cur < 75 -> 75
            cur < 100 -> 100
            else -> 25
        }
        setBrightnessPercent(context, next)
        return next
    }

    fun setBrightnessPercent(context: Context, pct: Int) {
        val appCtx = context.applicationContext
        val cleanPct = pct.coerceIn(5, 100)
        val hue = getHue(appCtx)
        val sat = getSaturationPct(appCtx)
        saveState(appCtx, isOn = true, brightPct = cleanPct)
        enqueueLatestAction(appCtx, PendingLedAction.ColorHsv(hue, sat, cleanPct))
    }

    fun stepSaturationByDelta(context: Context, deltaPct: Int) {
        val appCtx = context.applicationContext
        effectCycleJob?.cancel()
        effectCycleJob = null
        val nextSat = (getSaturationPct(appCtx) + deltaPct).coerceIn(15, 100)
        val hue = getHue(appCtx)
        val bright = getBrightnessPct(appCtx)
        saveState(appCtx, isOn = true, satPct = nextSat)
        enqueueLatestAction(appCtx, PendingLedAction.ColorHsv(hue, nextSat, bright))
    }

    fun cycleSaturationPreset(context: Context): Int {
        val cur = getSaturationPct(context)
        val next = when {
            cur < 45 -> 60
            cur < 80 -> 100
            else -> 30
        }
        val appCtx = context.applicationContext
        val hue = getHue(appCtx)
        val bright = getBrightnessPct(appCtx)
        saveState(appCtx, isOn = true, satPct = next)
        enqueueLatestAction(appCtx, PendingLedAction.ColorHsv(hue, next, bright))
        return next
    }

    fun applySwatchPreset(context: Context, preset: LedSwatchPreset) {
        val appCtx = context.applicationContext
        effectCycleJob?.cancel()
        effectCycleJob = null
        val bright = getBrightnessPct(appCtx).coerceAtLeast(25)
        saveState(
            appCtx,
            isOn = true,
            hue = preset.hue,
            satPct = preset.satPct,
            brightPct = bright,
            modeLabel = preset.name
        )
        enqueueLatestAction(appCtx, PendingLedAction.ColorHsv(preset.hue, preset.satPct, bright))
    }

    fun setHexColor(context: Context, rawHex: String, modeTitle: String? = null) {
        val appCtx = context.applicationContext
        effectCycleJob?.cancel()
        effectCycleJob = null
        val cleanHex = if (rawHex.trim().startsWith("#")) rawHex.trim() else "#${rawHex.trim()}"
        val parsedColor = try {
            Color.parseColor(cleanHex)
        } catch (_: Exception) {
            Color.parseColor("#00F0FF")
        }
        val hsv = FloatArray(3)
        Color.colorToHSV(parsedColor, hsv)
        val h = hsv[0].toInt().coerceIn(0, 360)
        val s = (hsv[1] * 100f).toInt().coerceIn(15, 100)
        val b = getBrightnessPct(appCtx).coerceAtLeast(30)
        val label = modeTitle ?: describeHueName(h)
        saveState(appCtx, isOn = true, hue = h, satPct = s, brightPct = b, modeLabel = label)
        enqueueLatestAction(appCtx, PendingLedAction.ColorHsv(h, s, b))
    }

    fun activateDynamicScene(context: Context, sceneCode: String) {
        val appCtx = context.applicationContext
        loadCachedRoutingPrefsIfNeeded(appCtx)
        lastUserCommandWallMs = System.currentTimeMillis()
        effectCycleJob?.cancel()
        effectCycleJob = null

        val upper = sceneCode.trim().uppercase(Locale.US)
        when {
            upper.contains("NIGHT") || upper.contains("НОЧ") -> {
                saveState(appCtx, isOn = true, hue = 30, satPct = 85, brightPct = 15, modeLabel = "Режим: Ночник")
                enqueueLatestAction(appCtx, PendingLedAction.ColorHsv(30, 85, 15))
            }
            upper.contains("BREATH") || upper.contains("ДЫХ") -> {
                saveState(appCtx, isOn = true, modeLabel = "Режим: Дыхание")
                startSoftwareSceneLoop(appCtx, "BREATHE")
            }
            upper.contains("PARTY") || upper.contains("ВЕЧЕР") -> {
                saveState(appCtx, isOn = true, modeLabel = "Режим: Вечеринка")
                startSoftwareSceneLoop(appCtx, "PARTY")
            }
            else -> {
                saveState(appCtx, isOn = true, modeLabel = "Режим: Радуга")
                startSoftwareSceneLoop(appCtx, "RAINBOW")
            }
        }
    }

    private fun startSoftwareSceneLoop(context: Context, mode: String) {
        effectCycleJob?.cancel()
        effectCycleJob = ioScope.launch {
            var step = 0
            while (isActive && isLedOn(context)) {
                when (mode) {
                    "BREATHE" -> {
                        val h = getHue(context)
                        val b = if (step % 2 == 0) 95 else 22
                        enqueueLatestAction(context, PendingLedAction.ColorHsv(h, 95, b))
                        delay(2400L)
                    }
                    "PARTY" -> {
                        val partyHues = intArrayOf(184, 324, 271, 145, 20, 224)
                        val h = partyHues[step % partyHues.size]
                        enqueueLatestAction(context, PendingLedAction.ColorHsv(h, 100, 100))
                        delay(1400L)
                    }
                    else -> {
                        val h = (step * 36) % 360
                        enqueueLatestAction(context, PendingLedAction.ColorHsv(h, 100, 95))
                        delay(2000L)
                    }
                }
                step++
            }
        }
    }

    fun refreshStatusFromCloudAsync(context: Context) {
        val appCtx = context.applicationContext
        loadCachedRoutingPrefsIfNeeded(appCtx)
        ensureWarmupStarted(appCtx)
        ioScope.launch {
            inspectDeviceStatus(appCtx)
        }
    }

    private suspend fun inspectDeviceStatus(context: Context?) {
        val devId = LauncherConfig.TUYA_LED_DEVICE_ID
        val resp = executeSignedTuyaRequest("GET", "/v1.0/iot-03/devices/$devId/status", "") ?: return
        if (!resp.optBoolean("success", false)) return
        val arr = resp.optJSONArray("result") ?: return
        var foundSwitch: Boolean? = null
        for (i in 0 until arr.length()) {
            val item = arr.optJSONObject(i) ?: continue
            val code = item.optString("code", "")
            val rawVal = item.opt("value")
            if (code == "switch_led" || code == "switch_led_1" || code == "led_switch" || code == "switch") {
                discoveredSwitchCode = code
                if (rawVal is Boolean) foundSwitch = rawVal
            }
        }
        val sinceUserClickMs = System.currentTimeMillis() - lastUserCommandWallMs
        if (context != null && foundSwitch != null && sinceUserClickMs > 8_000L) {
            saveState(context, isOn = foundSwitch)
        }
    }

    private suspend fun sendSwitchCommand(context: Context, turnOn: Boolean): Boolean {
        val caps = loadDeviceSpecifications()
        val swCode = caps?.switchCode ?: discoveredSwitchCode
        val commands = JSONArray().put(JSONObject().put("code", swCode).put("value", turnOn))
        if (postDeviceCommands(commands)) {
            if (discoveredSwitchCode != swCode) {
                discoveredSwitchCode = swCode
                context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
                    .edit().putString(PREF_DISCOVERED_SWITCH_CODE, swCode).apply()
            }
            return true
        }
        for (altCode in listOf("switch_led", "switch_led_1", "switch", "led_switch")) {
            if (altCode == swCode) continue
            val altCmds = JSONArray().put(JSONObject().put("code", altCode).put("value", turnOn))
            if (postDeviceCommands(altCmds)) {
                discoveredSwitchCode = altCode
                return true
            }
        }
        return false
    }

    private fun buildColourPayload(
        switchCode: String,
        format: ColourFormat,
        h: Int,
        s: Int,
        v: Int,
        withMode: Boolean
    ): JSONArray {
        val arr = JSONArray()
        arr.put(JSONObject().put("code", switchCode).put("value", true))
        if (withMode) {
            arr.put(JSONObject().put("code", "work_mode").put("value", "colour"))
        }
        val hsv = JSONObject().put("h", h).put("s", s).put("v", v)
        when (format) {
            ColourFormat.V2_OBJECT -> arr.put(JSONObject().put("code", "colour_data_v2").put("value", hsv))
            ColourFormat.V2_STRING -> arr.put(JSONObject().put("code", "colour_data_v2").put("value", hsv.toString()))
            ColourFormat.V1_OBJECT -> arr.put(JSONObject().put("code", "colour_data").put("value", hsv))
            ColourFormat.V1_STRING -> arr.put(JSONObject().put("code", "colour_data").put("value", hsv.toString()))
            ColourFormat.HEX12_LOWER -> arr.put(
                JSONObject().put("code", "colour_data").put("value", String.format(Locale.US, "%04x%04x%04x", h, s, v))
            )
            ColourFormat.HEX12_UPPER -> arr.put(
                JSONObject().put("code", "colour_data").put("value", String.format(Locale.US, "%04X%04X%04X", h, s, v))
            )
        }
        return arr
    }

    private fun buildGuessPayload(
        switchCode: String,
        format: ColourFormat,
        h: Int,
        sPromille: Int,
        vPromille: Int,
        withMode: Boolean
    ): JSONArray {
        val isV1 = format == ColourFormat.V1_OBJECT || format == ColourFormat.V1_STRING
        val s = if (isV1) (sPromille * 255 / 1000).coerceAtLeast(1) else sPromille
        val v = if (isV1) (vPromille * 255 / 1000).coerceAtLeast(1) else vPromille
        return buildColourPayload(switchCode, format, h, s, v, withMode)
    }

    /**
     * Отправка цвета один в один по проверенному алгоритму из SmartTouchConsole TuyaController.kt:
     * 1. Если спецификация прочитана (/v1.0/devices/$id/specifications) — масштабируем s/v к sMax/vMax и шлём V2_OBJECT / V1_OBJECT (с фоллбэком на V2_STRING / V1_STRING).
     * 2. Иначе используем сохранённый learnedFormatPair или перебираем V2_OBJECT, V2_STRING, V1_OBJECT, V1_STRING, HEX12 (сохраняя первый сработавший формат навсегда).
     */
    private suspend fun sendHsvColorCommand(context: Context, hue: Int, satPct: Int, brightPct: Int): Boolean {
        val h = ((hue % 360) + 360) % 360
        val sPromille = (satPct * 10).coerceIn(10, 1000)
        val vPromille = (brightPct * 10).coerceIn(10, 1000)

        val caps = loadDeviceSpecifications()
        if (caps != null && caps.colourCode != null) {
            val isV2 = caps.colourCode == "colour_data_v2"
            val objFormat = if (isV2) ColourFormat.V2_OBJECT else ColourFormat.V1_OBJECT
            val strFormat = if (isV2) ColourFormat.V2_STRING else ColourFormat.V1_STRING
            val sDev = (sPromille * caps.sMax / 1000).coerceAtLeast(1)
            val vDev = (vPromille * caps.vMax / 1000).coerceAtLeast(1)

            // Сначала проверяем уже выученный вариант (если есть)
            learnedFormatPair?.let { (fmt, modeFlag) ->
                val learnedScaleS = if (fmt == ColourFormat.V1_OBJECT || fmt == ColourFormat.V1_STRING) (sPromille * 255 / 1000).coerceAtLeast(1) else sPromille
                val learnedScaleV = if (fmt == ColourFormat.V1_OBJECT || fmt == ColourFormat.V1_STRING) (vPromille * 255 / 1000).coerceAtLeast(1) else vPromille
                if (postDeviceCommands(buildColourPayload(caps.switchCode, fmt, h, learnedScaleS, learnedScaleV, modeFlag))) {
                    return true
                }
            }

            if (postDeviceCommands(buildColourPayload(caps.switchCode, objFormat, h, sDev, vDev, caps.hasWorkMode))) {
                saveLearnedFormat(context, objFormat, caps.hasWorkMode)
                return true
            }
            if (postDeviceCommands(buildColourPayload(caps.switchCode, strFormat, h, sDev, vDev, caps.hasWorkMode))) {
                saveLearnedFormat(context, strFormat, caps.hasWorkMode)
                return true
            }
            if (postDeviceCommands(buildColourPayload(caps.switchCode, objFormat, h, sDev, vDev, !caps.hasWorkMode))) {
                saveLearnedFormat(context, objFormat, !caps.hasWorkMode)
                return true
            }
            if (postDeviceCommands(buildColourPayload(caps.switchCode, strFormat, h, sDev, vDev, !caps.hasWorkMode))) {
                saveLearnedFormat(context, strFormat, !caps.hasWorkMode)
                return true
            }
        }

        val sw = caps?.switchCode ?: discoveredSwitchCode
        learnedFormatPair?.let { (fmt, withMode) ->
            if (postDeviceCommands(buildGuessPayload(sw, fmt, h, sPromille, vPromille, withMode))) {
                return true
            }
            learnedFormatPair = null
        }

        for (fmt in ColourFormat.values()) {
            for (withMode in listOf(true, false)) {
                if (postDeviceCommands(buildGuessPayload(sw, fmt, h, sPromille, vPromille, withMode))) {
                    saveLearnedFormat(context, fmt, withMode)
                    return true
                }
            }
        }
        return false
    }

    private suspend fun postDeviceCommands(commandsArray: JSONArray): Boolean {
        val devId = LauncherConfig.TUYA_LED_DEVICE_ID
        val body = JSONObject().put("commands", commandsArray).toString()
        val res = executeSignedTuyaRequest("POST", "/v1.0/iot-03/devices/$devId/commands", body)
        if (res != null && res.optBoolean("success", false)) {
            return true
        }
        val fallbackRes = executeSignedTuyaRequest("POST", "/v1.0/devices/$devId/commands", body)
        return fallbackRes != null && fallbackRes.optBoolean("success", false)
    }

    private suspend fun ensureAccessToken(forceRefresh: Boolean = false): String = withContext(Dispatchers.IO) {
        synchronized(tokenLock) {
            val nowWall = System.currentTimeMillis()
            if (!forceRefresh && cachedAccessToken.isNotEmpty() && nowWall < tokenExpiresAtWallMs) {
                return@withContext cachedAccessToken
            }

            val orderedHosts = mutableListOf<String>()
            orderedHosts.add(cachedHost)
            for (h in apiHosts) {
                if (h != cachedHost) orderedHosts.add(h)
            }

            val secret = LauncherConfig.TUYA_CLIENT_SECRET

            for (host in orderedHosts) {
                var tokenJson = executeRawSignedCall(
                    host = host,
                    method = "GET",
                    pathWithQuery = "/v1.0/token?grant_type=1",
                    body = "",
                    accessToken = "",
                    secretOverride = secret
                ) ?: continue

                val serverT = tokenJson.optLong("t", 0L)
                if (serverT > 1_600_000_000_000L) {
                    serverTimeOffsetMs = serverT - System.currentTimeMillis()
                }

                if (!tokenJson.optBoolean("success", false)) {
                    val retryJson = executeRawSignedCall(
                        host = host,
                        method = "GET",
                        pathWithQuery = "/v1.0/token?grant_type=1",
                        body = "",
                        accessToken = "",
                        secretOverride = secret
                    )
                    if (retryJson != null) {
                        tokenJson = retryJson
                    }
                }

                if (tokenJson.optBoolean("success", false)) {
                    val resObj = tokenJson.optJSONObject("result")
                    val tok = resObj?.optString("access_token", "").orEmpty()
                    val expSec = resObj?.optLong("expire_time", 7200L) ?: 7200L
                    if (tok.isNotEmpty()) {
                        cachedHost = host
                        cachedAccessToken = tok
                        val safeTtlMs = ((expSec - 120L).coerceIn(300L, 7000L)) * 1000L
                        tokenExpiresAtWallMs = System.currentTimeMillis() + safeTtlMs
                        return@withContext tok
                    }
                }
            }
            cachedAccessToken
        }
    }

    private suspend fun executeSignedTuyaRequest(
        method: String,
        pathWithQuery: String,
        body: String
    ): JSONObject? = withContext(Dispatchers.IO) {
        var token = ensureAccessToken(forceRefresh = false)
        if (token.isEmpty()) return@withContext null

        val secret = LauncherConfig.TUYA_CLIENT_SECRET
        var res = executeRawSignedCall(cachedHost, method, pathWithQuery, body, token, secret)

        if (res == null) {
            res = executeRawSignedCall(cachedHost, method, pathWithQuery, body, token, secret)
        } else if (!res.optBoolean("success", false)) {
            val serverT = res.optLong("t", 0L)
            if (serverT > 1_600_000_000_000L) {
                serverTimeOffsetMs = serverT - System.currentTimeMillis()
            }
            val code = res.optInt("code", 0)
            val msg = res.optString("msg", "").lowercase(Locale.US)
            if (code == 1010 || code == 1013 || code == 1004 || msg.contains("token") || msg.contains("sign")) {
                token = ensureAccessToken(forceRefresh = true)
                if (token.isNotEmpty()) {
                    res = executeRawSignedCall(cachedHost, method, pathWithQuery, body, token, secret)
                }
            }
        }
        res
    }

    private fun executeRawSignedCall(
        host: String,
        method: String,
        pathWithQuery: String,
        body: String,
        accessToken: String,
        secretOverride: String = ""
    ): JSONObject? {
        val clientId = LauncherConfig.TUYA_CLIENT_ID
        val secret = if (secretOverride.isNotEmpty()) secretOverride else LauncherConfig.TUYA_CLIENT_SECRET
        val timestamp = (System.currentTimeMillis() + serverTimeOffsetMs).toString()

        val bodyBytes = body.toByteArray(Charsets.UTF_8)
        val contentSha256 = sha256HexLower(bodyBytes)
        val stringToSign = "$method\n$contentSha256\n\n$pathWithQuery"
        val payloadToSign = if (accessToken.isEmpty()) {
            "$clientId$timestamp$stringToSign"
        } else {
            "$clientId$accessToken$timestamp$stringToSign"
        }
        val signUpper = hmacSha256HexUpper(payloadToSign, secret)

        var conn: HttpURLConnection? = null
        return try {
            val connObj = (URL("$host$pathWithQuery").openConnection() as HttpURLConnection).apply {
                requestMethod = method
                connectTimeout = 2800
                readTimeout = 3500
                doInput = true
                useCaches = false
                setRequestProperty("Connection", "keep-alive")
                setRequestProperty("client_id", clientId)
                setRequestProperty("sign", signUpper)
                setRequestProperty("t", timestamp)
                setRequestProperty("sign_method", "HMAC-SHA256")
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                if (accessToken.isNotEmpty()) {
                    setRequestProperty("access_token", accessToken)
                }
                if (method == "POST" || method == "PUT") {
                    doOutput = true
                }
            }
            conn = connObj
            if (method == "POST" || method == "PUT") {
                connObj.outputStream.use { os ->
                    os.write(bodyBytes)
                    os.flush()
                }
            }
            val code = connObj.responseCode
            val stream = if (code in 200..299) connObj.inputStream else connObj.errorStream
            val respText = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (respText.isNotBlank()) JSONObject(respText) else null
        } catch (e: Exception) {
            try {
                conn?.disconnect()
            } catch (_: Exception) {
            }
            null
        }
    }

    private fun sha256HexLower(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        val sb = StringBuilder(digest.size * 2)
        for (b in digest) {
            sb.append(String.format(Locale.US, "%02x", b.toInt() and 0xFF))
        }
        return sb.toString()
    }

    private fun hmacSha256HexUpper(data: String, secret: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        val keySpec = SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256")
        mac.init(keySpec)
        val raw = mac.doFinal(data.toByteArray(Charsets.UTF_8))
        val sb = StringBuilder(raw.size * 2)
        for (b in raw) {
            sb.append(String.format(Locale.US, "%02X", b.toInt() and 0xFF))
        }
        return sb.toString()
    }
}

/**
 * Долгосрочная энергонезависимая память ИИ (0 МБ фонового потребления ОЗУ):
 * хранит заметки, факты, коды и привычки пользователя в SharedPreferences и передаёт их в промпт Gemini.
 */
object AiMemoryStore {
    private const val PREF_MEMORY_JSON = "pref_ai_long_term_memory_v58"

    fun rememberFact(context: Context, rawFact: String) {
        val clean = rawFact.trim()
        if (clean.isEmpty()) return
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val arr = try {
            JSONArray(prefs.getString(PREF_MEMORY_JSON, "[]") ?: "[]")
        } catch (_: Exception) {
            JSONArray()
        }
        val list = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            val item = arr.optString(i, "").trim()
            if (item.isNotEmpty() && !item.equals(clean, ignoreCase = true)) {
                list.add(item)
            }
        }
        list.add(clean)
        while (list.size > 30) {
            list.removeAt(0)
        }
        val outArr = JSONArray()
        for (s in list) outArr.put(s)
        prefs.edit().putString(PREF_MEMORY_JSON, outArr.toString()).apply()
    }

    fun forgetFact(context: Context, keywordOrAll: String) {
        val kw = keywordOrAll.trim().lowercase(Locale.ROOT)
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        if (kw.isEmpty() || kw == "all" || kw == "все" || kw == "всё") {
            prefs.edit().putString(PREF_MEMORY_JSON, "[]").apply()
            return
        }
        val arr = try {
            JSONArray(prefs.getString(PREF_MEMORY_JSON, "[]") ?: "[]")
        } catch (_: Exception) {
            JSONArray()
        }
        val outArr = JSONArray()
        for (i in 0 until arr.length()) {
            val item = arr.optString(i, "").trim()
            if (item.isNotEmpty() && !item.lowercase(Locale.ROOT).contains(kw)) {
                outArr.put(item)
            }
        }
        prefs.edit().putString(PREF_MEMORY_JSON, outArr.toString()).apply()
    }

    fun getMemoryPromptBlock(context: Context): String {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val arr = try {
            JSONArray(prefs.getString(PREF_MEMORY_JSON, "[]") ?: "[]")
        } catch (_: Exception) {
            JSONArray()
        }
        if (arr.length() == 0) return ""
        val items = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            val s = arr.optString(i, "").trim()
            if (s.isNotEmpty()) items.add("- $s")
        }
        if (items.isEmpty()) return ""
        return "\nДОЛГОСРОЧНАЯ ПАМЯТЬ ПОЛЬЗОВАТЕЛЯ (используй эти сохранённые факты при ответах):\n" +
            items.joinToString("\n") + "\n"
    }
}

/**
 * Планировщик отложенных голосовых напоминаний и умных команд через время (0 МБ лишней ОЗУ):
 * - Работает поверх любого приложения (YouTube, Kick, фильм) и в режиме ожидания
 * - При наступлении времени напоминания выдвигает Dynamic Island, приглушает звук ТВ и озвучивает напоминание живым голосом Gemini TTS!
 * - При наступлении времени отложенной команды (например, «включи ленту через 20 минут») сам выполняет команду.
 */
object ScheduledTaskManager {
    private const val PREF_TASKS_JSON = "pref_ai_scheduled_tasks_v58"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val lock = Any()
    @Volatile
    private var loopStarted = false

    fun ensureStarted(context: Context) {
        if (loopStarted) return
        loopStarted = true
        val appCtx = context.applicationContext
        scope.launch {
            while (isActive) {
                try {
                    checkAndFireDueTasks(appCtx)
                } catch (_: Exception) {
                }
                delay(2000L)
            }
        }
    }

    fun scheduleVoiceReminder(context: Context, delaySeconds: Long, reminderText: String) {
        val cleanText = reminderText.trim()
        if (cleanText.isEmpty()) return
        val triggerAtMs = System.currentTimeMillis() + (delaySeconds.coerceAtLeast(3L) * 1000L)
        addTask(context, type = "REMIND", triggerAtMs = triggerAtMs, payload = cleanText)
    }

    fun scheduleDelayedCommand(context: Context, delaySeconds: Long, commandSpec: String) {
        val cleanSpec = commandSpec.trim()
        if (cleanSpec.isEmpty()) return
        val triggerAtMs = System.currentTimeMillis() + (delaySeconds.coerceAtLeast(3L) * 1000L)
        addTask(context, type = "CMD", triggerAtMs = triggerAtMs, payload = cleanSpec)
    }

    private fun addTask(context: Context, type: String, triggerAtMs: Long, payload: String) {
        val appCtx = context.applicationContext
        ensureStarted(appCtx)
        synchronized(lock) {
            val prefs = appCtx.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            val arr = try {
                JSONArray(prefs.getString(PREF_TASKS_JSON, "[]") ?: "[]")
            } catch (_: Exception) {
                JSONArray()
            }
            arr.put(
                JSONObject().apply {
                    put("type", type)
                    put("triggerAtMs", triggerAtMs)
                    put("payload", payload)
                }
            )
            prefs.edit().putString(PREF_TASKS_JSON, arr.toString()).apply()
        }
    }

    private fun checkAndFireDueTasks(context: Context) {
        val now = System.currentTimeMillis()
        val dueList = mutableListOf<Pair<String, String>>()
        synchronized(lock) {
            val prefs = context.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            val raw = prefs.getString(PREF_TASKS_JSON, "[]") ?: "[]"
            if (raw == "[]") return
            val arr = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
            if (arr.length() == 0) return
            val remaining = JSONArray()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val triggerAt = obj.optLong("triggerAtMs", 0L)
                val t = obj.optString("type", "")
                val p = obj.optString("payload", "")
                if (now >= triggerAt) {
                    dueList.add(t to p)
                } else {
                    remaining.put(obj)
                }
            }
            if (dueList.isNotEmpty()) {
                prefs.edit().putString(PREF_TASKS_JSON, remaining.toString()).apply()
            }
        }

        for ((type, payload) in dueList) {
            mainHandler.post {
                if (type == "REMIND") {
                    DynamicIslandBus.showAnnouncement(context, "🔔 Напоминание: $payload", speakText = "Напоминаю: $payload")
                } else if (type == "CMD") {
                    executeDelayedAction(context, payload)
                }
            }
        }
    }

    private fun executeDelayedAction(context: Context, commandSpec: String) {
        val parts = commandSpec.split(":", limit = 2)
        val act = parts[0].trim().uppercase(Locale.US)
        val arg = parts.getOrNull(1)?.trim().orEmpty()
        when (act) {
            "LED_ON" -> {
                TuyaSmartHomeController.setPower(context, true)
                DynamicIslandBus.showAnnouncement(context, "✦ Таймер: подсветка включена", speakText = "Включаю подсветку по таймеру.")
            }
            "LED_OFF" -> {
                TuyaSmartHomeController.setPower(context, false)
                DynamicIslandBus.showAnnouncement(context, "✦ Таймер: подсветка выключена", speakText = "Выключаю подсветку по таймеру.")
            }
            "LED_COLOR" -> if (arg.isNotEmpty()) {
                TuyaSmartHomeController.setHexColor(context, arg)
                DynamicIslandBus.showAnnouncement(context, "✦ Таймер: цвет подсветки изменён", speakText = "Меняю цвет подсветки по таймеру.")
            }
            "SLEEP", "TV_OFF" -> {
                ShellKeyController.sendKeyEvent(223)
            }
            "WAKEUP", "TV_ON" -> {
                ShellKeyController.sendKeyEvent(224)
            }
            "PAUSE" -> LocalVoiceCommandRouter.executeSystemAudioCommand(context, "PAUSE")
            "PLAY" -> LocalVoiceCommandRouter.executeSystemAudioCommand(context, "PLAY")
            "MUTE" -> LocalVoiceCommandRouter.executeSystemAudioCommand(context, "MUTE")
            "YT" -> if (arg.isNotEmpty()) LocalVoiceCommandRouter.launchYouTubeSearch(context, arg)
            "KICK" -> if (arg.isNotEmpty()) LocalVoiceCommandRouter.launchKickStream(context, arg)
            "SPOTIFY" -> if (arg.isNotEmpty()) LocalVoiceCommandRouter.launchSpotifyTrackOrArtist(context, arg)
        }
    }
}

object AssistantVoiceSpeaker {

    private const val PREF_TTS_ENABLED = "pref_assistant_tts_enabled"
    private const val PREF_TTS_VOICE = "pref_assistant_tts_voice"

    val AVAILABLE_VOICES: List<Pair<String, String>> = listOf(
        "Puck" to "Puck (Мужской · Бодрый)",
        "Charon" to "Charon (Мужской · Глубокий)",
        "Fenrir" to "Fenrir (Мужской · Энергичный)",
        "Kore" to "Kore (Женский · Чёткий)",
        "Aoede" to "Aoede (Женский · Мягкий)"
    )

    private val ttsModels = listOf(
        "gemini-2.5-flash-preview-tts",
        "gemini-2.5-pro-preview-tts"
    )

    @Volatile
    private var cachedTtsModel: String? = null

    private val speakerScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    private var speakJob: Job? = null

    @Volatile
    private var activeAudioTrack: AudioTrack? = null

    @Volatile
    private var fallbackSystemTts: TextToSpeech? = null

    @Volatile
    private var fallbackTtsReady: Boolean = false

    @Volatile
    var isSpeakingNow: Boolean = false
        private set

    @Volatile
    var currentVoiceWaveLevel: Float = 0.45f
        private set

    private var currentAudioFocusRequest: AudioFocusRequest? = null

    fun isTtsEnabled(context: Context): Boolean {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(PREF_TTS_ENABLED, true)
    }

    fun setTtsEnabled(context: Context, enabled: Boolean) {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(PREF_TTS_ENABLED, enabled).apply()
        if (!enabled) {
            stop(context)
        }
    }

    fun getSelectedVoiceName(context: Context): String {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString(PREF_TTS_VOICE, "Puck") ?: "Puck"
        return if (AVAILABLE_VOICES.any { it.first.equals(saved, ignoreCase = true) }) {
            AVAILABLE_VOICES.first { it.first.equals(saved, ignoreCase = true) }.first
        } else {
            "Puck"
        }
    }

    fun getSelectedVoiceDisplayLabel(context: Context): String {
        val code = getSelectedVoiceName(context)
        return AVAILABLE_VOICES.firstOrNull { it.first == code }?.second ?: code
    }

    fun setVoiceName(context: Context, rawVoice: String): String {
        val clean = rawVoice.trim()
        val matched = AVAILABLE_VOICES.firstOrNull {
            it.first.equals(clean, ignoreCase = true) || it.second.lowercase(Locale.ROOT).contains(clean.lowercase(Locale.ROOT))
        }?.first ?: when {
            clean.lowercase(Locale.ROOT).contains("жен") || clean.lowercase(Locale.ROOT).contains("жіноч") || clean.lowercase(Locale.ROOT).contains("kore") -> "Kore"
            clean.lowercase(Locale.ROOT).contains("мягк") || clean.lowercase(Locale.ROOT).contains("aoede") -> "Aoede"
            clean.lowercase(Locale.ROOT).contains("глуб") || clean.lowercase(Locale.ROOT).contains("charon") -> "Charon"
            clean.lowercase(Locale.ROOT).contains("энерг") || clean.lowercase(Locale.ROOT).contains("fenrir") -> "Fenrir"
            else -> "Puck"
        }
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(PREF_TTS_VOICE, matched).apply()
        return matched
    }

    fun cycleNextVoice(context: Context): String {
        val current = getSelectedVoiceName(context)
        val idx = AVAILABLE_VOICES.indexOfFirst { it.first == current }
        val next = if (idx >= 0) AVAILABLE_VOICES[(idx + 1) % AVAILABLE_VOICES.size].first else AVAILABLE_VOICES.first().first
        setVoiceName(context, next)
        return getSelectedVoiceDisplayLabel(context)
    }

    fun init(context: Context) {
        TuyaSmartHomeController.ensureWarmupStarted(context)
    }

    /**
     * Разбивает только очень длинные тексты (> 250 символов), чтобы обычные ответы из 1–2 предложений
     * отправлялись ОДНИМ запросом в живой Google Gemini TTS без параллельных лимитов 429!
     */
    private fun splitTextForReliableGeminiTts(text: String): List<String> {
        val clean = text.trim()
        if (clean.length <= 250) return listOf(clean)

        val chunks = mutableListOf<String>()
        var remaining = clean
        while (remaining.isNotEmpty()) {
            if (remaining.length <= 240) {
                chunks.add(remaining)
                break
            }
            var splitAt = -1
            for (d in listOf(". ", "! ", "? ", "; ")) {
                val idx = remaining.lastIndexOf(d, 240)
                if (idx >= 40 && idx + d.length > splitAt) {
                    splitAt = idx + d.length
                }
            }
            if (splitAt == -1) {
                val spIdx = remaining.lastIndexOf(' ', 230)
                splitAt = if (spIdx >= 40) spIdx + 1 else 230
            }
            val piece = remaining.substring(0, splitAt).trim()
            if (piece.isNotEmpty()) chunks.add(piece)
            remaining = remaining.substring(splitAt).trim()
        }
        return if (chunks.isEmpty()) listOf(clean) else chunks
    }

    /**
     * Надёжная озвучка с приоритетом ЖИВОГО нейронного голоса Google Gemini TTS (gemini-2.5-flash-preview-tts):
     * 1. Всегда сначала вызывает живой нейронный голос Google Gemini TTS (с автоматическим повтором при сетевой помехе).
     * 2. Только если облако Google недоступно — бесшовно подстраховывает встроенным синтезатором Android, чтобы ИИ никогда не молчал!
     */
    fun speak(context: Context, rawText: String, onFinished: ((Boolean) -> Unit)? = null) {
        val appCtx = context.applicationContext
        stop(appCtx)

        if (!isTtsEnabled(appCtx)) {
            onFinished?.let { mainHandler.post { it.invoke(false) } }
            return
        }

        val cleanText = rawText
            .removePrefix("✦")
            .replace("🔔", "")
            .replace("⚡", "")
            .replace("✓", "")
            .replace("*", "")
            .replace("#", "")
            .replace("·", ", ")
            .replace("–", " до ")
            .trim()

        if (cleanText.isEmpty()) {
            onFinished?.let { mainHandler.post { it.invoke(false) } }
            return
        }

        val voiceName = getSelectedVoiceName(appCtx)
        val textChunks = splitTextForReliableGeminiTts(cleanText)
        isSpeakingNow = true
        currentVoiceWaveLevel = 0.52f

        speakJob = speakerScope.launch {
            var playedSuccessfully = false
            var track: AudioTrack? = null
            try {
                for (idx in textChunks.indices) {
                    if (!isActive || !isSpeakingNow) break
                    val chunkText = textChunks[idx]
                    val pcmData = fetchGeminiTtsPcmWithRetry(chunkText, voiceName)
                    if (pcmData != null && pcmData.size > 400 && isActive && isSpeakingNow) {
                        if (track == null) {
                            track = openStreamingAudioTrack24kHz(appCtx)
                            activeAudioTrack = track
                        }
                        val activeAt = track
                        if (activeAt != null) {
                            val ok = writePcmChunkWithVisualizer(activeAt, pcmData)
                            if (ok) playedSuccessfully = true
                        }
                    }
                }

                // Если живой облачный Gemini TTS не ответил из-за интернета — подстраховываем системным голосом
                if (!playedSuccessfully && isActive && isSpeakingNow) {
                    playedSuccessfully = speakWithAndroidFallbackBlocking(appCtx, cleanText)
                }
            } catch (_: Exception) {
            } finally {
                activeAudioTrack = null
                try {
                    track?.stop()
                } catch (_: Exception) {
                }
                try {
                    track?.release()
                } catch (_: Exception) {
                }
                isSpeakingNow = false
                currentVoiceWaveLevel = 0.35f
                abandonAudioFocus(appCtx)
                if (isActive) {
                    val didPlay = playedSuccessfully
                    onFinished?.let { cb ->
                        mainHandler.post { cb.invoke(didPlay) }
                    }
                }
            }
        }
    }

    private suspend fun speakWithAndroidFallbackBlocking(context: Context, text: String): Boolean {
        return try {
            requestTransientAudioDucking(context)
            var tts = fallbackSystemTts
            if (tts == null) {
                var initDone = false
                tts = TextToSpeech(context.applicationContext) { status ->
                    fallbackTtsReady = (status == TextToSpeech.SUCCESS)
                    initDone = true
                }
                fallbackSystemTts = tts
                var waited = 0
                while (!initDone && waited < 25) {
                    delay(80L)
                    waited++
                }
            }
            if (fallbackTtsReady && tts != null) {
                tts.language = Locale("ru", "RU")
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mitv_fallback_utt")
                val estMs = (1200L + text.length * 68L).coerceIn(1500L, 9000L)
                var elapsed = 0L
                while (isSpeakingNow && elapsed < estMs) {
                    currentVoiceWaveLevel = if ((elapsed / 160L) % 2L == 0L) 0.72f else 0.38f
                    delay(160L)
                    elapsed += 160L
                }
                true
            } else {
                false
            }
        } catch (_: Exception) {
            false
        }
    }

    fun stop(context: Context? = null) {
        speakJob?.cancel()
        speakJob = null
        isSpeakingNow = false
        currentVoiceWaveLevel = 0.35f
        try {
            fallbackSystemTts?.stop()
        } catch (_: Exception) {
        }
        val runningTrack = activeAudioTrack
        activeAudioTrack = null
        if (runningTrack != null) {
            try {
                runningTrack.pause()
                runningTrack.flush()
            } catch (_: Exception) {
            }
            try {
                runningTrack.release()
            } catch (_: Exception) {
            }
        }
        if (context != null) {
            abandonAudioFocus(context.applicationContext)
        }
    }

    private suspend fun fetchGeminiTtsPcmWithRetry(textToSpeak: String, voiceName: String): ByteArray? {
        for (attempt in 0 until 2) {
            val pcm = fetchGeminiTtsPcmOnce(textToSpeak, voiceName)
            if (pcm != null && pcm.size > 400) return pcm
            if (attempt == 0) {
                delay(380L)
            }
        }
        return null
    }

    private fun fetchGeminiTtsPcmOnce(textToSpeak: String, voiceName: String): ByteArray? {
        val apiKey = LauncherConfig.DEFAULT_GEMINI_API_KEY
        // Явная директива для Gemini TTS, чтобы модель всегда зачитывала текст вслух (даже если в конце есть вопросительный знак!)
        val directiveText = "Read aloud verbatim with natural expressive intonation: $textToSpeak"
        val payload = JSONObject().apply {
            put("contents", JSONArray().put(
                JSONObject().apply {
                    put("parts", JSONArray().put(
                        JSONObject().put("text", directiveText)
                    ))
                }
            ))
            put("generationConfig", JSONObject().apply {
                put("responseModalities", JSONArray().put("AUDIO"))
                put("speechConfig", JSONObject().apply {
                    put("voiceConfig", JSONObject().apply {
                        put("prebuiltVoiceConfig", JSONObject().apply {
                            put("voiceName", voiceName)
                        })
                    })
                })
            })
        }.toString()

        val orderedModels = mutableListOf<String>()
        val cached = cachedTtsModel
        if (cached != null) orderedModels.add(cached)
        for (m in ttsModels) {
            if (m != cached) orderedModels.add(m)
        }

        for (model in orderedModels) {
            var conn: HttpURLConnection? = null
            try {
                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=${Uri.encode(apiKey)}")
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 4000
                    readTimeout = 8500
                    doOutput = true
                    doInput = true
                    useCaches = false
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Connection", "keep-alive")
                }
                conn = connection
                connection.outputStream.use { os ->
                    os.write(payload.toByteArray(Charsets.UTF_8))
                    os.flush()
                }
                if (connection.responseCode in 200..299) {
                    val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    val root = JSONObject(body)
                    val parts = root.optJSONArray("candidates")
                        ?.optJSONObject(0)
                        ?.optJSONObject("content")
                        ?.optJSONArray("parts")
                    if (parts != null) {
                        for (i in 0 until parts.length()) {
                            val inlineData = parts.optJSONObject(i)?.optJSONObject("inlineData") ?: continue
                            val b64 = inlineData.optString("data", "")
                            if (b64.isNotBlank()) {
                                cachedTtsModel = model
                                val rawBytes = Base64.decode(b64, Base64.DEFAULT)
                                return if (rawBytes.size > 44 &&
                                    rawBytes[0] == 0x52.toByte() &&
                                    rawBytes[1] == 0x49.toByte() &&
                                    rawBytes[2] == 0x46.toByte() &&
                                    rawBytes[3] == 0x46.toByte()
                                ) {
                                    rawBytes.copyOfRange(44, rawBytes.size)
                                } else {
                                    rawBytes
                                }
                            }
                        }
                    }
                } else {
                    connection.errorStream?.close()
                }
            } catch (_: Exception) {
                try {
                    conn?.disconnect()
                } catch (_: Exception) {
                }
            }
        }
        return null
    }

    private fun openStreamingAudioTrack24kHz(context: Context): AudioTrack? {
        val sampleRate = 24000
        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(4800)

        return try {
            requestTransientAudioDucking(context)
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            val format = AudioFormat.Builder()
                .setSampleRate(sampleRate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()
            AudioTrack(
                attrs,
                format,
                minBuf * 2,
                AudioTrack.MODE_STREAM,
                AudioManager.AUDIO_SESSION_ID_GENERATE
            ).apply {
                play()
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun writePcmChunkWithVisualizer(at: AudioTrack, pcmBytes: ByteArray): Boolean {
        return try {
            val chunkSize = 1920 // 40 мс при 24000 Гц (16 бит моно)
            var offset = 0
            while (offset < pcmBytes.size && isSpeakingNow) {
                val len = (pcmBytes.size - offset).coerceAtMost(chunkSize)
                val samplesCount = len / 2
                if (samplesCount > 0) {
                    var sumSq = 0.0
                    val bb = ByteBuffer.wrap(pcmBytes, offset, len).order(ByteOrder.LITTLE_ENDIAN)
                    for (s in 0 until samplesCount) {
                        val v = bb.short.toDouble()
                        sumSq += v * v
                    }
                    val rms = sqrt(sumSq / samplesCount)
                    val normalized = (0.24 + (rms / 6500.0) * 0.76).coerceIn(0.24, 1.0).toFloat()
                    currentVoiceWaveLevel = normalized
                }
                val written = at.write(pcmBytes, offset, len)
                if (written <= 0) break
                offset += written
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun requestTransientAudioDucking(context: Context) {
        try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
                val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(attrs)
                    .setAcceptsDelayedFocusGain(false)
                    .setWillPauseWhenDucked(false)
                    .build()
                currentAudioFocusRequest = req
                am.requestAudioFocus(req)
            } else {
                @Suppress("DEPRECATION")
                am.requestAudioFocus(
                    null,
                    AudioManager.STREAM_MUSIC,
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
                )
            }
        } catch (_: Exception) {
        }
    }

    private fun abandonAudioFocus(context: Context) {
        try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                currentAudioFocusRequest?.let { am.abandonAudioFocusRequest(it) }
                currentAudioFocusRequest = null
            } else {
                @Suppress("DEPRECATION")
                am.abandonAudioFocus(null)
            }
        } catch (_: Exception) {
        }
    }
}

data class GeminiTurnResult(
    val displayText: String,
    val shouldContinueDialog: Boolean,
    val isSilence: Boolean = false
)

object GeminiCloudClient {

    private data class ChatTurn(
        val role: String,
        val text: String
    )

    private val candidateModels = listOf(
        "gemini-2.5-flash",
        "gemini-2.5-flash-lite",
        "gemini-2.0-flash",
        "gemini-2.0-flash-lite",
        "gemini-flash-latest",
        "gemini-1.5-flash"
    )

    private val conversationHistory = mutableListOf<ChatTurn>()

    @Volatile
    private var lastInteractionRealtimeMs: Long = 0L

    @Volatile
    private var cachedModelName: String? = null

    @Volatile
    private var cachedUseHeaderAuth: Boolean = false

    @Synchronized
    fun clearConversationHistory() {
        conversationHistory.clear()
    }

    @Synchronized
    private fun appendTurnToHistory(userText: String, modelText: String) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastInteractionRealtimeMs > 5 * 60 * 1000L) {
            conversationHistory.clear()
        }
        lastInteractionRealtimeMs = now
        if (userText.isNotBlank()) {
            conversationHistory.add(ChatTurn("user", userText.take(350)))
        }
        if (modelText.isNotBlank()) {
            conversationHistory.add(ChatTurn("model", modelText.take(450)))
        }
        while (conversationHistory.size > 8) {
            conversationHistory.removeAt(0)
        }
    }

    @Synchronized
    private fun formatRecentHistoryBlock(): String {
        val now = SystemClock.elapsedRealtime()
        if (now - lastInteractionRealtimeMs > 5 * 60 * 1000L) {
            conversationHistory.clear()
            return ""
        }
        if (conversationHistory.isEmpty()) return ""
        val lines = conversationHistory.joinToString("\n") { turn ->
            val who = if (turn.role == "user") "Пользователь" else "Ты (Ассистент)"
            "$who: ${turn.text}"
        }
        return "\nПредыдущий контекст текущего диалога (учитывай его при ответе на уточняющие вопросы вроде «а на завтра?», «а почему?», «расскажи подробнее»):\n$lines\n"
    }

    private fun buildCommandInstruction(context: Context): String {
        val appCtx = context.applicationContext
        val apps = AppLauncher(appCtx).getInstalledApps().take(30)
            .joinToString(", ") { "${it.label} (${it.packageName})" }
        val outageInfo = OutageRepository.getSummaryForAi(appCtx)
        val historyBlock = formatRecentHistoryBlock() + AiMemoryStore.getMemoryPromptBlock(appCtx)
        val currentVoice = AssistantVoiceSpeaker.getSelectedVoiceName(appCtx)
        val ttsEnabled = AssistantVoiceSpeaker.isTtsEnabled(appCtx)
        return "Ты — живой, умный и сверхбыстрый голосовой ИИ-ассистент в кастомном лаунчере Android TV (Xiaomi Mi TV Stick). " +
            "Сейчас твоя голосовая озвучка: ${if (ttsEnabled) "ВКЛЮЧЕНА (голос $currentVoice)" else "ВЫКЛЮЧЕНА"}. " +
            "Отвечай естественно, дружелюбно и лаконично (1–2 предложения, без звёздочек и без разметки Markdown). " +
            "Актуальные данные по графику отключений света пользователя ($outageInfo). Если пользователь спрашивает про свет/отключения/график ДТЭК — дай точный ответ по этим данным! " +
            historyBlock +
            "Ты идеально понимаешь украинский, русский, суржик и английский языки. Отвечай на том же языке, на котором обратился пользователь.\n" +
            "ВАЖНОЕ ПРАВИЛО РЕЖИМА ДИАЛОГА:\n" +
            "- Если пользователь выполняет команду управления ТВ (включи трек/видео/стрим, открой приложение, измени громкость/цвет) ИЛИ задал простой закрытый вопрос на один факт (например «когда выключат свет?», «какая очередь?», «сколько времени?») — обязательно поставь в начале ответа тег [MODE:ONE_SHOT], чтобы после ответа микрофон НЕ включался сам.\n" +
            "- Ставь тег [MODE:DIALOG] ТОЛЬКО тогда, когда пользователь явно ведёт беседу/обсуждение (например «посоветуй фильм», «давай поговорим», «расскажи...») ИЛИ когда ты сам задаёшь пользователю встречный уточняющий вопрос в конце ответа!\n" +
            "ТЕГИ КОМАНД УПРАВЛЕНИЯ ПРИСТАВКОЙ (ставь в начале ответа, если пользователь просит выполнить действие):\n" +
            "- Включить песню, трек, альбом или исполнителя в Spotify: [CMD:SPOTIFY:Точное имя артиста и трека] (переводи транслит в оригинальное название, например «уикенд старбой» -> [CMD:SPOTIFY:The Weeknd Starboy])\n" +
            "- Запустить стрим на Kick: [CMD:KICK:channel_slug] (переводи русские/украинские имена стримеров в их точный ник на Kick: Калатай -> kalatay3, Зубарев -> zubarefff, Мелстрой -> mellstroy, Бустер -> buster, Плохой Парень -> plohoyparen, Эвелон -> evelone192, Строго -> strogo, Хесус -> jesusavgn, Коряга -> korya_mc)\n" +
            "- Включить конкретное видео, клип, песню или канал на YouTube (автоматически запустит видео!): [CMD:YT:точный поисковый запрос] (например «включи на ютубе лав 66 бай бай» -> [CMD:YT:LOVV66 БАЙ БАЙ])\n" +
            "- Запомнить любой факт, заметку, код или правило в долгосрочную память: [CMD:REMEMBER:текст для запоминания]\n" +
            "- Забыть заметку из долгосрочной памяти: [CMD:FORGET:ключевое слово или ALL]\n" +
            "- Поставить голосовое напоминание через время (например «напомни мне уколоть инсулин через 20 минут», «напомни через полчаса выключить духовку»): [CMD:REMIND:секунды:текст напоминания] (переведи минуты/часы в секунды, например 20 минут = 1200, 1 минута = 60, полчаса = 1800, 1 час = 3600)\n" +
            "- Выполнить отложенную команду умного дома или ТВ через время (например «включи ленту через 20 минут» -> [CMD:DELAY_CMD:1200:LED_ON], «выключи ленту через 15 минут» -> [CMD:DELAY_CMD:900:LED_OFF], «включи фиолетовую ленту через 10 минут» -> [CMD:DELAY_CMD:600:LED_COLOR:#C084FC], «выключи телевизор через 30 минут» -> [CMD:DELAY_CMD:1800:SLEEP]): [CMD:DELAY_CMD:секунды:КОМАНДА]\n" +
            "- Изменить цвет темы лаунчера, обводки или ползунка громкости: [CMD:COLOR:#RRGGBB] (красный #EF4444, розовый #EC4899, фиолетовый #A78BFA, зелёный #34D399, синий #60A5FA, голубой/бирюзовый #00F0FF, жёлтый/золотой #F59E0B, оранжевый #F97316, белый #E2E8F0)\n" +
            "- Управление умной светодиодной LED-лентой (подсветкой ТВ): включить ленту/подсветку [CMD:LED_ON], выключить ленту/подсветку [CMD:LED_OFF], установить ЛЮБОЙ цвет или оттенок ленты [CMD:LED_COLOR:#RRGGBB] (переводи любое название оттенка — бирюзовый #00F0FF, морская волна #06B6D4, сапфир #2563EB, индиго #6366F1, лаванда #C084FC, фиолетовый #A855F7, фуксия/розовый #EC4899, малиновый #F43F5E, красный #EF4444, персиковый #FB923C, закат #F97316, янтарный/жёлтый #F59E0B, лайм #84CC16, изумрудный/зелёный #10B981, мята #2DD4BF, тёплый белый #FDE68A), изменить яркость ленты в процентах [CMD:LED_BRIGHT:10..100], включить динамический режим на ленте [CMD:LED_SCENE:RAINBOW|BREATHE|PARTY|NIGHT]\n" +
            "- Открыть установленное приложение: [CMD:LAUNCH:package_name] (список приложений: $apps)\n" +
            "- Открыть системные настройки ТВ: [CMD:SETTINGS], настройки Wi-Fi: [CMD:WIFI], настройки Bluetooth: [CMD:BLUETOOTH]\n" +
            "- Открыть сайт в браузере: [CMD:URL:https://адрес]\n" +
            "- Громкость в процентах: [CMD:VOL_SET:0..100], сделать громче: [CMD:VOL_UP], тише: [CMD:VOL_DOWN], выключить звук: [CMD:MUTE], включить звук: [CMD:UNMUTE]\n" +
            "- Управление плеером: [CMD:PAUSE], [CMD:PLAY], [CMD:NEXT], [CMD:PREV]\n" +
            "- Очистить оперативную память / ускорить приставку: [CMD:BOOST]\n" +
            "- Выключить или включить звук щелчков пульта: [CMD:NAV_SOUND:OFF] или [CMD:NAV_SOUND:ON]\n" +
            "- Выключить или включить голосовую озвучку твоих ответов: [CMD:TTS:OFF] или [CMD:TTS:ON]\n" +
            "- Сменить твой голос озвучки (доступны мужские голоса Puck, Charon, Fenrir и женские Kore, Aoede): [CMD:VOICE:имя_голоса]\n" +
            "- Показать на экране окно графика отключений света: [CMD:OUTAGE_OPEN]\n" +
            "- Изменить очередь (группу) отключений света ДТЭК (от 1.1 до 6.2): [CMD:OUTAGE_GROUP:номер_очереди]\n" +
            "- Ввести или напечатать текст в поле поиска на экране ТВ: [CMD:TYPE:текст для ввода]\n" +
            "- Нажать на кнопку, вкладку или карточку на экране ТВ по названию: [CMD:CLICK:текст кнопки]\n" +
            "- Системная навигация по ТВ: [CMD:NAV:HOME] (на главный экран), [CMD:NAV:BACK] (назад)\n" +
            "- Если пользователь прощается или говорит «спасибо, всё / хватит / пока / отбой»: [CMD:STOP_DIALOG]\n" +
            "- Если пользователь просит забыть контекст или сменить тему: [CMD:CLEAR_MEMORY]\n" +
            "После тегов напиши короткий живой ответ для пользователя."
    }

    private fun buildPayloadForModel(contentsArray: JSONArray, modelName: String, temperature: Double): String {
        val genConfig = JSONObject().apply {
            put("maxOutputTokens", 1200)
            put("temperature", temperature)
            if (modelName.startsWith("gemini-2.5-flash")) {
                put("thinkingConfig", JSONObject().apply {
                    put("thinkingBudget", 0)
                })
            }
        }
        return JSONObject().apply {
            put("contents", contentsArray)
            put("generationConfig", genConfig)
        }.toString()
    }

    suspend fun askGeminiTextTurn(context: Context, userQuery: String): GeminiTurnResult = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext
        try {
            OutageRepository.refreshIfNeeded(appCtx, force = false)
        } catch (_: Exception) {
        }
        val fullPrompt = "${buildCommandInstruction(appCtx)}\n\nЗапрос пользователя: $userQuery"

        val contentsArray = JSONArray().put(
            JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", fullPrompt)))
            }
        )

        val rawReply = executeWithEndpointFallback(contentsArray, temperature = 0.35)
        processCommandTags(appCtx, rawReply, userTranscript = userQuery)
    }

    suspend fun askGeminiText(context: Context, userQuery: String): String {
        return askGeminiTextTurn(context, userQuery).displayText
    }

    suspend fun askGeminiAudioTurn(context: Context, wavBytes: ByteArray): GeminiTurnResult = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext
        try {
            OutageRepository.refreshIfNeeded(appCtx, force = false)
        } catch (_: Exception) {
        }
        val audioPrompt = buildCommandInstruction(appCtx) +
            "\n\nПрослушай голосовую реплику пользователя (на украинском, русском, суржике или английском). " +
            "Если на записи только тишина или фоновый шум без речи — ответь ровно одним словом: [SILENCE]. " +
            "Иначе в самом начале ответа напиши тег [USER_SAID:точная краткая расшифровка слов пользователя], затем тег режима ([MODE:ONE_SHOT] или [MODE:DIALOG]), теги команд [CMD:...] (если нужны) и свой ответ."

        val b64Audio = Base64.encodeToString(wavBytes, Base64.NO_WRAP)
        val partsArray = JSONArray()
            .put(JSONObject().put("text", audioPrompt))
            .put(JSONObject().put("inlineData", JSONObject().apply {
                put("mimeType", "audio/wav")
                put("data", b64Audio)
            }))

        val contentsArray = JSONArray().put(
            JSONObject().apply {
                put("role", "user")
                put("parts", partsArray)
            }
        )

        val rawReply = executeWithEndpointFallback(contentsArray, temperature = 0.3)
        if (rawReply.contains("[SILENCE]")) {
            return@withContext GeminiTurnResult(
                displayText = "✦ Не расслышал речь. Скажите запрос в микрофон.",
                shouldContinueDialog = false,
                isSilence = true
            )
        }
        processCommandTags(appCtx, rawReply, userTranscript = "")
    }

    suspend fun askGeminiAudio(context: Context, wavBytes: ByteArray): String {
        return askGeminiAudioTurn(context, wavBytes).displayText
    }

    private fun processCommandTags(context: Context, reply: String, userTranscript: String): GeminiTurnResult {
        var clean = reply.trim()
        var extractedUserSaid = userTranscript.trim()

        val saidRegex = Regex("\\[USER_SAID:([^\\]]+)\\]")
        val saidMatch = saidRegex.find(clean)
        if (saidMatch != null) {
            if (extractedUserSaid.isEmpty()) {
                extractedUserSaid = saidMatch.groupValues[1].trim()
            }
            clean = clean.replace(saidMatch.value, "").trim()
        }

        var modeIsDialog = false
        var modeExplicitlyOneShot = false
        val modeRegex = Regex("\\[MODE:([^\\]]+)\\]")
        for (mm in modeRegex.findAll(clean).toList()) {
            val modeVal = mm.groupValues[1].trim().uppercase(Locale.US)
            if (modeVal.contains("DIALOG")) {
                modeIsDialog = true
            } else if (modeVal.contains("ONE_SHOT") || modeVal.contains("SINGLE")) {
                modeExplicitlyOneShot = true
            }
            clean = clean.replace(mm.value, "").trim()
        }

        val cmdRegex = Regex("\\[CMD:([^\\]]+)\\]")
        val matches = cmdRegex.findAll(clean).toList()

        var hasAnyCommand = false
        var explicitStopDialog = false
        val isErrorReply = clean.startsWith("Ошибка ответа Gemini") || clean.startsWith("Не удалось связаться")

        if (matches.isNotEmpty()) {
            hasAnyCommand = true
            val handler = Handler(Looper.getMainLooper())
            for (m in matches) {
                clean = clean.replace(m.value, "").trim()
                val tagContent = m.groupValues[1]
                val parts = tagContent.split(":", limit = 2)
                val action = parts[0].trim().uppercase(Locale.US)
                val arg = parts.getOrNull(1)?.trim().orEmpty()

                if (action == "STOP_DIALOG") {
                    explicitStopDialog = true
                }
                if (action == "CLEAR_MEMORY") {
                    clearConversationHistory()
                }

                handler.post {
                    when (action) {
                        "SPOTIFY" -> if (arg.isNotEmpty()) {
                            LocalVoiceCommandRouter.launchSpotifyTrackOrArtist(context, arg)
                        }
                        "KICK" -> {
                            val lowerArg = arg.lowercase(Locale.ROOT).trim()
                            val slug = when {
                                lowerArg.contains("kalatay") || lowerArg.contains("калатай") -> "kalatay3"
                                lowerArg.contains("зубар") || lowerArg.contains("zubar") -> "zubarefff"
                                lowerArg.contains("мелстр") || lowerArg.contains("mell") -> "mellstroy"
                                lowerArg.contains("бустер") || lowerArg.contains("buster") -> "buster"
                                lowerArg.contains("плохой") || lowerArg.contains("plohoy") -> "plohoyparen"
                                lowerArg.contains("эвелон") || lowerArg.contains("evelon") -> "evelone192"
                                lowerArg.contains("строго") || lowerArg.contains("strogo") -> "strogo"
                                lowerArg.contains("хесус") || lowerArg.contains("jesus") -> "jesusavgn"
                                else -> arg
                            }
                            handler.postDelayed({
                                LocalVoiceCommandRouter.launchKickStream(context, slug)
                            }, 350L)
                        }
                        "YT" -> if (arg.isNotEmpty()) {
                            handler.postDelayed({
                                LocalVoiceCommandRouter.launchYouTubeSearch(context, arg)
                            }, 350L)
                        }
                        "REMEMBER" -> if (arg.isNotEmpty()) {
                            AiMemoryStore.rememberFact(context, arg)
                        }
                        "FORGET" -> {
                            AiMemoryStore.forgetFact(context, arg)
                        }
                        "REMIND" -> if (arg.isNotEmpty()) {
                            val sub = arg.split(":", limit = 2)
                            val secs = sub[0].trim().toLongOrNull() ?: 60L
                            val msg = sub.getOrNull(1)?.trim().orEmpty().ifEmpty { "Время напоминания" }
                            ScheduledTaskManager.scheduleVoiceReminder(context, secs, msg)
                        }
                        "DELAY_CMD" -> if (arg.isNotEmpty()) {
                            val sub = arg.split(":", limit = 2)
                            val secs = sub[0].trim().toLongOrNull() ?: 60L
                            val cmdSpec = sub.getOrNull(1)?.trim().orEmpty()
                            if (cmdSpec.isNotEmpty()) {
                                ScheduledTaskManager.scheduleDelayedCommand(context, secs, cmdSpec)
                            }
                        }
                        "COLOR" -> if (arg.isNotEmpty()) {
                            LocalVoiceCommandRouter.applyThemeColorEverywhere(context, arg)
                            TuyaSmartHomeController.syncWithLauncherThemeIfNeeded(context, arg)
                        }
                        "LED_ON" -> {
                            TuyaSmartHomeController.setPower(context, true)
                        }
                        "LED_OFF" -> {
                            TuyaSmartHomeController.setPower(context, false)
                        }
                        "LED_COLOR" -> if (arg.isNotEmpty()) {
                            TuyaSmartHomeController.setHexColor(context, arg)
                        }
                        "LED_BRIGHT" -> {
                            val pct = arg.toIntOrNull()
                            if (pct != null) {
                                TuyaSmartHomeController.setBrightnessPercent(context, pct)
                            }
                        }
                        "LED_SCENE" -> if (arg.isNotEmpty()) {
                            TuyaSmartHomeController.activateDynamicScene(context, arg)
                        }
                        "LAUNCH" -> if (arg.isNotEmpty()) {
                            MediaStateBus.onMediaAppOpened(arg)
                            AppLauncher(context).launchPackage(arg)
                        }
                        "SETTINGS" -> LocalVoiceCommandRouter.openSystemSettingsAction(context, Settings.ACTION_SETTINGS)
                        "WIFI" -> LocalVoiceCommandRouter.openSystemSettingsAction(context, Settings.ACTION_WIFI_SETTINGS)
                        "BLUETOOTH" -> LocalVoiceCommandRouter.openSystemSettingsAction(context, Settings.ACTION_BLUETOOTH_SETTINGS)
                        "URL" -> if (arg.isNotEmpty()) {
                            LocalVoiceCommandRouter.launchUrlInTvBrowser(context, arg)
                        }
                        "VOL_SET" -> {
                            val pct = arg.toIntOrNull()
                            if (pct != null) {
                                LocalVoiceCommandRouter.setVolumePercent(context, pct)
                            }
                        }
                        "VOL_UP", "VOL_DOWN", "MUTE", "UNMUTE", "PAUSE", "PLAY", "NEXT", "PREV" -> {
                            LocalVoiceCommandRouter.executeSystemAudioCommand(context, action)
                        }
                        "BOOST" -> LocalVoiceCommandRouter.cleanRamBackground(context)
                        "NAV_SOUND" -> {
                            val enable = !arg.uppercase(Locale.US).contains("OFF")
                            NavSoundPlayer.setSoundEnabled(context, enable)
                        }
                        "TTS" -> {
                            val enable = !arg.uppercase(Locale.US).contains("OFF")
                            AssistantVoiceSpeaker.setTtsEnabled(context, enable)
                        }
                        "VOICE" -> if (arg.isNotEmpty()) {
                            AssistantVoiceSpeaker.setVoiceName(context, arg)
                            AssistantVoiceSpeaker.setTtsEnabled(context, true)
                        }
                        "OUTAGE_OPEN" -> {
                            OutageRepository.onOpenScheduleRequested?.invoke()
                        }
                        "OUTAGE_GROUP" -> if (arg.isNotEmpty()) {
                            OutageRepository.setSelectedGroup(context, arg)
                        }
                        "TYPE" -> if (arg.isNotEmpty()) {
                            TvUiControllerBus.typeText(arg)
                        }
                        "CLICK" -> if (arg.isNotEmpty()) {
                            TvUiControllerBus.clickByText(arg)
                        }
                        "NAV" -> if (arg.isNotEmpty()) {
                            TvUiControllerBus.performNav(arg)
                        }
                    }
                }
            }
            val finalClean = clean.removePrefix("✦").trim().ifEmpty { "Готово" }
            if (!isErrorReply) {
                appendTurnToHistory(extractedUserSaid, finalClean)
            }
            val continueAfterCmd = modeIsDialog && !modeExplicitlyOneShot && !explicitStopDialog && !isErrorReply && finalClean.endsWith("?")
            return GeminiTurnResult(
                displayText = "✦ $finalClean",
                shouldContinueDialog = continueAfterCmd
            )
        }

        if (!isErrorReply) {
            appendTurnToHistory(extractedUserSaid, clean)
        }
        val shouldContinue = (modeIsDialog || (!modeExplicitlyOneShot && clean.endsWith("?"))) && !hasAnyCommand && !explicitStopDialog && !isErrorReply
        return GeminiTurnResult(
            displayText = clean,
            shouldContinueDialog = shouldContinue
        )
    }

    private fun executeWithEndpointFallback(contentsArray: JSONArray, temperature: Double): String {
        val primaryKey = LauncherConfig.DEFAULT_GEMINI_API_KEY
        val endpointTemplate = "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent"

        val cModel = cachedModelName
        if (cModel != null) {
            val urlStr = String.format(Locale.US, endpointTemplate, cModel)
            val bodyStr = buildPayloadForModel(contentsArray, cModel, temperature)
            val res = trySingleRequest(urlStr, primaryKey, cachedUseHeaderAuth, bodyStr)
            val cachedTxt = res.text
            if (res.isSuccess && !cachedTxt.isNullOrBlank()) {
                return cachedTxt
            }
        }

        var firstMeaningfulError = ""
        var lastError = ""

        for (model in candidateModels) {
            val urlStr = String.format(Locale.US, endpointTemplate, model)
            val bodyStr = buildPayloadForModel(contentsArray, model, temperature)
            val res = trySingleRequest(urlStr, primaryKey, useHeaderAuth = false, jsonBody = bodyStr)
            val txt = res.text
            if (res.isSuccess && !txt.isNullOrBlank()) {
                cachedModelName = model
                cachedUseHeaderAuth = false
                return txt
            }
            if (res.errorSummary == "HTTP 400" && model.startsWith("gemini-2.5-flash")) {
                val plainBody = buildPayloadForModel(contentsArray, "gemini-2.0-flash", temperature)
                val retryRes = trySingleRequest(urlStr, primaryKey, useHeaderAuth = false, jsonBody = plainBody)
                val retryTxt = retryRes.text
                if (retryRes.isSuccess && !retryTxt.isNullOrBlank()) {
                    cachedModelName = model
                    cachedUseHeaderAuth = false
                    return retryTxt
                }
            }
            if (res.errorSummary.isNotBlank()) {
                lastError = res.errorSummary
                if (firstMeaningfulError.isBlank() && res.errorSummary != "HTTP 404") {
                    firstMeaningfulError = res.errorSummary
                }
            }
        }

        val discoveredModels = discoverAvailableModels(primaryKey)
        for (model in discoveredModels) {
            if (model in candidateModels) continue
            val urlStr = String.format(Locale.US, endpointTemplate, model)
            val bodyStr = buildPayloadForModel(contentsArray, "gemini-2.0-flash", temperature)
            val res = trySingleRequest(urlStr, primaryKey, useHeaderAuth = false, jsonBody = bodyStr)
            val txt = res.text
            if (res.isSuccess && !txt.isNullOrBlank()) {
                cachedModelName = model
                cachedUseHeaderAuth = false
                return txt
            } else if (res.errorSummary.isNotBlank() && firstMeaningfulError.isBlank() && res.errorSummary != "HTTP 404") {
                firstMeaningfulError = res.errorSummary
            }
        }

        val finalErr = firstMeaningfulError.ifBlank { lastError }
        return if (finalErr.isNotBlank()) {
            "Ошибка ответа Gemini ($finalErr)"
        } else {
            "Не удалось связаться с Gemini. Проверьте интернет-соединение."
        }
    }

    private fun discoverAvailableModels(apiKey: String): List<String> {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models?key=${Uri.encode(apiKey)}")
            val connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 5000
                readTimeout = 7000
                doInput = true
            }
            conn = connection
            if (connection.responseCode !in 200..299) return emptyList()
            val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val root = JSONObject(body)
            val modelsArr = root.optJSONArray("models") ?: return emptyList()
            val flashModels = mutableListOf<String>()
            val otherModels = mutableListOf<String>()
            for (i in 0 until modelsArr.length()) {
                val obj = modelsArr.optJSONObject(i) ?: continue
                val name = obj.optString("name", "").removePrefix("models/").trim()
                if (name.isEmpty() || name.contains("embedding") || name.contains("imagen") || name.contains("tts") || name.contains("aqa")) continue
                val methods = obj.optJSONArray("supportedGenerationMethods")
                var supportsGenerate = false
                if (methods != null) {
                    for (j in 0 until methods.length()) {
                        if (methods.optString(j) == "generateContent") {
                            supportsGenerate = true
                            break
                        }
                    }
                }
                if (supportsGenerate) {
                    if (name.contains("flash")) {
                        flashModels.add(name)
                    } else if (name.startsWith("gemini")) {
                        otherModels.add(name)
                    }
                }
            }
            flashModels + otherModels
        } catch (_: Exception) {
            emptyList()
        } finally {
            try {
                conn?.disconnect()
            } catch (_: Exception) {
            }
        }
    }

    private data class HttpResult(
        val isSuccess: Boolean,
        val text: String? = null,
        val errorSummary: String = ""
    )

    private fun trySingleRequest(
        baseUrl: String,
        apiKey: String,
        useHeaderAuth: Boolean,
        jsonBody: String
    ): HttpResult {
        var conn: HttpURLConnection? = null
        return try {
            val finalUrl = if (useHeaderAuth) {
                baseUrl
            } else {
                "$baseUrl?key=${Uri.encode(apiKey)}"
            }
            val connection = (URL(finalUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 6000
                readTimeout = 12000
                doOutput = true
                doInput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Connection", "keep-alive")
                if (useHeaderAuth) {
                    setRequestProperty("x-goog-api-key", apiKey)
                }
            }
            conn = connection
            connection.outputStream.use { os ->
                os.write(jsonBody.toByteArray(Charsets.UTF_8))
            }
            val code = connection.responseCode
            if (code in 200..299) {
                val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val parsed = extractTextFromGeminiJson(body)
                if (!parsed.isNullOrBlank()) {
                    HttpResult(isSuccess = true, text = parsed)
                } else {
                    HttpResult(isSuccess = false, errorSummary = "Empty response")
                }
            } else {
                HttpResult(isSuccess = false, errorSummary = "HTTP $code")
            }
        } catch (e: Exception) {
            HttpResult(isSuccess = false, errorSummary = e.javaClass.simpleName)
        } finally {
            try {
                conn?.disconnect()
            } catch (_: Exception) {
            }
        }
    }

    private fun extractTextFromGeminiJson(rawJson: String): String? {
        return try {
            val root = JSONObject(rawJson)
            val candidates = root.optJSONArray("candidates") ?: return null
            if (candidates.length() == 0) return null
            val content = candidates.optJSONObject(0)?.optJSONObject("content") ?: return null
            val parts = content.optJSONArray("parts") ?: return null
            val sb = StringBuilder()
            val fallbackSb = StringBuilder()
            for (i in 0 until parts.length()) {
                val partObj = parts.optJSONObject(i) ?: continue
                val t = partObj.optString("text", "")
                if (t.isNotBlank()) {
                    if (partObj.optBoolean("thought", false)) {
                        if (fallbackSb.isNotEmpty()) fallbackSb.append(" ")
                        fallbackSb.append(t.trim())
                    } else {
                        if (sb.isNotEmpty()) sb.append(" ")
                        sb.append(t.trim())
                    }
                }
            }
            val chosen = if (sb.isNotEmpty()) sb.toString() else fallbackSb.toString()
            chosen.replace("**", "").replace("*", "").trim()
        } catch (_: Exception) {
            null
        }
    }
}
