package com.mitv.customlauncher.data

import android.app.ActivityManager
import android.app.SearchManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.view.KeyEvent
import com.mitv.customlauncher.service.DynamicIslandBus
import com.mitv.customlauncher.service.MediaStateBus
import com.mitv.customlauncher.service.VolumeHudBus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed interface AssistantState {
    data object Idle : AssistantState
    data object Listening : AssistantState
    data object Processing : AssistantState
    data class Result(val text: String) : AssistantState
    data class Error(val code: String) : AssistantState
}

interface AssistantEngine {
    val state: StateFlow<AssistantState>
    fun startSession()
    fun cancelSession()
}

class FakeAssistantEngine(
    private val scope: CoroutineScope,
    private val demoReplyText: String
) : AssistantEngine {
    private val _state = MutableStateFlow<AssistantState>(AssistantState.Idle)
    override val state: StateFlow<AssistantState> = _state.asStateFlow()
    override fun startSession() {}
    override fun cancelSession() {
        _state.value = AssistantState.Idle
    }
}

/**
 * Локальный 0-токенный маршрутизатор + глубокие действия управления Android TV:
 * - мгновенная смена цвета лаунчера/ползунка/островка на любой оттенок (RU/UK/EN)
 * - мгновенный запуск стрима Калатая на Kick (https://kick.com/kalatay3) и любых каналов Kick
 * - глубокий запуск треков и исполнителей в Spotify с авто-стартом воспроизведения
 * - поиск видео на YouTube, управление громкостью, медиа-плеером, ОЗУ и приложениями
 */
object LocalVoiceCommandRouter {

    data class LocalActionResult(
        val confirmationText: String,
        val isQuickCommand: Boolean = true
    )

    var onThemeColorChanged: ((String) -> Unit)? = null
    var onVolumeChangedCallback: (() -> Unit)? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    fun tryExecuteLocalCommand(context: Context, rawText: String): LocalActionResult? {
        val text = rawText.trim()
        if (text.isEmpty()) return null
        val lower = text.lowercase(Locale.getDefault())
            .replace("ё", "е")
            .trim()

        // 1. Смена цвета лаунчера / ползунка / Dynamic Island (0 токенов — понимает любые формулировки!)
        val colorAction = tryMatchColorChangeCommand(context, lower)
        if (colorAction != null) {
            return colorAction
        }

        // 2. Стримы на Kick (например: «запусти кик стрим калатая», «включи калатая на кике», «открой кик калатай»)
        if (lower.contains("калатай") || lower.contains("калатая") || lower.contains("калатаю") ||
            lower.contains("kalatay") || lower.contains("kalatai") || lower.contains("kolotay")
        ) {
            launchKickStream(context, "kalatay3")
            return LocalActionResult("✦ Включаю стрим Калатая на Kick (kalatay3)")
        }

        if (lower.contains("кик ") || lower.contains(" на кике") || lower.contains(" в кике") || lower.contains("kick")) {
            val slug = extractKickStreamerSlug(lower)
            if (slug != null) {
                launchKickStream(context, slug)
                return LocalActionResult("✦ Открываю стрим на Kick: $slug")
            } else if (lower == "кик" || lower == "открой кик" || lower == "включи кик" || lower == "запусти кик" || lower == "kick") {
                launchKickStream(context, "")
                return LocalActionResult("✦ Открываю Kick")
            }
            // Если назван другой стример кириллицей — передаём в Gemini, чтобы он точно перевёл ник в slug!
            return null
        }

        // 3. Глубокий запуск трека или исполнителя в Spotify:
        //    Если пользователь просит конкретный трек/песню/исполнителя в Spotify —
        //    передаём в Gemini, чтобы он исправил транслит (например «уикенд» -> «The Weeknd») и вызвал [CMD:SPOTIFY:...]!
        val mentionsSpotify = lower.contains("спотифай") || lower.contains("спотик") ||
            lower.contains("спотифае") || lower.contains("spotify")
        val mentionsTrackOrArtist = lower.contains("трек ") || lower.contains("песню ") ||
            lower.contains("пісню ") || lower.contains("исполнител") || lower.contains("альбом ") ||
            lower.contains("группу ") || lower.contains("плейлист")

        if (mentionsSpotify || mentionsTrackOrArtist) {
            // Проверяем, не просто ли это команда «открой спотифай» без названия песни
            val strippedSpotify = lower
                .replace("открой", "")
                .replace("включи", "")
                .replace("запусти", "")
                .replace("відкрий", "")
                .replace("увімкни", "")
                .replace("спотифай", "")
                .replace("спотик", "")
                .replace("spotify", "")
                .replace("пожалуйста", "")
                .trim()
            if (mentionsSpotify && strippedSpotify.isEmpty()) {
                // Просто запуск самого приложения Spotify (0 токенов)
                val appLauncher = AppLauncher(context.applicationContext)
                val spApp = appLauncher.getInstalledApps().firstOrNull {
                    it.packageName.lowercase().contains("spotify") || it.label.lowercase().contains("spotify")
                }
                if (spApp != null) {
                    MediaStateBus.onMediaAppOpened(spApp.packageName)
                    appLauncher.launchPackage(spApp.packageName)
                    return LocalActionResult("✦ Открываю ${spApp.label}")
                }
            } else {
                // Конкретный трек или артист -> отдаём в Gemini для идеального распознавания имени артиста/трека!
                return null
            }
        }

        // 4. Поиск на YouTube («найди на ютубе ...», «включи на ютубе ...»)
        val ytPrefixes = listOf(
            "найди на ютубе ", "найди в ютубе ", "найди на youtube ", "найди в youtube ",
            "поищи на ютубе ", "поищи в ютубе ", "включи на ютубе ", "открой на ютубе ",
            "знайди на ютубі ", "включи на ютубі ", "ютуб поиск ", "youtube search "
        )
        for (prefix in ytPrefixes) {
            if (lower.startsWith(prefix)) {
                val query = text.substring(prefix.length).trim()
                if (query.isNotEmpty()) {
                    launchYouTubeSearch(context, query)
                    return LocalActionResult("✦ YouTube: «$query»")
                }
            }
        }

        // 5. Управление громкостью и звуком (0 токенов!)
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        if (am != null) {
            val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            val curVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            val curPct = ((curVol * 100f) / maxVol).toInt().coerceIn(0, 100)

            if (lower.contains("громкост") || lower.contains("гучніст") || lower.contains("звук") || lower.contains("volume")) {
                val numMatch = Regex("(\d{1,3})").find(lower)
                if (numMatch != null) {
                    val targetPct = numMatch.groupValues[1].toIntOrNull()?.coerceIn(0, 100)
                    if (targetPct != null) {
                        setVolumePercent(context, targetPct)
                        return LocalActionResult("✦ Громкость установлена на $targetPct%")
                    }
                }
            }

            if (lower == "выключи звук" || lower == "без звука" || lower == "мут" || lower == "убери звук" ||
                lower == "тишина" || lower == "вимкни звук" || lower == "mute"
            ) {
                try {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
                } catch (_: Exception) {
                }
                onVolumeChangedCallback?.invoke()
                VolumeHudBus.notifyVolumeChanged()
                return LocalActionResult("✦ Звук выключен (Mute)")
            }

            if (lower == "включи звук" || lower == "верни звук" || lower == "размуть" || lower == "увімкни звук" || lower == "unmute") {
                try {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
                } catch (_: Exception) {
                }
                onVolumeChangedCallback?.invoke()
                VolumeHudBus.notifyVolumeChanged()
                return LocalActionResult("✦ Звук включён")
            }

            if (lower == "громче" || lower == "сделай громче" || lower == "добавь звук" ||
                lower == "добавь звука" || lower == "прибавь звук" || lower == "прибавь громкость" ||
                lower == "увеличь громкость" || lower == "звук больше" || lower == "погромче" ||
                lower == "гучніше" || lower == "зроби гучніше" || lower == "volume up"
            ) {
                val newPct = (curPct + 15).coerceAtMost(100)
                val targetVol = ((newPct * maxVol) / 100f + 0.5f).toInt().coerceIn((curVol + 1).coerceAtMost(maxVol), maxVol)
                try {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
                } catch (_: Exception) {
                }
                val updatedPct = ((am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100f) / maxVol).toInt().coerceIn(0, 100)
                onVolumeChangedCallback?.invoke()
                VolumeHudBus.notifyVolumeChanged()
                return LocalActionResult("✦ Громкость: $updatedPct%")
            }

            if (lower == "тише" || lower == "сделай тише" || lower == "убавь звук" ||
                lower == "убавь громкость" || lower == "уменьши громкость" || lower == "звук меньше" ||
                lower == "потише" || lower == "тихіше" || lower == "зроби тихіше" || lower == "volume down"
            ) {
                val newPct = (curPct - 15).coerceAtLeast(0)
                val targetVol = ((newPct * maxVol) / 100f).toInt().coerceIn(0, (curVol - 1).coerceAtLeast(0))
                try {
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
                } catch (_: Exception) {
                }
                val updatedPct = ((am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100f) / maxVol).toInt().coerceIn(0, 100)
                onVolumeChangedCallback?.invoke()
                VolumeHudBus.notifyVolumeChanged()
                return LocalActionResult("✦ Громкость: $updatedPct%")
            }

            // 6. Управление медиа-плеером (0 токенов!)
            if (lower == "пауза" || lower == "поставь на паузу" || lower == "останови музыку" || lower == "стоп" || lower == "pause") {
                MediaStateBus.dispatchTransportAction("PLAY_PAUSE", am)
                return LocalActionResult("✦ Пауза")
            }
            if (lower == "продолжи" || lower == "играй" || lower == "воспроизведение" || lower == "play") {
                MediaStateBus.dispatchTransportAction("PLAY_PAUSE", am)
                return LocalActionResult("✦ Воспроизведение")
            }
            if (lower == "следующий трек" || lower == "следующая песня" || lower == "дальше" ||
                lower == "переключи трек" || lower == "наступний трек" || lower == "next"
            ) {
                MediaStateBus.dispatchTransportAction("NEXT", am)
                return LocalActionResult("✦ Следующий трек")
            }
            if (lower == "предыдущий трек" || lower == "предыдущая песня" || lower == "прошлый трек" ||
                lower == "попередній трек" || lower == "previous"
            ) {
                MediaStateBus.dispatchTransportAction("PREV", am)
                return LocalActionResult("✦ Предыдущий трек")
            }
        }

        // 7. Очистка ОЗУ (0 токенов!)
        if (lower.contains("очисти память") || lower.contains("очисти оператив") ||
            lower.contains("ускорь приставк") || lower.contains("освободи память") ||
            lower == "ускорение" || lower == "ускорь" || lower.contains("очисти пам'ять")
        ) {
            cleanRamBackground(context)
            return LocalActionResult("✦ Фоновые процессы закрыты · ОЗУ очищено")
        }

        // 8. Текущее время / дата (0 токенов!)
        if (lower == "сколько времени" || lower == "который час" || lower == "время" ||
            lower == "какое сегодня число" || lower == "котра година"
        ) {
            val fmt = SimpleDateFormat("HH:mm · EEEE, d MMMM", Locale("ru"))
            return LocalActionResult("✦ Сейчас ${fmt.format(Date())}")
        }

        // 9. Открытие системных настроек и установленных приложений (только если это короткая команда запуска приложения)
        val launchPrefixes = listOf(
            "открой ", "включи ", "запусти ", "перейди в ", "зайди в ", "покажи ",
            "відкрий ", "увімкни ", "запусти ", "open ", "launch "
        )
        val matchedPrefix = launchPrefixes.firstOrNull { lower.startsWith(it) }
        val hasLaunchVerb = matchedPrefix != null
        val targetPhrase = if (matchedPrefix != null) lower.removePrefix(matchedPrefix).trim() else lower

        if (hasLaunchVerb || lower == "настройки" || lower == "вайфай" || lower == "блютуз" || lower == "налаштування") {
            if (targetPhrase == "вайфай" || targetPhrase == "вай-фай" || targetPhrase == "wi-fi" || targetPhrase == "wifi" ||
                targetPhrase == "настройки вайфай" || targetPhrase == "настройки wi-fi"
            ) {
                openSystemSettingsAction(context, Settings.ACTION_WIFI_SETTINGS)
                return LocalActionResult("✦ Открываю настройки Wi-Fi")
            }
            if (targetPhrase == "блютуз" || targetPhrase == "bluetooth" || targetPhrase == "настройки блютуз") {
                openSystemSettingsAction(context, Settings.ACTION_BLUETOOTH_SETTINGS)
                return LocalActionResult("✦ Открываю настройки Bluetooth")
            }
            if (targetPhrase == "настройки" || targetPhrase == "системные настройки" ||
                targetPhrase == "настройки тв" || targetPhrase == "налаштування" || targetPhrase == "settings"
            ) {
                openSystemSettingsAction(context, Settings.ACTION_SETTINGS)
                return LocalActionResult("✦ Открываю настройки Android TV")
            }
        }

        // Запускаем приложение локально только если фраза короткая (1–3 слова) и не содержит сложных уточнений
        val wordsCount = targetPhrase.split(" ").filter { it.isNotBlank() }.size
        if ((hasLaunchVerb && wordsCount <= 3) || (!hasLaunchVerb && wordsCount <= 2)) {
            val appLauncher = AppLauncher(context.applicationContext)
            val installed = appLauncher.getInstalledApps()
            val matchedApp = matchInstalledAppByVoice(targetPhrase, installed, strictIfNoVerb = !hasLaunchVerb)
            if (matchedApp != null) {
                MediaStateBus.onMediaAppOpened(matchedApp.packageName)
                appLauncher.launchPackage(matchedApp.packageName)
                return LocalActionResult("✦ Открываю ${matchedApp.label}")
            }
        }

        return null
    }

    private fun tryMatchColorChangeCommand(context: Context, lower: String): LocalActionResult? {
        val colorKeywords = listOf(
            "цвет", "колір", "тему", "тема", "обводк", "подсветк", "акцент", "color", "theme",
            "перекрась", "покрась", "сделай ", "поставь ", "поменяй ", "измени ", "включи ",
            "зроби ", "постав ", "зміни "
        )
        if (colorKeywords.none { lower.contains(it) }) return null
        // Не перехватываем, если человек просит включить песню/трек/клип/фильм с цветным словом в названии
        if (lower.contains("трек") || lower.contains("песн") || lower.contains("пісн") ||
            lower.contains("спотиф") || lower.contains("spotify") || lower.contains("ютуб") ||
            lower.contains("youtube") || lower.contains("фильм") || lower.contains("стрим")
        ) {
            return null
        }

        val matchedColor: Pair<String, String>? = when {
            lower.contains("изумруд") || lower.contains("зелен") || lower.contains("салатов") ||
                lower.contains("мятн") || lower.contains("green") || lower.contains("emerald") ->
                "#34D399" to "Изумрудный"
            lower.contains("красн") || lower.contains("алый") || lower.contains("бордов") ||
                lower.contains("червон") || lower.contains("red") || lower.contains("crimson") ->
                "#EF4444" to "Красный"
            lower.contains("розов") || lower.contains("малинов") || lower.contains("пурпур") ||
                lower.contains("неоново розов") || lower.contains("рожев") || lower.contains("pink") || lower.contains("magenta") ->
                "#EC4899" to "Розовый неон"
            lower.contains("аметист") || lower.contains("фиолет") || lower.contains("сиренев") ||
                lower.contains("лавандов") || lower.contains("фіолет") || lower.contains("purple") || lower.contains("violet") ->
                "#A78BFA" to "Аметист (Фиолетовый)"
            lower.contains("сапфир") || lower.contains("синий") || lower.contains("синюю") ||
                lower.contains("синим") || lower.contains("синій") || lower.contains("индиго") || lower.contains("blue") ->
                "#60A5FA" to "Сапфировый синий"
            lower.contains("неон") || lower.contains("голуб") || lower.contains("бирюз") ||
                lower.contains("циан") || lower.contains("стандарт") || lower.contains("штатн") ||
                lower.contains("блакитн") || lower.contains("cyan") ->
                "#00F0FF" to "Бирюзовый неон"
            lower.contains("янтар") || lower.contains("желт") || lower.contains("золот") ||
                lower.contains("лимон") || lower.contains("жовт") || lower.contains("yellow") || lower.contains("gold") || lower.contains("amber") ->
                "#F59E0B" to "Тёплый янтарь"
            lower.contains("оранж") || lower.contains("рыж") || lower.contains("персик") ||
                lower.contains("помаранч") || lower.contains("orange") ->
                "#F97316" to "Оранжевый"
            lower.contains("серебр") || lower.contains("белый") || lower.contains("белую") ||
                lower.contains("белым") || lower.contains("серый") || lower.contains("платин") ||
                lower.contains("білий") || lower.contains("срібн") || lower.contains("white") || lower.contains("silver") ->
                "#E2E8F0" to "Платиновый серебристый"
            else -> null
        }

        if (matchedColor != null) {
            val (hex, name) = matchedColor
            applyThemeColorEverywhere(context, hex)
            return LocalActionResult("✦ Цвет темы изменён: $name")
        }
        return null
    }

    fun applyThemeColorEverywhere(context: Context, hex: String) {
        val cleanHex = if (hex.startsWith("#")) hex else "#$hex"
        try {
            android.graphics.Color.parseColor(cleanHex)
        } catch (_: Exception) {
            return
        }
        AppLauncher(context.applicationContext).saveAccentColorHex(cleanHex)
        mainHandler.post {
            onThemeColorChanged?.invoke(cleanHex)
            DynamicIslandBus.notifyAccentColorChanged(cleanHex)
        }
    }

    fun setVolumePercent(context: Context, targetPct: Int) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val clamped = targetPct.coerceIn(0, 100)
        val targetVol = ((clamped * maxVol) / 100f + 0.5f).toInt().coerceIn(0, maxVol)
        try {
            if (clamped > 0) {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
            }
            am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
        } catch (_: Exception) {
        }
        mainHandler.post {
            onVolumeChangedCallback?.invoke()
            VolumeHudBus.notifyVolumeChanged()
        }
    }

    private fun extractKickStreamerSlug(lower: String): String? {
        if (lower.contains("калатай") || lower.contains("калатая") || lower.contains("kalatay")) {
            return "kalatay3"
        }
        if (lower.contains("меллстрой") || lower.contains("мелстрой") || lower.contains("mellstroy")) {
            return "mellstroy"
        }
        val latinMatch = Regex("\b([a-z0-9_]{3,25})\b").findAll(lower)
            .map { it.groupValues[1] }
            .firstOrNull { it != "kick" && it != "stream" && it != "live" && it != "com" }
        return latinMatch
    }

    fun launchKickStream(context: Context, channelSlug: String) {
        val cleanSlug = channelSlug.trim().removePrefix("https://kick.com/").removePrefix("kick.com/").trim('/')
        val url = if (cleanSlug.isNotEmpty()) "https://kick.com/$cleanSlug" else "https://kick.com"
        val appLauncher = AppLauncher(context.applicationContext)
        val allApps = appLauncher.getInstalledApps()

        // 1. Если установлен клиент Kick — открываем в нём
        val kickApp = allApps.firstOrNull {
            it.packageName.lowercase().contains("kick") || it.label.lowercase() == "kick"
        }
        if (kickApp != null) {
            try {
                val kickIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    setPackage(kickApp.packageName)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(kickIntent)
                return
            } catch (_: Exception) {
            }
        }

        // 2. Открываем напрямую в установленном ТВ-браузере (сначала проверяем слот 2 Браузер, затем все браузеры)
        launchUrlInTvBrowser(context, url)
    }

    fun launchUrlInTvBrowser(context: Context, url: String) {
        val finalUrl = if (url.startsWith("http://") || url.startsWith("https://")) url else "https://$url"
        val uri = Uri.parse(finalUrl)
        val appLauncher = AppLauncher(context.applicationContext)
        val allApps = appLauncher.getInstalledApps()

        val browserCandidate = appLauncher.getBoundAppForSlot(CardSlot.SLOT_2, allApps)
            ?: allApps.firstOrNull {
                val p = it.packageName.lowercase()
                val l = it.label.lowercase()
                p.contains("browser") || p.contains("chrome") || p.contains("tvbro") ||
                    p.contains("puffin") || p.contains("firefox") || p.contains("opera") ||
                    l.contains("браузер") || l.contains("browser")
            }

        if (browserCandidate != null) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                    setPackage(browserCandidate.packageName)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return
            } catch (_: Exception) {
            }
        }

        try {
            val generic = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(generic)
        } catch (_: Exception) {
        }
    }

    /**
     * Глубокий запуск конкретного трека или исполнителя в Spotify на Android TV:
     * 1. Пробует MEDIA_PLAY_FROM_SEARCH (мгновенное воспроизведение трека/артиста)
     * 2. Пробует ACTION_SEARCH / spotify:search:URI внутри пакета Spotify
     * 3. Отправляет медиа-команду PLAY и авто-нажатие выбора, чтобы трек сразу заиграл!
     */
    fun launchSpotifyTrackOrArtist(context: Context, rawQuery: String) {
        val query = rawQuery.trim()
        if (query.isEmpty()) return
        val appLauncher = AppLauncher(context.applicationContext)
        val allApps = appLauncher.getInstalledApps()
        val spotifyApp = allApps.firstOrNull {
            val p = it.packageName.lowercase()
            p.contains("spotify") || it.label.lowercase().contains("spotify")
        }
        val spotifyPkg = spotifyApp?.packageName

        if (spotifyPkg != null) {
            MediaStateBus.onMediaAppOpened(spotifyPkg)

            // Попытка 1: Прямой голосовой интент воспроизведения MEDIA_PLAY_FROM_SEARCH
            try {
                val playIntent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
                    setPackage(spotifyPkg)
                    putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                    putExtra(SearchManager.QUERY, query)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                context.startActivity(playIntent)
                scheduleSpotifyAutoPlayKick(context)
                return
            } catch (_: Exception) {
            }

            // Попытка 2: Deep-link spotify:search:<query>
            try {
                val uriIntent = Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:${Uri.encode(query)}")).apply {
                    setPackage(spotifyPkg)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                context.startActivity(uriIntent)
                scheduleSpotifyAutoPlayKick(context)
                return
            } catch (_: Exception) {
            }

            // Попытка 3: ACTION_SEARCH внутри пакета Spotify TV
            try {
                val searchIntent = Intent(Intent.ACTION_SEARCH).apply {
                    setPackage(spotifyPkg)
                    putExtra(SearchManager.QUERY, query)
                    putExtra("query", query)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                context.startActivity(searchIntent)
                scheduleSpotifyAutoPlayKick(context)
                return
            } catch (_: Exception) {
            }

            appLauncher.launchPackage(spotifyPkg)
            scheduleSpotifyAutoPlayKick(context)
            return
        }

        // Если Spotify не установлен — ищем трек на YouTube!
        launchYouTubeSearch(context, query)
    }

    private fun scheduleSpotifyAutoPlayKick(context: Context) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        mainHandler.postDelayed({
            try {
                val now = SystemClock.uptimeMillis()
                val down = KeyEvent(now, now, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY, 0)
                val up = KeyEvent(now, now, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY, 0)
                am.dispatchMediaKeyEvent(down)
                am.dispatchMediaKeyEvent(up)
            } catch (_: Exception) {
            }
        }, 2000L)
    }

    private fun matchInstalledAppByVoice(
        phrase: String,
        apps: List<InstalledAppInfo>,
        strictIfNoVerb: Boolean
    ): InstalledAppInfo? {
        val clean = phrase.lowercase(Locale.getDefault()).trim()
        if (clean.length < 2) return null

        for (app in apps) {
            val labelLower = app.label.lowercase(Locale.getDefault())
            if (labelLower == clean || (!strictIfNoVerb && (labelLower.contains(clean) || clean.contains(labelLower)))) {
                return app
            }
        }

        val synonymKeywords: List<String>? = when {
            clean == "ютуб" || clean == "ютьюб" || clean == "youtube" ->
                listOf("youtube", "smarttube")
            clean == "спотифай" || clean == "спотик" || clean == "spotify" ->
                listOf("spotify")
            clean == "браузер" || clean == "интернет" || clean == "хром" || clean == "browser" ->
                listOf("browser", "chrome", "puffin", "tvbro", "firefox", "opera")
            clean.contains("трансляц") || clean == "каст" || clean == "airscreen" || clean == "cast" ->
                listOf("airscreen", "cast", "mediashell", "miracast")
            clean == "лампа" || clean == "lampa" ->
                listOf("lampa")
            clean == "смарттуб" || clean == "smarttube" ->
                listOf("smarttube")
            clean == "саундклауд" || clean == "soundcloud" ->
                listOf("soundcloud")
            clean == "влц" || clean == "vlc" ->
                listOf("vlc")
            clean == "коди" || clean == "kodi" ->
                listOf("kodi")
            clean == "нетфликс" || clean == "netflix" ->
                listOf("netflix")
            clean == "прайм" || clean == "prime" ->
                listOf("prime", "amazon")
            clean == "проводник" || clean == "файлы" || clean == "флешка" ->
                listOf("file", "explorer", "manager", "total", "xplore", "fx")
            else -> null
        }

        if (synonymKeywords != null) {
            for (kw in synonymKeywords) {
                val found = apps.firstOrNull {
                    it.packageName.lowercase().contains(kw) || it.label.lowercase().contains(kw)
                }
                if (found != null) return found
            }
        }

        return null
    }

    fun launchYouTubeSearch(context: Context, query: String) {
        val appLauncher = AppLauncher(context.applicationContext)
        val apps = appLauncher.getInstalledApps()
        val ytApp = apps.firstOrNull {
            val p = it.packageName.lowercase()
            p.contains("youtube.tv") || p.contains("smarttube") || p.contains("youtube")
        }
        try {
            val searchIntent = Intent(Intent.ACTION_SEARCH).apply {
                if (ytApp != null) setPackage(ytApp.packageName)
                putExtra(SearchManager.QUERY, query)
                putExtra("query", query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(searchIntent)
            return
        } catch (_: Exception) {
        }
        try {
            val webUri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query))
            val viewIntent = Intent(Intent.ACTION_VIEW, webUri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(viewIntent)
        } catch (_: Exception) {
        }
    }

    private fun openSystemSettingsAction(context: Context, action: String) {
        try {
            val intent = Intent(action).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            try {
                val fallback = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(fallback)
            } catch (_: Exception) {
            }
        }
    }

    fun cleanRamBackground(context: Context) {
        try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return
            val apps = AppLauncher(context.applicationContext).getInstalledApps()
            for (app in apps) {
                val p = app.packageName.lowercase()
                if (app.packageName != context.packageName &&
                    !p.contains("spotify") &&
                    !p.contains("mediashell") &&
                    !p.contains("soundcloud")
                ) {
                    am.killBackgroundProcesses(app.packageName)
                }
            }
        } catch (_: Exception) {
        }
    }
}

/**
 * Супер-клиент Gemini API (2.5 & 3.x) с полным управлением Android TV:
 * - Понимает русский, украинский, английский, сленг и транслит
 * - Умеет включать конкретные треки/исполнителей в Spotify ([CMD:SPOTIFY:...])
 * - Умеет включать стримы на Kick ([CMD:KICK:kalatay3] и др.)
 * - Умеет менять цвет темы лаунчера и ползунка на любой оттенок ([CMD:COLOR:#HEX])
 * - Умеет искать видео на YouTube ([CMD:YT:...]), открывать сайты ([CMD:URL:...]), менять громкость и запускать приложения
 */
object GeminiCloudClient {

    private val candidateModels = listOf(
        "gemini-2.5-flash",
        "gemini-3-flash-preview",
        "gemini-3.1-flash-lite",
        "gemini-2.5-flash-lite",
        "gemini-2.5-pro",
        "gemini-2.0-flash"
    )

    @Volatile
    private var cachedEndpointTemplate: String? = null

    @Volatile
    private var cachedUseHeaderAuth: Boolean = true

    private fun buildCommandInstruction(context: Context): String {
        val apps = AppLauncher(context.applicationContext).getInstalledApps().take(25)
            .joinToString(", ") { "${it.label} (${it.packageName})" }
        return "Ты — умный голосовой ИИ-ассистент Gemini в кастомном лаунчере Android TV (Xiaomi Mi TV Stick). " +
            "Понимаешь русский, украинский и английский языки, включая голосовой транслит английских названий треков, артистов и стримеров. " +
            "Отвечай кратко, живо и по делу (1–3 предложения, без разметки Markdown и звёздочек). " +
            "ВАЖНО: Если пользователь просит выполнить действие на ТВ, ОБЯЗАТЕЛЬНО добавь в начале ответа соответствующий тег команды:
" +
            "- Включить песню, трек или исполнителя в Спотифай (Spotify): [CMD:SPOTIFY:Точное имя артиста и трека] (переводи русский транслит в оригинальное название, например «уикенд старбой» -> [CMD:SPOTIFY:The Weeknd Starboy])
" +
            "- Запустить стрим на Кике (Kick): [CMD:KICK:channel_slug] (для стримера Калатай / Kalatay всегда используй [CMD:KICK:kalatay3])
" +
            "- Найти или включить видео/канал на YouTube: [CMD:YT:поисковый запрос]
" +
            "- Изменить цвет лаунчера, обводки или ползунка на любой цвет: [CMD:COLOR:#RRGGBB] (например: красный #EF4444, розовый #EC4899, фиолетовый #A78BFA, зелёный/изумрудный #34D399, синий #60A5FA, голубой/бирюзовый #00F0FF, жёлтый/янтарный #F59E0B, оранжевый #F97316, белый/серебро #E2E8F0)
" +
            "- Открыть установленное приложение: [CMD:LAUNCH:package_name] (список установленных: $apps)
" +
            "- Открыть сайт в браузере: [CMD:URL:https://адрес]
" +
            "- Установить громкость в процентах: [CMD:VOL_SET:число_от_0_до_100], прибавить: [CMD:VOL_UP], убавить: [CMD:VOL_DOWN], выключить звук: [CMD:MUTE]
" +
            "- Пауза/продолжить/следующий трек: [CMD:PAUSE], [CMD:PLAY], [CMD:NEXT], [CMD:PREV]
" +
            "- Очистить память/ускорить: [CMD:BOOST]
" +
            "После тега напиши короткое подтверждение (например: «[CMD:SPOTIFY:Miyagi Captain] Включаю Miyagi — Captain в Spotify»). Если это просто вопрос — дай умный краткий ответ без тегов."
    }

    suspend fun askGeminiText(context: Context, userQuery: String): String = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext
        val apiKey = AppLauncher(appCtx).getGeminiApiKey()
        val fullPrompt = "${buildCommandInstruction(appCtx)}

Распознанная фраза пользователя: $userQuery"

        val payload = JSONObject().apply {
            put("contents", JSONArray().put(
                JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", fullPrompt)))
                }
            ))
            put("generationConfig", JSONObject().apply {
                put("maxOutputTokens", 700)
                put("temperature", 0.35)
            })
        }.toString()

        val rawReply = executeWithEndpointFallback(apiKey, payload)
        processCommandTags(appCtx, rawReply, fallbackQuery = userQuery)
    }

    suspend fun askGeminiAudio(context: Context, wavBytes: ByteArray): String = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext
        val apiKey = AppLauncher(appCtx).getGeminiApiKey()
        val audioPrompt = buildCommandInstruction(appCtx) +
            "

Прослушай голосовую команду пользователя (она может быть на русском, украинском или английском языке) и ответь."

        val b64Audio = Base64.encodeToString(wavBytes, Base64.NO_WRAP)
        val partsArray = JSONArray()
            .put(JSONObject().put("text", audioPrompt))
            .put(JSONObject().put("inlineData", JSONObject().apply {
                put("mimeType", "audio/wav")
                put("data", b64Audio)
            }))

        val payload = JSONObject().apply {
            put("contents", JSONArray().put(
                JSONObject().apply {
                    put("role", "user")
                    put("parts", partsArray)
                }
            ))
            put("generationConfig", JSONObject().apply {
                put("maxOutputTokens", 700)
                put("temperature", 0.35)
            })
        }.toString()

        val rawReply = executeWithEndpointFallback(apiKey, payload)
        processCommandTags(appCtx, rawReply, fallbackQuery = "")
    }

    private fun processCommandTags(context: Context, reply: String, fallbackQuery: String): String {
        var clean = reply.trim()
        val cmdRegex = Regex("\[CMD:([^\]]+)\]")
        val matches = cmdRegex.findAll(clean).toList()

        if (matches.isNotEmpty()) {
            val handler = Handler(Looper.getMainLooper())
            for (m in matches) {
                clean = clean.replace(m.value, "").trim()
                val tagContent = m.groupValues[1]
                val parts = tagContent.split(":", limit = 2)
                val action = parts[0].trim().uppercase(Locale.US)
                val arg = parts.getOrNull(1)?.trim().orEmpty()

                handler.post {
                    when (action) {
                        "SPOTIFY" -> if (arg.isNotEmpty()) {
                            LocalVoiceCommandRouter.launchSpotifyTrackOrArtist(context, arg)
                        }
                        "KICK" -> {
                            val slug = if (arg.lowercase().contains("kalatay") || arg.lowercase().contains("калатай")) {
                                "kalatay3"
                            } else {
                                arg
                            }
                            LocalVoiceCommandRouter.launchKickStream(context, slug)
                        }
                        "YT" -> if (arg.isNotEmpty()) {
                            LocalVoiceCommandRouter.launchYouTubeSearch(context, arg)
                        }
                        "COLOR" -> if (arg.isNotEmpty()) {
                            LocalVoiceCommandRouter.applyThemeColorEverywhere(context, arg)
                        }
                        "LAUNCH" -> if (arg.isNotEmpty()) {
                            MediaStateBus.onMediaAppOpened(arg)
                            AppLauncher(context).launchPackage(arg)
                        }
                        "URL" -> if (arg.isNotEmpty()) {
                            LocalVoiceCommandRouter.launchUrlInTvBrowser(context, arg)
                        }
                        "VOL_SET" -> {
                            val pct = arg.toIntOrNull()
                            if (pct != null) {
                                LocalVoiceCommandRouter.setVolumePercent(context, pct)
                            }
                        }
                        "VOL_UP" -> LocalVoiceCommandRouter.tryExecuteLocalCommand(context, "громче")
                        "VOL_DOWN" -> LocalVoiceCommandRouter.tryExecuteLocalCommand(context, "тише")
                        "MUTE" -> LocalVoiceCommandRouter.tryExecuteLocalCommand(context, "выключи звук")
                        "UNMUTE" -> LocalVoiceCommandRouter.tryExecuteLocalCommand(context, "включи звук")
                        "PAUSE" -> LocalVoiceCommandRouter.tryExecuteLocalCommand(context, "пауза")
                        "PLAY" -> LocalVoiceCommandRouter.tryExecuteLocalCommand(context, "продолжи")
                        "NEXT" -> LocalVoiceCommandRouter.tryExecuteLocalCommand(context, "следующий трек")
                        "PREV" -> LocalVoiceCommandRouter.tryExecuteLocalCommand(context, "предыдущий трек")
                        "BOOST" -> LocalVoiceCommandRouter.cleanRamBackground(context)
                    }
                }
            }
            return "✦ " + clean.removePrefix("✦").trim().ifEmpty { "Команда выполнена" }
        }

        // Fallback: если сеть/API вернула ошибку, но пользователь просил включить трек в Spotify
        if (clean.startsWith("Ошибка") || clean.startsWith("Не удалось")) {
            val lowerFallback = fallbackQuery.lowercase(Locale.getDefault())
            if (lowerFallback.contains("спотифай") || lowerFallback.contains("спотик") || lowerFallback.contains("spotify") || lowerFallback.contains("трек")) {
                val extracted = lowerFallback
                    .replace("включи", "")
                    .replace("запусти", "")
                    .replace("открой", "")
                    .replace("поставь", "")
                    .replace("трек", "")
                    .replace("песню", "")
                    .replace("в спотифае", "")
                    .replace("в спотифай", "")
                    .replace("спотифай", "")
                    .replace("в spotify", "")
                    .replace("spotify", "")
                    .trim()
                if (extracted.isNotEmpty()) {
                    Handler(Looper.getMainLooper()).post {
                        LocalVoiceCommandRouter.launchSpotifyTrackOrArtist(context, extracted)
                    }
                    return "✦ Включаю в Spotify: «$extracted»"
                }
            }
        }

        return clean
    }

    private fun executeWithEndpointFallback(apiKey: String, jsonBody: String): String {
        val cached = cachedEndpointTemplate
        if (cached != null) {
            val res = trySingleRequest(cached, apiKey, cachedUseHeaderAuth, jsonBody)
            val cachedTxt = res.text
            if (res.isSuccess && !cachedTxt.isNullOrBlank()) {
                return cachedTxt
            }
        }

        val endpointTemplates = listOf(
            "https://aiplatform.googleapis.com/v1/publishers/google/models/%s:generateContent" to true,
            "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent" to true,
            "https://aiplatform.googleapis.com/v1/publishers/google/models/%s:generateContent" to false,
            "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent" to false
        )

        var lastErr = ""
        for (model in candidateModels) {
            for ((template, useHeader) in endpointTemplates) {
                val urlStr = String.format(Locale.US, template, model)
                val res = trySingleRequest(urlStr, apiKey, useHeader, jsonBody)
                val txt = res.text
                if (res.isSuccess && !txt.isNullOrBlank()) {
                    cachedEndpointTemplate = urlStr
                    cachedUseHeaderAuth = useHeader
                    return txt
                } else if (res.errorSummary.isNotBlank()) {
                    lastErr = res.errorSummary
                }
            }
        }

        return if (lastErr.isNotBlank()) {
            "Ошибка ответа Gemini ($lastErr)"
        } else {
            "Не удалось связаться с Gemini. Проверьте интернет-соединение."
        }
    }

    private data class HttpResult(
        val isSuccess: Boolean,
        val text: String? = null,
        val errorSummary: String = ""
    )

    private fun trySingleRequest(
        baseUrl: String,
        apiKey: String,
        useHeaderAuth: Boolean,
        jsonBody: String
    ): HttpResult {
        var conn: HttpURLConnection? = null
        return try {
            val finalUrl = if (useHeaderAuth) {
                baseUrl
            } else {
                "$baseUrl?key=${Uri.encode(apiKey)}"
            }
            val connection = (URL(finalUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 7000
                readTimeout = 12000
                doOutput = true
                doInput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                if (useHeaderAuth) {
                    setRequestProperty("x-goog-api-key", apiKey)
                }
            }
            conn = connection
            connection.outputStream.use { os ->
                os.write(jsonBody.toByteArray(Charsets.UTF_8))
            }
            val code = connection.responseCode
            if (code in 200..299) {
                val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val parsed = extractTextFromGeminiJson(body)
                if (!parsed.isNullOrBlank()) {
                    HttpResult(isSuccess = true, text = parsed)
                } else {
                    HttpResult(isSuccess = false, errorSummary = "Empty response")
                }
            } else {
                HttpResult(isSuccess = false, errorSummary = "HTTP $code")
            }
        } catch (e: Exception) {
            HttpResult(isSuccess = false, errorSummary = e.javaClass.simpleName)
        } finally {
            try {
                conn?.disconnect()
            } catch (_: Exception) {
            }
        }
    }

    private fun extractTextFromGeminiJson(rawJson: String): String? {
        return try {
            val root = JSONObject(rawJson)
            val candidates = root.optJSONArray("candidates") ?: return null
            if (candidates.length() == 0) return null
            val content = candidates.optJSONObject(0)?.optJSONObject("content") ?: return null
            val parts = content.optJSONArray("parts") ?: return null
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val partObj = parts.optJSONObject(i) ?: continue
                if (partObj.optBoolean("thought", false)) continue
                val t = partObj.optString("text", "")
                if (t.isNotBlank()) {
                    if (sb.isNotEmpty()) sb.append(" ")
                    sb.append(t.trim())
                }
            }
            sb.toString().replace("**", "").replace("*", "").trim()
        } catch (_: Exception) {
            null
        }
    }
}
