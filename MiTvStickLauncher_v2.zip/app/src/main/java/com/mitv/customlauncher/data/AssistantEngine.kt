package com.mitv.customlauncher.data

import android.app.ActivityManager
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.isActive
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import android.graphics.Color
import kotlinx.coroutines.delay
import java.nio.ByteOrder
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import kotlin.math.sqrt
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.speech.tts.TextToSpeech
import com.mitv.customlauncher.service.DynamicIslandBus
import com.mitv.customlauncher.service.RemoteConsoleServer
import com.mitv.customlauncher.service.ShellKeyController
import android.util.Base64
import android.util.Log
import android.widget.Toast
import android.view.KeyEvent
import com.mitv.customlauncher.service.TvUiControllerBus
import com.mitv.customlauncher.service.MediaStateBus
import com.mitv.customlauncher.service.NavSoundPlayer
import com.mitv.customlauncher.service.VolumeHudBus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed interface AssistantState {
    data object Idle : AssistantState
    data object Listening : AssistantState
    data object Processing : AssistantState
    data class Result(val text: String) : AssistantState
    data class Error(val code: String) : AssistantState
}

interface AssistantEngine {
    val state: StateFlow<AssistantState>
    fun startSession()
    fun cancelSession()
}

class FakeAssistantEngine(
    private val scope: CoroutineScope,
    private val demoReplyText: String
) : AssistantEngine {
    private val _state = MutableStateFlow<AssistantState>(AssistantState.Idle)
    override val state: StateFlow<AssistantState> = _state.asStateFlow()
    override fun startSession() {}
    override fun cancelSession() {
        _state.value = AssistantState.Idle
    }
}

/**
 * Исполнитель глубоких действий Android TV, вызываемых напрямую ИИ Gemini:
 * - запуск треков и артистов в Spotify (MEDIA_PLAY_FROM_SEARCH + spotify:search + авто-PLAY)
 * - запуск стримов на Kick (kalatay3 и любые другие каналы)
 * - смена цвета лаунчера/ползунка/островка на любой HEX-цвет
 * - управление громкостью, плеером, памятью, приложениями и звуком щелчков пульта
 */
object LocalVoiceCommandRouter {

    data class LocalActionResult(
        val confirmationText: String,
        val isQuickCommand: Boolean = true
    )

    var onThemeColorChanged: ((String) -> Unit)? = null
    var onVolumeChangedCallback: (() -> Unit)? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    /**
     * В v3.8 100% всех голосовых запросов обрабатываются напрямую через Gemini,
     * чтобы идеально понимать украинский, русский, суржик и английский без жёстких шаблонов!
     */
    fun tryExecuteLocalCommand(context: Context, rawText: String): LocalActionResult? {
        return null
    }

    fun executeSystemAudioCommand(context: Context, actionType: String) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val curVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val curPct = ((curVol * 100f) / maxVol).toInt().coerceIn(0, 100)

        when (actionType) {
            "VOL_UP" -> {
                val newPct = (curPct + 15).coerceAtMost(100)
                val targetVol = ((newPct * maxVol) / 100f + 0.5f).toInt().coerceIn((curVol + 1).coerceAtMost(maxVol), maxVol)
                try {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
                } catch (_: Exception) {
                }
                mainHandler.post {
                    onVolumeChangedCallback?.invoke()
                    VolumeHudBus.notifyVolumeChanged()
                }
            }
            "VOL_DOWN" -> {
                val newPct = (curPct - 15).coerceAtLeast(0)
                val targetVol = ((newPct * maxVol) / 100f).toInt().coerceIn(0, (curVol - 1).coerceAtLeast(0))
                try {
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
                } catch (_: Exception) {
                }
                mainHandler.post {
                    onVolumeChangedCallback?.invoke()
                    VolumeHudBus.notifyVolumeChanged()
                }
            }
            "MUTE" -> {
                try {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
                } catch (_: Exception) {
                }
                mainHandler.post {
                    onVolumeChangedCallback?.invoke()
                    VolumeHudBus.notifyVolumeChanged()
                }
            }
            "UNMUTE" -> {
                try {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
                } catch (_: Exception) {
                }
                mainHandler.post {
                    onVolumeChangedCallback?.invoke()
                    VolumeHudBus.notifyVolumeChanged()
                }
            }
            "PAUSE", "PLAY" -> {
                MediaStateBus.dispatchTransportAction("PLAY_PAUSE", am)
                Thread { ShellKeyController.sendKeyEvent(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) }.start()
            }
            "NEXT" -> {
                MediaStateBus.dispatchTransportAction("NEXT", am)
                Thread { ShellKeyController.sendKeyEvent(KeyEvent.KEYCODE_MEDIA_NEXT) }.start()
            }
            "PREV" -> {
                MediaStateBus.dispatchTransportAction("PREV", am)
                Thread { ShellKeyController.sendKeyEvent(KeyEvent.KEYCODE_MEDIA_PREVIOUS) }.start()
            }
        }
    }

    fun applyThemeColorEverywhere(context: Context, hex: String) {
        val cleanHex = if (hex.startsWith("#")) hex else "#$hex"
        try {
            android.graphics.Color.parseColor(cleanHex)
        } catch (_: Exception) {
            return
        }
        AppLauncher(context.applicationContext).saveAccentColorHex(cleanHex)
        mainHandler.post {
            onThemeColorChanged?.invoke(cleanHex)
            DynamicIslandBus.notifyAccentColorChanged(cleanHex)
        }
    }

    fun setVolumePercent(context: Context, targetPct: Int) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val clamped = targetPct.coerceIn(0, 100)
        val targetVol = ((clamped * maxVol) / 100f + 0.5f).toInt().coerceIn(0, maxVol)
        try {
            if (clamped > 0) {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
            }
            am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
        } catch (_: Exception) {
        }
        mainHandler.post {
            onVolumeChangedCallback?.invoke()
            VolumeHudBus.notifyVolumeChanged()
        }
    }

    fun launchKickStream(context: Context, channelSlug: String) {
        val cleanSlug = channelSlug.trim().removePrefix("https://kick.com/").removePrefix("kick.com/").trim('/')
        val url = if (cleanSlug.isNotEmpty()) "https://kick.com/$cleanSlug" else "https://kick.com"
        val appLauncher = AppLauncher(context.applicationContext)
        val pm = context.packageManager
        val allApps = appLauncher.getInstalledApps()

        val kickApp = allApps.firstOrNull {
            val p = it.packageName.lowercase()
            val l = it.label.lowercase()
            p.contains("kick") || l == "kick" || l.startsWith("kick:") || l.startsWith("kick ")
        }

        if (kickApp != null) {
            val pkg = kickApp.packageName
            // 1. Проверяем, поддерживает ли установленная версия Kick прямые ссылки (на телефоне — да, на Android TV — нет)
            val candidateUris = listOf(
                Uri.parse(url),
                Uri.parse("kick://channel/$cleanSlug"),
                Uri.parse("kick://$cleanSlug")
            )
            for (u in candidateUris) {
                try {
                    val deepIntent = Intent(Intent.ACTION_VIEW, u).apply {
                        setPackage(pkg)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    @Suppress("DEPRECATION")
                    if (pm.queryIntentActivities(deepIntent, 0).isNotEmpty()) {
                        context.startActivity(deepIntent)
                        return
                    }
                } catch (_: Exception) {
                }
            }

            // 2. Проверяем поддержку системного ACTION_SEARCH внутри Kick
            if (cleanSlug.isNotEmpty()) {
                try {
                    val searchIntent = Intent(Intent.ACTION_SEARCH).apply {
                        setPackage(pkg)
                        putExtra(SearchManager.QUERY, cleanSlug)
                        putExtra("query", cleanSlug)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    @Suppress("DEPRECATION")
                    if (pm.queryIntentActivities(searchIntent, 0).isNotEmpty()) {
                        context.startActivity(searchIntent)
                        return
                    }
                } catch (_: Exception) {
                }
            }

            // 3. ТВ-версия Kick («Kick: стриминг в прямом эфире»): запускаем само приложение Kick без белого окна ошибки
            // и включаем ИИ-автопоиск стримера через наш AccessibilityService!
            if (appLauncher.launchPackage(pkg)) {
                if (cleanSlug.isNotEmpty()) {
                    TvUiControllerBus.scheduleInAppSearch(pkg, cleanSlug)
                }
                return
            }
        }

        launchUrlInTvBrowser(context, url)
    }

    fun launchUrlInTvBrowser(context: Context, url: String) {
        val finalUrl = if (url.startsWith("http://") || url.startsWith("https://")) url else "https://$url"
        val uri = Uri.parse(finalUrl)
        val appLauncher = AppLauncher(context.applicationContext)
        val pm = context.packageManager
        val allApps = appLauncher.getInstalledApps()

        val browserCandidate = allApps.firstOrNull {
            val p = it.packageName.lowercase()
            val l = it.label.lowercase()
            p.contains("browser") || p.contains("chrome") || p.contains("tvbro") ||
                p.contains("puffin") || p.contains("firefox") || p.contains("opera") ||
                l.contains("браузер") || l.contains("browser")
        }

        if (browserCandidate != null) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                    setPackage(browserCandidate.packageName)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return
            } catch (_: Exception) {
            }
        }

        try {
            val generic = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            @Suppress("DEPRECATION")
            val handlers = pm.queryIntentActivities(generic, 0).filter {
                !it.activityInfo.packageName.lowercase().contains("tv.fw.browsable") &&
                    !it.activityInfo.name.lowercase().contains("stub")
            }
            if (handlers.isNotEmpty()) {
                context.startActivity(generic)
            }
        } catch (_: Exception) {
        }
    }

    fun launchSpotifyTrackOrArtist(context: Context, rawQuery: String) {
        val query = rawQuery.trim()
        if (query.isEmpty()) return
        val appLauncher = AppLauncher(context.applicationContext)
        val allApps = appLauncher.getInstalledApps()
        val spotifyApp = allApps.firstOrNull {
            val p = it.packageName.lowercase()
            p.contains("spotify") || it.label.lowercase().contains("spotify")
        }
        val spotifyPkg = spotifyApp?.packageName

        if (spotifyPkg != null) {
            MediaStateBus.seedTrackFromQuery(context, spotifyPkg, query)

            try {
                val playIntent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
                    setPackage(spotifyPkg)
                    putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                    putExtra(SearchManager.QUERY, query)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                context.startActivity(playIntent)
                scheduleSpotifyAutoPlayKick(context)
                return
            } catch (_: Exception) {
            }

            try {
                val uriIntent = Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:${Uri.encode(query)}")).apply {
                    setPackage(spotifyPkg)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                context.startActivity(uriIntent)
                scheduleSpotifyAutoPlayKick(context)
                return
            } catch (_: Exception) {
            }

            try {
                val searchIntent = Intent(Intent.ACTION_SEARCH).apply {
                    setPackage(spotifyPkg)
                    putExtra(SearchManager.QUERY, query)
                    putExtra("query", query)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                context.startActivity(searchIntent)
                scheduleSpotifyAutoPlayKick(context)
                return
            } catch (_: Exception) {
            }

            appLauncher.launchPackage(spotifyPkg)
            scheduleSpotifyAutoPlayKick(context)
            return
        }

        launchYouTubeSearch(context, query)
    }

    private fun scheduleSpotifyAutoPlayKick(context: Context) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        mainHandler.postDelayed({
            try {
                val now = SystemClock.uptimeMillis()
                val down = KeyEvent(now, now, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY, 0)
                val up = KeyEvent(now, now, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY, 0)
                am.dispatchMediaKeyEvent(down)
                am.dispatchMediaKeyEvent(up)
            } catch (_: Exception) {
            }
        }, 2000L)
    }

    fun launchYouTubeSearch(context: Context, query: String) {
        val cleanQuery = query.trim()
        val appLauncher = AppLauncher(context.applicationContext)
        val apps = appLauncher.getInstalledApps()
        val ytApp = apps.firstOrNull {
            val p = it.packageName.lowercase()
            p.contains("youtube.tv") || p.contains("smarttube") || p.contains("youtube")
        }
        val targetPkg = ytApp?.packageName ?: "com.google.android.youtube.tv"
        if (cleanQuery.isEmpty()) {
            appLauncher.launchPackage(targetPkg)
            return
        }
        try {
            val searchIntent = Intent(Intent.ACTION_SEARCH).apply {
                if (ytApp != null) setPackage(ytApp.packageName)
                putExtra(SearchManager.QUERY, cleanQuery)
                putExtra("query", cleanQuery)
                putExtra("va_play_first_result", true)
                putExtra(Intent.EXTRA_REFERRER, Uri.parse("android-app://com.google.android.katniss"))
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            context.startActivity(searchIntent)
            TvUiControllerBus.scheduleYouTubeAutoPlay(targetPkg, cleanQuery)
            return
        } catch (_: Exception) {
        }
        try {
            val webUri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(cleanQuery))
            val viewIntent = Intent(Intent.ACTION_VIEW, webUri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(viewIntent)
            TvUiControllerBus.scheduleYouTubeAutoPlay(targetPkg, cleanQuery)
        } catch (_: Exception) {
        }
    }

    fun launchPlayStoreSearch(context: Context, query: String) {
        val cleanQuery = query.trim()
        val appLauncher = AppLauncher(context.applicationContext)
        val marketPkg = "com.android.vending"
        if (cleanQuery.isEmpty()) {
            if (!appLauncher.launchPackage(marketPkg)) {
                launchUrlInTvBrowser(context, "https://play.google.com/store")
            }
            return
        }
        try {
            val marketUri = Uri.parse("market://search?q=" + Uri.encode(cleanQuery))
            val viewIntent = Intent(Intent.ACTION_VIEW, marketUri).apply {
                setPackage(marketPkg)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            context.startActivity(viewIntent)
            TvUiControllerBus.scheduleInAppSearch(marketPkg, cleanQuery)
            return
        } catch (_: Exception) {
        }
        if (appLauncher.launchPackage(marketPkg)) {
            TvUiControllerBus.scheduleInAppSearch(marketPkg, cleanQuery)
        } else {
            launchUrlInTvBrowser(context, "https://play.google.com/store/search?q=" + Uri.encode(cleanQuery))
        }
    }

    fun executeVideoSeek(spec: String) {
        val upper = spec.trim().uppercase(Locale.US)
        val isRewind = upper.contains("REW") || upper.contains("BACK") || upper.startsWith("-")
        val digits = Regex("[0-9]+").find(upper)?.value?.toIntOrNull() ?: 30
        val presses = (digits / 10).coerceIn(1, 12)
        val keyCode = if (isRewind) KeyEvent.KEYCODE_DPAD_LEFT else KeyEvent.KEYCODE_DPAD_RIGHT
        Thread {
            try {
                for (i in 0 until presses) {
                    ShellKeyController.sendKeyEvent(keyCode)
                    Thread.sleep(140L)
                }
                ShellKeyController.sendKeyEvent(KeyEvent.KEYCODE_DPAD_CENTER)
            } catch (_: Exception) {
            }
        }.start()
    }

    fun openSystemSettingsAction(context: Context, action: String) {
        try {
            val intent = Intent(action).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            try {
                val fallback = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(fallback)
            } catch (_: Exception) {
            }
        }
    }

    fun cleanRamBackground(context: Context) {
        try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return
            val apps = AppLauncher(context.applicationContext).getInstalledApps()
            for (app in apps) {
                val p = app.packageName.lowercase()
                if (app.packageName != context.packageName &&
                    !p.contains("spotify") &&
                    !p.contains("mediashell") &&
                    !p.contains("soundcloud") &&
                    !p.contains("remote") &&
                    !p.contains("katniss") &&
                    !p.contains("bluetooth") &&
                    !p.contains("google.android.gms")
                ) {
                    am.killBackgroundProcesses(app.packageName)
                }
            }
        } catch (_: Exception) {
        }
    }
}

/**
 * 100% Gemini-ассистент (2.5 & 3.8):
 * - Слушает живой голос напрямую в формате WAV (идеально понимает украинский, русский, суржик и английский!)
 * - Использует рабочий ключ XOR_PROTECTED_KEY (без ошибки 401!)
 * - Сам управляет Spotify, Kick, YouTube, цветами лаунчера, приложениями и звуком ТВ
 */
/**
 * Голосовой синтезатор речи ассистента (TTS) с мгновенным откликом,
 * автоопределением украинского/русского/английского языка и приглушением фоновой музыки (Audio Ducking).
 */
/**
 * Облачный голосовой синтезатор речи Gemini TTS (gemini-2.5-flash-preview-tts):
 * - 0 МБ фонового потребления ОЗУ (работает без системного com.google.android.tts напрямую через легковесный AudioTrack)
 * - 5 живых нейронных голосов на выбор: Puck, Charon, Fenrir (мужские) и Kore, Aoede (женские)
 * - Вычисляет реальную амплитуду звуковой волны (currentVoiceWaveLevel) каждые 40 мс для 60 FPS анимации полосок Dynamic Island
 */
/**
 * Контроллер умной Wi-Fi LED-ленты Tuya Smart Life (OpenAPI v2.0 HMAC-SHA256):
 * - 360° полный цветовой спектр HSV (Оттенок 0..360°, Насыщенность 10..100%, Яркость 10..100%)
 * - Автоопределение поддерживаемых датапоинтов ленты (v2 `colour_data_v2` / `bright_value_v2` и v1 `colour_data` / `bright_value`)
 * - 12 выверенных студийных пресетов оттенков + режим тёплого белого света
 * - 4 динамических режима (Радуга, Дыхание, Вечеринка, Ночник)
 * - Режим синхронизации с акцентным цветом темы лаунчера (Ambilight)
 */
data class LedSwatchPreset(
    val name: String,
    val hexColor: String,
    val hue: Int,
    val satPct: Int,
    val brightPct: Int = 100,
    val isWarmWhite: Boolean = false
)

object TuyaSmartHomeController {

    private const val TAG = "TuyaLauncher"
    private const val PREF_LED_IS_ON = "pref_tuya_led_is_on"
    private const val PREF_LED_HUE = "pref_tuya_led_hue"
    private const val PREF_LED_SAT = "pref_tuya_led_sat"
    private const val PREF_LED_BRIGHT = "pref_tuya_led_bright"
    private const val PREF_LED_SYNC_THEME = "pref_tuya_led_sync_theme"
    private const val PREF_LED_MODE_LABEL = "pref_tuya_led_mode_label"
    private const val PREF_LEARNED_FMT_NAME = "pref_tuya_learned_fmt_v58"
    private const val PREF_LEARNED_WITH_MODE = "pref_tuya_learned_mode_v58"
    private const val PREF_DISCOVERED_SWITCH_CODE = "pref_tuya_switch_code_v58"

    private val apiHosts = listOf(
        "https://openapi.tuyaeu.com",
        "https://openapi-weaz.tuyaeu.com"
    )

    val CURATED_SWATCHES: List<LedSwatchPreset> = listOf(
        // Ряд 1: Неон и киберпанк (выверенные углы круга Tuya Smart Life)
        LedSwatchPreset("Кибер", "#00F0FF", hue = 184, satPct = 100),
        LedSwatchPreset("Океан", "#38BDF8", hue = 200, satPct = 98),
        LedSwatchPreset("Сапфир", "#3B82F6", hue = 224, satPct = 100),
        LedSwatchPreset("Индиго", "#818CF8", hue = 248, satPct = 94),
        LedSwatchPreset("Фиолет", "#C084FC", hue = 271, satPct = 85),
        LedSwatchPreset("Фуксия", "#F472B6", hue = 324, satPct = 95),
        // Ряд 2: Уют, природа и кино
        LedSwatchPreset("Малина", "#FB7185", hue = 336, satPct = 100),
        LedSwatchPreset("Закат", "#FB923C", hue = 20, satPct = 100),
        LedSwatchPreset("Янтарь", "#FBBF24", hue = 38, satPct = 100),
        LedSwatchPreset("Лайм", "#A3E635", hue = 85, satPct = 95),
        LedSwatchPreset("Изумруд", "#34D399", hue = 145, satPct = 96),
        LedSwatchPreset("Тёплый", "#FDE68A", hue = 34, satPct = 28, isWarmWhite = true)
    )

    private enum class ColourFormat {
        V2_OBJECT,
        V2_STRING,
        V1_OBJECT,
        V1_STRING,
        HEX12_LOWER,
        HEX12_UPPER
    }

    private class DeviceCaps(
        val switchCode: String,
        val colourCode: String?,
        val sMax: Int,
        val vMax: Int,
        val hasWorkMode: Boolean
    )

    private sealed class PendingLedAction {
        data class Power(val turnOn: Boolean) : PendingLedAction()
        data class ColorHsv(val hue: Int, val satPct: Int, val brightPct: Int) : PendingLedAction()
    }

    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val tokenLock = Any()
    private val queueLock = Any()

    @Volatile
    private var cachedHost: String = "https://openapi.tuyaeu.com"

    @Volatile
    private var cachedAccessToken: String = ""

    @Volatile
    private var tokenExpiresAtWallMs: Long = 0L

    @Volatile
    private var serverTimeOffsetMs: Long = 0L

    @Volatile
    private var discoveredSwitchCode: String = "switch_led"

    @Volatile
    private var cachedDeviceCaps: DeviceCaps? = null

    @Volatile
    private var learnedFormatPair: Pair<ColourFormat, Boolean>? = null

    @Volatile
    private var prefsLoadedIntoRam: Boolean = false

    @Volatile
    private var pendingAction: PendingLedAction? = null

    @Volatile
    private var isQueueWorkerRunning: Boolean = false

    @Volatile
    private var effectCycleJob: Job? = null

    @Volatile
    private var warmupStarted: Boolean = false

    @Volatile
    private var lastUserCommandWallMs: Long = 0L

    @Volatile
    var onStateUpdatedUiCallback: (() -> Unit)? = null

    private fun notifyUi() {
        mainHandler.post {
            onStateUpdatedUiCallback?.invoke()
        }
    }

    private fun loadCachedRoutingPrefsIfNeeded(context: Context) {
        if (prefsLoadedIntoRam) return
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val savedFmtName = prefs.getString(PREF_LEARNED_FMT_NAME, "").orEmpty()
        val savedWithMode = prefs.getBoolean(PREF_LEARNED_WITH_MODE, true)
        val savedSw = prefs.getString(PREF_DISCOVERED_SWITCH_CODE, "").orEmpty()
        if (savedSw.isNotEmpty()) discoveredSwitchCode = savedSw
        if (savedFmtName.isNotEmpty()) {
            try {
                val fmt = ColourFormat.valueOf(savedFmtName)
                learnedFormatPair = fmt to savedWithMode
            } catch (_: Exception) {
            }
        }
        prefsLoadedIntoRam = true
    }

    private fun saveLearnedFormat(context: Context?, fmt: ColourFormat, withMode: Boolean) {
        learnedFormatPair = fmt to withMode
        if (context != null) {
            val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit()
                .putString(PREF_LEARNED_FMT_NAME, fmt.name)
                .putBoolean(PREF_LEARNED_WITH_MODE, withMode)
                .apply()
        }
    }

    fun ensureWarmupStarted(context: Context? = null) {
        if (context != null) {
            loadCachedRoutingPrefsIfNeeded(context)
            ScheduledTaskManager.ensureStarted(context)
        }
        if (warmupStarted) return
        warmupStarted = true
        ioScope.launch {
            try {
                ensureAccessToken(forceRefresh = false)
                loadDeviceSpecifications()
                inspectDeviceStatus(context)
            } catch (_: Exception) {
            }
            while (isActive) {
                delay(10 * 60 * 1000L)
                try {
                    val now = System.currentTimeMillis()
                    if (cachedAccessToken.isEmpty() || now > tokenExpiresAtWallMs - 300_000L) {
                        ensureAccessToken(forceRefresh = false)
                    }
                    if (cachedDeviceCaps == null) {
                        loadDeviceSpecifications()
                    }
                } catch (_: Exception) {
                }
            }
        }
    }

    /**
     * Точное чтение спецификаций ленты (один в один как в SmartTouchConsole TuyaController.kt):
     * определяет switchCode, colourCode (colour_data_v2 или colour_data), диапазоны sMax/vMax (1000 или 255) и наличие work_mode!
     */
    private suspend fun loadDeviceSpecifications(): DeviceCaps? {
        cachedDeviceCaps?.let { return it }
        val devId = LauncherConfig.TUYA_LED_DEVICE_ID
        val paths = listOf(
            "/v1.0/devices/$devId/specifications",
            "/v1.0/iot-03/devices/$devId/specification"
        )
        for (path in paths) {
            val resp = executeSignedTuyaRequest("GET", path, "") ?: continue
            if (!resp.optBoolean("success", false)) continue
            try {
                val resObj = resp.optJSONObject("result") ?: continue
                val functions = resObj.optJSONArray("functions") ?: JSONArray()
                var swCode = discoveredSwitchCode
                var colCode: String? = null
                var sMax = 1000
                var vMax = 1000
                var hasWorkMode = false
                for (i in 0 until functions.length()) {
                    val f = functions.optJSONObject(i) ?: continue
                    val code = f.optString("code", "")
                    when (code) {
                        "switch_led", "switch_led_1", "led_switch", "switch_1", "switch" -> {
                            swCode = code
                            discoveredSwitchCode = code
                        }
                        "work_mode" -> hasWorkMode = true
                        "colour_data_v2", "colour_data" -> {
                            if (colCode == null || code == "colour_data_v2") {
                                colCode = code
                                val valuesStr = f.optString("values", "{}")
                                val valuesJson = try { JSONObject(valuesStr) } catch (_: Exception) { JSONObject() }
                                val defMax = if (code == "colour_data_v2") 1000 else 255
                                sMax = valuesJson.optJSONObject("s")?.optInt("max", defMax) ?: defMax
                                vMax = valuesJson.optJSONObject("v")?.optInt("max", defMax) ?: defMax
                            }
                        }
                    }
                }
                if (colCode != null || functions.length() > 0) {
                    val caps = DeviceCaps(swCode, colCode, sMax, vMax, hasWorkMode)
                    cachedDeviceCaps = caps
                    return caps
                }
            } catch (_: Exception) {
            }
        }
        return null
    }

    fun isLedOn(context: Context): Boolean {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(PREF_LED_IS_ON, true)
    }

    fun getHue(context: Context): Int {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(PREF_LED_HUE, 184).coerceIn(0, 360)
    }

    fun getSaturationPct(context: Context): Int {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(PREF_LED_SAT, 100).coerceIn(10, 100)
    }

    fun getBrightnessPct(context: Context): Int {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getInt(PREF_LED_BRIGHT, 100).coerceIn(10, 100)
    }

    fun isThemeSyncEnabled(context: Context): Boolean {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(PREF_LED_SYNC_THEME, false)
    }

    fun getCurrentModeLabel(context: Context): String {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(PREF_LED_MODE_LABEL, "")?.takeIf { it.isNotBlank() } ?: describeHueName(getHue(context))
    }

    fun findActiveSwatchIndex(context: Context): Int {
        val mode = getCurrentModeLabel(context)
        if (mode.startsWith("Режим:")) return -1
        val byName = CURATED_SWATCHES.indexOfFirst { it.name.equals(mode, ignoreCase = true) }
        if (byName >= 0) return byName
        val h = getHue(context)
        val s = getSaturationPct(context)
        if (s <= 42 && h in 20..52) {
            return CURATED_SWATCHES.indexOfFirst { it.isWarmWhite }
        }
        var bestIdx = -1
        var bestDist = 999
        for (i in CURATED_SWATCHES.indices) {
            val p = CURATED_SWATCHES[i]
            if (p.isWarmWhite) continue
            val rawDiff = kotlin.math.abs(h - p.hue)
            val dist = kotlin.math.min(rawDiff, 360 - rawDiff)
            if (dist <= 9 && dist < bestDist) {
                bestDist = dist
                bestIdx = i
            }
        }
        return bestIdx
    }

    fun getCurrentPreviewColorInt(context: Context): Int {
        val idx = findActiveSwatchIndex(context)
        if (idx in CURATED_SWATCHES.indices) {
            return try {
                Color.parseColor(CURATED_SWATCHES[idx].hexColor)
            } catch (_: Exception) {
                Color.parseColor("#00F0FF")
            }
        }
        val h = getHue(context).toFloat()
        val s = (getSaturationPct(context) / 100f).coerceIn(0.25f, 1f)
        return Color.HSVToColor(floatArrayOf(h, s, 0.96f))
    }

    fun describeHueName(hue: Int): String {
        val h = ((hue % 360) + 360) % 360
        return when (h) {
            in 0..12 -> "Алый"
            in 13..28 -> "Закат"
            in 29..48 -> "Янтарь"
            in 49..68 -> "Золото"
            in 69..105 -> "Лайм"
            in 106..158 -> "Изумруд"
            in 159..174 -> "Мята"
            in 175..194 -> "Кибер"
            in 195..214 -> "Океан"
            in 215..236 -> "Сапфир"
            in 237..264 -> "Индиго"
            in 265..298 -> "Фиолет"
            in 299..338 -> "Фуксия"
            else -> "Малина"
        }
    }

    private fun saveState(
        context: Context,
        isOn: Boolean? = null,
        hue: Int? = null,
        satPct: Int? = null,
        brightPct: Int? = null,
        syncTheme: Boolean? = null,
        modeLabel: String? = null
    ) {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val ed = prefs.edit()
        if (isOn != null) ed.putBoolean(PREF_LED_IS_ON, isOn)
        if (hue != null) ed.putInt(PREF_LED_HUE, ((hue % 360) + 360) % 360)
        if (satPct != null) ed.putInt(PREF_LED_SAT, satPct.coerceIn(10, 100))
        if (brightPct != null) ed.putInt(PREF_LED_BRIGHT, brightPct.coerceIn(10, 100))
        if (syncTheme != null) ed.putBoolean(PREF_LED_SYNC_THEME, syncTheme)
        if (modeLabel != null) ed.putString(PREF_LED_MODE_LABEL, modeLabel)
        ed.apply()
        notifyUi()
    }

    private fun enqueueLatestAction(context: Context, action: PendingLedAction) {
        val appCtx = context.applicationContext
        loadCachedRoutingPrefsIfNeeded(appCtx)
        lastUserCommandWallMs = System.currentTimeMillis()
        var shouldLaunchWorker = false
        synchronized(queueLock) {
            pendingAction = action
            if (!isQueueWorkerRunning) {
                isQueueWorkerRunning = true
                shouldLaunchWorker = true
            }
        }
        if (shouldLaunchWorker) {
            ioScope.launch {
                try {
                    while (true) {
                        val next = synchronized(queueLock) {
                            val a = pendingAction
                            pendingAction = null
                            if (a == null) {
                                isQueueWorkerRunning = false
                            }
                            a
                        } ?: break

                        when (next) {
                            is PendingLedAction.Power -> {
                                sendSwitchCommand(appCtx, next.turnOn)
                            }
                            is PendingLedAction.ColorHsv -> {
                                sendHsvColorCommand(appCtx, next.hue, next.satPct, next.brightPct)
                            }
                        }
                    }
                } finally {
                    synchronized(queueLock) {
                        isQueueWorkerRunning = false
                    }
                }
            }
        }
    }

    fun setThemeSyncEnabled(context: Context, enabled: Boolean, currentThemeHex: String? = null) {
        saveState(context, syncTheme = enabled)
        if (enabled && !currentThemeHex.isNullOrBlank()) {
            setHexColor(context, currentThemeHex, modeTitle = "Синхр. с темой")
        }
    }

    fun syncWithLauncherThemeIfNeeded(context: Context, hexColor: String) {
        if (isThemeSyncEnabled(context)) {
            setHexColor(context, hexColor, modeTitle = "Синхр. с темой")
        }
    }

    fun togglePower(context: Context): Boolean {
        val target = !isLedOn(context)
        setPower(context, target)
        return target
    }

    fun setPower(context: Context, turnOn: Boolean) {
        val appCtx = context.applicationContext
        effectCycleJob?.cancel()
        effectCycleJob = null
        saveState(appCtx, isOn = turnOn)
        enqueueLatestAction(appCtx, PendingLedAction.Power(turnOn))
    }

    fun stepHueByDelta(context: Context, deltaDeg: Int, immediate: Boolean = false) {
        val appCtx = context.applicationContext
        effectCycleJob?.cancel()
        effectCycleJob = null
        val nextHue = (((getHue(appCtx) + deltaDeg) % 360) + 360) % 360
        val sat = getSaturationPct(appCtx).coerceAtLeast(85)
        val bright = getBrightnessPct(appCtx)
        saveState(appCtx, isOn = true, hue = nextHue, satPct = sat, modeLabel = describeHueName(nextHue))
        enqueueLatestAction(appCtx, PendingLedAction.ColorHsv(nextHue, sat, bright))
    }

    fun stepBrightnessByDelta(context: Context, deltaPct: Int) {
        val appCtx = context.applicationContext
        val nextBright = (getBrightnessPct(appCtx) + deltaPct).coerceIn(10, 100)
        val hue = getHue(appCtx)
        val sat = getSaturationPct(appCtx)
        saveState(appCtx, isOn = true, brightPct = nextBright)
        enqueueLatestAction(appCtx, PendingLedAction.ColorHsv(hue, sat, nextBright))
    }

    fun cycleBrightnessPreset(context: Context): Int {
        val cur = getBrightnessPct(context)
        val next = when {
            cur < 25 -> 25
            cur < 50 -> 50
            cur < 75 -> 75
            cur < 100 -> 100
            else -> 25
        }
        setBrightnessPercent(context, next)
        return next
    }

    fun setBrightnessPercent(context: Context, pct: Int) {
        val appCtx = context.applicationContext
        val cleanPct = pct.coerceIn(5, 100)
        val hue = getHue(appCtx)
        val sat = getSaturationPct(appCtx)
        saveState(appCtx, isOn = true, brightPct = cleanPct)
        enqueueLatestAction(appCtx, PendingLedAction.ColorHsv(hue, sat, cleanPct))
    }

    fun stepSaturationByDelta(context: Context, deltaPct: Int) {
        val appCtx = context.applicationContext
        effectCycleJob?.cancel()
        effectCycleJob = null
        val nextSat = (getSaturationPct(appCtx) + deltaPct).coerceIn(15, 100)
        val hue = getHue(appCtx)
        val bright = getBrightnessPct(appCtx)
        saveState(appCtx, isOn = true, satPct = nextSat)
        enqueueLatestAction(appCtx, PendingLedAction.ColorHsv(hue, nextSat, bright))
    }

    fun cycleSaturationPreset(context: Context): Int {
        val cur = getSaturationPct(context)
        val next = when {
            cur < 45 -> 60
            cur < 80 -> 100
            else -> 30
        }
        val appCtx = context.applicationContext
        val hue = getHue(appCtx)
        val bright = getBrightnessPct(appCtx)
        saveState(appCtx, isOn = true, satPct = next)
        enqueueLatestAction(appCtx, PendingLedAction.ColorHsv(hue, next, bright))
        return next
    }

    fun applySwatchPreset(context: Context, preset: LedSwatchPreset) {
        val appCtx = context.applicationContext
        effectCycleJob?.cancel()
        effectCycleJob = null
        val bright = getBrightnessPct(appCtx).coerceAtLeast(25)
        saveState(
            appCtx,
            isOn = true,
            hue = preset.hue,
            satPct = preset.satPct,
            brightPct = bright,
            modeLabel = preset.name
        )
        enqueueLatestAction(appCtx, PendingLedAction.ColorHsv(preset.hue, preset.satPct, bright))
    }

    fun setHexColor(context: Context, rawHex: String, modeTitle: String? = null) {
        val appCtx = context.applicationContext
        effectCycleJob?.cancel()
        effectCycleJob = null
        val cleanHex = if (rawHex.trim().startsWith("#")) rawHex.trim() else "#${rawHex.trim()}"
        val parsedColor = try {
            Color.parseColor(cleanHex)
        } catch (_: Exception) {
            Color.parseColor("#00F0FF")
        }
        val hsv = FloatArray(3)
        Color.colorToHSV(parsedColor, hsv)
        val h = hsv[0].toInt().coerceIn(0, 360)
        val s = (hsv[1] * 100f).toInt().coerceIn(15, 100)
        val b = getBrightnessPct(appCtx).coerceAtLeast(30)
        val label = modeTitle ?: describeHueName(h)
        saveState(appCtx, isOn = true, hue = h, satPct = s, brightPct = b, modeLabel = label)
        enqueueLatestAction(appCtx, PendingLedAction.ColorHsv(h, s, b))
    }

    fun activateDynamicScene(context: Context, sceneCode: String) {
        val appCtx = context.applicationContext
        loadCachedRoutingPrefsIfNeeded(appCtx)
        lastUserCommandWallMs = System.currentTimeMillis()
        effectCycleJob?.cancel()
        effectCycleJob = null

        val upper = sceneCode.trim().uppercase(Locale.US)
        when {
            upper.contains("AMBI") || upper.contains("АМБИ") || upper.contains("МУЗЫК") || upper.contains("MUSIC") || upper.contains("SPOTIFY") -> {
                saveState(appCtx, isOn = true, modeLabel = "Режим: Амбилайн")
                startSoftwareSceneLoop(appCtx, "AMBILINE")
            }
            upper.contains("NIGHT") || upper.contains("НОЧ") -> {
                saveState(appCtx, isOn = true, hue = 30, satPct = 85, brightPct = 15, modeLabel = "Режим: Ночник")
                enqueueLatestAction(appCtx, PendingLedAction.ColorHsv(30, 85, 15))
            }
            upper.contains("BREATH") || upper.contains("ДЫХ") -> {
                saveState(appCtx, isOn = true, modeLabel = "Режим: Дыхание")
                startSoftwareSceneLoop(appCtx, "BREATHE")
            }
            upper.contains("PARTY") || upper.contains("ВЕЧЕР") -> {
                saveState(appCtx, isOn = true, modeLabel = "Режим: Вечеринка")
                startSoftwareSceneLoop(appCtx, "PARTY")
            }
            else -> {
                saveState(appCtx, isOn = true, modeLabel = "Режим: Радуга")
                startSoftwareSceneLoop(appCtx, "RAINBOW")
            }
        }
    }

    private fun extractDominantCoverHsv(bmp: android.graphics.Bitmap?): Pair<Int, Int>? {
        NativeCore.extractDominantCoverHsv(bmp)?.let { return it }
        if (bmp == null || bmp.isRecycled || bmp.width <= 0 || bmp.height <= 0) return null
        try {
            val bucketWeights = FloatArray(36)
            val bucketHueSum = FloatArray(36)
            val bucketSatSum = FloatArray(36)
            val hsv = FloatArray(3)
            val w = bmp.width
            val h = bmp.height
            val stepX = (w / 20).coerceAtLeast(1)
            val stepY = (h / 20).coerceAtLeast(1)
            var y = stepY / 2
            while (y < h) {
                var x = stepX / 2
                while (x < w) {
                    val px = bmp.getPixel(x, y)
                    val a = Color.alpha(px)
                    if (a > 140) {
                        Color.colorToHSV(px, hsv)
                        val deg = hsv[0]
                        val sat = hsv[1]
                        val bri = hsv[2]
                        if (bri > 0.18f && sat > 0.24f) {
                            val bucket = ((deg.toInt() % 360) / 10).coerceIn(0, 35)
                            val skinPenalty = if (deg in 14f..44f && sat < 0.68f) 0.22f else 1.0f
                            val weight = (sat * sat * sat * bri) * skinPenalty
                            bucketWeights[bucket] += weight
                            bucketHueSum[bucket] += deg * weight
                            bucketSatSum[bucket] += sat * weight
                        }
                    }
                    x += stepX
                }
                y += stepY
            }
            var bestBucket = -1
            var bestWeight = 0f
            for (i in 0 until 36) {
                if (bucketWeights[i] > bestWeight) {
                    bestWeight = bucketWeights[i]
                    bestBucket = i
                }
            }
            if (bestBucket >= 0 && bestWeight > 0.02f) {
                val rawHue = (bucketHueSum[bestBucket] / bestWeight).toInt().coerceIn(0, 360)
                val avgSat = (bucketSatSum[bestBucket] / bestWeight).coerceIn(0.75f, 1.0f)
                return rawHue to (avgSat * 100f).toInt().coerceIn(80, 100)
            }
            return 195 to 60
        } catch (_: Exception) {
            return null
        }
    }

    private fun startSoftwareSceneLoop(context: Context, mode: String) {
        effectCycleJob?.cancel()
        effectCycleJob = ioScope.launch {
            var step = 0
            var lastAmbilineSig = 0
            var lastAmbilineHue = -1
            while (isActive && isLedOn(context)) {
                when (mode) {
                    "AMBILINE" -> {
                        try {
                            com.mitv.customlauncher.service.MediaStateBus.pollActiveControllerLight(context)
                        } catch (_: Exception) {
                        }
                        val snap = com.mitv.customlauncher.service.MediaStateBus.state.value
                        val bmp = snap.coverBitmap
                        val sig = if (bmp != null && !bmp.isRecycled) bmp.generationId else 0
                        if (bmp != null && sig != 0 && sig != lastAmbilineSig) {
                            val extracted = extractDominantCoverHsv(bmp)
                            if (extracted != null) {
                                lastAmbilineSig = sig
                                val (targetHue, targetSat) = extracted
                                val curBright = getBrightnessPct(context).coerceAtLeast(45)
                                if (kotlin.math.abs(targetHue - lastAmbilineHue) >= 5 || lastAmbilineHue == -1) {
                                    lastAmbilineHue = targetHue
                                    saveState(
                                        context,
                                        isOn = true,
                                        hue = targetHue,
                                        satPct = targetSat,
                                        brightPct = curBright,
                                        modeLabel = "Режим: Амбилайн"
                                    )
                                    enqueueLatestAction(context, PendingLedAction.ColorHsv(targetHue, targetSat, curBright))
                                }
                            }
                        } else if (step == 0 && lastAmbilineHue == -1) {
                            val curH = getHue(context)
                            val curS = getSaturationPct(context).coerceAtLeast(80)
                            val curB = getBrightnessPct(context).coerceAtLeast(45)
                            lastAmbilineHue = curH
                            enqueueLatestAction(context, PendingLedAction.ColorHsv(curH, curS, curB))
                        }
                        delay(1100L)
                    }
                    "BREATHE" -> {
                        val h = getHue(context)
                        val b = if (step % 2 == 0) 95 else 22
                        enqueueLatestAction(context, PendingLedAction.ColorHsv(h, 95, b))
                        delay(2400L)
                    }
                    "PARTY" -> {
                        val partyHues = intArrayOf(184, 324, 271, 145, 20, 224)
                        val h = partyHues[step % partyHues.size]
                        enqueueLatestAction(context, PendingLedAction.ColorHsv(h, 100, 100))
                        delay(1400L)
                    }
                    else -> {
                        val h = (step * 36) % 360
                        enqueueLatestAction(context, PendingLedAction.ColorHsv(h, 100, 95))
                        delay(2000L)
                    }
                }
                step++
            }
        }
    }

    fun refreshStatusFromCloudAsync(context: Context) {
        val appCtx = context.applicationContext
        loadCachedRoutingPrefsIfNeeded(appCtx)
        ensureWarmupStarted(appCtx)
        ioScope.launch {
            inspectDeviceStatus(appCtx)
        }
    }

    private suspend fun inspectDeviceStatus(context: Context?) {
        val devId = LauncherConfig.TUYA_LED_DEVICE_ID
        val resp = executeSignedTuyaRequest("GET", "/v1.0/iot-03/devices/$devId/status", "") ?: return
        if (!resp.optBoolean("success", false)) return
        val arr = resp.optJSONArray("result") ?: return
        var foundSwitch: Boolean? = null
        for (i in 0 until arr.length()) {
            val item = arr.optJSONObject(i) ?: continue
            val code = item.optString("code", "")
            val rawVal = item.opt("value")
            if (code == "switch_led" || code == "switch_led_1" || code == "led_switch" || code == "switch") {
                discoveredSwitchCode = code
                if (rawVal is Boolean) foundSwitch = rawVal
            }
        }
        val sinceUserClickMs = System.currentTimeMillis() - lastUserCommandWallMs
        if (context != null && foundSwitch != null && sinceUserClickMs > 8_000L) {
            saveState(context, isOn = foundSwitch)
        }
    }

    private suspend fun sendSwitchCommand(context: Context, turnOn: Boolean): Boolean {
        val caps = loadDeviceSpecifications()
        val swCode = caps?.switchCode ?: discoveredSwitchCode
        val commands = JSONArray().put(JSONObject().put("code", swCode).put("value", turnOn))
        if (postDeviceCommands(commands)) {
            if (discoveredSwitchCode != swCode) {
                discoveredSwitchCode = swCode
                context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
                    .edit().putString(PREF_DISCOVERED_SWITCH_CODE, swCode).apply()
            }
            return true
        }
        for (altCode in listOf("switch_led", "switch_led_1", "switch", "led_switch")) {
            if (altCode == swCode) continue
            val altCmds = JSONArray().put(JSONObject().put("code", altCode).put("value", turnOn))
            if (postDeviceCommands(altCmds)) {
                discoveredSwitchCode = altCode
                return true
            }
        }
        return false
    }

    private fun buildColourPayload(
        switchCode: String,
        format: ColourFormat,
        h: Int,
        s: Int,
        v: Int,
        withMode: Boolean
    ): JSONArray {
        val arr = JSONArray()
        arr.put(JSONObject().put("code", switchCode).put("value", true))
        if (withMode) {
            arr.put(JSONObject().put("code", "work_mode").put("value", "colour"))
        }
        val hsv = JSONObject().put("h", h).put("s", s).put("v", v)
        when (format) {
            ColourFormat.V2_OBJECT -> arr.put(JSONObject().put("code", "colour_data_v2").put("value", hsv))
            ColourFormat.V2_STRING -> arr.put(JSONObject().put("code", "colour_data_v2").put("value", hsv.toString()))
            ColourFormat.V1_OBJECT -> arr.put(JSONObject().put("code", "colour_data").put("value", hsv))
            ColourFormat.V1_STRING -> arr.put(JSONObject().put("code", "colour_data").put("value", hsv.toString()))
            ColourFormat.HEX12_LOWER -> arr.put(
                JSONObject().put("code", "colour_data").put("value", String.format(Locale.US, "%04x%04x%04x", h, s, v))
            )
            ColourFormat.HEX12_UPPER -> arr.put(
                JSONObject().put("code", "colour_data").put("value", String.format(Locale.US, "%04X%04X%04X", h, s, v))
            )
        }
        return arr
    }

    private fun buildGuessPayload(
        switchCode: String,
        format: ColourFormat,
        h: Int,
        sPromille: Int,
        vPromille: Int,
        withMode: Boolean
    ): JSONArray {
        val isV1 = format == ColourFormat.V1_OBJECT || format == ColourFormat.V1_STRING
        val s = if (isV1) (sPromille * 255 / 1000).coerceAtLeast(1) else sPromille
        val v = if (isV1) (vPromille * 255 / 1000).coerceAtLeast(1) else vPromille
        return buildColourPayload(switchCode, format, h, s, v, withMode)
    }

    /**
     * Отправка цвета один в один по проверенному алгоритму из SmartTouchConsole TuyaController.kt:
     * 1. Если спецификация прочитана (/v1.0/devices/$id/specifications) — масштабируем s/v к sMax/vMax и шлём V2_OBJECT / V1_OBJECT (с фоллбэком на V2_STRING / V1_STRING).
     * 2. Иначе используем сохранённый learnedFormatPair или перебираем V2_OBJECT, V2_STRING, V1_OBJECT, V1_STRING, HEX12 (сохраняя первый сработавший формат навсегда).
     */
    private suspend fun sendHsvColorCommand(context: Context, hue: Int, satPct: Int, brightPct: Int): Boolean {
        val h = ((hue % 360) + 360) % 360
        val sPromille = (satPct * 10).coerceIn(10, 1000)
        val vPromille = (brightPct * 10).coerceIn(10, 1000)

        val caps = loadDeviceSpecifications()
        if (caps != null && caps.colourCode != null) {
            val isV2 = caps.colourCode == "colour_data_v2"
            val objFormat = if (isV2) ColourFormat.V2_OBJECT else ColourFormat.V1_OBJECT
            val strFormat = if (isV2) ColourFormat.V2_STRING else ColourFormat.V1_STRING
            val sDev = (sPromille * caps.sMax / 1000).coerceAtLeast(1)
            val vDev = (vPromille * caps.vMax / 1000).coerceAtLeast(1)

            // Сначала проверяем уже выученный вариант (если есть)
            learnedFormatPair?.let { (fmt, modeFlag) ->
                val learnedScaleS = if (fmt == ColourFormat.V1_OBJECT || fmt == ColourFormat.V1_STRING) (sPromille * 255 / 1000).coerceAtLeast(1) else sPromille
                val learnedScaleV = if (fmt == ColourFormat.V1_OBJECT || fmt == ColourFormat.V1_STRING) (vPromille * 255 / 1000).coerceAtLeast(1) else vPromille
                if (postDeviceCommands(buildColourPayload(caps.switchCode, fmt, h, learnedScaleS, learnedScaleV, modeFlag))) {
                    return true
                }
            }

            if (postDeviceCommands(buildColourPayload(caps.switchCode, objFormat, h, sDev, vDev, caps.hasWorkMode))) {
                saveLearnedFormat(context, objFormat, caps.hasWorkMode)
                return true
            }
            if (postDeviceCommands(buildColourPayload(caps.switchCode, strFormat, h, sDev, vDev, caps.hasWorkMode))) {
                saveLearnedFormat(context, strFormat, caps.hasWorkMode)
                return true
            }
            if (postDeviceCommands(buildColourPayload(caps.switchCode, objFormat, h, sDev, vDev, !caps.hasWorkMode))) {
                saveLearnedFormat(context, objFormat, !caps.hasWorkMode)
                return true
            }
            if (postDeviceCommands(buildColourPayload(caps.switchCode, strFormat, h, sDev, vDev, !caps.hasWorkMode))) {
                saveLearnedFormat(context, strFormat, !caps.hasWorkMode)
                return true
            }
        }

        val sw = caps?.switchCode ?: discoveredSwitchCode
        learnedFormatPair?.let { (fmt, withMode) ->
            if (postDeviceCommands(buildGuessPayload(sw, fmt, h, sPromille, vPromille, withMode))) {
                return true
            }
            learnedFormatPair = null
        }

        for (fmt in ColourFormat.values()) {
            for (withMode in listOf(true, false)) {
                if (postDeviceCommands(buildGuessPayload(sw, fmt, h, sPromille, vPromille, withMode))) {
                    saveLearnedFormat(context, fmt, withMode)
                    return true
                }
            }
        }
        return false
    }

    private suspend fun postDeviceCommands(commandsArray: JSONArray): Boolean {
        val devId = LauncherConfig.TUYA_LED_DEVICE_ID
        val body = JSONObject().put("commands", commandsArray).toString()
        val res = executeSignedTuyaRequest("POST", "/v1.0/iot-03/devices/$devId/commands", body)
        if (res != null && res.optBoolean("success", false)) {
            return true
        }
        val fallbackRes = executeSignedTuyaRequest("POST", "/v1.0/devices/$devId/commands", body)
        return fallbackRes != null && fallbackRes.optBoolean("success", false)
    }

    private suspend fun ensureAccessToken(forceRefresh: Boolean = false): String = withContext(Dispatchers.IO) {
        synchronized(tokenLock) {
            val nowWall = System.currentTimeMillis()
            if (!forceRefresh && cachedAccessToken.isNotEmpty() && nowWall < tokenExpiresAtWallMs) {
                return@withContext cachedAccessToken
            }

            val orderedHosts = mutableListOf<String>()
            orderedHosts.add(cachedHost)
            for (h in apiHosts) {
                if (h != cachedHost) orderedHosts.add(h)
            }

            val secret = LauncherConfig.TUYA_CLIENT_SECRET

            for (host in orderedHosts) {
                var tokenJson = executeRawSignedCall(
                    host = host,
                    method = "GET",
                    pathWithQuery = "/v1.0/token?grant_type=1",
                    body = "",
                    accessToken = "",
                    secretOverride = secret
                ) ?: continue

                val serverT = tokenJson.optLong("t", 0L)
                if (serverT > 1_600_000_000_000L) {
                    serverTimeOffsetMs = serverT - System.currentTimeMillis()
                }

                if (!tokenJson.optBoolean("success", false)) {
                    val retryJson = executeRawSignedCall(
                        host = host,
                        method = "GET",
                        pathWithQuery = "/v1.0/token?grant_type=1",
                        body = "",
                        accessToken = "",
                        secretOverride = secret
                    )
                    if (retryJson != null) {
                        tokenJson = retryJson
                    }
                }

                if (tokenJson.optBoolean("success", false)) {
                    val resObj = tokenJson.optJSONObject("result")
                    val tok = resObj?.optString("access_token", "").orEmpty()
                    val expSec = resObj?.optLong("expire_time", 7200L) ?: 7200L
                    if (tok.isNotEmpty()) {
                        cachedHost = host
                        cachedAccessToken = tok
                        val safeTtlMs = ((expSec - 120L).coerceIn(300L, 7000L)) * 1000L
                        tokenExpiresAtWallMs = System.currentTimeMillis() + safeTtlMs
                        return@withContext tok
                    }
                }
            }
            cachedAccessToken
        }
    }

    private suspend fun executeSignedTuyaRequest(
        method: String,
        pathWithQuery: String,
        body: String
    ): JSONObject? = withContext(Dispatchers.IO) {
        var token = ensureAccessToken(forceRefresh = false)
        if (token.isEmpty()) return@withContext null

        val secret = LauncherConfig.TUYA_CLIENT_SECRET
        var res = executeRawSignedCall(cachedHost, method, pathWithQuery, body, token, secret)

        if (res == null) {
            res = executeRawSignedCall(cachedHost, method, pathWithQuery, body, token, secret)
        } else if (!res.optBoolean("success", false)) {
            val serverT = res.optLong("t", 0L)
            if (serverT > 1_600_000_000_000L) {
                serverTimeOffsetMs = serverT - System.currentTimeMillis()
            }
            val code = res.optInt("code", 0)
            val msg = res.optString("msg", "").lowercase(Locale.US)
            if (code == 1010 || code == 1013 || code == 1004 || msg.contains("token") || msg.contains("sign")) {
                token = ensureAccessToken(forceRefresh = true)
                if (token.isNotEmpty()) {
                    res = executeRawSignedCall(cachedHost, method, pathWithQuery, body, token, secret)
                }
            }
        }
        res
    }

    private fun executeRawSignedCall(
        host: String,
        method: String,
        pathWithQuery: String,
        body: String,
        accessToken: String,
        secretOverride: String = ""
    ): JSONObject? {
        val clientId = LauncherConfig.TUYA_CLIENT_ID
        val secret = if (secretOverride.isNotEmpty()) secretOverride else LauncherConfig.TUYA_CLIENT_SECRET
        val timestamp = (System.currentTimeMillis() + serverTimeOffsetMs).toString()

        val bodyBytes = body.toByteArray(Charsets.UTF_8)
        val contentSha256 = sha256HexLower(bodyBytes)
        val stringToSign = "$method\n$contentSha256\n\n$pathWithQuery"
        val payloadToSign = if (accessToken.isEmpty()) {
            "$clientId$timestamp$stringToSign"
        } else {
            "$clientId$accessToken$timestamp$stringToSign"
        }
        val signUpper = hmacSha256HexUpper(payloadToSign, secret)

        var conn: HttpURLConnection? = null
        return try {
            val connObj = (URL("$host$pathWithQuery").openConnection() as HttpURLConnection).apply {
                requestMethod = method
                connectTimeout = 2800
                readTimeout = 3500
                doInput = true
                useCaches = false
                setRequestProperty("Connection", "keep-alive")
                setRequestProperty("client_id", clientId)
                setRequestProperty("sign", signUpper)
                setRequestProperty("t", timestamp)
                setRequestProperty("sign_method", "HMAC-SHA256")
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                if (accessToken.isNotEmpty()) {
                    setRequestProperty("access_token", accessToken)
                }
                if (method == "POST" || method == "PUT") {
                    doOutput = true
                }
            }
            conn = connObj
            if (method == "POST" || method == "PUT") {
                connObj.outputStream.use { os ->
                    os.write(bodyBytes)
                    os.flush()
                }
            }
            val code = connObj.responseCode
            val stream = if (code in 200..299) connObj.inputStream else connObj.errorStream
            val respText = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
            if (respText.isNotBlank()) JSONObject(respText) else null
        } catch (e: Exception) {
            try {
                conn?.disconnect()
            } catch (_: Exception) {
            }
            null
        }
    }

    private fun sha256HexLower(bytes: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
        val sb = StringBuilder(digest.size * 2)
        for (b in digest) {
            sb.append(String.format(Locale.US, "%02x", b.toInt() and 0xFF))
        }
        return sb.toString()
    }

    private fun hmacSha256HexUpper(data: String, secret: String): String {
        val mac = Mac.getInstance("HmacSHA256")
        val keySpec = SecretKeySpec(secret.toByteArray(Charsets.UTF_8), "HmacSHA256")
        mac.init(keySpec)
        val raw = mac.doFinal(data.toByteArray(Charsets.UTF_8))
        val sb = StringBuilder(raw.size * 2)
        for (b in raw) {
            sb.append(String.format(Locale.US, "%02X", b.toInt() and 0xFF))
        }
        return sb.toString()
    }
}

/**
 * Долгосрочная энергонезависимая память ИИ (0 МБ фонового потребления ОЗУ):
 * хранит заметки, факты, коды и привычки пользователя в SharedPreferences и передаёт их в промпт Gemini.
 */
object AiMemoryStore {
    private const val PREF_MEMORY_JSON = "pref_ai_long_term_memory_v58"

    fun rememberFact(context: Context, rawFact: String) {
        val clean = rawFact.trim()
        if (clean.isEmpty()) return
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val arr = try {
            JSONArray(prefs.getString(PREF_MEMORY_JSON, "[]") ?: "[]")
        } catch (_: Exception) {
            JSONArray()
        }
        val list = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            val item = arr.optString(i, "").trim()
            if (item.isNotEmpty() && !item.equals(clean, ignoreCase = true)) {
                list.add(item)
            }
        }
        list.add(clean)
        while (list.size > 30) {
            list.removeAt(0)
        }
        val outArr = JSONArray()
        for (s in list) outArr.put(s)
        prefs.edit().putString(PREF_MEMORY_JSON, outArr.toString()).apply()
    }

    fun forgetFact(context: Context, keywordOrAll: String) {
        val kw = keywordOrAll.trim().lowercase(Locale.ROOT)
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        if (kw.isEmpty() || kw == "all" || kw == "все" || kw == "всё") {
            prefs.edit().putString(PREF_MEMORY_JSON, "[]").apply()
            return
        }
        val arr = try {
            JSONArray(prefs.getString(PREF_MEMORY_JSON, "[]") ?: "[]")
        } catch (_: Exception) {
            JSONArray()
        }
        val outArr = JSONArray()
        for (i in 0 until arr.length()) {
            val item = arr.optString(i, "").trim()
            if (item.isNotEmpty() && !item.lowercase(Locale.ROOT).contains(kw)) {
                outArr.put(item)
            }
        }
        prefs.edit().putString(PREF_MEMORY_JSON, outArr.toString()).apply()
    }

    fun getMemoryPromptBlock(context: Context): String {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val arr = try {
            JSONArray(prefs.getString(PREF_MEMORY_JSON, "[]") ?: "[]")
        } catch (_: Exception) {
            JSONArray()
        }
        if (arr.length() == 0) return ""
        val items = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            val s = arr.optString(i, "").trim()
            if (s.isNotEmpty()) items.add("- $s")
        }
        if (items.isEmpty()) return ""
        return "\nДОЛГОСРОЧНАЯ ПАМЯТЬ ПОЛЬЗОВАТЕЛЯ (используй эти сохранённые факты при ответах):\n" +
            items.joinToString("\n") + "\n"
    }
}

/**
 * Планировщик отложенных голосовых напоминаний и умных команд через время (0 МБ лишней ОЗУ):
 * - Работает поверх любого приложения (YouTube, Kick, фильм) и в режиме ожидания
 * - При наступлении времени напоминания выдвигает Dynamic Island, приглушает звук ТВ и озвучивает напоминание живым голосом Gemini TTS!
 * - При наступлении времени отложенной команды (например, «включи ленту через 20 минут») сам выполняет команду.
 */
object ScheduledTaskManager {
    private const val PREF_TASKS_JSON = "pref_ai_scheduled_tasks_v58"
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())
    private val lock = Any()
    @Volatile
    private var loopStarted = false

    fun ensureStarted(context: Context) {
        if (loopStarted) return
        loopStarted = true
        val appCtx = context.applicationContext
        scope.launch {
            while (isActive) {
                try {
                    checkAndFireDueTasks(appCtx)
                } catch (_: Exception) {
                }
                delay(2000L)
            }
        }
    }

    fun scheduleVoiceReminder(context: Context, delaySeconds: Long, reminderText: String) {
        val cleanText = reminderText.trim()
        if (cleanText.isEmpty()) return
        val triggerAtMs = System.currentTimeMillis() + (delaySeconds.coerceAtLeast(3L) * 1000L)
        addTask(context, type = "REMIND", triggerAtMs = triggerAtMs, payload = cleanText)
    }

    /**
     * Планирует напоминание на конкретную дату и время ("yyyy-MM-dd HH:mm" или "HH:mm") в постоянную память,
     * чтобы оно никогда не терялось при сбросе контекстного окна диалога или перезапуске!
     */
    fun scheduleVoiceReminderAt(context: Context, dateTimeSpec: String, reminderText: String) {
        val cleanText = reminderText.trim().ifEmpty { "Напоминание" }
        val rawSpec = dateTimeSpec.trim()
        val now = System.currentTimeMillis()
        var targetMs = 0L
        for (pattern in listOf("yyyy-MM-dd HH:mm", "yyyy-MM-dd H:mm", "dd.MM.yyyy HH:mm")) {
            try {
                val sdf = SimpleDateFormat(pattern, Locale.US)
                val parsed = sdf.parse(rawSpec)
                if (parsed != null && parsed.time > now) {
                    targetMs = parsed.time
                    break
                }
            } catch (_: Exception) {
            }
        }
        if (targetMs <= now) {
            // Если передано только время "HH:mm"
            val hmMatch = Regex("(\\d{1,2}):(\\d{2})").find(rawSpec)
            if (hmMatch != null) {
                val h = hmMatch.groupValues[1].toIntOrNull() ?: 10
                val m = hmMatch.groupValues[2].toIntOrNull() ?: 0
                val cal = java.util.Calendar.getInstance()
                cal.set(java.util.Calendar.HOUR_OF_DAY, h.coerceIn(0, 23))
                cal.set(java.util.Calendar.MINUTE, m.coerceIn(0, 59))
                cal.set(java.util.Calendar.SECOND, 0)
                cal.set(java.util.Calendar.MILLISECOND, 0)
                if (cal.timeInMillis <= now) {
                    cal.add(java.util.Calendar.DAY_OF_YEAR, 1)
                }
                targetMs = cal.timeInMillis
            }
        }
        if (targetMs <= now) {
            targetMs = now + 60_000L
        }
        addTask(context, type = "REMIND", triggerAtMs = targetMs, payload = cleanText)
    }

    fun getPendingRemindersSummaryForAi(context: Context): String {
        val appCtx = context.applicationContext
        synchronized(lock) {
            val prefs = appCtx.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            val raw = prefs.getString(PREF_TASKS_JSON, "[]") ?: "[]"
            if (raw == "[]") return ""
            val arr = try { JSONArray(raw) } catch (_: Exception) { return "" }
            if (arr.length() == 0) return ""
            val sdf = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
            val items = mutableListOf<String>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val t = obj.optString("type", "")
                val p = obj.optString("payload", "")
                val trig = obj.optLong("triggerAtMs", 0L)
                if (trig > System.currentTimeMillis()) {
                    items.add("$t в ${sdf.format(Date(trig))}: $p")
                }
            }
            if (items.isEmpty()) return ""
            return "\nАктивные запланированные напоминания и таймеры в памяти приставки: " + items.joinToString("; ") + "\n"
        }
    }

    fun scheduleDelayedCommand(context: Context, delaySeconds: Long, commandSpec: String) {
        val cleanSpec = commandSpec.trim()
        if (cleanSpec.isEmpty()) return
        val triggerAtMs = System.currentTimeMillis() + (delaySeconds.coerceAtLeast(3L) * 1000L)
        addTask(context, type = "CMD", triggerAtMs = triggerAtMs, payload = cleanSpec)
    }

    private fun addTask(context: Context, type: String, triggerAtMs: Long, payload: String) {
        val appCtx = context.applicationContext
        ensureStarted(appCtx)
        synchronized(lock) {
            val prefs = appCtx.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            val arr = try {
                JSONArray(prefs.getString(PREF_TASKS_JSON, "[]") ?: "[]")
            } catch (_: Exception) {
                JSONArray()
            }
            arr.put(
                JSONObject().apply {
                    put("type", type)
                    put("triggerAtMs", triggerAtMs)
                    put("payload", payload)
                }
            )
            prefs.edit().putString(PREF_TASKS_JSON, arr.toString()).apply()
        }
    }

    private fun checkAndFireDueTasks(context: Context) {
        val now = System.currentTimeMillis()
        val dueList = mutableListOf<Pair<String, String>>()
        synchronized(lock) {
            val prefs = context.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            val raw = prefs.getString(PREF_TASKS_JSON, "[]") ?: "[]"
            if (raw == "[]") return
            val arr = try { JSONArray(raw) } catch (_: Exception) { JSONArray() }
            if (arr.length() == 0) return
            val remaining = JSONArray()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val triggerAt = obj.optLong("triggerAtMs", 0L)
                val t = obj.optString("type", "")
                val p = obj.optString("payload", "")
                if (now >= triggerAt) {
                    dueList.add(t to p)
                } else {
                    remaining.put(obj)
                }
            }
            if (dueList.isNotEmpty()) {
                prefs.edit().putString(PREF_TASKS_JSON, remaining.toString()).apply()
            }
        }

        for ((type, payload) in dueList) {
            mainHandler.post {
                if (type == "REMIND") {
                    DynamicIslandBus.showAnnouncement(context, "Напоминание: $payload", speakText = "Напоминаю: $payload")
                } else if (type == "CMD") {
                    executeDelayedAction(context, payload)
                }
            }
        }
    }

    private fun executeDelayedAction(context: Context, commandSpec: String) {
        val parts = commandSpec.split(":", limit = 2)
        val act = parts[0].trim().uppercase(Locale.US)
        val arg = parts.getOrNull(1)?.trim().orEmpty()
        when (act) {
            "LED_ON" -> {
                TuyaSmartHomeController.setPower(context, true)
                DynamicIslandBus.showAnnouncement(context, "Таймер: подсветка включена", speakText = "Включаю подсветку по таймеру.")
            }
            "LED_OFF" -> {
                TuyaSmartHomeController.setPower(context, false)
                DynamicIslandBus.showAnnouncement(context, "Таймер: подсветка выключена", speakText = "Выключаю подсветку по таймеру.")
            }
            "LED_COLOR" -> if (arg.isNotEmpty()) {
                TuyaSmartHomeController.setHexColor(context, arg)
                DynamicIslandBus.showAnnouncement(context, "Таймер: цвет подсветки изменён", speakText = "Меняю цвет подсветки по таймеру.")
            }
            "SLEEP", "TV_OFF" -> {
                ShellKeyController.sendKeyEvent(223)
            }
            "WAKEUP", "TV_ON" -> {
                ShellKeyController.sendKeyEvent(224)
            }
            "PAUSE" -> LocalVoiceCommandRouter.executeSystemAudioCommand(context, "PAUSE")
            "PLAY" -> LocalVoiceCommandRouter.executeSystemAudioCommand(context, "PLAY")
            "MUTE" -> LocalVoiceCommandRouter.executeSystemAudioCommand(context, "MUTE")
            "YT" -> if (arg.isNotEmpty()) LocalVoiceCommandRouter.launchYouTubeSearch(context, arg)
            "KICK" -> if (arg.isNotEmpty()) LocalVoiceCommandRouter.launchKickStream(context, arg)
            "SPOTIFY" -> if (arg.isNotEmpty()) LocalVoiceCommandRouter.launchSpotifyTrackOrArtist(context, arg)
        }
    }
}

object AssistantVoiceSpeaker {

    private const val PREF_TTS_ENABLED = "pref_assistant_tts_enabled"
    private const val PREF_TTS_VOICE = "pref_assistant_tts_voice"
    private const val PREF_CACHED_TTS_MODEL = "pref_cached_gemini_tts_model_v62"
    private const val PREF_NO_STREAM_MODELS = "pref_no_stream_tts_models_v60"
    private const val PREF_NO_STREAM_TS = "pref_no_stream_tts_ts_v60"
    private const val PREF_NO_STREAM_VER = "pref_no_stream_tts_ver_v60"
    private const val CURRENT_APP_VERSION_CODE = 60

    private const val TTS_FIRST_SOUND_BUDGET_MS = 6_000L
    private const val MAX_KEY_ATTEMPTS = 3

    val AVAILABLE_VOICES: List<Pair<String, String>> = listOf(
        "Puck" to "Puck (Живой мужской)",
        "Aoede" to "Aoede (Мягкий женский)",
        "Kore" to "Kore (Чёткий женский)",
        "Charon" to "Charon (Глубокий мужской)",
        "Fenrir" to "Fenrir (Энергичный мужской)"
    )

    private val ttsModels = listOf(
        "gemini-3.8-flash-lite-tts",
        "gemini-3.8-flash-tts",
        "gemini-3.1-flash-tts-preview",
        "gemini-2.5-flash-preview-tts",
        "gemini-2.5-pro-preview-tts"
    )

    @Volatile
    private var lastTtsError: String = ""

    @Volatile
    private var cachedTtsModel: String? = null

    @Volatile
    private var lastRateLimitToastMs: Long = 0L

    private val speakerScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    private var speakJob: Job? = null

    @Volatile
    private var activeAudioTrack: AudioTrack? = null

    @Volatile
    private var fallbackSystemTts: TextToSpeech? = null

    @Volatile
    private var fallbackTtsReady: Boolean = false

    @Volatile
    var isSpeakingNow: Boolean = false
        private set

    @Volatile
    var currentVoiceWaveLevel: Float = 0.45f
        private set

    private var currentAudioFocusRequest: AudioFocusRequest? = null

    private val noStreamModels = java.util.concurrent.CopyOnWriteArraySet<String>()
    private val unavailableTtsModels = java.util.concurrent.CopyOnWriteArraySet<String>()

    @Volatile
    private var prefsLoaded = false

    // Предзагрузка первого предложения во время потоковой генерации текста (Этап 3)
    @Volatile
    private var prefetchedSentenceText: String? = null

    @Volatile
    private var prefetchedSentenceJob: Deferred<ByteArray?>? = null

    @Synchronized
    private fun ensureTtsCacheLoaded(context: Context) {
        if (prefsLoaded) return
        prefsLoaded = true
        try {
            val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            val savedModel = prefs.getString(PREF_CACHED_TTS_MODEL, null)
            if (!savedModel.isNullOrBlank()) {
                cachedTtsModel = savedModel
            }
            val now = System.currentTimeMillis()
            val savedVer = prefs.getInt(PREF_NO_STREAM_VER, 0)
            val savedTs = prefs.getLong(PREF_NO_STREAM_TS, 0L)
            if (savedVer != CURRENT_APP_VERSION_CODE || (now - savedTs) > 24L * 3600_000L) {
                noStreamModels.clear()
                prefs.edit()
                    .remove(PREF_NO_STREAM_MODELS)
                    .putInt(PREF_NO_STREAM_VER, CURRENT_APP_VERSION_CODE)
                    .putLong(PREF_NO_STREAM_TS, now)
                    .apply()
            } else {
                val rawSet = prefs.getString(PREF_NO_STREAM_MODELS, "") ?: ""
                for (item in rawSet.split(",")) {
                    val m = item.trim()
                    if (m.isNotEmpty()) noStreamModels.add(m)
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun saveCachedTtsModel(context: Context, model: String) {
        cachedTtsModel = model
        try {
            val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit().putString(PREF_CACHED_TTS_MODEL, model).apply()
        } catch (_: Exception) {
        }
    }

    private fun markNoStreamModel(context: Context, model: String) {
        if (noStreamModels.add(model)) {
            try {
                val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
                prefs.edit()
                    .putString(PREF_NO_STREAM_MODELS, noStreamModels.joinToString(","))
                    .putLong(PREF_NO_STREAM_TS, System.currentTimeMillis())
                    .putInt(PREF_NO_STREAM_VER, CURRENT_APP_VERSION_CODE)
                    .apply()
            } catch (_: Exception) {
            }
        }
    }

    fun isTtsEnabled(context: Context): Boolean {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(PREF_TTS_ENABLED, true)
    }

    fun setTtsEnabled(context: Context, enabled: Boolean) {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(PREF_TTS_ENABLED, enabled).apply()
        if (!enabled) {
            stop(context)
        }
    }

    fun getSelectedVoiceName(context: Context): String {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString(PREF_TTS_VOICE, "Puck") ?: "Puck"
        return if (AVAILABLE_VOICES.any { it.first.equals(saved, ignoreCase = true) }) {
            AVAILABLE_VOICES.first { it.first.equals(saved, ignoreCase = true) }.first
        } else {
            "Puck"
        }
    }

    fun getSelectedVoiceDisplayLabel(context: Context): String {
        val code = getSelectedVoiceName(context)
        return AVAILABLE_VOICES.firstOrNull { it.first == code }?.second ?: code
    }

    fun setVoiceName(context: Context, rawVoice: String): String {
        val clean = rawVoice.trim()
        val matched = AVAILABLE_VOICES.firstOrNull {
            it.first.equals(clean, ignoreCase = true) || it.second.lowercase(Locale.ROOT).contains(clean.lowercase(Locale.ROOT))
        }?.first ?: when {
            clean.lowercase(Locale.ROOT).contains("жен") || clean.lowercase(Locale.ROOT).contains("жіноч") || clean.lowercase(Locale.ROOT).contains("kore") -> "Kore"
            clean.lowercase(Locale.ROOT).contains("мягк") || clean.lowercase(Locale.ROOT).contains("aoede") -> "Aoede"
            clean.lowercase(Locale.ROOT).contains("глуб") || clean.lowercase(Locale.ROOT).contains("charon") -> "Charon"
            clean.lowercase(Locale.ROOT).contains("энерг") || clean.lowercase(Locale.ROOT).contains("fenrir") -> "Fenrir"
            else -> "Puck"
        }
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(PREF_TTS_VOICE, matched).apply()
        return matched
    }

    fun cycleNextVoice(context: Context): String {
        val current = getSelectedVoiceName(context)
        val idx = AVAILABLE_VOICES.indexOfFirst { it.first == current }
        val next = if (idx >= 0) AVAILABLE_VOICES[(idx + 1) % AVAILABLE_VOICES.size].first else AVAILABLE_VOICES.first().first
        setVoiceName(context, next)
        return getSelectedVoiceDisplayLabel(context)
    }

    fun init(context: Context) {
        ensureTtsCacheLoaded(context)
        TuyaSmartHomeController.ensureWarmupStarted(context)
    }

    fun normalizeSpeechText(rawText: String): String {
        return rawText
            .removePrefix("✦")
            .replace("🔔", "")
            .replace("⚡", "")
            .replace("✓", "")
            .replace("*", "")
            .replace("#", "")
            .replace("·", ", ")
            .replace("–", " до ")
            .trim()
    }

    /**
     * Разбивает ответ на предложения для мгновенного старта озвучки:
     * - Первый кусок: по первому законченному предложению (разделители `. ! ? …` и `\n`), не короче ~40 символов и не длиннее ~120 символов.
     * - Следующие предложения ставятся в очередь и предзагружаются параллельно, пока играет предыдущее.
     */
    /**
     * Обычные ответы до 260 символов передаются ОДНИМ цельным потоком (streamGenerateContent SSE),
     * чтобы не было стыков, щелчков и пауз между словами! Только длинные тексты делятся по предложениям.
     */
    fun splitTextIntoStreamingSentences(text: String): List<String> {
        val clean = normalizeSpeechText(text)
        if (clean.isEmpty()) return emptyList()
        // Первое законченное предложение озвучиваем отдельным куском: звук начинается раньше,
        // а остаток подгружается параллельно, пока играет первый кусок.
        val firstBreak = findSentenceBreak(clean, minLen = EARLY_MIN_LEN, maxLen = EARLY_MAX_LEN)
        if (clean.length > 90 && firstBreak in 1 until clean.length && clean.length - firstBreak >= 25) {
            val first = clean.substring(0, firstBreak).trim()
            val rest = clean.substring(firstBreak).trim()
            if (first.isNotEmpty() && rest.isNotEmpty()) {
                return listOf(first) + splitLongText(rest)
            }
        }
        return splitLongText(clean)
    }

    private const val EARLY_MIN_LEN = 30
    private const val EARLY_MAX_LEN = 160

    /**
     * Первое законченное предложение из приходящего потока текста (после него уже есть пробел/перенос),
     * либо null, если оно ещё не дописано. Совпадает с первым куском splitTextIntoStreamingSentences.
     */
    fun extractFirstSentenceForEarlyTts(text: String): String? {
        val clean = normalizeSpeechText(text)
        if (clean.length < EARLY_MIN_LEN + 5) return null
        val idx = findSentenceBreak(clean, minLen = EARLY_MIN_LEN, maxLen = EARLY_MAX_LEN)
        if (idx <= 0 || idx >= clean.length) return null
        return clean.substring(0, idx).trim().takeIf { it.isNotEmpty() }
    }

    private fun splitLongText(clean: String): List<String> {
        if (clean.isEmpty()) return emptyList()
        if (clean.length <= 260) return listOf(clean)

        val result = mutableListOf<String>()
        var remaining = clean

        while (remaining.isNotEmpty()) {
            if (remaining.length <= 240) {
                result.add(remaining)
                break
            }
            var splitIdx = findSentenceBreak(remaining, minLen = 50, maxLen = 230)
            if (splitIdx == -1) {
                val spaceIdx = remaining.lastIndexOf(' ', 220)
                splitIdx = if (spaceIdx >= 50) spaceIdx + 1 else 220
            }
            val piece = remaining.substring(0, splitIdx).trim()
            if (piece.isNotEmpty()) {
                result.add(piece)
            }
            remaining = remaining.substring(splitIdx).trim()
        }

        return if (result.isEmpty()) listOf(clean) else result
    }

    private fun findSentenceBreak(s: String, minLen: Int, maxLen: Int): Int {
        val limit = minOf(s.length, maxLen)
        if (limit < minLen) return -1
        for (i in minLen - 1 until limit) {
            val ch = s[i]
            if (ch == '\n') {
                return i + 1
            }
            if (ch == '.' || ch == '!' || ch == '?' || ch == '…') {
                if (i + 1 >= s.length || s[i + 1].isWhitespace()) {
                    return i + 1
                }
            }
        }
        return -1
    }

    /**
     * Запускает фоновую предзагрузку первого предложения ещё во время прихода потокового текста (Этап 3).
     */
    @Synchronized
    fun startFirstSentencePrefetchIfReady(context: Context, firstSentence: String) {
        val appCtx = context.applicationContext
        if (!isTtsEnabled(appCtx)) return
        val normalized = normalizeSpeechText(firstSentence)
        if (normalized.length < 20) return
        if (prefetchedSentenceText == normalized && prefetchedSentenceJob?.isActive == true) return

        prefetchedSentenceJob?.cancel()
        prefetchedSentenceText = normalized
        val voiceName = getSelectedVoiceName(appCtx)
        prefetchedSentenceJob = speakerScope.async {
            val startMs = SystemClock.elapsedRealtime()
            fetchGeminiTtsPcmWithRetry(appCtx, normalized, voiceName, startMs)
        }
    }

    @Synchronized
    private fun consumeMatchingPrefetch(chunkText: String): Deferred<ByteArray?>? {
        val normalized = normalizeSpeechText(chunkText)
        val job = prefetchedSentenceJob
        return if (job != null && prefetchedSentenceText == normalized) {
            prefetchedSentenceJob = null
            prefetchedSentenceText = null
            job
        } else {
            prefetchedSentenceJob?.cancel()
            prefetchedSentenceJob = null
            prefetchedSentenceText = null
            null
        }
    }

    private fun maybeShowRateLimitToast(context: Context) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastRateLimitToastMs >= 60_000L) {
            lastRateLimitToastMs = now
            mainHandler.post {
                try {
                    Toast.makeText(context, "Лимит Gemini TTS, говорю встроенным голосом", Toast.LENGTH_SHORT).show()
                } catch (_: Exception) {
                }
            }
        }
    }

    /**
     * Надёжная озвучка с пулом ключей Gemini TTS, предзагрузкой следующих предложений и резервным встроенным голосом ТВ:
     * 1. Если сообщение — уведомление об исчерпании текстовых лимитов или пул TTS пуст — сразу озвучивает встроенным голосом ТВ без тишины.
     * 2. Иначе озвучивает первым предложением (через предзагрузку или SSE-поток) и параллельно качает следующее предложение в фоне.
     */
    fun speak(context: Context, rawText: String, onFinished: ((Boolean) -> Unit)? = null) {
        val appCtx = context.applicationContext
        ensureTtsCacheLoaded(appCtx)
        stop(appCtx, preservePrefetch = true)

        if (!isTtsEnabled(appCtx)) {
            consumeMatchingPrefetch("")
            onFinished?.let { mainHandler.post { it.invoke(false) } }
            return
        }

        val cleanText = normalizeSpeechText(rawText)
        if (cleanText.isEmpty()) {
            consumeMatchingPrefetch("")
            onFinished?.let { mainHandler.post { it.invoke(false) } }
            return
        }

        val voiceName = getSelectedVoiceName(appCtx)
        val textChunks = splitTextIntoStreamingSentences(cleanText)
        val matchedFirstPrefetch = if (textChunks.isNotEmpty()) consumeMatchingPrefetch(textChunks[0]) else null

        isSpeakingNow = true
        currentVoiceWaveLevel = 0.52f
        firstAudioLoggedThisSpeak = false
        GeminiCloudClient.logTiming("tts_speak_called")

        speakJob = speakerScope.launch {
            val selfJob = coroutineContext[Job]
            var playedSuccessfully = false
            var track: AudioTrack? = null
            var totalFramesWritten = 0L
            var isFirstSpeechChunk = true
            var nextChunkPrefetch: Deferred<ByteArray?>? = null
            val turnStartElapsedMs = SystemClock.elapsedRealtime()

            try {
                // Если это системное сообщение о лимите всех текстовых ключей (п. 3.2), не отправляем его в Gemini TTS
                val isTextQuotaMessage = cleanText.startsWith("Лимиты Gemini исчерпаны")
                if (!isTextQuotaMessage) {
                    for (idx in textChunks.indices) {
                        if (!isActive || !isSpeakingNow) break
                        val chunkText = textChunks[idx]

                        // Пока будет играть текущий кусок idx, параллельно запускаем предзагрузку куска idx + 1
                        val currentPrefetch = if (idx == 0) matchedFirstPrefetch else nextChunkPrefetch
                        nextChunkPrefetch = if (idx + 1 < textChunks.size) {
                            val nextText = textChunks[idx + 1]
                            async(Dispatchers.IO) {
                                fetchGeminiTtsPcmWithRetry(appCtx, nextText, voiceName, SystemClock.elapsedRealtime())
                            }
                        } else {
                            null
                        }

                        var chunkPlayed = false
                        if (currentPrefetch != null) {
                            val prePcm = try {
                                currentPrefetch.await()
                            } catch (_: Exception) {
                                null
                            }
                            if (prePcm != null && prePcm.size > 400 && isActive && isSpeakingNow) {
                                if (track == null) {
                                    val opened = openStreamingAudioTrack24kHz(appCtx)
                                    track = opened?.first
                                    totalFramesWritten += opened?.second ?: 0L
                                    activeAudioTrack = track
                                }
                                val activeAt = track
                                if (activeAt != null) {
                                    val preparedPcm = if (isFirstSpeechChunk) {
                                        isFirstSpeechChunk = false
                                        applyLeadingFadeIn16BitMono(prePcm)
                                    } else {
                                        prePcm
                                    }
                                    val frames = writePcmChunkWithVisualizer(activeAt, preparedPcm)
                                    if (frames > 0L) {
                                        totalFramesWritten += frames
                                        playedSuccessfully = true
                                        chunkPlayed = true
                                    }
                                }
                            }
                        }

                        if (chunkPlayed) continue
                        if (!isActive || !isSpeakingNow) break

                        // Потоковая озвучка: звук начинает играть, как только пришли первые данные
                        val budgetStart = if (playedSuccessfully) SystemClock.elapsedRealtime() else turnStartElapsedMs
                        val streamed = streamGeminiTts(appCtx, chunkText, voiceName, budgetStart) { pcm ->
                            if (!isActive || !isSpeakingNow) {
                                false
                            } else {
                                if (track == null) {
                                    val opened = openStreamingAudioTrack24kHz(appCtx)
                                    track = opened?.first
                                    totalFramesWritten += opened?.second ?: 0L
                                    activeAudioTrack = track
                                }
                                val at = track
                                if (at != null) {
                                    val preparedPcm = if (isFirstSpeechChunk) {
                                        isFirstSpeechChunk = false
                                        applyLeadingFadeIn16BitMono(pcm)
                                    } else {
                                        pcm
                                    }
                                    val frames = writePcmChunkWithVisualizer(at, preparedPcm)
                                    if (frames > 0L) {
                                        totalFramesWritten += frames
                                        playedSuccessfully = true
                                        true
                                    } else {
                                        false
                                    }
                                } else {
                                    false
                                }
                            }
                        }
                        if (streamed) continue
                        if (!isActive || !isSpeakingNow) break

                        val pcmData = fetchGeminiTtsPcmWithRetry(appCtx, chunkText, voiceName, budgetStart)
                        if (pcmData != null && pcmData.size > 400 && isActive && isSpeakingNow) {
                            if (track == null) {
                                val opened = openStreamingAudioTrack24kHz(appCtx)
                                track = opened?.first
                                totalFramesWritten += opened?.second ?: 0L
                                activeAudioTrack = track
                            }
                            val activeAt = track
                            if (activeAt != null) {
                                val preparedPcm = if (isFirstSpeechChunk) {
                                    isFirstSpeechChunk = false
                                    applyLeadingFadeIn16BitMono(pcmData)
                                } else {
                                    pcmData
                                }
                                val frames = writePcmChunkWithVisualizer(activeAt, preparedPcm)
                                if (frames > 0L) {
                                    totalFramesWritten += frames
                                    playedSuccessfully = true
                                }
                            }
                        } else if (!playedSuccessfully) {
                            // Если первый же кусок не удалось озвучить в пределах бюджета — сразу переходим на встроенный голос
                            break
                        }
                    }
                }

                // Дожидаемся, пока буфер AudioTrack полностью доиграет хвост фразы перед stop()/release()
                val finalTrack = track
                if (playedSuccessfully && finalTrack != null && isActive && isSpeakingNow) {
                    awaitAudioTrackDrain(finalTrack, totalFramesWritten)
                }

                // Если живой облачный Gemini TTS не ответил или исчерпаны лимиты — сразу подстраховываем системным голосом ТВ
                if (!playedSuccessfully && isActive && isSpeakingNow && !isTextQuotaMessage) {
                    val safeErr = GeminiKeyPool.sanitize(lastTtsError)
                    val isRateLimited = safeErr.contains("429") ||
                        safeErr.contains("RESOURCE_EXHAUSTED") ||
                        GeminiKeyPool.nextAvailableInMs(appCtx, GeminiKeyPool.Kind.TTS)?.let { it > 0L } == true
                    if (isRateLimited) {
                        maybeShowRateLimitToast(appCtx)
                    } else if (safeErr.isNotEmpty()) {
                        mainHandler.post {
                            try {
                                Toast.makeText(appCtx, "Gemini TTS: " + safeErr, Toast.LENGTH_LONG).show()
                            } catch (_: Exception) {
                            }
                        }
                    }
                    playedSuccessfully = speakWithAndroidFallbackBlocking(appCtx, cleanText)
                }
            } catch (_: Exception) {
            } finally {
                nextChunkPrefetch?.cancel()
                try {
                    track?.stop()
                } catch (_: Exception) {
                }
                try {
                    track?.release()
                } catch (_: Exception) {
                }
                // Старая (отменённая) задача не должна сбрасывать состояние новой озвучки
                if (speakJob === selfJob) {
                    activeAudioTrack = null
                    isSpeakingNow = false
                    currentVoiceWaveLevel = 0.35f
                    abandonAudioFocus(appCtx)
                }
                if (isActive) {
                    val didPlay = playedSuccessfully
                    onFinished?.let { cb ->
                        mainHandler.post { cb.invoke(didPlay) }
                    }
                }
            }
        }
    }

    private suspend fun speakWithAndroidFallbackBlocking(context: Context, text: String): Boolean {
        return try {
            requestTransientAudioDucking(context)
            var tts = fallbackSystemTts
            if (tts == null) {
                var initDone = false
                tts = TextToSpeech(context.applicationContext) { status ->
                    fallbackTtsReady = (status == TextToSpeech.SUCCESS)
                    initDone = true
                }
                fallbackSystemTts = tts
                var waited = 0
                while (!initDone && waited < 25) {
                    delay(80L)
                    waited++
                }
            }
            if (fallbackTtsReady && tts != null) {
                tts.language = Locale("ru", "RU")
                tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mitv_fallback_utt")
                val estMs = (1200L + text.length * 68L).coerceIn(1500L, 9000L)
                var elapsed = 0L
                while (isSpeakingNow && elapsed < estMs) {
                    currentVoiceWaveLevel = if ((elapsed / 160L) % 2L == 0L) 0.72f else 0.38f
                    delay(160L)
                    elapsed += 160L
                }
                true
            } else {
                false
            }
        } catch (_: Exception) {
            false
        }
    }

    fun stop(context: Context? = null, preservePrefetch: Boolean = false) {
        if (!preservePrefetch) {
            prefetchedSentenceJob?.cancel()
            prefetchedSentenceJob = null
            prefetchedSentenceText = null
        }
        speakJob?.cancel()
        speakJob = null
        isSpeakingNow = false
        currentVoiceWaveLevel = 0.35f
        try {
            fallbackSystemTts?.stop()
        } catch (_: Exception) {
        }
        val runningTrack = activeAudioTrack
        activeAudioTrack = null
        if (runningTrack != null) {
            try {
                runningTrack.pause()
                runningTrack.flush()
            } catch (_: Exception) {
            }
            try {
                runningTrack.release()
            } catch (_: Exception) {
            }
        }
        if (context != null) {
            abandonAudioFocus(context.applicationContext)
        }
    }

    /**
     * Вырезает WAV/RIFF заголовок любой длины (ищет секцию "data", чтобы метаданные заголовка
     * никогда не попадали в AudioTrack как щелчок или писк в начале).
     */
    /**
     * Вырезает WAV/RIFF заголовок любой длины и отсекает служебные метаданные в конце (LIST, INFO, SynthID),
     * чтобы они никогда не проигрывались как цифровой треск в конце фраз!
     */
    private fun stripWavHeaderIfPresent(rawBytes: ByteArray): ByteArray {
        if (rawBytes.size <= 44) return rawBytes
        if (rawBytes[0] == 0x52.toByte() && rawBytes[1] == 0x49.toByte() &&
            rawBytes[2] == 0x46.toByte() && rawBytes[3] == 0x46.toByte()
        ) {
            val searchLimit = minOf(rawBytes.size - 8, 512)
            var pos = 12
            while (pos <= searchLimit) {
                if (rawBytes[pos] == 0x64.toByte() &&
                    rawBytes[pos + 1] == 0x61.toByte() &&
                    rawBytes[pos + 2] == 0x74.toByte() &&
                    rawBytes[pos + 3] == 0x61.toByte()
                ) {
                    val dataSize = ByteBuffer.wrap(rawBytes, pos + 4, 4).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xFFFFFFFFL
                    val dataStart = pos + 8
                    if (dataStart < rawBytes.size) {
                        val availableData = rawBytes.size - dataStart
                        val effectiveLen = if (dataSize in 1L..availableData) dataSize.toInt() else availableData
                        val clean = rawBytes.copyOfRange(dataStart, dataStart + effectiveLen)
                        return if (clean.size % 2 == 1) clean.copyOfRange(0, clean.size - 1) else clean
                    }
                }
                pos++
            }
            val fallback = rawBytes.copyOfRange(44, rawBytes.size)
            return if (fallback.size % 2 == 1) fallback.copyOfRange(0, fallback.size - 1) else fallback
        }
        return if (rawBytes.size % 2 == 1) rawBytes.copyOfRange(0, rawBytes.size - 1) else rawBytes
    }

    /**
     * Мягкий 20 мс fade-out в конце аудиоданных предотвращает щелчок/треск при обрыве амплитуды.
     */
    private fun applyTrailingFadeOut16BitMono(pcmBytes: ByteArray): ByteArray {
        val totalSamples = pcmBytes.size / 2
        val fadeSamples = minOf(totalSamples, 480) // 20 мс при 24 кГц
        if (fadeSamples <= 0) return pcmBytes
        val out = pcmBytes.copyOf()
        val bb = ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN)
        val startSample = totalSamples - fadeSamples
        for (i in 0 until fadeSamples) {
            val idx = (startSample + i) * 2
            val orig = bb.getShort(idx).toInt()
            val factor = (fadeSamples - i).toDouble() / fadeSamples.toDouble()
            val scaled = (orig * factor).toInt().coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            bb.putShort(idx, scaled)
        }
        return out
    }

    /**
     * Мягкий 15 мс fade-in на самом первом куске речи убирает любой начальный щелчок/хрип ЦАП.
     */
    private fun applyLeadingFadeIn16BitMono(pcmBytes: ByteArray): ByteArray {
        val totalSamples = pcmBytes.size / 2
        val fadeSamples = minOf(totalSamples, 360) // 15 мс при 24 кГц
        if (fadeSamples <= 0) return pcmBytes
        val out = pcmBytes.copyOf()
        val bb = ByteBuffer.wrap(out).order(ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until fadeSamples) {
            val orig = bb.getShort(i * 2).toInt()
            val scaled = ((orig * i) / fadeSamples).coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt()).toShort()
            bb.putShort(i * 2, scaled)
        }
        return out
    }

    private fun buildOrderedTtsModels(includeNoStreamFilter: Boolean): List<String> {
        val ordered = mutableListOf<String>()
        val cached = cachedTtsModel
        if (cached != null && !unavailableTtsModels.contains(cached) && (!includeNoStreamFilter || !noStreamModels.contains(cached))) {
            ordered.add(cached)
        }
        for (m in ttsModels) {
            if (m != cached && !unavailableTtsModels.contains(m) && (!includeNoStreamFilter || !noStreamModels.contains(m))) {
                ordered.add(m)
            }
        }
        return ordered
    }

    /**
     * Потоковый запрос Gemini TTS (streamGenerateContent, SSE) с двухуровневым перебором:
     * внешний цикл — по ключам пула (до 3 попыток), внутренний — по моделям.
     * При 429 меняет ключ с той же моделью; при 404/400 меняет модель с тем же ключом.
     */
    private fun streamGeminiTts(
        context: Context,
        textToSpeak: String,
        voiceName: String,
        budgetStartElapsedMs: Long,
        onPcm: (ByteArray) -> Boolean
    ): Boolean {
        val appCtx = context.applicationContext
        val orderedModels = buildOrderedTtsModels(includeNoStreamFilter = true)
        if (orderedModels.isEmpty()) return false

        val payload = JSONObject().apply {
            put("contents", JSONArray().put(
                JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", textToSpeak)))
                }
            ))
            put("generationConfig", JSONObject().apply {
                put("responseModalities", JSONArray().put("AUDIO"))
                put("speechConfig", JSONObject().apply {
                    put("voiceConfig", JSONObject().apply {
                        put("prebuiltVoiceConfig", JSONObject().apply {
                            put("voiceName", voiceName)
                        })
                    })
                })
            })
        }.toString()

        val triedFingerprints = HashSet<String>()
        var lease = GeminiKeyPool.acquire(appCtx, GeminiKeyPool.Kind.TTS, triedFingerprints)
        if (lease == null) {
            lastTtsError = "HTTP 429: все ключи TTS на паузе"
            return false
        }

        var keyAttempts = 1
        var modelIdx = 0

        while (lease != null && modelIdx < orderedModels.size) {
            if (SystemClock.elapsedRealtime() - budgetStartElapsedMs >= TTS_FIRST_SOUND_BUDGET_MS) {
                break
            }
            val currentLease = lease
            val model = orderedModels[modelIdx]
            if (noStreamModels.contains(model)) {
                modelIdx++
                continue
            }

            var conn: HttpURLConnection? = null
            var delivered = false
            try {
                val useQueryKey = currentLease.apiKey.startsWith("AIza")
                val urlStr = if (useQueryKey) {
                    "https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse&key=${Uri.encode(currentLease.apiKey)}"
                } else {
                    "https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse"
                }
                val connection = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 4000
                    readTimeout = 10000
                    doOutput = true
                    doInput = true
                    useCaches = false
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Accept-Encoding", "identity")
                    if (!useQueryKey) {
                        setRequestProperty("x-goog-api-key", currentLease.apiKey)
                    }
                }
                conn = connection
                connection.outputStream.use { os ->
                    os.write(payload.toByteArray(Charsets.UTF_8))
                    os.flush()
                }
                val code = connection.responseCode
                if (code !in 200..299) {
                    val errBody = try {
                        connection.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                    } catch (_: Exception) {
                        ""
                    }
                    val safeErrBody = GeminiKeyPool.sanitize(errBody)
                    lastTtsError = "$model (${currentLease.label} stream): HTTP $code " + safeErrBody.replace("\n", " ").take(140)
                    Log.w("GeminiTTS", lastTtsError)

                    val outcome = GeminiKeyPool.classifyHttpError(code, safeErrBody)
                    GeminiKeyPool.report(appCtx, currentLease, outcome)

                    when (outcome) {
                        is GeminiKeyPool.Outcome.ModelError -> {
                            if (code == 404 || code == 501) unavailableTtsModels.add(model)
                            markNoStreamModel(appCtx, model)
                            modelIdx++
                        }
                        is GeminiKeyPool.Outcome.RateLimited,
                        is GeminiKeyPool.Outcome.KeyDead,
                        is GeminiKeyPool.Outcome.NetworkError -> {
                            if (keyAttempts >= MAX_KEY_ATTEMPTS) break
                            triedFingerprints.add(currentLease.fingerprint)
                            lease = GeminiKeyPool.acquire(appCtx, GeminiKeyPool.Kind.TTS, triedFingerprints)
                            keyAttempts++
                        }
                        else -> modelIdx++
                    }
                    continue
                }

                connection.inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
                    var firstPiece = true
                    var carryByte: Byte? = null
                    var stopped = false
                    while (!stopped) {
                        val line = reader.readLine() ?: break
                        if (!line.startsWith("data:")) continue
                        val json = line.substring(5).trim()
                        if (json.isEmpty() || json == "[DONE]") continue
                        val parts = JSONObject(json).optJSONArray("candidates")
                            ?.optJSONObject(0)
                            ?.optJSONObject("content")
                            ?.optJSONArray("parts") ?: continue
                        for (i in 0 until parts.length()) {
                            val b64 = parts.optJSONObject(i)?.optJSONObject("inlineData")?.optString("data", "") ?: ""
                            if (b64.isBlank()) continue
                            var data = Base64.decode(b64, Base64.DEFAULT)
                            if (firstPiece) {
                                firstPiece = false
                                data = stripWavHeaderIfPresent(data)
                            }
                            val c = carryByte
                            if (c != null) {
                                data = byteArrayOf(c) + data
                                carryByte = null
                            }
                            if (data.size % 2 == 1) {
                                carryByte = data[data.size - 1]
                                data = data.copyOfRange(0, data.size - 1)
                            }
                            if (data.isEmpty()) continue
                            delivered = true
                            saveCachedTtsModel(appCtx, model)
                            if (!onPcm(data)) {
                                stopped = true
                                break
                            }
                        }
                    }
                }

                if (delivered) {
                    GeminiKeyPool.report(appCtx, currentLease, GeminiKeyPool.Outcome.Ok)
                    return true
                }
                lastTtsError = "$model (${currentLease.label} stream): нет аудио в ответе"
                markNoStreamModel(appCtx, model)
                modelIdx++
            } catch (e: Exception) {
                if (delivered) {
                    GeminiKeyPool.report(appCtx, currentLease, GeminiKeyPool.Outcome.Ok)
                    return true
                }
                val safeMsg = GeminiKeyPool.sanitize(e.message)
                lastTtsError = "$model (${currentLease.label} stream): " + e.javaClass.simpleName + " " + safeMsg.take(90)
                Log.w("GeminiTTS", lastTtsError)
                GeminiKeyPool.report(appCtx, currentLease, GeminiKeyPool.Outcome.NetworkError)
                if (keyAttempts >= MAX_KEY_ATTEMPTS) break
                triedFingerprints.add(currentLease.fingerprint)
                lease = GeminiKeyPool.acquire(appCtx, GeminiKeyPool.Kind.TTS, triedFingerprints)
                keyAttempts++
            } finally {
                try {
                    conn?.disconnect()
                } catch (_: Exception) {
                }
            }
        }
        return false
    }

    private suspend fun fetchGeminiTtsPcmWithRetry(
        context: Context,
        textToSpeak: String,
        voiceName: String,
        budgetStartElapsedMs: Long
    ): ByteArray? {
        for (attempt in 0 until 2) {
            if (SystemClock.elapsedRealtime() - budgetStartElapsedMs >= TTS_FIRST_SOUND_BUDGET_MS) break
            val pcm = fetchGeminiTtsPcmOnce(context, textToSpeak, voiceName, budgetStartElapsedMs)
            if (pcm != null && pcm.size > 400) return pcm
            if (attempt == 0 && SystemClock.elapsedRealtime() - budgetStartElapsedMs < TTS_FIRST_SOUND_BUDGET_MS - 500L) {
                delay(250L)
            }
        }
        return null
    }

    private fun fetchGeminiTtsPcmOnce(
        context: Context,
        textToSpeak: String,
        voiceName: String,
        budgetStartElapsedMs: Long
    ): ByteArray? {
        val appCtx = context.applicationContext
        val orderedModels = buildOrderedTtsModels(includeNoStreamFilter = false)
        if (orderedModels.isEmpty()) return null

        val payload = JSONObject().apply {
            put("contents", JSONArray().put(
                JSONObject().apply {
                    put("parts", JSONArray().put(
                        JSONObject().put("text", textToSpeak)
                    ))
                }
            ))
            put("generationConfig", JSONObject().apply {
                put("responseModalities", JSONArray().put("AUDIO"))
                put("speechConfig", JSONObject().apply {
                    put("voiceConfig", JSONObject().apply {
                        put("prebuiltVoiceConfig", JSONObject().apply {
                            put("voiceName", voiceName)
                        })
                    })
                })
            })
        }.toString()

        val triedFingerprints = HashSet<String>()
        var lease = GeminiKeyPool.acquire(appCtx, GeminiKeyPool.Kind.TTS, triedFingerprints)
        if (lease == null) {
            lastTtsError = "HTTP 429: все ключи TTS на паузе"
            return null
        }

        var keyAttempts = 1
        var modelIdx = 0

        while (lease != null && modelIdx < orderedModels.size) {
            if (SystemClock.elapsedRealtime() - budgetStartElapsedMs >= TTS_FIRST_SOUND_BUDGET_MS) {
                break
            }
            val currentLease = lease
            val model = orderedModels[modelIdx]
            var conn: HttpURLConnection? = null
            try {
                val useQueryKey = currentLease.apiKey.startsWith("AIza")
                val urlStr = if (useQueryKey) {
                    "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=${Uri.encode(currentLease.apiKey)}"
                } else {
                    "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
                }
                val connection = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 4000
                    readTimeout = 10000
                    doOutput = true
                    doInput = true
                    useCaches = false
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    if (!useQueryKey) {
                        setRequestProperty("x-goog-api-key", currentLease.apiKey)
                    }
                }
                conn = connection
                connection.outputStream.use { os ->
                    os.write(payload.toByteArray(Charsets.UTF_8))
                    os.flush()
                }
                val code = connection.responseCode
                if (code in 200..299) {
                    val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    val root = JSONObject(body)
                    val parts = root.optJSONArray("candidates")
                        ?.optJSONObject(0)
                        ?.optJSONObject("content")
                        ?.optJSONArray("parts")
                    if (parts != null) {
                        for (i in 0 until parts.length()) {
                            val inlineData = parts.optJSONObject(i)?.optJSONObject("inlineData") ?: continue
                            val b64 = inlineData.optString("data", "")
                            if (b64.isNotBlank()) {
                                GeminiKeyPool.report(appCtx, currentLease, GeminiKeyPool.Outcome.Ok)
                                saveCachedTtsModel(appCtx, model)
                                val rawBytes = Base64.decode(b64, Base64.DEFAULT)
                                val pcm = stripWavHeaderIfPresent(rawBytes)
                                val evenPcm = if (pcm.size % 2 == 1) pcm.copyOfRange(0, pcm.size - 1) else pcm
                                return applyTrailingFadeOut16BitMono(evenPcm)
                            }
                        }
                    }
                    lastTtsError = "$model (${currentLease.label}): нет аудио в ответе"
                    modelIdx++
                } else {
                    val errBody = try {
                        connection.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                    } catch (_: Exception) {
                        ""
                    }
                    val safeErrBody = GeminiKeyPool.sanitize(errBody)
                    lastTtsError = "$model (${currentLease.label}): HTTP $code " + safeErrBody.replace("\n", " ").take(140)
                    Log.w("GeminiTTS", lastTtsError)

                    val outcome = GeminiKeyPool.classifyHttpError(code, safeErrBody)
                    GeminiKeyPool.report(appCtx, currentLease, outcome)

                    when (outcome) {
                        is GeminiKeyPool.Outcome.ModelError -> {
                            if (code == 404 || code == 501) unavailableTtsModels.add(model)
                            modelIdx++
                        }
                        is GeminiKeyPool.Outcome.RateLimited,
                        is GeminiKeyPool.Outcome.KeyDead,
                        is GeminiKeyPool.Outcome.NetworkError -> {
                            if (keyAttempts >= MAX_KEY_ATTEMPTS) break
                            triedFingerprints.add(currentLease.fingerprint)
                            lease = GeminiKeyPool.acquire(appCtx, GeminiKeyPool.Kind.TTS, triedFingerprints)
                            keyAttempts++
                        }
                        else -> modelIdx++
                    }
                }
            } catch (e: Exception) {
                try {
                    conn?.disconnect()
                } catch (_: Exception) {
                }
                val safeMsg = GeminiKeyPool.sanitize(e.message)
                lastTtsError = "$model (${currentLease.label}): " + e.javaClass.simpleName + " " + safeMsg.take(90)
                Log.w("GeminiTTS", lastTtsError)
                GeminiKeyPool.report(appCtx, currentLease, GeminiKeyPool.Outcome.NetworkError)
                if (keyAttempts >= MAX_KEY_ATTEMPTS) break
                triedFingerprints.add(currentLease.fingerprint)
                lease = GeminiKeyPool.acquire(appCtx, GeminiKeyPool.Kind.TTS, triedFingerprints)
                keyAttempts++
            }
        }
        return null
    }

    /**
     * Открывает AudioTrack (24 кГц, 16 бит, моно) и сразу подаёт 160 мс тишины (3840 кадров = 7680 байт)
     * перед стартом воспроизведения, чтобы аудиотракт ТВ / HDMI успел проснуться без хрипа и съедания начала.
     */
    private fun openStreamingAudioTrack24kHz(context: Context): Pair<AudioTrack, Long>? {
        val sampleRate = 24000
        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(4800)

        return try {
            requestTransientAudioDucking(context)
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            val format = AudioFormat.Builder()
                .setSampleRate(sampleRate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()
            val track = AudioTrack(
                attrs,
                format,
                (minBuf * 2).coerceAtLeast(48000),
                AudioTrack.MODE_STREAM,
                AudioManager.AUDIO_SESSION_ID_GENERATE
            )
            // 160 мс тишины (3840 сэмплов = 7680 байт) до первого куска речи
            val leadInSilence = ByteArray(7680)
            val preWritten = track.write(leadInSilence, 0, leadInSilence.size).coerceAtLeast(0)
            track.play()
            Pair(track, (preWritten / 2).toLong())
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Записывает PCM-данные в AudioTrack и возвращает точное число записанных кадров (1 кадр = 2 байта).
     */
    @Volatile
    private var firstAudioLoggedThisSpeak = false

    private fun writePcmChunkWithVisualizer(at: AudioTrack, pcmBytes: ByteArray): Long {
        if (!firstAudioLoggedThisSpeak) {
            firstAudioLoggedThisSpeak = true
            GeminiCloudClient.logTiming("tts_first_audio_written")
        }
        return try {
            val chunkSize = 1920 // 40 мс при 24000 Гц (16 бит моно)
            var offset = 0
            var totalWrittenBytes = 0L
            while (offset < pcmBytes.size && isSpeakingNow) {
                val len = (pcmBytes.size - offset).coerceAtMost(chunkSize)
                val samplesCount = len / 2
                if (samplesCount > 0) {
                    var sumSq = 0.0
                    val bb = ByteBuffer.wrap(pcmBytes, offset, len).order(ByteOrder.LITTLE_ENDIAN)
                    for (s in 0 until samplesCount) {
                        val v = bb.short.toDouble()
                        sumSq += v * v
                    }
                    val rms = sqrt(sumSq / samplesCount)
                    val normalized = (0.24 + (rms / 6500.0) * 0.76).coerceIn(0.24, 1.0).toFloat()
                    currentVoiceWaveLevel = normalized
                }
                val written = at.write(pcmBytes, offset, len)
                if (written <= 0) break
                offset += written
                totalWrittenBytes += written
            }
            totalWrittenBytes / 2L
        } catch (_: Exception) {
            0L
        }
    }

    /**
     * Дожидается полного проигрывания буфера AudioTrack до targetFrames перед вызовом stop()/release(),
     * чтобы конец фразы никогда не обрезался.
     */
    private suspend fun awaitAudioTrackDrain(at: AudioTrack, speechFramesWritten: Long) {
        if (speechFramesWritten <= 0L) return
        try {
            // Плавное затухание 20 мс (480 сэмплов = 960 байт) + тишина гарантируют полное отсутствие треска в конце!
            val fadeOutChunk = ByteArray(960)
            at.write(fadeOutChunk, 0, fadeOutChunk.size)
            val tailSilence = ByteArray(7680)
            at.write(tailSilence, 0, tailSilence.size)

            val startHead = at.playbackHeadPosition.toLong() and 0xFFFFFFFFL
            val remainingFrames = (speechFramesWritten - startHead).coerceAtLeast(0L)
            val maxWaitMs = ((remainingFrames * 1000L) / 24000L + 650L).coerceIn(350L, 2400L)

            var waitedMs = 0L
            var lastHead = startHead
            var stalledMs = 0L

            while (isSpeakingNow && waitedMs < maxWaitMs) {
                val currentHead = at.playbackHeadPosition.toLong() and 0xFFFFFFFFL
                if (currentHead >= speechFramesWritten) break
                if (currentHead > lastHead) {
                    lastHead = currentHead
                    stalledMs = 0L
                } else {
                    stalledMs += 25L
                    if (stalledMs >= 350L) break
                }
                currentVoiceWaveLevel = 0.28f
                delay(25L)
                waitedMs += 25L
            }
        } catch (_: Exception) {
        }
    }

    private fun requestTransientAudioDucking(context: Context) {
        try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
                val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(attrs)
                    .setAcceptsDelayedFocusGain(false)
                    .setWillPauseWhenDucked(false)
                    .build()
                currentAudioFocusRequest = req
                am.requestAudioFocus(req)
            } else {
                @Suppress("DEPRECATION")
                am.requestAudioFocus(
                    null,
                    AudioManager.STREAM_MUSIC,
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
                )
            }
        } catch (_: Exception) {
        }
    }

    private fun abandonAudioFocus(context: Context) {
        try {
            val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                currentAudioFocusRequest?.let { am.abandonAudioFocusRequest(it) }
                currentAudioFocusRequest = null
            } else {
                @Suppress("DEPRECATION")
                am.abandonAudioFocus(null)
            }
        } catch (_: Exception) {
        }
    }
}

data class GeminiTurnResult(
    val displayText: String,
    val shouldContinueDialog: Boolean,
    val isSilence: Boolean = false
)

object GeminiCloudClient {

    private const val PREF_CACHED_TEXT_MODEL = "pref_cached_gemini_text_model_v63"
    private const val PREF_DISCOVERED_MODELS = "pref_discovered_gemini_models_v62"
    private const val PREF_DISCOVERED_TS = "pref_discovered_gemini_ts_v62"

    private const val TEXT_TURN_BUDGET_MS = 15_000L

    // false: для голоса берём самую быструю модель из списка (lite). true: принудительно gemini-3.5-flash первой
    // (точнее расшифровка, но заметно медленнее).
    private const val VOICE_PREFER_SMART_MODEL = false
    private const val TAG_TIMING = "AssistantTiming"
    private const val MAX_KEY_ATTEMPTS = 3

    private data class ChatTurn(
        val role: String,
        val text: String
    )

    // Очищенный список актуальных быстрых моделей (отключённая gemini-1.5-flash убрана)
    private val candidateModels = listOf(
        "gemini-3.5-flash-lite",
        "gemini-3.5-flash",
        "gemini-3.1-flash-lite"
    )

    private val unavailableTextModels = java.util.concurrent.CopyOnWriteArraySet<String>()
    private val noStreamTextModels = java.util.concurrent.CopyOnWriteArraySet<String>()
    // model -> "low" (мягче, чем minimal) или "NONE" (не отправлять thinkingConfig). Заполняется только
    // когда API явно пожаловался на thinking в теле ошибки 400.
    private val thinkingLevelOverride = java.util.concurrent.ConcurrentHashMap<String, String>()

    @Volatile
    private var turnT0ElapsedMs: Long = 0L

    /** Лог времени этапов хода (logcat, тег AssistantTiming): от старта запроса к Gemini до первого звука. */
    fun logTiming(stage: String) {
        val base = turnT0ElapsedMs
        val dt = if (base > 0L) SystemClock.elapsedRealtime() - base else -1L
        Log.i(TAG_TIMING, "+${dt}ms $stage")
    }

    private val conversationHistory = mutableListOf<ChatTurn>()
    private val warmupScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile
    private var lastInteractionRealtimeMs: Long = 0L

    @Volatile
    private var cachedModelName: String? = null

    @Volatile
    private var prefsLoaded: Boolean = false

    @Volatile
    private var lastWarmupRealtimeMs: Long = 0L

    private val leadingTagCleanupRegex = Regex("^(\\s*\\[(USER_SAID|MODE|CMD):[^\\]]*\\]\\s*)+")

    @Synchronized
    private fun ensureTextModelCacheLoaded(context: Context) {
        if (prefsLoaded) return
        prefsLoaded = true
        try {
            val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            val saved = prefs.getString(PREF_CACHED_TEXT_MODEL, null)
            if (!saved.isNullOrBlank()) {
                cachedModelName = saved
            }
        } catch (_: Exception) {
        }
    }

    private fun saveCachedTextModel(context: Context, model: String) {
        cachedModelName = model
        try {
            val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit().putString(PREF_CACHED_TEXT_MODEL, model).apply()
        } catch (_: Exception) {
        }
    }

    /**
     * Фоновый прогрев TLS/Keep-Alive соединения с generativelanguage.googleapis.com в момент старта записи речи (Этап 2),
     * чтобы основной запрос текста и озвучки не тратил 200–500 мс на TCP+TLS рукопожатие.
     */
    fun warmupConnectionAsync(context: Context) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastWarmupRealtimeMs < 45_000L) return
        lastWarmupRealtimeMs = now
        val appCtx = context.applicationContext
        warmupScope.launch {
            ensureTextModelCacheLoaded(appCtx)
            AssistantVoiceSpeaker.init(appCtx)
            // Проверяем ключи в фоне без изменения очереди round-robin (чтобы не забирать очередь у рабочего ключа #1!)
            val leases = GeminiKeyPool.peekKeysForBackgroundProbe(appCtx)
            for (lease in leases.take(3)) {
                var conn: HttpURLConnection? = null
                var reuse = false
                try {
                    val useQuery = lease.apiKey.startsWith("AIza")
                    val urlStr = if (useQuery) {
                        "https://generativelanguage.googleapis.com/v1beta/models?pageSize=1&key=${Uri.encode(lease.apiKey)}"
                    } else {
                        "https://generativelanguage.googleapis.com/v1beta/models?pageSize=1"
                    }
                    val connection = (URL(urlStr).openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 3500
                        readTimeout = 3500
                        doInput = true
                        useCaches = false
                        if (!useQuery) {
                            setRequestProperty("x-goog-api-key", lease.apiKey)
                        }
                    }
                    conn = connection
                    val code = connection.responseCode
                    if (code in 200..299) {
                        connection.inputStream.use { it.readBytes() }
                        reuse = true
                    } else {
                        val err = try {
                            connection.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                        } catch (_: Exception) {
                            ""
                        }
                        if (code in listOf(400, 401, 403)) {
                            val outcome = GeminiKeyPool.classifyHttpError(code, err)
                            if (outcome is GeminiKeyPool.Outcome.KeyDead) {
                                GeminiKeyPool.report(appCtx, lease, outcome)
                            }
                        }
                    }
                } catch (_: Exception) {
                } finally {
                    // disconnect() закрывает сокет и убивает keep-alive: после успешного ответа соединение оставляем в пуле
                    if (!reuse) {
                        try {
                            conn?.disconnect()
                        } catch (_: Exception) {
                        }
                    }
                }
            }
        }
    }

    @Synchronized
    fun clearConversationHistory() {
        conversationHistory.clear()
    }

    @Synchronized
    private fun appendTurnToHistory(userText: String, modelText: String) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastInteractionRealtimeMs > 5 * 60 * 1000L) {
            conversationHistory.clear()
        }
        lastInteractionRealtimeMs = now
        if (userText.isNotBlank()) {
            conversationHistory.add(ChatTurn("user", userText.take(350)))
        }
        if (modelText.isNotBlank()) {
            conversationHistory.add(ChatTurn("model", modelText.take(450)))
        }
        while (conversationHistory.size > 8) {
            conversationHistory.removeAt(0)
        }
    }

    @Synchronized
    private fun formatRecentHistoryBlock(): String {
        val now = SystemClock.elapsedRealtime()
        if (now - lastInteractionRealtimeMs > 5 * 60 * 1000L) {
            conversationHistory.clear()
            return ""
        }
        if (conversationHistory.isEmpty()) return ""
        val lines = conversationHistory.joinToString("\n") { turn ->
            val who = if (turn.role == "user") "Пользователь" else "Ты (Ассистент)"
            "$who: ${turn.text}"
        }
        return "\nПредыдущий контекст текущего диалога (учитывай его при ответе на уточняющие вопросы вроде «а на завтра?», «а почему?», «расскажи подробнее»):\n$lines\n"
    }

    private fun buildCommandInstruction(context: Context): String {
        val appCtx = context.applicationContext
        val apps = AppLauncher(appCtx).getInstalledApps().take(30)
            .joinToString(", ") { "${it.label} (${it.packageName})" }
        val outageInfo = OutageRepository.getSummaryForAi(appCtx)
        val quotaReport = GeminiKeyPool.getVoiceQuotaReport(appCtx)
        val nowDateStr = SimpleDateFormat("yyyy-MM-dd HH:mm (EEEE)", Locale("ru", "RU")).format(Date())
        val remindersBlock = ScheduledTaskManager.getPendingRemindersSummaryForAi(appCtx)
        val historyBlock = formatRecentHistoryBlock() + AiMemoryStore.getMemoryPromptBlock(appCtx) + remindersBlock
        val currentVoice = AssistantVoiceSpeaker.getSelectedVoiceName(appCtx)
        val ttsEnabled = AssistantVoiceSpeaker.isTtsEnabled(appCtx)
        // Статическая часть идёт первой и не меняется между ходами, поэтому Gemini может кэшировать общий префикс.
        // Всё, что меняется (время, история, память, график света и т.д.), вынесено в блок «ТЕКУЩИЕ ДАННЫЕ» в конце.
        val staticRules = "Ты — живой, умный и сверхбыстрый голосовой ИИ-ассистент в кастомном лаунчере Android TV (Xiaomi Mi TV Stick). " +
            "Отвечай естественно, дружелюбно и лаконично (1–2 предложения, без звёздочек и без разметки Markdown). " +
            "Актуальные данные (время, график отключений света, озвучка, статус ключей, контекст диалога, память, напоминания, список приложений) находятся в блоке «ТЕКУЩИЕ ДАННЫЕ» в конце этой инструкции. " +
            "Если пользователь спрашивает про свет/отключения/график ДТЭК — дай точный ответ по этим данным! " +
            "НИКОГДА не говори про ключи и лимиты сам по себе; отвечай статусом пула ключей ТОЛЬКО если пользователь сам прямо спросил «сколько ключей активно/не работает» или «что там по лимитам». " +
            "Ты идеально понимаешь украинский, русский, суржик и английский языки. Отвечай на том же языке, на котором обратился пользователь.\n" +
            "ПРАВИЛА ТОЧНОСТИ (очень важно):\n" +
            "- Сначала внимательно определи, ЧТО именно сказал пользователь (название песни, артиста, приложения, стримера). Не подставляй похожие по звучанию слова и не выдумывай названия.\n" +
            "- Если сервис не назван: песню, трек, альбом или исполнителя включай через [CMD:SPOTIFY:...]; видео, клип, ролик, ютуб, фильм — через [CMD:YT:...]; стрим — через [CMD:KICK:...]. Слово «аудио» или «audio» в названии — это часть названия трека или артиста, а не отдельная команда.\n" +
            "- Название артиста и трека пиши в оригинальной латинице или кириллице, как оно правильно пишется (исправляй расслышанный транслит).\n" +
            "- Если ты расслышал запрос плохо, он неоднозначный или ты не уверен в названии — НЕ запускай ничего наугад: коротко переспроси «Вы имели в виду …?» и поставь [MODE:DIALOG].\n" +
            "ВАЖНОЕ ПРАВИЛО РЕЖИМА ДИАЛОГА:\n" +
            "- Если пользователь выполняет команду управления ТВ (включи трек/видео/стрим, открой приложение, измени громкость/цвет) ИЛИ задал простой закрытый вопрос на один факт (например «когда выключат свет?», «какая очередь?», «сколько времени?») — обязательно поставь в начале ответа тег [MODE:ONE_SHOT], чтобы после ответа микрофон НЕ включался сам.\n" +
            "- Ставь тег [MODE:DIALOG] ТОЛЬКО тогда, когда пользователь явно ведёт беседу/обсуждение (например «посоветуй фильм», «давай поговорим», «расскажи...») ИЛИ когда ты сам задаёшь пользователю встречный уточняющий вопрос в конце ответа!\n" +
            "ТЕГИ КОМАНД УПРАВЛЕНИЯ ПРИСТАВКОЙ (ставь в начале ответа, если пользователь просит выполнить действие):\n" +
            "- Включить песню, трек, альбом или исполнителя в Spotify: [CMD:SPOTIFY:Точное имя артиста и трека] (переводи транслит в оригинальное название, например «уикенд старбой» -> [CMD:SPOTIFY:The Weeknd Starboy])\n" +
            "- Запустить стрим на Kick: [CMD:KICK:channel_slug] (переводи русские/украинские имена стримеров в их точный ник на Kick: Калатай -> kalatay3, Зубарев -> zubarefff, Мелстрой -> mellstroy, Бустер -> buster, Плохой Парень -> plohoyparen, Эвелон -> evelone192, Строго -> strogo, Хесус -> jesusavgn, Коряга -> korya_mc)\n" +
            "- Включить конкретное видео, клип, песню или канал на YouTube (автоматически запустит видео!): [CMD:YT:точный поисковый запрос] (например «включи на ютубе лав 66 бай бай» -> [CMD:YT:LOVV66 БАЙ БАЙ])\n" +
            "- Запомнить любой факт, заметку, код или правило в долгосрочную память: [CMD:REMEMBER:текст для запоминания]\n" +
            "- Забыть заметку из долгосрочной памяти: [CMD:FORGET:ключевое слово или ALL]\n" +
            "- Найти или открыть приложение/игру/страницу в Google Play Маркете: [CMD:MARKET:название приложения или пусто для открытия Маркета]\n" +
            "- Перемотать видео или стрим вперёд/назад на нужное число секунд: [CMD:SEEK:FWD_30] или [CMD:SEEK:REW_30] (укажи секунды, например FWD_120 для 2 минут вперёд)\n" +
            "- Поставить голосовое напоминание через N секунд/минут/часов: [CMD:REMIND:секунды:текст напоминания] (например 20 минут = 1200, полчаса = 1800, 1 час = 3600)\n" +
            "- Поставить голосовое напоминание на конкретное время или завтрашний день (например «напомни завтра в 10 утра позвонить», «напомни в 18:30» — сохраняется в постоянную память и НЕ сбрасывается!): [CMD:REMIND_AT:ГГГГ-ММ-ДД ЧЧ:ММ;текст напоминания] (рассчитай точную дату ГГГГ-ММ-ДД ЧЧ:ММ относительно текущего времени из блока «ТЕКУЩИЕ ДАННЫЕ», разделитель перед текстом — точка с запятой `;`)\n" +
            "- Выполнить отложенную команду умного дома или ТВ через время (например «включи ленту через 20 минут» -> [CMD:DELAY_CMD:1200:LED_ON], «выключи телевизор через 30 минут» -> [CMD:DELAY_CMD:1800:SLEEP]): [CMD:DELAY_CMD:секунды:КОМАНДА]\n" +
            "- Изменить цвет СИСТЕМЫ (темы лаунчера, обводки, часов, градиента фона): [CMD:COLOR:#RRGGBB] (красный #EF4444, розовый #EC4899, фиолетовый #A78BFA, зелёный #34D399, синий #60A5FA, голубой/бирюзовый #00F0FF, жёлтый/золотой #F59E0B, оранжевый #F97316, белый #E2E8F0). ВАЖНО: если пользователь просит изменить цвет СИСТЕМЫ / ТЕМЫ / ЛАУНЧЕРА — ставь ТОЛЬКО [CMD:COLOR:#RRGGBB] и НИКОГДА не ставь [CMD:LED_COLOR] (если у пользователя включена синхронизация с лентой, лаунчер сам синхронизирует её автоматически!)\n" +
            "- Управление умной светодиодной LED-лентой (подсветкой ТВ — ставь ТОЛЬКО когда пользователь явно сказал слово «лента» или «подсветка»!): включить ленту/подсветку [CMD:LED_ON], выключить ленту/подсветку [CMD:LED_OFF], установить цвет ленты [CMD:LED_COLOR:#RRGGBB] (переводи любое название оттенка — бирюзовый #00F0FF, морская волна #06B6D4, сапфир #2563EB, индиго #6366F1, лаванда #C084FC, фиолетовый #A855F7, фуксия/розовый #EC4899, малиновый #F43F5E, красный #EF4444, персиковый #FB923C, закат #F97316, янтарный/жёлтый #F59E0B, лайм #84CC16, изумрудный/зелёный #10B981, мята #2DD4BF, тёплый белый #FDE68A), изменить яркость ленты в процентах [CMD:LED_BRIGHT:10..100], включить динамический режим на ленте [CMD:LED_SCENE:RAINBOW|BREATHE|PARTY|NIGHT]\n" +
            "- Открыть установленное приложение: [CMD:LAUNCH:package_name] (список приложений — в блоке «ТЕКУЩИЕ ДАННЫЕ»)\n" +
            "- Открыть системные настройки ТВ: [CMD:SETTINGS], настройки Wi-Fi: [CMD:WIFI], настройки Bluetooth: [CMD:BLUETOOTH]\n" +
            "- Открыть сайт в браузере: [CMD:URL:https://адрес]\n" +
            "- Громкость в процентах: [CMD:VOL_SET:0..100], сделать громче: [CMD:VOL_UP], тише: [CMD:VOL_DOWN], выключить звук: [CMD:MUTE], включить звук: [CMD:UNMUTE]\n" +
            "- Управление плеером: [CMD:PAUSE], [CMD:PLAY], [CMD:NEXT], [CMD:PREV]\n" +
            "- Очистить оперативную память / ускорить приставку: [CMD:BOOST]\n" +
            "- Выключить или включить звук щелчков пульта: [CMD:NAV_SOUND:OFF] или [CMD:NAV_SOUND:ON]\n" +
            "- Выключить или включить голосовую озвучку твоих ответов: [CMD:TTS:OFF] или [CMD:TTS:ON]\n" +
            "- Сменить твой голос озвучки (доступны мужские голоса Puck, Charon, Fenrir и женские Kore, Aoede): [CMD:VOICE:имя_голоса]\n" +
            "- Показать на экране окно графика отключений света: [CMD:OUTAGE_OPEN]\n" +
            "- Изменить очередь (группу) отключений света ДТЭК (от 1.1 до 6.2): [CMD:OUTAGE_GROUP:номер_очереди]\n" +
            "- Ввести или напечатать текст в поле поиска на экране ТВ: [CMD:TYPE:текст для ввода]\n" +
            "- Нажать на кнопку, вкладку или карточку на экране ТВ по названию: [CMD:CLICK:текст кнопки]\n" +
            "- Системная навигация по ТВ: [CMD:NAV:HOME] (на главный экран), [CMD:NAV:BACK] (назад)\n" +
            "- Если пользователь прощается или говорит «спасибо, всё / хватит / пока / отбой»: [CMD:STOP_DIALOG]\n" +
            "- Если пользователь просит забыть контекст или сменить тему: [CMD:CLEAR_MEMORY]\n" +
            "После тегов напиши короткий живой ответ для пользователя."

        val dynamicBlock = "\n\nТЕКУЩИЕ ДАННЫЕ:\n" +
            "Точное текущее время и дата на приставке: $nowDateStr.\n" +
            "Голосовая озвучка ответов: ${if (ttsEnabled) "ВКЛЮЧЕНА (голос $currentVoice)" else "ВЫКЛЮЧЕНА"}.\n" +
            "График отключений света пользователя: $outageInfo.\n" +
            "Статус пула ключей: $quotaReport.\n" +
            "Установленные приложения: $apps.\n" +
            historyBlock
        return staticRules + dynamicBlock
    }

    private fun buildPayloadForModel(
        contentsArray: JSONArray,
        modelName: String,
        temperature: Double,
        systemText: String? = null
    ): String {
        val genConfig = JSONObject().apply {
            put("maxOutputTokens", 1200)
            put("temperature", temperature)
            val override = thinkingLevelOverride[modelName]
            if (override != "NONE") {
                if (modelName.startsWith("gemini-2.5-flash")) {
                    put("thinkingConfig", JSONObject().apply {
                        put("thinkingBudget", 0)
                    })
                } else if (modelName.startsWith("gemini-3")) {
                    put("thinkingConfig", JSONObject().apply {
                        put("thinkingLevel", override ?: "minimal")
                    })
                }
            }
        }
        return JSONObject().apply {
            if (!systemText.isNullOrBlank()) {
                put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", systemText)))
                })
            }
            put("contents", contentsArray)
            put("generationConfig", genConfig)
        }.toString()
    }

    /**
     * Проверяет приходящий потоковый текст (streamGenerateContent?alt=sse): как только после
     * командных тегов появилось первое законченное предложение (40..120 символов, разделитель . ! ? … \n),
     * сразу запускает предзагрузку его озвучки в AssistantVoiceSpeaker!
     */
    private fun inspectStreamingTextForEarlyTts(context: Context, partialRawText: String, alreadyTriggered: Boolean): Boolean {
        if (alreadyTriggered || !AssistantVoiceSpeaker.isTtsEnabled(context)) return alreadyTriggered
        if (partialRawText.contains("[SILENCE]")) return true
        val stripped = partialRawText.replace(leadingTagCleanupRegex, "").trimStart()
        // Тег ещё не дописан (например «[CMD:SPOT») — ждём
        if (stripped.startsWith("[")) return false
        val first = AssistantVoiceSpeaker.extractFirstSentenceForEarlyTts(stripped) ?: return false
        logTiming("early_tts_prefetch_started")
        AssistantVoiceSpeaker.startFirstSentencePrefetchIfReady(context, first)
        return true
    }

    suspend fun askGeminiTextTurn(context: Context, userQuery: String): GeminiTurnResult = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext
        ensureTextModelCacheLoaded(appCtx)
        warmupScope.launch {
            try {
                OutageRepository.refreshIfNeeded(appCtx, force = false)
            } catch (_: Exception) {
            }
        }
        val systemText = buildCommandInstruction(appCtx)
        val fullPrompt = "Запрос пользователя: $userQuery"

        val contentsArray = JSONArray().put(
            JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", fullPrompt)))
            }
        )

        var earlyTtsStarted = false
        val rawReply = executeWithEndpointFallback(appCtx, contentsArray, systemText, temperature = 0.35) { partialText ->
            earlyTtsStarted = inspectStreamingTextForEarlyTts(appCtx, partialText, earlyTtsStarted)
        }
        processCommandTags(appCtx, rawReply, userTranscript = userQuery)
    }

    suspend fun askGeminiText(context: Context, userQuery: String): String {
        return askGeminiTextTurn(context, userQuery).displayText
    }

    suspend fun askGeminiAudioTurn(context: Context, wavBytes: ByteArray): GeminiTurnResult = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext
        ensureTextModelCacheLoaded(appCtx)
        warmupScope.launch {
            try {
                OutageRepository.refreshIfNeeded(appCtx, force = false)
            } catch (_: Exception) {
            }
        }
        val systemText = buildCommandInstruction(appCtx)
        val audioPrompt =
            "Прослушай голосовую реплику пользователя (на украинском, русском, суржике или английском). " +
            "Если на записи только тишина или фоновый шум без речи — ответь ровно одним словом: [SILENCE]. " +
            "Иначе в самом начале ответа напиши тег [USER_SAID:точная краткая расшифровка слов пользователя], затем тег режима ([MODE:ONE_SHOT] или [MODE:DIALOG]), теги команд [CMD:...] (если нужны) и свой ответ."

        val b64Audio = Base64.encodeToString(wavBytes, Base64.NO_WRAP)
        val partsArray = JSONArray()
            .put(JSONObject().put("text", audioPrompt))
            .put(JSONObject().put("inlineData", JSONObject().apply {
                put("mimeType", "audio/wav")
                put("data", b64Audio)
            }))

        val contentsArray = JSONArray().put(
            JSONObject().apply {
                put("role", "user")
                put("parts", partsArray)
            }
        )

        var earlyTtsStarted = false
        val rawReply = executeWithEndpointFallback(appCtx, contentsArray, systemText, temperature = 0.3, smartFirst = true) { partialText ->
            earlyTtsStarted = inspectStreamingTextForEarlyTts(appCtx, partialText, earlyTtsStarted)
        }
        if (rawReply.contains("[SILENCE]")) {
            return@withContext GeminiTurnResult(
                displayText = "Не расслышал речь. Скажите запрос в микрофон.",
                shouldContinueDialog = false,
                isSilence = true
            )
        }
        processCommandTags(appCtx, rawReply, userTranscript = "")
    }

    suspend fun askGeminiAudio(context: Context, wavBytes: ByteArray): String {
        return askGeminiAudioTurn(context, wavBytes).displayText
    }

    private fun processCommandTags(context: Context, reply: String, userTranscript: String): GeminiTurnResult {
        var clean = reply.trim()
        var extractedUserSaid = userTranscript.trim()

        val saidRegex = Regex("\\[USER_SAID:([^\\]]+)\\]")
        val saidMatch = saidRegex.find(clean)
        if (saidMatch != null) {
            if (extractedUserSaid.isEmpty()) {
                extractedUserSaid = saidMatch.groupValues[1].trim()
            }
            clean = clean.replace(saidMatch.value, "").trim()
        }

        var modeIsDialog = false
        var modeExplicitlyOneShot = false
        val modeRegex = Regex("\\[MODE:([^\\]]+)\\]")
        for (mm in modeRegex.findAll(clean).toList()) {
            val modeVal = mm.groupValues[1].trim().uppercase(Locale.US)
            if (modeVal.contains("DIALOG")) {
                modeIsDialog = true
            } else if (modeVal.contains("ONE_SHOT") || modeVal.contains("SINGLE")) {
                modeExplicitlyOneShot = true
            }
            clean = clean.replace(mm.value, "").trim()
        }

        val cmdRegex = Regex("\\[CMD:([^\\]]+)\\]")
        val matches = cmdRegex.findAll(clean).toList()

        var hasAnyCommand = false
        var explicitStopDialog = false
        val isErrorReply = clean.startsWith("Ошибка ответа Gemini") ||
            clean.startsWith("Не удалось связаться") ||
            clean.startsWith("Лимиты Gemini исчерпаны")

        if (matches.isNotEmpty()) {
            hasAnyCommand = true
            val handler = Handler(Looper.getMainLooper())
            for (m in matches) {
                clean = clean.replace(m.value, "").trim()
                val tagContent = m.groupValues[1]
                val parts = tagContent.split(":", limit = 2)
                val action = parts[0].trim().uppercase(Locale.US)
                val arg = parts.getOrNull(1)?.trim().orEmpty()

                if (action == "STOP_DIALOG") {
                    explicitStopDialog = true
                }
                if (action == "CLEAR_MEMORY") {
                    clearConversationHistory()
                }

                handler.post {
                    when (action) {
                        "SPOTIFY" -> if (arg.isNotEmpty()) {
                            LocalVoiceCommandRouter.launchSpotifyTrackOrArtist(context, arg)
                        }
                        "KICK" -> {
                            val lowerArg = arg.lowercase(Locale.ROOT).trim()
                            val slug = when {
                                lowerArg.contains("kalatay") || lowerArg.contains("калатай") -> "kalatay3"
                                lowerArg.contains("зубар") || lowerArg.contains("zubar") -> "zubarefff"
                                lowerArg.contains("мелстр") || lowerArg.contains("mell") -> "mellstroy"
                                lowerArg.contains("бустер") || lowerArg.contains("buster") -> "buster"
                                lowerArg.contains("плохой") || lowerArg.contains("plohoy") -> "plohoyparen"
                                lowerArg.contains("эвелон") || lowerArg.contains("evelon") -> "evelone192"
                                lowerArg.contains("строго") || lowerArg.contains("strogo") -> "strogo"
                                lowerArg.contains("хесус") || lowerArg.contains("jesus") -> "jesusavgn"
                                else -> arg
                            }
                            handler.postDelayed({
                                LocalVoiceCommandRouter.launchKickStream(context, slug)
                            }, 350L)
                        }
                        "YT" -> if (arg.isNotEmpty()) {
                            handler.postDelayed({
                                LocalVoiceCommandRouter.launchYouTubeSearch(context, arg)
                            }, 350L)
                        }
                        "REMEMBER" -> if (arg.isNotEmpty()) {
                            AiMemoryStore.rememberFact(context, arg)
                        }
                        "FORGET" -> {
                            AiMemoryStore.forgetFact(context, arg)
                        }
                        "MARKET" -> {
                            handler.postDelayed({
                                LocalVoiceCommandRouter.launchPlayStoreSearch(context, arg)
                            }, 300L)
                        }
                        "SEEK" -> if (arg.isNotEmpty()) {
                            LocalVoiceCommandRouter.executeVideoSeek(arg)
                        }
                        "REMIND" -> if (arg.isNotEmpty()) {
                            val sub = arg.split(":", limit = 2)
                            val secs = sub[0].trim().toLongOrNull() ?: 60L
                            val msg = sub.getOrNull(1)?.trim().orEmpty().ifEmpty { "Время напоминания" }
                            ScheduledTaskManager.scheduleVoiceReminder(context, secs, msg)
                        }
                        "REMIND_AT" -> if (arg.isNotEmpty()) {
                            val delimiter = if (arg.contains(";")) ";" else "|"
                            val sub = if (arg.contains(delimiter)) {
                                arg.split(delimiter, limit = 2)
                            } else {
                                // На случай если модель разделила двоеточием после минут "2026-11-08 10:00:позвонить"
                                val lastColon = arg.indexOf(':', startIndex = arg.indexOf(':') + 1)
                                if (lastColon != -1) listOf(arg.substring(0, lastColon), arg.substring(lastColon + 1)) else listOf(arg, "Напоминание")
                            }
                            val dtSpec = sub[0].trim()
                            val msg = sub.getOrNull(1)?.trim().orEmpty().ifEmpty { "Время напоминания" }
                            ScheduledTaskManager.scheduleVoiceReminderAt(context, dtSpec, msg)
                        }
                        "DELAY_CMD" -> if (arg.isNotEmpty()) {
                            val sub = arg.split(":", limit = 2)
                            val secs = sub[0].trim().toLongOrNull() ?: 60L
                            val cmdSpec = sub.getOrNull(1)?.trim().orEmpty()
                            if (cmdSpec.isNotEmpty()) {
                                ScheduledTaskManager.scheduleDelayedCommand(context, secs, cmdSpec)
                            }
                        }
                        "COLOR", "SYS_COLOR" -> if (arg.isNotEmpty()) {
                            LocalVoiceCommandRouter.applyThemeColorEverywhere(context, arg)
                            TuyaSmartHomeController.syncWithLauncherThemeIfNeeded(context, arg)
                        }
                        "LED_ON" -> {
                            TuyaSmartHomeController.setPower(context, true)
                        }
                        "LED_OFF" -> {
                            TuyaSmartHomeController.setPower(context, false)
                        }
                        "LED_COLOR" -> if (arg.isNotEmpty()) {
                            val saidLower = extractedUserSaid.lowercase(Locale.ROOT)
                            val askedForSystemTheme = (saidLower.contains("систем") || saidLower.contains("тем") || saidLower.contains("лаунчер") || saidLower.contains("интерфейс") || saidLower.contains("обводк")) &&
                                !saidLower.contains("лент") && !saidLower.contains("подсветк")
                            if (askedForSystemTheme) {
                                LocalVoiceCommandRouter.applyThemeColorEverywhere(context, arg)
                                TuyaSmartHomeController.syncWithLauncherThemeIfNeeded(context, arg)
                            } else {
                                TuyaSmartHomeController.setHexColor(context, arg)
                            }
                        }
                        "LED_BRIGHT" -> {
                            val pct = arg.toIntOrNull()
                            if (pct != null) {
                                TuyaSmartHomeController.setBrightnessPercent(context, pct)
                            }
                        }
                        "LED_SCENE" -> if (arg.isNotEmpty()) {
                            TuyaSmartHomeController.activateDynamicScene(context, arg)
                        }
                        "LAUNCH" -> if (arg.isNotEmpty()) {
                            MediaStateBus.onMediaAppOpened(arg)
                            AppLauncher(context).launchPackage(arg)
                        }
                        "SETTINGS" -> LocalVoiceCommandRouter.openSystemSettingsAction(context, Settings.ACTION_SETTINGS)
                        "WIFI" -> LocalVoiceCommandRouter.openSystemSettingsAction(context, Settings.ACTION_WIFI_SETTINGS)
                        "BLUETOOTH" -> LocalVoiceCommandRouter.openSystemSettingsAction(context, Settings.ACTION_BLUETOOTH_SETTINGS)
                        "URL" -> if (arg.isNotEmpty()) {
                            LocalVoiceCommandRouter.launchUrlInTvBrowser(context, arg)
                        }
                        "VOL_SET" -> {
                            val pct = arg.toIntOrNull()
                            if (pct != null) {
                                LocalVoiceCommandRouter.setVolumePercent(context, pct)
                            }
                        }
                        "VOL_UP", "VOL_DOWN", "MUTE", "UNMUTE", "PAUSE", "PLAY", "NEXT", "PREV" -> {
                            LocalVoiceCommandRouter.executeSystemAudioCommand(context, action)
                        }
                        "BOOST" -> LocalVoiceCommandRouter.cleanRamBackground(context)
                        "NAV_SOUND" -> {
                            val enable = !arg.uppercase(Locale.US).contains("OFF")
                            NavSoundPlayer.setSoundEnabled(context, enable)
                        }
                        "TTS" -> {
                            val enable = !arg.uppercase(Locale.US).contains("OFF")
                            AssistantVoiceSpeaker.setTtsEnabled(context, enable)
                        }
                        "VOICE" -> if (arg.isNotEmpty()) {
                            AssistantVoiceSpeaker.setVoiceName(context, arg)
                            AssistantVoiceSpeaker.setTtsEnabled(context, true)
                        }
                        "OUTAGE_OPEN" -> {
                            OutageRepository.onOpenScheduleRequested?.invoke()
                        }
                        "OUTAGE_GROUP" -> if (arg.isNotEmpty()) {
                            OutageRepository.setSelectedGroup(context, arg)
                        }
                        "TYPE" -> if (arg.isNotEmpty()) {
                            TvUiControllerBus.typeText(arg)
                        }
                        "CLICK" -> if (arg.isNotEmpty()) {
                            TvUiControllerBus.clickByText(arg)
                        }
                        "NAV" -> if (arg.isNotEmpty()) {
                            TvUiControllerBus.performNav(arg)
                        }
                    }
                }
            }
            val finalClean = clean.removePrefix("✦").trim().ifEmpty { "Готово" }
            if (!isErrorReply) {
                appendTurnToHistory(extractedUserSaid, finalClean)
            }
            val continueAfterCmd = modeIsDialog && !modeExplicitlyOneShot && !explicitStopDialog && !isErrorReply && finalClean.endsWith("?")
            return GeminiTurnResult(
                displayText = finalClean,
                shouldContinueDialog = continueAfterCmd
            )
        }

        if (!isErrorReply) {
            appendTurnToHistory(extractedUserSaid, clean)
        }
        val shouldContinue = (modeIsDialog || (!modeExplicitlyOneShot && clean.endsWith("?"))) && !hasAnyCommand && !explicitStopDialog && !isErrorReply
        return GeminiTurnResult(
            displayText = clean,
            shouldContinueDialog = shouldContinue
        )
    }

    private fun buildOrderedTextModels(context: Context): List<String> {
        val ordered = mutableListOf<String>()
        val cached = cachedModelName
        if (!cached.isNullOrBlank() && !unavailableTextModels.contains(cached)) {
            ordered.add(cached)
        }
        for (m in candidateModels) {
            if (m != cached && !unavailableTextModels.contains(m)) {
                ordered.add(m)
            }
        }
        for (m in getCachedOrDiscoverModelsOncePerDay(context, allowNetwork = false)) {
            if (m !in ordered && !unavailableTextModels.contains(m)) {
                ordered.add(m)
            }
        }
        return ordered
    }

    private fun formatQuotaExhaustedMessage(context: Context): String {
        val waitMs = GeminiKeyPool.nextAvailableInMs(context, GeminiKeyPool.Kind.TEXT) ?: 60_000L
        val waitMin = ((waitMs + 59_999L) / 60_000L).coerceAtLeast(1L)
        return "Лимиты Gemini исчерпаны, попробуйте через $waitMin мин"
    }

    /**
     * Двухуровневый перебор для текстового ответа:
     * - Внешний цикл: ключи из GeminiKeyPool (тип TEXT, не более 3 попыток).
     * - Внутренний цикл: модели (сначала кэшированная из SharedPreferences).
     * - Потоковый режим streamGenerateContent?alt=sse для мгновенного старта первого предложения TTS,
     *   с прозрачным откатом на generateContent.
     * - Общий бюджет времени: 15 секунд.
     */
    private fun executeWithEndpointFallback(
        context: Context,
        contentsArray: JSONArray,
        systemText: String,
        temperature: Double,
        smartFirst: Boolean = false,
        onPartialText: ((String) -> Unit)? = null
    ): String {
        val appCtx = context.applicationContext
        val startElapsedMs = SystemClock.elapsedRealtime()
        turnT0ElapsedMs = startElapsedMs
        logTiming("request_start")
        var firstChunkLogged = false
        val partialSink: (String) -> Unit = { partial ->
            if (!firstChunkLogged) {
                firstChunkLogged = true
                logTiming("first_text_chunk")
            }
            onPartialText?.invoke(partial)
        }

        var orderedModels = buildOrderedTextModels(appCtx).toMutableList()
        if (smartFirst && VOICE_PREFER_SMART_MODEL) {
            val smart = "gemini-3.5-flash"
            if (!unavailableTextModels.contains(smart)) {
                orderedModels.remove(smart)
                orderedModels.add(0, smart)
            }
        }
        if (orderedModels.isEmpty()) {
            unavailableTextModels.clear()
            orderedModels = candidateModels.toMutableList()
        }

        val triedFingerprints = HashSet<String>()
        var lease = GeminiKeyPool.acquire(appCtx, GeminiKeyPool.Kind.TEXT, triedFingerprints)
        if (lease == null) {
            return formatQuotaExhaustedMessage(appCtx)
        }

        var keyAttempts = 1
        var modelIdx = 0
        var sawRateLimit = false
        var firstMeaningfulError = ""
        var lastError = ""
        var triedDailyDiscovery = false

        while (lease != null && modelIdx < orderedModels.size) {
            if (SystemClock.elapsedRealtime() - startElapsedMs >= TEXT_TURN_BUDGET_MS) {
                break
            }
            val currentLease = lease
            val model = orderedModels[modelIdx]
            val bodyStr = buildPayloadForModel(contentsArray, model, temperature, systemText)

            // Сначала потоковый запрос (SSE), при обрыве/таймауте стрима — откат на обычный generateContent
            val res = requestWithStreamFallback(model, currentLease.apiKey, bodyStr, startElapsedMs, partialSink)

            val txt = res.text
            if (res.isSuccess && !txt.isNullOrBlank()) {
                GeminiKeyPool.report(appCtx, currentLease, GeminiKeyPool.Outcome.Ok)
                saveCachedTextModel(appCtx, model)
                logTiming("text_done model=$model key=${currentLease.label} keyAttempts=$keyAttempts")
                return txt
            }

            // 400 из-за thinkingConfig: понижаем только если тело ошибки ЯВНО упоминает thinking.
            // Любая другая 400 (например, плохое аудио) не должна отключать быстрый режим навсегда.
            if (res.httpCode == 400 && res.outcome is GeminiKeyPool.Outcome.ModelError &&
                res.errorBody.contains("thinking", ignoreCase = true)
            ) {
                val prev = thinkingLevelOverride[model]
                val next = if (model.startsWith("gemini-3") && prev == null) "low" else "NONE"
                thinkingLevelOverride[model] = next
                logTiming("thinking_config_rejected model=$model -> $next")
                val retryBody = buildPayloadForModel(contentsArray, model, temperature, systemText)
                val retryRes = trySingleRequest(model, currentLease.apiKey, retryBody, startElapsedMs)
                val retryTxt = retryRes.text
                if (retryRes.isSuccess && !retryTxt.isNullOrBlank()) {
                    partialSink(retryTxt)
                    GeminiKeyPool.report(appCtx, currentLease, GeminiKeyPool.Outcome.Ok)
                    saveCachedTextModel(appCtx, model)
                    return retryTxt
                }
            }

            val outcome = res.outcome ?: GeminiKeyPool.Outcome.NetworkError
            GeminiKeyPool.report(appCtx, currentLease, outcome)

            if (res.errorSummary.isNotBlank()) {
                lastError = res.errorSummary
                if (firstMeaningfulError.isBlank() && res.httpCode != 404) {
                    firstMeaningfulError = res.errorSummary
                }
            }

            when (outcome) {
                is GeminiKeyPool.Outcome.ModelError -> {
                    if (res.httpCode == 404 || res.httpCode == 501) {
                        unavailableTextModels.add(model)
                    }
                    modelIdx++
                    if (modelIdx >= orderedModels.size && !triedDailyDiscovery &&
                        SystemClock.elapsedRealtime() - startElapsedMs < TEXT_TURN_BUDGET_MS - 3_000L
                    ) {
                        triedDailyDiscovery = true
                        for (dm in getCachedOrDiscoverModelsOncePerDay(appCtx, allowNetwork = true, leaseKey = currentLease.apiKey)) {
                            if (dm !in orderedModels && !unavailableTextModels.contains(dm)) {
                                orderedModels.add(dm)
                            }
                        }
                    }
                }

                is GeminiKeyPool.Outcome.RateLimited -> {
                    sawRateLimit = true
                    if (keyAttempts >= MAX_KEY_ATTEMPTS) break
                    triedFingerprints.add(currentLease.fingerprint)
                    lease = GeminiKeyPool.acquire(appCtx, GeminiKeyPool.Kind.TEXT, triedFingerprints)
                    keyAttempts++
                }

                is GeminiKeyPool.Outcome.KeyDead,
                is GeminiKeyPool.Outcome.NetworkError -> {
                    if (keyAttempts >= MAX_KEY_ATTEMPTS) break
                    triedFingerprints.add(currentLease.fingerprint)
                    lease = GeminiKeyPool.acquire(appCtx, GeminiKeyPool.Kind.TEXT, triedFingerprints)
                    keyAttempts++
                }

                else -> modelIdx++
            }
        }

        logTiming("text_failed sawRateLimit=$sawRateLimit lastError=$lastError")
        if (sawRateLimit || GeminiKeyPool.nextAvailableInMs(appCtx, GeminiKeyPool.Kind.TEXT)?.let { it > 0L } == true) {
            return formatQuotaExhaustedMessage(appCtx)
        }

        val finalErr = GeminiKeyPool.sanitize(firstMeaningfulError.ifBlank { lastError })
        return if (finalErr.isNotBlank()) {
            "Ошибка ответа Gemini ($finalErr)"
        } else {
            "Не удалось связаться с Gemini. Проверьте интернет-соединение."
        }
    }

    /**
     * Один запрос к модели: сначала SSE-стрим, а если стрим оборвался/завис/вернул пустоту — тот же запрос обычным
     * generateContent на том же ключе. Модель, на которой стрим сломался, до перезапуска приложения идёт без стрима.
     */
    private fun requestWithStreamFallback(
        model: String,
        apiKey: String,
        body: String,
        turnStartMs: Long,
        sink: (String) -> Unit
    ): HttpResult {
        if (!noStreamTextModels.contains(model)) {
            val s = streamSingleRequestSse(model, apiKey, body, turnStartMs, sink)
            val brokenStream = !s.isSuccess && (s.httpCode == 0 || s.errorSummary == "Empty stream") &&
                s.errorSummary in STREAM_RECOVERABLE_ERRORS
            if (!brokenStream) return s
            if (s.errorSummary == "SocketTimeoutException" || s.errorSummary == "Empty stream") {
                noStreamTextModels.add(model)
            }
            logTiming("stream_failed(${s.errorSummary}) -> fallback generateContent")
            if (SystemClock.elapsedRealtime() - turnStartMs >= TEXT_TURN_BUDGET_MS) return s
        }
        val r = trySingleRequest(model, apiKey, body, turnStartMs)
        val t = r.text
        if (r.isSuccess && !t.isNullOrBlank()) sink(t)
        return r
    }

    private val STREAM_RECOVERABLE_ERRORS = setOf(
        "SocketTimeoutException", "Empty stream", "ProtocolException", "EOFException", "SSLException", "IOException"
    )

    /**
     * Вызывает ListModels не чаще 1 раза в сутки и сохраняет результат в SharedPreferences (п. 3.2).
     */
    private fun getCachedOrDiscoverModelsOncePerDay(
        context: Context,
        allowNetwork: Boolean,
        leaseKey: String? = null
    ): List<String> {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val now = System.currentTimeMillis()
        val lastTs = prefs.getLong(PREF_DISCOVERED_TS, 0L)
        val cachedCsv = prefs.getString(PREF_DISCOVERED_MODELS, "") ?: ""
        val cachedList = cachedCsv.split(",").map { it.trim() }.filter { it.isNotEmpty() && !it.contains("1.5") }

        if (!allowNetwork || (now - lastTs < 24L * 3600_000L && cachedList.isNotEmpty())) {
            return cachedList
        }

        val apiKey = leaseKey ?: GeminiKeyPool.acquire(context, GeminiKeyPool.Kind.TEXT)?.apiKey ?: return cachedList
        val fresh = discoverAvailableModels(apiKey)
        if (fresh.isNotEmpty()) {
            prefs.edit()
                .putString(PREF_DISCOVERED_MODELS, fresh.joinToString(","))
                .putLong(PREF_DISCOVERED_TS, now)
                .apply()
            return fresh
        }
        return cachedList
    }

    private fun discoverAvailableModels(apiKey: String): List<String> {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models")
            val connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 4000
                readTimeout = 5000
                doInput = true
                setRequestProperty("Connection", "keep-alive")
                setRequestProperty("x-goog-api-key", apiKey)
            }
            conn = connection
            if (connection.responseCode !in 200..299) {
                connection.errorStream?.use { it.readBytes() }
                return emptyList()
            }
            val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val root = JSONObject(body)
            val modelsArr = root.optJSONArray("models") ?: return emptyList()
            val flashModels = mutableListOf<String>()
            val otherModels = mutableListOf<String>()
            for (i in 0 until modelsArr.length()) {
                val obj = modelsArr.optJSONObject(i) ?: continue
                val name = obj.optString("name", "").removePrefix("models/").trim()
                if (name.isEmpty() || name.contains("1.5") || name.contains("embedding") || name.contains("imagen") || name.contains("tts") || name.contains("aqa")) continue
                val methods = obj.optJSONArray("supportedGenerationMethods")
                var supportsGenerate = false
                if (methods != null) {
                    for (j in 0 until methods.length()) {
                        if (methods.optString(j) == "generateContent") {
                            supportsGenerate = true
                            break
                        }
                    }
                }
                if (supportsGenerate) {
                    if (name.contains("flash")) {
                        flashModels.add(name)
                    } else if (name.startsWith("gemini")) {
                        otherModels.add(name)
                    }
                }
            }
            flashModels + otherModels
        } catch (_: Exception) {
            try {
                conn?.disconnect()
            } catch (_: Exception) {
            }
            emptyList()
        }
    }

    private data class HttpResult(
        val isSuccess: Boolean,
        val text: String? = null,
        val httpCode: Int = 0,
        val outcome: GeminiKeyPool.Outcome? = null,
        val errorSummary: String = "",
        val errorBody: String = ""
    )

    private fun streamSingleRequestSse(
        model: String,
        apiKey: String,
        jsonBody: String,
        turnStartElapsedMs: Long,
        onPartialText: ((String) -> Unit)?
    ): HttpResult {
        val remainingBudgetMs = (TEXT_TURN_BUDGET_MS - (SystemClock.elapsedRealtime() - turnStartElapsedMs)).coerceIn(2500L, 8000L).toInt()
        var conn: HttpURLConnection? = null
        return try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:streamGenerateContent?alt=sse")
            val connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = minOf(3500, remainingBudgetMs)
                readTimeout = remainingBudgetMs
                doOutput = true
                doInput = true
                useCaches = false
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Accept-Encoding", "identity")
                setRequestProperty("Connection", "keep-alive")
                setRequestProperty("x-goog-api-key", apiKey)
            }
            conn = connection
            connection.outputStream.use { os ->
                os.write(jsonBody.toByteArray(Charsets.UTF_8))
                os.flush()
            }
            val code = connection.responseCode
            if (code in 200..299) {
                val sb = StringBuilder()
                val fallbackSb = StringBuilder()
                connection.inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
                    while (true) {
                        val line = reader.readLine() ?: break
                        if (!line.startsWith("data:")) continue
                        val json = line.substring(5).trim()
                        if (json.isEmpty() || json == "[DONE]") continue
                        val root = try {
                            JSONObject(json)
                        } catch (_: Exception) {
                            continue
                        }
                        val parts = root.optJSONArray("candidates")
                            ?.optJSONObject(0)
                            ?.optJSONObject("content")
                            ?.optJSONArray("parts") ?: continue
                        for (i in 0 until parts.length()) {
                            val partObj = parts.optJSONObject(i) ?: continue
                            val t = partObj.optString("text", "")
                            if (t.isNotEmpty()) {
                                if (partObj.optBoolean("thought", false)) {
                                    fallbackSb.append(t)
                                } else {
                                    sb.append(t)
                                    val cleanSoFar = sb.toString().replace("**", "").replace("*", "")
                                    onPartialText?.invoke(cleanSoFar)
                                }
                            }
                        }
                    }
                }
                val chosen = if (sb.isNotEmpty()) sb.toString() else fallbackSb.toString()
                val finalParsed = chosen.replace("**", "").replace("*", "").trim()
                if (finalParsed.isNotBlank()) {
                    HttpResult(isSuccess = true, text = finalParsed, httpCode = code, outcome = GeminiKeyPool.Outcome.Ok)
                } else {
                    HttpResult(
                        isSuccess = false,
                        httpCode = code,
                        outcome = GeminiKeyPool.Outcome.ModelError,
                        errorSummary = "Empty stream"
                    )
                }
            } else {
                val errBody = try {
                    connection.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                } catch (_: Exception) {
                    ""
                }
                val safeErr = GeminiKeyPool.sanitize(errBody)
                val outcome = GeminiKeyPool.classifyHttpError(code, safeErr)
                HttpResult(
                    isSuccess = false,
                    httpCode = code,
                    outcome = outcome,
                    errorSummary = "HTTP $code",
                    errorBody = safeErr.take(600)
                )
            }
        } catch (e: Exception) {
            try {
                conn?.disconnect()
            } catch (_: Exception) {
            }
            HttpResult(
                isSuccess = false,
                httpCode = 0,
                outcome = GeminiKeyPool.Outcome.NetworkError,
                errorSummary = e.javaClass.simpleName
            )
        }
    }

    private fun trySingleRequest(
        model: String,
        apiKey: String,
        jsonBody: String,
        turnStartElapsedMs: Long
    ): HttpResult {
        var conn: HttpURLConnection? = null
        var reuse = false
        return try {
            val useQueryKey = apiKey.startsWith("AIza")
            val finalUrl = if (useQueryKey) {
                "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=${Uri.encode(apiKey)}"
            } else {
                "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent"
            }
            val connection = (URL(finalUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 4000
                readTimeout = (TEXT_TURN_BUDGET_MS - (SystemClock.elapsedRealtime() - turnStartElapsedMs)).coerceIn(4000L, 9000L).toInt()
                doOutput = true
                doInput = true
                useCaches = false
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                if (!useQueryKey) {
                    setRequestProperty("x-goog-api-key", apiKey)
                }
            }
            conn = connection
            connection.outputStream.use { os ->
                os.write(jsonBody.toByteArray(Charsets.UTF_8))
                os.flush()
            }
            val code = connection.responseCode
            if (code in 200..299) {
                val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                reuse = true
                val parsed = extractTextFromGeminiJson(body)
                if (!parsed.isNullOrBlank()) {
                    HttpResult(isSuccess = true, text = parsed, httpCode = code, outcome = GeminiKeyPool.Outcome.Ok)
                } else {
                    HttpResult(
                        isSuccess = false,
                        httpCode = code,
                        outcome = GeminiKeyPool.Outcome.ModelError,
                        errorSummary = "Empty response"
                    )
                }
            } else {
                val errBody = try {
                    connection.errorStream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
                } catch (_: Exception) {
                    ""
                }
                val safeErr = GeminiKeyPool.sanitize(errBody)
                val outcome = GeminiKeyPool.classifyHttpError(code, safeErr)
                HttpResult(
                    isSuccess = false,
                    httpCode = code,
                    outcome = outcome,
                    errorSummary = "HTTP $code",
                    errorBody = safeErr.take(600)
                )
            }
        } catch (e: Exception) {
            HttpResult(
                isSuccess = false,
                httpCode = 0,
                outcome = GeminiKeyPool.Outcome.NetworkError,
                errorSummary = e.javaClass.simpleName
            )
        } finally {
            // disconnect() закрывает сокет и убивает keep-alive: после успешного ответа соединение оставляем в пуле
            if (!reuse) {
                try {
                    conn?.disconnect()
                } catch (_: Exception) {
                }
            }
        }
    }

    private fun extractTextFromGeminiJson(rawJson: String): String? {
        return try {
            val root = JSONObject(rawJson)
            val candidates = root.optJSONArray("candidates") ?: return null
            if (candidates.length() == 0) return null
            val content = candidates.optJSONObject(0)?.optJSONObject("content") ?: return null
            val parts = content.optJSONArray("parts") ?: return null
            val sb = StringBuilder()
            val fallbackSb = StringBuilder()
            for (i in 0 until parts.length()) {
                val partObj = parts.optJSONObject(i) ?: continue
                val t = partObj.optString("text", "")
                if (t.isNotBlank()) {
                    if (partObj.optBoolean("thought", false)) {
                        if (fallbackSb.isNotEmpty()) fallbackSb.append(" ")
                        fallbackSb.append(t.trim())
                    } else {
                        if (sb.isNotEmpty()) sb.append(" ")
                        sb.append(t.trim())
                    }
                }
            }
            val chosen = if (sb.isNotEmpty()) sb.toString() else fallbackSb.toString()
            chosen.replace("**", "").replace("*", "").trim()
        } catch (_: Exception) {
            null
        }
    }
}
