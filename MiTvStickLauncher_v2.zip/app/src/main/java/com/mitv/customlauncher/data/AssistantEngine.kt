package com.mitv.customlauncher.data

import android.app.ActivityManager
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.view.KeyEvent
import com.mitv.customlauncher.service.DynamicIslandBus
import com.mitv.customlauncher.service.MediaStateBus
import com.mitv.customlauncher.service.NavSoundPlayer
import com.mitv.customlauncher.service.VolumeHudBus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

sealed interface AssistantState {
    data object Idle : AssistantState
    data object Listening : AssistantState
    data object Processing : AssistantState
    data class Result(val text: String) : AssistantState
    data class Error(val code: String) : AssistantState
}

interface AssistantEngine {
    val state: StateFlow<AssistantState>
    fun startSession()
    fun cancelSession()
}

class FakeAssistantEngine(
    private val scope: CoroutineScope,
    private val demoReplyText: String
) : AssistantEngine {
    private val _state = MutableStateFlow<AssistantState>(AssistantState.Idle)
    override val state: StateFlow<AssistantState> = _state.asStateFlow()
    override fun startSession() {}
    override fun cancelSession() {
        _state.value = AssistantState.Idle
    }
}

/**
 * Исполнитель глубоких действий Android TV, вызываемых напрямую ИИ Gemini:
 * - запуск треков и артистов в Spotify (MEDIA_PLAY_FROM_SEARCH + spotify:search + авто-PLAY)
 * - запуск стримов на Kick (kalatay3 и любые другие каналы)
 * - смена цвета лаунчера/ползунка/островка на любой HEX-цвет
 * - управление громкостью, плеером, памятью, приложениями и звуком щелчков пульта
 */
object LocalVoiceCommandRouter {

    data class LocalActionResult(
        val confirmationText: String,
        val isQuickCommand: Boolean = true
    )

    var onThemeColorChanged: ((String) -> Unit)? = null
    var onVolumeChangedCallback: (() -> Unit)? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    /**
     * В v3.8 100% всех голосовых запросов обрабатываются напрямую через Gemini,
     * чтобы идеально понимать украинский, русский, суржик и английский без жёстких шаблонов!
     */
    fun tryExecuteLocalCommand(context: Context, rawText: String): LocalActionResult? {
        return null
    }

    fun executeSystemAudioCommand(context: Context, actionType: String) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val curVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val curPct = ((curVol * 100f) / maxVol).toInt().coerceIn(0, 100)

        when (actionType) {
            "VOL_UP" -> {
                val newPct = (curPct + 15).coerceAtMost(100)
                val targetVol = ((newPct * maxVol) / 100f + 0.5f).toInt().coerceIn((curVol + 1).coerceAtMost(maxVol), maxVol)
                try {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
                } catch (_: Exception) {
                }
                mainHandler.post {
                    onVolumeChangedCallback?.invoke()
                    VolumeHudBus.notifyVolumeChanged()
                }
            }
            "VOL_DOWN" -> {
                val newPct = (curPct - 15).coerceAtLeast(0)
                val targetVol = ((newPct * maxVol) / 100f).toInt().coerceIn(0, (curVol - 1).coerceAtLeast(0))
                try {
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
                } catch (_: Exception) {
                }
                mainHandler.post {
                    onVolumeChangedCallback?.invoke()
                    VolumeHudBus.notifyVolumeChanged()
                }
            }
            "MUTE" -> {
                try {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
                } catch (_: Exception) {
                }
                mainHandler.post {
                    onVolumeChangedCallback?.invoke()
                    VolumeHudBus.notifyVolumeChanged()
                }
            }
            "UNMUTE" -> {
                try {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
                } catch (_: Exception) {
                }
                mainHandler.post {
                    onVolumeChangedCallback?.invoke()
                    VolumeHudBus.notifyVolumeChanged()
                }
            }
            "PAUSE", "PLAY" -> MediaStateBus.dispatchTransportAction("PLAY_PAUSE", am)
            "NEXT" -> MediaStateBus.dispatchTransportAction("NEXT", am)
            "PREV" -> MediaStateBus.dispatchTransportAction("PREV", am)
        }
    }

    fun applyThemeColorEverywhere(context: Context, hex: String) {
        val cleanHex = if (hex.startsWith("#")) hex else "#$hex"
        try {
            android.graphics.Color.parseColor(cleanHex)
        } catch (_: Exception) {
            return
        }
        AppLauncher(context.applicationContext).saveAccentColorHex(cleanHex)
        mainHandler.post {
            onThemeColorChanged?.invoke(cleanHex)
            DynamicIslandBus.notifyAccentColorChanged(cleanHex)
        }
    }

    fun setVolumePercent(context: Context, targetPct: Int) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val clamped = targetPct.coerceIn(0, 100)
        val targetVol = ((clamped * maxVol) / 100f + 0.5f).toInt().coerceIn(0, maxVol)
        try {
            if (clamped > 0) {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
            }
            am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
        } catch (_: Exception) {
        }
        mainHandler.post {
            onVolumeChangedCallback?.invoke()
            VolumeHudBus.notifyVolumeChanged()
        }
    }

    fun launchKickStream(context: Context, channelSlug: String) {
        val cleanSlug = channelSlug.trim().removePrefix("https://kick.com/").removePrefix("kick.com/").trim('/')
        val url = if (cleanSlug.isNotEmpty()) "https://kick.com/$cleanSlug" else "https://kick.com"
        val appLauncher = AppLauncher(context.applicationContext)
        val allApps = appLauncher.getInstalledApps()

        val kickApp = allApps.firstOrNull {
            it.packageName.lowercase().contains("kick") || it.label.lowercase() == "kick"
        }
        if (kickApp != null) {
            try {
                val kickIntent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                    setPackage(kickApp.packageName)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(kickIntent)
                return
            } catch (_: Exception) {
            }
        }

        launchUrlInTvBrowser(context, url)
    }

    fun launchUrlInTvBrowser(context: Context, url: String) {
        val finalUrl = if (url.startsWith("http://") || url.startsWith("https://")) url else "https://$url"
        val uri = Uri.parse(finalUrl)
        val appLauncher = AppLauncher(context.applicationContext)
        val allApps = appLauncher.getInstalledApps()

        val browserCandidate = appLauncher.getBoundAppForSlot(CardSlot.SLOT_2, allApps)
            ?: allApps.firstOrNull {
                val p = it.packageName.lowercase()
                val l = it.label.lowercase()
                p.contains("browser") || p.contains("chrome") || p.contains("tvbro") ||
                    p.contains("puffin") || p.contains("firefox") || p.contains("opera") ||
                    l.contains("браузер") || l.contains("browser")
            }

        if (browserCandidate != null) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                    setPackage(browserCandidate.packageName)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return
            } catch (_: Exception) {
            }
        }

        try {
            val generic = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(generic)
        } catch (_: Exception) {
        }
    }

    fun launchSpotifyTrackOrArtist(context: Context, rawQuery: String) {
        val query = rawQuery.trim()
        if (query.isEmpty()) return
        val appLauncher = AppLauncher(context.applicationContext)
        val allApps = appLauncher.getInstalledApps()
        val spotifyApp = allApps.firstOrNull {
            val p = it.packageName.lowercase()
            p.contains("spotify") || it.label.lowercase().contains("spotify")
        }
        val spotifyPkg = spotifyApp?.packageName

        if (spotifyPkg != null) {
            MediaStateBus.onMediaAppOpened(spotifyPkg)

            try {
                val playIntent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
                    setPackage(spotifyPkg)
                    putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                    putExtra(SearchManager.QUERY, query)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                context.startActivity(playIntent)
                scheduleSpotifyAutoPlayKick(context)
                return
            } catch (_: Exception) {
            }

            try {
                val uriIntent = Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:${Uri.encode(query)}")).apply {
                    setPackage(spotifyPkg)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                context.startActivity(uriIntent)
                scheduleSpotifyAutoPlayKick(context)
                return
            } catch (_: Exception) {
            }

            try {
                val searchIntent = Intent(Intent.ACTION_SEARCH).apply {
                    setPackage(spotifyPkg)
                    putExtra(SearchManager.QUERY, query)
                    putExtra("query", query)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                context.startActivity(searchIntent)
                scheduleSpotifyAutoPlayKick(context)
                return
            } catch (_: Exception) {
            }

            appLauncher.launchPackage(spotifyPkg)
            scheduleSpotifyAutoPlayKick(context)
            return
        }

        launchYouTubeSearch(context, query)
    }

    private fun scheduleSpotifyAutoPlayKick(context: Context) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        mainHandler.postDelayed({
            try {
                val now = SystemClock.uptimeMillis()
                val down = KeyEvent(now, now, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY, 0)
                val up = KeyEvent(now, now, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY, 0)
                am.dispatchMediaKeyEvent(down)
                am.dispatchMediaKeyEvent(up)
            } catch (_: Exception) {
            }
        }, 2000L)
    }

    fun launchYouTubeSearch(context: Context, query: String) {
        val appLauncher = AppLauncher(context.applicationContext)
        val apps = appLauncher.getInstalledApps()
        val ytApp = apps.firstOrNull {
            val p = it.packageName.lowercase()
            p.contains("youtube.tv") || p.contains("smarttube") || p.contains("youtube")
        }
        try {
            val searchIntent = Intent(Intent.ACTION_SEARCH).apply {
                if (ytApp != null) setPackage(ytApp.packageName)
                putExtra(SearchManager.QUERY, query)
                putExtra("query", query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(searchIntent)
            return
        } catch (_: Exception) {
        }
        try {
            val webUri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query))
            val viewIntent = Intent(Intent.ACTION_VIEW, webUri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(viewIntent)
        } catch (_: Exception) {
        }
    }

    fun openSystemSettingsAction(context: Context, action: String) {
        try {
            val intent = Intent(action).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            try {
                val fallback = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(fallback)
            } catch (_: Exception) {
            }
        }
    }

    fun cleanRamBackground(context: Context) {
        try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return
            val apps = AppLauncher(context.applicationContext).getInstalledApps()
            for (app in apps) {
                val p = app.packageName.lowercase()
                if (app.packageName != context.packageName &&
                    !p.contains("spotify") &&
                    !p.contains("mediashell") &&
                    !p.contains("soundcloud")
                ) {
                    am.killBackgroundProcesses(app.packageName)
                }
            }
        } catch (_: Exception) {
        }
    }
}

/**
 * 100% Gemini-ассистент (2.5 & 3.8):
 * - Слушает живой голос напрямую в формате WAV (идеально понимает украинский, русский, суржик и английский!)
 * - Использует рабочий ключ XOR_PROTECTED_KEY (без ошибки 401!)
 * - Сам управляет Spotify, Kick, YouTube, цветами лаунчера, приложениями и звуком ТВ
 */
object GeminiCloudClient {

    private val candidateModels = listOf(
        "gemini-2.5-flash",
        "gemini-2.5-flash-lite",
        "gemini-2.0-flash",
        "gemini-2.0-flash-lite",
        "gemini-flash-latest",
        "gemini-1.5-flash"
    )

    @Volatile
    private var cachedModelName: String? = null

    @Volatile
    private var cachedUseHeaderAuth: Boolean = false

    private fun buildCommandInstruction(context: Context): String {
        val appCtx = context.applicationContext
        val apps = AppLauncher(appCtx).getInstalledApps().take(30)
            .joinToString(", ") { "${it.label} (${it.packageName})" }
        val outageInfo = OutageRepository.getSummaryForAi(appCtx)
        return "Ты — главный голосовой ИИ-ассистент Gemini в кастомном лаунчере Android TV (Xiaomi Mi TV Stick). " +
            "Актуальные данные по графику отключений света пользователя ($outageInfo). Если пользователь спрашивает про свет/отключения/график ДТЭК — дай точный ответ по этим данным! " +
            "Ты идеально понимаешь украинский, русский, суржик и английский языки. Отвечай на том же языке, на котором обратился пользователь, максимально кратко и по делу (1–3 предложения, без звёздочек и без разметки Markdown). " +
            "ВАЖНО: Если пользователь просит выполнить действие на приставке, ОБЯЗАТЕЛЬНО поставь в самом начале ответа тег команды:\n" +
            "- Включить песню, трек, альбом или исполнителя в Spotify: [CMD:SPOTIFY:Точное имя артиста и трека] (всегда переводи голосовой транслит в правильное название, например «уикенд старбой» -> [CMD:SPOTIFY:The Weeknd Starboy])\n" +
            "- Запустить стрим на Kick: [CMD:KICK:channel_slug] (для стримера Калатай / Kalatay всегда используй [CMD:KICK:kalatay3])\n" +
            "- Найти или включить видео на YouTube: [CMD:YT:поисковый запрос]\n" +
            "- Изменить цвет темы лаунчера, обводки или ползунка громкости: [CMD:COLOR:#RRGGBB] (подбери красивый яркий HEX под любой названный цвет: например красный #EF4444, розовый/малиновый #EC4899, фиолетовый/аметист #A78BFA, зелёный/изумрудный #34D399, синий/сапфир #60A5FA, голубой/бирюзовый #00F0FF, жёлтый/золотой/янтарный #F59E0B, оранжевый #F97316, белый/серебро #E2E8F0)\n" +
            "- Открыть установленное приложение: [CMD:LAUNCH:package_name] (список установленных приложений: $apps)\n" +
            "- Открыть системные настройки ТВ: [CMD:SETTINGS], настройки Wi-Fi: [CMD:WIFI], настройки Bluetooth: [CMD:BLUETOOTH]\n" +
            "- Открыть сайт в браузере: [CMD:URL:https://адрес]\n" +
            "- Громкость в процентах: [CMD:VOL_SET:0..100], сделать громче: [CMD:VOL_UP], тише: [CMD:VOL_DOWN], выключить звук: [CMD:MUTE], включить звук: [CMD:UNMUTE]\n" +
            "- Управление плеером: [CMD:PAUSE], [CMD:PLAY], [CMD:NEXT], [CMD:PREV]\n" +
            "- Очистить оперативную память / ускорить приставку: [CMD:BOOST]\n" +
            "- Выключить или включить звук щелчков пульта в лаунчере: [CMD:NAV_SOUND:OFF] или [CMD:NAV_SOUND:ON]\n" +
            "- Показать на экране окно графика отключений света: [CMD:OUTAGE_OPEN]\n" +
            "- Изменить очередь (группу) отключений света ДТЭК (от 1.1 до 6.2): [CMD:OUTAGE_GROUP:номер_очереди]\n" +
            "После тега напиши короткое подтверждение (например: «[CMD:COLOR:#A78BFA] Колір теми змінено на фіолетовий»). Если пользователь просто задал вопрос или общается — дай умный краткий ответ без тегов."
    }

    private fun buildPayloadForModel(contentsArray: JSONArray, modelName: String, temperature: Double): String {
        val genConfig = JSONObject().apply {
            put("maxOutputTokens", 2048)
            put("temperature", temperature)
            if (modelName.startsWith("gemini-2.5-flash")) {
                put("thinkingConfig", JSONObject().apply {
                    put("thinkingBudget", 0)
                })
            }
        }
        return JSONObject().apply {
            put("contents", contentsArray)
            put("generationConfig", genConfig)
        }.toString()
    }

    suspend fun askGeminiText(context: Context, userQuery: String): String = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext
        try {
            OutageRepository.refreshIfNeeded(appCtx, force = false)
        } catch (_: Exception) {
        }
        val fullPrompt = "${buildCommandInstruction(appCtx)}\n\nЗапрос пользователя: $userQuery"

        val contentsArray = JSONArray().put(
            JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", fullPrompt)))
            }
        )

        val rawReply = executeWithEndpointFallback(contentsArray, temperature = 0.35)
        processCommandTags(appCtx, rawReply)
    }

    suspend fun askGeminiAudio(context: Context, wavBytes: ByteArray): String = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext
        try {
            OutageRepository.refreshIfNeeded(appCtx, force = false)
        } catch (_: Exception) {
        }
        val audioPrompt = buildCommandInstruction(appCtx) +
            "\n\nПрослушай голосовую команду пользователя (она может быть на украинском, русском, суржике или английском языке). " +
            "Если на записи полная тишина и совсем нет речи — ответь ровно одним словом: [SILENCE]."

        val b64Audio = Base64.encodeToString(wavBytes, Base64.NO_WRAP)
        val partsArray = JSONArray()
            .put(JSONObject().put("text", audioPrompt))
            .put(JSONObject().put("inlineData", JSONObject().apply {
                put("mimeType", "audio/wav")
                put("data", b64Audio)
            }))

        val contentsArray = JSONArray().put(
            JSONObject().apply {
                put("role", "user")
                put("parts", partsArray)
            }
        )

        val rawReply = executeWithEndpointFallback(contentsArray, temperature = 0.3)
        if (rawReply.contains("[SILENCE]")) {
            return@withContext "✦ Не расслышал речь. Скажите запрос в микрофон пульта."
        }
        processCommandTags(appCtx, rawReply)
    }

    private fun processCommandTags(context: Context, reply: String): String {
        var clean = reply.trim()
        val cmdRegex = Regex("\\[CMD:([^\\]]+)\\]")
        val matches = cmdRegex.findAll(clean).toList()

        if (matches.isNotEmpty()) {
            val handler = Handler(Looper.getMainLooper())
            for (m in matches) {
                clean = clean.replace(m.value, "").trim()
                val tagContent = m.groupValues[1]
                val parts = tagContent.split(":", limit = 2)
                val action = parts[0].trim().uppercase(Locale.US)
                val arg = parts.getOrNull(1)?.trim().orEmpty()

                handler.post {
                    when (action) {
                        "SPOTIFY" -> if (arg.isNotEmpty()) {
                            LocalVoiceCommandRouter.launchSpotifyTrackOrArtist(context, arg)
                        }
                        "KICK" -> {
                            val slug = if (arg.lowercase().contains("kalatay") || arg.lowercase().contains("калатай")) {
                                "kalatay3"
                            } else {
                                arg
                            }
                            LocalVoiceCommandRouter.launchKickStream(context, slug)
                        }
                        "YT" -> if (arg.isNotEmpty()) {
                            LocalVoiceCommandRouter.launchYouTubeSearch(context, arg)
                        }
                        "COLOR" -> if (arg.isNotEmpty()) {
                            LocalVoiceCommandRouter.applyThemeColorEverywhere(context, arg)
                        }
                        "LAUNCH" -> if (arg.isNotEmpty()) {
                            MediaStateBus.onMediaAppOpened(arg)
                            AppLauncher(context).launchPackage(arg)
                        }
                        "SETTINGS" -> LocalVoiceCommandRouter.openSystemSettingsAction(context, Settings.ACTION_SETTINGS)
                        "WIFI" -> LocalVoiceCommandRouter.openSystemSettingsAction(context, Settings.ACTION_WIFI_SETTINGS)
                        "BLUETOOTH" -> LocalVoiceCommandRouter.openSystemSettingsAction(context, Settings.ACTION_BLUETOOTH_SETTINGS)
                        "URL" -> if (arg.isNotEmpty()) {
                            LocalVoiceCommandRouter.launchUrlInTvBrowser(context, arg)
                        }
                        "VOL_SET" -> {
                            val pct = arg.toIntOrNull()
                            if (pct != null) {
                                LocalVoiceCommandRouter.setVolumePercent(context, pct)
                            }
                        }
                        "VOL_UP", "VOL_DOWN", "MUTE", "UNMUTE", "PAUSE", "PLAY", "NEXT", "PREV" -> {
                            LocalVoiceCommandRouter.executeSystemAudioCommand(context, action)
                        }
                        "BOOST" -> LocalVoiceCommandRouter.cleanRamBackground(context)
                        "NAV_SOUND" -> {
                            val enable = !arg.uppercase(Locale.US).contains("OFF")
                            NavSoundPlayer.setSoundEnabled(context, enable)
                        }
                        "OUTAGE_OPEN" -> {
                            OutageRepository.onOpenScheduleRequested?.invoke()
                        }
                        "OUTAGE_GROUP" -> if (arg.isNotEmpty()) {
                            OutageRepository.setSelectedGroup(context, arg)
                        }
                    }
                }
            }
            return "✦ " + clean.removePrefix("✦").trim().ifEmpty { "Готово" }
        }

        return clean
    }

    private fun executeWithEndpointFallback(contentsArray: JSONArray, temperature: Double): String {
        val primaryKey = LauncherConfig.DEFAULT_GEMINI_API_KEY
        val endpointTemplate = "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent"

        // 0. Если уже есть проверенная рабочая модель — пробуем её первой
        val cModel = cachedModelName
        if (cModel != null) {
            val urlStr = String.format(Locale.US, endpointTemplate, cModel)
            val bodyStr = buildPayloadForModel(contentsArray, cModel, temperature)
            val res = trySingleRequest(urlStr, primaryKey, cachedUseHeaderAuth, bodyStr)
            val cachedTxt = res.text
            if (res.isSuccess && !cachedTxt.isNullOrBlank()) {
                return cachedTxt
            }
        }

        var firstMeaningfulError = ""
        var lastError = ""

        // 1. Пробуем реальные модели Google AI Studio (v1beta)
        for (model in candidateModels) {
            val urlStr = String.format(Locale.US, endpointTemplate, model)
            val bodyStr = buildPayloadForModel(contentsArray, model, temperature)
            val res = trySingleRequest(urlStr, primaryKey, useHeaderAuth = false, jsonBody = bodyStr)
            val txt = res.text
            if (res.isSuccess && !txt.isNullOrBlank()) {
                cachedModelName = model
                cachedUseHeaderAuth = false
                return txt
            }
            // Если модель не приняла thinkingConfig (например HTTP 400), пробуем без thinkingConfig
            if (res.errorSummary == "HTTP 400" && model.startsWith("gemini-2.5-flash")) {
                val plainBody = buildPayloadForModel(contentsArray, "gemini-2.0-flash", temperature)
                val retryRes = trySingleRequest(urlStr, primaryKey, useHeaderAuth = false, jsonBody = plainBody)
                val retryTxt = retryRes.text
                if (retryRes.isSuccess && !retryTxt.isNullOrBlank()) {
                    cachedModelName = model
                    cachedUseHeaderAuth = false
                    return retryTxt
                }
            }
            if (res.errorSummary.isNotBlank()) {
                lastError = res.errorSummary
                if (firstMeaningfulError.isBlank() && res.errorSummary != "HTTP 404") {
                    firstMeaningfulError = res.errorSummary
                }
            }
        }

        // 2. Авто-обнаружение доступных моделей через GET /v1beta/models?key=... (если вдруг все имена вернули 404)
        val discoveredModels = discoverAvailableModels(primaryKey)
        for (model in discoveredModels) {
            if (model in candidateModels) continue
            val urlStr = String.format(Locale.US, endpointTemplate, model)
            val bodyStr = buildPayloadForModel(contentsArray, "gemini-2.0-flash", temperature)
            val res = trySingleRequest(urlStr, primaryKey, useHeaderAuth = false, jsonBody = bodyStr)
            val txt = res.text
            if (res.isSuccess && !txt.isNullOrBlank()) {
                cachedModelName = model
                cachedUseHeaderAuth = false
                return txt
            } else if (res.errorSummary.isNotBlank() && firstMeaningfulError.isBlank() && res.errorSummary != "HTTP 404") {
                firstMeaningfulError = res.errorSummary
            }
        }

        val finalErr = firstMeaningfulError.ifBlank { lastError }
        return if (finalErr.isNotBlank()) {
            "Ошибка ответа Gemini ($finalErr)"
        } else {
            "Не удалось связаться с Gemini. Проверьте интернет-соединение."
        }
    }

    private fun discoverAvailableModels(apiKey: String): List<String> {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models?key=${Uri.encode(apiKey)}")
            val connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 5000
                readTimeout = 7000
                doInput = true
            }
            conn = connection
            if (connection.responseCode !in 200..299) return emptyList()
            val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val root = JSONObject(body)
            val modelsArr = root.optJSONArray("models") ?: return emptyList()
            val flashModels = mutableListOf<String>()
            val otherModels = mutableListOf<String>()
            for (i in 0 until modelsArr.length()) {
                val obj = modelsArr.optJSONObject(i) ?: continue
                val name = obj.optString("name", "").removePrefix("models/").trim()
                if (name.isEmpty() || name.contains("embedding") || name.contains("imagen") || name.contains("tts") || name.contains("aqa")) continue
                val methods = obj.optJSONArray("supportedGenerationMethods")
                var supportsGenerate = false
                if (methods != null) {
                    for (j in 0 until methods.length()) {
                        if (methods.optString(j) == "generateContent") {
                            supportsGenerate = true
                            break
                        }
                    }
                }
                if (supportsGenerate) {
                    if (name.contains("flash")) {
                        flashModels.add(name)
                    } else if (name.startsWith("gemini")) {
                        otherModels.add(name)
                    }
                }
            }
            flashModels + otherModels
        } catch (_: Exception) {
            emptyList()
        } finally {
            try {
                conn?.disconnect()
            } catch (_: Exception) {
            }
        }
    }

    private data class HttpResult(
        val isSuccess: Boolean,
        val text: String? = null,
        val errorSummary: String = ""
    )

    private fun trySingleRequest(
        baseUrl: String,
        apiKey: String,
        useHeaderAuth: Boolean,
        jsonBody: String
    ): HttpResult {
        var conn: HttpURLConnection? = null
        return try {
            val finalUrl = if (useHeaderAuth) {
                baseUrl
            } else {
                "$baseUrl?key=${Uri.encode(apiKey)}"
            }
            val connection = (URL(finalUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 7000
                readTimeout = 14000
                doOutput = true
                doInput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                if (useHeaderAuth) {
                    setRequestProperty("x-goog-api-key", apiKey)
                }
            }
            conn = connection
            connection.outputStream.use { os ->
                os.write(jsonBody.toByteArray(Charsets.UTF_8))
            }
            val code = connection.responseCode
            if (code in 200..299) {
                val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val parsed = extractTextFromGeminiJson(body)
                if (!parsed.isNullOrBlank()) {
                    HttpResult(isSuccess = true, text = parsed)
                } else {
                    HttpResult(isSuccess = false, errorSummary = "Empty response")
                }
            } else {
                HttpResult(isSuccess = false, errorSummary = "HTTP $code")
            }
        } catch (e: Exception) {
            HttpResult(isSuccess = false, errorSummary = e.javaClass.simpleName)
        } finally {
            try {
                conn?.disconnect()
            } catch (_: Exception) {
            }
        }
    }

    private fun extractTextFromGeminiJson(rawJson: String): String? {
        return try {
            val root = JSONObject(rawJson)
            val candidates = root.optJSONArray("candidates") ?: return null
            if (candidates.length() == 0) return null
            val content = candidates.optJSONObject(0)?.optJSONObject("content") ?: return null
            val parts = content.optJSONArray("parts") ?: return null
            val sb = StringBuilder()
            val fallbackSb = StringBuilder()
            for (i in 0 until parts.length()) {
                val partObj = parts.optJSONObject(i) ?: continue
                val t = partObj.optString("text", "")
                if (t.isNotBlank()) {
                    if (partObj.optBoolean("thought", false)) {
                        if (fallbackSb.isNotEmpty()) fallbackSb.append(" ")
                        fallbackSb.append(t.trim())
                    } else {
                        if (sb.isNotEmpty()) sb.append(" ")
                        sb.append(t.trim())
                    }
                }
            }
            val chosen = if (sb.isNotEmpty()) sb.toString() else fallbackSb.toString()
            chosen.replace("**", "").replace("*", "").trim()
        } catch (_: Exception) {
            null
        }
    }
}
