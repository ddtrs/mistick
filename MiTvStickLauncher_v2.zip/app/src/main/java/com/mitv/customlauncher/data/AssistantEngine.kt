package com.mitv.customlauncher.data

import android.app.ActivityManager
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.Base64
import com.mitv.customlauncher.service.MediaStateBus
import com.mitv.customlauncher.service.VolumeHudBus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed interface AssistantState {
    data object Idle : AssistantState
    data object Listening : AssistantState
    data object Processing : AssistantState
    data class Result(val text: String) : AssistantState
    data class Error(val code: String) : AssistantState
}

interface AssistantEngine {
    val state: StateFlow<AssistantState>
    fun startSession()
    fun cancelSession()
}

class FakeAssistantEngine(
    private val scope: CoroutineScope,
    private val demoReplyText: String
) : AssistantEngine {
    private val _state = MutableStateFlow<AssistantState>(AssistantState.Idle)
    override val state: StateFlow<AssistantState> = _state.asStateFlow()
    override fun startSession() {}
    override fun cancelSession() {
        _state.value = AssistantState.Idle
    }
}

/**
 * Локальный 0-токенный маршрутизатор голосовых команд:
 * Мгновенно (за 0.05 сек) и БЕСПЛАТНО (0 токенов Gemini!) выполняет базовые команды управления ТВ:
 * - запуск любых установленных приложений (YouTube, Spotify, Браузер, Настройки и т.д.)
 * - поиск видео на YouTube («найди на ютубе ...»)
 * - управление громкостью («громче», «тише», «добавь звук», «громкость 35%», «выключи звук»)
 * - управление плеером («пауза», «продолжи», «следующий трек», «предыдущий трек»)
 * - очистка ОЗУ («очисти память», «ускорь»)
 * - смена цвета темы («поменяй цвет на изумрудный / фиолетовый / синий / янтарный / голубой / серебро»)
 * - текущее время и дата
 */
object LocalVoiceCommandRouter {

    data class LocalActionResult(
        val confirmationText: String,
        val isQuickCommand: Boolean = true
    )

    var onThemeColorChanged: ((String) -> Unit)? = null
    var onVolumeChangedCallback: (() -> Unit)? = null

    fun tryExecuteLocalCommand(context: Context, rawText: String): LocalActionResult? {
        val text = rawText.trim()
        if (text.isEmpty()) return null
        val lower = text.lowercase(Locale.getDefault())

        // 1. Поиск на YouTube («найди на ютубе ...», «включи на ютубе ...», «поищи в youtube ...»)
        val ytPrefixes = listOf(
            "найди на ютубе ", "найди в ютубе ", "найди на youtube ", "найди в youtube ",
            "поищи на ютубе ", "поищи в ютубе ", "включи на ютубе ", "открой на ютубе ",
            "ютуб поиск ", "youtube "
        )
        for (prefix in ytPrefixes) {
            if (lower.startsWith(prefix)) {
                val query = text.substring(prefix.length).trim()
                if (query.isNotEmpty()) {
                    launchYouTubeSearch(context, query)
                    return LocalActionResult("✦ YouTube поиск: «$query»")
                }
            }
        }

        // 2. Управление громкостью и звуком (0 токенов!)
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        if (am != null) {
            val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            val curVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            val curPct = ((curVol * 100f) / maxVol).toInt().coerceIn(0, 100)

            // Точный процент громкости: «громкость 40», «звук на 30 процентов», «сделай громкость 50»
            if (lower.contains("громкост") || lower.contains("звук")) {
                val numMatch = Regex("(\\d{1,3})").find(lower)
                if (numMatch != null) {
                    val targetPct = numMatch.groupValues[1].toIntOrNull()?.coerceIn(0, 100)
                    if (targetPct != null) {
                        val targetVol = ((targetPct * maxVol) / 100f + 0.5f).toInt().coerceIn(0, maxVol)
                        try {
                            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
                            am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
                        } catch (_: Exception) {
                        }
                        onVolumeChangedCallback?.invoke()
                        VolumeHudBus.notifyVolumeChanged()
                        return LocalActionResult("✦ Громкость установлена на $targetPct%")
                    }
                }
            }

            if (lower == "выключи звук" || lower == "без звука" || lower == "мут" || lower == "убери звук" || lower == "тишина") {
                try {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
                } catch (_: Exception) {
                }
                onVolumeChangedCallback?.invoke()
                VolumeHudBus.notifyVolumeChanged()
                return LocalActionResult("✦ Звук выключен (Mute)")
            }

            if (lower == "включи звук" || lower == "верни звук" || lower == "размуть") {
                try {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
                } catch (_: Exception) {
                }
                onVolumeChangedCallback?.invoke()
                VolumeHudBus.notifyVolumeChanged()
                return LocalActionResult("✦ Звук включён")
            }

            if (lower == "громче" || lower == "сделай громче" || lower == "добавь звук" ||
                lower == "добавь звука" || lower == "прибавь звук" || lower == "прибавь громкость" ||
                lower == "увеличь громкость" || lower == "звук больше" || lower == "погромче"
            ) {
                val newPct = (curPct + 15).coerceAtMost(100)
                val targetVol = ((newPct * maxVol) / 100f + 0.5f).toInt().coerceIn((curVol + 1).coerceAtMost(maxVol), maxVol)
                try {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
                } catch (_: Exception) {
                }
                val updatedPct = ((am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100f) / maxVol).toInt().coerceIn(0, 100)
                onVolumeChangedCallback?.invoke()
                VolumeHudBus.notifyVolumeChanged()
                return LocalActionResult("✦ Громкость: $updatedPct%")
            }

            if (lower == "тише" || lower == "сделай тише" || lower == "убавь звук" ||
                lower == "убавь громкость" || lower == "уменьши громкость" || lower == "звук меньше" || lower == "потише"
            ) {
                val newPct = (curPct - 15).coerceAtLeast(0)
                val targetVol = ((newPct * maxVol) / 100f).toInt().coerceIn(0, (curVol - 1).coerceAtLeast(0))
                try {
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
                } catch (_: Exception) {
                }
                val updatedPct = ((am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100f) / maxVol).toInt().coerceIn(0, 100)
                onVolumeChangedCallback?.invoke()
                VolumeHudBus.notifyVolumeChanged()
                return LocalActionResult("✦ Громкость: $updatedPct%")
            }

            // 3. Управление медиа-плеером (0 токенов!)
            if (lower == "пауза" || lower == "поставь на паузу" || lower == "останови музыку" || lower == "стоп") {
                MediaStateBus.dispatchTransportAction("PLAY_PAUSE", am)
                return LocalActionResult("✦ Пауза")
            }
            if (lower == "продолжи" || lower == "включи музыку" || lower == "играй" || lower == "воспроизведение") {
                MediaStateBus.dispatchTransportAction("PLAY_PAUSE", am)
                return LocalActionResult("✦ Воспроизведение")
            }
            if (lower == "следующий трек" || lower == "следующая песня" || lower == "дальше" || lower == "переключи трек") {
                MediaStateBus.dispatchTransportAction("NEXT", am)
                return LocalActionResult("✦ Следующий трек")
            }
            if (lower == "предыдущий трек" || lower == "предыдущая песня" || lower == "прошлый трек") {
                MediaStateBus.dispatchTransportAction("PREV", am)
                return LocalActionResult("✦ Предыдущий трек")
            }
        }

        // 4. Очистка ОЗУ (0 токенов!)
        if (lower.contains("очисти память") || lower.contains("очисти оператив") ||
            lower.contains("ускорь приставк") || lower.contains("освободи память") || lower == "ускорение"
        ) {
            cleanRamBackground(context)
            return LocalActionResult("✦ Фоновые процессы закрыты · ОЗУ очищено")
        }

        // 5. Смена акцентного цвета лаунчера голосом (0 токенов!)
        if (lower.contains("цвет") || lower.contains("тему") || lower.contains("обводк")) {
            val matchedColor: Pair<String, String>? = when {
                lower.contains("изумруд") || lower.contains("зелен") || lower.contains("зелён") -> "#34D399" to "Изумрудный"
                lower.contains("янтар") || lower.contains("желт") || lower.contains("жёлт") || lower.contains("оранж") || lower.contains("золот") -> "#F59E0B" to "Янтарный"
                lower.contains("сапфир") || lower.contains("синий") || lower.contains("синюю") -> "#60A5FA" to "Сапфир"
                lower.contains("аметист") || lower.contains("фиолет") || lower.contains("сиренев") || lower.contains("розов") -> "#A78BFA" to "Аметист"
                lower.contains("серебр") || lower.contains("белый") || lower.contains("белую") -> "#E2E8F0" to "Серебро"
                lower.contains("неон") || lower.contains("голуб") || lower.contains("бирюз") || lower.contains("стандарт") -> "#00F0FF" to "Неон"
                else -> null
            }
            if (matchedColor != null) {
                val (hex, name) = matchedColor
                AppLauncher(context.applicationContext).saveAccentColorHex(hex)
                onThemeColorChanged?.invoke(hex)
                return LocalActionResult("✦ Цвет темы изменён: $name")
            }
        }

        // 6. Текущее время / дата (0 токенов!)
        if (lower == "сколько времени" || lower == "который час" || lower == "время" || lower == "какое сегодня число") {
            val fmt = SimpleDateFormat("HH:mm · EEEE, d MMMM", Locale("ru"))
            return LocalActionResult("✦ Сейчас ${fmt.format(Date())}")
        }

        // 7. Открытие системных настроек / Wi-Fi / Bluetooth
        val launchPrefixes = listOf(
            "открой ", "включи ", "запусти ", "перейди в ", "зайди в ", "покажи "
        )
        val hasLaunchVerb = launchPrefixes.any { lower.startsWith(it) }
        val targetPhrase = launchPrefixes.firstOrNull { lower.startsWith(it) }
            ?.let { lower.removePrefix(it).trim() }
            ?: lower

        if (hasLaunchVerb || lower == "настройки" || lower == "вайфай" || lower == "блютуз") {
            if (targetPhrase.contains("вайфай") || targetPhrase.contains("вай-фай") || targetPhrase.contains("wi-fi") || targetPhrase.contains("wifi")) {
                openSystemSettingsAction(context, Settings.ACTION_WIFI_SETTINGS)
                return LocalActionResult("✦ Открываю настройки Wi-Fi")
            }
            if (targetPhrase.contains("блютуз") || targetPhrase.contains("bluetooth")) {
                openSystemSettingsAction(context, Settings.ACTION_BLUETOOTH_SETTINGS)
                return LocalActionResult("✦ Открываю настройки Bluetooth")
            }
            if (targetPhrase == "настройки" || targetPhrase == "системные настройки" || targetPhrase == "настройки тв") {
                openSystemSettingsAction(context, Settings.ACTION_SETTINGS)
                return LocalActionResult("✦ Открываю настройки Android TV")
            }
        }

        // 8. Поиск и запуск любого установленного приложения (по русскому/английскому названию или синониму)
        if (hasLaunchVerb || targetPhrase.split(" ").size <= 2) {
            val appLauncher = AppLauncher(context.applicationContext)
            val installed = appLauncher.getInstalledApps()
            val matchedApp = matchInstalledAppByVoice(targetPhrase, installed, strictIfNoVerb = !hasLaunchVerb)
            if (matchedApp != null) {
                MediaStateBus.onMediaAppOpened(matchedApp.packageName)
                appLauncher.launchPackage(matchedApp.packageName)
                return LocalActionResult("✦ Открываю ${matchedApp.label}")
            }
        }

        return null
    }

    private fun matchInstalledAppByVoice(
        phrase: String,
        apps: List<InstalledAppInfo>,
        strictIfNoVerb: Boolean
    ): InstalledAppInfo? {
        val clean = phrase.lowercase(Locale.getDefault()).trim()
        if (clean.length < 2) return null

        for (app in apps) {
            val labelLower = app.label.lowercase(Locale.getDefault())
            if (labelLower == clean || (!strictIfNoVerb && (labelLower.contains(clean) || clean.contains(labelLower)))) {
                return app
            }
        }

        val synonymKeywords: List<String>? = when {
            clean.contains("ютуб") || clean.contains("ютьюб") || clean.contains("youtube") ->
                listOf("youtube", "smarttube")
            clean.contains("спотифай") || clean.contains("спотик") || clean.contains("spotify") ->
                listOf("spotify")
            clean.contains("браузер") || clean.contains("интернет") || clean.contains("хром") || clean.contains("browser") ->
                listOf("browser", "chrome", "puffin", "tvbro", "firefox", "opera")
            clean.contains("трансляц") || clean.contains("каст") || clean.contains("airscreen") || clean.contains("cast") ->
                listOf("airscreen", "cast", "mediashell", "miracast")
            clean.contains("ламп") || clean.contains("lampa") ->
                listOf("lampa")
            clean.contains("смарттуб") || clean.contains("smarttube") ->
                listOf("smarttube")
            clean.contains("саундклауд") || clean.contains("soundcloud") ->
                listOf("soundcloud")
            clean.contains("влц") || clean.contains("vlc") ->
                listOf("vlc")
            clean.contains("коди") || clean.contains("kodi") ->
                listOf("kodi")
            clean.contains("нетфликс") || clean.contains("netflix") ->
                listOf("netflix")
            clean.contains("прайм") || clean.contains("prime") ->
                listOf("prime", "amazon")
            clean.contains("проводник") || clean.contains("файлы") || clean.contains("флешк") ->
                listOf("file", "explorer", "manager", "total", "xplore", "fx")
            else -> null
        }

        if (synonymKeywords != null) {
            for (kw in synonymKeywords) {
                val found = apps.firstOrNull {
                    it.packageName.lowercase().contains(kw) || it.label.lowercase().contains(kw)
                }
                if (found != null) return found
            }
        }

        return null
    }

    fun launchYouTubeSearch(context: Context, query: String) {
        val appLauncher = AppLauncher(context.applicationContext)
        val apps = appLauncher.getInstalledApps()
        val ytApp = apps.firstOrNull {
            val p = it.packageName.lowercase()
            p.contains("youtube.tv") || p.contains("smarttube") || p.contains("youtube")
        }
        try {
            val searchIntent = Intent(Intent.ACTION_SEARCH).apply {
                if (ytApp != null) setPackage(ytApp.packageName)
                putExtra(SearchManager.QUERY, query)
                putExtra("query", query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(searchIntent)
            return
        } catch (_: Exception) {
        }
        try {
            val webUri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query))
            val viewIntent = Intent(Intent.ACTION_VIEW, webUri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(viewIntent)
        } catch (_: Exception) {
        }
    }

    private fun openSystemSettingsAction(context: Context, action: String) {
        try {
            val intent = Intent(action).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            try {
                val fallback = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(fallback)
            } catch (_: Exception) {
            }
        }
    }

    fun cleanRamBackground(context: Context) {
        try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return
            val apps = AppLauncher(context.applicationContext).getInstalledApps()
            for (app in apps) {
                val p = app.packageName.lowercase()
                if (app.packageName != context.packageName &&
                    !p.contains("spotify") &&
                    !p.contains("mediashell") &&
                    !p.contains("soundcloud")
                ) {
                    am.killBackgroundProcesses(app.packageName)
                }
            }
        } catch (_: Exception) {
        }
    }
}

/**
 * Умный клиент Gemini API с поддержкой:
 * - Ключей формата AQ.Ab8RN6... (Vertex AI Express Mode + Google AI Studio)
 * - Актуальных моделей Gemini 2.5 и 3.x (gemini-2.5-flash, gemini-3-flash-preview, gemini-3.1-flash-lite, gemini-2.5-flash-lite)
 * - Автоматического кэширования рабочего эндпоинта с первого успешного запроса
 */
object GeminiCloudClient {

    private val candidateModels = listOf(
        "gemini-2.5-flash",
        "gemini-3-flash-preview",
        "gemini-3.1-flash-lite",
        "gemini-2.5-flash-lite",
        "gemini-2.5-pro",
        "gemini-2.0-flash"
    )

    @Volatile
    private var cachedEndpointTemplate: String? = null

    @Volatile
    private var cachedUseHeaderAuth: Boolean = true

    private const val BASE_PROMPT =
        "Ты — встроенный голосовой ИИ-ассистент Gemini в минималистичном лаунчере Android TV (Xiaomi Mi TV Stick). " +
        "Отвечай на русском языке, максимально кратко, чётко и по делу (1–3 коротких предложения, без списков со звёздочками и без разметки Markdown), " +
        "чтобы ответ легко читался в компактной капсуле Dynamic Island на экране телевизора."

    private fun buildCommandInstruction(context: Context): String {
        val apps = AppLauncher(context.applicationContext).getInstalledApps().take(20)
            .joinToString(", ") { "${it.label} (${it.packageName})" }
        return "$BASE_PROMPT Если пользователь просит выполнить действие на ТВ, добавь В НАЧАЛЕ ответа один тег: " +
            "[CMD:LAUNCH:package_name] (приложения: $apps), [CMD:YT:поисковый запрос], [CMD:VOL_UP], [CMD:VOL_DOWN], [CMD:MUTE], [CMD:BOOST], " +
            "и короткое подтверждение (например: «Открываю YouTube»). Если это обычный вопрос — дай краткий ответ без тегов."
    }

    suspend fun askGeminiText(context: Context, userQuery: String): String = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext
        val apiKey = AppLauncher(appCtx).getGeminiApiKey()
        val fullPrompt = "${buildCommandInstruction(appCtx)}

Запрос пользователя: $userQuery"

        val payload = JSONObject().apply {
            put("contents", JSONArray().put(
                JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().put(JSONObject().put("text", fullPrompt)))
                }
            ))
            put("generationConfig", JSONObject().apply {
                put("maxOutputTokens", 800)
                put("temperature", 0.5)
            })
        }.toString()

        val rawReply = executeWithEndpointFallback(apiKey, payload)
        processCommandTags(appCtx, rawReply)
    }

    suspend fun askGeminiAudio(context: Context, wavBytes: ByteArray): String = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext
        val apiKey = AppLauncher(appCtx).getGeminiApiKey()
        val audioPrompt = buildCommandInstruction(appCtx)

        val b64Audio = Base64.encodeToString(wavBytes, Base64.NO_WRAP)
        val partsArray = JSONArray()
            .put(JSONObject().put("text", audioPrompt))
            .put(JSONObject().put("inlineData", JSONObject().apply {
                put("mimeType", "audio/wav")
                put("data", b64Audio)
            }))

        val payload = JSONObject().apply {
            put("contents", JSONArray().put(
                JSONObject().apply {
                    put("role", "user")
                    put("parts", partsArray)
                }
            ))
            put("generationConfig", JSONObject().apply {
                put("maxOutputTokens", 800)
                put("temperature", 0.4)
            })
        }.toString()

        val rawReply = executeWithEndpointFallback(apiKey, payload)
        processCommandTags(appCtx, rawReply)
    }

    private fun processCommandTags(context: Context, reply: String): String {
        var clean = reply.trim()
        val cmdRegex = Regex("\\[CMD:([^\\]]+)\\]")
        val match = cmdRegex.find(clean)
        if (match != null) {
            val tagContent = match.groupValues[1]
            clean = clean.replace(match.value, "").trim()
            val parts = tagContent.split(":", limit = 2)
            val action = parts[0].uppercase(Locale.US)
            val arg = parts.getOrNull(1)?.trim().orEmpty()
            val handler = Handler(Looper.getMainLooper())
            handler.post {
                when (action) {
                    "LAUNCH" -> if (arg.isNotEmpty()) {
                        MediaStateBus.onMediaAppOpened(arg)
                        AppLauncher(context).launchPackage(arg)
                    }
                    "YT" -> if (arg.isNotEmpty()) {
                        LocalVoiceCommandRouter.launchYouTubeSearch(context, arg)
                    }
                    "VOL_UP" -> LocalVoiceCommandRouter.tryExecuteLocalCommand(context, "громче")
                    "VOL_DOWN" -> LocalVoiceCommandRouter.tryExecuteLocalCommand(context, "тише")
                    "MUTE" -> LocalVoiceCommandRouter.tryExecuteLocalCommand(context, "выключи звук")
                    "BOOST" -> LocalVoiceCommandRouter.cleanRamBackground(context)
                }
            }
            return "✦ " + clean.removePrefix("✦").trim().ifEmpty { "Команда выполнена" }
        }
        return clean
    }

    private fun executeWithEndpointFallback(apiKey: String, jsonBody: String): String {
        val cached = cachedEndpointTemplate
        if (cached != null) {
            val res = trySingleRequest(cached, apiKey, cachedUseHeaderAuth, jsonBody)
            if (res.isSuccess && !res.text.isNullOrBlank()) {
                return res.text
            }
        }

        val endpointTemplates = listOf(
            "https://aiplatform.googleapis.com/v1/publishers/google/models/%s:generateContent" to true,
            "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent" to true,
            "https://aiplatform.googleapis.com/v1/publishers/google/models/%s:generateContent" to false,
            "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent" to false
        )

        var lastErr = ""
        for (model in candidateModels) {
            for ((template, useHeader) in endpointTemplates) {
                val urlStr = String.format(Locale.US, template, model)
                val res = trySingleRequest(urlStr, apiKey, useHeader, jsonBody)
                if (res.isSuccess && !res.text.isNullOrBlank()) {
                    cachedEndpointTemplate = urlStr
                    cachedUseHeaderAuth = useHeader
                    return res.text
                } else if (res.errorSummary.isNotBlank()) {
                    lastErr = res.errorSummary
                }
            }
        }

        return if (lastErr.isNotBlank()) {
            "Ошибка ответа Gemini ($lastErr)"
        } else {
            "Не удалось связаться с Gemini. Проверьте интернет-соединение."
        }
    }

    private data class HttpResult(
        val isSuccess: Boolean,
        val text: String? = null,
        val errorSummary: String = ""
    )

    private fun trySingleRequest(
        baseUrl: String,
        apiKey: String,
        useHeaderAuth: Boolean,
        jsonBody: String
    ): HttpResult {
        var conn: HttpURLConnection? = null
        return try {
            val finalUrl = if (useHeaderAuth) {
                baseUrl
            } else {
                "$baseUrl?key=${Uri.encode(apiKey)}"
            }
            conn = (URL(finalUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 7000
                readTimeout = 12000
                doOutput = true
                doInput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                if (useHeaderAuth) {
                    setRequestProperty("x-goog-api-key", apiKey)
                }
            }
            conn.outputStream.use { os ->
                os.write(jsonBody.toByteArray(Charsets.UTF_8))
            }
            val code = conn.responseCode
            if (code in 200..299) {
                val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val parsed = extractTextFromGeminiJson(body)
                if (!parsed.isNullOrBlank()) {
                    HttpResult(isSuccess = true, text = parsed)
                } else {
                    HttpResult(isSuccess = false, errorSummary = "Empty response")
                }
            } else {
                HttpResult(isSuccess = false, errorSummary = "HTTP $code")
            }
        } catch (e: Exception) {
            HttpResult(isSuccess = false, errorSummary = e.javaClass.simpleName)
        } finally {
            try {
                conn?.disconnect()
            } catch (_: Exception) {
            }
        }
    }

    private fun extractTextFromGeminiJson(rawJson: String): String? {
        return try {
            val root = JSONObject(rawJson)
            val candidates = root.optJSONArray("candidates") ?: return null
            if (candidates.length() == 0) return null
            val content = candidates.optJSONObject(0)?.optJSONObject("content") ?: return null
            val parts = content.optJSONArray("parts") ?: return null
            val sb = StringBuilder()
            for (i in 0 until parts.length()) {
                val partObj = parts.optJSONObject(i) ?: continue
                if (partObj.optBoolean("thought", false)) continue
                val t = partObj.optString("text", "")
                if (t.isNotBlank()) {
                    if (sb.isNotEmpty()) sb.append(" ")
                    sb.append(t.trim())
                }
            }
            sb.toString().replace("**", "").replace("*", "").trim()
        } catch (_: Exception) {
            null
        }
    }
}
