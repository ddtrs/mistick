package com.mitv.customlauncher.data

import android.app.ActivityManager
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.isActive
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.view.KeyEvent
import com.mitv.customlauncher.service.DynamicIslandBus
import com.mitv.customlauncher.service.TvUiControllerBus
import com.mitv.customlauncher.service.MediaStateBus
import com.mitv.customlauncher.service.NavSoundPlayer
import com.mitv.customlauncher.service.VolumeHudBus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

sealed interface AssistantState {
    data object Idle : AssistantState
    data object Listening : AssistantState
    data object Processing : AssistantState
    data class Result(val text: String) : AssistantState
    data class Error(val code: String) : AssistantState
}

interface AssistantEngine {
    val state: StateFlow<AssistantState>
    fun startSession()
    fun cancelSession()
}

class FakeAssistantEngine(
    private val scope: CoroutineScope,
    private val demoReplyText: String
) : AssistantEngine {
    private val _state = MutableStateFlow<AssistantState>(AssistantState.Idle)
    override val state: StateFlow<AssistantState> = _state.asStateFlow()
    override fun startSession() {}
    override fun cancelSession() {
        _state.value = AssistantState.Idle
    }
}

/**
 * Исполнитель глубоких действий Android TV, вызываемых напрямую ИИ Gemini:
 * - запуск треков и артистов в Spotify (MEDIA_PLAY_FROM_SEARCH + spotify:search + авто-PLAY)
 * - запуск стримов на Kick (kalatay3 и любые другие каналы)
 * - смена цвета лаунчера/ползунка/островка на любой HEX-цвет
 * - управление громкостью, плеером, памятью, приложениями и звуком щелчков пульта
 */
object LocalVoiceCommandRouter {

    data class LocalActionResult(
        val confirmationText: String,
        val isQuickCommand: Boolean = true
    )

    var onThemeColorChanged: ((String) -> Unit)? = null
    var onVolumeChangedCallback: (() -> Unit)? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    /**
     * В v3.8 100% всех голосовых запросов обрабатываются напрямую через Gemini,
     * чтобы идеально понимать украинский, русский, суржик и английский без жёстких шаблонов!
     */
    fun tryExecuteLocalCommand(context: Context, rawText: String): LocalActionResult? {
        return null
    }

    fun executeSystemAudioCommand(context: Context, actionType: String) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val curVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
        val curPct = ((curVol * 100f) / maxVol).toInt().coerceIn(0, 100)

        when (actionType) {
            "VOL_UP" -> {
                val newPct = (curPct + 15).coerceAtMost(100)
                val targetVol = ((newPct * maxVol) / 100f + 0.5f).toInt().coerceIn((curVol + 1).coerceAtMost(maxVol), maxVol)
                try {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
                } catch (_: Exception) {
                }
                mainHandler.post {
                    onVolumeChangedCallback?.invoke()
                    VolumeHudBus.notifyVolumeChanged()
                }
            }
            "VOL_DOWN" -> {
                val newPct = (curPct - 15).coerceAtLeast(0)
                val targetVol = ((newPct * maxVol) / 100f).toInt().coerceIn(0, (curVol - 1).coerceAtLeast(0))
                try {
                    am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
                } catch (_: Exception) {
                }
                mainHandler.post {
                    onVolumeChangedCallback?.invoke()
                    VolumeHudBus.notifyVolumeChanged()
                }
            }
            "MUTE" -> {
                try {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_MUTE, 0)
                } catch (_: Exception) {
                }
                mainHandler.post {
                    onVolumeChangedCallback?.invoke()
                    VolumeHudBus.notifyVolumeChanged()
                }
            }
            "UNMUTE" -> {
                try {
                    am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
                } catch (_: Exception) {
                }
                mainHandler.post {
                    onVolumeChangedCallback?.invoke()
                    VolumeHudBus.notifyVolumeChanged()
                }
            }
            "PAUSE", "PLAY" -> MediaStateBus.dispatchTransportAction("PLAY_PAUSE", am)
            "NEXT" -> MediaStateBus.dispatchTransportAction("NEXT", am)
            "PREV" -> MediaStateBus.dispatchTransportAction("PREV", am)
        }
    }

    fun applyThemeColorEverywhere(context: Context, hex: String) {
        val cleanHex = if (hex.startsWith("#")) hex else "#$hex"
        try {
            android.graphics.Color.parseColor(cleanHex)
        } catch (_: Exception) {
            return
        }
        AppLauncher(context.applicationContext).saveAccentColorHex(cleanHex)
        mainHandler.post {
            onThemeColorChanged?.invoke(cleanHex)
            DynamicIslandBus.notifyAccentColorChanged(cleanHex)
        }
    }

    fun setVolumePercent(context: Context, targetPct: Int) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val clamped = targetPct.coerceIn(0, 100)
        val targetVol = ((clamped * maxVol) / 100f + 0.5f).toInt().coerceIn(0, maxVol)
        try {
            if (clamped > 0) {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_UNMUTE, 0)
            }
            am.setStreamVolume(AudioManager.STREAM_MUSIC, targetVol, 0)
        } catch (_: Exception) {
        }
        mainHandler.post {
            onVolumeChangedCallback?.invoke()
            VolumeHudBus.notifyVolumeChanged()
        }
    }

    fun launchKickStream(context: Context, channelSlug: String) {
        val cleanSlug = channelSlug.trim().removePrefix("https://kick.com/").removePrefix("kick.com/").trim('/')
        val url = if (cleanSlug.isNotEmpty()) "https://kick.com/$cleanSlug" else "https://kick.com"
        val appLauncher = AppLauncher(context.applicationContext)
        val pm = context.packageManager
        val allApps = appLauncher.getInstalledApps()

        val kickApp = allApps.firstOrNull {
            val p = it.packageName.lowercase()
            val l = it.label.lowercase()
            p.contains("kick") || l == "kick" || l.startsWith("kick:") || l.startsWith("kick ")
        }

        if (kickApp != null) {
            val pkg = kickApp.packageName
            // 1. Проверяем, поддерживает ли установленная версия Kick прямые ссылки (на телефоне — да, на Android TV — нет)
            val candidateUris = listOf(
                Uri.parse(url),
                Uri.parse("kick://channel/$cleanSlug"),
                Uri.parse("kick://$cleanSlug")
            )
            for (u in candidateUris) {
                try {
                    val deepIntent = Intent(Intent.ACTION_VIEW, u).apply {
                        setPackage(pkg)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    @Suppress("DEPRECATION")
                    if (pm.queryIntentActivities(deepIntent, 0).isNotEmpty()) {
                        context.startActivity(deepIntent)
                        return
                    }
                } catch (_: Exception) {
                }
            }

            // 2. Проверяем поддержку системного ACTION_SEARCH внутри Kick
            if (cleanSlug.isNotEmpty()) {
                try {
                    val searchIntent = Intent(Intent.ACTION_SEARCH).apply {
                        setPackage(pkg)
                        putExtra(SearchManager.QUERY, cleanSlug)
                        putExtra("query", cleanSlug)
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    @Suppress("DEPRECATION")
                    if (pm.queryIntentActivities(searchIntent, 0).isNotEmpty()) {
                        context.startActivity(searchIntent)
                        return
                    }
                } catch (_: Exception) {
                }
            }

            // 3. ТВ-версия Kick («Kick: стриминг в прямом эфире»): запускаем само приложение Kick без белого окна ошибки
            // и включаем ИИ-автопоиск стримера через наш AccessibilityService!
            if (appLauncher.launchPackage(pkg)) {
                if (cleanSlug.isNotEmpty()) {
                    TvUiControllerBus.scheduleInAppSearch(pkg, cleanSlug)
                }
                return
            }
        }

        launchUrlInTvBrowser(context, url)
    }

    fun launchUrlInTvBrowser(context: Context, url: String) {
        val finalUrl = if (url.startsWith("http://") || url.startsWith("https://")) url else "https://$url"
        val uri = Uri.parse(finalUrl)
        val appLauncher = AppLauncher(context.applicationContext)
        val pm = context.packageManager
        val allApps = appLauncher.getInstalledApps()

        val browserCandidate = allApps.firstOrNull {
            val p = it.packageName.lowercase()
            val l = it.label.lowercase()
            p.contains("browser") || p.contains("chrome") || p.contains("tvbro") ||
                p.contains("puffin") || p.contains("firefox") || p.contains("opera") ||
                l.contains("браузер") || l.contains("browser")
        }

        if (browserCandidate != null) {
            try {
                val intent = Intent(Intent.ACTION_VIEW, uri).apply {
                    setPackage(browserCandidate.packageName)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                return
            } catch (_: Exception) {
            }
        }

        try {
            val generic = Intent(Intent.ACTION_VIEW, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            @Suppress("DEPRECATION")
            val handlers = pm.queryIntentActivities(generic, 0).filter {
                !it.activityInfo.packageName.lowercase().contains("tv.fw.browsable") &&
                    !it.activityInfo.name.lowercase().contains("stub")
            }
            if (handlers.isNotEmpty()) {
                context.startActivity(generic)
            }
        } catch (_: Exception) {
        }
    }

    fun launchSpotifyTrackOrArtist(context: Context, rawQuery: String) {
        val query = rawQuery.trim()
        if (query.isEmpty()) return
        val appLauncher = AppLauncher(context.applicationContext)
        val allApps = appLauncher.getInstalledApps()
        val spotifyApp = allApps.firstOrNull {
            val p = it.packageName.lowercase()
            p.contains("spotify") || it.label.lowercase().contains("spotify")
        }
        val spotifyPkg = spotifyApp?.packageName

        if (spotifyPkg != null) {
            MediaStateBus.seedTrackFromQuery(context, spotifyPkg, query)

            try {
                val playIntent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
                    setPackage(spotifyPkg)
                    putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
                    putExtra(SearchManager.QUERY, query)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                context.startActivity(playIntent)
                scheduleSpotifyAutoPlayKick(context)
                return
            } catch (_: Exception) {
            }

            try {
                val uriIntent = Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:${Uri.encode(query)}")).apply {
                    setPackage(spotifyPkg)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                context.startActivity(uriIntent)
                scheduleSpotifyAutoPlayKick(context)
                return
            } catch (_: Exception) {
            }

            try {
                val searchIntent = Intent(Intent.ACTION_SEARCH).apply {
                    setPackage(spotifyPkg)
                    putExtra(SearchManager.QUERY, query)
                    putExtra("query", query)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                }
                context.startActivity(searchIntent)
                scheduleSpotifyAutoPlayKick(context)
                return
            } catch (_: Exception) {
            }

            appLauncher.launchPackage(spotifyPkg)
            scheduleSpotifyAutoPlayKick(context)
            return
        }

        launchYouTubeSearch(context, query)
    }

    private fun scheduleSpotifyAutoPlayKick(context: Context) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        mainHandler.postDelayed({
            try {
                val now = SystemClock.uptimeMillis()
                val down = KeyEvent(now, now, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PLAY, 0)
                val up = KeyEvent(now, now, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PLAY, 0)
                am.dispatchMediaKeyEvent(down)
                am.dispatchMediaKeyEvent(up)
            } catch (_: Exception) {
            }
        }, 2000L)
    }

    fun launchYouTubeSearch(context: Context, query: String) {
        val appLauncher = AppLauncher(context.applicationContext)
        val apps = appLauncher.getInstalledApps()
        val ytApp = apps.firstOrNull {
            val p = it.packageName.lowercase()
            p.contains("youtube.tv") || p.contains("smarttube") || p.contains("youtube")
        }
        try {
            val searchIntent = Intent(Intent.ACTION_SEARCH).apply {
                if (ytApp != null) setPackage(ytApp.packageName)
                putExtra(SearchManager.QUERY, query)
                putExtra("query", query)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(searchIntent)
            return
        } catch (_: Exception) {
        }
        try {
            val webUri = Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query))
            val viewIntent = Intent(Intent.ACTION_VIEW, webUri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(viewIntent)
        } catch (_: Exception) {
        }
    }

    fun openSystemSettingsAction(context: Context, action: String) {
        try {
            val intent = Intent(action).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
        } catch (_: Exception) {
            try {
                val fallback = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(fallback)
            } catch (_: Exception) {
            }
        }
    }

    fun cleanRamBackground(context: Context) {
        try {
            val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return
            val apps = AppLauncher(context.applicationContext).getInstalledApps()
            for (app in apps) {
                val p = app.packageName.lowercase()
                if (app.packageName != context.packageName &&
                    !p.contains("spotify") &&
                    !p.contains("mediashell") &&
                    !p.contains("soundcloud")
                ) {
                    am.killBackgroundProcesses(app.packageName)
                }
            }
        } catch (_: Exception) {
        }
    }
}

/**
 * 100% Gemini-ассистент (2.5 & 3.8):
 * - Слушает живой голос напрямую в формате WAV (идеально понимает украинский, русский, суржик и английский!)
 * - Использует рабочий ключ XOR_PROTECTED_KEY (без ошибки 401!)
 * - Сам управляет Spotify, Kick, YouTube, цветами лаунчера, приложениями и звуком ТВ
 */
/**
 * Голосовой синтезатор речи ассистента (TTS) с мгновенным откликом,
 * автоопределением украинского/русского/английского языка и приглушением фоновой музыки (Audio Ducking).
 */
/**
 * Облачный голосовой синтезатор речи Gemini TTS (gemini-2.5-flash-preview-tts):
 * - 0 МБ фонового потребления ОЗУ (работает без системного com.google.android.tts напрямую через легковесный AudioTrack)
 * - 5 живых нейронных голосов на выбор: Puck, Charon, Fenrir (мужские) и Kore, Aoede (женские)
 * - Вычисляет реальную амплитуду звуковой волны (currentVoiceWaveLevel) каждые 40 мс для 60 FPS анимации полосок Dynamic Island
 */
object AssistantVoiceSpeaker {

    private const val PREF_TTS_ENABLED = "pref_assistant_tts_enabled"
    private const val PREF_TTS_VOICE = "pref_assistant_tts_voice"

    val AVAILABLE_VOICES: List<Pair<String, String>> = listOf(
        "Puck" to "Puck (Мужской · Бодрый)",
        "Charon" to "Charon (Мужской · Глубокий)",
        "Fenrir" to "Fenrir (Мужской · Энергичный)",
        "Kore" to "Kore (Женский · Чёткий)",
        "Aoede" to "Aoede (Женский · Мягкий)"
    )

    private val ttsModels = listOf(
        "gemini-2.5-flash-preview-tts",
        "gemini-2.5-pro-preview-tts"
    )

    @Volatile
    private var cachedTtsModel: String? = null

    private val speakerScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())

    @Volatile
    private var speakJob: Job? = null

    @Volatile
    private var activeAudioTrack: AudioTrack? = null

    @Volatile
    var isSpeakingNow: Boolean = false
        private set

    @Volatile
    var currentVoiceWaveLevel: Float = 0.45f
        private set

    private var currentAudioFocusRequest: AudioFocusRequest? = null

    fun isTtsEnabled(context: Context): Boolean {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(PREF_TTS_ENABLED, true)
    }

    fun setTtsEnabled(context: Context, enabled: Boolean) {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean(PREF_TTS_ENABLED, enabled).apply()
        if (!enabled) {
            stop(context)
        }
    }

    fun getSelectedVoiceName(context: Context): String {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString(PREF_TTS_VOICE, "Puck") ?: "Puck"
        return if (AVAILABLE_VOICES.any { it.first.equals(saved, ignoreCase = true) }) {
            AVAILABLE_VOICES.first { it.first.equals(saved, ignoreCase = true) }.first
        } else {
            "Puck"
        }
    }

    fun getSelectedVoiceDisplayLabel(context: Context): String {
        val code = getSelectedVoiceName(context)
        return AVAILABLE_VOICES.firstOrNull { it.first == code }?.second ?: code
    }

    fun setVoiceName(context: Context, rawVoice: String): String {
        val clean = rawVoice.trim()
        val matched = AVAILABLE_VOICES.firstOrNull {
            it.first.equals(clean, ignoreCase = true) || it.second.lowercase(Locale.ROOT).contains(clean.lowercase(Locale.ROOT))
        }?.first ?: when {
            clean.lowercase(Locale.ROOT).contains("жен") || clean.lowercase(Locale.ROOT).contains("жіноч") || clean.lowercase(Locale.ROOT).contains("kore") -> "Kore"
            clean.lowercase(Locale.ROOT).contains("мягк") || clean.lowercase(Locale.ROOT).contains("aoede") -> "Aoede"
            clean.lowercase(Locale.ROOT).contains("глуб") || clean.lowercase(Locale.ROOT).contains("charon") -> "Charon"
            clean.lowercase(Locale.ROOT).contains("энерг") || clean.lowercase(Locale.ROOT).contains("fenrir") -> "Fenrir"
            else -> "Puck"
        }
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(PREF_TTS_VOICE, matched).apply()
        return matched
    }

    fun cycleNextVoice(context: Context): String {
        val current = getSelectedVoiceName(context)
        val idx = AVAILABLE_VOICES.indexOfFirst { it.first == current }
        val next = if (idx >= 0) AVAILABLE_VOICES[(idx + 1) % AVAILABLE_VOICES.size].first else AVAILABLE_VOICES.first().first
        setVoiceName(context, next)
        return getSelectedVoiceDisplayLabel(context)
    }

    fun init(context: Context) {
        // 0 МБ фонового потребления ОЗУ в простое
    }

    /**
     * Разбивает ответ на короткую первую фразу (~20–62 символа) для мгновенного старта голоса за ~1 секунду
     * и последующие предложения, которые догружаются параллельно в фоне во время звучания первой фразы!
     */
    private fun splitTextForFastStart(text: String): List<String> {
        val clean = text.trim()
        if (clean.length <= 68) return listOf(clean)

        val chunks = mutableListOf<String>()
        var remaining = clean

        // 1. Выделяем короткую первую фразу (до первой точки, восклицательного/вопросительного знака, тире или запятой в диапазоне 18..68 символов)
        var firstSplitIdx = -1
        val strongDelims = listOf(". ", "! ", "? ", "; ", ": ", " — ", " - ")
        for (d in strongDelims) {
            val idx = remaining.indexOf(d)
            if (idx in 14..68) {
                val candidate = idx + d.length
                if (firstSplitIdx == -1 || candidate < firstSplitIdx) {
                    firstSplitIdx = candidate
                }
            }
        }
        if (firstSplitIdx == -1) {
            val commaIdx = remaining.indexOf(", ")
            if (commaIdx in 20..65) {
                firstSplitIdx = commaIdx + 2
            }
        }
        if (firstSplitIdx == -1) {
            val spaceIdx = remaining.lastIndexOf(' ', 58)
            if (spaceIdx >= 22) {
                firstSplitIdx = spaceIdx + 1
            }
        }

        if (firstSplitIdx > 0 && firstSplitIdx < remaining.length) {
            val firstPart = remaining.substring(0, firstSplitIdx).trim()
            if (firstPart.isNotEmpty()) {
                chunks.add(firstPart)
            }
            remaining = remaining.substring(firstSplitIdx).trim()
        }

        // 2. Остаток разбиваем по предложениям (до ~130 символов на чанк)
        while (remaining.isNotEmpty()) {
            if (remaining.length <= 135) {
                chunks.add(remaining)
                break
            }
            var splitAt = -1
            for (d in listOf(". ", "! ", "? ", "; ")) {
                val idx = remaining.lastIndexOf(d, 135)
                if (idx >= 25 && idx + d.length > splitAt) {
                    splitAt = idx + d.length
                }
            }
            if (splitAt == -1) {
                val commaIdx = remaining.lastIndexOf(", ", 130)
                if (commaIdx >= 30) {
                    splitAt = commaIdx + 2
                }
            }
            if (splitAt == -1) {
                val spIdx = remaining.lastIndexOf(' ', 125)
                splitAt = if (spIdx >= 30) spIdx + 1 else 125
            }
            val piece = remaining.substring(0, splitAt).trim()
            if (piece.isNotEmpty()) {
                chunks.add(piece)
            }
            remaining = remaining.substring(splitAt).trim()
        }

        return if (chunks.isEmpty()) listOf(clean) else chunks
    }

    /**
     * Потоково-конвейерный синтез и воспроизведение речи через Gemini 2.5 Flash TTS:
     * Первая короткая фраза синтезируется за ~1 сек и сразу начинает звучать через единый AudioTrack(MODE_STREAM),
     * а следующие фразы параллельно синтезируются в фоне во время воспроизведения первой!
     */
    fun speak(context: Context, rawText: String, onFinished: ((Boolean) -> Unit)? = null) {
        val appCtx = context.applicationContext
        stop(appCtx)

        if (!isTtsEnabled(appCtx)) {
            onFinished?.let { mainHandler.post { it.invoke(false) } }
            return
        }

        val cleanText = rawText
            .removePrefix("✦")
            .replace("⚡", "")
            .replace("✓", "")
            .replace("·", ", ")
            .replace("–", " до ")
            .trim()

        if (cleanText.isEmpty()) {
            onFinished?.let { mainHandler.post { it.invoke(false) } }
            return
        }

        val voiceName = getSelectedVoiceName(appCtx)
        val textChunks = splitTextForFastStart(cleanText)
        isSpeakingNow = true
        currentVoiceWaveLevel = 0.52f

        speakJob = speakerScope.launch {
            var playedSuccessfully = false
            var track: AudioTrack? = null
            try {
                // Запускаем генерацию 1-й короткой фразы прямо сейчас, а 2-й фразы — параллельно с небольшой форой!
                var currentDeferred: Deferred<ByteArray?>? = async { fetchGeminiTtsPcm(textChunks[0], voiceName) }
                var nextDeferred: Deferred<ByteArray?>? = if (textChunks.size > 1) {
                    async { fetchGeminiTtsPcm(textChunks[1], voiceName) }
                } else {
                    null
                }

                for (idx in textChunks.indices) {
                    if (!isActive || !isSpeakingNow) break

                    val pcmData = currentDeferred?.await()
                    // Пока сейчас будет играть текущий кусок, заранее ставим в генерацию (idx + 2)-й кусок
                    currentDeferred = nextDeferred
                    nextDeferred = if (idx + 2 < textChunks.size) {
                        async { fetchGeminiTtsPcm(textChunks[idx + 2], voiceName) }
                    } else {
                        null
                    }

                    if (pcmData != null && pcmData.size > 400 && isActive && isSpeakingNow) {
                        if (track == null) {
                            track = openStreamingAudioTrack24kHz(appCtx)
                            activeAudioTrack = track
                        }
                        val activeAt = track
                        if (activeAt != null) {
                            val ok = writePcmChunkWithVisualizer(activeAt, pcmData)
                            if (ok) playedSuccessfully = true
                        }
                    }
                }
            } catch (_: Exception) {
            } finally {
                activeAudioTrack = null
                try {
                    track?.stop()
                } catch (_: Exception) {
                }
                try {
                    track?.release()
                } catch (_: Exception) {
                }
                isSpeakingNow = false
                currentVoiceWaveLevel = 0.35f
                abandonAudioFocus(appCtx)
                if (isActive) {
                    val didPlay = playedSuccessfully
                    onFinished?.let { cb ->
                        mainHandler.post { cb.invoke(didPlay) }
                    }
                }
            }
        }
    }

    fun stop(context: Context? = null) {
        speakJob?.cancel()
        speakJob = null
        isSpeakingNow = false
        currentVoiceWaveLevel = 0.35f
        val runningTrack = activeAudioTrack
        activeAudioTrack = null
        if (runningTrack != null) {
            try {
                runningTrack.pause()
                runningTrack.flush()
            } catch (_: Exception) {
            }
            try {
                runningTrack.release()
            } catch (_: Exception) {
            }
        }
        if (context != null) {
            abandonAudioFocus(context.applicationContext)
        }
    }

    private fun fetchGeminiTtsPcm(textToSpeak: String, voiceName: String): ByteArray? {
        val apiKey = LauncherConfig.DEFAULT_GEMINI_API_KEY
        val payload = JSONObject().apply {
            put("contents", JSONArray().put(
                JSONObject().apply {
                    put("parts", JSONArray().put(
                        JSONObject().put("text", textToSpeak)
                    ))
                }
            ))
            put("generationConfig", JSONObject().apply {
                put("responseModalities", JSONArray().put("AUDIO"))
                put("speechConfig", JSONObject().apply {
                    put("voiceConfig", JSONObject().apply {
                        put("prebuiltVoiceConfig", JSONObject().apply {
                            put("voiceName", voiceName)
                        })
                    })
                })
            })
        }.toString()

        val orderedModels = mutableListOf<String>()
        val cached = cachedTtsModel
        if (cached != null) orderedModels.add(cached)
        for (m in ttsModels) {
            if (m != cached) orderedModels.add(m)
        }

        for (model in orderedModels) {
            var conn: HttpURLConnection? = null
            try {
                val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=${Uri.encode(apiKey)}")
                val connection = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 4500
                    readTimeout = 9500
                    doOutput = true
                    doInput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("Connection", "keep-alive")
                }
                conn = connection
                connection.outputStream.use { os ->
                    os.write(payload.toByteArray(Charsets.UTF_8))
                }
                if (connection.responseCode in 200..299) {
                    val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    val root = JSONObject(body)
                    val parts = root.optJSONArray("candidates")
                        ?.optJSONObject(0)
                        ?.optJSONObject("content")
                        ?.optJSONArray("parts")
                    if (parts != null) {
                        for (i in 0 until parts.length()) {
                            val inlineData = parts.optJSONObject(i)?.optJSONObject("inlineData") ?: continue
                            val b64 = inlineData.optString("data", "")
                            if (b64.isNotBlank()) {
                                cachedTtsModel = model
                                val rawBytes = Base64.decode(b64, Base64.DEFAULT)
                                return if (rawBytes.size > 44 &&
                                    rawBytes[0] == 0x52.toByte() &&
                                    rawBytes[1] == 0x49.toByte() &&
                                    rawBytes[2] == 0x46.toByte() &&
                                    rawBytes[3] == 0x46.toByte()
                                ) {
                                    rawBytes.copyOfRange(44, rawBytes.size)
                                } else {
                                    rawBytes
                                }
                            }
                        }
                    }
                }
            } catch (_: Exception) {
            } finally {
                try {
                    conn?.disconnect()
                } catch (_: Exception) {
                }
            }
        }
        return null
    }

    private fun openStreamingAudioTrack24kHz(context: Context): AudioTrack? {
        val sampleRate = 24000
        val minBuf = AudioTrack.getMinBufferSize(
            sampleRate,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(4800)

        return try {
            requestTransientAudioDucking(context)
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build()
            val format = AudioFormat.Builder()
                .setSampleRate(sampleRate)
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                .build()
            AudioTrack(
                attrs,
                format,
                minBuf * 2,
                AudioTrack.MODE_STREAM,
                AudioManager.AUDIO_SESSION_ID_GENERATE
            ).apply {
                play()
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun writePcmChunkWithVisualizer(at: AudioTrack, pcmBytes: ByteArray): Boolean {
        return try {
            val chunkSize = 1920 // 40 мс при 24000 Гц (16 бит моно)
            var offset = 0
            while (offset < pcmBytes.size && isSpeakingNow) {
                val len = (pcmBytes.size - offset).coerceAtMost(chunkSize)
                val samplesCount = len / 2
                if (samplesCount > 0) {
                    var sumSq = 0.0
                    val bb = ByteBuffer.wrap(pcmBytes, offset, len).order(ByteOrder.LITTLE_ENDIAN)
                    for (s in 0 until samplesCount) {
                        val v = bb.short.toDouble()
                        sumSq += v * v
                    }
                    val rms = sqrt(sumSq / samplesCount)
                    currentVoiceWaveLevel = (0.26f + (rms / 5500.0).toFloat()).coerceIn(0.26f, 1.0f)
                }
                val written = at.write(pcmBytes, offset, len)
                if (written <= 0) break
                offset += written
            }
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun requestTransientAudioDucking(context: Context) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val attrs = AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
                val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
                    .setAudioAttributes(attrs)
                    .setAcceptsDelayedFocusGain(false)
                    .setOnAudioFocusChangeListener {}
                    .build()
                currentAudioFocusRequest = req
                am.requestAudioFocus(req)
            } else {
                @Suppress("DEPRECATION")
                am.requestAudioFocus(
                    null,
                    AudioManager.STREAM_MUSIC,
                    AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK
                )
            }
        } catch (_: Exception) {
        }
    }

    private fun abandonAudioFocus(context: Context) {
        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val req = currentAudioFocusRequest
                if (req != null) {
                    am.abandonAudioFocusRequest(req)
                    currentAudioFocusRequest = null
                }
            } else {
                @Suppress("DEPRECATION")
                am.abandonAudioFocus(null)
            }
        } catch (_: Exception) {
        }
    }
}

data class GeminiTurnResult(
    val displayText: String,
    val shouldContinueDialog: Boolean,
    val isSilence: Boolean = false
)

object GeminiCloudClient {

    private data class ChatTurn(
        val role: String,
        val text: String
    )

    private val candidateModels = listOf(
        "gemini-2.5-flash",
        "gemini-2.5-flash-lite",
        "gemini-2.0-flash",
        "gemini-2.0-flash-lite",
        "gemini-flash-latest",
        "gemini-1.5-flash"
    )

    private val conversationHistory = mutableListOf<ChatTurn>()

    @Volatile
    private var lastInteractionRealtimeMs: Long = 0L

    @Volatile
    private var cachedModelName: String? = null

    @Volatile
    private var cachedUseHeaderAuth: Boolean = false

    @Synchronized
    fun clearConversationHistory() {
        conversationHistory.clear()
    }

    @Synchronized
    private fun appendTurnToHistory(userText: String, modelText: String) {
        val now = SystemClock.elapsedRealtime()
        if (now - lastInteractionRealtimeMs > 5 * 60 * 1000L) {
            conversationHistory.clear()
        }
        lastInteractionRealtimeMs = now
        if (userText.isNotBlank()) {
            conversationHistory.add(ChatTurn("user", userText.take(350)))
        }
        if (modelText.isNotBlank()) {
            conversationHistory.add(ChatTurn("model", modelText.take(450)))
        }
        while (conversationHistory.size > 8) {
            conversationHistory.removeAt(0)
        }
    }

    @Synchronized
    private fun formatRecentHistoryBlock(): String {
        val now = SystemClock.elapsedRealtime()
        if (now - lastInteractionRealtimeMs > 5 * 60 * 1000L) {
            conversationHistory.clear()
            return ""
        }
        if (conversationHistory.isEmpty()) return ""
        val lines = conversationHistory.joinToString("\n") { turn ->
            val who = if (turn.role == "user") "Пользователь" else "Ты (Ассистент)"
            "$who: ${turn.text}"
        }
        return "\nПредыдущий контекст текущего диалога (учитывай его при ответе на уточняющие вопросы вроде «а на завтра?», «а почему?», «расскажи подробнее»):\n$lines\n"
    }

    private fun buildCommandInstruction(context: Context): String {
        val appCtx = context.applicationContext
        val apps = AppLauncher(appCtx).getInstalledApps().take(30)
            .joinToString(", ") { "${it.label} (${it.packageName})" }
        val outageInfo = OutageRepository.getSummaryForAi(appCtx)
        val historyBlock = formatRecentHistoryBlock()
        val currentVoice = AssistantVoiceSpeaker.getSelectedVoiceName(appCtx)
        val ttsEnabled = AssistantVoiceSpeaker.isTtsEnabled(appCtx)
        return "Ты — живой, умный и сверхбыстрый голосовой ИИ-ассистент в кастомном лаунчере Android TV (Xiaomi Mi TV Stick). " +
            "Сейчас твоя голосовая озвучка: ${if (ttsEnabled) "ВКЛЮЧЕНА (голос $currentVoice)" else "ВЫКЛЮЧЕНА"}. " +
            "Отвечай естественно, дружелюбно и лаконично (1–2 предложения, без звёздочек и без разметки Markdown). " +
            "Актуальные данные по графику отключений света пользователя ($outageInfo). Если пользователь спрашивает про свет/отключения/график ДТЭК — дай точный ответ по этим данным! " +
            historyBlock +
            "Ты идеально понимаешь украинский, русский, суржик и английский языки. Отвечай на том же языке, на котором обратился пользователь.\n" +
            "ВАЖНОЕ ПРАВИЛО РЕЖИМА ДИАЛОГА:\n" +
            "- Если пользователь выполняет команду управления ТВ (включи трек/видео/стрим, открой приложение, измени громкость/цвет) ИЛИ задал простой закрытый вопрос на один факт (например «когда выключат свет?», «какая очередь?», «сколько времени?») — обязательно поставь в начале ответа тег [MODE:ONE_SHOT], чтобы после ответа микрофон НЕ включался сам.\n" +
            "- Ставь тег [MODE:DIALOG] ТОЛЬКО тогда, когда пользователь явно ведёт беседу/обсуждение (например «посоветуй фильм», «давай поговорим», «расскажи...») ИЛИ когда ты сам задаёшь пользователю встречный уточняющий вопрос в конце ответа!\n" +
            "ТЕГИ КОМАНД УПРАВЛЕНИЯ ПРИСТАВКОЙ (ставь в начале ответа, если пользователь просит выполнить действие):\n" +
            "- Включить песню, трек, альбом или исполнителя в Spotify: [CMD:SPOTIFY:Точное имя артиста и трека] (переводи транслит в оригинальное название, например «уикенд старбой» -> [CMD:SPOTIFY:The Weeknd Starboy])\n" +
            "- Запустить стрим на Kick: [CMD:KICK:channel_slug] (для стримера Калатай / Kalatay всегда используй [CMD:KICK:kalatay3])\n" +
            "- Найти или включить видео на YouTube: [CMD:YT:поисковый запрос]\n" +
            "- Изменить цвет темы лаунчера, обводки или ползунка громкости: [CMD:COLOR:#RRGGBB] (красный #EF4444, розовый #EC4899, фиолетовый #A78BFA, зелёный #34D399, синий #60A5FA, голубой/бирюзовый #00F0FF, жёлтый/золотой #F59E0B, оранжевый #F97316, белый #E2E8F0)\n" +
            "- Открыть установленное приложение: [CMD:LAUNCH:package_name] (список приложений: $apps)\n" +
            "- Открыть системные настройки ТВ: [CMD:SETTINGS], настройки Wi-Fi: [CMD:WIFI], настройки Bluetooth: [CMD:BLUETOOTH]\n" +
            "- Открыть сайт в браузере: [CMD:URL:https://адрес]\n" +
            "- Громкость в процентах: [CMD:VOL_SET:0..100], сделать громче: [CMD:VOL_UP], тише: [CMD:VOL_DOWN], выключить звук: [CMD:MUTE], включить звук: [CMD:UNMUTE]\n" +
            "- Управление плеером: [CMD:PAUSE], [CMD:PLAY], [CMD:NEXT], [CMD:PREV]\n" +
            "- Очистить оперативную память / ускорить приставку: [CMD:BOOST]\n" +
            "- Выключить или включить звук щелчков пульта: [CMD:NAV_SOUND:OFF] или [CMD:NAV_SOUND:ON]\n" +
            "- Выключить или включить голосовую озвучку твоих ответов: [CMD:TTS:OFF] или [CMD:TTS:ON]\n" +
            "- Сменить твой голос озвучки (доступны мужские голоса Puck, Charon, Fenrir и женские Kore, Aoede): [CMD:VOICE:имя_голоса]\n" +
            "- Показать на экране окно графика отключений света: [CMD:OUTAGE_OPEN]\n" +
            "- Изменить очередь (группу) отключений света ДТЭК (от 1.1 до 6.2): [CMD:OUTAGE_GROUP:номер_очереди]\n" +
            "- Ввести или напечатать текст в поле поиска на экране ТВ: [CMD:TYPE:текст для ввода]\n" +
            "- Нажать на кнопку, вкладку или карточку на экране ТВ по названию: [CMD:CLICK:текст кнопки]\n" +
            "- Системная навигация по ТВ: [CMD:NAV:HOME] (на главный экран), [CMD:NAV:BACK] (назад)\n" +
            "- Если пользователь прощается или говорит «спасибо, всё / хватит / пока / отбой»: [CMD:STOP_DIALOG]\n" +
            "- Если пользователь просит забыть контекст или сменить тему: [CMD:CLEAR_MEMORY]\n" +
            "После тегов напиши короткий живой ответ для пользователя."
    }

    private fun buildPayloadForModel(contentsArray: JSONArray, modelName: String, temperature: Double): String {
        val genConfig = JSONObject().apply {
            put("maxOutputTokens", 1200)
            put("temperature", temperature)
            if (modelName.startsWith("gemini-2.5-flash")) {
                put("thinkingConfig", JSONObject().apply {
                    put("thinkingBudget", 0)
                })
            }
        }
        return JSONObject().apply {
            put("contents", contentsArray)
            put("generationConfig", genConfig)
        }.toString()
    }

    suspend fun askGeminiTextTurn(context: Context, userQuery: String): GeminiTurnResult = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext
        try {
            OutageRepository.refreshIfNeeded(appCtx, force = false)
        } catch (_: Exception) {
        }
        val fullPrompt = "${buildCommandInstruction(appCtx)}\n\nЗапрос пользователя: $userQuery"

        val contentsArray = JSONArray().put(
            JSONObject().apply {
                put("role", "user")
                put("parts", JSONArray().put(JSONObject().put("text", fullPrompt)))
            }
        )

        val rawReply = executeWithEndpointFallback(contentsArray, temperature = 0.35)
        processCommandTags(appCtx, rawReply, userTranscript = userQuery)
    }

    suspend fun askGeminiText(context: Context, userQuery: String): String {
        return askGeminiTextTurn(context, userQuery).displayText
    }

    suspend fun askGeminiAudioTurn(context: Context, wavBytes: ByteArray): GeminiTurnResult = withContext(Dispatchers.IO) {
        val appCtx = context.applicationContext
        try {
            OutageRepository.refreshIfNeeded(appCtx, force = false)
        } catch (_: Exception) {
        }
        val audioPrompt = buildCommandInstruction(appCtx) +
            "\n\nПрослушай голосовую реплику пользователя (на украинском, русском, суржике или английском). " +
            "Если на записи только тишина или фоновый шум без речи — ответь ровно одним словом: [SILENCE]. " +
            "Иначе в самом начале ответа напиши тег [USER_SAID:точная краткая расшифровка слов пользователя], затем тег режима ([MODE:ONE_SHOT] или [MODE:DIALOG]), теги команд [CMD:...] (если нужны) и свой ответ."

        val b64Audio = Base64.encodeToString(wavBytes, Base64.NO_WRAP)
        val partsArray = JSONArray()
            .put(JSONObject().put("text", audioPrompt))
            .put(JSONObject().put("inlineData", JSONObject().apply {
                put("mimeType", "audio/wav")
                put("data", b64Audio)
            }))

        val contentsArray = JSONArray().put(
            JSONObject().apply {
                put("role", "user")
                put("parts", partsArray)
            }
        )

        val rawReply = executeWithEndpointFallback(contentsArray, temperature = 0.3)
        if (rawReply.contains("[SILENCE]")) {
            return@withContext GeminiTurnResult(
                displayText = "✦ Не расслышал речь. Скажите запрос в микрофон.",
                shouldContinueDialog = false,
                isSilence = true
            )
        }
        processCommandTags(appCtx, rawReply, userTranscript = "")
    }

    suspend fun askGeminiAudio(context: Context, wavBytes: ByteArray): String {
        return askGeminiAudioTurn(context, wavBytes).displayText
    }

    private fun processCommandTags(context: Context, reply: String, userTranscript: String): GeminiTurnResult {
        var clean = reply.trim()
        var extractedUserSaid = userTranscript.trim()

        val saidRegex = Regex("\\[USER_SAID:([^\\]]+)\\]")
        val saidMatch = saidRegex.find(clean)
        if (saidMatch != null) {
            if (extractedUserSaid.isEmpty()) {
                extractedUserSaid = saidMatch.groupValues[1].trim()
            }
            clean = clean.replace(saidMatch.value, "").trim()
        }

        var modeIsDialog = false
        var modeExplicitlyOneShot = false
        val modeRegex = Regex("\\[MODE:([^\\]]+)\\]")
        for (mm in modeRegex.findAll(clean).toList()) {
            val modeVal = mm.groupValues[1].trim().uppercase(Locale.US)
            if (modeVal.contains("DIALOG")) {
                modeIsDialog = true
            } else if (modeVal.contains("ONE_SHOT") || modeVal.contains("SINGLE")) {
                modeExplicitlyOneShot = true
            }
            clean = clean.replace(mm.value, "").trim()
        }

        val cmdRegex = Regex("\\[CMD:([^\\]]+)\\]")
        val matches = cmdRegex.findAll(clean).toList()

        var hasAnyCommand = false
        var explicitStopDialog = false
        val isErrorReply = clean.startsWith("Ошибка ответа Gemini") || clean.startsWith("Не удалось связаться")

        if (matches.isNotEmpty()) {
            hasAnyCommand = true
            val handler = Handler(Looper.getMainLooper())
            for (m in matches) {
                clean = clean.replace(m.value, "").trim()
                val tagContent = m.groupValues[1]
                val parts = tagContent.split(":", limit = 2)
                val action = parts[0].trim().uppercase(Locale.US)
                val arg = parts.getOrNull(1)?.trim().orEmpty()

                if (action == "STOP_DIALOG") {
                    explicitStopDialog = true
                }
                if (action == "CLEAR_MEMORY") {
                    clearConversationHistory()
                }

                handler.post {
                    when (action) {
                        "SPOTIFY" -> if (arg.isNotEmpty()) {
                            LocalVoiceCommandRouter.launchSpotifyTrackOrArtist(context, arg)
                        }
                        "KICK" -> {
                            val slug = if (arg.lowercase().contains("kalatay") || arg.lowercase().contains("калатай")) {
                                "kalatay3"
                            } else {
                                arg
                            }
                            LocalVoiceCommandRouter.launchKickStream(context, slug)
                        }
                        "YT" -> if (arg.isNotEmpty()) {
                            LocalVoiceCommandRouter.launchYouTubeSearch(context, arg)
                        }
                        "COLOR" -> if (arg.isNotEmpty()) {
                            LocalVoiceCommandRouter.applyThemeColorEverywhere(context, arg)
                        }
                        "LAUNCH" -> if (arg.isNotEmpty()) {
                            MediaStateBus.onMediaAppOpened(arg)
                            AppLauncher(context).launchPackage(arg)
                        }
                        "SETTINGS" -> LocalVoiceCommandRouter.openSystemSettingsAction(context, Settings.ACTION_SETTINGS)
                        "WIFI" -> LocalVoiceCommandRouter.openSystemSettingsAction(context, Settings.ACTION_WIFI_SETTINGS)
                        "BLUETOOTH" -> LocalVoiceCommandRouter.openSystemSettingsAction(context, Settings.ACTION_BLUETOOTH_SETTINGS)
                        "URL" -> if (arg.isNotEmpty()) {
                            LocalVoiceCommandRouter.launchUrlInTvBrowser(context, arg)
                        }
                        "VOL_SET" -> {
                            val pct = arg.toIntOrNull()
                            if (pct != null) {
                                LocalVoiceCommandRouter.setVolumePercent(context, pct)
                            }
                        }
                        "VOL_UP", "VOL_DOWN", "MUTE", "UNMUTE", "PAUSE", "PLAY", "NEXT", "PREV" -> {
                            LocalVoiceCommandRouter.executeSystemAudioCommand(context, action)
                        }
                        "BOOST" -> LocalVoiceCommandRouter.cleanRamBackground(context)
                        "NAV_SOUND" -> {
                            val enable = !arg.uppercase(Locale.US).contains("OFF")
                            NavSoundPlayer.setSoundEnabled(context, enable)
                        }
                        "TTS" -> {
                            val enable = !arg.uppercase(Locale.US).contains("OFF")
                            AssistantVoiceSpeaker.setTtsEnabled(context, enable)
                        }
                        "VOICE" -> if (arg.isNotEmpty()) {
                            AssistantVoiceSpeaker.setVoiceName(context, arg)
                            AssistantVoiceSpeaker.setTtsEnabled(context, true)
                        }
                        "OUTAGE_OPEN" -> {
                            OutageRepository.onOpenScheduleRequested?.invoke()
                        }
                        "OUTAGE_GROUP" -> if (arg.isNotEmpty()) {
                            OutageRepository.setSelectedGroup(context, arg)
                        }
                        "TYPE" -> if (arg.isNotEmpty()) {
                            TvUiControllerBus.typeText(arg)
                        }
                        "CLICK" -> if (arg.isNotEmpty()) {
                            TvUiControllerBus.clickByText(arg)
                        }
                        "NAV" -> if (arg.isNotEmpty()) {
                            TvUiControllerBus.performNav(arg)
                        }
                    }
                }
            }
            val finalClean = clean.removePrefix("✦").trim().ifEmpty { "Готово" }
            if (!isErrorReply) {
                appendTurnToHistory(extractedUserSaid, finalClean)
            }
            val continueAfterCmd = modeIsDialog && !modeExplicitlyOneShot && !explicitStopDialog && !isErrorReply && finalClean.endsWith("?")
            return GeminiTurnResult(
                displayText = "✦ $finalClean",
                shouldContinueDialog = continueAfterCmd
            )
        }

        if (!isErrorReply) {
            appendTurnToHistory(extractedUserSaid, clean)
        }
        val shouldContinue = (modeIsDialog || (!modeExplicitlyOneShot && clean.endsWith("?"))) && !hasAnyCommand && !explicitStopDialog && !isErrorReply
        return GeminiTurnResult(
            displayText = clean,
            shouldContinueDialog = shouldContinue
        )
    }

    private fun executeWithEndpointFallback(contentsArray: JSONArray, temperature: Double): String {
        val primaryKey = LauncherConfig.DEFAULT_GEMINI_API_KEY
        val endpointTemplate = "https://generativelanguage.googleapis.com/v1beta/models/%s:generateContent"

        val cModel = cachedModelName
        if (cModel != null) {
            val urlStr = String.format(Locale.US, endpointTemplate, cModel)
            val bodyStr = buildPayloadForModel(contentsArray, cModel, temperature)
            val res = trySingleRequest(urlStr, primaryKey, cachedUseHeaderAuth, bodyStr)
            val cachedTxt = res.text
            if (res.isSuccess && !cachedTxt.isNullOrBlank()) {
                return cachedTxt
            }
        }

        var firstMeaningfulError = ""
        var lastError = ""

        for (model in candidateModels) {
            val urlStr = String.format(Locale.US, endpointTemplate, model)
            val bodyStr = buildPayloadForModel(contentsArray, model, temperature)
            val res = trySingleRequest(urlStr, primaryKey, useHeaderAuth = false, jsonBody = bodyStr)
            val txt = res.text
            if (res.isSuccess && !txt.isNullOrBlank()) {
                cachedModelName = model
                cachedUseHeaderAuth = false
                return txt
            }
            if (res.errorSummary == "HTTP 400" && model.startsWith("gemini-2.5-flash")) {
                val plainBody = buildPayloadForModel(contentsArray, "gemini-2.0-flash", temperature)
                val retryRes = trySingleRequest(urlStr, primaryKey, useHeaderAuth = false, jsonBody = plainBody)
                val retryTxt = retryRes.text
                if (retryRes.isSuccess && !retryTxt.isNullOrBlank()) {
                    cachedModelName = model
                    cachedUseHeaderAuth = false
                    return retryTxt
                }
            }
            if (res.errorSummary.isNotBlank()) {
                lastError = res.errorSummary
                if (firstMeaningfulError.isBlank() && res.errorSummary != "HTTP 404") {
                    firstMeaningfulError = res.errorSummary
                }
            }
        }

        val discoveredModels = discoverAvailableModels(primaryKey)
        for (model in discoveredModels) {
            if (model in candidateModels) continue
            val urlStr = String.format(Locale.US, endpointTemplate, model)
            val bodyStr = buildPayloadForModel(contentsArray, "gemini-2.0-flash", temperature)
            val res = trySingleRequest(urlStr, primaryKey, useHeaderAuth = false, jsonBody = bodyStr)
            val txt = res.text
            if (res.isSuccess && !txt.isNullOrBlank()) {
                cachedModelName = model
                cachedUseHeaderAuth = false
                return txt
            } else if (res.errorSummary.isNotBlank() && firstMeaningfulError.isBlank() && res.errorSummary != "HTTP 404") {
                firstMeaningfulError = res.errorSummary
            }
        }

        val finalErr = firstMeaningfulError.ifBlank { lastError }
        return if (finalErr.isNotBlank()) {
            "Ошибка ответа Gemini ($finalErr)"
        } else {
            "Не удалось связаться с Gemini. Проверьте интернет-соединение."
        }
    }

    private fun discoverAvailableModels(apiKey: String): List<String> {
        var conn: HttpURLConnection? = null
        return try {
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models?key=${Uri.encode(apiKey)}")
            val connection = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "GET"
                connectTimeout = 5000
                readTimeout = 7000
                doInput = true
            }
            conn = connection
            if (connection.responseCode !in 200..299) return emptyList()
            val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
            val root = JSONObject(body)
            val modelsArr = root.optJSONArray("models") ?: return emptyList()
            val flashModels = mutableListOf<String>()
            val otherModels = mutableListOf<String>()
            for (i in 0 until modelsArr.length()) {
                val obj = modelsArr.optJSONObject(i) ?: continue
                val name = obj.optString("name", "").removePrefix("models/").trim()
                if (name.isEmpty() || name.contains("embedding") || name.contains("imagen") || name.contains("tts") || name.contains("aqa")) continue
                val methods = obj.optJSONArray("supportedGenerationMethods")
                var supportsGenerate = false
                if (methods != null) {
                    for (j in 0 until methods.length()) {
                        if (methods.optString(j) == "generateContent") {
                            supportsGenerate = true
                            break
                        }
                    }
                }
                if (supportsGenerate) {
                    if (name.contains("flash")) {
                        flashModels.add(name)
                    } else if (name.startsWith("gemini")) {
                        otherModels.add(name)
                    }
                }
            }
            flashModels + otherModels
        } catch (_: Exception) {
            emptyList()
        } finally {
            try {
                conn?.disconnect()
            } catch (_: Exception) {
            }
        }
    }

    private data class HttpResult(
        val isSuccess: Boolean,
        val text: String? = null,
        val errorSummary: String = ""
    )

    private fun trySingleRequest(
        baseUrl: String,
        apiKey: String,
        useHeaderAuth: Boolean,
        jsonBody: String
    ): HttpResult {
        var conn: HttpURLConnection? = null
        return try {
            val finalUrl = if (useHeaderAuth) {
                baseUrl
            } else {
                "$baseUrl?key=${Uri.encode(apiKey)}"
            }
            val connection = (URL(finalUrl).openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 6000
                readTimeout = 12000
                doOutput = true
                doInput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("Connection", "keep-alive")
                if (useHeaderAuth) {
                    setRequestProperty("x-goog-api-key", apiKey)
                }
            }
            conn = connection
            connection.outputStream.use { os ->
                os.write(jsonBody.toByteArray(Charsets.UTF_8))
            }
            val code = connection.responseCode
            if (code in 200..299) {
                val body = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                val parsed = extractTextFromGeminiJson(body)
                if (!parsed.isNullOrBlank()) {
                    HttpResult(isSuccess = true, text = parsed)
                } else {
                    HttpResult(isSuccess = false, errorSummary = "Empty response")
                }
            } else {
                HttpResult(isSuccess = false, errorSummary = "HTTP $code")
            }
        } catch (e: Exception) {
            HttpResult(isSuccess = false, errorSummary = e.javaClass.simpleName)
        } finally {
            try {
                conn?.disconnect()
            } catch (_: Exception) {
            }
        }
    }

    private fun extractTextFromGeminiJson(rawJson: String): String? {
        return try {
            val root = JSONObject(rawJson)
            val candidates = root.optJSONArray("candidates") ?: return null
            if (candidates.length() == 0) return null
            val content = candidates.optJSONObject(0)?.optJSONObject("content") ?: return null
            val parts = content.optJSONArray("parts") ?: return null
            val sb = StringBuilder()
            val fallbackSb = StringBuilder()
            for (i in 0 until parts.length()) {
                val partObj = parts.optJSONObject(i) ?: continue
                val t = partObj.optString("text", "")
                if (t.isNotBlank()) {
                    if (partObj.optBoolean("thought", false)) {
                        if (fallbackSb.isNotEmpty()) fallbackSb.append(" ")
                        fallbackSb.append(t.trim())
                    } else {
                        if (sb.isNotEmpty()) sb.append(" ")
                        sb.append(t.trim())
                    }
                }
            }
            val chosen = if (sb.isNotEmpty()) sb.toString() else fallbackSb.toString()
            chosen.replace("**", "").replace("*", "").trim()
        } catch (_: Exception) {
            null
        }
    }
}
