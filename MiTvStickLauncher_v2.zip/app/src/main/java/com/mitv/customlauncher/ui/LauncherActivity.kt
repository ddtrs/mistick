package com.mitv.customlauncher.ui

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.app.ActivityManager
import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Outline
import android.graphics.PorterDuff
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.mitv.customlauncher.R
import com.mitv.customlauncher.data.AppLauncher
import com.mitv.customlauncher.data.AssistantState
import com.mitv.customlauncher.data.CardSlot
import com.mitv.customlauncher.data.ClockFormatter
import com.mitv.customlauncher.data.IconStylizer
import com.mitv.customlauncher.data.InstalledAppInfo
import com.mitv.customlauncher.data.LauncherConfig
import com.mitv.customlauncher.data.NetworkMonitor
import com.mitv.customlauncher.data.NetworkStatus
import com.mitv.customlauncher.data.DayOutageSchedule
import com.mitv.customlauncher.data.OutageRepository
import com.mitv.customlauncher.data.OutageUiSnapshot
import com.mitv.customlauncher.databinding.ActivityLauncherBinding
import com.mitv.customlauncher.presentation.LauncherUiEvent
import com.mitv.customlauncher.presentation.LauncherViewModel
import com.mitv.customlauncher.data.LocalVoiceCommandRouter
import com.mitv.customlauncher.service.DynamicIslandBus
import com.mitv.customlauncher.service.NavSoundPlayer
import com.mitv.customlauncher.service.KeyCaptureBus
import com.mitv.customlauncher.service.KeyMapperAccessibilityService
import com.mitv.customlauncher.service.MediaStateBus
import com.mitv.customlauncher.service.NowPlayingSnapshot
import com.mitv.customlauncher.service.ServiceAutoActivator
import com.mitv.customlauncher.service.VolumeHudBus
import android.widget.FrameLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class LauncherActivity : ComponentActivity() {

    private lateinit var binding: ActivityLauncherBinding
    private lateinit var burnInProtector: BurnInProtector
    private lateinit var iconStylizer: IconStylizer
    private lateinit var appLauncherDirect: AppLauncher
    private lateinit var audioManager: AudioManager
    private var wifiManager: WifiManager? = null

    private val focusAnimators = mutableMapOf<View, ObjectAnimator>()
    private val decelerateInterpolator = DecelerateInterpolator()

    private var lastFocusedMainCard: View? = null
    private var selectedManageApp: InstalledAppInfo? = null
    private var returnToLauncherSettingsAfterAssign: Boolean = false

    private var currentAccentColor: Int = Color.parseColor("#00F0FF")
    private var isOutageShowingTomorrow: Boolean = false
    private var volumeHudHideJob: Job? = null

    private var pendingPresetId: String? = null
    private var pendingKeyDisplayName: String = ""
    private var capturedKeyCode = 0
    private var capturedScanCode = 0

    private val viewModel: LauncherViewModel by viewModels {
        LauncherViewModel.Factory(
            appLauncher = AppLauncher(applicationContext),
            networkMonitor = NetworkMonitor(applicationContext),
            demoReplyText = getString(R.string.fake_ai_demo_response)
        )
    }

    private val audioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            DynamicIslandBus.triggerAssistant(this)
        }
    }

    private val timeChangeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            viewModel.refreshTimeAndDate(forceDate = true)
        }
    }

    private val volumeChangeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            refreshSoundTileState()
            if (!KeyMapperAccessibilityService.isServiceConnectedAlive) {
                showCustomVolumeHud()
            }
        }
    }

    private val mediaBroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            if (intent.hasExtra("playing")) {
                MediaStateBus.updatePlayingFlag(intent.getBooleanExtra("playing", false))
            } else if (intent.hasExtra("playstate")) {
                MediaStateBus.updatePlayingFlag(intent.getBooleanExtra("playstate", false))
            }
            val track = intent.getStringExtra("track")
                ?: intent.getStringExtra("title")
                ?: intent.getStringExtra("android.intent.extra.TITLE")
                ?: ""
            val artist = intent.getStringExtra("artist")
                ?: intent.getStringExtra("album")
                ?: ""
            val duration = intent.getLongExtra("duration", -1L)
            val position = intent.getLongExtra("position", -1L)
            val pkg = intent.`package` ?: ""
            if (track.isNotEmpty() || artist.isNotEmpty()) {
                MediaStateBus.updateMetadata(
                    title = track,
                    artist = artist,
                    sourcePackage = pkg,
                    sourceAppName = if (pkg.isNotEmpty()) pkg.substringAfterLast('.') else "",
                    cover = null,
                    durationMs = duration,
                    positionMs = position
                )
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLauncherBinding.inflate(layoutInflater)
        setContentView(binding.root)

        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        appLauncherDirect = AppLauncher(applicationContext)
        iconStylizer = IconStylizer(applicationContext)
        burnInProtector = BurnInProtector(
            targetView = binding.contentContainer,
            density = resources.displayMetrics.density
        )

        currentAccentColor = try {
            Color.parseColor(appLauncherDirect.getAccentColorHex())
        } catch (_: Exception) {
            Color.parseColor("#00F0FF")
        }

        binding.tvNowPlayingTitle.isSelected = true

        val cornerPx = 12f * resources.displayMetrics.density
        binding.ivNowPlayingArt.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, cornerPx)
            }
        }
        binding.ivNowPlayingArt.clipToOutline = true

        VolumeHudBus.onVolumeIntercepted = {
            refreshSoundTileState()
            if (!KeyMapperAccessibilityService.isServiceConnectedAlive) {
                showCustomVolumeHud()
            }
        }

        DynamicIslandBus.onRequestAudioPermissionInActivity = {
            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }

        DynamicIslandBus.onIslandVisibilityChanged = { islandExpanded ->
            if (binding.controlCenterPanel.visibility != View.VISIBLE) {
                binding.bottomLeftPillsRow.visibility = if (islandExpanded) View.INVISIBLE else View.VISIBLE
            }
        }

        OutageRepository.onOpenScheduleRequested = {
            if (binding.outageSchedulePanel.visibility != View.VISIBLE) {
                openOutageSchedulePanel(lastFocusedMainCard ?: binding.cardYoutube)
            }
        }

        LocalVoiceCommandRouter.onThemeColorChanged = { hex ->
            try {
                currentAccentColor = Color.parseColor(hex)
                applyAccentColorTheme()
                DynamicIslandBus.notifyAccentColorChanged(hex)
            } catch (_: Exception) {
            }
        }

        window.decorView.isSoundEffectsEnabled = false
        NavSoundPlayer.init(this)
        ServiceAutoActivator.ensureServicesActive(this)

        setupMainCardsAndCornerPill()
        setupNowPlayingHoverControls()
        setupControlCenterPanel()
        setupOutageSchedulePanel()
        setupLauncherSettingsOverlay()
        setupAppManageOverlay()
        setupRemoteKeySelectOverlay()
        applyAccentColorTheme()
        observeStateAndLifecycle()

        binding.cardYoutube.requestFocus()
        handleIncomingIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        ServiceAutoActivator.ensureServicesActive(this)
        viewModel.reloadInstalledApps()
        updateAccessibilityStatusRow()
        MediaStateBus.pollActiveControllerLight(this)
        lifecycleScope.launch { OutageRepository.refreshIfNeeded(this@LauncherActivity, force = false) }
        if (binding.controlCenterPanel.visibility == View.VISIBLE) {
            refreshControlCenterToggles()
        }
    }

    override fun onDestroy() {
        VolumeHudBus.onVolumeIntercepted = null
        DynamicIslandBus.onRequestAudioPermissionInActivity = null
        DynamicIslandBus.onIslandVisibilityChanged = null
        OutageRepository.onOpenScheduleRequested = null
        KeyCaptureBus.isCapturingKey = false
        KeyCaptureBus.onKeyCapturedListener = null
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        burnInProtector.onUserInteraction(lifecycleScope)
        silentCleanBackgroundProcesses()
        if (handleIncomingIntent(intent)) {
            return
        }
        closeAllOverlays(restoreFocus = false)
        viewModel.onHomeIntentReceived()
    }

    private fun handleIncomingIntent(intent: Intent?): Boolean {
        if (intent == null) return false
        val action = intent.action
        if (action == Intent.ACTION_ASSIST ||
            action == Intent.ACTION_VOICE_COMMAND ||
            action == Intent.ACTION_SEARCH_LONG_PRESS ||
            intent.getBooleanExtra("EXTRA_OPEN_AI", false)
        ) {
            intent.removeExtra("EXTRA_OPEN_AI")
            closeAllOverlays(restoreFocus = false)
            triggerGeminiDynamicIsland()
            return true
        }
        if (intent.getBooleanExtra("EXTRA_OPEN_CONTROL_CENTER", false)) {
            intent.removeExtra("EXTRA_OPEN_CONTROL_CENTER")
            if (binding.controlCenterPanel.visibility == View.VISIBLE) {
                hideControlCenter(restoreFocus = true)
            } else {
                closeAllOverlays(restoreFocus = false)
                openControlCenter(lastFocusedMainCard ?: binding.cardYoutube)
            }
            return true
        }
        if (intent.getBooleanExtra("EXTRA_OPEN_ALL_APPS", false)) {
            intent.removeExtra("EXTRA_OPEN_ALL_APPS")
            closeAllOverlays(restoreFocus = false)
            openAppPickerOverlay(assignSlot = null, forKeyBind = false)
            return true
        }
        return false
    }

    private fun dpPx(dpVal: Float): Int = (dpVal * resources.displayMetrics.density + 0.5f).toInt()

    private fun createCardSelectorDrawable(accent: Int): StateListDrawable {
        val focused = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(20f).toFloat()
            setColor(Color.parseColor("#20222A"))
            setStroke(dpPx(2.5f), accent)
        }
        val idle = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(20f).toFloat()
            setColor(Color.parseColor("#16171B"))
            setStroke(dpPx(1f), Color.parseColor("#23252C"))
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(android.R.attr.state_selected), focused)
            addState(intArrayOf(), idle)
        }
    }

    private fun createMenuSelectorDrawable(accent: Int): StateListDrawable {
        val focused = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(14f).toFloat()
            setColor(ColorUtils.setAlphaComponent(accent, 36))
            setStroke(dpPx(2f), accent)
        }
        val idle = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(14f).toFloat()
            setColor(Color.parseColor("#1B1D24"))
            setStroke(dpPx(1f), Color.parseColor("#2A2D37"))
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(android.R.attr.state_selected), focused)
            addState(intArrayOf(), idle)
        }
    }

    private fun createMediaBtnSelectorDrawable(accent: Int): StateListDrawable {
        val focused = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(10f).toFloat()
            setColor(ColorUtils.setAlphaComponent(accent, 42))
            setStroke(dpPx(1.5f), accent)
        }
        val idle = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(10f).toFloat()
            setColor(Color.parseColor("#1B1D24"))
            setStroke(dpPx(1f), Color.parseColor("#2A2D37"))
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(), idle)
        }
    }

    private fun createCornerPillSelectorDrawable(accent: Int): StateListDrawable {
        val focused = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(22f).toFloat()
            setColor(ColorUtils.setAlphaComponent(accent, 38))
            setStroke(dpPx(2f), accent)
        }
        val idle = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(22f).toFloat()
            setColor(Color.parseColor("#14151A"))
            setStroke(dpPx(1f), Color.parseColor("#282B34"))
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(), idle)
        }
    }

    private fun createToggleDrawable(accent: Int, isActive: Boolean): StateListDrawable {
        val baseFill = if (isActive) ColorUtils.setAlphaComponent(accent, 38) else Color.parseColor("#181A20")
        val baseStroke = if (isActive) ColorUtils.setAlphaComponent(accent, 140) else Color.parseColor("#262932")
        val focused = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(16f).toFloat()
            setColor(if (isActive) ColorUtils.setAlphaComponent(accent, 64) else Color.parseColor("#22252E"))
            setStroke(dpPx(2f), accent)
        }
        val idle = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(16f).toFloat()
            setColor(baseFill)
            setStroke(dpPx(1f), baseStroke)
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(), idle)
        }
    }

    private fun createPanelDrawable(accent: Int, radiusDp: Float): Drawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(radiusDp).toFloat()
            setColor(Color.parseColor("#F2101115"))
            setStroke(dpPx(1.5f), ColorUtils.setAlphaComponent(accent, 190))
        }
    }

    /**
     * Динамическое применение выбранного цвета обводки и акцентов ко всему лаунчеру на лету!
     */
    private fun applyAccentColorTheme() {
        val accent = currentAccentColor

        binding.cardYoutube.background = createCardSelectorDrawable(accent)
        binding.cardBrowser.background = createCardSelectorDrawable(accent)
        binding.cardCast.background = createCardSelectorDrawable(accent)
        binding.cardAi.background = createCardSelectorDrawable(accent)

        binding.statusCornerPill.background = createCornerPillSelectorDrawable(accent)
        binding.outageCornerPill.background = createCornerPillSelectorDrawable(accent)
        binding.ivWifiCorner.setColorFilter(accent, PorterDuff.Mode.SRC_IN)
        binding.ivControlCenterIcon.setColorFilter(accent, PorterDuff.Mode.SRC_IN)
        binding.outageSchedulePanel.background = createPanelDrawable(accent, 22f)
        binding.btnOutageQueue.background = createMenuItemSelectorDrawable(accent)
        renderOutageWidgetAndPanel(OutageRepository.state.value)

        updateNowPlayingCardHoverBorder(isAnyPlayerButtonFocused())
        binding.ivNowPlayingArt.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(12f).toFloat()
            setColor(ColorUtils.setAlphaComponent(accent, 22))
        }

        binding.volumeHudCard.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(999f).toFloat()
            setColor(Color.parseColor("#F20D0F14"))
            setStroke(dpPx(1.5f), ColorUtils.setAlphaComponent(accent, 140))
        }
        binding.vVolumeHudFill.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(999f).toFloat()
            setColor(accent)
        }

        binding.controlCenterPanel.background = createPanelDrawable(accent, 22f)
        binding.llLauncherSettingsPanel.background = createPanelDrawable(accent, 22f)
        binding.llAppManagePanel.background = createPanelDrawable(accent, 22f)
        binding.llRemoteKeyPanel.background = createPanelDrawable(accent, 22f)
        binding.llKeyCapturePanel.background = createPanelDrawable(accent, 22f)
        binding.llAppPickerPanel.background = createPanelDrawable(accent, 22f)
        binding.llAssistantPanel.background = createPanelDrawable(accent, 22f)

        binding.tvLauncherSettingsTitle.setTextColor(accent)
        binding.tvPickerTitle.setTextColor(accent)
        binding.tvAppManageTitle.setTextColor(accent)
        binding.tvRemoteKeyTitle.setTextColor(accent)
        binding.tvKeyCaptureTitle.setTextColor(accent)
        binding.tvOverlayTitle.setTextColor(accent)
        binding.ivOverlayMic.setColorFilter(accent, PorterDuff.Mode.SRC_IN)

        val menuButtons = listOf(
            binding.btnMenuAllApps,
            binding.btnMenuAssignCurrent,
            binding.btnMenuBindKey,
            binding.btnMenuSystemSettings,
            binding.btnEditSlot1,
            binding.btnEditSlot2,
            binding.btnEditSlot3,
            binding.btnEditSlot4,
            binding.btnToggleNavSound,
            binding.btnColorCyan,
            binding.btnColorEmerald,
            binding.btnColorAmber,
            binding.btnColorSapphire,
            binding.btnColorAmethyst,
            binding.btnColorSilver,
            binding.btnAppManageOpen,
            binding.btnAppManageUninstall,
            binding.btnAppManageInfo,
            binding.btnKeyEnableAccessibility,
            binding.btnKeyPresetPatchwall,
            binding.btnKeyPresetNetflix,
            binding.btnKeyPresetPrime,
            binding.btnKeyCustomListen
        )
        menuButtons.forEach { btn ->
            btn.background = createMenuSelectorDrawable(accent)
        }

        binding.btnNpPrev.background = createMediaBtnSelectorDrawable(accent)
        binding.btnNpPlayPause.background = createMediaBtnSelectorDrawable(accent)
        binding.btnNpNext.background = createMediaBtnSelectorDrawable(accent)
        binding.btnNpClose.background = createMediaBtnSelectorDrawable(Color.parseColor("#FF5252"))

        binding.tvNowPlayingTime.setTextColor(accent)
        binding.vNowPlayingVisualizer.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(3f).toFloat()
            setColor(accent)
        }

        // Обновляем тинт иконок на главных карточках
        val cardPairs = listOf(
            binding.cardYoutube to binding.ivCard1,
            binding.cardBrowser to binding.ivCard2,
            binding.cardCast to binding.ivCard3,
            binding.cardAi to binding.ivCardAi
        )
        cardPairs.forEach { (card, icon) ->
            val tint = if (card.hasFocus()) accent else getColor(R.color.text_primary)
            icon.setColorFilter(tint, PorterDuff.Mode.SRC_IN)
        }

        refreshControlCenterToggles()
        renderNowPlayingWidget(MediaStateBus.state.value)
    }

    private fun setupNowPlayingHoverControls() {
        val npButtons = listOf(
            binding.btnNpPrev to binding.ivNpPrev,
            binding.btnNpPlayPause to binding.ivNpPlayPause,
            binding.btnNpNext to binding.ivNpNext,
            binding.btnNpClose to binding.ivNpClose
        )

        npButtons.forEach { (btn, icon) ->
            icon.setColorFilter(getColor(R.color.text_primary), PorterDuff.Mode.SRC_IN)
            btn.setOnFocusChangeListener { _, hasFocus ->
                val tint = if (hasFocus) {
                    if (btn.id == R.id.btnNpClose) getColor(R.color.status_error) else currentAccentColor
                } else {
                    getColor(R.color.text_primary)
                }
                icon.setColorFilter(tint, PorterDuff.Mode.SRC_IN)
                if (hasFocus) {
                    binding.llNowPlayingControls.visibility = View.VISIBLE
                    updateNowPlayingCardHoverBorder(true)
                } else {
                    binding.nowPlayingCard.post {
                        if (!isAnyPlayerButtonFocused()) {
                            updateNowPlayingCardHoverBorder(false)
                        }
                    }
                }
            }
        }

        binding.btnNpPrev.setOnClickListener {
            MediaStateBus.dispatchTransportAction("PREV", audioManager)
            lifecycleScope.launch {
                delay(250L)
                MediaStateBus.pollActiveControllerLight(this@LauncherActivity)
            }
        }

        binding.btnNpPlayPause.setOnClickListener {
            MediaStateBus.dispatchTransportAction("PLAY_PAUSE", audioManager)
            val nowPlaying = MediaStateBus.state.value.isPlaying
            binding.ivNpPlayPause.setImageResource(
                if (nowPlaying) R.drawable.ic_media_pause else R.drawable.ic_media_play
            )
            updateLiveTrackProgressTick()
        }

        binding.btnNpNext.setOnClickListener {
            MediaStateBus.dispatchTransportAction("NEXT", audioManager)
            lifecycleScope.launch {
                delay(250L)
                MediaStateBus.pollActiveControllerLight(this@LauncherActivity)
            }
        }

        binding.btnNpClose.setOnClickListener {
            MediaStateBus.dismissPlayerByUser(audioManager)
            binding.llNowPlayingControls.visibility = View.GONE
            updateNowPlayingCardHoverBorder(false)
            binding.nowPlayingCard.visibility = View.GONE
            (lastFocusedMainCard ?: binding.cardYoutube).requestFocus()
        }
    }

    private fun isAnyPlayerButtonFocused(): Boolean {
        return binding.btnNpPrev.hasFocus() ||
            binding.btnNpPlayPause.hasFocus() ||
            binding.btnNpNext.hasFocus() ||
            binding.btnNpClose.hasFocus()
    }

    /**
     * Обводка вокруг плеера появляется ТОЛЬКО при наведении фокуса на трек!
     * В обычном режиме фон и рамка полностью прозрачные (#00000000).
     */
    private fun updateNowPlayingCardHoverBorder(isHovered: Boolean) {
        if (isHovered) {
            binding.nowPlayingCard.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpPx(16f).toFloat()
                setColor(Color.parseColor("#14FFFFFF"))
                setStroke(dpPx(1f), currentAccentColor)
            }
        } else {
            binding.nowPlayingCard.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpPx(16f).toFloat()
                setColor(Color.TRANSPARENT)
            }
        }
    }

    private fun handleCustomVolumeKey(keyCode: Int) {
        try {
            when (keyCode) {
                KeyEvent.KEYCODE_VOLUME_UP -> {
                    audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0)
                }
                KeyEvent.KEYCODE_VOLUME_DOWN -> {
                    audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0)
                }
                KeyEvent.KEYCODE_VOLUME_MUTE -> {
                    audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, 0)
                }
            }
        } catch (_: Exception) {
        }

        refreshSoundTileState()
        showCustomVolumeHud()
    }

    private fun showCustomVolumeHud() {
        val isMuted = try {
            audioManager.isStreamMute(AudioManager.STREAM_MUSIC)
        } catch (_: Exception) {
            false
        }
        val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val pct = if (isMuted) 0 else ((curVol * 100f) / maxVol).toInt().coerceIn(0, 100)

        binding.tvVolumeHudPct.text = "$pct%"
        val activeColor = if (pct > 0) currentAccentColor else getColor(R.color.status_error)
        binding.tvVolumeHudPct.setTextColor(activeColor)
        binding.ivVolumeHudIcon.setColorFilter(activeColor, PorterDuff.Mode.SRC_IN)
        binding.vVolumeHudFill.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(999f).toFloat()
            setColor(activeColor)
        }

        binding.flVolumeHudTrack.post {
            val totalW = binding.flVolumeHudTrack.width.coerceAtLeast(100)
            val fillW = ((totalW * pct) / 100).coerceAtLeast(if (pct > 0) 6 else 0)
            val lp = binding.vVolumeHudFill.layoutParams
            if (lp.width != fillW) {
                lp.width = fillW
                binding.vVolumeHudFill.layoutParams = lp
            }
        }

        val hud = binding.volumeHudCard
        if (hud.visibility != View.VISIBLE) {
            hud.alpha = 0f
            hud.visibility = View.VISIBLE
            hud.animate().alpha(1f).setDuration(110L).start()
        } else {
            hud.animate().cancel()
            hud.alpha = 1f
        }

        volumeHudHideJob?.cancel()
        volumeHudHideJob = lifecycleScope.launch {
            delay(1600L)
            hud.animate()
                .alpha(0f)
                .setDuration(180L)
                .withEndAction { hud.visibility = View.GONE }
                .start()
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            burnInProtector.onUserInteraction(lifecycleScope)
        }

        val keyCode = event.keyCode
        val scanCode = event.scanCode

        if (event.action == KeyEvent.ACTION_DOWN &&
            (isDpadDirectionKey(keyCode) || isCenterKey(keyCode) || keyCode == KeyEvent.KEYCODE_BACK)
        ) {
            NavSoundPlayer.playClick(this)
        }

        // Перехватываем громкость с флагом 0 (без штатного ползунка) и выводим наш капсульный HUD в стиле системы!
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
            keyCode == KeyEvent.KEYCODE_VOLUME_DOWN ||
            keyCode == KeyEvent.KEYCODE_VOLUME_MUTE
        ) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                handleCustomVolumeKey(keyCode)
            }
            return true
        }

        if (binding.keyCaptureOverlay.visibility == View.VISIBLE) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
                    stopLiveKeyCapture()
                    binding.remoteKeySelectOverlay.visibility = View.VISIBLE
                    binding.btnKeyCustomListen.requestFocus()
                    return true
                }
                if (!isDpadDirectionKey(keyCode) && !isCenterKey(keyCode)) {
                    onLiveKeyCaught(keyCode, scanCode)
                    return true
                }
            }
            return true
        }

        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                when {
                    binding.appManageOverlay.visibility == View.VISIBLE -> {
                        binding.appManageOverlay.visibility = View.GONE
                        binding.appPickerOverlay.visibility = View.VISIBLE
                        binding.llAppListContainer.requestFocus()
                    }
                    binding.appPickerOverlay.visibility == View.VISIBLE -> {
                        binding.appPickerOverlay.visibility = View.GONE
                        if (returnToLauncherSettingsAfterAssign) {
                            returnToLauncherSettingsAfterAssign = false
                            openLauncherSettingsOverlay()
                        } else {
                            openControlCenter(lastFocusedMainCard)
                        }
                    }
                    binding.launcherSettingsOverlay.visibility == View.VISIBLE -> {
                        binding.launcherSettingsOverlay.visibility = View.GONE
                        openControlCenter(lastFocusedMainCard)
                    }
                    binding.remoteKeySelectOverlay.visibility == View.VISIBLE -> {
                        binding.remoteKeySelectOverlay.visibility = View.GONE
                        openControlCenter(lastFocusedMainCard)
                    }
                    binding.outageSchedulePanel.visibility == View.VISIBLE -> {
                        hideOutageSchedulePanel(restoreFocus = true)
                    }
                    binding.controlCenterPanel.visibility == View.VISIBLE -> {
                        hideControlCenter(restoreFocus = true)
                    }
                    binding.assistantOverlay.visibility == View.VISIBLE -> {
                        viewModel.closeAssistantOverlay(restoreFocusToAi = true)
                    }
                }
            }
            return true
        }

        if (!isAnyOverlayOpen() &&
            keyCode == KeyEvent.KEYCODE_DPAD_LEFT &&
            event.action == KeyEvent.ACTION_DOWN &&
            event.repeatCount == 0 &&
            (currentFocus?.id == R.id.cardYoutube || currentFocus?.id == R.id.cardCast) &&
            binding.nowPlayingCard.visibility == View.VISIBLE
        ) {
            binding.llNowPlayingControls.visibility = View.VISIBLE
            updateNowPlayingCardHoverBorder(true)
            binding.llNowPlayingControls.post {
                binding.btnNpPlayPause.requestFocus()
            }
            return true
        }

        if (keyCode == KeyEvent.KEYCODE_VOICE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_SEARCH ||
            scanCode == 582 || scanCode == 217 || scanCode == 221
        ) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                val custom = appLauncherDirect.getKeyBinding(keyCode, scanCode)
                if (!custom.isNullOrEmpty()) {
                    executeCustomKeyTarget(custom)
                } else {
                    triggerGeminiDynamicIsland()
                }
            }
            return true
        }

        if (!isDpadDirectionKey(keyCode) && !isCenterKey(keyCode)) {
            val boundTarget = resolveLocalKeyOrPreset(keyCode, scanCode)
            if (!boundTarget.isNullOrEmpty()) {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                    executeCustomKeyTarget(boundTarget)
                }
                return true
            }
        }

        if (keyCode == KeyEvent.KEYCODE_MENU ||
            keyCode == KeyEvent.KEYCODE_ALL_APPS ||
            keyCode == KeyEvent.KEYCODE_GUIDE ||
            keyCode == KeyEvent.KEYCODE_SETTINGS ||
            keyCode == KeyEvent.KEYCODE_TV_INPUT
        ) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                if (binding.controlCenterPanel.visibility == View.VISIBLE) {
                    hideControlCenter(restoreFocus = true)
                } else {
                    openControlCenter(currentFocus)
                }
            }
            return true
        }

        return super.dispatchKeyEvent(event)
    }

    private fun isMainGridCardFocused(): Boolean {
        val id = currentFocus?.id ?: return false
        return id == R.id.cardYoutube ||
            id == R.id.cardBrowser ||
            id == R.id.cardCast ||
            id == R.id.cardAi
    }

    private fun resolveLocalKeyOrPreset(keyCode: Int, scanCode: Int): String? {
        if (keyCode == KeyEvent.KEYCODE_ALL_APPS ||
            keyCode == KeyEvent.KEYCODE_MENU ||
            keyCode == KeyEvent.KEYCODE_GUIDE ||
            keyCode == KeyEvent.KEYCODE_SETTINGS ||
            keyCode == KeyEvent.KEYCODE_TV_INPUT ||
            keyCode == KeyEvent.KEYCODE_BUTTON_1 ||
            scanCode == 139 || scanCode == 362 || scanCode == 172 || scanCode == 256
        ) {
            appLauncherDirect.getPresetBinding("PATCHWALL")?.let { if (it.isNotEmpty()) return it }
        }
        if (keyCode == KeyEvent.KEYCODE_BUTTON_2 || keyCode == KeyEvent.KEYCODE_PROG_RED || scanCode == 412 || scanCode == 398 || keyCode == 309) {
            appLauncherDirect.getPresetBinding("NETFLIX")?.let { if (it.isNotEmpty()) return it }
        }
        if (keyCode == KeyEvent.KEYCODE_BUTTON_3 || keyCode == KeyEvent.KEYCODE_PROG_BLUE || scanCode == 413 || scanCode == 401 || keyCode == 310) {
            appLauncherDirect.getPresetBinding("PRIME")?.let { if (it.isNotEmpty()) return it }
        }
        return appLauncherDirect.getKeyBinding(keyCode, scanCode)
    }

    private fun triggerMainCardShortClick(cardView: View?) {
        when (cardView?.id) {
            R.id.cardYoutube -> viewModel.onSlotCardClicked(CardSlot.SLOT_1)
            R.id.cardBrowser -> viewModel.onSlotCardClicked(CardSlot.SLOT_2)
            R.id.cardCast -> viewModel.onSlotCardClicked(CardSlot.SLOT_3)
            R.id.cardAi -> viewModel.onSlotCardClicked(CardSlot.SLOT_4)
        }
    }

    private fun triggerGeminiDynamicIsland() {
        if (!hasAudioPermission()) {
            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        DynamicIslandBus.triggerAssistant(this)
    }

    private fun executeCustomKeyTarget(target: String) {
        when (target) {
            "ACTION_CONTROL_CENTER" -> {
                if (binding.controlCenterPanel.visibility == View.VISIBLE) {
                    hideControlCenter(restoreFocus = true)
                } else {
                    closeAllOverlays(restoreFocus = false)
                    openControlCenter(lastFocusedMainCard ?: binding.cardYoutube)
                }
            }
            "ACTION_ALL_APPS" -> {
                closeAllOverlays(restoreFocus = false)
                openAppPickerOverlay(assignSlot = null, forKeyBind = false)
            }
            "ACTION_SETTINGS" -> {
                closeAllOverlays(restoreFocus = true)
                viewModel.launchSystemSettings()
            }
            "ACTION_AI" -> {
                closeAllOverlays(restoreFocus = false)
                triggerGeminiDynamicIsland()
            }
            else -> {
                MediaStateBus.onMediaAppOpened(target)
                closeAllOverlays(restoreFocus = true)
                appLauncherDirect.launchPackage(target)
            }
        }
    }

    private fun setupMainCardsAndCornerPill() {
        val cardPairs = listOf(
            binding.cardYoutube to binding.ivCard1,
            binding.cardBrowser to binding.ivCard2,
            binding.cardCast to binding.ivCard3,
            binding.cardAi to binding.ivCardAi
        )

        cardPairs.forEach { (card, iconView) ->
            val pvhX = PropertyValuesHolder.ofFloat(View.SCALE_X, LauncherConfig.FOCUS_IDLE_SCALE, LauncherConfig.FOCUS_SCALE)
            val pvhY = PropertyValuesHolder.ofFloat(View.SCALE_Y, LauncherConfig.FOCUS_IDLE_SCALE, LauncherConfig.FOCUS_SCALE)
            val animator = ObjectAnimator.ofPropertyValuesHolder(card, pvhX, pvhY).apply {
                duration = LauncherConfig.FOCUS_ANIM_DURATION_MS
                interpolator = decelerateInterpolator
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationStart(animation: Animator) {
                        card.setLayerType(View.LAYER_TYPE_HARDWARE, null)
                    }

                    override fun onAnimationEnd(animation: Animator) {
                        card.setLayerType(View.LAYER_TYPE_NONE, null)
                    }

                    override fun onAnimationCancel(animation: Animator) {
                        card.setLayerType(View.LAYER_TYPE_NONE, null)
                    }
                })
            }
            focusAnimators[card] = animator

            iconView.setColorFilter(getColor(R.color.text_primary), PorterDuff.Mode.SRC_IN)

            card.setOnFocusChangeListener { v, hasFocus ->
                val anim = focusAnimators[v] ?: return@setOnFocusChangeListener
                val iconTint = if (hasFocus) currentAccentColor else getColor(R.color.text_primary)
                iconView.setColorFilter(iconTint, PorterDuff.Mode.SRC_IN)
                if (hasFocus) {
                    lastFocusedMainCard = v
                    binding.llNowPlayingControls.visibility = View.GONE
                    updateNowPlayingCardHoverBorder(false)
                    anim.setFloatValues(v.scaleX, LauncherConfig.FOCUS_SCALE)
                    anim.start()
                } else {
                    anim.reverse()
                }
            }

            // Мгновенное открытие приложения по нажатию OK (без задержки долгого нажатия!)
            card.setOnClickListener {
                triggerMainCardShortClick(card)
            }
        }

        binding.statusCornerPill.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                binding.llNowPlayingControls.visibility = View.GONE
                updateNowPlayingCardHoverBorder(false)
            }
        }

        binding.statusCornerPill.setOnClickListener {
            openControlCenter(lastFocusedMainCard ?: binding.cardYoutube)
        }

        binding.statusCornerPill.setOnLongClickListener {
            triggerGeminiDynamicIsland()
            true
        }

        binding.outageCornerPill.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                binding.llNowPlayingControls.visibility = View.GONE
                updateNowPlayingCardHoverBorder(false)
            }
        }

        binding.outageCornerPill.setOnClickListener {
            if (binding.outageSchedulePanel.visibility == View.VISIBLE) {
                hideOutageSchedulePanel(restoreFocus = false)
            } else {
                openOutageSchedulePanel(lastFocusedMainCard ?: binding.cardYoutube)
            }
        }
    }

    private fun openControlCenter(sourceCard: View?) {
        if (sourceCard != null && isMainGridCardFocused()) {
            lastFocusedMainCard = sourceCard
        }
        hideOutageSchedulePanel(restoreFocus = false)
        refreshControlCenterToggles()

        binding.llNowPlayingControls.visibility = View.GONE
        binding.nowPlayingCard.visibility = View.INVISIBLE
        binding.bottomLeftPillsRow.visibility = View.INVISIBLE

        val panel = binding.controlCenterPanel
        if (panel.visibility != View.VISIBLE) {
            panel.alpha = 0f
            panel.translationY = 24f * resources.displayMetrics.density
            panel.visibility = View.VISIBLE
            panel.setLayerType(View.LAYER_TYPE_HARDWARE, null)
            panel.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(140L)
                .setInterpolator(decelerateInterpolator)
                .withEndAction {
                    panel.setLayerType(View.LAYER_TYPE_NONE, null)
                }
                .start()
        }
        binding.tileCcWifi.requestFocus()
    }

    private fun hideControlCenter(restoreFocus: Boolean) {
        val panel = binding.controlCenterPanel
        if (panel.visibility == View.VISIBLE) {
            panel.animate().cancel()
            panel.setLayerType(View.LAYER_TYPE_NONE, null)
            panel.visibility = View.GONE
        }
        binding.bottomLeftPillsRow.visibility = View.VISIBLE
        renderNowPlayingWidget(MediaStateBus.state.value)

        if (restoreFocus) {
            (lastFocusedMainCard ?: binding.cardYoutube).requestFocus()
        }
    }

    private fun openOutageSchedulePanel(sourceCard: View?) {
        if (sourceCard != null && isMainGridCardFocused()) {
            lastFocusedMainCard = sourceCard
        }
        if (binding.controlCenterPanel.visibility == View.VISIBLE) {
            hideControlCenter(restoreFocus = false)
        hideOutageSchedulePanel(restoreFocus = false)
        }
        binding.llNowPlayingControls.visibility = View.GONE
        binding.nowPlayingCard.visibility = View.INVISIBLE
        binding.bottomLeftPillsRow.visibility = View.VISIBLE

        isOutageShowingTomorrow = false
        OutageRepository.recomputeFromCachedJson(this)
        renderOutageWidgetAndPanel(OutageRepository.state.value)
        lifecycleScope.launch {
            OutageRepository.refreshIfNeeded(this@LauncherActivity, force = true)
        }

        val panel = binding.outageSchedulePanel
        if (panel.visibility != View.VISIBLE) {
            panel.alpha = 0f
            panel.translationY = 20f * resources.displayMetrics.density
            panel.visibility = View.VISIBLE
            panel.setLayerType(View.LAYER_TYPE_HARDWARE, null)
            panel.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(150L)
                .setInterpolator(decelerateInterpolator)
                .withEndAction {
                    panel.setLayerType(View.LAYER_TYPE_NONE, null)
                }
                .start()
        }
        binding.btnOutageTabToday.requestFocus()
    }

    private fun hideOutageSchedulePanel(restoreFocus: Boolean) {
        val panel = binding.outageSchedulePanel
        if (panel.visibility == View.VISIBLE) {
            panel.animate().cancel()
            panel.setLayerType(View.LAYER_TYPE_NONE, null)
            panel.visibility = View.GONE
        }
        renderNowPlayingWidget(MediaStateBus.state.value)
        if (restoreFocus) {
            binding.outageCornerPill.requestFocus()
        }
    }

    private fun setupOutageSchedulePanel() {
        binding.btnOutageTabToday.setOnClickListener {
            isOutageShowingTomorrow = false
            renderOutageWidgetAndPanel(OutageRepository.state.value)
        }
        binding.btnOutageTabToday.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus && isOutageShowingTomorrow) {
                isOutageShowingTomorrow = false
                renderOutageWidgetAndPanel(OutageRepository.state.value)
            } else {
                updateOutageTabStyles()
            }
        }

        binding.btnOutageTabTomorrow.setOnClickListener {
            isOutageShowingTomorrow = true
            renderOutageWidgetAndPanel(OutageRepository.state.value)
        }
        binding.btnOutageTabTomorrow.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus && !isOutageShowingTomorrow) {
                isOutageShowingTomorrow = true
                renderOutageWidgetAndPanel(OutageRepository.state.value)
            } else {
                updateOutageTabStyles()
            }
        }

        binding.btnOutageQueue.setOnClickListener {
            val nextGroup = OutageRepository.cycleNextGroup(this)
            renderOutageWidgetAndPanel(OutageRepository.state.value)
            Toast.makeText(this, "Черга ДТЕК: $nextGroup", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateOutageTabStyles() {
        val accent = currentAccentColor
        val todayActive = !isOutageShowingTomorrow
        binding.btnOutageTabToday.background = createToggleDrawable(accent, isActive = todayActive)
        binding.btnOutageTabToday.setTextColor(if (todayActive) Color.parseColor("#F3F4F6") else Color.parseColor("#9CA3AF"))

        binding.btnOutageTabTomorrow.background = createToggleDrawable(accent, isActive = !todayActive)
        binding.btnOutageTabTomorrow.setTextColor(if (!todayActive) Color.parseColor("#F3F4F6") else Color.parseColor("#9CA3AF"))
    }

    private fun renderOutageWidgetAndPanel(snapshot: OutageUiSnapshot) {
        val accent = currentAccentColor
        val boltColor = if (snapshot.isPowerOnNow) accent else Color.parseColor("#EF4444")

        binding.ivOutageCornerBolt.setColorFilter(boltColor, PorterDuff.Mode.SRC_IN)
        binding.tvOutageCornerText.text = snapshot.pillText
        binding.tvOutageCornerText.setTextColor(
            if (snapshot.isPowerOnNow) Color.parseColor("#F3F4F6") else Color.parseColor("#FCA5A5")
        )

        binding.ivOutageHeaderBolt.setColorFilter(boltColor, PorterDuff.Mode.SRC_IN)
        binding.tvOutageHeaderTitle.text = snapshot.headerTitle
        binding.tvOutageHeaderSub.text = snapshot.headerSubtitle
        binding.btnOutageQueue.text = "Черга ${snapshot.groupCode}"

        val todayLabel = if (snapshot.todaySchedule.dateLabelUk.isNotEmpty()) {
            "Сьогодні (${snapshot.todaySchedule.dateLabelUk})"
        } else {
            "Сьогодні"
        }
        val tomorrowLabel = if (snapshot.tomorrowSchedule.dateLabelUk.isNotEmpty()) {
            "Завтра (${snapshot.tomorrowSchedule.dateLabelUk})"
        } else {
            "Завтра"
        }
        binding.btnOutageTabToday.text = todayLabel
        binding.btnOutageTabTomorrow.text = tomorrowLabel
        updateOutageTabStyles()

        val activeDaySchedule: DayOutageSchedule = if (isOutageShowingTomorrow) {
            snapshot.tomorrowSchedule
        } else {
            snapshot.todaySchedule
        }

        // 1. Отрисовка 24-часовой шкалы (00 .. 24)
        val barContainer = binding.llOutageTimelineBar
        barContainer.removeAllViews()
        for (h in 0 until 24) {
            val firstHalfOn = if (activeDaySchedule.isAvailable) activeDaySchedule.halfHourPowerOn[h * 2] else true
            val secondHalfOn = if (activeDaySchedule.isAvailable) activeDaySchedule.halfHourPowerOn[h * 2 + 1] else true
            val isCurrentHour = (!isOutageShowingTomorrow) && (h == snapshot.currentHourKyiv)

            val segColor = when {
                firstHalfOn && secondHalfOn -> accent
                !firstHalfOn && !secondHalfOn -> Color.parseColor("#EF4444")
                else -> Color.parseColor("#F59E0B")
            }

            val segView = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                    marginStart = if (h == 0) 0 else dpPx(1.5f)
                    marginEnd = if (h == 23) 0 else dpPx(1.5f)
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpPx(3.5f).toFloat()
                    setColor(if (isCurrentHour) ColorUtils.blendARGB(segColor, Color.WHITE, 0.28f) else segColor)
                    if (isCurrentHour) {
                        setStroke(dpPx(1.5f), Color.WHITE)
                    }
                }
            }
            barContainer.addView(segView)
        }

        // 2. Отрисовка слотов отключений на выбранный день
        val slotsContainer = binding.llOutageIntervalsContainer
        slotsContainer.removeAllViews()

        if (!activeDaySchedule.isAvailable) {
            slotsContainer.addView(
                createOutageSlotRowView(
                    text = if (isOutageShowingTomorrow) "Графік на завтра ще не опубліковано ДТЕК" else "Завантаження графіка ДТЕК...",
                    isHighlighted = false,
                    isPositive = false,
                    accent = accent
                )
            )
        } else if (activeDaySchedule.intervals.isEmpty()) {
            slotsContainer.addView(
                createOutageSlotRowView(
                    text = "✓ За графіком без відключень весь день",
                    isHighlighted = true,
                    isPositive = true,
                    accent = accent
                )
            )
        } else {
            val nowMin = snapshot.currentMinuteOfDayKyiv
            var highlightedAssigned = false
            for (interval in activeDaySchedule.intervals.take(4)) {
                val isPast = (!isOutageShowingTomorrow) && (interval.endMinuteOfDay <= nowMin)
                val isOngoing = (!isOutageShowingTomorrow) && (nowMin in interval.startMinuteOfDay until interval.endMinuteOfDay)
                val isNext = (!isOutageShowingTomorrow) && !isPast && !isOngoing && !highlightedAssigned
                if (isOngoing || isNext) {
                    highlightedAssigned = true
                }

                val statusSuffix = when {
                    isOngoing -> " · Зараз"
                    isNext -> " · Наступне"
                    isPast -> " · Минуло"
                    else -> ""
                }
                val rowText = "⚡ ${interval.formatTimeRange()} · ${interval.formatDurationUk()}$statusSuffix"
                slotsContainer.addView(
                    createOutageSlotRowView(
                        text = rowText,
                        isHighlighted = isOngoing || isNext || isOutageShowingTomorrow,
                        isPositive = false,
                        accent = if (isOngoing) Color.parseColor("#EF4444") else accent,
                        isMuted = isPast
                    )
                )
            }
        }

        binding.tvOutageFooter.text = "Оновлено ДТЕК: ${snapshot.updateTimestamp}"
    }

    private fun createOutageSlotRowView(
        text: String,
        isHighlighted: Boolean,
        isPositive: Boolean,
        accent: Int,
        isMuted: Boolean = false
    ): TextView {
        return TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dpPx(36f)
            ).apply {
                bottomMargin = dpPx(6f)
            }
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpPx(14f), 0, dpPx(14f), 0)
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(
                when {
                    isMuted -> Color.parseColor("#8A94A6")
                    isPositive -> accent
                    else -> Color.parseColor("#F3F4F6")
                }
            )
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpPx(999f).toFloat()
                setColor(
                    if (isHighlighted) ColorUtils.setAlphaComponent(accent, 34)
                    else Color.parseColor("#18FFFFFF")
                )
                setStroke(
                    dpPx(if (isHighlighted) 1.5f else 1f),
                    if (isHighlighted) ColorUtils.setAlphaComponent(accent, 210)
                    else Color.parseColor("#24FFFFFF")
                )
            }
            this.text = text
        }
    }

    private fun setupControlCenterPanel() {
        binding.tileCcWifi.setOnClickListener {
            toggleWifiDirectly()
        }
        binding.tileCcWifi.setOnLongClickListener {
            hideControlCenter(restoreFocus = true)
            openSettingsIntent(Settings.ACTION_WIFI_SETTINGS)
            true
        }

        binding.tileCcBluetooth.setOnClickListener {
            hideControlCenter(restoreFocus = true)
            openSettingsIntent(Settings.ACTION_BLUETOOTH_SETTINGS)
        }
        binding.tileCcBluetooth.setOnLongClickListener {
            toggleBluetoothDirectly()
            true
        }

        binding.tileCcSound.setOnClickListener {
            try {
                audioManager.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    AudioManager.ADJUST_TOGGLE_MUTE,
                    0
                )
            } catch (_: Exception) {
            }
            refreshSoundTileState()
        }

        binding.tileCcBoost.setOnClickListener {
            silentCleanBackgroundProcesses()
            binding.tileCcBoost.background = createToggleDrawable(currentAccentColor, isActive = true)
            binding.ivCcBoost.setColorFilter(currentAccentColor, PorterDuff.Mode.SRC_IN)
            binding.tvCcBoostState.text = "OK"
            binding.tvCcBoostState.setTextColor(currentAccentColor)
            Toast.makeText(this, R.string.toast_boost_done, Toast.LENGTH_SHORT).show()
        }

        binding.btnMenuAllApps.setOnClickListener {
            returnToLauncherSettingsAfterAssign = false
            hideControlCenter(restoreFocus = false)
        hideOutageSchedulePanel(restoreFocus = false)
            openAppPickerOverlay(assignSlot = null, forKeyBind = false)
        }

        // Кнопка «Настройка лаунчера» (вместо старой «Плитка: ...»)
        binding.btnMenuAssignCurrent.setOnClickListener {
            hideControlCenter(restoreFocus = false)
        hideOutageSchedulePanel(restoreFocus = false)
            openLauncherSettingsOverlay()
        }

        binding.btnMenuBindKey.setOnClickListener {
            hideControlCenter(restoreFocus = false)
        hideOutageSchedulePanel(restoreFocus = false)
            ServiceAutoActivator.ensureServicesActive(this)
            updateAccessibilityStatusRow()
            binding.remoteKeySelectOverlay.visibility = View.VISIBLE
            if (isAccessibilityMapperEnabled()) {
                binding.btnKeyPresetPatchwall.requestFocus()
            } else {
                binding.btnKeyEnableAccessibility.requestFocus()
            }
        }

        binding.btnMenuSystemSettings.setOnClickListener {
            hideControlCenter(restoreFocus = true)
            viewModel.launchSystemSettings()
        }
    }

    private fun openLauncherSettingsOverlay() {
        val state = viewModel.uiState.value
        val s1Name = state.slot1App?.label ?: getString(R.string.card_slot_1_default)
        val s2Name = state.slot2App?.label ?: getString(R.string.card_slot_2_default)
        val s3Name = state.slot3App?.label ?: getString(R.string.card_slot_3_default)
        val s4Name = state.slot4App?.label ?: getString(R.string.card_slot_4_default)

        binding.btnEditSlot1.text = getString(R.string.launcher_edit_slot_1, s1Name)
        binding.btnEditSlot2.text = getString(R.string.launcher_edit_slot_2, s2Name)
        binding.btnEditSlot3.text = getString(R.string.launcher_edit_slot_3, s3Name)
        binding.btnEditSlot4.text = getString(R.string.launcher_edit_slot_4, s4Name)
        updateNavSoundButtonLabel()

        binding.launcherSettingsOverlay.visibility = View.VISIBLE
        binding.btnEditSlot1.requestFocus()
    }

    private fun updateNavSoundButtonLabel() {
        val enabled = NavSoundPlayer.isSoundEnabled(this)
        binding.btnToggleNavSound.text = getString(
            if (enabled) R.string.launcher_nav_sound_on else R.string.launcher_nav_sound_off
        )
    }

    private fun setupLauncherSettingsOverlay() {
        binding.btnEditSlot1.setOnClickListener {
            returnToLauncherSettingsAfterAssign = true
            binding.launcherSettingsOverlay.visibility = View.GONE
            openAppPickerOverlay(assignSlot = CardSlot.SLOT_1, forKeyBind = false)
        }
        binding.btnEditSlot2.setOnClickListener {
            returnToLauncherSettingsAfterAssign = true
            binding.launcherSettingsOverlay.visibility = View.GONE
            openAppPickerOverlay(assignSlot = CardSlot.SLOT_2, forKeyBind = false)
        }
        binding.btnEditSlot3.setOnClickListener {
            returnToLauncherSettingsAfterAssign = true
            binding.launcherSettingsOverlay.visibility = View.GONE
            openAppPickerOverlay(assignSlot = CardSlot.SLOT_3, forKeyBind = false)
        }
        binding.btnEditSlot4.setOnClickListener {
            returnToLauncherSettingsAfterAssign = true
            binding.launcherSettingsOverlay.visibility = View.GONE
            openAppPickerOverlay(assignSlot = CardSlot.SLOT_4, forKeyBind = false)
        }
        binding.btnToggleNavSound.setOnClickListener {
            val nextState = !NavSoundPlayer.isSoundEnabled(this)
            NavSoundPlayer.setSoundEnabled(this, nextState)
            updateNavSoundButtonLabel()
            if (nextState) {
                NavSoundPlayer.playClick(this)
            }
        }

        val colorChoices = listOf(
            binding.btnColorCyan to "#00F0FF",
            binding.btnColorEmerald to "#34D399",
            binding.btnColorAmber to "#F59E0B",
            binding.btnColorSapphire to "#60A5FA",
            binding.btnColorAmethyst to "#A78BFA",
            binding.btnColorSilver to "#E2E8F0"
        )

        colorChoices.forEach { (btn, hex) ->
            btn.setOnClickListener {
                appLauncherDirect.saveAccentColorHex(hex)
                currentAccentColor = Color.parseColor(hex)
                applyAccentColorTheme()
                DynamicIslandBus.notifyAccentColorChanged(hex)
                Toast.makeText(this, R.string.toast_color_applied, Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupAppManageOverlay() {
        binding.btnAppManageOpen.setOnClickListener {
            val app = selectedManageApp ?: return@setOnClickListener
            closeAllOverlays(restoreFocus = true)
            viewModel.launchAppDirectly(app)
        }

        binding.btnAppManageUninstall.setOnClickListener {
            val app = selectedManageApp ?: return@setOnClickListener
            binding.appManageOverlay.visibility = View.GONE
            binding.appPickerOverlay.visibility = View.GONE
            launchUninstallApp(app.packageName)
        }

        binding.btnAppManageInfo.setOnClickListener {
            val app = selectedManageApp ?: return@setOnClickListener
            binding.appManageOverlay.visibility = View.GONE
            binding.appPickerOverlay.visibility = View.GONE
            openAppDetailsSettings(app.packageName)
        }
    }

    private fun openAppManageModal(app: InstalledAppInfo) {
        selectedManageApp = app
        binding.tvAppManageTitle.text = app.label
        binding.appManageOverlay.visibility = View.VISIBLE
        binding.btnAppManageUninstall.requestFocus()
    }

    @Suppress("DEPRECATION")
    private fun launchUninstallApp(pkg: String) {
        try {
            val uri = Uri.fromParts("package", pkg, null)
            val intent = Intent(Intent.ACTION_UNINSTALL_PACKAGE, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (_: Exception) {
            try {
                val uri = Uri.fromParts("package", pkg, null)
                val delIntent = Intent(Intent.ACTION_DELETE, uri).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(delIntent)
            } catch (_: Exception) {
                openAppDetailsSettings(pkg)
            }
        }
    }

    private fun openAppDetailsSettings(pkg: String) {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", pkg, null)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (_: Exception) {
            viewModel.launchSystemSettings()
        }
    }

    private fun toggleWifiDirectly() {
        val wm = wifiManager
        if (wm == null) {
            openSettingsIntent(Settings.ACTION_WIFI_SETTINGS)
            return
        }
        val targetState = !wm.isWifiEnabled
        @Suppress("DEPRECATION")
        val changed = try {
            wm.setWifiEnabled(targetState)
        } catch (_: Exception) {
            false
        }
        if (!changed) {
            hideControlCenter(restoreFocus = true)
            openSettingsIntent(Settings.ACTION_WIFI_SETTINGS)
        } else {
            lifecycleScope.launch {
                delay(350L)
                refreshControlCenterToggles()
            }
        }
    }

    private fun toggleBluetoothDirectly() {
        try {
            @Suppress("DEPRECATION")
            val adapter = BluetoothAdapter.getDefaultAdapter()
            if (adapter != null) {
                @Suppress("MissingPermission", "DEPRECATION")
                if (adapter.isEnabled) adapter.disable() else adapter.enable()
                lifecycleScope.launch {
                    delay(400L)
                    refreshControlCenterToggles()
                }
            }
        } catch (_: Exception) {
            openSettingsIntent(Settings.ACTION_BLUETOOTH_SETTINGS)
        }
    }

    private fun refreshControlCenterToggles() {
        val accent = currentAccentColor
        val wifiEnabled = try {
            wifiManager?.isWifiEnabled == true
        } catch (_: Exception) {
            true
        }
        binding.tileCcWifi.background = createToggleDrawable(accent, isActive = wifiEnabled)
        binding.ivCcWifi.setColorFilter(
            if (wifiEnabled) accent else getColor(R.color.text_secondary),
            PorterDuff.Mode.SRC_IN
        )
        binding.tvCcWifiState.text = getString(if (wifiEnabled) R.string.cc_state_on else R.string.cc_state_off)
        binding.tvCcWifiState.setTextColor(if (wifiEnabled) accent else getColor(R.color.text_secondary))

        val btEnabled = try {
            @Suppress("DEPRECATION", "MissingPermission")
            BluetoothAdapter.getDefaultAdapter()?.isEnabled == true
        } catch (_: Exception) {
            true
        }
        binding.tileCcBluetooth.background = createToggleDrawable(accent, isActive = btEnabled)
        binding.ivCcBt.setColorFilter(
            if (btEnabled) accent else getColor(R.color.text_secondary),
            PorterDuff.Mode.SRC_IN
        )
        binding.tvCcBtState.text = getString(if (btEnabled) R.string.cc_state_on else R.string.cc_state_off)
        binding.tvCcBtState.setTextColor(if (btEnabled) accent else getColor(R.color.text_secondary))

        refreshSoundTileState()

        binding.tileCcBoost.background = createToggleDrawable(accent, isActive = false)
        binding.ivCcBoost.setColorFilter(accent, PorterDuff.Mode.SRC_IN)
        binding.tvCcBoostState.text = getString(R.string.cc_state_ready)
        binding.tvCcBoostState.setTextColor(getColor(R.color.text_secondary))
    }

    private fun refreshSoundTileState() {
        val accent = currentAccentColor
        val isMuted = try {
            audioManager.isStreamMute(AudioManager.STREAM_MUSIC)
        } catch (_: Exception) {
            false
        }
        val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val pct = ((curVol * 100f) / maxVol).toInt().coerceIn(0, 100)
        val soundActive = !isMuted && pct > 0
        binding.tileCcSound.background = createToggleDrawable(accent, isActive = soundActive)
        binding.ivCcSound.setColorFilter(
            if (soundActive) accent else getColor(R.color.text_secondary),
            PorterDuff.Mode.SRC_IN
        )
        binding.tvCcSoundState.text = if (isMuted || pct == 0) getString(R.string.cc_state_muted) else "$pct%"
        binding.tvCcSoundState.setTextColor(if (soundActive) accent else getColor(R.color.text_secondary))
    }

    private fun isProtectedMediaPackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("spotify") ||
            p.contains("soundcloud") ||
            p.contains("mediashell") ||
            p.contains("chromecast") ||
            p.contains("music") ||
            p.contains("youtube")
    }

    private fun silentCleanBackgroundProcesses() {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val am = getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return@launch
                val activeMusicPkg = MediaStateBus.state.value.sourcePackage
                val ctrlPkg = MediaStateBus.activeController?.packageName.orEmpty()
                val apps = viewModel.uiState.value.installedApps
                for (app in apps) {
                    val pkg = app.packageName
                    if (pkg != packageName &&
                        pkg != activeMusicPkg &&
                        pkg != ctrlPkg &&
                        !isProtectedMediaPackage(pkg)
                    ) {
                        am.killBackgroundProcesses(pkg)
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun openSettingsIntent(action: String) {
        val intent = Intent(action).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(intent)
        } catch (_: Exception) {
            viewModel.launchSystemSettings()
        }
    }

    private fun renderNowPlayingWidget(snapshot: NowPlayingSnapshot) {
        if (binding.controlCenterPanel.visibility == View.VISIBLE) {
            binding.nowPlayingCard.visibility = View.INVISIBLE
            return
        }

        if (!snapshot.hasActiveSession) {
            binding.llNowPlayingControls.visibility = View.GONE
            binding.nowPlayingCard.visibility = View.GONE
            return
        }

        if (binding.nowPlayingCard.visibility != View.VISIBLE) {
            binding.nowPlayingCard.alpha = 0f
            binding.nowPlayingCard.visibility = View.VISIBLE
            binding.nowPlayingCard.animate().alpha(1f).setDuration(160L).start()
        }

        binding.tvNowPlayingTitle.text = snapshot.title.ifEmpty {
            getString(R.string.now_playing_active_generic)
        }
        binding.tvNowPlayingArtist.text = snapshot.artist.ifEmpty { snapshot.sourceAppName }

        binding.ivNpPlayPause.setImageResource(
            if (snapshot.isPlaying) R.drawable.ic_media_pause else R.drawable.ic_media_play
        )

        if (snapshot.coverBitmap != null) {
            binding.ivNowPlayingArt.setPadding(0, 0, 0, 0)
            binding.ivNowPlayingArt.clearColorFilter()
            binding.ivNowPlayingArt.setImageBitmap(snapshot.coverBitmap)
        } else {
            val pad = (10 * resources.displayMetrics.density).toInt()
            binding.ivNowPlayingArt.setPadding(pad, pad, pad, pad)
            if (snapshot.sourcePackage.isNotEmpty()) {
                binding.ivNowPlayingArt.setImageDrawable(
                    iconStylizer.getStylizedIcon(snapshot.sourcePackage, snapshot.sourceAppName)
                )
            } else {
                binding.ivNowPlayingArt.setImageResource(R.drawable.ic_music_64)
            }
            binding.ivNowPlayingArt.setColorFilter(currentAccentColor, PorterDuff.Mode.SRC_IN)
        }

        updateLiveTrackProgressTick()
    }

    private fun updateLiveTrackProgressTick() {
        val snap = MediaStateBus.state.value
        if (!snap.hasActiveSession || binding.nowPlayingCard.visibility != View.VISIBLE) return

        val (posMs, durMs) = MediaStateBus.getLivePositionAndDuration()
        val posSec = (posMs / 1000L).coerceAtLeast(0L)
        val posFormatted = String.format("%02d:%02d", posSec / 60, posSec % 60)

        if (durMs > 0L) {
            val durSec = (durMs / 1000L).coerceAtLeast(1L)
            val durFormatted = String.format("%02d:%02d", durSec / 60, durSec % 60)
            binding.tvNowPlayingTime.text = "$posFormatted / $durFormatted"
        } else {
            binding.tvNowPlayingTime.text = posFormatted
        }

        val trackW = binding.flNowPlayingProgressTrack.width
        if (trackW > 0) {
            val ratio = if (durMs > 0L) {
                (posMs.toFloat() / durMs.toFloat()).coerceIn(0.04f, 1.0f)
            } else {
                val cycle = (posSec % 180L).toFloat() / 180f
                cycle.coerceIn(0.06f, 1.0f)
            }
            val fillW = (trackW * ratio).toInt().coerceAtLeast(6)
            val lp = binding.vNowPlayingVisualizer.layoutParams
            if (lp.width != fillW) {
                lp.width = fillW
                binding.vNowPlayingVisualizer.layoutParams = lp
            }
        }
    }

    private fun setupRemoteKeySelectOverlay() {
        binding.btnKeyEnableAccessibility.setOnClickListener {
            appLauncherDirect.launchAccessibilitySettings()
        }

        binding.btnKeyPresetPatchwall.setOnClickListener {
            pendingPresetId = "PATCHWALL"
            pendingKeyDisplayName = "9 квадратиков"
            capturedKeyCode = 0
            capturedScanCode = 0
            binding.remoteKeySelectOverlay.visibility = View.GONE
            openAppPickerOverlay(assignSlot = null, forKeyBind = true)
        }

        binding.btnKeyPresetNetflix.setOnClickListener {
            pendingPresetId = "NETFLIX"
            pendingKeyDisplayName = "NETFLIX"
            capturedKeyCode = 0
            capturedScanCode = 0
            binding.remoteKeySelectOverlay.visibility = View.GONE
            openAppPickerOverlay(assignSlot = null, forKeyBind = true)
        }

        binding.btnKeyPresetPrime.setOnClickListener {
            pendingPresetId = "PRIME"
            pendingKeyDisplayName = "prime video"
            capturedKeyCode = 0
            capturedScanCode = 0
            binding.remoteKeySelectOverlay.visibility = View.GONE
            openAppPickerOverlay(assignSlot = null, forKeyBind = true)
        }

        binding.btnKeyCustomListen.setOnClickListener {
            binding.remoteKeySelectOverlay.visibility = View.GONE
            startLiveKeyCapture()
        }
    }

    private fun startLiveKeyCapture() {
        pendingPresetId = null
        binding.keyCaptureOverlay.visibility = View.VISIBLE
        binding.keyCaptureOverlay.requestFocus()
        KeyCaptureBus.onKeyCapturedListener = { keyCode, scanCode ->
            onLiveKeyCaught(keyCode, scanCode)
        }
        KeyCaptureBus.isCapturingKey = true
    }

    private fun stopLiveKeyCapture() {
        KeyCaptureBus.isCapturingKey = false
        KeyCaptureBus.onKeyCapturedListener = null
        binding.keyCaptureOverlay.visibility = View.GONE
    }

    private fun onLiveKeyCaught(keyCode: Int, scanCode: Int) {
        stopLiveKeyCapture()
        pendingPresetId = null
        capturedKeyCode = keyCode
        capturedScanCode = scanCode
        pendingKeyDisplayName = "Key #$keyCode (Scan #$scanCode)"
        openAppPickerOverlay(assignSlot = null, forKeyBind = true)
    }

    private fun updateAccessibilityStatusRow() {
        val enabled = isAccessibilityMapperEnabled()
        if (enabled) {
            binding.btnKeyEnableAccessibility.text = getString(R.string.key_service_status_on)
            binding.btnKeyEnableAccessibility.setTextColor(currentAccentColor)
        } else {
            binding.btnKeyEnableAccessibility.text = getString(R.string.key_service_status_off)
            binding.btnKeyEnableAccessibility.setTextColor(getColor(R.color.status_error))
        }
    }

    private fun isAccessibilityMapperEnabled(): Boolean {
        if (KeyMapperAccessibilityService.isServiceConnectedAlive) return true
        return try {
            val enabledServices = Settings.Secure.getString(
                contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            enabledServices.contains(packageName) && ServiceAutoActivator.hasWriteSecureSettings(this)
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Сетка «Все приложения» с жёсткой привязкой ViewId и nextFocusLeft/Right/Up/Down
     * (курсор гарантированно наводится на 100% программ, а удержание OK открывает меню Удаления/Инфо!).
     */
    private fun openAppPickerOverlay(assignSlot: CardSlot?, forKeyBind: Boolean) {
        val apps = viewModel.uiState.value.installedApps
        binding.tvPickerTitle.text = when {
            forKeyBind -> getString(R.string.picker_title_key_bind, pendingKeyDisplayName)
            assignSlot != null -> getString(R.string.picker_title_assign, apps.size)
            else -> getString(R.string.picker_title_launch, apps.size)
        }

        val container = binding.llAppListContainer
        container.removeAllViews()

        val dp = resources.displayMetrics.density
        val pad = (14 * dp).toInt()
        val iconPx = (44 * dp).toInt()
        val gap = (10 * dp).toInt()

        val actionRows = mutableListOf<View>()
        if (forKeyBind) {
            val specialActions = listOf(
                "ACTION_CONTROL_CENTER" to getString(R.string.action_open_control_center),
                "ACTION_ALL_APPS" to getString(R.string.action_open_all_apps),
                "ACTION_SETTINGS" to getString(R.string.action_open_tv_settings),
                "ACTION_AI" to getString(R.string.action_open_ai_assistant),
                "" to getString(R.string.action_clear_binding)
            )
            specialActions.forEach { (actionCode, actionTitle) ->
                val row = createActionRow(actionTitle, dp) {
                    applyKeyOrPresetBinding(actionCode.ifEmpty { null }, actionTitle)
                }.apply {
                    id = View.generateViewId()
                }
                actionRows.add(row)
                container.addView(row)
            }
        }

        val columns = 4
        val appTiles = mutableListOf<View>()
        val tileRowParents = mutableListOf<View>()

        val chunked = apps.chunked(columns)
        chunked.forEach { rowApps ->
            val rowLayout = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                weightSum = columns.toFloat()
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = gap
                }
            }

            for (col in 0 until columns) {
                val app = rowApps.getOrNull(col)
                if (app != null) {
                    val tile = LinearLayout(this).apply {
                        id = View.generateViewId()
                        orientation = LinearLayout.VERTICAL
                        gravity = Gravity.CENTER
                        background = createCardSelectorDrawable(currentAccentColor)
                        isFocusable = true
                        isClickable = true
                        isLongClickable = (assignSlot == null && !forKeyBind)
                        isFocusableInTouchMode = false
                        setDefaultFocusHighlightEnabled(false)
                        setPadding(pad, pad, pad, pad)
                        layoutParams = LinearLayout.LayoutParams(
                            0,
                            (112 * dp).toInt(),
                            1f
                        ).apply {
                            if (col < columns - 1) marginEnd = gap
                        }
                    }

                    val iconView = ImageView(this).apply {
                        layoutParams = LinearLayout.LayoutParams(iconPx, iconPx)
                        scaleType = ImageView.ScaleType.FIT_CENTER
                        setImageDrawable(iconStylizer.getStylizedIcon(app.packageName, app.label))
                        setColorFilter(getColor(R.color.text_primary), PorterDuff.Mode.SRC_IN)
                    }

                    val titleView = TextView(this).apply {
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply {
                            topMargin = (8 * dp).toInt()
                        }
                        gravity = Gravity.CENTER
                        text = app.label
                        setTextColor(getColor(R.color.text_primary))
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                        maxLines = 1
                        ellipsize = TextUtils.TruncateAt.END
                    }

                    tile.setOnFocusChangeListener { _, hasFocus ->
                        val tint = if (hasFocus) currentAccentColor else getColor(R.color.text_primary)
                        iconView.setColorFilter(tint, PorterDuff.Mode.SRC_IN)
                        titleView.setTextColor(tint)
                        if (hasFocus) {
                            binding.svAppList.post {
                                val targetY = (rowLayout.top - dpPx(16f)).coerceAtLeast(0)
                                binding.svAppList.smoothScrollTo(0, targetY)
                            }
                        }
                    }

                    tile.setOnClickListener {
                        when {
                            forKeyBind -> applyKeyOrPresetBinding(app.packageName, app.label)
                            assignSlot != null -> {
                                viewModel.assignAppToSlot(assignSlot, app)
                                binding.appPickerOverlay.visibility = View.GONE
                                if (returnToLauncherSettingsAfterAssign) {
                                    returnToLauncherSettingsAfterAssign = false
                                    openLauncherSettingsOverlay()
                                } else {
                                    closeAllOverlays(restoreFocus = true)
                                }
                            }
                            else -> {
                                MediaStateBus.onMediaAppOpened(app.packageName)
                                closeAllOverlays(restoreFocus = true)
                                viewModel.launchAppDirectly(app)
                            }
                        }
                    }

                    if (assignSlot == null && !forKeyBind) {
                        tile.setOnLongClickListener {
                            openAppManageModal(app)
                            true
                        }
                    }

                    tile.addView(iconView)
                    tile.addView(titleView)
                    rowLayout.addView(tile)
                    appTiles.add(tile)
                    tileRowParents.add(rowLayout)
                } else {
                    val spacer = View(this).apply {
                        isFocusable = false
                        isClickable = false
                        layoutParams = LinearLayout.LayoutParams(0, 1, 1f).apply {
                            if (col < columns - 1) marginEnd = gap
                        }
                    }
                    rowLayout.addView(spacer)
                }
            }
            container.addView(rowLayout)
        }

        // Явно связываем навигацию для спец-действий (если открыто меню привязки кнопки)
        for (i in actionRows.indices) {
            val row = actionRows[i]
            row.nextFocusLeftId = row.id
            row.nextFocusRightId = row.id
            row.nextFocusUpId = if (i > 0) actionRows[i - 1].id else row.id
            row.nextFocusDownId = when {
                i < actionRows.lastIndex -> actionRows[i + 1].id
                appTiles.isNotEmpty() -> appTiles[0].id
                else -> row.id
            }
        }

        // Явно связываем навигацию для ВСЕХ плиток программ (чтобы курсор никогда не застревал на неполных рядах!)
        for (i in appTiles.indices) {
            val tile = appTiles[i]
            tile.nextFocusLeftId = if (i > 0) appTiles[i - 1].id else tile.id
            tile.nextFocusRightId = if (i < appTiles.lastIndex) appTiles[i + 1].id else tile.id

            tile.nextFocusUpId = when {
                i - columns >= 0 -> appTiles[i - columns].id
                actionRows.isNotEmpty() -> actionRows.last().id
                else -> tile.id
            }

            val currentRowIdx = i / columns
            val lastRowIdx = (appTiles.size - 1) / columns
            tile.nextFocusDownId = if (currentRowIdx < lastRowIdx) {
                val targetIdx = (i + columns).coerceAtMost(appTiles.lastIndex)
                appTiles[targetIdx].id
            } else {
                tile.id
            }
        }

        binding.appPickerOverlay.visibility = View.VISIBLE
        val firstTarget = actionRows.firstOrNull() ?: appTiles.firstOrNull()
        firstTarget?.post {
            firstTarget.requestFocus()
        }
    }

    private fun createActionRow(title: String, dp: Float, onClick: () -> Unit): View {
        return TextView(this).apply {
            text = title
            setTextColor(getColor(R.color.text_primary))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            background = createMenuSelectorDrawable(currentAccentColor)
            isFocusable = true
            isClickable = true
            isFocusableInTouchMode = false
            setDefaultFocusHighlightEnabled(false)
            val pad = (14 * dp).toInt()
            setPadding(pad, pad, pad, pad)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = (8 * dp).toInt()
            }
            setOnFocusChangeListener { _, hasFocus ->
                setTextColor(if (hasFocus) currentAccentColor else getColor(R.color.text_primary))
            }
            setOnClickListener { onClick() }
        }
    }

    private fun applyKeyOrPresetBinding(targetValue: String?, targetLabel: String) {
        val preset = pendingPresetId
        if (preset != null) {
            appLauncherDirect.savePresetBinding(preset, targetValue)
        } else {
            appLauncherDirect.saveKeyBinding(capturedKeyCode, capturedScanCode, targetValue)
        }
        Toast.makeText(
            this,
            getString(R.string.toast_key_bound, pendingKeyDisplayName, targetLabel),
            Toast.LENGTH_SHORT
        ).show()
        closeAllOverlays(restoreFocus = true)
    }

    private fun observeStateAndLifecycle() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                burnInProtector.onUserInteraction(this)

                val filter = IntentFilter().apply {
                    addAction(Intent.ACTION_TIME_CHANGED)
                    addAction(Intent.ACTION_TIMEZONE_CHANGED)
                    addAction(Intent.ACTION_LOCALE_CHANGED)
                }
                ContextCompat.registerReceiver(
                    this@LauncherActivity,
                    timeChangeReceiver,
                    filter,
                    ContextCompat.RECEIVER_EXPORTED
                )

                val volFilter = IntentFilter("android.media.VOLUME_CHANGED_ACTION")
                ContextCompat.registerReceiver(
                    this@LauncherActivity,
                    volumeChangeReceiver,
                    volFilter,
                    ContextCompat.RECEIVER_EXPORTED
                )

                val mediaFilter = IntentFilter().apply {
                    addAction("com.android.music.metachanged")
                    addAction("com.android.music.playstatechanged")
                    addAction("com.spotify.music.metadatachanged")
                    addAction("com.spotify.music.playbackstatechanged")
                }
                ContextCompat.registerReceiver(
                    this@LauncherActivity,
                    mediaBroadcastReceiver,
                    mediaFilter,
                    ContextCompat.RECEIVER_EXPORTED
                )

                // Живой опрос плеера каждые 500 мс (мгновенная синхронизация Spotify и Cast в реальном времени!)
                launch {
                    var musicActiveHalfSecStreak = 0
                    while (isActive) {
                        viewModel.refreshTimeAndDate()
                        MediaStateBus.pollActiveControllerLight(this@LauncherActivity)
                        if (audioManager.isMusicActive) {
                            musicActiveHalfSecStreak++
                            if (musicActiveHalfSecStreak >= 2) {
                                MediaStateBus.onContinuousBackgroundMusicDetected(this@LauncherActivity)
                            }
                        } else {
                            musicActiveHalfSecStreak = 0
                        }
                        updateLiveTrackProgressTick()
                        delay(500L)
                    }
                }

                launch {
                    OutageRepository.refreshIfNeeded(this@LauncherActivity, force = false)
                }

                launch {
                    var tickCounter = 0
                    while (isActive) {
                        delay(30_000L)
                        tickCounter++
                        OutageRepository.recomputeFromCachedJson(this@LauncherActivity)
                        if (tickCounter % 15 == 0) {
                            OutageRepository.refreshIfNeeded(this@LauncherActivity, force = false)
                        }
                    }
                }

                launch {
                    OutageRepository.state.collect { outageSnap ->
                        renderOutageWidgetAndPanel(outageSnap)
                    }
                }

                launch {
                    MediaStateBus.state.collect { snapshot ->
                        renderNowPlayingWidget(snapshot)
                    }
                }

                launch {
                    viewModel.observeNetworkInForeground().collect { netStatus ->
                        viewModel.updateNetworkStatus(netStatus)
                    }
                }

                launch {
                    viewModel.uiState.collect { state ->
                        binding.tvClock.text = state.timeText
                        binding.tvDate.text = state.dateText
                        renderSlotCard(state.slot1App, binding.ivCard1, binding.tvCard1, binding.cardYoutube, R.string.card_slot_1_default)
                        renderSlotCard(state.slot2App, binding.ivCard2, binding.tvCard2, binding.cardBrowser, R.string.card_slot_2_default)
                        renderSlotCard(state.slot3App, binding.ivCard3, binding.tvCard3, binding.cardCast, R.string.card_slot_3_default)
                        renderSlotCard(state.slot4App, binding.ivCardAi, binding.tvCard4, binding.cardAi, R.string.card_slot_4_default)
                        renderNetworkCornerIcon(state.networkStatus)
                        renderAssistantState(state.assistantState, state.isOverlayVisible)
                    }
                }

                launch {
                    viewModel.events.collect { event ->
                        when (event) {
                            is LauncherUiEvent.ShowToastRes -> {
                                Toast.makeText(this@LauncherActivity, event.stringResId, Toast.LENGTH_SHORT).show()
                            }
                            is LauncherUiEvent.ShowBoundToast -> {
                                Toast.makeText(
                                    this@LauncherActivity,
                                    getString(R.string.toast_app_bound, event.appLabel),
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                            is LauncherUiEvent.OpenAppAssignPicker -> {
                                lastFocusedMainCard = currentFocus
                                openAppPickerOverlay(assignSlot = event.slot, forKeyBind = false)
                            }
                            LauncherUiEvent.RequestAudioPermission -> {
                                audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                            LauncherUiEvent.RestoreFocusToAiCard -> {
                                binding.cardAi.requestFocus()
                            }
                            LauncherUiEvent.RestoreFocusToYoutubeCard -> {
                                binding.cardYoutube.requestFocus()
                            }
                        }
                    }
                }

                try {
                    awaitCancellation()
                } finally {
                    unregisterReceiver(timeChangeReceiver)
                    unregisterReceiver(volumeChangeReceiver)
                    unregisterReceiver(mediaBroadcastReceiver)
                    burnInProtector.stop()
                }
            }
        }
    }

    private fun renderSlotCard(
        appInfo: InstalledAppInfo?,
        iconView: ImageView,
        titleView: TextView,
        cardView: View,
        defaultTitleRes: Int
    ) {
        if (appInfo != null) {
            titleView.text = appInfo.label
            cardView.contentDescription = appInfo.label
            iconView.setImageDrawable(iconStylizer.getStylizedIcon(appInfo.packageName, appInfo.label))
        } else {
            titleView.text = getString(defaultTitleRes)
            iconView.setImageResource(R.drawable.ic_grid_apps_64)
        }
        val tintColor = if (cardView.hasFocus()) currentAccentColor else getColor(R.color.text_primary)
        iconView.setColorFilter(tintColor, PorterDuff.Mode.SRC_IN)
    }

    private fun renderNetworkCornerIcon(status: NetworkStatus) {
        val resId = when (status) {
            is NetworkStatus.Wifi -> when {
                status.level >= 4 -> R.drawable.ic_wifi_neon_4
                status.level == 3 -> R.drawable.ic_wifi_neon_3
                status.level == 2 -> R.drawable.ic_wifi_neon_2
                else -> R.drawable.ic_wifi_neon_1
            }
            NetworkStatus.Ethernet -> R.drawable.ic_wifi_neon_4
            NetworkStatus.Disconnected -> R.drawable.ic_wifi_off
        }
        binding.ivWifiCorner.setImageResource(resId)
        binding.ivWifiCorner.setColorFilter(currentAccentColor, PorterDuff.Mode.SRC_IN)
        binding.ivCcWifi.setImageResource(resId)
    }

    private fun renderAssistantState(aiState: AssistantState, isOverlayVisible: Boolean) {
        binding.assistantOverlay.visibility = if (isOverlayVisible) View.VISIBLE else View.GONE
        if (isOverlayVisible) {
            binding.assistantOverlay.requestFocus()
        }

        when (aiState) {
            AssistantState.Idle -> {}
            AssistantState.Listening -> {
                binding.tvOverlayTitle.text = getString(R.string.overlay_title_listening)
            }
            AssistantState.Processing -> {
                binding.tvOverlayTitle.text = getString(R.string.overlay_title_processing)
            }
            is AssistantState.Result -> {
                binding.tvOverlayTitle.text = getString(R.string.overlay_title_result)
                binding.tvOverlayBody.text = aiState.text
            }
            is AssistantState.Error -> {
                binding.tvOverlayTitle.text = getString(R.string.overlay_title_error)
            }
        }
    }

    private fun isAnyOverlayOpen(): Boolean {
        return binding.controlCenterPanel.visibility == View.VISIBLE ||
            binding.outageSchedulePanel.visibility == View.VISIBLE ||
            binding.launcherSettingsOverlay.visibility == View.VISIBLE ||
            binding.appManageOverlay.visibility == View.VISIBLE ||
            binding.remoteKeySelectOverlay.visibility == View.VISIBLE ||
            binding.keyCaptureOverlay.visibility == View.VISIBLE ||
            binding.appPickerOverlay.visibility == View.VISIBLE ||
            binding.assistantOverlay.visibility == View.VISIBLE
    }

    private fun closeAllOverlays(restoreFocus: Boolean) {
        returnToLauncherSettingsAfterAssign = false
        stopLiveKeyCapture()
        hideControlCenter(restoreFocus = false)
        hideOutageSchedulePanel(restoreFocus = false)
        binding.launcherSettingsOverlay.visibility = View.GONE
        binding.appManageOverlay.visibility = View.GONE
        binding.remoteKeySelectOverlay.visibility = View.GONE
        binding.appPickerOverlay.visibility = View.GONE
        if (binding.assistantOverlay.visibility == View.VISIBLE) {
            viewModel.closeAssistantOverlay(restoreFocusToAi = false)
        }
        if (restoreFocus) {
            (lastFocusedMainCard ?: binding.cardYoutube).requestFocus()
        }
    }

    private fun isCenterKey(keyCode: Int): Boolean {
        return keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
            keyCode == KeyEvent.KEYCODE_ENTER ||
            keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER ||
            keyCode == KeyEvent.KEYCODE_BUTTON_SELECT ||
            keyCode == KeyEvent.KEYCODE_BUTTON_A
    }

    private fun isDpadDirectionKey(keyCode: Int): Boolean {
        return keyCode == KeyEvent.KEYCODE_DPAD_UP ||
            keyCode == KeyEvent.KEYCODE_DPAD_DOWN ||
            keyCode == KeyEvent.KEYCODE_DPAD_LEFT ||
            keyCode == KeyEvent.KEYCODE_DPAD_RIGHT
    }

    private fun hasAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }
}
