package com.mitv.customlauncher.ui

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.PorterDuff
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.os.Bundle
import android.os.SystemClock
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.mitv.customlauncher.R
import com.mitv.customlauncher.data.AppLauncher
import com.mitv.customlauncher.data.AssistantState
import com.mitv.customlauncher.data.CardSlot
import com.mitv.customlauncher.data.ClockFormatter
import com.mitv.customlauncher.data.IconStylizer
import com.mitv.customlauncher.data.InstalledAppInfo
import com.mitv.customlauncher.data.LauncherConfig
import com.mitv.customlauncher.data.NetworkMonitor
import com.mitv.customlauncher.data.NetworkStatus
import com.mitv.customlauncher.databinding.ActivityLauncherBinding
import com.mitv.customlauncher.presentation.LauncherUiEvent
import com.mitv.customlauncher.presentation.LauncherViewModel
import com.mitv.customlauncher.service.KeyCaptureBus
import com.mitv.customlauncher.service.MediaStateBus
import com.mitv.customlauncher.service.NowPlayingSnapshot
import kotlinx.coroutines.Job
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class LauncherActivity : ComponentActivity() {

    private lateinit var binding: ActivityLauncherBinding
    private lateinit var burnInProtector: BurnInProtector
    private lateinit var iconStylizer: IconStylizer
    private lateinit var appLauncherDirect: AppLauncher
    private lateinit var audioManager: AudioManager

    private val focusAnimators = mutableMapOf<View, ObjectAnimator>()
    private val decelerateInterpolator = DecelerateInterpolator()
    private var aiPulseAnimator: ObjectAnimator? = null
    private var visualizerAnimator: ObjectAnimator? = null

    private var lastFocusedMainCard: View? = null
    private var activeMenuSlot: CardSlot? = null

    private var centerHoldJob: Job? = null
    private var centerIsDown = false
    private var centerLongTriggered = false

    private var pendingPresetId: String? = null
    private var pendingKeyDisplayName: String = ""
    private var capturedKeyCode = 0
    private var capturedScanCode = 0

    private val viewModel: LauncherViewModel by viewModels {
        LauncherViewModel.Factory(
            appLauncher = AppLauncher(applicationContext),
            networkMonitor = NetworkMonitor(applicationContext),
            demoReplyText = getString(R.string.fake_ai_demo_response)
        )
    }

    private val audioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            viewModel.onAssistantTrigger(hasAudioPermission = true)
        }
    }

    private val timeChangeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            viewModel.refreshTimeAndDate(forceDate = true)
        }
    }

    // Приёмник широковещательных метаданных треков от Spotify / Android Music / SoundCloud / VLC
    private val mediaBroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            val track = intent.getStringExtra("track")
                ?: intent.getStringExtra("title")
                ?: intent.getStringExtra("android.intent.extra.TITLE")
                ?: ""
            val artist = intent.getStringExtra("artist")
                ?: intent.getStringExtra("album")
                ?: ""
            val pkg = intent.`package` ?: ""
            if (track.isNotEmpty() || artist.isNotEmpty()) {
                MediaStateBus.updateMetadata(
                    title = track,
                    artist = artist,
                    sourcePackage = pkg,
                    sourceAppName = if (pkg.isNotEmpty()) pkg.substringAfterLast('.') else "MEDIA",
                    cover = null
                )
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLauncherBinding.inflate(layoutInflater)
        setContentView(binding.root)

        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        appLauncherDirect = AppLauncher(applicationContext)
        iconStylizer = IconStylizer(applicationContext)
        burnInProtector = BurnInProtector(
            targetView = binding.contentContainer,
            density = resources.displayMetrics.density
        )

        // Включаем бегущую строку для длинных названий треков
        binding.tvNowPlayingTitle.isSelected = true

        setupMainCards()
        setupNowPlayingControls()
        setupMenuOverlay()
        setupRemoteKeySelectOverlay()
        observeStateAndLifecycle()

        binding.cardYoutube.requestFocus()
        handleIncomingIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        viewModel.reloadInstalledApps()
        updateAccessibilityStatusRow()
        MediaStateBus.updatePlayingFlag(audioManager.isMusicActive)
    }

    override fun onDestroy() {
        KeyCaptureBus.isCapturingKey = false
        KeyCaptureBus.onKeyCapturedListener = null
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        burnInProtector.onUserInteraction(lifecycleScope)
        if (handleIncomingIntent(intent)) {
            return
        }
        closeAllOverlays(restoreFocus = false)
        viewModel.onHomeIntentReceived()
    }

    private fun handleIncomingIntent(intent: Intent?): Boolean {
        if (intent == null) return false
        val action = intent.action
        if (action == Intent.ACTION_ASSIST ||
            action == Intent.ACTION_VOICE_COMMAND ||
            action == Intent.ACTION_SEARCH_LONG_PRESS ||
            intent.getBooleanExtra("EXTRA_OPEN_AI", false)
        ) {
            intent.removeExtra("EXTRA_OPEN_AI")
            closeAllOverlays(restoreFocus = false)
            viewModel.onAssistantTrigger(hasAudioPermission())
            return true
        }
        if (intent.getBooleanExtra("EXTRA_OPEN_ALL_APPS", false)) {
            intent.removeExtra("EXTRA_OPEN_ALL_APPS")
            closeAllOverlays(restoreFocus = false)
            openAppPickerOverlay(assignSlot = null, forKeyBind = false)
            return true
        }
        return false
    }

    private fun setupNowPlayingControls() {
        binding.btnMediaPrev.setOnClickListener {
            sendSystemMediaKey(KeyEvent.KEYCODE_MEDIA_PREVIOUS)
        }
        binding.btnMediaPlayPause.setOnClickListener {
            sendSystemMediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
            lifecycleScope.launch {
                delay(250L)
                MediaStateBus.updatePlayingFlag(audioManager.isMusicActive)
            }
        }
        binding.btnMediaNext.setOnClickListener {
            sendSystemMediaKey(KeyEvent.KEYCODE_MEDIA_NEXT)
        }
        binding.btnMediaOpenApp.setOnClickListener {
            val snap = MediaStateBus.state.value
            val targetPkg = snap.sourcePackage.ifEmpty {
                viewModel.uiState.value.slot1App?.packageName.orEmpty()
            }
            if (targetPkg.isNotEmpty()) {
                appLauncherDirect.launchPackage(targetPkg)
            }
        }
    }

    private fun sendSystemMediaKey(keyCode: Int) {
        try {
            val now = SystemClock.uptimeMillis()
            val downEvent = KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0)
            val upEvent = KeyEvent(now, now, KeyEvent.ACTION_UP, keyCode, 0)
            audioManager.dispatchMediaKeyEvent(downEvent)
            audioManager.dispatchMediaKeyEvent(upEvent)
        } catch (_: Exception) {
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            burnInProtector.onUserInteraction(lifecycleScope)
        }

        val keyCode = event.keyCode
        val scanCode = event.scanCode

        // 1. Живой захват кнопки пульта для биндинга
        if (binding.keyCaptureOverlay.visibility == View.VISIBLE) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
                    stopLiveKeyCapture()
                    binding.remoteKeySelectOverlay.visibility = View.VISIBLE
                    binding.btnKeyCustomListen.requestFocus()
                    return true
                }
                if (!isDpadDirectionKey(keyCode) && !isCenterKey(keyCode)) {
                    onLiveKeyCaught(keyCode, scanCode)
                    return true
                }
            }
            return true
        }

        // 2. Кнопка ← Назад (KEYCODE_BACK)
        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                when {
                    binding.appPickerOverlay.visibility == View.VISIBLE -> {
                        binding.appPickerOverlay.visibility = View.GONE
                        binding.menuOverlay.visibility = View.VISIBLE
                        binding.btnMenuAllApps.requestFocus()
                    }
                    binding.remoteKeySelectOverlay.visibility == View.VISIBLE -> {
                        binding.remoteKeySelectOverlay.visibility = View.GONE
                        binding.menuOverlay.visibility = View.VISIBLE
                        binding.btnMenuBindKey.requestFocus()
                    }
                    binding.menuOverlay.visibility == View.VISIBLE -> {
                        binding.menuOverlay.visibility = View.GONE
                        (lastFocusedMainCard ?: binding.cardYoutube).requestFocus()
                    }
                    binding.assistantOverlay.visibility == View.VISIBLE -> {
                        viewModel.closeAssistantOverlay(restoreFocusToAi = true)
                    }
                    else -> {
                        openLauncherMenu(currentFocus)
                    }
                }
            }
            return true
        }

        // 3. Верхняя кнопка Ассистента (с цветными точками)
        if (keyCode == KeyEvent.KEYCODE_VOICE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_SEARCH
        ) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                val custom = appLauncherDirect.getKeyBinding(keyCode, scanCode)
                if (!custom.isNullOrEmpty()) {
                    executeCustomKeyTarget(custom)
                } else {
                    viewModel.onAssistantTrigger(hasAudioPermission())
                }
            }
            return true
        }

        // 4. Забинженные кнопки пульта
        if (!isDpadDirectionKey(keyCode) && !isCenterKey(keyCode)) {
            val boundTarget = resolveLocalKeyOrPreset(keyCode, scanCode)
            if (!boundTarget.isNullOrEmpty()) {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                    executeCustomKeyTarget(boundTarget)
                }
                return true
            }
        }

        // 5. Кнопка 9 квадратиков по умолчанию открывает Меню
        if (keyCode == KeyEvent.KEYCODE_MENU ||
            keyCode == KeyEvent.KEYCODE_ALL_APPS ||
            keyCode == KeyEvent.KEYCODE_GUIDE ||
            keyCode == KeyEvent.KEYCODE_SETTINGS ||
            keyCode == KeyEvent.KEYCODE_TV_INPUT
        ) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                if (binding.menuOverlay.visibility == View.VISIBLE) {
                    closeAllOverlays(restoreFocus = true)
                } else {
                    openLauncherMenu(currentFocus)
                }
            }
            return true
        }

        // 6. Центральная кнопка OK на главных плитках (короткий клик vs удержание 420 мс)
        if (!isAnyOverlayOpen() && isCenterKey(keyCode) && isMainGridCardFocused()) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                if (!centerIsDown) {
                    centerIsDown = true
                    centerLongTriggered = false
                    val targetCard = currentFocus
                    centerHoldJob?.cancel()
                    centerHoldJob = lifecycleScope.launch {
                        delay(420L)
                        if (centerIsDown && !centerLongTriggered && !isAnyOverlayOpen()) {
                            centerLongTriggered = true
                            openLauncherMenu(targetCard)
                        }
                    }
                } else if (event.repeatCount > 0 && !centerLongTriggered && (event.eventTime - event.downTime) >= 380L) {
                    centerLongTriggered = true
                    centerHoldJob?.cancel()
                    openLauncherMenu(currentFocus)
                }
                return true
            } else if (event.action == KeyEvent.ACTION_UP) {
                centerHoldJob?.cancel()
                val wasLong = centerLongTriggered
                centerIsDown = false
                centerLongTriggered = false
                if (!wasLong && !isAnyOverlayOpen()) {
                    triggerMainCardShortClick(currentFocus)
                }
                return true
            }
        }

        return super.dispatchKeyEvent(event)
    }

    private fun isMainGridCardFocused(): Boolean {
        val id = currentFocus?.id ?: return false
        return id == R.id.cardYoutube ||
            id == R.id.cardBrowser ||
            id == R.id.cardCast ||
            id == R.id.cardAi
    }

    private fun resolveLocalKeyOrPreset(keyCode: Int, scanCode: Int): String? {
        if (keyCode == KeyEvent.KEYCODE_ALL_APPS ||
            keyCode == KeyEvent.KEYCODE_MENU ||
            keyCode == KeyEvent.KEYCODE_GUIDE ||
            keyCode == KeyEvent.KEYCODE_SETTINGS ||
            keyCode == KeyEvent.KEYCODE_TV_INPUT ||
            keyCode == KeyEvent.KEYCODE_BUTTON_1 ||
            scanCode == 139 || scanCode == 362 || scanCode == 172 || scanCode == 256
        ) {
            appLauncherDirect.getPresetBinding("PATCHWALL")?.let { if (it.isNotEmpty()) return it }
        }
        if (keyCode == KeyEvent.KEYCODE_BUTTON_2 || keyCode == KeyEvent.KEYCODE_PROG_RED || scanCode == 412 || scanCode == 398 || keyCode == 309) {
            appLauncherDirect.getPresetBinding("NETFLIX")?.let { if (it.isNotEmpty()) return it }
        }
        if (keyCode == KeyEvent.KEYCODE_BUTTON_3 || keyCode == KeyEvent.KEYCODE_PROG_BLUE || scanCode == 413 || scanCode == 401 || keyCode == 310) {
            appLauncherDirect.getPresetBinding("PRIME")?.let { if (it.isNotEmpty()) return it }
        }
        return appLauncherDirect.getKeyBinding(keyCode, scanCode)
    }

    private fun triggerMainCardShortClick(cardView: View?) {
        when (cardView?.id) {
            R.id.cardYoutube -> viewModel.onSlotCardClicked(CardSlot.SLOT_1)
            R.id.cardBrowser -> viewModel.onSlotCardClicked(CardSlot.SLOT_2)
            R.id.cardCast -> viewModel.onSlotCardClicked(CardSlot.SLOT_3)
            R.id.cardAi -> viewModel.onAssistantTrigger(hasAudioPermission())
        }
    }

    private fun executeCustomKeyTarget(target: String) {
        when (target) {
            "ACTION_ALL_APPS" -> {
                closeAllOverlays(restoreFocus = false)
                openAppPickerOverlay(assignSlot = null, forKeyBind = false)
            }
            "ACTION_SETTINGS" -> {
                closeAllOverlays(restoreFocus = true)
                viewModel.launchSystemSettings()
            }
            "ACTION_AI" -> {
                closeAllOverlays(restoreFocus = false)
                viewModel.onAssistantTrigger(hasAudioPermission())
            }
            else -> {
                closeAllOverlays(restoreFocus = true)
                appLauncherDirect.launchPackage(target)
            }
        }
    }

    private fun setupMainCards() {
        val cardPairs = listOf(
            binding.cardYoutube to binding.ivCard1,
            binding.cardBrowser to binding.ivCard2,
            binding.cardCast to binding.ivCard3,
            binding.cardAi to binding.ivCardAi
        )

        cardPairs.forEach { (card, iconView) ->
            val pvhX = PropertyValuesHolder.ofFloat(View.SCALE_X, LauncherConfig.FOCUS_IDLE_SCALE, LauncherConfig.FOCUS_SCALE)
            val pvhY = PropertyValuesHolder.ofFloat(View.SCALE_Y, LauncherConfig.FOCUS_IDLE_SCALE, LauncherConfig.FOCUS_SCALE)
            val animator = ObjectAnimator.ofPropertyValuesHolder(card, pvhX, pvhY).apply {
                duration = LauncherConfig.FOCUS_ANIM_DURATION_MS
                interpolator = decelerateInterpolator
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationStart(animation: Animator) {
                        card.setLayerType(View.LAYER_TYPE_HARDWARE, null)
                    }

                    override fun onAnimationEnd(animation: Animator) {
                        card.setLayerType(View.LAYER_TYPE_NONE, null)
                    }

                    override fun onAnimationCancel(animation: Animator) {
                        card.setLayerType(View.LAYER_TYPE_NONE, null)
                    }
                })
            }
            focusAnimators[card] = animator

            iconView.setColorFilter(getColor(R.color.text_primary), PorterDuff.Mode.SRC_IN)

            card.setOnFocusChangeListener { v, hasFocus ->
                val anim = focusAnimators[v] ?: return@setOnFocusChangeListener
                val iconTint = if (hasFocus) getColor(R.color.accent_cyan) else getColor(R.color.text_primary)
                iconView.setColorFilter(iconTint, PorterDuff.Mode.SRC_IN)
                if (hasFocus) {
                    lastFocusedMainCard = v
                    anim.setFloatValues(v.scaleX, LauncherConfig.FOCUS_SCALE)
                    anim.start()
                } else {
                    anim.reverse()
                }
            }
        }
    }

    private fun renderNowPlayingWidget(snapshot: NowPlayingSnapshot) {
        val accent = snapshot.accentColor
        binding.tvNowPlayingBadge.setTextColor(accent)
        binding.vNowPlayingVisualizer.setBackgroundColor(accent)

        // Подкрашиваем тонкую рамку карточки Now Playing под цвет обложки трека
        val cardBg = binding.nowPlayingCard.background
        if (cardBg is GradientDrawable) {
            val strokeWidthPx = (1.5f * resources.displayMetrics.density).toInt()
            val alphaAccent = (accent and 0x00FFFFFF) or (if (snapshot.isPlaying) 0x99000000.toInt() else 0x40000000)
            cardBg.setStroke(strokeWidthPx, alphaAccent)
        }

        val srcName = snapshot.sourceAppName.uppercase().ifEmpty { "AUDIO" }
        if (snapshot.isPlaying) {
            binding.tvNowPlayingBadge.text = getString(R.string.now_playing_badge_live, srcName)
            binding.tvNowPlayingTitle.text = snapshot.title.ifEmpty {
                getString(R.string.now_playing_active_generic)
            }
            binding.tvNowPlayingArtist.text = snapshot.artist.ifEmpty {
                snapshot.sourceAppName.ifEmpty { getString(R.string.now_playing_default_artist) }
            }
            binding.btnMediaPlayPause.text = "⏸"
            startVisualizerPulse()
        } else {
            binding.tvNowPlayingBadge.text = getString(R.string.now_playing_badge_idle)
            binding.tvNowPlayingTitle.text = snapshot.title.ifEmpty {
                getString(R.string.now_playing_default_title)
            }
            binding.tvNowPlayingArtist.text = snapshot.artist.ifEmpty {
                getString(R.string.now_playing_default_artist)
            }
            binding.btnMediaPlayPause.text = "▶"
            stopVisualizerPulse()
        }

        if (snapshot.coverBitmap != null) {
            binding.ivNowPlayingArt.setPadding(0, 0, 0, 0)
            binding.ivNowPlayingArt.clearColorFilter()
            binding.ivNowPlayingArt.setImageBitmap(snapshot.coverBitmap)
        } else {
            val pad = (10 * resources.displayMetrics.density).toInt()
            binding.ivNowPlayingArt.setPadding(pad, pad, pad, pad)
            if (snapshot.sourcePackage.isNotEmpty()) {
                binding.ivNowPlayingArt.setImageDrawable(
                    iconStylizer.getStylizedIcon(snapshot.sourcePackage, snapshot.sourceAppName)
                )
            } else {
                binding.ivNowPlayingArt.setImageResource(R.drawable.ic_music_64)
            }
            binding.ivNowPlayingArt.setColorFilter(accent, PorterDuff.Mode.SRC_IN)
        }
    }

    private fun startVisualizerPulse() {
        if (visualizerAnimator == null) {
            visualizerAnimator = ObjectAnimator.ofFloat(binding.vNowPlayingVisualizer, View.ALPHA, 1f, 0.25f).apply {
                duration = 550L
                repeatMode = ObjectAnimator.REVERSE
                repeatCount = ObjectAnimator.INFINITE
                interpolator = LinearInterpolator()
            }
        }
        if (visualizerAnimator?.isStarted == false) {
            visualizerAnimator?.start()
        }
    }

    private fun stopVisualizerPulse() {
        visualizerAnimator?.cancel()
        binding.vNowPlayingVisualizer.alpha = 0.35f
    }

    private fun openLauncherMenu(sourceCard: View?) {
        val focused = sourceCard ?: lastFocusedMainCard ?: binding.cardYoutube
        if (isMainGridCardFocused()) {
            lastFocusedMainCard = focused
        }

        val slot = when (focused.id) {
            R.id.cardYoutube -> CardSlot.SLOT_1
            R.id.cardBrowser -> CardSlot.SLOT_2
            R.id.cardCast -> CardSlot.SLOT_3
            else -> CardSlot.SLOT_1
        }
        activeMenuSlot = slot

        val tileName = when (slot) {
            CardSlot.SLOT_1 -> binding.tvCard1.text.toString()
            CardSlot.SLOT_2 -> binding.tvCard2.text.toString()
            CardSlot.SLOT_3 -> binding.tvCard3.text.toString()
        }

        binding.tvMenuTitle.text = getString(R.string.menu_title_for_card, tileName)
        binding.btnMenuAssignCurrent.text = getString(R.string.menu_assign_current_tile, tileName)
        binding.menuOverlay.visibility = View.VISIBLE
        binding.btnMenuAllApps.requestFocus()
    }

    private fun setupMenuOverlay() {
        binding.btnMenuAllApps.setOnClickListener {
            binding.menuOverlay.visibility = View.GONE
            openAppPickerOverlay(assignSlot = null, forKeyBind = false)
        }

        binding.btnMenuAssignCurrent.setOnClickListener {
            val slot = activeMenuSlot ?: CardSlot.SLOT_1
            binding.menuOverlay.visibility = View.GONE
            openAppPickerOverlay(assignSlot = slot, forKeyBind = false)
        }

        binding.btnMenuBindKey.setOnClickListener {
            binding.menuOverlay.visibility = View.GONE
            updateAccessibilityStatusRow()
            binding.remoteKeySelectOverlay.visibility = View.VISIBLE
            if (isAccessibilityMapperEnabled()) {
                binding.btnKeyPresetPatchwall.requestFocus()
            } else {
                binding.btnKeyEnableAccessibility.requestFocus()
            }
        }

        binding.btnMenuSystemSettings.setOnClickListener {
            closeAllOverlays(restoreFocus = true)
            viewModel.launchSystemSettings()
        }

        binding.btnMenuCancel.setOnClickListener {
            closeAllOverlays(restoreFocus = true)
        }
    }

    private fun setupRemoteKeySelectOverlay() {
        binding.btnKeyEnableAccessibility.setOnClickListener {
            appLauncherDirect.launchAccessibilitySettings()
        }

        binding.btnKeyPresetPatchwall.setOnClickListener {
            pendingPresetId = "PATCHWALL"
            pendingKeyDisplayName = "9 квадратиков"
            capturedKeyCode = 0
            capturedScanCode = 0
            binding.remoteKeySelectOverlay.visibility = View.GONE
            openAppPickerOverlay(assignSlot = null, forKeyBind = true)
        }

        binding.btnKeyPresetNetflix.setOnClickListener {
            pendingPresetId = "NETFLIX"
            pendingKeyDisplayName = "NETFLIX"
            capturedKeyCode = 0
            capturedScanCode = 0
            binding.remoteKeySelectOverlay.visibility = View.GONE
            openAppPickerOverlay(assignSlot = null, forKeyBind = true)
        }

        binding.btnKeyPresetPrime.setOnClickListener {
            pendingPresetId = "PRIME"
            pendingKeyDisplayName = "prime video"
            capturedKeyCode = 0
            capturedScanCode = 0
            binding.remoteKeySelectOverlay.visibility = View.GONE
            openAppPickerOverlay(assignSlot = null, forKeyBind = true)
        }

        binding.btnKeyCustomListen.setOnClickListener {
            binding.remoteKeySelectOverlay.visibility = View.GONE
            startLiveKeyCapture()
        }
    }

    private fun startLiveKeyCapture() {
        pendingPresetId = null
        binding.keyCaptureOverlay.visibility = View.VISIBLE
        KeyCaptureBus.onKeyCapturedListener = { keyCode, scanCode ->
            onLiveKeyCaught(keyCode, scanCode)
        }
        KeyCaptureBus.isCapturingKey = true
    }

    private fun stopLiveKeyCapture() {
        KeyCaptureBus.isCapturingKey = false
        KeyCaptureBus.onKeyCapturedListener = null
        binding.keyCaptureOverlay.visibility = View.GONE
    }

    private fun onLiveKeyCaught(keyCode: Int, scanCode: Int) {
        stopLiveKeyCapture()
        pendingPresetId = null
        capturedKeyCode = keyCode
        capturedScanCode = scanCode
        pendingKeyDisplayName = "Key #$keyCode (Scan #$scanCode)"
        openAppPickerOverlay(assignSlot = null, forKeyBind = true)
    }

    private fun updateAccessibilityStatusRow() {
        val enabled = isAccessibilityMapperEnabled()
        if (enabled) {
            binding.btnKeyEnableAccessibility.text = getString(R.string.key_service_status_on)
            binding.btnKeyEnableAccessibility.setTextColor(getColor(R.color.accent_cyan))
        } else {
            binding.btnKeyEnableAccessibility.text = getString(R.string.key_service_status_off)
            binding.btnKeyEnableAccessibility.setTextColor(getColor(R.color.status_error))
        }
    }

    private fun isAccessibilityMapperEnabled(): Boolean {
        return try {
            val enabledServices = Settings.Secure.getString(
                contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            enabledServices.contains(packageName)
        } catch (_: Exception) {
            false
        }
    }

    private fun openAppPickerOverlay(assignSlot: CardSlot?, forKeyBind: Boolean) {
        val apps = viewModel.uiState.value.installedApps
        binding.tvPickerTitle.text = when {
            forKeyBind -> getString(R.string.picker_title_key_bind, pendingKeyDisplayName)
            assignSlot != null -> getString(R.string.picker_title_assign, apps.size)
            else -> getString(R.string.picker_title_launch, apps.size)
        }

        val container = binding.llAppListContainer
        container.removeAllViews()

        val dp = resources.displayMetrics.density
        val padH = (16 * dp).toInt()
        val padV = (12 * dp).toInt()
        val iconPx = (40 * dp).toInt()
        val marginB = (8 * dp).toInt()

        var firstRow: View? = null

        if (forKeyBind) {
            val specialActions = listOf(
                "ACTION_ALL_APPS" to getString(R.string.action_open_all_apps),
                "ACTION_SETTINGS" to getString(R.string.action_open_tv_settings),
                "ACTION_AI" to getString(R.string.action_open_ai_assistant),
                "" to getString(R.string.action_clear_binding)
            )
            specialActions.forEach { (actionCode, actionTitle) ->
                val row = createPickerRow(
                    title = actionTitle,
                    iconDrawable = ContextCompat.getDrawable(this, R.drawable.ic_settings_64)!!,
                    padH = padH,
                    padV = padV,
                    iconPx = iconPx,
                    marginB = marginB
                ) {
                    applyKeyOrPresetBinding(actionCode.ifEmpty { null }, actionTitle)
                }
                container.addView(row)
                if (firstRow == null) firstRow = row
            }
        }

        apps.forEach { app ->
            val row = createPickerRow(
                title = app.label,
                iconDrawable = iconStylizer.getStylizedIcon(app.packageName, app.label),
                padH = padH,
                padV = padV,
                iconPx = iconPx,
                marginB = marginB
            ) {
                when {
                    forKeyBind -> {
                        applyKeyOrPresetBinding(app.packageName, app.label)
                    }
                    assignSlot != null -> {
                        viewModel.assignAppToSlot(assignSlot, app)
                        closeAllOverlays(restoreFocus = true)
                    }
                    else -> {
                        closeAllOverlays(restoreFocus = true)
                        viewModel.launchAppDirectly(app)
                    }
                }
            }
            container.addView(row)
            if (firstRow == null) firstRow = row
        }

        binding.appPickerOverlay.visibility = View.VISIBLE
        firstRow?.requestFocus()
    }

    private fun applyKeyOrPresetBinding(targetValue: String?, targetLabel: String) {
        val preset = pendingPresetId
        if (preset != null) {
            appLauncherDirect.savePresetBinding(preset, targetValue)
        } else {
            appLauncherDirect.saveKeyBinding(capturedKeyCode, capturedScanCode, targetValue)
        }
        Toast.makeText(
            this,
            getString(R.string.toast_key_bound, pendingKeyDisplayName, targetLabel),
            Toast.LENGTH_SHORT
        ).show()
        closeAllOverlays(restoreFocus = true)
    }

    private fun createPickerRow(
        title: String,
        iconDrawable: android.graphics.drawable.Drawable,
        padH: Int,
        padV: Int,
        iconPx: Int,
        marginB: Int,
        onClick: () -> Unit
    ): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = ContextCompat.getDrawable(this@LauncherActivity, R.drawable.bg_menu_item_selector)
            isFocusable = true
            isClickable = true
            isFocusableInTouchMode = false
            setDefaultFocusHighlightEnabled(false)
            setPadding(padH, padV, padH, padV)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = marginB
            }
        }

        val iconView = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(iconPx, iconPx).apply {
                marginEnd = padH
            }
            scaleType = ImageView.ScaleType.FIT_CENTER
            setImageDrawable(iconDrawable)
            setColorFilter(getColor(R.color.text_primary), PorterDuff.Mode.SRC_IN)
        }

        val titleView = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
            text = title
            setTextColor(getColor(R.color.text_primary))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }

        row.setOnFocusChangeListener { _, hasFocus ->
            val tintColor = if (hasFocus) getColor(R.color.accent_cyan) else getColor(R.color.text_primary)
            iconView.setColorFilter(tintColor, PorterDuff.Mode.SRC_IN)
            titleView.setTextColor(if (hasFocus) getColor(R.color.accent_cyan) else getColor(R.color.text_primary))
        }

        row.setOnClickListener { onClick() }
        row.addView(iconView)
        row.addView(titleView)
        return row
    }

    private fun observeStateAndLifecycle() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                burnInProtector.onUserInteraction(this)

                val filter = IntentFilter().apply {
                    addAction(Intent.ACTION_TIME_CHANGED)
                    addAction(Intent.ACTION_TIMEZONE_CHANGED)
                    addAction(Intent.ACTION_LOCALE_CHANGED)
                }
                ContextCompat.registerReceiver(
                    this@LauncherActivity,
                    timeChangeReceiver,
                    filter,
                    ContextCompat.RECEIVER_EXPORTED
                )

                val mediaFilter = IntentFilter().apply {
                    addAction("com.android.music.metachanged")
                    addAction("com.android.music.playstatechanged")
                    addAction("com.spotify.music.metadatachanged")
                    addAction("com.spotify.music.playbackstatechanged")
                }
                ContextCompat.registerReceiver(
                    this@LauncherActivity,
                    mediaBroadcastReceiver,
                    mediaFilter,
                    ContextCompat.RECEIVER_EXPORTED
                )

                // Корутина часов + проверка фонового воспроизведения AudioManager.isMusicActive
                launch {
                    while (isActive) {
                        viewModel.refreshTimeAndDate()
                        MediaStateBus.updatePlayingFlag(audioManager.isMusicActive)
                        delay(ClockFormatter.computeDelayToNextSecond(System.currentTimeMillis()))
                    }
                }

                // Подписка на состояние фонового плеера Now Playing
                launch {
                    MediaStateBus.state.collect { snapshot ->
                        renderNowPlayingWidget(snapshot)
                    }
                }

                launch {
                    viewModel.observeNetworkInForeground().collect { netStatus ->
                        viewModel.updateNetworkStatus(netStatus)
                    }
                }

                launch {
                    viewModel.uiState.collect { state ->
                        binding.tvClock.text = state.timeText
                        binding.tvDate.text = state.dateText
                        renderSlotCard(state.slot1App, binding.ivCard1, binding.tvCard1, binding.cardYoutube, R.string.card_slot_1_default)
                        renderSlotCard(state.slot2App, binding.ivCard2, binding.tvCard2, binding.cardBrowser, R.string.card_slot_2_default)
                        renderSlotCard(state.slot3App, binding.ivCard3, binding.tvCard3, binding.cardCast, R.string.card_slot_3_default)
                        renderNetworkStatus(state.networkStatus)
                        renderAssistantState(state.assistantState, state.isOverlayVisible)
                    }
                }

                launch {
                    viewModel.events.collect { event ->
                        when (event) {
                            is LauncherUiEvent.ShowToastRes -> {
                                Toast.makeText(this@LauncherActivity, event.stringResId, Toast.LENGTH_SHORT).show()
                            }
                            is LauncherUiEvent.ShowBoundToast -> {
                                Toast.makeText(
                                    this@LauncherActivity,
                                    getString(R.string.toast_app_bound, event.appLabel),
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                            is LauncherUiEvent.OpenAppAssignPicker -> {
                                lastFocusedMainCard = currentFocus
                                openAppPickerOverlay(assignSlot = event.slot, forKeyBind = false)
                            }
                            LauncherUiEvent.RequestAudioPermission -> {
                                audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                            LauncherUiEvent.RestoreFocusToAiCard -> {
                                binding.cardAi.requestFocus()
                            }
                            LauncherUiEvent.RestoreFocusToYoutubeCard -> {
                                binding.cardYoutube.requestFocus()
                            }
                        }
                    }
                }

                try {
                    awaitCancellation()
                } finally {
                    unregisterReceiver(timeChangeReceiver)
                    unregisterReceiver(mediaBroadcastReceiver)
                    stopVisualizerPulse()
                    burnInProtector.stop()
                }
            }
        }
    }

    private fun renderSlotCard(
        appInfo: InstalledAppInfo?,
        iconView: ImageView,
        titleView: TextView,
        cardView: View,
        defaultTitleRes: Int
    ) {
        if (appInfo != null) {
            titleView.text = appInfo.label
            cardView.contentDescription = appInfo.label
            iconView.setImageDrawable(iconStylizer.getStylizedIcon(appInfo.packageName, appInfo.label))
        } else {
            titleView.text = getString(defaultTitleRes)
            iconView.setImageResource(R.drawable.ic_grid_apps_64)
        }
        val tintColor = if (cardView.hasFocus()) getColor(R.color.accent_cyan) else getColor(R.color.text_primary)
        iconView.setColorFilter(tintColor, PorterDuff.Mode.SRC_IN)
    }

    private fun renderNetworkStatus(status: NetworkStatus) {
        when (status) {
            is NetworkStatus.Wifi -> {
                binding.tvNetworkStatus.text = getString(R.string.net_wifi_level, status.level)
                binding.tvNetworkStatus.setTextColor(getColor(R.color.text_secondary))
            }
            NetworkStatus.Ethernet -> {
                binding.tvNetworkStatus.text = getString(R.string.net_ethernet)
                binding.tvNetworkStatus.setTextColor(getColor(R.color.text_secondary))
            }
            NetworkStatus.Disconnected -> {
                binding.tvNetworkStatus.text = getString(R.string.net_disconnected)
                binding.tvNetworkStatus.setTextColor(getColor(R.color.status_error))
            }
        }
    }

    private fun renderAssistantState(aiState: AssistantState, isOverlayVisible: Boolean) {
        binding.assistantOverlay.visibility = if (isOverlayVisible) View.VISIBLE else View.GONE
        if (isOverlayVisible) {
            binding.assistantOverlay.requestFocus()
        }

        if (aiState is AssistantState.Listening) {
            if (aiPulseAnimator == null) {
                aiPulseAnimator = ObjectAnimator.ofFloat(binding.tvAiStatus, View.ALPHA, 1f, 0.35f).apply {
                    duration = 650L
                    repeatMode = ObjectAnimator.REVERSE
                    repeatCount = ObjectAnimator.INFINITE
                    interpolator = LinearInterpolator()
                }
            }
            if (aiPulseAnimator?.isStarted == false) {
                aiPulseAnimator?.start()
            }
        } else {
            aiPulseAnimator?.cancel()
            binding.tvAiStatus.alpha = 1f
        }

        when (aiState) {
            AssistantState.Idle -> {
                binding.tvAiStatus.text = getString(R.string.ai_status_idle)
                binding.tvAiStatus.setTextColor(getColor(R.color.text_secondary))
            }
            AssistantState.Listening -> {
                binding.tvAiStatus.text = getString(R.string.ai_status_listening)
                binding.tvAiStatus.setTextColor(getColor(R.color.accent_cyan))
                binding.tvOverlayTitle.text = getString(R.string.overlay_title_listening)
            }
            AssistantState.Processing -> {
                binding.tvAiStatus.text = getString(R.string.ai_status_processing)
                binding.tvAiStatus.setTextColor(getColor(R.color.accent_cyan))
                binding.tvOverlayTitle.text = getString(R.string.overlay_title_processing)
            }
            is AssistantState.Result -> {
                binding.tvAiStatus.text = getString(R.string.ai_status_idle)
                binding.tvAiStatus.setTextColor(getColor(R.color.accent_cyan))
                binding.tvOverlayTitle.text = getString(R.string.overlay_title_result)
                binding.tvOverlayBody.text = aiState.text
            }
            is AssistantState.Error -> {
                binding.tvAiStatus.text = getString(R.string.ai_status_error, aiState.code)
                binding.tvAiStatus.setTextColor(getColor(R.color.status_error))
                binding.tvOverlayTitle.text = getString(R.string.overlay_title_error)
            }
        }
    }

    private fun isAnyOverlayOpen(): Boolean {
        return binding.menuOverlay.visibility == View.VISIBLE ||
            binding.remoteKeySelectOverlay.visibility == View.VISIBLE ||
            binding.keyCaptureOverlay.visibility == View.VISIBLE ||
            binding.appPickerOverlay.visibility == View.VISIBLE ||
            binding.assistantOverlay.visibility == View.VISIBLE
    }

    private fun closeAllOverlays(restoreFocus: Boolean) {
        stopLiveKeyCapture()
        binding.menuOverlay.visibility = View.GONE
        binding.remoteKeySelectOverlay.visibility = View.GONE
        binding.appPickerOverlay.visibility = View.GONE
        if (binding.assistantOverlay.visibility == View.VISIBLE) {
            viewModel.closeAssistantOverlay(restoreFocusToAi = false)
        }
        if (restoreFocus) {
            (lastFocusedMainCard ?: binding.cardYoutube).requestFocus()
        }
    }

    private fun isCenterKey(keyCode: Int): Boolean {
        return keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
            keyCode == KeyEvent.KEYCODE_ENTER ||
            keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER ||
            keyCode == KeyEvent.KEYCODE_BUTTON_SELECT ||
            keyCode == KeyEvent.KEYCODE_BUTTON_A
    }

    private fun isDpadDirectionKey(keyCode: Int): Boolean {
        return keyCode == KeyEvent.KEYCODE_DPAD_UP ||
            keyCode == KeyEvent.KEYCODE_DPAD_DOWN ||
            keyCode == KeyEvent.KEYCODE_DPAD_LEFT ||
            keyCode == KeyEvent.KEYCODE_DPAD_RIGHT
    }

    private fun hasAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }
}
