package com.mitv.customlauncher.ui

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.PorterDuff
import android.os.Bundle
import android.text.TextUtils
import android.util.Log
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.mitv.customlauncher.R
import com.mitv.customlauncher.data.AppLauncher
import com.mitv.customlauncher.data.AssistantState
import com.mitv.customlauncher.data.CardSlot
import com.mitv.customlauncher.data.ClockFormatter
import com.mitv.customlauncher.data.IconStylizer
import com.mitv.customlauncher.data.InstalledAppInfo
import com.mitv.customlauncher.data.LauncherConfig
import com.mitv.customlauncher.data.NetworkMonitor
import com.mitv.customlauncher.data.NetworkStatus
import com.mitv.customlauncher.databinding.ActivityLauncherBinding
import com.mitv.customlauncher.presentation.LauncherUiEvent
import com.mitv.customlauncher.presentation.LauncherViewModel
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class LauncherActivity : ComponentActivity() {

    private lateinit var binding: ActivityLauncherBinding
    private lateinit var burnInProtector: BurnInProtector
    private lateinit var iconStylizer: IconStylizer

    private val focusAnimators = mutableMapOf<View, ObjectAnimator>()
    private val decelerateInterpolator = DecelerateInterpolator()
    private var aiPulseAnimator: ObjectAnimator? = null

    private var activeMenuSlot: CardSlot? = null
    private var lastFocusedCardView: View? = null

    private val viewModel: LauncherViewModel by viewModels {
        LauncherViewModel.Factory(
            appLauncher = AppLauncher(applicationContext),
            networkMonitor = NetworkMonitor(applicationContext),
            demoReplyText = getString(R.string.fake_ai_demo_response)
        )
    }

    private val audioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            viewModel.onAssistantTrigger(hasAudioPermission = true)
        }
    }

    private val timeChangeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            viewModel.refreshTimeAndDate(forceDate = true)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLauncherBinding.inflate(layoutInflater)
        setContentView(binding.root)

        iconStylizer = IconStylizer(applicationContext)
        burnInProtector = BurnInProtector(
            targetView = binding.contentContainer,
            density = resources.displayMetrics.density
        )

        setupCardsAndFocusAnimation()
        setupContextMenuOverlay()
        setupBackNavigation()
        observeStateAndLifecycle()

        binding.cardYoutube.requestFocus()
    }

    override fun onResume() {
        super.onResume()
        // Обновляем список реальных приложений при возврате в лончер (если установили/удалили APK)
        viewModel.reloadInstalledApps()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        burnInProtector.onUserInteraction(lifecycleScope)
        closeAllOverlays(restoreFocus = false)
        viewModel.onHomeIntentReceived()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            burnInProtector.onUserInteraction(lifecycleScope)
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_SEARCH || keyCode == KeyEvent.KEYCODE_VOICE_ASSIST) {
            Log.d("MiTvLauncher", "Voice keycode received: $keyCode")
            viewModel.onAssistantTrigger(hasAudioPermission())
            return true
        }

        if (keyCode == KeyEvent.KEYCODE_MENU) {
            openContextMenuForCurrentFocus()
            return true
        }

        // Отслеживание короткого и долгого нажатия OK только когда мы на главном экране
        if (isCenterKey(keyCode) && !isAnyOverlayOpen()) {
            if (event.repeatCount == 0) {
                event.startTracking()
            }
            return true
        }

        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyLongPress(keyCode: Int, event: KeyEvent): Boolean {
        if (isCenterKey(keyCode) && !isAnyOverlayOpen()) {
            openContextMenuForCurrentFocus()
            return true
        }
        return super.onKeyLongPress(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (isCenterKey(keyCode) && !isAnyOverlayOpen()) {
            if (!event.isCanceled) {
                handleShortCenterClick()
            }
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    private fun handleShortCenterClick() {
        if (isAnyOverlayOpen()) return
        when (currentFocus?.id) {
            R.id.cardYoutube -> viewModel.onSlotCardClicked(CardSlot.SLOT_1)
            R.id.cardBrowser -> viewModel.onSlotCardClicked(CardSlot.SLOT_2)
            R.id.cardCast -> viewModel.onSlotCardClicked(CardSlot.SLOT_3)
            R.id.cardAi -> viewModel.onAssistantTrigger(hasAudioPermission())
        }
    }

    private fun openContextMenuForCurrentFocus() {
        val focused = currentFocus ?: binding.cardYoutube
        lastFocusedCardView = focused

        val slot = when (focused.id) {
            R.id.cardYoutube -> CardSlot.SLOT_1
            R.id.cardBrowser -> CardSlot.SLOT_2
            R.id.cardCast -> CardSlot.SLOT_3
            else -> null
        }
        activeMenuSlot = slot

        val cardTitle = when (slot) {
            CardSlot.SLOT_1 -> binding.tvCard1.text.toString()
            CardSlot.SLOT_2 -> binding.tvCard2.text.toString()
            CardSlot.SLOT_3 -> binding.tvCard3.text.toString()
            null -> getString(R.string.card_ai)
        }

        binding.tvMenuTitle.text = getString(R.string.menu_title_for_card, cardTitle)
        binding.btnMenuAssignCard.visibility = if (slot != null) View.VISIBLE else View.GONE
        binding.menuOverlay.visibility = View.VISIBLE
        binding.btnMenuAllApps.requestFocus()
    }

    private fun setupContextMenuOverlay() {
        binding.btnMenuAllApps.setOnClickListener {
            binding.menuOverlay.visibility = View.GONE
            openAppPickerOverlay(assignSlot = null)
        }

        binding.btnMenuAssignCard.setOnClickListener {
            val slot = activeMenuSlot
            binding.menuOverlay.visibility = View.GONE
            if (slot != null) {
                openAppPickerOverlay(assignSlot = slot)
            }
        }

        binding.btnMenuSystemSettings.setOnClickListener {
            closeAllOverlays(restoreFocus = true)
            viewModel.launchSystemSettings()
        }

        binding.btnMenuCancel.setOnClickListener {
            closeAllOverlays(restoreFocus = true)
        }
    }

    private fun openAppPickerOverlay(assignSlot: CardSlot?) {
        val apps = viewModel.uiState.value.installedApps
        binding.tvPickerTitle.text = if (assignSlot != null) {
            getString(R.string.picker_title_assign, apps.size)
        } else {
            getString(R.string.picker_title_launch, apps.size)
        }

        val container = binding.llAppListContainer
        container.removeAllViews()

        val dp = resources.displayMetrics.density
        val padH = (16 * dp).toInt()
        val padV = (12 * dp).toInt()
        val iconPx = (40 * dp).toInt()
        val marginB = (8 * dp).toInt()

        var firstRow: View? = null

        apps.forEach { app ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                background = ContextCompat.getDrawable(this@LauncherActivity, R.drawable.bg_menu_item_selector)
                isFocusable = true
                isClickable = true
                isFocusableInTouchMode = false
                setDefaultFocusHighlightEnabled(false)
                setPadding(padH, padV, padH, padV)
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = marginB
                }
            }

            val iconView = ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(iconPx, iconPx).apply {
                    marginEnd = padH
                }
                scaleType = ImageView.ScaleType.FIT_CENTER
                setImageDrawable(iconStylizer.getStylizedIcon(app.packageName, app.label))
                setColorFilter(getColor(R.color.text_primary), PorterDuff.Mode.SRC_IN)
            }

            val titleView = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                text = app.label
                setTextColor(getColor(R.color.text_primary))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }

            row.setOnFocusChangeListener { _, hasFocus ->
                val tintColor = if (hasFocus) getColor(R.color.accent_cyan) else getColor(R.color.text_primary)
                iconView.setColorFilter(tintColor, PorterDuff.Mode.SRC_IN)
                titleView.setTextColor(if (hasFocus) getColor(R.color.accent_cyan) else getColor(R.color.text_primary))
            }

            row.setOnClickListener {
                if (assignSlot != null) {
                    viewModel.assignAppToSlot(assignSlot, app)
                    closeAllOverlays(restoreFocus = true)
                } else {
                    closeAllOverlays(restoreFocus = true)
                    viewModel.launchAppDirectly(app)
                }
            }

            row.addView(iconView)
            row.addView(titleView)
            container.addView(row)

            if (firstRow == null) {
                firstRow = row
            }
        }

        binding.appPickerOverlay.visibility = View.VISIBLE
        firstRow?.requestFocus()
    }

    private fun setupCardsAndFocusAnimation() {
        val cardTriples = listOf(
            Triple(binding.cardYoutube, binding.ivCard1, binding.tvCard1),
            Triple(binding.cardBrowser, binding.ivCard2, binding.tvCard2),
            Triple(binding.cardCast, binding.ivCard3, binding.tvCard3),
            Triple(binding.cardAi, binding.ivCardAi, null)
        )

        cardTriples.forEach { (card, iconView, _) ->
            val pvhX = PropertyValuesHolder.ofFloat(View.SCALE_X, LauncherConfig.FOCUS_IDLE_SCALE, LauncherConfig.FOCUS_SCALE)
            val pvhY = PropertyValuesHolder.ofFloat(View.SCALE_Y, LauncherConfig.FOCUS_IDLE_SCALE, LauncherConfig.FOCUS_SCALE)
            val animator = ObjectAnimator.ofPropertyValuesHolder(card, pvhX, pvhY).apply {
                duration = LauncherConfig.FOCUS_ANIM_DURATION_MS
                interpolator = decelerateInterpolator
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationStart(animation: Animator) {
                        card.setLayerType(View.LAYER_TYPE_HARDWARE, null)
                    }

                    override fun onAnimationEnd(animation: Animator) {
                        card.setLayerType(View.LAYER_TYPE_NONE, null)
                    }

                    override fun onAnimationCancel(animation: Animator) {
                        card.setLayerType(View.LAYER_TYPE_NONE, null)
                    }
                })
            }
            focusAnimators[card] = animator

            // Начальный тонирующий цвет иконки (#FFFFFF в покое, #00F0FF в фокусе)
            iconView.setColorFilter(getColor(R.color.text_primary), PorterDuff.Mode.SRC_IN)

            card.setOnFocusChangeListener { v, hasFocus ->
                val anim = focusAnimators[v] ?: return@setOnFocusChangeListener
                val iconTint = if (hasFocus) getColor(R.color.accent_cyan) else getColor(R.color.text_primary)
                iconView.setColorFilter(iconTint, PorterDuff.Mode.SRC_IN)
                if (hasFocus) {
                    anim.setFloatValues(v.scaleX, LauncherConfig.FOCUS_SCALE)
                    anim.start()
                } else {
                    anim.reverse()
                }
            }

            card.setOnClickListener {
                handleShortCenterClick()
            }
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                when {
                    binding.appPickerOverlay.visibility == View.VISIBLE -> {
                        binding.appPickerOverlay.visibility = View.GONE
                        (lastFocusedCardView ?: binding.cardYoutube).requestFocus()
                    }
                    binding.menuOverlay.visibility == View.VISIBLE -> {
                        binding.menuOverlay.visibility = View.GONE
                        (lastFocusedCardView ?: binding.cardYoutube).requestFocus()
                    }
                    binding.assistantOverlay.visibility == View.VISIBLE -> {
                        viewModel.closeAssistantOverlay(restoreFocusToAi = true)
                    }
                }
            }
        })
    }

    private fun observeStateAndLifecycle() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                burnInProtector.onUserInteraction(this)

                val filter = IntentFilter().apply {
                    addAction(Intent.ACTION_TIME_CHANGED)
                    addAction(Intent.ACTION_TIMEZONE_CHANGED)
                    addAction(Intent.ACTION_LOCALE_CHANGED)
                }
                ContextCompat.registerReceiver(
                    this@LauncherActivity,
                    timeChangeReceiver,
                    filter,
                    ContextCompat.RECEIVER_EXPORTED
                )

                launch {
                    while (isActive) {
                        viewModel.refreshTimeAndDate()
                        delay(ClockFormatter.computeDelayToNextSecond(System.currentTimeMillis()))
                    }
                }

                launch {
                    viewModel.observeNetworkInForeground().collect { netStatus ->
                        viewModel.updateNetworkStatus(netStatus)
                    }
                }

                launch {
                    viewModel.uiState.collect { state ->
                        binding.tvClock.text = state.timeText
                        binding.tvDate.text = state.dateText
                        renderSlotCard(state.slot1App, binding.ivCard1, binding.tvCard1, binding.cardYoutube, R.string.card_slot_1_default)
                        renderSlotCard(state.slot2App, binding.ivCard2, binding.tvCard2, binding.cardBrowser, R.string.card_slot_2_default)
                        renderSlotCard(state.slot3App, binding.ivCard3, binding.tvCard3, binding.cardCast, R.string.card_slot_3_default)
                        renderNetworkStatus(state.networkStatus)
                        renderAssistantState(state.assistantState, state.isOverlayVisible)
                    }
                }

                launch {
                    viewModel.events.collect { event ->
                        when (event) {
                            is LauncherUiEvent.ShowToastRes -> {
                                Toast.makeText(this@LauncherActivity, event.stringResId, Toast.LENGTH_SHORT).show()
                            }
                            is LauncherUiEvent.ShowBoundToast -> {
                                Toast.makeText(
                                    this@LauncherActivity,
                                    getString(R.string.toast_app_bound, event.appLabel),
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                            is LauncherUiEvent.OpenAppAssignPicker -> {
                                lastFocusedCardView = currentFocus
                                openAppPickerOverlay(assignSlot = event.slot)
                            }
                            LauncherUiEvent.RequestAudioPermission -> {
                                audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                            LauncherUiEvent.RestoreFocusToAiCard -> {
                                binding.cardAi.requestFocus()
                            }
                            LauncherUiEvent.RestoreFocusToYoutubeCard -> {
                                binding.cardYoutube.requestFocus()
                            }
                        }
                    }
                }

                try {
                    awaitCancellation()
                } finally {
                    unregisterReceiver(timeChangeReceiver)
                    burnInProtector.stop()
                }
            }
        }
    }

    private fun renderSlotCard(
        appInfo: InstalledAppInfo?,
        iconView: ImageView,
        titleView: TextView,
        cardView: View,
        defaultTitleRes: Int
    ) {
        if (appInfo != null) {
            titleView.text = appInfo.label
            cardView.contentDescription = appInfo.label
            iconView.setImageDrawable(iconStylizer.getStylizedIcon(appInfo.packageName, appInfo.label))
        } else {
            titleView.text = getString(defaultTitleRes)
            iconView.setImageResource(R.drawable.ic_grid_apps_64)
        }
        val tintColor = if (cardView.hasFocus()) getColor(R.color.accent_cyan) else getColor(R.color.text_primary)
        iconView.setColorFilter(tintColor, PorterDuff.Mode.SRC_IN)
    }

    private fun renderNetworkStatus(status: NetworkStatus) {
        when (status) {
            is NetworkStatus.Wifi -> {
                binding.tvNetworkStatus.text = getString(R.string.net_wifi_level, status.level)
                binding.tvNetworkStatus.setTextColor(getColor(R.color.text_secondary))
            }
            NetworkStatus.Ethernet -> {
                binding.tvNetworkStatus.text = getString(R.string.net_ethernet)
                binding.tvNetworkStatus.setTextColor(getColor(R.color.text_secondary))
            }
            NetworkStatus.Disconnected -> {
                binding.tvNetworkStatus.text = getString(R.string.net_disconnected)
                binding.tvNetworkStatus.setTextColor(getColor(R.color.status_error))
            }
        }
    }

    private fun renderAssistantState(aiState: AssistantState, isOverlayVisible: Boolean) {
        binding.assistantOverlay.visibility = if (isOverlayVisible) View.VISIBLE else View.GONE
        if (isOverlayVisible) {
            binding.assistantOverlay.requestFocus()
        }

        if (aiState is AssistantState.Listening) {
            if (aiPulseAnimator == null) {
                aiPulseAnimator = ObjectAnimator.ofFloat(binding.tvAiStatus, View.ALPHA, 1f, 0.35f).apply {
                    duration = 650L
                    repeatMode = ObjectAnimator.REVERSE
                    repeatCount = ObjectAnimator.INFINITE
                    interpolator = LinearInterpolator()
                }
            }
            if (aiPulseAnimator?.isStarted == false) {
                aiPulseAnimator?.start()
            }
        } else {
            aiPulseAnimator?.cancel()
            binding.tvAiStatus.alpha = 1f
        }

        when (aiState) {
            AssistantState.Idle -> {
                binding.tvAiStatus.text = getString(R.string.ai_status_idle)
                binding.tvAiStatus.setTextColor(getColor(R.color.text_secondary))
            }
            AssistantState.Listening -> {
                binding.tvAiStatus.text = getString(R.string.ai_status_listening)
                binding.tvAiStatus.setTextColor(getColor(R.color.accent_cyan))
                binding.tvOverlayTitle.text = getString(R.string.overlay_title_listening)
            }
            AssistantState.Processing -> {
                binding.tvAiStatus.text = getString(R.string.ai_status_processing)
                binding.tvAiStatus.setTextColor(getColor(R.color.accent_cyan))
                binding.tvOverlayTitle.text = getString(R.string.overlay_title_processing)
            }
            is AssistantState.Result -> {
                binding.tvAiStatus.text = getString(R.string.ai_status_idle)
                binding.tvAiStatus.setTextColor(getColor(R.color.accent_cyan))
                binding.tvOverlayTitle.text = getString(R.string.overlay_title_result)
                binding.tvOverlayBody.text = aiState.text
            }
            is AssistantState.Error -> {
                binding.tvAiStatus.text = getString(R.string.ai_status_error, aiState.code)
                binding.tvAiStatus.setTextColor(getColor(R.color.status_error))
                binding.tvOverlayTitle.text = getString(R.string.overlay_title_error)
            }
        }
    }

    private fun isAnyOverlayOpen(): Boolean {
        return binding.menuOverlay.visibility == View.VISIBLE ||
            binding.appPickerOverlay.visibility == View.VISIBLE ||
            binding.assistantOverlay.visibility == View.VISIBLE
    }

    private fun closeAllOverlays(restoreFocus: Boolean) {
        binding.menuOverlay.visibility = View.GONE
        binding.appPickerOverlay.visibility = View.GONE
        if (binding.assistantOverlay.visibility == View.VISIBLE) {
            viewModel.closeAssistantOverlay(restoreFocusToAi = false)
        }
        if (restoreFocus) {
            (lastFocusedCardView ?: binding.cardYoutube).requestFocus()
        }
    }

    private fun isCenterKey(keyCode: Int): Boolean {
        return keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
            keyCode == KeyEvent.KEYCODE_ENTER ||
            keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER
    }

    private fun hasAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }
}
