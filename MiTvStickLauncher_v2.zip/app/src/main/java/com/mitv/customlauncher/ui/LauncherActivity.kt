package com.mitv.customlauncher.ui

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.animation.PropertyValuesHolder
import android.app.ActivityManager
import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Outline
import android.graphics.PorterDuff
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.media.AudioManager
import android.net.Uri
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.text.SpannableString
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.text.style.RelativeSizeSpan
import java.util.Calendar
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import java.io.File
import org.json.JSONArray
import java.net.URL
import java.net.HttpURLConnection
import java.io.FileOutputStream
import android.os.Build
import androidx.core.graphics.ColorUtils
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.mitv.customlauncher.R
import com.mitv.customlauncher.data.AppLauncher
import com.mitv.customlauncher.data.AssistantState
import kotlinx.coroutines.withContext
import com.mitv.customlauncher.data.AssistantVoiceSpeaker
import com.mitv.customlauncher.data.TuyaSmartHomeController
import com.mitv.customlauncher.data.GeminiCloudClient
import com.mitv.customlauncher.data.GeminiTurnResult
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.graphics.Typeface
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sin
import kotlin.math.sqrt
import com.mitv.customlauncher.data.CardSlot
import com.mitv.customlauncher.data.ClockFormatter
import com.mitv.customlauncher.data.IconStylizer
import com.mitv.customlauncher.data.InstalledAppInfo
import com.mitv.customlauncher.data.LauncherConfig
import com.mitv.customlauncher.data.NetworkMonitor
import com.mitv.customlauncher.data.NetworkStatus
import com.mitv.customlauncher.data.DayOutageSchedule
import com.mitv.customlauncher.data.OutageRepository
import com.mitv.customlauncher.data.OutageUiSnapshot
import com.mitv.customlauncher.databinding.ActivityLauncherBinding
import com.mitv.customlauncher.presentation.LauncherUiEvent
import com.mitv.customlauncher.presentation.LauncherViewModel
import com.mitv.customlauncher.data.LocalVoiceCommandRouter
import com.mitv.customlauncher.service.DynamicIslandBus
import com.mitv.customlauncher.service.RemoteConsoleServer
import com.mitv.customlauncher.service.NavSoundPlayer
import com.mitv.customlauncher.service.KeyCaptureBus
import com.mitv.customlauncher.service.KeyMapperAccessibilityService
import com.mitv.customlauncher.service.MediaStateBus
import com.mitv.customlauncher.service.NowPlayingSnapshot
import com.mitv.customlauncher.service.ServiceAutoActivator
import com.mitv.customlauncher.service.VolumeHudBus
import android.widget.FrameLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class LauncherActivity : ComponentActivity() {

    private lateinit var binding: ActivityLauncherBinding
    private lateinit var burnInProtector: BurnInProtector
    private lateinit var iconStylizer: IconStylizer
    private lateinit var appLauncherDirect: AppLauncher
    private lateinit var audioManager: AudioManager
    private var wifiManager: WifiManager? = null

    private val focusAnimators = mutableMapOf<View, ObjectAnimator>()
    private val decelerateInterpolator = DecelerateInterpolator()

    private var lastFocusedMainCard: View? = null
    private lateinit var appStrip: AppStripController
    private lateinit var stripReorder: StripReorderOverlay
    private var stripKey: List<Any?>? = null
    private var stripApps: List<InstalledAppInfo?> = emptyList()
    private var selectedManageApp: InstalledAppInfo? = null
    private var returnToLauncherSettingsAfterAssign: Boolean = false

    private var currentAccentColor: Int = Color.parseColor("#00F0FF")
    private var isOutageShowingTomorrow: Boolean = false
    private var volumeHudHideJob: Job? = null

    // In-Activity Dynamic Island (для работы на телефоне и без включённой спецвозможности)
    private val actIslandHandler = Handler(Looper.getMainLooper())
    private var actIslandRoot: LinearLayout? = null
    private var actIslandSpark: ImageView? = null
    private var actIslandWaveBox: LinearLayout? = null
    private val actIslandWaveBars = mutableListOf<View>()
    private var actIslandStatusTv: TextView? = null
    private var actIslandHintTv: TextView? = null
    private var actIslandBodyTv: TextView? = null
    private var actIslandVisible: Boolean = false
    private var actIslandListening: Boolean = false
    private var actIslandSpeaking: Boolean = false
    private var actIslandFollowUp: Boolean = false
    private var actAudioRecordJob: Job? = null
    private var actGeminiJob: Job? = null
    @Volatile
    private var actTargetVoiceLevel: Float = 0.35f
    private var actSmoothedVoiceLevel: Float = 0.35f
    private var actWavePhaseRad: Double = 0.0

    private val actHideIslandRunnable = Runnable {
        collapseActivityDynamicIsland()
    }

    private val actPulseWaveRunnable = object : Runnable {
        override fun run() {
            if (!actIslandVisible) return
            if (actIslandWaveBox?.visibility == View.VISIBLE) {
                val baseTarget = when {
                    actIslandListening -> actTargetVoiceLevel
                    actIslandSpeaking || AssistantVoiceSpeaker.isSpeakingNow -> AssistantVoiceSpeaker.currentVoiceWaveLevel
                    else -> 0.42f
                }
                actSmoothedVoiceLevel += (baseTarget - actSmoothedVoiceLevel) * 0.24f
                actWavePhaseRad += if (actIslandListening || actIslandSpeaking) 0.26 else 0.16
                for (i in actIslandWaveBars.indices) {
                    val bar = actIslandWaveBars[i]
                    val wave = ((sin(actWavePhaseRad + i * 1.15) + 1.0) * 0.5).toFloat()
                    val scale = (0.24f + actSmoothedVoiceLevel * (0.35f + 0.41f * wave)).coerceIn(0.22f, 1.0f)
                    bar.scaleY = scale
                }
                actIslandHandler.postDelayed(this, 16L)
            }
        }
    }

    private var pendingPresetId: String? = null
    private var pendingKeyDisplayName: String = ""
    private var capturedKeyCode = 0
    private var capturedScanCode = 0

    private val viewModel: LauncherViewModel by viewModels {
        LauncherViewModel.Factory(
            appLauncher = AppLauncher(applicationContext),
            networkMonitor = NetworkMonitor(applicationContext),
            demoReplyText = getString(R.string.fake_ai_demo_response)
        )
    }

    private val audioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            DynamicIslandBus.triggerAssistant(this)
        }
    }

    private val timeChangeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            viewModel.refreshTimeAndDate(forceDate = true)
        }
    }

    private val volumeChangeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            refreshSoundTileState()
            if (!KeyMapperAccessibilityService.isServiceConnectedAlive) {
                showCustomVolumeHud()
            }
        }
    }

    private val mediaBroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            MediaStateBus.handleMediaBroadcastIntent(this@LauncherActivity, intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLauncherBinding.inflate(layoutInflater)
        setContentView(binding.root)

        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        appLauncherDirect = AppLauncher(applicationContext)
        iconStylizer = IconStylizer(applicationContext)
        burnInProtector = BurnInProtector(
            targetView = binding.contentContainer,
            density = resources.displayMetrics.density
        )

        currentAccentColor = try {
            Color.parseColor(appLauncherDirect.getAccentColorHex())
        } catch (_: Exception) {
            Color.parseColor("#00F0FF")
        }

        binding.tvNowPlayingTitle.isSelected = true

        val cornerPx = 12f * resources.displayMetrics.density
        binding.ivNowPlayingArt.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, cornerPx)
            }
        }
        binding.ivNowPlayingArt.clipToOutline = true

        VolumeHudBus.onVolumeIntercepted = {
            refreshSoundTileState()
            if (!KeyMapperAccessibilityService.isServiceConnectedAlive) {
                showCustomVolumeHud()
            }
        }

        DynamicIslandBus.onRequestAudioPermissionInActivity = {
            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }

        RemoteConsoleServer.ensureStarted(this)

        DynamicIslandBus.onTriggerIslandInActivity = {
            triggerActivityDynamicIsland(isFollowUp = false)
        }

        DynamicIslandBus.onTriggerVoiceTextInActivity = { spokenText ->
            triggerActivityDynamicIslandWithText(spokenText)
        }

        DynamicIslandBus.onHomePressedInActivity = {
            runOnUiThread {
                closeAllOverlays(restoreFocus = false)
                if (::appStrip.isInitialized) {
                    appStrip.scrollToStart(animated = true)
                }
                binding.cardYoutube.requestFocus()
                binding.cardYoutube.post { binding.cardYoutube.requestFocus() }
            }
        }
        DynamicIslandBus.onDispatchKeyInActivity = { keyCode ->
            if (hasWindowFocus()) {
                val now = SystemClock.uptimeMillis()
                dispatchKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0))
                dispatchKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_UP, keyCode, 0))
                true
            } else {
                false
            }
        }

        DynamicIslandBus.onIslandVisibilityChanged = { islandExpanded ->
            if (binding.controlCenterPanel.visibility != View.VISIBLE) {
                binding.bottomLeftPillsRow.visibility = if (islandExpanded) View.INVISIBLE else View.VISIBLE
            }
        }

        OutageRepository.onOpenScheduleRequested = {
            if (binding.outageSchedulePanel.visibility != View.VISIBLE) {
                openOutageSchedulePanel(lastFocusedMainCard ?: binding.cardYoutube)
            }
        }

        LocalVoiceCommandRouter.onThemeColorChanged = { hex ->
            try {
                currentAccentColor = Color.parseColor(hex)
                applyAccentColorTheme()
                DynamicIslandBus.notifyAccentColorChanged(hex)
            } catch (_: Exception) {
            }
        }

        window.decorView.isSoundEffectsEnabled = false
        NavSoundPlayer.init(this)
        AssistantVoiceSpeaker.init(this)
        ServiceAutoActivator.ensureServicesActive(this)

        setupMainCardsAndCornerPill()
        setupAppStrip()
        setupNowPlayingHoverControls()
        setupControlCenterPanel()
        setupOutageSchedulePanel()
        setupLauncherSettingsOverlay()
        loadNightModeSettings()
        setupAppManageOverlay()
        setupRemoteKeySelectOverlay()
        applyAccentColorTheme()
        observeStateAndLifecycle()

        binding.cardYoutube.requestFocus()
        handleIncomingIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        ServiceAutoActivator.ensureServicesActive(this)
        viewModel.reloadInstalledApps()
        updateAccessibilityStatusRow()
        MediaStateBus.pollActiveControllerLight(this)
        lifecycleScope.launch { OutageRepository.refreshIfNeeded(this@LauncherActivity, force = false) }
        if (binding.controlCenterPanel.visibility == View.VISIBLE) {
            refreshControlCenterToggles()
        }
    }

    override fun onDestroy() {
        VolumeHudBus.onVolumeIntercepted = null
        DynamicIslandBus.onRequestAudioPermissionInActivity = null
        DynamicIslandBus.onTriggerIslandInActivity = null
        DynamicIslandBus.onTriggerVoiceTextInActivity = null
        DynamicIslandBus.onDispatchKeyInActivity = null
        DynamicIslandBus.onHomePressedInActivity = null
        collapseActivityDynamicIsland()
        DynamicIslandBus.onIslandVisibilityChanged = null
        OutageRepository.onOpenScheduleRequested = null
        TuyaSmartHomeController.onStateUpdatedUiCallback = null
        KeyCaptureBus.isCapturingKey = false
        KeyCaptureBus.onKeyCapturedListener = null
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        burnInProtector.onUserInteraction(lifecycleScope)
        silentCleanBackgroundProcesses()
        if (handleIncomingIntent(intent)) {
            return
        }
        closeAllOverlays(restoreFocus = false)
        if (::appStrip.isInitialized) {
            appStrip.scrollToStart(animated = true)
        }
        viewModel.onHomeIntentReceived()
        binding.cardYoutube.requestFocus()
        binding.cardYoutube.post { binding.cardYoutube.requestFocus() }
    }

    private fun handleIncomingIntent(intent: Intent?): Boolean {
        if (intent == null) return false
        val action = intent.action
        val remoteVoiceQuery = intent.getStringExtra("EXTRA_VOICE_QUERY").orEmpty().trim()
        if (remoteVoiceQuery.isNotEmpty()) {
            intent.removeExtra("EXTRA_VOICE_QUERY")
            closeAllOverlays(restoreFocus = false)
            triggerActivityDynamicIslandWithText(remoteVoiceQuery)
            return true
        }
        if (action == Intent.ACTION_ASSIST ||
            action == Intent.ACTION_VOICE_COMMAND ||
            action == Intent.ACTION_SEARCH_LONG_PRESS ||
            intent.getBooleanExtra("EXTRA_OPEN_AI", false)
        ) {
            intent.removeExtra("EXTRA_OPEN_AI")
            closeAllOverlays(restoreFocus = false)
            triggerGeminiDynamicIsland()
            return true
        }
        if (intent.getBooleanExtra("EXTRA_OPEN_CONTROL_CENTER", false)) {
            intent.removeExtra("EXTRA_OPEN_CONTROL_CENTER")
            if (binding.controlCenterPanel.visibility == View.VISIBLE) {
                hideControlCenter(restoreFocus = true)
            } else {
                closeAllOverlays(restoreFocus = false)
                openControlCenter(lastFocusedMainCard ?: binding.cardYoutube)
            }
            return true
        }
        if (intent.getBooleanExtra("EXTRA_OPEN_ALL_APPS", false)) {
            intent.removeExtra("EXTRA_OPEN_ALL_APPS")
            closeAllOverlays(restoreFocus = false)
            openAppPickerOverlay(assignSlot = null, forKeyBind = false)
            return true
        }
        return false
    }

    private fun dpPx(dpVal: Float): Int = (dpVal * resources.displayMetrics.density + 0.5f).toInt()

    private fun getNightAdjustedBorderColor(accent: Int): Int {
        // Днём (nightModeGlowFactor = 1.0) яркость обводки 100%, ночью (0.6) плавно смягчается до 75% (x0.75)
        val t = ((nightModeGlowFactor - 0.6f) / 0.4f).coerceIn(0f, 1f)
        val borderBrightnessFactor = 0.75f + 0.25f * t
        val hsv = FloatArray(3)
        Color.colorToHSV(accent, hsv)
        hsv[2] = (hsv[2] * borderBrightnessFactor).coerceIn(0.25f, 1.0f)
        return Color.HSVToColor(hsv)
    }

    private fun createCardSelectorDrawable(accent: Int): StateListDrawable {
        val borderColor = getNightAdjustedBorderColor(accent)
        val focused = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(20f).toFloat()
            setColor(Color.parseColor("#20222A"))
            setStroke(dpPx(2f), borderColor)
        }
        val idle = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(20f).toFloat()
            setColor(Color.parseColor("#16171B"))
            setStroke(dpPx(1f), Color.parseColor("#23252C"))
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(android.R.attr.state_selected), focused)
            addState(intArrayOf(), idle)
        }
    }

    private fun createMenuSelectorDrawable(accent: Int): StateListDrawable {
        val focused = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(14f).toFloat()
            setColor(ColorUtils.setAlphaComponent(accent, 36))
            setStroke(dpPx(2f), accent)
        }
        val idle = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(14f).toFloat()
            setColor(Color.parseColor("#1B1D24"))
            setStroke(dpPx(1f), Color.parseColor("#2A2D37"))
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(android.R.attr.state_selected), focused)
            addState(intArrayOf(), idle)
        }
    }

    private fun createMediaBtnSelectorDrawable(accent: Int): StateListDrawable {
        val focused = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(10f).toFloat()
            setColor(ColorUtils.setAlphaComponent(accent, 42))
            setStroke(dpPx(2f), accent)
        }
        val idle = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(10f).toFloat()
            setColor(Color.parseColor("#1B1D24"))
            setStroke(dpPx(1f), Color.parseColor("#2A2D37"))
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(), idle)
        }
    }

    private fun createCornerPillSelectorDrawable(accent: Int): StateListDrawable {
        val focused = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(22f).toFloat()
            setColor(ColorUtils.setAlphaComponent(accent, 38))
            setStroke(dpPx(2f), accent)
        }
        val idle = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(22f).toFloat()
            setColor(Color.parseColor("#14151A"))
            setStroke(dpPx(1f), Color.parseColor("#282B34"))
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(), idle)
        }
    }

    private fun createToggleDrawable(accent: Int, isActive: Boolean): StateListDrawable {
        val topIdle = if (isActive) ColorUtils.blendARGB(Color.parseColor("#252A38"), accent, 0.24f) else Color.parseColor("#E6222632")
        val botIdle = if (isActive) ColorUtils.blendARGB(Color.parseColor("#181C26"), accent, 0.14f) else Color.parseColor("#E6161922")
        val topFocus = if (isActive) ColorUtils.blendARGB(Color.parseColor("#2D3446"), accent, 0.36f) else Color.parseColor("#F22B3040")
        val botFocus = if (isActive) ColorUtils.blendARGB(Color.parseColor("#1E2330"), accent, 0.22f) else Color.parseColor("#F21C202B")
        val baseStroke = if (isActive) ColorUtils.setAlphaComponent(accent, 155) else Color.parseColor("#36FFFFFF")

        val focused = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(topFocus, botFocus)
        ).apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(28f).toFloat()
            setStroke(dpPx(2f), accent)
        }
        val idle = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(topIdle, botIdle)
        ).apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(28f).toFloat()
            setStroke(dpPx(1f), baseStroke)
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(android.R.attr.state_selected), focused)
            addState(intArrayOf(), idle)
        }
    }

    private fun createSquircleIconDrawable(accent: Int): StateListDrawable {
        val focused = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(
                ColorUtils.blendARGB(Color.parseColor("#2C3242"), accent, 0.30f),
                ColorUtils.blendARGB(Color.parseColor("#1B1F2A"), accent, 0.16f)
            )
        ).apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(16f).toFloat()
            setStroke(dpPx(2f), accent)
        }
        val idle = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(Color.parseColor("#E6222632"), Color.parseColor("#E6151820"))
        ).apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(16f).toFloat()
            setStroke(dpPx(1f), Color.parseColor("#33FFFFFF"))
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(android.R.attr.state_selected), focused)
            addState(intArrayOf(), idle)
        }
    }

    private fun createPanelDrawable(accent: Int, radiusDp: Float): Drawable {
        return GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(radiusDp).toFloat()
            setColor(Color.parseColor("#F2101115"))
            setStroke(dpPx(2f), ColorUtils.setAlphaComponent(accent, 190))
        }
    }

    /**
     * Динамическое применение выбранного цвета обводки и акцентов ко всему лаунчеру на лету!
     */
    private fun applyAccentColorTheme() {
        val accent = currentAccentColor

        binding.cardYoutube.background = createCardSelectorDrawable(accent)
        binding.cardBrowser.background = createCardSelectorDrawable(accent)
        binding.cardCast.background = createCardSelectorDrawable(accent)
        binding.cardAi.background = createCardSelectorDrawable(accent)
        applyGlowToFocusedCards()

        binding.statusCornerPill.background = createCornerPillSelectorDrawable(accent)
        binding.outageCornerPill.background = createCornerPillSelectorDrawable(accent)
        binding.ivWifiCorner.setColorFilter(accent, PorterDuff.Mode.SRC_IN)
        binding.ivControlCenterIcon.setColorFilter(accent, PorterDuff.Mode.SRC_IN)
        refreshActivityIslandAccent(accent)
        binding.outageSchedulePanel.background = createPanelDrawable(accent, 22f)
        binding.btnOutageQueue.background = createMenuSelectorDrawable(accent)
        renderOutageWidgetAndPanel(OutageRepository.state.value)

        updateNowPlayingCardHoverBorder(isAnyPlayerButtonFocused())
        binding.ivNowPlayingArt.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(12f).toFloat()
            setColor(ColorUtils.setAlphaComponent(accent, 22))
        }

        binding.volumeHudCard.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(999f).toFloat()
            setColor(Color.parseColor("#F20D0F14"))
            setStroke(dpPx(2f), ColorUtils.setAlphaComponent(accent, 140))
        }
        binding.vVolumeHudFill.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(999f).toFloat()
            setColor(accent)
        }

        binding.controlCenterPanel.background = if (isSmartHomeTabActive) createPanelDrawable(accent, 22f) else null
        binding.btnCcQuickLedStudio.background = createSquircleIconDrawable(accent)
        binding.btnMenuBindKey.background = createSquircleIconDrawable(accent)
        binding.btnMenuAssignCurrent.background = createSquircleIconDrawable(accent)
        binding.btnMenuSystemSettings.background = createSquircleIconDrawable(accent)
        refreshSmartHomeUiState()
        binding.llLauncherSettingsPanel.background = createPanelDrawable(accent, 22f)
        binding.llAppManagePanel.background = createPanelDrawable(accent, 22f)
        binding.llRemoteKeyPanel.background = createPanelDrawable(accent, 22f)
        binding.llKeyCapturePanel.background = createPanelDrawable(accent, 22f)
        binding.llAppPickerPanel.background = createPanelDrawable(accent, 22f)
        binding.llAssistantPanel.background = createPanelDrawable(accent, 22f)

        binding.tvLauncherSettingsTitle.setTextColor(accent)
        binding.tvPickerTitle.setTextColor(accent)
        binding.tvAppManageTitle.setTextColor(accent)
        binding.tvRemoteKeyTitle.setTextColor(accent)
        binding.tvKeyCaptureTitle.setTextColor(accent)
        binding.tvOverlayTitle.setTextColor(accent)
        binding.ivOverlayMic.setColorFilter(accent, PorterDuff.Mode.SRC_IN)

        val menuButtons = listOf(

            binding.barLedHueSpectrum,
            binding.btnLedBrightness,
            binding.btnLedSaturation,

            binding.btnEditSlot1,
            binding.btnEditSlot2,
            binding.btnEditSlot3,
            binding.btnEditSlot4,
            binding.btnReorderStrip,
            binding.btnToggleNavSound,
            binding.btnToggleAiTts,
            binding.btnCycleAiVoice,
            binding.btnToggleNightMode,
            binding.btnColorCyan,
            binding.btnColorEmerald,
            binding.btnColorAmber,
            binding.btnColorSapphire,
            binding.btnColorAmethyst,
            binding.btnColorSilver,
            binding.btnUpdateLauncher,
            binding.btnAppManageOpen,
            binding.btnAppManageUninstall,
            binding.btnAppManageInfo,
            binding.btnKeyEnableAccessibility,
            binding.btnKeyPresetPatchwall,
            binding.btnKeyPresetNetflix,
            binding.btnKeyPresetPrime,
            binding.btnKeyCustomListen
        )
        menuButtons.forEach { btn ->
            btn.background = createMenuSelectorDrawable(accent)
        }

        binding.btnNpPrev.background = createMediaBtnSelectorDrawable(accent)
        binding.btnNpPlayPause.background = createMediaBtnSelectorDrawable(accent)
        binding.btnNpNext.background = createMediaBtnSelectorDrawable(accent)
        binding.btnNpClose.background = createMediaBtnSelectorDrawable(Color.parseColor("#FF5252"))

        binding.tvNowPlayingTime.setTextColor(accent)
        binding.vNowPlayingVisualizer.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(3f).toFloat()
            setColor(accent)
        }

        // Обновляем тинт иконок на главных карточках
        val cardPairs = listOf(
            binding.cardYoutube to binding.ivCard1,
            binding.cardBrowser to binding.ivCard2,
            binding.cardCast to binding.ivCard3,
            binding.cardAi to binding.ivCardAi
        )
        cardPairs.forEach { (card, icon) ->
            val tint = if (card.hasFocus()) accent else getColor(R.color.text_primary)
            icon.setColorFilter(tint, PorterDuff.Mode.SRC_IN)
        }

        refreshControlCenterToggles()
        renderNowPlayingWidget(MediaStateBus.state.value)
    }

    private fun setupNowPlayingHoverControls() {
        val npButtons = listOf(
            binding.btnNpPrev to binding.ivNpPrev,
            binding.btnNpPlayPause to binding.ivNpPlayPause,
            binding.btnNpNext to binding.ivNpNext,
            binding.btnNpClose to binding.ivNpClose
        )

        npButtons.forEach { (btn, icon) ->
            icon.setColorFilter(getColor(R.color.text_primary), PorterDuff.Mode.SRC_IN)
            btn.setOnFocusChangeListener { _, hasFocus ->
                val tint = if (hasFocus) {
                    if (btn.id == R.id.btnNpClose) getColor(R.color.status_error) else currentAccentColor
                } else {
                    getColor(R.color.text_primary)
                }
                icon.setColorFilter(tint, PorterDuff.Mode.SRC_IN)
                if (hasFocus) {
                    binding.llNowPlayingControls.visibility = View.VISIBLE
                    updateNowPlayingCardHoverBorder(true)
                } else {
                    binding.nowPlayingCard.post {
                        if (!isAnyPlayerButtonFocused()) {
                            updateNowPlayingCardHoverBorder(false)
                        }
                    }
                }
            }
        }

        binding.btnNpPrev.setOnClickListener {
            MediaStateBus.dispatchTransportAction("PREV", audioManager)
            lifecycleScope.launch {
                delay(250L)
                MediaStateBus.pollActiveControllerLight(this@LauncherActivity)
            }
        }

        binding.btnNpPlayPause.setOnClickListener {
            MediaStateBus.dispatchTransportAction("PLAY_PAUSE", audioManager)
            val nowPlaying = MediaStateBus.state.value.isPlaying
            binding.ivNpPlayPause.setImageResource(
                if (nowPlaying) R.drawable.ic_media_pause else R.drawable.ic_media_play
            )
            updateLiveTrackProgressTick()
        }

        binding.btnNpNext.setOnClickListener {
            MediaStateBus.dispatchTransportAction("NEXT", audioManager)
            lifecycleScope.launch {
                delay(250L)
                MediaStateBus.pollActiveControllerLight(this@LauncherActivity)
            }
        }

        binding.btnNpClose.setOnClickListener {
            MediaStateBus.dismissPlayerByUser(audioManager)
            binding.llNowPlayingControls.visibility = View.GONE
            updateNowPlayingCardHoverBorder(false)
            binding.nowPlayingCard.visibility = View.GONE
            (lastFocusedMainCard ?: binding.cardYoutube).requestFocus()
        }

        binding.nowPlayingCard.setOnClickListener {
            val nowVis = binding.llNowPlayingControls.visibility == View.VISIBLE
            binding.llNowPlayingControls.visibility = if (nowVis) View.GONE else View.VISIBLE
            updateNowPlayingCardHoverBorder(!nowVis)
        }
    }

    private fun isAnyPlayerButtonFocused(): Boolean {
        return binding.btnNpPrev.hasFocus() ||
            binding.btnNpPlayPause.hasFocus() ||
            binding.btnNpNext.hasFocus() ||
            binding.btnNpClose.hasFocus()
    }

    /**
     * Обводка вокруг плеера появляется ТОЛЬКО при наведении фокуса на трек!
     * В обычном режиме фон и рамка полностью прозрачные (#00000000).
     */
    private fun updateNowPlayingCardHoverBorder(isHovered: Boolean) {
        if (isHovered) {
            binding.nowPlayingCard.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpPx(16f).toFloat()
                setColor(Color.parseColor("#14FFFFFF"))
                setStroke(dpPx(1f), currentAccentColor)
            }
        } else {
            binding.nowPlayingCard.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpPx(16f).toFloat()
                setColor(Color.TRANSPARENT)
            }
        }
    }

    private fun handleCustomVolumeKey(keyCode: Int) {
        try {
            when (keyCode) {
                KeyEvent.KEYCODE_VOLUME_UP -> {
                    audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0)
                }
                KeyEvent.KEYCODE_VOLUME_DOWN -> {
                    audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0)
                }
                KeyEvent.KEYCODE_VOLUME_MUTE -> {
                    audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, 0)
                }
            }
        } catch (_: Exception) {
        }

        refreshSoundTileState()
        showCustomVolumeHud()
    }

    private fun showCustomVolumeHud() {
        val isMuted = try {
            audioManager.isStreamMute(AudioManager.STREAM_MUSIC)
        } catch (_: Exception) {
            false
        }
        val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val pct = if (isMuted) 0 else ((curVol * 100f) / maxVol).toInt().coerceIn(0, 100)

        binding.tvVolumeHudPct.text = "$pct%"
        val activeColor = if (pct > 0) currentAccentColor else getColor(R.color.status_error)
        binding.tvVolumeHudPct.setTextColor(activeColor)
        binding.ivVolumeHudIcon.setColorFilter(activeColor, PorterDuff.Mode.SRC_IN)
        binding.vVolumeHudFill.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(999f).toFloat()
            setColor(activeColor)
        }

        binding.flVolumeHudTrack.post {
            val totalW = binding.flVolumeHudTrack.width.coerceAtLeast(100)
            val fillW = ((totalW * pct) / 100).coerceAtLeast(if (pct > 0) 6 else 0)
            val lp = binding.vVolumeHudFill.layoutParams
            if (lp.width != fillW) {
                lp.width = fillW
                binding.vVolumeHudFill.layoutParams = lp
            }
        }

        val hud = binding.volumeHudCard
        if (hud.visibility != View.VISIBLE) {
            hud.alpha = 0f
            hud.visibility = View.VISIBLE
            hud.animate().alpha(1f).setDuration(110L).start()
        } else {
            hud.animate().cancel()
            hud.alpha = 1f
        }

        volumeHudHideJob?.cancel()
        volumeHudHideJob = lifecycleScope.launch {
            delay(1600L)
            hud.animate()
                .alpha(0f)
                .setDuration(180L)
                .withEndAction { hud.visibility = View.GONE }
                .start()
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            burnInProtector.onUserInteraction(lifecycleScope)
        }

        val keyCode = event.keyCode
        val scanCode = event.scanCode

        if (event.action == KeyEvent.ACTION_DOWN &&
            (isDpadDirectionKey(keyCode) || isCenterKey(keyCode) || keyCode == KeyEvent.KEYCODE_BACK)
        ) {
            NavSoundPlayer.playClick(this)
        }

        if (actIslandVisible) {
            if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                    collapseActivityDynamicIsland()
                }
                return true
            }
            if (isCenterKey(keyCode)) {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                    if (actIslandListening) {
                        actIslandListening = false
                    } else if (actIslandSpeaking || AssistantVoiceSpeaker.isSpeakingNow) {
                        AssistantVoiceSpeaker.stop(this)
                        actIslandSpeaking = false
                        triggerActivityDynamicIsland(isFollowUp = true)
                    } else {
                        triggerActivityDynamicIsland(isFollowUp = true)
                    }
                }
                return true
            }
        }

        // Перехватываем громкость с флагом 0 (без штатного ползунка) и выводим наш капсульный HUD в стиле системы!
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
            keyCode == KeyEvent.KEYCODE_VOLUME_DOWN ||
            keyCode == KeyEvent.KEYCODE_VOLUME_MUTE
        ) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                handleCustomVolumeKey(keyCode)
            }
            return true
        }

        if (::stripReorder.isInitialized && stripReorder.isVisible) {
            stripReorder.handleKey(event)
            return true
        }

        if (binding.keyCaptureOverlay.visibility == View.VISIBLE) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
                    stopLiveKeyCapture()
                    binding.remoteKeySelectOverlay.visibility = View.VISIBLE
                    binding.btnKeyCustomListen.requestFocus()
                    return true
                }
                if (!isDpadDirectionKey(keyCode) && !isCenterKey(keyCode)) {
                    onLiveKeyCaught(keyCode, scanCode)
                    return true
                }
            }
            return true
        }

        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                when {
                    binding.appManageOverlay.visibility == View.VISIBLE -> {
                        binding.appManageOverlay.visibility = View.GONE
                        binding.appPickerOverlay.visibility = View.VISIBLE
                        binding.llAppListContainer.requestFocus()
                    }
                    binding.appPickerOverlay.visibility == View.VISIBLE -> {
                        binding.appPickerOverlay.visibility = View.GONE
                        if (returnToLauncherSettingsAfterAssign) {
                            returnToLauncherSettingsAfterAssign = false
                            openLauncherSettingsOverlay()
                        } else {
                            openControlCenter(lastFocusedMainCard)
                        }
                    }
                    binding.launcherSettingsOverlay.visibility == View.VISIBLE -> {
                        binding.launcherSettingsOverlay.visibility = View.GONE
                        openControlCenter(lastFocusedMainCard)
                    }
                    binding.remoteKeySelectOverlay.visibility == View.VISIBLE -> {
                        binding.remoteKeySelectOverlay.visibility = View.GONE
                        openControlCenter(lastFocusedMainCard)
                    }
                    binding.outageSchedulePanel.visibility == View.VISIBLE -> {
                        hideOutageSchedulePanel(restoreFocus = true)
                    }
                    binding.controlCenterPanel.visibility == View.VISIBLE -> {
                        hideControlCenter(restoreFocus = true)
                    }
                    binding.assistantOverlay.visibility == View.VISIBLE -> {
                        viewModel.closeAssistantOverlay(restoreFocusToAi = true)
                    }
                    ::appStrip.isInitialized && (appStrip.canScrollLeft() || appStrip.isAnimating) -> {
                        appStrip.scrollToStart(animated = true)
                        binding.cardYoutube.requestFocus()
                        binding.cardYoutube.post { binding.cardYoutube.requestFocus() }
                    }
                }
            }
            return true
        }

        if (keyCode == KeyEvent.KEYCODE_HOME) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                closeAllOverlays(restoreFocus = false)
                if (::appStrip.isInitialized) {
                    appStrip.scrollToStart(animated = true)
                }
                binding.cardYoutube.requestFocus()
                binding.cardYoutube.post { binding.cardYoutube.requestFocus() }
            }
            return true
        }

        if (binding.controlCenterPanel.visibility == View.VISIBLE &&
            event.action == KeyEvent.ACTION_DOWN &&
            (keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT)
        ) {
            val dir = if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT) 1 else -1
            when (currentFocus?.id) {
                R.id.barLedHueSpectrum -> {
                    NavSoundPlayer.playClick(this)
                    TuyaSmartHomeController.stepHueByDelta(this, dir * 10)
                    return true
                }
                R.id.btnLedBrightness -> {
                    NavSoundPlayer.playClick(this)
                    TuyaSmartHomeController.stepBrightnessByDelta(this, dir * 10)
                    return true
                }
                R.id.btnLedSaturation -> {
                    NavSoundPlayer.playClick(this)
                    TuyaSmartHomeController.stepSaturationByDelta(this, dir * 15)
                    return true
                }
            }
        }

        if (::appStrip.isInitialized &&
            !isAnyOverlayOpen() &&
            event.action == KeyEvent.ACTION_DOWN &&
            (keyCode == KeyEvent.KEYCODE_DPAD_LEFT || keyCode == KeyEvent.KEYCODE_DPAD_RIGHT)
        ) {
            val focusId = currentFocus?.id
            if (keyCode == KeyEvent.KEYCODE_DPAD_RIGHT &&
                (focusId == R.id.cardBrowser || focusId == R.id.cardAi) &&
                (appStrip.canScrollRight() || appStrip.isAnimating)
            ) {
                if (!appStrip.isAnimating) appStrip.scrollRight(event.repeatCount > 0)
                return true
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT &&
                (focusId == R.id.cardYoutube || focusId == R.id.cardCast) &&
                (appStrip.canScrollLeft() || appStrip.isAnimating)
            ) {
                if (!appStrip.isAnimating) appStrip.scrollLeft(event.repeatCount > 0)
                return true
            }
        }

        if (!isAnyOverlayOpen() &&
            keyCode == KeyEvent.KEYCODE_DPAD_LEFT &&
            event.action == KeyEvent.ACTION_DOWN &&
            event.repeatCount == 0 &&
            (currentFocus?.id == R.id.cardYoutube || currentFocus?.id == R.id.cardCast) &&
            binding.nowPlayingCard.visibility == View.VISIBLE
        ) {
            binding.llNowPlayingControls.visibility = View.VISIBLE
            updateNowPlayingCardHoverBorder(true)
            binding.llNowPlayingControls.post {
                binding.btnNpPlayPause.requestFocus()
            }
            return true
        }

        if (keyCode == KeyEvent.KEYCODE_VOICE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_SEARCH ||
            scanCode == 582 || scanCode == 217 || scanCode == 221
        ) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                val custom = appLauncherDirect.getKeyBinding(keyCode, scanCode)
                if (!custom.isNullOrEmpty()) {
                    executeCustomKeyTarget(custom)
                } else {
                    triggerGeminiDynamicIsland()
                }
            }
            return true
        }

        if (!isDpadDirectionKey(keyCode) && !isCenterKey(keyCode)) {
            val boundTarget = resolveLocalKeyOrPreset(keyCode, scanCode)
            if (!boundTarget.isNullOrEmpty()) {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                    executeCustomKeyTarget(boundTarget)
                }
                return true
            }
        }

        if (keyCode == KeyEvent.KEYCODE_MENU ||
            keyCode == KeyEvent.KEYCODE_ALL_APPS ||
            keyCode == KeyEvent.KEYCODE_GUIDE ||
            keyCode == KeyEvent.KEYCODE_SETTINGS ||
            keyCode == KeyEvent.KEYCODE_TV_INPUT
        ) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                if (binding.controlCenterPanel.visibility == View.VISIBLE) {
                    hideControlCenter(restoreFocus = true)
                } else {
                    openControlCenter(currentFocus)
                }
            }
            return true
        }

        if (!isAnyOverlayOpen() && isMainGridCardFocused() && isCenterKey(keyCode)) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                if (event.repeatCount == 0) {
                    mainCardLongPressConsumed = false
                } else if (!mainCardLongPressConsumed && (event.isLongPress || event.repeatCount >= 2)) {
                    mainCardLongPressConsumed = true
                    triggerMainCardLongPressUninstall(currentFocus)
                    return true
                } else if (mainCardLongPressConsumed) {
                    return true
                }
            } else if (event.action == KeyEvent.ACTION_UP && mainCardLongPressConsumed) {
                mainCardLongPressConsumed = false
                return true
            }
        }

        return super.dispatchKeyEvent(event)
    }

    private fun isMainGridCardFocused(): Boolean {
        val id = currentFocus?.id ?: return false
        return id == R.id.cardYoutube ||
            id == R.id.cardBrowser ||
            id == R.id.cardCast ||
            id == R.id.cardAi
    }

    private fun resolveLocalKeyOrPreset(keyCode: Int, scanCode: Int): String? {
        if (keyCode == KeyEvent.KEYCODE_ALL_APPS ||
            keyCode == KeyEvent.KEYCODE_MENU ||
            keyCode == KeyEvent.KEYCODE_GUIDE ||
            keyCode == KeyEvent.KEYCODE_SETTINGS ||
            keyCode == KeyEvent.KEYCODE_TV_INPUT ||
            keyCode == KeyEvent.KEYCODE_BUTTON_1 ||
            scanCode == 139 || scanCode == 362 || scanCode == 172 || scanCode == 256
        ) {
            appLauncherDirect.getPresetBinding("PATCHWALL")?.let { if (it.isNotEmpty()) return it }
        }
        if (keyCode == KeyEvent.KEYCODE_BUTTON_2 || keyCode == KeyEvent.KEYCODE_PROG_RED || scanCode == 412 || scanCode == 398 || keyCode == 309) {
            appLauncherDirect.getPresetBinding("NETFLIX")?.let { if (it.isNotEmpty()) return it }
        }
        if (keyCode == KeyEvent.KEYCODE_BUTTON_3 || keyCode == KeyEvent.KEYCODE_PROG_BLUE || scanCode == 413 || scanCode == 401 || keyCode == 310) {
            appLauncherDirect.getPresetBinding("PRIME")?.let { if (it.isNotEmpty()) return it }
        }
        return appLauncherDirect.getKeyBinding(keyCode, scanCode)
    }

    private var mainCardLongPressConsumed: Boolean = false

    private fun resolveAppForMainCard(cardView: View?): InstalledAppInfo? {
        if (cardView == null) return null
        val flat = if (::appStrip.isInitialized) appStrip.appIndexFor(cardView) else -1
        if (flat < 0) return null
        if (flat < 4) {
            val st = viewModel.uiState.value
            return when (flat) {
                0 -> st.slot1App
                1 -> st.slot3App
                2 -> st.slot2App
                else -> st.slot4App
            }
        }
        return stripApps.getOrNull(flat)
    }

    private fun triggerMainCardLongPressUninstall(cardView: View?): Boolean {
        val app = resolveAppForMainCard(cardView) ?: return false
        if (app.packageName == packageName) return false
        NavSoundPlayer.playClick(this)
        launchUninstallApp(app.packageName)
        return true
    }

    private fun triggerMainCardShortClick(cardView: View?) {
        if (cardView == null) return
        val flat = if (::appStrip.isInitialized) appStrip.appIndexFor(cardView) else -1
        if (flat < 0) return
        if (flat < 4) {
            val slot = when (flat) {
                0 -> CardSlot.SLOT_1
                1 -> CardSlot.SLOT_3
                2 -> CardSlot.SLOT_2
                else -> CardSlot.SLOT_4
            }
            viewModel.onSlotCardClicked(slot)
        } else {
            stripApps.getOrNull(flat)?.let { viewModel.launchAppDirectly(it) }
        }
    }

    private fun triggerGeminiDynamicIsland() {
        if (!hasAudioPermission()) {
            audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        DynamicIslandBus.triggerAssistant(this)
    }

    private fun executeCustomKeyTarget(target: String) {
        when (target) {
            "ACTION_CONTROL_CENTER" -> {
                if (binding.controlCenterPanel.visibility == View.VISIBLE) {
                    hideControlCenter(restoreFocus = true)
                } else {
                    closeAllOverlays(restoreFocus = false)
                    openControlCenter(lastFocusedMainCard ?: binding.cardYoutube)
                }
            }
            "ACTION_ALL_APPS" -> {
                closeAllOverlays(restoreFocus = false)
                openAppPickerOverlay(assignSlot = null, forKeyBind = false)
            }
            "ACTION_SETTINGS" -> {
                closeAllOverlays(restoreFocus = true)
                viewModel.launchSystemSettings()
            }
            "ACTION_AI" -> {
                closeAllOverlays(restoreFocus = false)
                triggerGeminiDynamicIsland()
            }
            else -> {
                MediaStateBus.onMediaAppOpened(target)
                closeAllOverlays(restoreFocus = true)
                appLauncherDirect.launchPackage(target)
            }
        }
    }

    private fun setupMainCardsAndCornerPill() {
        val cardPairs = listOf(
            binding.cardYoutube to binding.ivCard1,
            binding.cardBrowser to binding.ivCard2,
            binding.cardCast to binding.ivCard3,
            binding.cardAi to binding.ivCardAi
        )

        cardPairs.forEach { (card, iconView) ->
            val pvhX = PropertyValuesHolder.ofFloat(View.SCALE_X, LauncherConfig.FOCUS_IDLE_SCALE, LauncherConfig.FOCUS_SCALE)
            val pvhY = PropertyValuesHolder.ofFloat(View.SCALE_Y, LauncherConfig.FOCUS_IDLE_SCALE, LauncherConfig.FOCUS_SCALE)
            val animator = ObjectAnimator.ofPropertyValuesHolder(card, pvhX, pvhY).apply {
                duration = LauncherConfig.FOCUS_ANIM_DURATION_MS
                interpolator = decelerateInterpolator
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationStart(animation: Animator) {
                        card.setLayerType(View.LAYER_TYPE_HARDWARE, null)
                    }

                    override fun onAnimationEnd(animation: Animator) {
                        card.setLayerType(View.LAYER_TYPE_NONE, null)
                    }

                    override fun onAnimationCancel(animation: Animator) {
                        card.setLayerType(View.LAYER_TYPE_NONE, null)
                    }
                })
            }
            focusAnimators[card] = animator

            iconView.setColorFilter(getColor(R.color.text_primary), PorterDuff.Mode.SRC_IN)

            card.setOnFocusChangeListener { v, hasFocus ->
                val iconTint = if (hasFocus) getNightAdjustedBorderColor(currentAccentColor) else getColor(R.color.text_primary)
                iconView.setColorFilter(iconTint, PorterDuff.Mode.SRC_IN)
                applyGlowToCard(v, hasFocus)
                val targetCardScale = if (hasFocus) 1.045f else 1.0f
                val targetCardAlpha = if (hasFocus) 1.0f else 0.90f
                val targetIconScale = if (hasFocus) 1.08f else 1.0f
                v.animate()
                    .scaleX(targetCardScale)
                    .scaleY(targetCardScale)
                    .alpha(targetCardAlpha)
                    .setDuration(180L)
                    .setInterpolator(android.view.animation.PathInterpolator(0.22f, 1f, 0.36f, 1f))
                    .start()
                iconView.animate()
                    .scaleX(targetIconScale)
                    .scaleY(targetIconScale)
                    .setDuration(180L)
                    .setInterpolator(android.view.animation.PathInterpolator(0.22f, 1f, 0.36f, 1f))
                    .start()
                if (hasFocus) {
                    lastFocusedMainCard = v
                    binding.llNowPlayingControls.visibility = View.GONE
                    updateNowPlayingCardHoverBorder(false)
                }
            }

            card.isLongClickable = true
            card.setOnLongClickListener {
                mainCardLongPressConsumed = true
                triggerMainCardLongPressUninstall(card)
                true
            }
            card.setOnClickListener {
                if (mainCardLongPressConsumed) {
                    mainCardLongPressConsumed = false
                    return@setOnClickListener
                }
                triggerMainCardShortClick(card)
            }
        }

        binding.statusCornerPill.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                binding.llNowPlayingControls.visibility = View.GONE
                updateNowPlayingCardHoverBorder(false)
            }
        }

        binding.statusCornerPill.setOnClickListener {
            openControlCenter(lastFocusedMainCard ?: binding.cardYoutube)
        }

        binding.statusCornerPill.setOnLongClickListener {
            triggerGeminiDynamicIsland()
            true
        }

        binding.outageCornerPill.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                binding.llNowPlayingControls.visibility = View.GONE
                updateNowPlayingCardHoverBorder(false)
            }
        }

        binding.outageCornerPill.setOnClickListener {
            if (binding.outageSchedulePanel.visibility == View.VISIBLE) {
                hideOutageSchedulePanel(restoreFocus = false)
            } else {
                openOutageSchedulePanel(lastFocusedMainCard ?: binding.cardYoutube)
            }
        }

        binding.tvClock.setOnClickListener {
            closeAllOverlays(restoreFocus = false)
            triggerGeminiDynamicIsland()
        }
    }

    private fun ensureActivityDynamicIslandCreated() {
        if (actIslandRoot != null) return
        val parent = window.decorView as? FrameLayout ?: return
        val accent = currentAccentColor

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpPx(18f), dpPx(12f), dpPx(18f), dpPx(12f))
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpPx(22f).toFloat()
                setColor(Color.parseColor("#F5101218"))
                setStroke(dpPx(1.8f), accent)
            }
            elevation = dpPx(24f).toFloat()
            visibility = View.GONE
            isClickable = true
            isFocusable = false
            setOnClickListener {
                if (actIslandListening) {
                    actIslandListening = false
                } else if (actIslandSpeaking || AssistantVoiceSpeaker.isSpeakingNow) {
                    AssistantVoiceSpeaker.stop(this@LauncherActivity)
                    actIslandSpeaking = false
                    triggerActivityDynamicIsland(isFollowUp = true)
                } else {
                    collapseActivityDynamicIsland()
                }
            }
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        val spark = ImageView(this).apply {
            layoutParams = LinearLayout.LayoutParams(dpPx(20f), dpPx(20f))
            setImageResource(R.drawable.ic_ai_64)
            setColorFilter(accent, PorterDuff.Mode.SRC_IN)
        }

        val waveBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                dpPx(22f)
            ).apply {
                marginStart = dpPx(10f)
            }
        }
        actIslandWaveBars.clear()
        for (i in 0 until 4) {
            val bar = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(dpPx(3.5f), dpPx(18f)).apply {
                    marginEnd = dpPx(3.5f)
                }
                scaleY = 0.32f
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpPx(99f).toFloat()
                    setColor(accent)
                }
            }
            actIslandWaveBars.add(bar)
            waveBox.addView(bar)
        }

        val statusTv = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginStart = dpPx(10f)
            }
            setTextColor(Color.parseColor("#F3F4F6"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            text = "Слушаю..."
        }

        val hintTv = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                marginStart = dpPx(10f)
            }
            setTextColor(Color.parseColor("#9CA3AF"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            text = "Тап / OK — стоп"
        }

        header.addView(spark)
        header.addView(waveBox)
        header.addView(statusTv)
        header.addView(hintTv)

        val bodyTv = TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                topMargin = dpPx(8f)
            }
            setTextColor(Color.parseColor("#E5E7EB"))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
            setLineSpacing(dpPx(2f).toFloat(), 1.05f)
            maxLines = 7
            ellipsize = TextUtils.TruncateAt.END
            visibility = View.GONE
        }

        root.addView(header)
        root.addView(bodyTv)

        val flp = FrameLayout.LayoutParams(
            dpPx(470f),
            ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.START
            marginStart = dpPx(54f)
            bottomMargin = dpPx(38f)
        }
        parent.addView(root, flp)

        actIslandRoot = root
        actIslandSpark = spark
        actIslandWaveBox = waveBox
        actIslandStatusTv = statusTv
        actIslandHintTv = hintTv
        actIslandBodyTv = bodyTv
    }

    private fun refreshActivityIslandAccent(accent: Int) {
        actIslandRoot?.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(22f).toFloat()
            setColor(Color.parseColor("#F5101218"))
            setStroke(dpPx(1.8f), accent)
        }
        actIslandSpark?.setColorFilter(accent, PorterDuff.Mode.SRC_IN)
        actIslandWaveBars.forEach { bar ->
            bar.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpPx(99f).toFloat()
                setColor(accent)
            }
        }
    }

    private fun morphActivityIslandWidth(targetWidthDp: Float) {
        val root = actIslandRoot ?: return
        val lp = root.layoutParams as? FrameLayout.LayoutParams ?: return
        val endW = dpPx(targetWidthDp)
        if (lp.width != endW) {
            val prevW = if (lp.width > 0) lp.width else dpPx(220f)
            lp.width = endW
            root.layoutParams = lp
            root.pivotX = 0f
            root.pivotY = dpPx(26f).toFloat()
            root.scaleX = (prevW.toFloat() / endW.toFloat()).coerceIn(0.68f, 1.15f)
            root.animate()
                .scaleX(1f)
                .alpha(1f)
                .setDuration(210L)
                .setInterpolator(decelerateInterpolator)
                .start()
        }
    }

    @Suppress("MissingPermission")
    private fun triggerActivityDynamicIsland(isFollowUp: Boolean = false) {
        ensureActivityDynamicIslandCreated()
        refreshActivityIslandAccent(currentAccentColor)

        if (!isFollowUp && actIslandVisible && actIslandListening) {
            actIslandListening = false
            return
        }

        AssistantVoiceSpeaker.stop(this)
        actIslandSpeaking = false
        actIslandHandler.removeCallbacks(actHideIslandRunnable)
        actGeminiJob?.cancel()
        actAudioRecordJob?.cancel()

        val root = actIslandRoot ?: return
        if (!isFollowUp || actIslandBodyTv?.text.isNullOrBlank()) {
            actIslandBodyTv?.visibility = View.GONE
        } else {
            actIslandBodyTv?.visibility = View.VISIBLE
        }
        actIslandWaveBox?.visibility = View.VISIBLE
        actIslandSpark?.setImageResource(R.drawable.ic_ai_mic_24)
        actIslandStatusTv?.text = if (isFollowUp) "Ваш ответ (Тап / Назад — закрыть)" else "Слушаю... говорите"
        actIslandStatusTv?.setTextColor(Color.parseColor("#F3F4F6"))
        actIslandHintTv?.text = if (isFollowUp) "Тап / Назад — выход" else "Тап / OK — готово"
        actIslandVisible = true
        actIslandListening = true
        actIslandFollowUp = isFollowUp
        DynamicIslandBus.notifyIslandVisibility(true)

        if (root.visibility != View.VISIBLE) {
            root.alpha = 0f
            root.visibility = View.VISIBLE
            root.animate().alpha(1f).setDuration(140L).start()
        } else {
            root.animate().cancel()
            root.alpha = 1f
        }

        morphActivityIslandWidth(470f)
        actIslandHandler.removeCallbacks(actPulseWaveRunnable)
        actIslandHandler.post(actPulseWaveRunnable)

        GeminiCloudClient.warmupConnectionAsync(this)
        val followUpMode = isFollowUp
        actAudioRecordJob = lifecycleScope.launch(Dispatchers.IO) {
            delay(50L)
            val sampleRate = 16000
            val minBuf = AudioRecord.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(3200)

            var recorder: AudioRecord? = null
            val pcmOut = ByteArrayOutputStream()
            var maxObservedRms = 0.0
            var heardSpeech = false
            try {
                val sources = intArrayOf(
                    MediaRecorder.AudioSource.VOICE_RECOGNITION,
                    MediaRecorder.AudioSource.MIC,
                    MediaRecorder.AudioSource.DEFAULT
                )
                for (src in sources) {
                    try {
                        val candidate = AudioRecord(
                            src,
                            sampleRate,
                            AudioFormat.CHANNEL_IN_MONO,
                            AudioFormat.ENCODING_PCM_16BIT,
                            minBuf * 2
                        )
                        if (candidate.state == AudioRecord.STATE_INITIALIZED) {
                            recorder = candidate
                            break
                        }
                        candidate.release()
                    } catch (_: Exception) {
                    }
                }

                val rec = recorder
                if (rec != null) {
                    rec.startRecording()
                    val buf = ShortArray(1024)
                    val startMs = SystemClock.elapsedRealtime()
                    var lastSpeechMs = startMs

                    while (isActive && actIslandListening) {
                        val read = rec.read(buf, 0, buf.size)
                        if (read > 0) {
                            var sumSq = 0.0
                            val bb = ByteBuffer.allocate(read * 2).order(ByteOrder.LITTLE_ENDIAN)
                            for (i in 0 until read) {
                                val s = buf[i]
                                bb.putShort(s)
                                sumSq += (s.toDouble() * s.toDouble())
                            }
                            pcmOut.write(bb.array())

                            val rms = sqrt(sumSq / read)
                            if (rms > maxObservedRms) maxObservedRms = rms
                            val db = (rms / 170.0).toFloat().coerceIn(0f, 10f)
                            actTargetVoiceLevel = ((db + 2f) / 10f).coerceIn(0.28f, 1.0f)

                            val now = SystemClock.elapsedRealtime()
                            if (rms > 310) {
                                heardSpeech = true
                                lastSpeechMs = now
                            }
                            if (followUpMode && !heardSpeech && (now - startMs) > 3600L) {
                                break
                            }
                            if (heardSpeech && (now - lastSpeechMs) > 450L && (now - startMs) > 720L) {
                                break
                            }
                            if ((now - startMs) > 5800L) {
                                break
                            }
                        } else {
                            delay(15L)
                        }
                    }
                }
            } catch (_: Exception) {
            } finally {
                try {
                    recorder?.stop()
                } catch (_: Exception) {
                }
                try {
                    recorder?.release()
                } catch (_: Exception) {
                }
            }

            val rawPcm = pcmOut.toByteArray()
            withContext(Dispatchers.Main) {
                actIslandListening = false
                if (!heardSpeech && followUpMode) {
                    collapseActivityDynamicIsland()
                    return@withContext
                }
                if (rawPcm.size < 2800 || (!heardSpeech && maxObservedRms < 190.0)) {
                    if (followUpMode) {
                        collapseActivityDynamicIsland()
                    } else {
                        showActivityIslandResult(GeminiTurnResult("Не расслышал запрос. Скажите ещё раз.", false), isQuick = true)
                    }
                } else {
                    val wavBytes = encodeActivityPcmToWav(trimActivityPcmSilence(rawPcm, sampleRate), sampleRate)
                    actIslandSpeaking = false
                    actIslandWaveBox?.visibility = View.VISIBLE
                    actIslandBodyTv?.visibility = View.GONE
                    actIslandSpark?.setImageResource(R.drawable.ic_scene_spark_24)
                    actIslandStatusTv?.text = "Gemini думает..."
                    actIslandHintTv?.text = "Тап / Назад — отмена"
                    morphActivityIslandWidth(460f)

                    actGeminiJob = lifecycleScope.launch {
                        val turnResult = GeminiCloudClient.askGeminiAudioTurn(this@LauncherActivity, wavBytes)
                        if (turnResult.isSilence && followUpMode) {
                            collapseActivityDynamicIsland()
                        } else {
                            showActivityIslandResult(
                                turnResult,
                                isQuick = turnResult.displayText.startsWith("✦") && turnResult.displayText.length <= 55 && !turnResult.shouldContinueDialog
                            )
                        }
                    }
                }
            }
        }
    }

    private fun trimActivityPcmSilence(pcmData: ByteArray, sampleRate: Int): ByteArray {
        val totalSamples = pcmData.size / 2
        if (totalSamples < 1600) return pcmData
        val frameSamples = 320
        val totalFrames = totalSamples / frameSamples
        var firstSpeechFrame = -1
        var lastSpeechFrame = -1
        val bb = ByteBuffer.wrap(pcmData).order(ByteOrder.LITTLE_ENDIAN)
        for (f in 0 until totalFrames) {
            var sumSq = 0.0
            val baseIdx = f * frameSamples * 2
            for (s in 0 until frameSamples) {
                val sample = bb.getShort(baseIdx + s * 2).toDouble()
                sumSq += sample * sample
            }
            val rms = kotlin.math.sqrt(sumSq / frameSamples)
            if (rms > 240.0) {
                if (firstSpeechFrame == -1) firstSpeechFrame = f
                lastSpeechFrame = f
            }
        }
        if (firstSpeechFrame == -1 || lastSpeechFrame == -1) return pcmData
        val preRollFrames = (0.12 * sampleRate / frameSamples).toInt()
        val postRollFrames = (0.16 * sampleRate / frameSamples).toInt()
        val startFrame = (firstSpeechFrame - preRollFrames).coerceAtLeast(0)
        val endFrame = (lastSpeechFrame + postRollFrames + 1).coerceAtMost(totalFrames)
        val startByte = startFrame * frameSamples * 2
        val endByte = (endFrame * frameSamples * 2).coerceAtMost(pcmData.size)
        return if (endByte > startByte) pcmData.copyOfRange(startByte, endByte) else pcmData
    }

    private fun encodeActivityPcmToWav(pcmData: ByteArray, sampleRate: Int): ByteArray {
        val totalDataLen = pcmData.size + 36
        val byteRate = sampleRate * 2
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray(Charsets.US_ASCII))
        header.putInt(totalDataLen)
        header.put("WAVE".toByteArray(Charsets.US_ASCII))
        header.put("fmt ".toByteArray(Charsets.US_ASCII))
        header.putInt(16)
        header.putShort(1.toShort())
        header.putShort(1.toShort())
        header.putInt(sampleRate)
        header.putInt(byteRate)
        header.putShort(2.toShort())
        header.putShort(16.toShort())
        header.put("data".toByteArray(Charsets.US_ASCII))
        header.putInt(pcmData.size)

        val out = ByteArray(44 + pcmData.size)
        System.arraycopy(header.array(), 0, out, 0, 44)
        System.arraycopy(pcmData, 0, out, 44, pcmData.size)
        return out
    }

    private fun triggerActivityDynamicIslandWithText(spokenText: String) {
        ensureActivityDynamicIslandCreated()
        refreshActivityIslandAccent(currentAccentColor)
        AssistantVoiceSpeaker.stop(this)
        actIslandSpeaking = false
        actIslandListening = false
        actIslandHandler.removeCallbacks(actHideIslandRunnable)
        actGeminiJob?.cancel()
        actAudioRecordJob?.cancel()

        val root = actIslandRoot ?: return
        actIslandVisible = true
        DynamicIslandBus.notifyIslandVisibility(true)
        if (root.visibility != View.VISIBLE) {
            root.alpha = 0f
            root.visibility = View.VISIBLE
            root.animate().alpha(1f).setDuration(140L).start()
        } else {
            root.animate().cancel()
            root.alpha = 1f
        }

        actIslandWaveBox?.visibility = View.VISIBLE
        actIslandBodyTv?.visibility = View.GONE
        actIslandSpark?.setImageResource(R.drawable.ic_scene_spark_24)
        actIslandStatusTv?.text = "Gemini думает: «$spokenText»"
        actIslandHintTv?.text = "Тап / Назад — отмена"
        morphActivityIslandWidth(460f)

        actGeminiJob = lifecycleScope.launch {
            val turnResult = GeminiCloudClient.askGeminiTextTurn(this@LauncherActivity, spokenText)
            showActivityIslandResult(
                turnResult,
                isQuick = turnResult.displayText.startsWith("✦") && turnResult.displayText.length <= 55 && !turnResult.shouldContinueDialog
            )
        }
    }

    private fun showActivityIslandResult(turnResult: GeminiTurnResult, isQuick: Boolean) {
        val text = turnResult.displayText
        actIslandListening = false
        val accent = currentAccentColor
        actIslandSpark?.setColorFilter(accent, PorterDuff.Mode.SRC_IN)
        actIslandHandler.removeCallbacks(actHideIslandRunnable)

        val cleanDisplay = text.removePrefix("✦ ").trim()
        val isError = cleanDisplay.startsWith("Ошибка ответа") ||
            cleanDisplay.startsWith("Не удалось") ||
            cleanDisplay.startsWith("Лимиты Gemini исчерпаны")
        val ttsEnabled = AssistantVoiceSpeaker.isTtsEnabled(this)
        val shouldSpeak = ttsEnabled && !turnResult.isSilence && !isError
        val readingHoldMs = (6500L + cleanDisplay.length * 60L).coerceIn(8500L, 15000L)

        actIslandSpeaking = shouldSpeak
        actIslandWaveBox?.visibility = if (shouldSpeak) View.VISIBLE else View.GONE
        actIslandSpark?.setImageResource(if (shouldSpeak) R.drawable.ic_volume_24 else R.drawable.ic_scene_spark_24)
        actIslandStatusTv?.text = if (shouldSpeak) "Gemini отвечает..." else "Gemini"
        actIslandStatusTv?.setTextColor(accent)
        actIslandHintTv?.text = "Тап / OK — ответить · Назад — закрыть"
        actIslandBodyTv?.text = cleanDisplay
        actIslandBodyTv?.visibility = View.VISIBLE
        morphActivityIslandWidth(580f)

        if (shouldSpeak) {
            actIslandHandler.removeCallbacks(actPulseWaveRunnable)
            actIslandHandler.post(actPulseWaveRunnable)
            AssistantVoiceSpeaker.speak(this, cleanDisplay) { didPlayAudio ->
                actIslandSpeaking = false
                if (!actIslandVisible) return@speak
                if (turnResult.shouldContinueDialog) {
                    if (didPlayAudio) {
                        triggerActivityDynamicIsland(isFollowUp = true)
                    } else {
                        actIslandWaveBox?.visibility = View.GONE
                        actIslandSpark?.setImageResource(R.drawable.ic_scene_spark_24)
                        actIslandStatusTv?.text = "Gemini"
                        actIslandHandler.postDelayed({
                            if (actIslandVisible && !actIslandListening) {
                                triggerActivityDynamicIsland(isFollowUp = true)
                            }
                        }, 4500L)
                    }
                } else {
                    actIslandWaveBox?.visibility = View.GONE
                    actIslandSpark?.setImageResource(R.drawable.ic_scene_spark_24)
                        actIslandStatusTv?.text = "Gemini"
                    val holdAfterSpeech = if (didPlayAudio) 5500L else readingHoldMs
                    actIslandHandler.postDelayed(actHideIslandRunnable, holdAfterSpeech)
                }
            }
        } else {
            actIslandHandler.removeCallbacks(actPulseWaveRunnable)
            if (turnResult.shouldContinueDialog) {
                actIslandHandler.postDelayed({
                    if (actIslandVisible && !actIslandListening) {
                        triggerActivityDynamicIsland(isFollowUp = true)
                    }
                }, 4500L)
            } else {
                actIslandHandler.postDelayed(actHideIslandRunnable, readingHoldMs)
            }
        }
    }

    private fun collapseActivityDynamicIsland() {
        actIslandHandler.removeCallbacks(actHideIslandRunnable)
        actIslandHandler.removeCallbacks(actPulseWaveRunnable)
        actGeminiJob?.cancel()
        actAudioRecordJob?.cancel()
        AssistantVoiceSpeaker.stop(this)
        actIslandListening = false
        actIslandSpeaking = false
        actIslandFollowUp = false
        actIslandVisible = false
        val root = actIslandRoot ?: return
        if (root.visibility == View.VISIBLE) {
            morphActivityIslandWidth(148f)
            root.animate()
                .alpha(0f)
                .setDuration(170L)
                .withEndAction {
                    root.visibility = View.GONE
                    actIslandBodyTv?.visibility = View.GONE
                    DynamicIslandBus.notifyIslandVisibility(false)
                }
                .start()
        } else {
            DynamicIslandBus.notifyIslandVisibility(false)
        }
    }

    private fun captureBlurredScreenBitmap(): Bitmap? {
        return try {
            val root = binding.rootFrame
            val w = root.width
            val h = root.height
            if (w <= 0 || h <= 0) return null
            val scale = 10
            val sw = (w / scale).coerceAtLeast(32)
            val sh = (h / scale).coerceAtLeast(18)
            val bmp = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
            val canvas = android.graphics.Canvas(bmp)
            canvas.scale(1f / scale.toFloat(), 1f / scale.toFloat())
            val wasCcVisible = binding.controlCenterPanel.visibility
            val wasBlurVisible = binding.ivCcBlurBackdrop.visibility
            binding.controlCenterPanel.visibility = View.GONE
            binding.ivCcBlurBackdrop.visibility = View.GONE
            root.draw(canvas)
            binding.controlCenterPanel.visibility = wasCcVisible
            binding.ivCcBlurBackdrop.visibility = wasBlurVisible
            // Быстрый 3-проходный блочный/гауссов блюр на уменьшенном буфере (занимает < 1 мс)
            val pixels = IntArray(sw * sh)
            val tmp = IntArray(sw * sh)
            bmp.getPixels(pixels, 0, sw, 0, 0, sw, sh)
            val radius = 5
            repeat(3) {
                // Горизонтальный проход
                for (y in 0 until sh) {
                    val rowOffset = y * sw
                    for (x in 0 until sw) {
                        var rSum = 0
                        var gSum = 0
                        var bSum = 0
                        var count = 0
                        for (dx in -radius..radius) {
                            val nx = (x + dx).coerceIn(0, sw - 1)
                            val c = pixels[rowOffset + nx]
                            rSum += (c shr 16) and 0xFF
                            gSum += (c shr 8) and 0xFF
                            bSum += c and 0xFF
                            count++
                        }
                        tmp[rowOffset + x] = (0xFF shl 24) or ((rSum / count) shl 16) or ((gSum / count) shl 8) or (bSum / count)
                    }
                }
                // Вертикальный проход
                for (x in 0 until sw) {
                    for (y in 0 until sh) {
                        var rSum = 0
                        var gSum = 0
                        var bSum = 0
                        var count = 0
                        for (dy in -radius..radius) {
                            val ny = (y + dy).coerceIn(0, sh - 1)
                            val c = tmp[ny * sw + x]
                            rSum += (c shr 16) and 0xFF
                            gSum += (c shr 8) and 0xFF
                            bSum += c and 0xFF
                            count++
                        }
                        pixels[y * sw + x] = (0xFF shl 24) or ((rSum / count) shl 16) or ((gSum / count) shl 8) or (bSum / count)
                    }
                }
            }
            bmp.setPixels(pixels, 0, sw, 0, 0, sw, sh)
            // Наносим благородное матовое затемнение поверх размытия, чтобы парящие капсулы читались идеально
            canvas.setMatrix(android.graphics.Matrix())
            canvas.drawColor(Color.parseColor("#8807090F"))
            bmp
        } catch (_: Exception) {
            null
        }
    }

    private fun openControlCenter(sourceCard: View?) {
        if (sourceCard != null && isMainGridCardFocused()) {
            lastFocusedMainCard = sourceCard
        }
        hideOutageSchedulePanel(restoreFocus = false)
        refreshControlCenterToggles()

        binding.llNowPlayingControls.visibility = View.GONE
        binding.nowPlayingCard.visibility = View.INVISIBLE
        binding.bottomLeftPillsRow.visibility = View.INVISIBLE

        val blurredBmp = captureBlurredScreenBitmap()
        if (blurredBmp != null) {
            binding.ivCcBlurBackdrop.setImageBitmap(blurredBmp)
            binding.ivCcBlurBackdrop.alpha = 0f
            binding.ivCcBlurBackdrop.visibility = View.VISIBLE
            binding.ivCcBlurBackdrop.animate().alpha(1f).setDuration(170L).start()
        }
        binding.ambientZone.translationZ = dpPx(30f).toFloat()

        val panel = binding.controlCenterPanel
        panel.background = if (isSmartHomeTabActive) createPanelDrawable(currentAccentColor, 22f) else null
        if (panel.visibility != View.VISIBLE) {
            panel.alpha = 0f
            panel.translationY = 20f * resources.displayMetrics.density
            panel.visibility = View.VISIBLE
            panel.setLayerType(View.LAYER_TYPE_HARDWARE, null)
            panel.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(170L)
                .setInterpolator(android.view.animation.PathInterpolator(0.22f, 1f, 0.36f, 1f))
                .withEndAction {
                    panel.setLayerType(View.LAYER_TYPE_NONE, null)
                }
                .start()
        }
        if (isSmartHomeTabActive) {
            TuyaSmartHomeController.refreshStatusFromCloudAsync(this)
            binding.tileLedPower.requestFocus()
        } else {
            binding.tileCcWifi.requestFocus()
        }
    }

    private fun hideControlCenter(restoreFocus: Boolean) {
        val panel = binding.controlCenterPanel
        if (panel.visibility == View.VISIBLE) {
            panel.animate().cancel()
            panel.setLayerType(View.LAYER_TYPE_NONE, null)
            panel.visibility = View.GONE
        }
        binding.ivCcBlurBackdrop.animate().cancel()
        binding.ivCcBlurBackdrop.visibility = View.GONE
        binding.ambientZone.translationZ = 0f
        binding.bottomLeftPillsRow.visibility = View.VISIBLE
        renderNowPlayingWidget(MediaStateBus.state.value)

        if (restoreFocus) {
            (lastFocusedMainCard ?: binding.cardYoutube).requestFocus()
        }
    }

    private fun openOutageSchedulePanel(sourceCard: View?) {
        if (sourceCard != null && isMainGridCardFocused()) {
            lastFocusedMainCard = sourceCard
        }
        if (binding.controlCenterPanel.visibility == View.VISIBLE) {
            hideControlCenter(restoreFocus = false)
        }
        binding.llNowPlayingControls.visibility = View.GONE
        binding.nowPlayingCard.visibility = View.INVISIBLE
        binding.bottomLeftPillsRow.visibility = View.VISIBLE

        isOutageShowingTomorrow = false
        OutageRepository.recomputeFromCachedJson(this)
        renderOutageWidgetAndPanel(OutageRepository.state.value)
        lifecycleScope.launch {
            OutageRepository.refreshIfNeeded(this@LauncherActivity, force = true)
        }

        val panel = binding.outageSchedulePanel
        if (panel.visibility != View.VISIBLE) {
            panel.alpha = 0f
            panel.translationY = 20f * resources.displayMetrics.density
            panel.visibility = View.VISIBLE
            panel.setLayerType(View.LAYER_TYPE_HARDWARE, null)
            panel.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(150L)
                .setInterpolator(decelerateInterpolator)
                .withEndAction {
                    panel.setLayerType(View.LAYER_TYPE_NONE, null)
                }
                .start()
        }
        binding.btnOutageTabToday.requestFocus()
    }

    private fun hideOutageSchedulePanel(restoreFocus: Boolean) {
        val panel = binding.outageSchedulePanel
        if (panel.visibility == View.VISIBLE) {
            panel.animate().cancel()
            panel.setLayerType(View.LAYER_TYPE_NONE, null)
            panel.visibility = View.GONE
        }
        renderNowPlayingWidget(MediaStateBus.state.value)
        if (restoreFocus) {
            binding.outageCornerPill.requestFocus()
        }
    }

    private fun setupOutageSchedulePanel() {
        binding.btnOutageTabToday.setOnClickListener {
            isOutageShowingTomorrow = false
            renderOutageWidgetAndPanel(OutageRepository.state.value)
        }
        binding.btnOutageTabToday.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus && isOutageShowingTomorrow) {
                isOutageShowingTomorrow = false
                renderOutageWidgetAndPanel(OutageRepository.state.value)
            } else {
                updateOutageTabStyles()
            }
        }

        binding.btnOutageTabTomorrow.setOnClickListener {
            isOutageShowingTomorrow = true
            renderOutageWidgetAndPanel(OutageRepository.state.value)
        }
        binding.btnOutageTabTomorrow.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus && !isOutageShowingTomorrow) {
                isOutageShowingTomorrow = true
                renderOutageWidgetAndPanel(OutageRepository.state.value)
            } else {
                updateOutageTabStyles()
            }
        }

        binding.btnOutageQueue.setOnClickListener {
            val nextGroup = OutageRepository.cycleNextGroup(this)
            renderOutageWidgetAndPanel(OutageRepository.state.value)
            Toast.makeText(this, "Черга ДТЕК: $nextGroup", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateOutageTabStyles() {
        val accent = currentAccentColor
        val todayActive = !isOutageShowingTomorrow
        binding.btnOutageTabToday.background = createToggleDrawable(accent, isActive = todayActive)
        binding.btnOutageTabToday.setTextColor(if (todayActive) Color.parseColor("#F3F4F6") else Color.parseColor("#9CA3AF"))

        binding.btnOutageTabTomorrow.background = createToggleDrawable(accent, isActive = !todayActive)
        binding.btnOutageTabTomorrow.setTextColor(if (!todayActive) Color.parseColor("#F3F4F6") else Color.parseColor("#9CA3AF"))
    }

    private fun renderOutageWidgetAndPanel(snapshot: OutageUiSnapshot) {
        val accent = currentAccentColor
        val boltColor = if (snapshot.isPowerOnNow) accent else Color.parseColor("#EF4444")

        binding.ivOutageCornerBolt.setColorFilter(boltColor, PorterDuff.Mode.SRC_IN)
        binding.tvOutageCornerText.text = snapshot.pillText
        binding.tvOutageCornerText.setTextColor(
            if (snapshot.isPowerOnNow) Color.parseColor("#F3F4F6") else Color.parseColor("#FCA5A5")
        )

        binding.ivOutageHeaderBolt.setColorFilter(boltColor, PorterDuff.Mode.SRC_IN)
        binding.tvOutageHeaderTitle.text = snapshot.headerTitle
        binding.tvOutageHeaderSub.text = snapshot.headerSubtitle
        binding.btnOutageQueue.text = "Черга ${snapshot.groupCode}"

        val todayLabel = if (snapshot.todaySchedule.dateLabelUk.isNotEmpty()) {
            "Сьогодні (${snapshot.todaySchedule.dateLabelUk})"
        } else {
            "Сьогодні"
        }
        val tomorrowLabel = if (snapshot.tomorrowSchedule.dateLabelUk.isNotEmpty()) {
            "Завтра (${snapshot.tomorrowSchedule.dateLabelUk})"
        } else {
            "Завтра"
        }
        binding.btnOutageTabToday.text = todayLabel
        binding.btnOutageTabTomorrow.text = tomorrowLabel
        updateOutageTabStyles()

        val activeDaySchedule: DayOutageSchedule = if (isOutageShowingTomorrow) {
            snapshot.tomorrowSchedule
        } else {
            snapshot.todaySchedule
        }

        // 1. Отрисовка 24-часовой шкалы (00 .. 24)
        val barContainer = binding.llOutageTimelineBar
        barContainer.removeAllViews()
        for (h in 0 until 24) {
            val firstHalfOn = if (activeDaySchedule.isAvailable) activeDaySchedule.halfHourPowerOn[h * 2] else true
            val secondHalfOn = if (activeDaySchedule.isAvailable) activeDaySchedule.halfHourPowerOn[h * 2 + 1] else true
            val isCurrentHour = (!isOutageShowingTomorrow) && (h == snapshot.currentHourKyiv)

            val segColor = when {
                firstHalfOn && secondHalfOn -> accent
                !firstHalfOn && !secondHalfOn -> Color.parseColor("#EF4444")
                else -> Color.parseColor("#F59E0B")
            }

            val segView = View(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                    marginStart = if (h == 0) 0 else dpPx(1.5f)
                    marginEnd = if (h == 23) 0 else dpPx(1.5f)
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpPx(3.5f).toFloat()
                    setColor(if (isCurrentHour) ColorUtils.blendARGB(segColor, Color.WHITE, 0.28f) else segColor)
                    if (isCurrentHour) {
                        setStroke(dpPx(1.5f), Color.WHITE)
                    }
                }
            }
            barContainer.addView(segView)
        }

        // 2. Отрисовка слотов отключений на выбранный день
        val slotsContainer = binding.llOutageIntervalsContainer
        slotsContainer.removeAllViews()

        if (!activeDaySchedule.isAvailable) {
            slotsContainer.addView(
                createOutageSlotRowView(
                    text = if (isOutageShowingTomorrow) "Графік на завтра ще не опубліковано ДТЕК" else "Завантаження графіка ДТЕК...",
                    isHighlighted = false,
                    isPositive = false,
                    accent = accent
                )
            )
        } else if (activeDaySchedule.intervals.isEmpty()) {
            slotsContainer.addView(
                createOutageSlotRowView(
                    text = "За графіком без відключень весь день",
                    isHighlighted = true,
                    isPositive = true,
                    accent = accent
                )
            )
        } else {
            val nowMin = snapshot.currentMinuteOfDayKyiv
            var highlightedAssigned = false
            for (interval in activeDaySchedule.intervals.take(4)) {
                val isPast = (!isOutageShowingTomorrow) && (interval.endMinuteOfDay <= nowMin)
                val isOngoing = (!isOutageShowingTomorrow) && (nowMin in interval.startMinuteOfDay until interval.endMinuteOfDay)
                val isNext = (!isOutageShowingTomorrow) && !isPast && !isOngoing && !highlightedAssigned
                if (isOngoing || isNext) {
                    highlightedAssigned = true
                }

                val statusSuffix = when {
                    isOngoing -> " · Зараз"
                    isNext -> " · Наступне"
                    isPast -> " · Минуло"
                    else -> ""
                }
                val rowText = "${interval.formatTimeRange()} · ${interval.formatDurationUk()}$statusSuffix"
                slotsContainer.addView(
                    createOutageSlotRowView(
                        text = rowText,
                        isHighlighted = isOngoing || isNext || isOutageShowingTomorrow,
                        isPositive = false,
                        accent = if (isOngoing) Color.parseColor("#EF4444") else accent,
                        isMuted = isPast
                    )
                )
            }
        }

        binding.tvOutageFooter.text = "Оновлено ДТЕК: ${snapshot.updateTimestamp}"
    }

    private fun createOutageSlotRowView(
        text: String,
        isHighlighted: Boolean,
        isPositive: Boolean,
        accent: Int,
        isMuted: Boolean = false
    ): TextView {
        return TextView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                dpPx(36f)
            ).apply {
                bottomMargin = dpPx(6f)
            }
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dpPx(14f), 0, dpPx(14f), 0)
            typeface = android.graphics.Typeface.create("sans-serif-medium", android.graphics.Typeface.NORMAL)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(
                when {
                    isMuted -> Color.parseColor("#8A94A6")
                    isPositive -> accent
                    else -> Color.parseColor("#F3F4F6")
                }
            )
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpPx(999f).toFloat()
                setColor(
                    if (isHighlighted) ColorUtils.setAlphaComponent(accent, 34)
                    else Color.parseColor("#18FFFFFF")
                )
                setStroke(
                    dpPx(if (isHighlighted) 1.5f else 1f),
                    if (isHighlighted) ColorUtils.setAlphaComponent(accent, 210)
                    else Color.parseColor("#24FFFFFF")
                )
            }
            this.text = text
        }
    }

    private fun setupControlCenterPanel() {
        binding.tileCcWifi.setOnClickListener {
            toggleWifiDirectly()
        }
        binding.tileCcWifi.setOnLongClickListener {
            hideControlCenter(restoreFocus = true)
            openSettingsIntent(Settings.ACTION_WIFI_SETTINGS)
            true
        }

        binding.tileCcBluetooth.setOnClickListener {
            hideControlCenter(restoreFocus = true)
            openSettingsIntent(Settings.ACTION_BLUETOOTH_SETTINGS)
        }
        binding.tileCcBluetooth.setOnLongClickListener {
            toggleBluetoothDirectly()
            true
        }

        binding.tileCcSound.setOnClickListener {
            try {
                audioManager.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    AudioManager.ADJUST_TOGGLE_MUTE,
                    0
                )
            } catch (_: Exception) {
            }
            refreshSoundTileState()
        }

        binding.tileCcBoost.setOnClickListener {
            silentCleanBackgroundProcesses()
            refreshRamTileState(cleanedBonusPct = 14)
            Toast.makeText(this, R.string.toast_boost_done, Toast.LENGTH_SHORT).show()
        }

        binding.tileCcNightQuick.setOnClickListener {
            val nextSetting = when (nightModeSetting) {
                NightModeSetting.AUTO -> NightModeSetting.ALWAYS_NIGHT
                NightModeSetting.ALWAYS_NIGHT -> NightModeSetting.ALWAYS_DAY
                NightModeSetting.ALWAYS_DAY -> NightModeSetting.AUTO
            }
            saveNightModeSetting(nextSetting)
            refreshControlCenterToggles()
        }

        binding.tileCcLedQuick.setOnClickListener {
            TuyaSmartHomeController.togglePower(this)
            refreshControlCenterToggles()
        }
        binding.tileCcLedQuick.setOnLongClickListener {
            switchControlCenterTab(showSmartHome = true, requestFocusInside = true)
            true
        }

        binding.btnCcQuickLedStudio.setOnClickListener {
            switchControlCenterTab(showSmartHome = true, requestFocusInside = true)
        }

        val allCcInteractive = listOf(
            binding.tileCcWifi,
            binding.tileCcBluetooth,
            binding.tileCcBoost,
            binding.tileCcNightQuick,
            binding.tileCcSound,
            binding.tileCcLedQuick,
            binding.btnCcQuickLedStudio,
            binding.btnMenuBindKey,
            binding.btnMenuAssignCurrent,
            binding.btnMenuSystemSettings
        )
        for (v in allCcInteractive) {
            v.setOnFocusChangeListener { view, hasFocus ->
                val targetScale = if (hasFocus) 1.038f else 1.0f
                view.animate()
                    .scaleX(targetScale)
                    .scaleY(targetScale)
                    .setDuration(150L)
                    .setInterpolator(android.view.animation.PathInterpolator(0.22f, 1f, 0.36f, 1f))
                    .start()
                refreshControlCenterBottomIconsTint()
            }
        }

        // Кнопка «Настройка лаунчера»
        binding.btnMenuAssignCurrent.setOnClickListener {
            hideControlCenter(restoreFocus = false)
            openLauncherSettingsOverlay()
        }

        binding.btnMenuBindKey.setOnClickListener {
            hideControlCenter(restoreFocus = false)
            ServiceAutoActivator.ensureServicesActive(this)
            updateAccessibilityStatusRow()
            binding.remoteKeySelectOverlay.visibility = View.VISIBLE
            if (isAccessibilityMapperEnabled()) {
                binding.btnKeyPresetPatchwall.requestFocus()
            } else {
                binding.btnKeyEnableAccessibility.requestFocus()
            }
        }

        binding.btnMenuSystemSettings.setOnClickListener {
            hideControlCenter(restoreFocus = true)
            viewModel.launchSystemSettings()
        }

        setupSmartHomeTabAndControls()
    }

    private var isSmartHomeTabActive: Boolean = false

    private fun switchControlCenterTab(showSmartHome: Boolean, requestFocusInside: Boolean = false) {
        isSmartHomeTabActive = showSmartHome
        binding.controlCenterPanel.background = if (showSmartHome) createPanelDrawable(currentAccentColor, 22f) else null
        binding.llCcSystemPage.visibility = if (showSmartHome) View.GONE else View.VISIBLE
        binding.llCcSmartHomePage.visibility = if (showSmartHome) View.VISIBLE else View.GONE
        refreshControlCenterToggles()
        if (showSmartHome) {
            TuyaSmartHomeController.refreshStatusFromCloudAsync(this)
            if (requestFocusInside) {
                binding.tileLedPower.requestFocus()
            }
        } else if (requestFocusInside) {
            binding.tileCcWifi.requestFocus()
        }
    }

    private fun createSceneSelectorDrawable(accent: Int, isSelected: Boolean = false): StateListDrawable {
        val focused = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(10f).toFloat()
            setColor(ColorUtils.setAlphaComponent(accent, if (isSelected) 72 else 40))
            setStroke(dpPx(2f), accent)
        }
        val idle = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(10f).toFloat()
            setColor(if (isSelected) ColorUtils.setAlphaComponent(accent, 42) else Color.parseColor("#1B1D24"))
            if (isSelected) {
                setStroke(dpPx(2f), accent)
            } else {
                setStroke(dpPx(1f), Color.parseColor("#2A2D37"))
            }
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(android.R.attr.state_selected), focused)
            addState(intArrayOf(), idle)
        }
    }

    private fun createColorSwatchDrawable(hexColor: String, accent: Int, isSelected: Boolean = false): StateListDrawable {
        val baseColor = try { Color.parseColor(hexColor) } catch (_: Exception) { accent }
        val focused = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(10f).toFloat()
            setColor(ColorUtils.setAlphaComponent(baseColor, if (isSelected) 115 else 82))
            setStroke(dpPx(2f), Color.WHITE)
        }
        val idle = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(10f).toFloat()
            setColor(ColorUtils.setAlphaComponent(baseColor, if (isSelected) 78 else 28))
            if (isSelected) {
                setStroke(dpPx(2f), Color.WHITE)
            } else {
                setStroke(dpPx(1f), ColorUtils.setAlphaComponent(baseColor, 135))
            }
        }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_focused), focused)
            addState(intArrayOf(android.R.attr.state_selected), focused)
            addState(intArrayOf(), idle)
        }
    }

    private fun setupSmartHomeTabAndControls() {
        TuyaSmartHomeController.onStateUpdatedUiCallback = {
            if (binding.controlCenterPanel.visibility == View.VISIBLE) {
                refreshSmartHomeUiState()
            }
        }

        binding.vLedRainbowStrip.background = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(
                Color.parseColor("#EF4444"),
                Color.parseColor("#F59E0B"),
                Color.parseColor("#10B981"),
                Color.parseColor("#00F0FF"),
                Color.parseColor("#3B82F6"),
                Color.parseColor("#A855F7"),
                Color.parseColor("#EC4899"),
                Color.parseColor("#EF4444")
            )
        ).apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(5f).toFloat()
        }

        binding.tabCcControls.setOnClickListener {
            switchControlCenterTab(showSmartHome = false, requestFocusInside = true)
        }
        binding.tabCcControls.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus && isSmartHomeTabActive) {
                switchControlCenterTab(showSmartHome = false, requestFocusInside = false)
            }
            refreshControlCenterTabHeaderStyle()
        }

        binding.tabCcSmartHome.setOnClickListener {
            switchControlCenterTab(showSmartHome = true, requestFocusInside = true)
        }
        binding.tabCcSmartHome.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus && !isSmartHomeTabActive) {
                switchControlCenterTab(showSmartHome = true, requestFocusInside = false)
            }
            refreshControlCenterTabHeaderStyle()
        }

        binding.tileLedPower.setOnClickListener {
            TuyaSmartHomeController.togglePower(this)
            refreshSmartHomeUiState()
        }

        binding.tileLedSyncTheme.setOnClickListener {
            val nextSync = !TuyaSmartHomeController.isThemeSyncEnabled(this)
            val curHex = appLauncherDirect.getAccentColorHex()
            TuyaSmartHomeController.setThemeSyncEnabled(this, nextSync, curHex)
            refreshSmartHomeUiState()
        }

        binding.barLedHueSpectrum.setOnClickListener {
            TuyaSmartHomeController.stepHueByDelta(this, 24, immediate = true)
            refreshSmartHomeUiState()
        }

        binding.btnLedBrightness.setOnClickListener {
            TuyaSmartHomeController.cycleBrightnessPreset(this)
            refreshSmartHomeUiState()
        }

        binding.btnLedSaturation.setOnClickListener {
            TuyaSmartHomeController.cycleSaturationPreset(this)
            refreshSmartHomeUiState()
        }

        val swatchButtons = listOf(
            binding.btnLedSwatch1,
            binding.btnLedSwatch2,
            binding.btnLedSwatch3,
            binding.btnLedSwatch4,
            binding.btnLedSwatch5,
            binding.btnLedSwatch6,
            binding.btnLedSwatch7,
            binding.btnLedSwatch8,
            binding.btnLedSwatch9,
            binding.btnLedSwatch10,
            binding.btnLedSwatch11,
            binding.btnLedSwatch12
        )

        val presets = TuyaSmartHomeController.CURATED_SWATCHES
        for (i in swatchButtons.indices) {
            val btn = swatchButtons[i]
            val preset = presets[i]
            btn.text = preset.name
            btn.background = createColorSwatchDrawable(preset.hexColor, currentAccentColor)
            btn.setOnClickListener {
                TuyaSmartHomeController.applySwatchPreset(this, preset)
                refreshSmartHomeUiState()
            }
        }

        binding.btnLedSceneRainbow.setOnClickListener {
            TuyaSmartHomeController.activateDynamicScene(this, "RAINBOW")
            refreshSmartHomeUiState()
        }
        binding.btnLedSceneBreathe.setOnClickListener {
            TuyaSmartHomeController.activateDynamicScene(this, "BREATHE")
            refreshSmartHomeUiState()
        }
        binding.btnLedSceneParty.setOnClickListener {
            TuyaSmartHomeController.activateDynamicScene(this, "PARTY")
            refreshSmartHomeUiState()
        }
        binding.btnLedSceneNight.setOnClickListener {
            TuyaSmartHomeController.activateDynamicScene(this, "NIGHT")
            refreshSmartHomeUiState()
        }
        binding.btnLedSceneAmbiline.setOnClickListener {
            TuyaSmartHomeController.activateDynamicScene(this, "AMBILINE")
            refreshSmartHomeUiState()
        }
    }

    private fun refreshControlCenterTabHeaderStyle() {
        val accent = currentAccentColor
        val controlsActive = !isSmartHomeTabActive
        val homeActive = isSmartHomeTabActive

        binding.tabCcControls.background = createToggleDrawable(accent, isActive = controlsActive)
        binding.ivTabCcControls.setColorFilter(
            if (controlsActive) accent else getColor(R.color.text_secondary),
            PorterDuff.Mode.SRC_IN
        )
        binding.tvTabCcControls.setTextColor(
            if (controlsActive) getColor(R.color.text_primary) else getColor(R.color.text_secondary)
        )

        binding.tabCcSmartHome.background = createToggleDrawable(accent, isActive = homeActive)
        binding.ivTabCcSmartHome.setColorFilter(
            if (homeActive) accent else getColor(R.color.text_secondary),
            PorterDuff.Mode.SRC_IN
        )
        binding.tvTabCcSmartHome.setTextColor(
            if (homeActive) getColor(R.color.text_primary) else getColor(R.color.text_secondary)
        )
    }

    private fun refreshSmartHomeUiState() {
        val accent = currentAccentColor
        val ledOn = TuyaSmartHomeController.isLedOn(this)
        val hue = TuyaSmartHomeController.getHue(this)
        val sat = TuyaSmartHomeController.getSaturationPct(this)
        val bright = TuyaSmartHomeController.getBrightnessPct(this)
        val syncOn = TuyaSmartHomeController.isThemeSyncEnabled(this)
        val modeLabel = TuyaSmartHomeController.getCurrentModeLabel(this)
        val previewColor = TuyaSmartHomeController.getCurrentPreviewColorInt(this)
        val activeSwatchIdx = if (ledOn) TuyaSmartHomeController.findActiveSwatchIndex(this) else -1

        binding.tileLedPower.background = createToggleDrawable(previewColor, isActive = ledOn)
        binding.ivLedPower.setColorFilter(
            if (ledOn) previewColor else getColor(R.color.text_secondary),
            PorterDuff.Mode.SRC_IN
        )
        val cleanMode = modeLabel.removePrefix("Режим: ")
        binding.tvLedPowerState.text = if (ledOn) "ВКЛ · $cleanMode" else getString(R.string.cc_state_off)
        binding.tvLedPowerState.setTextColor(
            if (ledOn) previewColor else getColor(R.color.text_secondary)
        )

        binding.tileLedSyncTheme.background = createToggleDrawable(accent, isActive = syncOn)
        binding.ivLedSyncTheme.setColorFilter(
            if (syncOn) accent else getColor(R.color.text_secondary),
            PorterDuff.Mode.SRC_IN
        )
        binding.tvLedSyncState.text = getString(if (syncOn) R.string.cc_state_on else R.string.cc_state_off)
        binding.tvLedSyncState.setTextColor(
            if (syncOn) accent else getColor(R.color.text_secondary)
        )

        binding.vLedHuePreviewDot.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(previewColor)
            setStroke(dpPx(1.5f), Color.WHITE)
        }
        val activeTitle = if (activeSwatchIdx in TuyaSmartHomeController.CURATED_SWATCHES.indices) {
            TuyaSmartHomeController.CURATED_SWATCHES[activeSwatchIdx].name
        } else {
            TuyaSmartHomeController.describeHueName(hue)
        }
        binding.tvLedHueValue.text = "Спектр: ${hue}° · $activeTitle"
        binding.tvLedBrightValue.text = "Яркость: ${bright}%"
        binding.tvLedSatValue.text = "Насыщенность: ${sat}%"
        binding.ivLedBrightIcon.setColorFilter(previewColor, PorterDuff.Mode.SRC_IN)
        binding.ivLedSatIcon.setColorFilter(previewColor, PorterDuff.Mode.SRC_IN)

        val swatchButtons = listOf(
            binding.btnLedSwatch1,
            binding.btnLedSwatch2,
            binding.btnLedSwatch3,
            binding.btnLedSwatch4,
            binding.btnLedSwatch5,
            binding.btnLedSwatch6,
            binding.btnLedSwatch7,
            binding.btnLedSwatch8,
            binding.btnLedSwatch9,
            binding.btnLedSwatch10,
            binding.btnLedSwatch11,
            binding.btnLedSwatch12
        )
        val presets = TuyaSmartHomeController.CURATED_SWATCHES
        for (i in swatchButtons.indices) {
            val btn = swatchButtons[i]
            val preset = presets[i]
            val isSelected = (i == activeSwatchIdx)
            btn.background = createColorSwatchDrawable(preset.hexColor, accent, isSelected)
            btn.setTextColor(if (isSelected) Color.WHITE else Color.parseColor(preset.hexColor))
        }

        val scenePairs = listOf(
            binding.btnLedSceneRainbow to "Радуга",
            binding.btnLedSceneBreathe to "Дыхание",
            binding.btnLedSceneParty to "Вечеринка",
            binding.btnLedSceneNight to "Ночник",
            binding.btnLedSceneAmbiline to "Амбилайн"
        )
        for ((sceneBtn, keyword) in scenePairs) {
            val sceneActive = ledOn && modeLabel.contains(keyword, ignoreCase = true)
            sceneBtn.background = createSceneSelectorDrawable(accent, isSelected = sceneActive)
            sceneBtn.setTextColor(if (sceneActive) accent else getColor(R.color.text_primary))
        }
    }

    private fun openLauncherSettingsOverlay() {
        val state = viewModel.uiState.value
        val s1Name = state.slot1App?.label ?: getString(R.string.card_slot_1_default)
        val s2Name = state.slot2App?.label ?: getString(R.string.card_slot_2_default)
        val s3Name = state.slot3App?.label ?: getString(R.string.card_slot_3_default)
        val s4Name = state.slot4App?.label ?: getString(R.string.card_slot_4_default)

        binding.btnEditSlot1.text = getString(R.string.launcher_edit_slot_1, s1Name)
        binding.btnEditSlot2.text = getString(R.string.launcher_edit_slot_2, s2Name)
        binding.btnEditSlot3.text = getString(R.string.launcher_edit_slot_3, s3Name)
        binding.btnEditSlot4.text = getString(R.string.launcher_edit_slot_4, s4Name)
        updateNavSoundButtonLabel()
        updateAiTtsButtonsLabels()

        binding.launcherSettingsOverlay.visibility = View.VISIBLE
        binding.svLauncherSettings.scrollTo(0, 0)
        binding.btnEditSlot1.requestFocus()
    }

    private fun updateNavSoundButtonLabel() {
        val enabled = NavSoundPlayer.isSoundEnabled(this)
        binding.btnToggleNavSound.text = getString(
            if (enabled) R.string.launcher_nav_sound_on else R.string.launcher_nav_sound_off
        )
    }

    private fun updateAiTtsButtonsLabels() {
        val ttsOn = AssistantVoiceSpeaker.isTtsEnabled(this)
        binding.btnToggleAiTts.text = getString(
            if (ttsOn) R.string.launcher_tts_on else R.string.launcher_tts_off
        )
        val voiceLabel = AssistantVoiceSpeaker.getSelectedVoiceDisplayLabel(this)
        binding.btnCycleAiVoice.text = getString(R.string.launcher_tts_voice, voiceLabel)
        binding.btnToggleNightMode.text = when (nightModeSetting) {
            NightModeSetting.AUTO -> getString(R.string.launcher_night_mode_auto)
            NightModeSetting.ALWAYS_DAY -> getString(R.string.launcher_night_mode_day)
            NightModeSetting.ALWAYS_NIGHT -> getString(R.string.launcher_night_mode_night)
        }
    }

    private fun setupLauncherSettingsOverlay() {
        binding.btnReorderStrip.setOnClickListener {
            binding.launcherSettingsOverlay.visibility = View.GONE
            stripReorder.show(stripApps.drop(4).filterNotNull())
        }
        binding.btnEditSlot1.setOnClickListener {
            returnToLauncherSettingsAfterAssign = true
            binding.launcherSettingsOverlay.visibility = View.GONE
            openAppPickerOverlay(assignSlot = CardSlot.SLOT_1, forKeyBind = false)
        }
        binding.btnEditSlot2.setOnClickListener {
            returnToLauncherSettingsAfterAssign = true
            binding.launcherSettingsOverlay.visibility = View.GONE
            openAppPickerOverlay(assignSlot = CardSlot.SLOT_2, forKeyBind = false)
        }
        binding.btnEditSlot3.setOnClickListener {
            returnToLauncherSettingsAfterAssign = true
            binding.launcherSettingsOverlay.visibility = View.GONE
            openAppPickerOverlay(assignSlot = CardSlot.SLOT_3, forKeyBind = false)
        }
        binding.btnEditSlot4.setOnClickListener {
            returnToLauncherSettingsAfterAssign = true
            binding.launcherSettingsOverlay.visibility = View.GONE
            openAppPickerOverlay(assignSlot = CardSlot.SLOT_4, forKeyBind = false)
        }
        binding.btnToggleNavSound.setOnClickListener {
            val nextState = !NavSoundPlayer.isSoundEnabled(this)
            NavSoundPlayer.setSoundEnabled(this, nextState)
            updateNavSoundButtonLabel()
            if (nextState) {
                NavSoundPlayer.playClick(this)
            }
        }
        binding.btnToggleAiTts.setOnClickListener {
            val nextTts = !AssistantVoiceSpeaker.isTtsEnabled(this)
            AssistantVoiceSpeaker.setTtsEnabled(this, nextTts)
            updateAiTtsButtonsLabels()
        }
        binding.btnCycleAiVoice.setOnClickListener {
            val newVoiceLabel = AssistantVoiceSpeaker.cycleNextVoice(this)
            updateAiTtsButtonsLabels()
            Toast.makeText(this, "Голос ИИ: $newVoiceLabel", Toast.LENGTH_SHORT).show()
        }
        binding.btnToggleNightMode.setOnClickListener {
            val nextSetting = when (nightModeSetting) {
                NightModeSetting.AUTO -> NightModeSetting.ALWAYS_DAY
                NightModeSetting.ALWAYS_DAY -> NightModeSetting.ALWAYS_NIGHT
                NightModeSetting.ALWAYS_NIGHT -> NightModeSetting.AUTO
            }
            saveNightModeSetting(nextSetting)
            updateAiTtsButtonsLabels()
        }

        val colorChoices = listOf(
            binding.btnColorCyan to "#00F0FF",
            binding.btnColorEmerald to "#34D399",
            binding.btnColorAmber to "#F59E0B",
            binding.btnColorSapphire to "#60A5FA",
            binding.btnColorAmethyst to "#A78BFA",
            binding.btnColorSilver to "#E2E8F0"
        )

        colorChoices.forEach { (btn, hex) ->
            btn.setOnClickListener {
                appLauncherDirect.saveAccentColorHex(hex)
                currentAccentColor = Color.parseColor(hex)
                applyAccentColorTheme()
                DynamicIslandBus.notifyAccentColorChanged(hex)
                TuyaSmartHomeController.syncWithLauncherThemeIfNeeded(this, hex)
                Toast.makeText(this, R.string.toast_color_applied, Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnUpdateLauncher.setOnClickListener {
            downloadAndInstallLauncherOtaUpdate()
        }
    }

    
    private enum class NightModeSetting {
        AUTO,
        ALWAYS_DAY,
        ALWAYS_NIGHT
    }

    private var nightModeSetting = NightModeSetting.AUTO
    private var isNightModeActive = false
    private var nightModeGlowFactor = 1.0f // 1.0f днем, 0.6f ночью
    private var manualNightModeOverride: Boolean? = null
    private var nightModeTransitionAnimator: ValueAnimator? = null
    private var lastNightScheduleState: Boolean? = null

    private fun loadNightModeSettings() {
        val prefs = getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString("pref_night_mode_setting", "AUTO") ?: "AUTO"
        nightModeSetting = try { NightModeSetting.valueOf(saved) } catch (_: Exception) { NightModeSetting.AUTO }
        updateNightModeState(immediate = true)
    }

    private fun saveNightModeSetting(setting: NightModeSetting) {
        nightModeSetting = setting
        manualNightModeOverride = null
        val prefs = getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString("pref_night_mode_setting", setting.name).apply()
        updateNightModeState(immediate = false, durationMs = 600L)
    }

    private fun isScheduledNightTime(): Boolean {
        val cal = Calendar.getInstance()
        val year = cal.get(Calendar.YEAR)
        if (year < 2024) return false // Если время стика еще не синхронизировано, остаемся в дневном режиме
        val hour = cal.get(Calendar.HOUR_OF_DAY)
        return hour >= 23 || hour < 6
    }

    private fun updateNightModeState(immediate: Boolean = false, durationMs: Long = 60_000L) {
        val scheduledNight = isScheduledNightTime()
        if (lastNightScheduleState != null && lastNightScheduleState != scheduledNight) {
            // Наступила смена расписания суток (23:00 или 06:00) — сбрасываем ручной оверрайд
            manualNightModeOverride = null
        }
        lastNightScheduleState = scheduledNight

        val targetNight = when (nightModeSetting) {
            NightModeSetting.ALWAYS_DAY -> false
            NightModeSetting.ALWAYS_NIGHT -> true
            NightModeSetting.AUTO -> manualNightModeOverride ?: scheduledNight
        }

        if (isNightModeActive == targetNight && !immediate) return
        isNightModeActive = targetNight
        val targetGlowFactor = if (targetNight) 0.6f else 1.0f

        nightModeTransitionAnimator?.cancel()
        if (immediate) {
            nightModeGlowFactor = targetGlowFactor
            applyGlowToFocusedCards()
        } else {
            nightModeTransitionAnimator = ValueAnimator.ofFloat(nightModeGlowFactor, targetGlowFactor).apply {
                duration = durationMs
                interpolator = DecelerateInterpolator()
                addUpdateListener { va ->
                    nightModeGlowFactor = va.animatedValue as Float
                    applyGlowToFocusedCards()
                }
                start()
            }
        }
    }

    private fun createAmbientBackgroundDrawable(accent: Int, glowFactor: Float): Drawable {
        val baseBgColor = getColor(R.color.bg_screen)
        val factor = glowFactor.coerceIn(0.3f, 1.0f)

        // Перцептивная компенсация гаммы ТВ-экрана:
        // У бирюзового (#00F0FF) зелёный канал G=240 даёт высокую видимость уже при alpha=44,
        // а у фиолетового (#A78BFA / #A855F7), синего (#60A5FA) и красного зелёная компонента ниже,
        // поэтому автоматически поднимаем плотность свечения (до 1.95x), чтобы градиент на фиолетовом
        // и любом другом цвете был виден так же сочно и отчётливо, как на бирюзовом!
        val rChan = Color.red(accent) / 255f
        val gChan = Color.green(accent) / 255f
        val bChan = Color.blue(accent) / 255f
        val greenPerceptual = (0.18f * rChan + 0.72f * gChan + 0.10f * bChan).coerceIn(0.15f, 0.90f)
        val perceptualBoost = (0.76f / greenPerceptual).coerceIn(1.0f, 1.95f)

        // Делаем оттенок свечения максимально насыщенным (S >= 0.85, V = 1.0), чтобы пастельный аметист (#A78BFA)
        // не выглядел бледно-серым на тёмном фоне, а светился глубоким неоновым фиолетовым!
        val hsv = FloatArray(3)
        Color.colorToHSV(accent, hsv)
        if (hsv[1] in 0.22f..0.85f) {
            hsv[1] = (hsv[1] * 1.32f).coerceAtMost(0.92f)
        }
        hsv[2] = 1.0f
        val vibrantGlowRgb = Color.HSVToColor(hsv)

        val tlAlphaPeak = (46f * perceptualBoost * factor).toInt().coerceIn(0, 115)
        val tlAlphaMid = (25f * perceptualBoost * factor).toInt().coerceIn(0, 72)
        val tlAlphaOuter = (9f * perceptualBoost * factor).toInt().coerceIn(0, 32)

        val brAlphaPeak = (34f * perceptualBoost * factor).toInt().coerceIn(0, 92)
        val brAlphaMid = (18f * perceptualBoost * factor).toInt().coerceIn(0, 52)
        val brAlphaOuter = (6f * perceptualBoost * factor).toInt().coerceIn(0, 24)

        return object : Drawable() {
            private val paint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.DITHER_FLAG)

            override fun draw(canvas: Canvas) {
                val b = bounds
                val w = b.width().toFloat()
                val h = b.height().toFloat()
                if (w <= 0f || h <= 0f) return

                canvas.drawColor(baseBgColor)

                // 1. Верхнее левое мягкое радиальное свечение (за часами и датой)
                val cx1 = w * 0.14f
                val cy1 = h * 0.08f
                val r1 = h * 0.78f
                paint.shader = RadialGradient(
                    cx1,
                    cy1,
                    r1,
                    intArrayOf(
                        ColorUtils.setAlphaComponent(vibrantGlowRgb, tlAlphaPeak),
                        ColorUtils.setAlphaComponent(vibrantGlowRgb, tlAlphaMid),
                        ColorUtils.setAlphaComponent(vibrantGlowRgb, tlAlphaOuter),
                        Color.TRANSPARENT
                    ),
                    floatArrayOf(0f, 0.42f, 0.72f, 1f),
                    Shader.TileMode.CLAMP
                )
                canvas.drawRect(b, paint)

                // 2. Нижнее правое мягкое радиальное свечение (в правом нижнем углу за карточкой Музыки)
                val cx2 = w * 0.92f
                val cy2 = h * 0.94f
                val r2 = h * 0.60f
                paint.shader = RadialGradient(
                    cx2,
                    cy2,
                    r2,
                    intArrayOf(
                        ColorUtils.setAlphaComponent(vibrantGlowRgb, brAlphaPeak),
                        ColorUtils.setAlphaComponent(vibrantGlowRgb, brAlphaMid),
                        ColorUtils.setAlphaComponent(vibrantGlowRgb, brAlphaOuter),
                        Color.TRANSPARENT
                    ),
                    floatArrayOf(0f, 0.42f, 0.72f, 1f),
                    Shader.TileMode.CLAMP
                )
                canvas.drawRect(b, paint)
                paint.shader = null
            }

            override fun setAlpha(alpha: Int) {
                paint.alpha = alpha
            }

            override fun setColorFilter(colorFilter: android.graphics.ColorFilter?) {
                paint.colorFilter = colorFilter
            }

            @Deprecated("Deprecated in Java")
            override fun getOpacity(): Int = PixelFormat.OPAQUE
        }
    }

    private fun applyGlowToCard(card: View, hasFocus: Boolean) {
        // Карточки остаются без внешнего свечения — только чёткая фирменная обводка
        card.elevation = 0f
    }

    private fun applyGlowToFocusedCards() {
        val accent = currentAccentColor
        binding.rootFrame.background = createAmbientBackgroundDrawable(accent, nightModeGlowFactor)
        binding.cardYoutube.background = createCardSelectorDrawable(accent)
        binding.cardBrowser.background = createCardSelectorDrawable(accent)
        binding.cardCast.background = createCardSelectorDrawable(accent)
        binding.cardAi.background = createCardSelectorDrawable(accent)
        val nightBorderAccent = getNightAdjustedBorderColor(accent)
        val pairs = listOf(
            binding.cardYoutube to binding.ivCard1,
            binding.cardBrowser to binding.ivCard2,
            binding.cardCast to binding.ivCard3,
            binding.cardAi to binding.ivCardAi
        )
        for ((card, icon) in pairs) {
            val tint = if (card.hasFocus()) nightBorderAccent else getColor(R.color.text_primary)
            icon.setColorFilter(tint, PorterDuff.Mode.SRC_IN)
        }
    }

    private var isOtaDownloading: Boolean = false

    private fun resolveNewestGithubApkUrl(): String? {
        var conn: HttpURLConnection? = null
        return try {
            val apiConn = (URL("https://api.github.com/repos/ddtrs/mistick/releases").openConnection() as HttpURLConnection).apply {
                connectTimeout = 8000
                readTimeout = 8000
                useCaches = false
                setRequestProperty("Accept", "application/vnd.github+json")
                setRequestProperty("Cache-Control", "no-cache")
                setRequestProperty("User-Agent", "MiTvStickLauncher-OTA/5.8")
            }
            conn = apiConn
            if (apiConn.responseCode in 200..299) {
                val jsonText = apiConn.inputStream.bufferedReader(Charsets.UTF_8).readText()
                val releases = JSONArray(jsonText)
                var bestUrl: String? = null
                var bestUpdatedAt = ""
                for (i in 0 until releases.length()) {
                    val rel = releases.optJSONObject(i) ?: continue
                    val assets = rel.optJSONArray("assets") ?: continue
                    for (j in 0 until assets.length()) {
                        val asset = assets.optJSONObject(j) ?: continue
                        val name = asset.optString("name", "")
                        val url = asset.optString("browser_download_url", "")
                        val updatedAt = asset.optString("updated_at", "")
                        if (name.endsWith(".apk", ignoreCase = true) && url.startsWith("http")) {
                            if (bestUrl == null || updatedAt > bestUpdatedAt) {
                                bestUpdatedAt = updatedAt
                                bestUrl = url
                            }
                        }
                    }
                }
                bestUrl
            } else {
                null
            }
        } catch (_: Exception) {
            null
        } finally {
            try {
                conn?.disconnect()
            } catch (_: Exception) {
            }
        }
    }

    private fun downloadAndInstallLauncherOtaUpdate() {
        if (isOtaDownloading) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !packageManager.canRequestPackageInstalls()) {
            try {
                val permIntent = Intent(
                    Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:$packageName")
                )
                startActivity(permIntent)
                Toast.makeText(this, "Разрешите установку обновлений и нажмите снова", Toast.LENGTH_LONG).show()
                return
            } catch (_: Exception) {
            }
        }

        isOtaDownloading = true
        binding.btnUpdateLauncher.text = "Скачивание обновления... 0%"
        Toast.makeText(this, "Скачивание обновления с GitHub...", Toast.LENGTH_SHORT).show()

        lifecycleScope.launch(Dispatchers.IO) {
            val candidateUrls = mutableListOf<String>()
            val apiAssetUrl = resolveNewestGithubApkUrl()
            if (!apiAssetUrl.isNullOrBlank()) {
                candidateUrls.add(apiAssetUrl)
            }
            candidateUrls.add("https://github.com/ddtrs/mistick/releases/download/v2.0/MiTvStickLauncher-v2.apk")
            candidateUrls.add("https://github.com/ddtrs/mistick/releases/latest/download/MiTvStickLauncher-v2.apk")
            candidateUrls.add("https://github.com/ddtrs/mistick/releases/latest/download/MiTvStickLauncher-release.apk")
            candidateUrls.add("https://github.com/ddtrs/mistick/releases/download/v1.0.0/MiTvStickLauncher-release.apk")
            candidateUrls.add("https://github.com/ddtrs/mistick/releases/latest/download/app-release.apk")

            val outDir = externalCacheDir ?: cacheDir
            val destFile = File(outDir, "launcher_ota_update.apk")
            var downloadedOk = false
            var lastError = "APK не найден в релизах GitHub"

            for (urlStr in candidateUrls.distinct()) {
                var conn: HttpURLConnection? = null
                try {
                    var currentUrl = urlStr
                    var redirects = 0
                    while (redirects < 6) {
                        val c = (URL(currentUrl).openConnection() as HttpURLConnection).apply {
                            instanceFollowRedirects = false
                            connectTimeout = 12000
                            readTimeout = 30000
                            useCaches = false
                            setRequestProperty("Cache-Control", "no-cache")
                            setRequestProperty("User-Agent", "MiTvStickLauncher-OTA/5.8")
                        }
                        conn = c
                        val code = c.responseCode
                        if (code in 300..399) {
                            val loc: String = c.getHeaderField("Location") ?: break
                            c.disconnect()
                            currentUrl = if (loc.startsWith("http", ignoreCase = true)) {
                                loc
                            } else {
                                URL(URL(currentUrl), loc).toString()
                            }
                            redirects++
                            continue
                        }
                        if (code in 200..299) {
                            val totalBytes: Long = c.contentLengthLong
                            if (destFile.exists()) destFile.delete()
                            val inp = c.inputStream
                            val out = FileOutputStream(destFile)
                            try {
                                val buf = ByteArray(16 * 1024)
                                var downloaded: Long = 0L
                                var lastPct: Int = -1
                                while (true) {
                                    val r: Int = inp.read(buf)
                                    if (r <= 0) break
                                    out.write(buf, 0, r)
                                    downloaded += r.toLong()
                                    if (totalBytes > 0L) {
                                        val pct: Int = ((downloaded * 100L) / totalBytes).toInt().coerceIn(0, 100)
                                        if (pct != lastPct && pct % 5 == 0) {
                                            lastPct = pct
                                            withContext(Dispatchers.Main) {
                                                binding.btnUpdateLauncher.text = "Скачивание... $pct%"
                                            }
                                        }
                                    }
                                }
                                out.flush()
                            } finally {
                                try {
                                    inp.close()
                                } catch (_: Exception) {
                                }
                                try {
                                    out.close()
                                } catch (_: Exception) {
                                }
                            }
                            if (destFile.length() > 80_000L) {
                                downloadedOk = true
                            } else {
                                lastError = "Файл повреждён (${destFile.length()} Б)"
                            }
                        } else {
                            lastError = "HTTP $code"
                        }
                        break
                    }
                } catch (e: Exception) {
                    lastError = e.javaClass.simpleName
                } finally {
                    try {
                        conn?.disconnect()
                    } catch (_: Exception) {
                    }
                }
                if (downloadedOk) break
            }

            withContext(Dispatchers.Main) {
                isOtaDownloading = false
                binding.btnUpdateLauncher.text = getString(R.string.launcher_update_btn)
                if (downloadedOk) {
                    launchDownloadedApkInstaller(destFile)
                } else {
                    Toast.makeText(
                        this@LauncherActivity,
                        "Ошибка обновления: $lastError",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private fun launchDownloadedApkInstaller(apkFile: File) {
        try {
            val contentUri = FileProvider.getUriForFile(
                this,
                "com.mitv.customlauncher.fileprovider",
                apkFile
            )
            val installIntent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(contentUri, "application/vnd.android.package-archive")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(installIntent)
        } catch (e: Exception) {
            Toast.makeText(this, "Ошибка запуска установщика: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun setupAppManageOverlay() {
        binding.btnAppManageOpen.setOnClickListener {
            val app = selectedManageApp ?: return@setOnClickListener
            closeAllOverlays(restoreFocus = true)
            viewModel.launchAppDirectly(app)
        }

        binding.btnAppManageUninstall.setOnClickListener {
            val app = selectedManageApp ?: return@setOnClickListener
            binding.appManageOverlay.visibility = View.GONE
            binding.appPickerOverlay.visibility = View.GONE
            launchUninstallApp(app.packageName)
        }

        binding.btnAppManageInfo.setOnClickListener {
            val app = selectedManageApp ?: return@setOnClickListener
            binding.appManageOverlay.visibility = View.GONE
            binding.appPickerOverlay.visibility = View.GONE
            openAppDetailsSettings(app.packageName)
        }
    }

    private fun openAppManageModal(app: InstalledAppInfo) {
        selectedManageApp = app
        binding.tvAppManageTitle.text = app.label
        binding.appManageOverlay.visibility = View.VISIBLE
        binding.btnAppManageUninstall.requestFocus()
    }

    @Suppress("DEPRECATION")
    private fun launchUninstallApp(pkg: String) {
        try {
            val uri = Uri.fromParts("package", pkg, null)
            val intent = Intent(Intent.ACTION_UNINSTALL_PACKAGE, uri).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (_: Exception) {
            try {
                val uri = Uri.fromParts("package", pkg, null)
                val delIntent = Intent(Intent.ACTION_DELETE, uri).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(delIntent)
            } catch (_: Exception) {
                openAppDetailsSettings(pkg)
            }
        }
    }

    private fun openAppDetailsSettings(pkg: String) {
        try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.fromParts("package", pkg, null)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
        } catch (_: Exception) {
            viewModel.launchSystemSettings()
        }
    }

    private fun toggleWifiDirectly() {
        val wm = wifiManager
        if (wm == null) {
            openSettingsIntent(Settings.ACTION_WIFI_SETTINGS)
            return
        }
        val targetState = !wm.isWifiEnabled
        @Suppress("DEPRECATION")
        val changed = try {
            wm.setWifiEnabled(targetState)
        } catch (_: Exception) {
            false
        }
        if (!changed) {
            hideControlCenter(restoreFocus = true)
            openSettingsIntent(Settings.ACTION_WIFI_SETTINGS)
        } else {
            lifecycleScope.launch {
                delay(350L)
                refreshControlCenterToggles()
            }
        }
    }

    private fun toggleBluetoothDirectly() {
        try {
            @Suppress("DEPRECATION")
            val adapter = BluetoothAdapter.getDefaultAdapter()
            if (adapter != null) {
                @Suppress("MissingPermission", "DEPRECATION")
                if (adapter.isEnabled) adapter.disable() else adapter.enable()
                lifecycleScope.launch {
                    delay(400L)
                    refreshControlCenterToggles()
                }
            }
        } catch (_: Exception) {
            openSettingsIntent(Settings.ACTION_BLUETOOTH_SETTINGS)
        }
    }

    private fun refreshControlCenterToggles() {
        val accent = currentAccentColor
        val wifiEnabled = try {
            wifiManager?.isWifiEnabled == true
        } catch (_: Exception) {
            true
        }
        binding.tileCcWifi.background = createToggleDrawable(accent, isActive = wifiEnabled)
        binding.ivCcWifi.setColorFilter(
            if (wifiEnabled) accent else getColor(R.color.text_secondary),
            PorterDuff.Mode.SRC_IN
        )
        binding.tvCcWifiState.text = if (wifiEnabled) "Подключено" else "Выкл."
        binding.tvCcWifiState.setTextColor(if (wifiEnabled) accent else getColor(R.color.text_secondary))

        val btEnabled = try {
            @Suppress("DEPRECATION", "MissingPermission")
            BluetoothAdapter.getDefaultAdapter()?.isEnabled == true
        } catch (_: Exception) {
            true
        }
        binding.tileCcBluetooth.background = createToggleDrawable(accent, isActive = btEnabled)
        binding.ivCcBt.setColorFilter(
            if (btEnabled) accent else getColor(R.color.text_secondary),
            PorterDuff.Mode.SRC_IN
        )
        binding.tvCcBtState.text = if (btEnabled) "Вкл." else "Выкл."
        binding.tvCcBtState.setTextColor(if (btEnabled) accent else getColor(R.color.text_secondary))

        refreshSoundTileState()
        refreshRamTileState(cleanedBonusPct = 0)

        val nightActive = isNightDimCurrentlyActive()
        binding.tileCcNightQuick.background = createToggleDrawable(accent, isActive = nightActive)
        binding.ivCcNightQuick.setColorFilter(
            if (nightActive) accent else getColor(R.color.text_primary),
            PorterDuff.Mode.SRC_IN
        )
        binding.tvCcNightQuickState.text = when (nightModeSetting) {
            NightModeSetting.AUTO -> if (nightActive) "Авто · Активен" else "Авто (23:00)"
            NightModeSetting.ALWAYS_NIGHT -> "Вкл."
            NightModeSetting.ALWAYS_DAY -> "Выкл."
        }
        binding.tvCcNightQuickState.setTextColor(if (nightActive) accent else getColor(R.color.text_secondary))

        val ledOn = TuyaSmartHomeController.isLedOn(this)
        val ledMode = TuyaSmartHomeController.getCurrentModeLabel(this).removePrefix("Режим: ")
        binding.tileCcLedQuick.background = createToggleDrawable(accent, isActive = ledOn)
        binding.ivCcLedQuick.setColorFilter(
            if (ledOn) accent else getColor(R.color.text_primary),
            PorterDuff.Mode.SRC_IN
        )
        binding.tvCcLedQuickState.text = if (ledOn) "ВКЛ · $ledMode" else "Выкл."
        binding.tvCcLedQuickState.setTextColor(if (ledOn) accent else getColor(R.color.text_secondary))

        binding.btnCcQuickLedStudio.background = createSquircleIconDrawable(accent)
        binding.btnMenuBindKey.background = createSquircleIconDrawable(accent)
        binding.btnMenuAssignCurrent.background = createSquircleIconDrawable(accent)
        binding.btnMenuSystemSettings.background = createSquircleIconDrawable(accent)
        refreshControlCenterBottomIconsTint()

        refreshControlCenterTabHeaderStyle()
        refreshSmartHomeUiState()
    }

    private fun refreshSoundTileState() {
        val accent = currentAccentColor
        val isMuted = try {
            audioManager.isStreamMute(AudioManager.STREAM_MUSIC)
        } catch (_: Exception) {
            false
        }
        val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val pct = ((curVol * 100f) / maxVol).toInt().coerceIn(0, 100)
        val soundActive = !isMuted && pct > 0
        binding.tileCcSound.background = createToggleDrawable(accent, isActive = soundActive)
        binding.ivCcSound.setColorFilter(
            if (soundActive) accent else getColor(R.color.text_secondary),
            PorterDuff.Mode.SRC_IN
        )
        binding.tvCcSoundState.text = if (isMuted || pct == 0) "Без звука" else "Динамики ТВ · $pct%"
        binding.tvCcSoundState.setTextColor(if (soundActive) accent else getColor(R.color.text_secondary))
    }

    private fun refreshRamTileState(cleanedBonusPct: Int = 0) {
        val accent = currentAccentColor
        val usedPct = try {
            val am = getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            am?.getMemoryInfo(memInfo)
            if (memInfo.totalMem > 0L) {
                val raw = (((memInfo.totalMem - memInfo.availMem) * 100L) / memInfo.totalMem).toInt()
                (raw - cleanedBonusPct).coerceIn(22, 95)
            } else {
                (58 - cleanedBonusPct).coerceAtLeast(25)
            }
        } catch (_: Exception) {
            (58 - cleanedBonusPct).coerceAtLeast(25)
        }

        binding.tileCcBoost.background = createToggleDrawable(accent, isActive = cleanedBonusPct > 0)
        binding.ivCcBoost.setColorFilter(
            if (cleanedBonusPct > 0) accent else getColor(R.color.text_primary),
            PorterDuff.Mode.SRC_IN
        )
        binding.tvCcBoostState.text = if (cleanedBonusPct > 0) "$usedPct% · Очищено" else "$usedPct% занято"
        binding.tvCcBoostState.setTextColor(if (cleanedBonusPct > 0) accent else getColor(R.color.text_secondary))

        binding.flCcRamTrack.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(99f).toFloat()
            setColor(Color.parseColor("#38FFFFFF"))
        }
        binding.vCcRamFill.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(99f).toFloat()
            setColor(if (cleanedBonusPct > 0) accent else Color.WHITE)
        }
        binding.flCcRamTrack.post {
            val totalW = binding.flCcRamTrack.width
            if (totalW > 0) {
                val lp = binding.vCcRamFill.layoutParams
                lp.width = ((totalW * usedPct) / 100).coerceAtLeast(dpPx(6f))
                binding.vCcRamFill.layoutParams = lp
            }
        }
    }

    private fun refreshControlCenterBottomIconsTint() {
        val accent = currentAccentColor
        val white = getColor(R.color.text_primary)
        binding.ivCcQuickLedStudio.setColorFilter(if (binding.btnCcQuickLedStudio.hasFocus()) accent else white, PorterDuff.Mode.SRC_IN)
        binding.ivCcQuickRemote.setColorFilter(if (binding.btnMenuBindKey.hasFocus()) accent else white, PorterDuff.Mode.SRC_IN)
        binding.ivCcQuickLauncherSettings.setColorFilter(if (binding.btnMenuAssignCurrent.hasFocus()) accent else white, PorterDuff.Mode.SRC_IN)
        binding.ivCcQuickSysSettings.setColorFilter(if (binding.btnMenuSystemSettings.hasFocus()) accent else white, PorterDuff.Mode.SRC_IN)
    }

    private fun isProtectedMediaPackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("spotify") ||
            p.contains("soundcloud") ||
            p.contains("mediashell") ||
            p.contains("chromecast") ||
            p.contains("music") ||
            p.contains("youtube") ||
            p.contains("remote") ||
            p.contains("katniss") ||
            p.contains("bluetooth") ||
            p.contains("google.android.gms")
    }

    private fun silentCleanBackgroundProcesses() {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val am = getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return@launch
                val activeMusicPkg = MediaStateBus.state.value.sourcePackage
                val ctrlPkg = MediaStateBus.activeController?.packageName.orEmpty()
                val apps = viewModel.uiState.value.installedApps
                for (app in apps) {
                    val pkg = app.packageName
                    if (pkg != packageName &&
                        pkg != activeMusicPkg &&
                        pkg != ctrlPkg &&
                        !isProtectedMediaPackage(pkg)
                    ) {
                        am.killBackgroundProcesses(pkg)
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun openSettingsIntent(action: String) {
        val intent = Intent(action).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(intent)
        } catch (_: Exception) {
            viewModel.launchSystemSettings()
        }
    }

    private fun renderNowPlayingWidget(snapshot: NowPlayingSnapshot) {
        if (binding.controlCenterPanel.visibility == View.VISIBLE) {
            binding.nowPlayingCard.visibility = View.INVISIBLE
            return
        }

        val hasRealTrack = snapshot.hasActiveSession &&
            snapshot.title.isNotBlank() &&
            !snapshot.title.equals(snapshot.sourceAppName, ignoreCase = true) &&
            !MediaStateBus.isExcludedVideoPackage(snapshot.sourcePackage)

        if (!hasRealTrack) {
            binding.llNowPlayingControls.visibility = View.GONE
            binding.nowPlayingCard.visibility = View.GONE
            return
        }

        if (binding.nowPlayingCard.visibility != View.VISIBLE) {
            binding.nowPlayingCard.alpha = 0f
            binding.nowPlayingCard.visibility = View.VISIBLE
            binding.nowPlayingCard.animate().alpha(1f).setDuration(160L).start()
        }

        binding.tvNowPlayingTitle.text = when {
            snapshot.title.isNotEmpty() -> snapshot.title
            snapshot.sourceAppName.isNotEmpty() -> "${snapshot.sourceAppName} · в эфире"
            else -> getString(R.string.now_playing_active_generic)
        }
        binding.tvNowPlayingArtist.text = when {
            snapshot.artist.isNotEmpty() && !snapshot.artist.equals(snapshot.sourceAppName, ignoreCase = true) ->
                if (snapshot.sourceAppName.isNotEmpty()) "${snapshot.artist} · ${snapshot.sourceAppName}" else snapshot.artist
            snapshot.sourceAppName.isNotEmpty() -> snapshot.sourceAppName
            else -> snapshot.artist
        }

        binding.ivNpPlayPause.setImageResource(
            if (snapshot.isPlaying) R.drawable.ic_media_pause else R.drawable.ic_media_play
        )

        if (snapshot.coverBitmap != null) {
            binding.ivNowPlayingArt.setPadding(0, 0, 0, 0)
            binding.ivNowPlayingArt.clearColorFilter()
            binding.ivNowPlayingArt.setImageBitmap(snapshot.coverBitmap)
        } else {
            val pad = (10 * resources.displayMetrics.density).toInt()
            binding.ivNowPlayingArt.setPadding(pad, pad, pad, pad)
            if (snapshot.sourcePackage.isNotEmpty()) {
                binding.ivNowPlayingArt.setImageDrawable(
                    iconStylizer.getStylizedIcon(snapshot.sourcePackage, snapshot.sourceAppName)
                )
            } else {
                binding.ivNowPlayingArt.setImageResource(R.drawable.ic_music_64)
            }
            binding.ivNowPlayingArt.setColorFilter(currentAccentColor, PorterDuff.Mode.SRC_IN)
        }

        updateLiveTrackProgressTick()
    }

    private fun updateLiveTrackProgressTick() {
        val snap = MediaStateBus.state.value
        if (!snap.hasActiveSession || binding.nowPlayingCard.visibility != View.VISIBLE) return

        val (posMs, durMs) = MediaStateBus.getLivePositionAndDuration()
        val posSec = (posMs / 1000L).coerceAtLeast(0L)
        val posFormatted = String.format("%02d:%02d", posSec / 60, posSec % 60)

        if (durMs > 0L) {
            val durSec = (durMs / 1000L).coerceAtLeast(1L)
            val durFormatted = String.format("%02d:%02d", durSec / 60, durSec % 60)
            binding.tvNowPlayingTime.text = "$posFormatted / $durFormatted"
        } else {
            binding.tvNowPlayingTime.text = posFormatted
        }

        val trackW = binding.flNowPlayingProgressTrack.width
        if (trackW > 0) {
            val ratio = if (durMs > 0L) {
                (posMs.toFloat() / durMs.toFloat()).coerceIn(0.04f, 1.0f)
            } else {
                val cycle = (posSec % 180L).toFloat() / 180f
                cycle.coerceIn(0.06f, 1.0f)
            }
            val fillW = (trackW * ratio).toInt().coerceAtLeast(6)
            val lp = binding.vNowPlayingVisualizer.layoutParams
            if (lp.width != fillW) {
                lp.width = fillW
                binding.vNowPlayingVisualizer.layoutParams = lp
            }
        }
    }

    private fun setupRemoteKeySelectOverlay() {
        binding.btnKeyEnableAccessibility.setOnClickListener {
            appLauncherDirect.launchAccessibilitySettings()
        }

        binding.btnKeyPresetPatchwall.setOnClickListener {
            pendingPresetId = "PATCHWALL"
            pendingKeyDisplayName = "9 квадратиков"
            capturedKeyCode = 0
            capturedScanCode = 0
            binding.remoteKeySelectOverlay.visibility = View.GONE
            openAppPickerOverlay(assignSlot = null, forKeyBind = true)
        }

        binding.btnKeyPresetNetflix.setOnClickListener {
            pendingPresetId = "NETFLIX"
            pendingKeyDisplayName = "NETFLIX"
            capturedKeyCode = 0
            capturedScanCode = 0
            binding.remoteKeySelectOverlay.visibility = View.GONE
            openAppPickerOverlay(assignSlot = null, forKeyBind = true)
        }

        binding.btnKeyPresetPrime.setOnClickListener {
            pendingPresetId = "PRIME"
            pendingKeyDisplayName = "prime video"
            capturedKeyCode = 0
            capturedScanCode = 0
            binding.remoteKeySelectOverlay.visibility = View.GONE
            openAppPickerOverlay(assignSlot = null, forKeyBind = true)
        }

        binding.btnKeyCustomListen.setOnClickListener {
            binding.remoteKeySelectOverlay.visibility = View.GONE
            startLiveKeyCapture()
        }
    }

    private fun startLiveKeyCapture() {
        pendingPresetId = null
        binding.keyCaptureOverlay.visibility = View.VISIBLE
        binding.keyCaptureOverlay.requestFocus()
        KeyCaptureBus.onKeyCapturedListener = { keyCode, scanCode ->
            onLiveKeyCaught(keyCode, scanCode)
        }
        KeyCaptureBus.isCapturingKey = true
    }

    private fun stopLiveKeyCapture() {
        KeyCaptureBus.isCapturingKey = false
        KeyCaptureBus.onKeyCapturedListener = null
        binding.keyCaptureOverlay.visibility = View.GONE
    }

    private fun onLiveKeyCaught(keyCode: Int, scanCode: Int) {
        stopLiveKeyCapture()
        pendingPresetId = null
        capturedKeyCode = keyCode
        capturedScanCode = scanCode
        pendingKeyDisplayName = "Key #$keyCode (Scan #$scanCode)"
        openAppPickerOverlay(assignSlot = null, forKeyBind = true)
    }

    private fun updateAccessibilityStatusRow() {
        val enabled = isAccessibilityMapperEnabled()
        if (enabled) {
            binding.btnKeyEnableAccessibility.text = getString(R.string.key_service_status_on)
            binding.btnKeyEnableAccessibility.setTextColor(currentAccentColor)
        } else {
            binding.btnKeyEnableAccessibility.text = getString(R.string.key_service_status_off)
            binding.btnKeyEnableAccessibility.setTextColor(getColor(R.color.status_error))
        }
    }

    private fun isAccessibilityMapperEnabled(): Boolean {
        if (KeyMapperAccessibilityService.isServiceConnectedAlive) return true
        return try {
            val enabledServices = Settings.Secure.getString(
                contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            enabledServices.contains(packageName) && ServiceAutoActivator.hasWriteSecureSettings(this)
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Сетка «Все приложения» с жёсткой привязкой ViewId и nextFocusLeft/Right/Up/Down
     * (курсор гарантированно наводится на 100% программ, а удержание OK открывает меню Удаления/Инфо!).
     */
    private fun openAppPickerOverlay(assignSlot: CardSlot?, forKeyBind: Boolean) {
        val apps = viewModel.uiState.value.installedApps
        binding.tvPickerTitle.text = when {
            forKeyBind -> getString(R.string.picker_title_key_bind, pendingKeyDisplayName)
            assignSlot != null -> getString(R.string.picker_title_assign, apps.size)
            else -> getString(R.string.picker_title_launch, apps.size)
        }

        val container = binding.llAppListContainer
        container.removeAllViews()

        val dp = resources.displayMetrics.density
        val pad = (14 * dp).toInt()
        val iconPx = (44 * dp).toInt()
        val gap = (10 * dp).toInt()

        val actionRows = mutableListOf<View>()
        if (forKeyBind) {
            val specialActions = listOf(
                "ACTION_CONTROL_CENTER" to getString(R.string.action_open_control_center),
                "ACTION_ALL_APPS" to getString(R.string.action_open_all_apps),
                "ACTION_SETTINGS" to getString(R.string.action_open_tv_settings),
                "ACTION_AI" to getString(R.string.action_open_ai_assistant),
                "" to getString(R.string.action_clear_binding)
            )
            specialActions.forEach { (actionCode, actionTitle) ->
                val row = createActionRow(actionTitle, dp) {
                    applyKeyOrPresetBinding(actionCode.ifEmpty { null }, actionTitle)
                }.apply {
                    id = View.generateViewId()
                }
                actionRows.add(row)
                container.addView(row)
            }
        }

        val columns = 4
        val appTiles = mutableListOf<View>()
        val tileRowParents = mutableListOf<View>()

        val chunked = apps.chunked(columns)
        chunked.forEach { rowApps ->
            val rowLayout = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                weightSum = columns.toFloat()
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = gap
                }
            }

            for (col in 0 until columns) {
                val app = rowApps.getOrNull(col)
                if (app != null) {
                    val tile = LinearLayout(this).apply {
                        id = View.generateViewId()
                        orientation = LinearLayout.VERTICAL
                        gravity = Gravity.CENTER
                        background = createCardSelectorDrawable(currentAccentColor)
                        isFocusable = true
                        isClickable = true
                        isLongClickable = (assignSlot == null && !forKeyBind)
                        isFocusableInTouchMode = false
                        setDefaultFocusHighlightEnabled(false)
                        setPadding(pad, pad, pad, pad)
                        layoutParams = LinearLayout.LayoutParams(
                            0,
                            (112 * dp).toInt(),
                            1f
                        ).apply {
                            if (col < columns - 1) marginEnd = gap
                        }
                    }

                    val iconView = ImageView(this).apply {
                        layoutParams = LinearLayout.LayoutParams(iconPx, iconPx)
                        scaleType = ImageView.ScaleType.FIT_CENTER
                        setImageDrawable(iconStylizer.getStylizedIcon(app.packageName, app.label))
                        setColorFilter(getColor(R.color.text_primary), PorterDuff.Mode.SRC_IN)
                    }

                    val titleView = TextView(this).apply {
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply {
                            topMargin = (8 * dp).toInt()
                        }
                        gravity = Gravity.CENTER
                        text = app.label
                        setTextColor(getColor(R.color.text_primary))
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                        maxLines = 1
                        ellipsize = TextUtils.TruncateAt.END
                    }

                    tile.setOnFocusChangeListener { _, hasFocus ->
                        val tint = if (hasFocus) currentAccentColor else getColor(R.color.text_primary)
                        iconView.setColorFilter(tint, PorterDuff.Mode.SRC_IN)
                        titleView.setTextColor(tint)
                        if (hasFocus) {
                            binding.svAppList.post {
                                val targetY = (rowLayout.top - dpPx(16f)).coerceAtLeast(0)
                                binding.svAppList.smoothScrollTo(0, targetY)
                            }
                        }
                    }

                    tile.setOnClickListener {
                        when {
                            forKeyBind -> applyKeyOrPresetBinding(app.packageName, app.label)
                            assignSlot != null -> {
                                viewModel.assignAppToSlot(assignSlot, app)
                                binding.appPickerOverlay.visibility = View.GONE
                                if (returnToLauncherSettingsAfterAssign) {
                                    returnToLauncherSettingsAfterAssign = false
                                    openLauncherSettingsOverlay()
                                } else {
                                    closeAllOverlays(restoreFocus = true)
                                }
                            }
                            else -> {
                                MediaStateBus.onMediaAppOpened(app.packageName)
                                closeAllOverlays(restoreFocus = true)
                                viewModel.launchAppDirectly(app)
                            }
                        }
                    }

                    if (assignSlot == null && !forKeyBind) {
                        tile.setOnLongClickListener {
                            openAppManageModal(app)
                            true
                        }
                    }

                    tile.addView(iconView)
                    tile.addView(titleView)
                    rowLayout.addView(tile)
                    appTiles.add(tile)
                    tileRowParents.add(rowLayout)
                } else {
                    val spacer = View(this).apply {
                        isFocusable = false
                        isClickable = false
                        layoutParams = LinearLayout.LayoutParams(0, 1, 1f).apply {
                            if (col < columns - 1) marginEnd = gap
                        }
                    }
                    rowLayout.addView(spacer)
                }
            }
            container.addView(rowLayout)
        }

        // Явно связываем навигацию для спец-действий (если открыто меню привязки кнопки)
        for (i in actionRows.indices) {
            val row = actionRows[i]
            row.nextFocusLeftId = row.id
            row.nextFocusRightId = row.id
            row.nextFocusUpId = if (i > 0) actionRows[i - 1].id else row.id
            row.nextFocusDownId = when {
                i < actionRows.lastIndex -> actionRows[i + 1].id
                appTiles.isNotEmpty() -> appTiles[0].id
                else -> row.id
            }
        }

        // Явно связываем навигацию для ВСЕХ плиток программ (чтобы курсор никогда не застревал на неполных рядах!)
        for (i in appTiles.indices) {
            val tile = appTiles[i]
            tile.nextFocusLeftId = if (i > 0) appTiles[i - 1].id else tile.id
            tile.nextFocusRightId = if (i < appTiles.lastIndex) appTiles[i + 1].id else tile.id

            tile.nextFocusUpId = when {
                i - columns >= 0 -> appTiles[i - columns].id
                actionRows.isNotEmpty() -> actionRows.last().id
                else -> tile.id
            }

            val currentRowIdx = i / columns
            val lastRowIdx = (appTiles.size - 1) / columns
            tile.nextFocusDownId = if (currentRowIdx < lastRowIdx) {
                val targetIdx = (i + columns).coerceAtMost(appTiles.lastIndex)
                appTiles[targetIdx].id
            } else {
                tile.id
            }
        }

        binding.appPickerOverlay.visibility = View.VISIBLE
        val firstTarget = actionRows.firstOrNull() ?: appTiles.firstOrNull()
        firstTarget?.post {
            firstTarget.requestFocus()
        }
    }

    private fun createActionRow(title: String, dp: Float, onClick: () -> Unit): View {
        return TextView(this).apply {
            text = title
            setTextColor(getColor(R.color.text_primary))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            background = createMenuSelectorDrawable(currentAccentColor)
            isFocusable = true
            isClickable = true
            isFocusableInTouchMode = false
            setDefaultFocusHighlightEnabled(false)
            val pad = (14 * dp).toInt()
            setPadding(pad, pad, pad, pad)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = (8 * dp).toInt()
            }
            setOnFocusChangeListener { _, hasFocus ->
                setTextColor(if (hasFocus) currentAccentColor else getColor(R.color.text_primary))
            }
            setOnClickListener { onClick() }
        }
    }

    private fun applyKeyOrPresetBinding(targetValue: String?, targetLabel: String) {
        val preset = pendingPresetId
        if (preset != null) {
            appLauncherDirect.savePresetBinding(preset, targetValue)
        } else {
            appLauncherDirect.saveKeyBinding(capturedKeyCode, capturedScanCode, targetValue)
        }
        Toast.makeText(
            this,
            getString(R.string.toast_key_bound, pendingKeyDisplayName, targetLabel),
            Toast.LENGTH_SHORT
        ).show()
        closeAllOverlays(restoreFocus = true)
    }

    private fun observeStateAndLifecycle() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                burnInProtector.onUserInteraction(this)

                val filter = IntentFilter().apply {
                    addAction(Intent.ACTION_TIME_CHANGED)
                    addAction(Intent.ACTION_TIMEZONE_CHANGED)
                    addAction(Intent.ACTION_LOCALE_CHANGED)
                }
                ContextCompat.registerReceiver(
                    this@LauncherActivity,
                    timeChangeReceiver,
                    filter,
                    ContextCompat.RECEIVER_EXPORTED
                )

                val volFilter = IntentFilter("android.media.VOLUME_CHANGED_ACTION")
                ContextCompat.registerReceiver(
                    this@LauncherActivity,
                    volumeChangeReceiver,
                    volFilter,
                    ContextCompat.RECEIVER_EXPORTED
                )

                val mediaFilter = IntentFilter().apply {
                    for (mediaAct in MediaStateBus.UNIVERSAL_MEDIA_BROADCAST_ACTIONS) {
                        addAction(mediaAct)
                    }
                }
                ContextCompat.registerReceiver(
                    this@LauncherActivity,
                    mediaBroadcastReceiver,
                    mediaFilter,
                    ContextCompat.RECEIVER_EXPORTED
                )

                // Живой опрос плеера каждые 500 мс (мгновенная синхронизация Spotify и Cast в реальном времени!)
                launch {
                    var musicActiveHalfSecStreak = 0
                    while (isActive) {
                        viewModel.refreshTimeAndDate()
                        MediaStateBus.pollActiveControllerLight(this@LauncherActivity)
                        if (audioManager.isMusicActive) {
                            musicActiveHalfSecStreak++
                            if (musicActiveHalfSecStreak >= 2) {
                                MediaStateBus.onContinuousBackgroundMusicDetected(this@LauncherActivity)
                            }
                        } else {
                            musicActiveHalfSecStreak = 0
                        }
                        updateLiveTrackProgressTick()
                        delay(500L)
                    }
                }

                launch {
                    OutageRepository.refreshIfNeeded(this@LauncherActivity, force = false)
                }

                launch {
                    var tickCounter = 0
                    while (isActive) {
                        delay(30_000L)
                        tickCounter++
                        OutageRepository.recomputeFromCachedJson(this@LauncherActivity)
                        if (tickCounter % 15 == 0) {
                            OutageRepository.refreshIfNeeded(this@LauncherActivity, force = false)
                        }
                    }
                }

                launch {
                    OutageRepository.state.collect { outageSnap ->
                        renderOutageWidgetAndPanel(outageSnap)
                    }
                }

                launch {
                    MediaStateBus.state.collect { snapshot ->
                        renderNowPlayingWidget(snapshot)
                    }
                }

                launch {
                    viewModel.observeNetworkInForeground().collect { netStatus ->
                        viewModel.updateNetworkStatus(netStatus)
                    }
                }

                launch {
                    viewModel.uiState.collect { state ->
                        updateNightModeState(immediate = false, durationMs = 60_000L)
                    val rawTime = state.timeText // "HH:mm:ss"
                    if (rawTime.length >= 8 && rawTime[2] == ':' && rawTime[5] == ':') {
                        val hours = rawTime.substring(0, 2)
                        val mins = rawTime.substring(3, 5)
                        val secs = rawTime.substring(6, 8)
                        // Точно как на макете: "17:25 40" (моноширинное двоеточие без лишних пробелов + маленькие секунды цвета акцента)
                        val fullClock = "$hours:$mins $secs"
                        val spannable = SpannableString(fullClock)

                        // Мигание двоеточия: прозрачность от 1.0 (255) до 0.25 (64) раз в секунду
                        val secInt = secs.toIntOrNull() ?: 0
                        val isEvenSec = (secInt % 2 == 0)
                        val colonAlpha = if (isEvenSec) 255 else 64
                        val colonColor = ColorUtils.setAlphaComponent(Color.WHITE, colonAlpha)
                        val colonIdx = fullClock.indexOf(":")
                        if (colonIdx != -1) {
                            spannable.setSpan(ForegroundColorSpan(colonColor), colonIdx, colonIdx + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                        }

                        // Секунды + пробел перед ними уменьшены до 45% по нижней линии (отступ 11px и размер 1:1 как на 3290.jpg), цвет акцента 60%
                        val spaceAndSecStart = (fullClock.length - secs.length - 1).coerceAtLeast(0)
                        val secStart = fullClock.length - secs.length
                        val secColor = ColorUtils.setAlphaComponent(currentAccentColor, 153) // 60%
                        spannable.setSpan(RelativeSizeSpan(0.45f), spaceAndSecStart, fullClock.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                        spannable.setSpan(ForegroundColorSpan(secColor), secStart, fullClock.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)

                        binding.tvClock.text = spannable
                    } else {
                        binding.tvClock.text = state.timeText
                    }
                        binding.tvDate.text = state.dateText
                        updateAppStrip(state.slot1App, state.slot2App, state.slot3App, state.slot4App, state.installedApps)
                        renderNetworkCornerIcon(state.networkStatus)
                        renderAssistantState(state.assistantState, state.isOverlayVisible)
                    }
                }

                launch {
                    viewModel.events.collect { event ->
                        when (event) {
                            is LauncherUiEvent.ShowToastRes -> {
                                Toast.makeText(this@LauncherActivity, event.stringResId, Toast.LENGTH_SHORT).show()
                            }
                            is LauncherUiEvent.ShowBoundToast -> {
                                Toast.makeText(
                                    this@LauncherActivity,
                                    getString(R.string.toast_app_bound, event.appLabel),
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                            is LauncherUiEvent.OpenAppAssignPicker -> {
                                lastFocusedMainCard = currentFocus
                                openAppPickerOverlay(assignSlot = event.slot, forKeyBind = false)
                            }
                            LauncherUiEvent.RequestAudioPermission -> {
                                audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                            LauncherUiEvent.RestoreFocusToAiCard -> {
                                binding.cardAi.requestFocus()
                            }
                            LauncherUiEvent.RestoreFocusToYoutubeCard -> {
                                if (::appStrip.isInitialized) {
                                    appStrip.scrollToStart(animated = true)
                                }
                                binding.cardYoutube.requestFocus()
                                binding.cardYoutube.post { binding.cardYoutube.requestFocus() }
                            }
                        }
                    }
                }

                try {
                    awaitCancellation()
                } finally {
                    unregisterReceiver(timeChangeReceiver)
                    unregisterReceiver(volumeChangeReceiver)
                    unregisterReceiver(mediaBroadcastReceiver)
                    burnInProtector.stop()
                }
            }
        }
    }

    private fun setupAppStrip() {
        appStrip = AppStripController(
            parent = binding.contentContainer,
            cards = listOf(binding.cardYoutube, binding.cardCast, binding.cardBrowser, binding.cardAi),
            icons = listOf(binding.ivCard1, binding.ivCard3, binding.ivCard2, binding.ivCardAi),
            titles = listOf(binding.tvCard1, binding.tvCard3, binding.tvCard2, binding.tvCard4),
            defaultTitleRes = listOf(
                R.string.card_slot_1_default,
                R.string.card_slot_3_default,
                R.string.card_slot_2_default,
                R.string.card_slot_4_default
            ),
            bind = { app, icon, title, card, defaultRes -> renderSlotCard(app, icon, title, card, defaultRes) }
        )
        stripReorder = StripReorderOverlay(
            host = binding.rootFrame,
            titleText = getString(R.string.strip_reorder_title),
            hintText = getString(R.string.strip_reorder_hint),
            emptyText = getString(R.string.strip_reorder_empty),
            panelBackground = { createPanelDrawable(currentAccentColor, 22f) },
            rowBackground = { createMenuSelectorDrawable(currentAccentColor) },
            accentColor = { currentAccentColor },
            onClose = { order -> onStripReorderClosed(order) }
        )
    }

    private fun updateAppStrip(
        slot1: InstalledAppInfo?,
        slot2: InstalledAppInfo?,
        slot3: InstalledAppInfo?,
        slot4: InstalledAppInfo?,
        installed: List<InstalledAppInfo>
    ) {
        if (!::appStrip.isInitialized) return
        val key = listOf(slot1, slot2, slot3, slot4, installed)
        if (key != stripKey) {
            stripKey = key
            val pinned = listOf(slot1, slot3, slot2, slot4)
            val pinnedPackages = pinned.mapNotNull { it?.packageName }.toSet()
            val extras = appLauncherDirect.orderedExtraApps(installed, pinnedPackages)
            stripApps = pinned + extras
            appStrip.setApps(stripApps)
        } else {
            appStrip.render()
        }
    }

    private fun onStripReorderClosed(order: List<String>) {
        appLauncherDirect.saveStripOrder(order)
        stripKey = null
        val st = viewModel.uiState.value
        updateAppStrip(st.slot1App, st.slot2App, st.slot3App, st.slot4App, st.installedApps)
        openLauncherSettingsOverlay()
    }

    private fun renderSlotCard(
        appInfo: InstalledAppInfo?,
        iconView: ImageView,
        titleView: TextView,
        cardView: View,
        defaultTitleRes: Int
    ) {
        if (appInfo != null) {
            titleView.text = appInfo.label
            cardView.contentDescription = appInfo.label
            iconView.setImageDrawable(iconStylizer.getStylizedIcon(appInfo.packageName, appInfo.label))
        } else {
            titleView.text = getString(defaultTitleRes)
            iconView.setImageResource(R.drawable.ic_grid_apps_64)
        }
        val tintColor = if (cardView.hasFocus()) currentAccentColor else getColor(R.color.text_primary)
        iconView.setColorFilter(tintColor, PorterDuff.Mode.SRC_IN)
    }

    private fun renderNetworkCornerIcon(status: NetworkStatus) {
        val resId = when (status) {
            is NetworkStatus.Wifi -> when {
                status.level >= 4 -> R.drawable.ic_wifi_neon_4
                status.level == 3 -> R.drawable.ic_wifi_neon_3
                status.level == 2 -> R.drawable.ic_wifi_neon_2
                else -> R.drawable.ic_wifi_neon_1
            }
            NetworkStatus.Ethernet -> R.drawable.ic_wifi_neon_4
            NetworkStatus.Disconnected -> R.drawable.ic_wifi_off
        }
        binding.ivWifiCorner.setImageResource(resId)
        binding.ivWifiCorner.setColorFilter(currentAccentColor, PorterDuff.Mode.SRC_IN)
        binding.ivCcWifi.setImageResource(resId)
    }

    private fun renderAssistantState(aiState: AssistantState, isOverlayVisible: Boolean) {
        binding.assistantOverlay.visibility = if (isOverlayVisible) View.VISIBLE else View.GONE
        if (isOverlayVisible) {
            binding.assistantOverlay.requestFocus()
        }

        when (aiState) {
            AssistantState.Idle -> {}
            AssistantState.Listening -> {
                binding.tvOverlayTitle.text = getString(R.string.overlay_title_listening)
            }
            AssistantState.Processing -> {
                binding.tvOverlayTitle.text = getString(R.string.overlay_title_processing)
            }
            is AssistantState.Result -> {
                binding.tvOverlayTitle.text = getString(R.string.overlay_title_result)
                binding.tvOverlayBody.text = aiState.text
            }
            is AssistantState.Error -> {
                binding.tvOverlayTitle.text = getString(R.string.overlay_title_error)
            }
        }
    }

    private fun isAnyOverlayOpen(): Boolean {
        return binding.controlCenterPanel.visibility == View.VISIBLE ||
            binding.outageSchedulePanel.visibility == View.VISIBLE ||
            binding.launcherSettingsOverlay.visibility == View.VISIBLE ||
            binding.appManageOverlay.visibility == View.VISIBLE ||
            binding.remoteKeySelectOverlay.visibility == View.VISIBLE ||
            binding.keyCaptureOverlay.visibility == View.VISIBLE ||
            binding.appPickerOverlay.visibility == View.VISIBLE ||
            binding.assistantOverlay.visibility == View.VISIBLE ||
            (::stripReorder.isInitialized && stripReorder.isVisible)
    }

    private fun closeAllOverlays(restoreFocus: Boolean) {
        returnToLauncherSettingsAfterAssign = false
        stopLiveKeyCapture()
        hideControlCenter(restoreFocus = false)
        hideOutageSchedulePanel(restoreFocus = false)
        binding.launcherSettingsOverlay.visibility = View.GONE
        binding.appManageOverlay.visibility = View.GONE
        binding.remoteKeySelectOverlay.visibility = View.GONE
        binding.appPickerOverlay.visibility = View.GONE
        if (::stripReorder.isInitialized) stripReorder.hideSilently()
        if (binding.assistantOverlay.visibility == View.VISIBLE) {
            viewModel.closeAssistantOverlay(restoreFocusToAi = false)
        }
        if (restoreFocus) {
            (lastFocusedMainCard ?: binding.cardYoutube).requestFocus()
        }
    }

    private fun isCenterKey(keyCode: Int): Boolean {
        return keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
            keyCode == KeyEvent.KEYCODE_ENTER ||
            keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER ||
            keyCode == KeyEvent.KEYCODE_BUTTON_SELECT ||
            keyCode == KeyEvent.KEYCODE_BUTTON_A
    }

    private fun isDpadDirectionKey(keyCode: Int): Boolean {
        return keyCode == KeyEvent.KEYCODE_DPAD_UP ||
            keyCode == KeyEvent.KEYCODE_DPAD_DOWN ||
            keyCode == KeyEvent.KEYCODE_DPAD_LEFT ||
            keyCode == KeyEvent.KEYCODE_DPAD_RIGHT
    }

    private fun hasAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }
}
