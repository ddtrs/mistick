package com.mitv.customlauncher.ui

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.app.ActivityManager
import android.bluetooth.BluetoothAdapter
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Outline
import android.graphics.PorterDuff
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.mitv.customlauncher.R
import com.mitv.customlauncher.data.AppLauncher
import com.mitv.customlauncher.data.AssistantState
import com.mitv.customlauncher.data.CardSlot
import com.mitv.customlauncher.data.ClockFormatter
import com.mitv.customlauncher.data.IconStylizer
import com.mitv.customlauncher.data.InstalledAppInfo
import com.mitv.customlauncher.data.LauncherConfig
import com.mitv.customlauncher.data.NetworkMonitor
import com.mitv.customlauncher.data.NetworkStatus
import com.mitv.customlauncher.databinding.ActivityLauncherBinding
import com.mitv.customlauncher.presentation.LauncherUiEvent
import com.mitv.customlauncher.presentation.LauncherViewModel
import com.mitv.customlauncher.service.KeyCaptureBus
import com.mitv.customlauncher.service.MediaStateBus
import com.mitv.customlauncher.service.NowPlayingSnapshot
import com.mitv.customlauncher.service.VolumeHudBus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.awaitCancellation
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class LauncherActivity : ComponentActivity() {

    private lateinit var binding: ActivityLauncherBinding
    private lateinit var burnInProtector: BurnInProtector
    private lateinit var iconStylizer: IconStylizer
    private lateinit var appLauncherDirect: AppLauncher
    private lateinit var audioManager: AudioManager
    private var wifiManager: WifiManager? = null

    private val focusAnimators = mutableMapOf<View, ObjectAnimator>()
    private val decelerateInterpolator = DecelerateInterpolator()

    private var lastFocusedMainCard: View? = null
    private var activeMenuSlot: CardSlot? = null

    private var centerHoldJob: Job? = null
    private var centerIsDown = false
    private var centerLongTriggered = false

    private var volumeHudHideJob: Job? = null

    private var pendingPresetId: String? = null
    private var pendingKeyDisplayName: String = ""
    private var capturedKeyCode = 0
    private var capturedScanCode = 0

    private val viewModel: LauncherViewModel by viewModels {
        LauncherViewModel.Factory(
            appLauncher = AppLauncher(applicationContext),
            networkMonitor = NetworkMonitor(applicationContext),
            demoReplyText = getString(R.string.fake_ai_demo_response)
        )
    }

    private val audioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            viewModel.onAssistantTrigger(hasAudioPermission = true)
        }
    }

    private val timeChangeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            viewModel.refreshTimeAndDate(forceDate = true)
        }
    }

    // Системный сигнал изменения громкости: обновляет плитку в Центре управления И показывает наш неоновый HUD!
    private val volumeChangeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            refreshSoundTileState()
            showCustomVolumeHud()
        }
    }

    private val mediaBroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            val track = intent.getStringExtra("track")
                ?: intent.getStringExtra("title")
                ?: intent.getStringExtra("android.intent.extra.TITLE")
                ?: ""
            val artist = intent.getStringExtra("artist")
                ?: intent.getStringExtra("album")
                ?: ""
            val duration = intent.getLongExtra("duration", -1L)
            val position = intent.getLongExtra("position", -1L)
            val pkg = intent.`package` ?: ""
            if (track.isNotEmpty() || artist.isNotEmpty()) {
                MediaStateBus.updateMetadata(
                    title = track,
                    artist = artist,
                    sourcePackage = pkg,
                    sourceAppName = if (pkg.isNotEmpty()) pkg.substringAfterLast('.') else "",
                    cover = null,
                    durationMs = duration,
                    positionMs = position
                )
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLauncherBinding.inflate(layoutInflater)
        setContentView(binding.root)

        audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        wifiManager = applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
        appLauncherDirect = AppLauncher(applicationContext)
        iconStylizer = IconStylizer(applicationContext)
        burnInProtector = BurnInProtector(
            targetView = binding.contentContainer,
            density = resources.displayMetrics.density
        )

        binding.tvNowPlayingTitle.isSelected = true

        val cornerPx = 12f * resources.displayMetrics.density
        binding.ivNowPlayingArt.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, cornerPx)
            }
        }
        binding.ivNowPlayingArt.clipToOutline = true

        VolumeHudBus.onVolumeIntercepted = {
            refreshSoundTileState()
            showCustomVolumeHud()
        }

        setupMainCardsAndCornerPill()
        setupNowPlayingHoverControls()
        setupControlCenterPanel()
        setupRemoteKeySelectOverlay()
        observeStateAndLifecycle()

        binding.cardYoutube.requestFocus()
        handleIncomingIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        viewModel.reloadInstalledApps()
        updateAccessibilityStatusRow()
        MediaStateBus.pollActiveControllerLight()
        if (audioManager.isMusicActive) {
            MediaStateBus.updatePlayingFlag(true)
        }
        if (binding.controlCenterPanel.visibility == View.VISIBLE) {
            refreshControlCenterToggles()
        }
    }

    override fun onDestroy() {
        KeyCaptureBus.isCapturingKey = false
        KeyCaptureBus.onKeyCapturedListener = null
        VolumeHudBus.onVolumeIntercepted = null
        super.onDestroy()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        burnInProtector.onUserInteraction(lifecycleScope)
        silentCleanBackgroundProcesses()
        if (handleIncomingIntent(intent)) {
            return
        }
        closeAllOverlays(restoreFocus = false)
        viewModel.onHomeIntentReceived()
    }

    private fun handleIncomingIntent(intent: Intent?): Boolean {
        if (intent == null) return false
        val action = intent.action
        if (action == Intent.ACTION_ASSIST ||
            action == Intent.ACTION_VOICE_COMMAND ||
            action == Intent.ACTION_SEARCH_LONG_PRESS ||
            intent.getBooleanExtra("EXTRA_OPEN_AI", false)
        ) {
            intent.removeExtra("EXTRA_OPEN_AI")
            closeAllOverlays(restoreFocus = false)
            viewModel.onAssistantTrigger(hasAudioPermission())
            return true
        }
        if (intent.getBooleanExtra("EXTRA_OPEN_ALL_APPS", false)) {
            intent.removeExtra("EXTRA_OPEN_ALL_APPS")
            closeAllOverlays(restoreFocus = false)
            openAppPickerOverlay(assignSlot = null, forKeyBind = false)
            return true
        }
        return false
    }

    private fun setupNowPlayingHoverControls() {
        val npButtons = listOf(
            binding.btnNpPrev to binding.ivNpPrev,
            binding.btnNpPlayPause to binding.ivNpPlayPause,
            binding.btnNpNext to binding.ivNpNext
        )

        npButtons.forEach { (btn, icon) ->
            icon.setColorFilter(getColor(R.color.text_primary), PorterDuff.Mode.SRC_IN)
            btn.setOnFocusChangeListener { _, hasFocus ->
                val tint = if (hasFocus) getColor(R.color.accent_cyan) else getColor(R.color.text_primary)
                icon.setColorFilter(tint, PorterDuff.Mode.SRC_IN)
                if (hasFocus) {
                    binding.llNowPlayingControls.visibility = View.VISIBLE
                }
            }
        }

        binding.btnNpPrev.setOnClickListener {
            MediaStateBus.dispatchTransportAction("PREV", audioManager)
            lifecycleScope.launch {
                delay(300L)
                MediaStateBus.pollActiveControllerLight()
            }
        }

        binding.btnNpPlayPause.setOnClickListener {
            MediaStateBus.dispatchTransportAction("PLAY_PAUSE", audioManager)
            val nowPlaying = MediaStateBus.state.value.isPlaying
            binding.ivNpPlayPause.setImageResource(
                if (nowPlaying) R.drawable.ic_media_pause else R.drawable.ic_media_play
            )
        }

        binding.btnNpNext.setOnClickListener {
            MediaStateBus.dispatchTransportAction("NEXT", audioManager)
            lifecycleScope.launch {
                delay(300L)
                MediaStateBus.pollActiveControllerLight()
            }
        }
    }

    private fun handleCustomVolumeKey(keyCode: Int) {
        try {
            when (keyCode) {
                KeyEvent.KEYCODE_VOLUME_UP -> {
                    audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0)
                }
                KeyEvent.KEYCODE_VOLUME_DOWN -> {
                    audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0)
                }
                KeyEvent.KEYCODE_VOLUME_MUTE -> {
                    audioManager.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, 0)
                }
            }
        } catch (_: Exception) {
        }

        refreshSoundTileState()
        showCustomVolumeHud()
    }

    private fun showCustomVolumeHud() {
        val isMuted = try {
            audioManager.isStreamMute(AudioManager.STREAM_MUSIC)
        } catch (_: Exception) {
            false
        }
        val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val pct = if (isMuted) 0 else ((curVol * 100f) / maxVol).toInt().coerceIn(0, 100)

        binding.tvVolumeHudPct.text = "$pct%"
        val activeColor = getColor(if (pct > 0) R.color.accent_cyan else R.color.status_error)
        binding.tvVolumeHudPct.setTextColor(activeColor)
        binding.ivVolumeHudIcon.setColorFilter(activeColor, PorterDuff.Mode.SRC_IN)

        binding.flVolumeHudTrack.post {
            val totalW = binding.flVolumeHudTrack.width.coerceAtLeast(100)
            val fillW = ((totalW * pct) / 100).coerceAtLeast(if (pct > 0) 6 else 0)
            val lp = binding.vVolumeHudFill.layoutParams
            lp.width = fillW
            binding.vVolumeHudFill.layoutParams = lp
        }

        val hud = binding.volumeHudCard
        if (hud.visibility != View.VISIBLE) {
            hud.alpha = 0f
            hud.visibility = View.VISIBLE
            hud.animate().alpha(1f).setDuration(110L).start()
        } else {
            hud.animate().cancel()
            hud.alpha = 1f
        }

        volumeHudHideJob?.cancel()
        volumeHudHideJob = lifecycleScope.launch {
            delay(1600L)
            hud.animate()
                .alpha(0f)
                .setDuration(180L)
                .withEndAction { hud.visibility = View.GONE }
                .start()
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            burnInProtector.onUserInteraction(lifecycleScope)
        }

        val keyCode = event.keyCode
        val scanCode = event.scanCode

        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
            keyCode == KeyEvent.KEYCODE_VOLUME_DOWN ||
            keyCode == KeyEvent.KEYCODE_VOLUME_MUTE
        ) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                handleCustomVolumeKey(keyCode)
            }
            return true
        }

        if (binding.keyCaptureOverlay.visibility == View.VISIBLE) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
                    stopLiveKeyCapture()
                    binding.remoteKeySelectOverlay.visibility = View.VISIBLE
                    binding.btnKeyCustomListen.requestFocus()
                    return true
                }
                if (!isDpadDirectionKey(keyCode) && !isCenterKey(keyCode)) {
                    onLiveKeyCaught(keyCode, scanCode)
                    return true
                }
            }
            return true
        }

        if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                when {
                    binding.appPickerOverlay.visibility == View.VISIBLE -> {
                        binding.appPickerOverlay.visibility = View.GONE
                        openControlCenter(lastFocusedMainCard)
                    }
                    binding.remoteKeySelectOverlay.visibility == View.VISIBLE -> {
                        binding.remoteKeySelectOverlay.visibility = View.GONE
                        openControlCenter(lastFocusedMainCard)
                    }
                    binding.controlCenterPanel.visibility == View.VISIBLE -> {
                        hideControlCenter(restoreFocus = true)
                    }
                    binding.assistantOverlay.visibility == View.VISIBLE -> {
                        viewModel.closeAssistantOverlay(restoreFocusToAi = true)
                    }
                }
            }
            return true
        }

        // Переход с левых плиток (YouTube / Cast) влево на плеер (с отложенным requestFocus после отрисовки!)
        if (!isAnyOverlayOpen() &&
            keyCode == KeyEvent.KEYCODE_DPAD_LEFT &&
            event.action == KeyEvent.ACTION_DOWN &&
            event.repeatCount == 0 &&
            (currentFocus?.id == R.id.cardYoutube || currentFocus?.id == R.id.cardCast) &&
            binding.nowPlayingCard.visibility == View.VISIBLE
        ) {
            binding.llNowPlayingControls.visibility = View.VISIBLE
            binding.llNowPlayingControls.post {
                binding.btnNpPlayPause.requestFocus()
            }
            return true
        }

        if (keyCode == KeyEvent.KEYCODE_VOICE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_SEARCH
        ) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                val custom = appLauncherDirect.getKeyBinding(keyCode, scanCode)
                if (!custom.isNullOrEmpty()) {
                    executeCustomKeyTarget(custom)
                } else {
                    viewModel.onAssistantTrigger(hasAudioPermission())
                }
            }
            return true
        }

        if (!isDpadDirectionKey(keyCode) && !isCenterKey(keyCode)) {
            val boundTarget = resolveLocalKeyOrPreset(keyCode, scanCode)
            if (!boundTarget.isNullOrEmpty()) {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                    executeCustomKeyTarget(boundTarget)
                }
                return true
            }
        }

        if (keyCode == KeyEvent.KEYCODE_MENU ||
            keyCode == KeyEvent.KEYCODE_ALL_APPS ||
            keyCode == KeyEvent.KEYCODE_GUIDE ||
            keyCode == KeyEvent.KEYCODE_SETTINGS ||
            keyCode == KeyEvent.KEYCODE_TV_INPUT
        ) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                if (binding.controlCenterPanel.visibility == View.VISIBLE) {
                    hideControlCenter(restoreFocus = true)
                } else {
                    openControlCenter(currentFocus)
                }
            }
            return true
        }

        if (!isAnyOverlayOpen() && isCenterKey(keyCode) && isMainGridCardFocused()) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                if (!centerIsDown) {
                    centerIsDown = true
                    centerLongTriggered = false
                    val targetCard = currentFocus
                    centerHoldJob?.cancel()
                    centerHoldJob = lifecycleScope.launch {
                        delay(420L)
                        if (centerIsDown && !centerLongTriggered && !isAnyOverlayOpen()) {
                            centerLongTriggered = true
                            openControlCenter(targetCard)
                        }
                    }
                } else if (event.repeatCount > 0 && !centerLongTriggered && (event.eventTime - event.downTime) >= 380L) {
                    centerLongTriggered = true
                    centerHoldJob?.cancel()
                    openControlCenter(currentFocus)
                }
                return true
            } else if (event.action == KeyEvent.ACTION_UP) {
                centerHoldJob?.cancel()
                val wasLong = centerLongTriggered
                centerIsDown = false
                centerLongTriggered = false
                if (!wasLong && !isAnyOverlayOpen()) {
                    triggerMainCardShortClick(currentFocus)
                }
                return true
            }
        }

        return super.dispatchKeyEvent(event)
    }

    private fun isMainGridCardFocused(): Boolean {
        val id = currentFocus?.id ?: return false
        return id == R.id.cardYoutube ||
            id == R.id.cardBrowser ||
            id == R.id.cardCast ||
            id == R.id.cardAi
    }

    private fun resolveLocalKeyOrPreset(keyCode: Int, scanCode: Int): String? {
        if (keyCode == KeyEvent.KEYCODE_ALL_APPS ||
            keyCode == KeyEvent.KEYCODE_MENU ||
            keyCode == KeyEvent.KEYCODE_GUIDE ||
            keyCode == KeyEvent.KEYCODE_SETTINGS ||
            keyCode == KeyEvent.KEYCODE_TV_INPUT ||
            keyCode == KeyEvent.KEYCODE_BUTTON_1 ||
            scanCode == 139 || scanCode == 362 || scanCode == 172 || scanCode == 256
        ) {
            appLauncherDirect.getPresetBinding("PATCHWALL")?.let { if (it.isNotEmpty()) return it }
        }
        if (keyCode == KeyEvent.KEYCODE_BUTTON_2 || keyCode == KeyEvent.KEYCODE_PROG_RED || scanCode == 412 || scanCode == 398 || keyCode == 309) {
            appLauncherDirect.getPresetBinding("NETFLIX")?.let { if (it.isNotEmpty()) return it }
        }
        if (keyCode == KeyEvent.KEYCODE_BUTTON_3 || keyCode == KeyEvent.KEYCODE_PROG_BLUE || scanCode == 413 || scanCode == 401 || keyCode == 310) {
            appLauncherDirect.getPresetBinding("PRIME")?.let { if (it.isNotEmpty()) return it }
        }
        return appLauncherDirect.getKeyBinding(keyCode, scanCode)
    }

    private fun triggerMainCardShortClick(cardView: View?) {
        when (cardView?.id) {
            R.id.cardYoutube -> viewModel.onSlotCardClicked(CardSlot.SLOT_1)
            R.id.cardBrowser -> viewModel.onSlotCardClicked(CardSlot.SLOT_2)
            R.id.cardCast -> viewModel.onSlotCardClicked(CardSlot.SLOT_3)
            R.id.cardAi -> viewModel.onAssistantTrigger(hasAudioPermission())
        }
    }

    private fun executeCustomKeyTarget(target: String) {
        when (target) {
            "ACTION_ALL_APPS" -> {
                closeAllOverlays(restoreFocus = false)
                openAppPickerOverlay(assignSlot = null, forKeyBind = false)
            }
            "ACTION_SETTINGS" -> {
                closeAllOverlays(restoreFocus = true)
                viewModel.launchSystemSettings()
            }
            "ACTION_AI" -> {
                closeAllOverlays(restoreFocus = false)
                viewModel.onAssistantTrigger(hasAudioPermission())
            }
            else -> {
                closeAllOverlays(restoreFocus = true)
                appLauncherDirect.launchPackage(target)
            }
        }
    }

    private fun setupMainCardsAndCornerPill() {
        val cardPairs = listOf(
            binding.cardYoutube to binding.ivCard1,
            binding.cardBrowser to binding.ivCard2,
            binding.cardCast to binding.ivCard3,
            binding.cardAi to binding.ivCardAi
        )

        cardPairs.forEach { (card, iconView) ->
            val pvhX = PropertyValuesHolder.ofFloat(View.SCALE_X, LauncherConfig.FOCUS_IDLE_SCALE, LauncherConfig.FOCUS_SCALE)
            val pvhY = PropertyValuesHolder.ofFloat(View.SCALE_Y, LauncherConfig.FOCUS_IDLE_SCALE, LauncherConfig.FOCUS_SCALE)
            val animator = ObjectAnimator.ofPropertyValuesHolder(card, pvhX, pvhY).apply {
                duration = LauncherConfig.FOCUS_ANIM_DURATION_MS
                interpolator = decelerateInterpolator
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationStart(animation: Animator) {
                        card.setLayerType(View.LAYER_TYPE_HARDWARE, null)
                    }

                    override fun onAnimationEnd(animation: Animator) {
                        card.setLayerType(View.LAYER_TYPE_NONE, null)
                    }

                    override fun onAnimationCancel(animation: Animator) {
                        card.setLayerType(View.LAYER_TYPE_NONE, null)
                    }
                })
            }
            focusAnimators[card] = animator

            iconView.setColorFilter(getColor(R.color.text_primary), PorterDuff.Mode.SRC_IN)

            card.setOnFocusChangeListener { v, hasFocus ->
                val anim = focusAnimators[v] ?: return@setOnFocusChangeListener
                val iconTint = if (hasFocus) getColor(R.color.accent_cyan) else getColor(R.color.text_primary)
                iconView.setColorFilter(iconTint, PorterDuff.Mode.SRC_IN)
                if (hasFocus) {
                    lastFocusedMainCard = v
                    // Когда фокус перешёл на правые 4 плитки — прячем кнопки управления плеером!
                    binding.llNowPlayingControls.visibility = View.GONE
                    anim.setFloatValues(v.scaleX, LauncherConfig.FOCUS_SCALE)
                    anim.start()
                } else {
                    anim.reverse()
                }
            }
        }

        binding.statusCornerPill.setOnFocusChangeListener { _, hasFocus ->
            if (hasFocus) {
                binding.llNowPlayingControls.visibility = View.GONE
            }
        }

        binding.statusCornerPill.setOnClickListener {
            openControlCenter(lastFocusedMainCard ?: binding.cardYoutube)
        }
    }

    private fun openControlCenter(sourceCard: View?) {
        if (sourceCard != null && isMainGridCardFocused()) {
            lastFocusedMainCard = sourceCard
        }
        val focused = lastFocusedMainCard ?: binding.cardYoutube

        val slot = when (focused.id) {
            R.id.cardYoutube -> CardSlot.SLOT_1
            R.id.cardBrowser -> CardSlot.SLOT_2
            R.id.cardCast -> CardSlot.SLOT_3
            else -> CardSlot.SLOT_1
        }
        activeMenuSlot = slot

        val tileName = when (slot) {
            CardSlot.SLOT_1 -> binding.tvCard1.text.toString()
            CardSlot.SLOT_2 -> binding.tvCard2.text.toString()
            CardSlot.SLOT_3 -> binding.tvCard3.text.toString()
        }

        binding.btnMenuAssignCurrent.text = getString(R.string.menu_assign_current_tile, tileName)
        refreshControlCenterToggles()

        binding.llNowPlayingControls.visibility = View.GONE
        binding.nowPlayingCard.visibility = View.INVISIBLE
        binding.statusCornerPill.visibility = View.INVISIBLE

        val panel = binding.controlCenterPanel
        if (panel.visibility != View.VISIBLE) {
            panel.alpha = 0f
            panel.translationY = 24f * resources.displayMetrics.density
            panel.visibility = View.VISIBLE
            panel.setLayerType(View.LAYER_TYPE_HARDWARE, null)
            panel.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(140L)
                .setInterpolator(decelerateInterpolator)
                .withEndAction {
                    panel.setLayerType(View.LAYER_TYPE_NONE, null)
                }
                .start()
        }
        binding.tileCcWifi.requestFocus()
    }

    private fun hideControlCenter(restoreFocus: Boolean) {
        val panel = binding.controlCenterPanel
        if (panel.visibility == View.VISIBLE) {
            panel.animate().cancel()
            panel.setLayerType(View.LAYER_TYPE_NONE, null)
            panel.visibility = View.GONE
        }
        binding.statusCornerPill.visibility = View.VISIBLE
        renderNowPlayingWidget(MediaStateBus.state.value)

        if (restoreFocus) {
            (lastFocusedMainCard ?: binding.cardYoutube).requestFocus()
        }
    }

    private fun setupControlCenterPanel() {
        binding.tileCcWifi.setOnClickListener {
            toggleWifiDirectly()
        }
        binding.tileCcWifi.setOnLongClickListener {
            hideControlCenter(restoreFocus = true)
            openSettingsIntent(Settings.ACTION_WIFI_SETTINGS)
            true
        }

        binding.tileCcBluetooth.setOnClickListener {
            hideControlCenter(restoreFocus = true)
            openSettingsIntent(Settings.ACTION_BLUETOOTH_SETTINGS)
        }
        binding.tileCcBluetooth.setOnLongClickListener {
            toggleBluetoothDirectly()
            true
        }

        binding.tileCcSound.setOnClickListener {
            try {
                audioManager.adjustStreamVolume(
                    AudioManager.STREAM_MUSIC,
                    AudioManager.ADJUST_TOGGLE_MUTE,
                    0
                )
            } catch (_: Exception) {
            }
            refreshSoundTileState()
            showCustomVolumeHud()
        }

        binding.tileCcBoost.setOnClickListener {
            silentCleanBackgroundProcesses()
            binding.tileCcBoost.setBackgroundResource(R.drawable.bg_cc_toggle_active)
            binding.ivCcBoost.setColorFilter(getColor(R.color.accent_cyan), PorterDuff.Mode.SRC_IN)
            binding.tvCcBoostState.text = "OK"
            binding.tvCcBoostState.setTextColor(getColor(R.color.accent_cyan))
            Toast.makeText(this, R.string.toast_boost_done, Toast.LENGTH_SHORT).show()
        }

        binding.btnMenuAllApps.setOnClickListener {
            hideControlCenter(restoreFocus = false)
            openAppPickerOverlay(assignSlot = null, forKeyBind = false)
        }

        binding.btnMenuAssignCurrent.setOnClickListener {
            val slot = activeMenuSlot ?: CardSlot.SLOT_1
            hideControlCenter(restoreFocus = false)
            openAppPickerOverlay(assignSlot = slot, forKeyBind = false)
        }

        binding.btnMenuBindKey.setOnClickListener {
            hideControlCenter(restoreFocus = false)
            updateAccessibilityStatusRow()
            binding.remoteKeySelectOverlay.visibility = View.VISIBLE
            if (isAccessibilityMapperEnabled()) {
                binding.btnKeyPresetPatchwall.requestFocus()
            } else {
                binding.btnKeyEnableAccessibility.requestFocus()
            }
        }

        binding.btnMenuSystemSettings.setOnClickListener {
            hideControlCenter(restoreFocus = true)
            viewModel.launchSystemSettings()
        }
    }

    private fun toggleWifiDirectly() {
        val wm = wifiManager
        if (wm == null) {
            openSettingsIntent(Settings.ACTION_WIFI_SETTINGS)
            return
        }
        val targetState = !wm.isWifiEnabled
        @Suppress("DEPRECATION")
        val changed = try {
            wm.setWifiEnabled(targetState)
        } catch (_: Exception) {
            false
        }
        if (!changed) {
            hideControlCenter(restoreFocus = true)
            openSettingsIntent(Settings.ACTION_WIFI_SETTINGS)
        } else {
            lifecycleScope.launch {
                delay(350L)
                refreshControlCenterToggles()
            }
        }
    }

    private fun toggleBluetoothDirectly() {
        try {
            @Suppress("DEPRECATION")
            val adapter = BluetoothAdapter.getDefaultAdapter()
            if (adapter != null) {
                @Suppress("MissingPermission", "DEPRECATION")
                if (adapter.isEnabled) adapter.disable() else adapter.enable()
                lifecycleScope.launch {
                    delay(400L)
                    refreshControlCenterToggles()
                }
            }
        } catch (_: Exception) {
            openSettingsIntent(Settings.ACTION_BLUETOOTH_SETTINGS)
        }
    }

    private fun refreshControlCenterToggles() {
        val wifiEnabled = try {
            wifiManager?.isWifiEnabled == true
        } catch (_: Exception) {
            true
        }
        binding.tileCcWifi.setBackgroundResource(
            if (wifiEnabled) R.drawable.bg_cc_toggle_active else R.drawable.bg_cc_toggle_inactive
        )
        binding.tvCcWifiState.text = getString(if (wifiEnabled) R.string.cc_state_on else R.string.cc_state_off)
        binding.tvCcWifiState.setTextColor(getColor(if (wifiEnabled) R.color.accent_cyan else R.color.text_secondary))

        val btEnabled = try {
            @Suppress("DEPRECATION", "MissingPermission")
            BluetoothAdapter.getDefaultAdapter()?.isEnabled == true
        } catch (_: Exception) {
            true
        }
        binding.tileCcBluetooth.setBackgroundResource(
            if (btEnabled) R.drawable.bg_cc_toggle_active else R.drawable.bg_cc_toggle_inactive
        )
        binding.ivCcBt.setColorFilter(
            getColor(if (btEnabled) R.color.accent_cyan else R.color.text_secondary),
            PorterDuff.Mode.SRC_IN
        )
        binding.tvCcBtState.text = getString(if (btEnabled) R.string.cc_state_on else R.string.cc_state_off)
        binding.tvCcBtState.setTextColor(getColor(if (btEnabled) R.color.accent_cyan else R.color.text_secondary))

        refreshSoundTileState()

        binding.tileCcBoost.setBackgroundResource(R.drawable.bg_cc_toggle_inactive)
        binding.ivCcBoost.setColorFilter(getColor(R.color.accent_cyan), PorterDuff.Mode.SRC_IN)
        binding.tvCcBoostState.text = getString(R.string.cc_state_ready)
        binding.tvCcBoostState.setTextColor(getColor(R.color.text_secondary))
    }

    private fun refreshSoundTileState() {
        val isMuted = try {
            audioManager.isStreamMute(AudioManager.STREAM_MUSIC)
        } catch (_: Exception) {
            false
        }
        val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        val curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val pct = ((curVol * 100f) / maxVol).toInt().coerceIn(0, 100)
        val soundActive = !isMuted && pct > 0
        binding.tileCcSound.setBackgroundResource(
            if (soundActive) R.drawable.bg_cc_toggle_active else R.drawable.bg_cc_toggle_inactive
        )
        binding.ivCcSound.setColorFilter(
            getColor(if (soundActive) R.color.accent_cyan else R.color.text_secondary),
            PorterDuff.Mode.SRC_IN
        )
        binding.tvCcSoundState.text = if (isMuted || pct == 0) getString(R.string.cc_state_muted) else "$pct%"
        binding.tvCcSoundState.setTextColor(getColor(if (soundActive) R.color.accent_cyan else R.color.text_secondary))
    }

    private fun silentCleanBackgroundProcesses() {
        lifecycleScope.launch(Dispatchers.IO) {
            try {
                val am = getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return@launch
                val activeMusicPkg = MediaStateBus.state.value.sourcePackage
                val apps = viewModel.uiState.value.installedApps
                for (app in apps) {
                    val pkg = app.packageName
                    if (pkg != packageName && pkg != activeMusicPkg) {
                        am.killBackgroundProcesses(pkg)
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    private fun openSettingsIntent(action: String) {
        val intent = Intent(action).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        try {
            startActivity(intent)
        } catch (_: Exception) {
            viewModel.launchSystemSettings()
        }
    }

    /**
     * Плеер остаётся видимым на паузе (пока активна медиа-сессия), меняя только значок || на ▶!
     */
    private fun renderNowPlayingWidget(snapshot: NowPlayingSnapshot) {
        if (binding.controlCenterPanel.visibility == View.VISIBLE) {
            binding.nowPlayingCard.visibility = View.INVISIBLE
            return
        }

        if (!snapshot.hasActiveSession) {
            binding.llNowPlayingControls.visibility = View.GONE
            binding.nowPlayingCard.visibility = View.GONE
            return
        }

        if (binding.nowPlayingCard.visibility != View.VISIBLE) {
            binding.nowPlayingCard.alpha = 0f
            binding.nowPlayingCard.visibility = View.VISIBLE
            binding.nowPlayingCard.animate().alpha(1f).setDuration(160L).start()
        }

        binding.tvNowPlayingTitle.text = snapshot.title.ifEmpty {
            getString(R.string.now_playing_active_generic)
        }
        binding.tvNowPlayingArtist.text = snapshot.artist.ifEmpty { snapshot.sourceAppName }

        binding.ivNpPlayPause.setImageResource(
            if (snapshot.isPlaying) R.drawable.ic_media_pause else R.drawable.ic_media_play
        )

        if (snapshot.coverBitmap != null) {
            binding.ivNowPlayingArt.setPadding(0, 0, 0, 0)
            binding.ivNowPlayingArt.clearColorFilter()
            binding.ivNowPlayingArt.setImageBitmap(snapshot.coverBitmap)
        } else {
            val pad = (10 * resources.displayMetrics.density).toInt()
            binding.ivNowPlayingArt.setPadding(pad, pad, pad, pad)
            if (snapshot.sourcePackage.isNotEmpty()) {
                binding.ivNowPlayingArt.setImageDrawable(
                    iconStylizer.getStylizedIcon(snapshot.sourcePackage, snapshot.sourceAppName)
                )
            } else {
                binding.ivNowPlayingArt.setImageResource(R.drawable.ic_music_64)
            }
            binding.ivNowPlayingArt.setColorFilter(getColor(R.color.accent_cyan), PorterDuff.Mode.SRC_IN)
        }

        updateLiveTrackProgressTick()
    }

    private fun updateLiveTrackProgressTick() {
        val snap = MediaStateBus.state.value
        if (!snap.hasActiveSession || binding.nowPlayingCard.visibility != View.VISIBLE) return

        val (posMs, durMs) = MediaStateBus.getLivePositionAndDuration()
        val posSec = (posMs / 1000L).coerceAtLeast(0L)
        val posFormatted = String.format("%02d:%02d", posSec / 60, posSec % 60)

        if (durMs > 0L) {
            val durSec = (durMs / 1000L).coerceAtLeast(1L)
            val durFormatted = String.format("%02d:%02d", durSec / 60, durSec % 60)
            binding.tvNowPlayingTime.text = "$posFormatted / $durFormatted"
        } else {
            binding.tvNowPlayingTime.text = posFormatted
        }

        val trackW = binding.flNowPlayingProgressTrack.width
        if (trackW > 0) {
            val ratio = if (durMs > 0L) {
                (posMs.toFloat() / durMs.toFloat()).coerceIn(0.04f, 1.0f)
            } else {
                val cycle = (posSec % 180L).toFloat() / 180f
                cycle.coerceIn(0.06f, 1.0f)
            }
            val fillW = (trackW * ratio).toInt().coerceAtLeast(6)
            val lp = binding.vNowPlayingVisualizer.layoutParams
            if (lp.width != fillW) {
                lp.width = fillW
                binding.vNowPlayingVisualizer.layoutParams = lp
            }
        }
    }

    private fun setupRemoteKeySelectOverlay() {
        binding.btnKeyEnableAccessibility.setOnClickListener {
            appLauncherDirect.launchAccessibilitySettings()
        }

        binding.btnKeyPresetPatchwall.setOnClickListener {
            pendingPresetId = "PATCHWALL"
            pendingKeyDisplayName = "9 квадратиков"
            capturedKeyCode = 0
            capturedScanCode = 0
            binding.remoteKeySelectOverlay.visibility = View.GONE
            openAppPickerOverlay(assignSlot = null, forKeyBind = true)
        }

        binding.btnKeyPresetNetflix.setOnClickListener {
            pendingPresetId = "NETFLIX"
            pendingKeyDisplayName = "NETFLIX"
            capturedKeyCode = 0
            capturedScanCode = 0
            binding.remoteKeySelectOverlay.visibility = View.GONE
            openAppPickerOverlay(assignSlot = null, forKeyBind = true)
        }

        binding.btnKeyPresetPrime.setOnClickListener {
            pendingPresetId = "PRIME"
            pendingKeyDisplayName = "prime video"
            capturedKeyCode = 0
            capturedScanCode = 0
            binding.remoteKeySelectOverlay.visibility = View.GONE
            openAppPickerOverlay(assignSlot = null, forKeyBind = true)
        }

        binding.btnKeyCustomListen.setOnClickListener {
            binding.remoteKeySelectOverlay.visibility = View.GONE
            startLiveKeyCapture()
        }
    }

    private fun startLiveKeyCapture() {
        pendingPresetId = null
        binding.keyCaptureOverlay.visibility = View.VISIBLE
        KeyCaptureBus.onKeyCapturedListener = { keyCode, scanCode ->
            onLiveKeyCaught(keyCode, scanCode)
        }
        KeyCaptureBus.isCapturingKey = true
    }

    private fun stopLiveKeyCapture() {
        KeyCaptureBus.isCapturingKey = false
        KeyCaptureBus.onKeyCapturedListener = null
        binding.keyCaptureOverlay.visibility = View.GONE
    }

    private fun onLiveKeyCaught(keyCode: Int, scanCode: Int) {
        stopLiveKeyCapture()
        pendingPresetId = null
        capturedKeyCode = keyCode
        capturedScanCode = scanCode
        pendingKeyDisplayName = "Key #$keyCode (Scan #$scanCode)"
        openAppPickerOverlay(assignSlot = null, forKeyBind = true)
    }

    private fun updateAccessibilityStatusRow() {
        val enabled = isAccessibilityMapperEnabled()
        if (enabled) {
            binding.btnKeyEnableAccessibility.text = getString(R.string.key_service_status_on)
            binding.btnKeyEnableAccessibility.setTextColor(getColor(R.color.accent_cyan))
        } else {
            binding.btnKeyEnableAccessibility.text = getString(R.string.key_service_status_off)
            binding.btnKeyEnableAccessibility.setTextColor(getColor(R.color.status_error))
        }
    }

    private fun isAccessibilityMapperEnabled(): Boolean {
        return try {
            val enabledServices = Settings.Secure.getString(
                contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            enabledServices.contains(packageName)
        } catch (_: Exception) {
            false
        }
    }

    private fun openAppPickerOverlay(assignSlot: CardSlot?, forKeyBind: Boolean) {
        val apps = viewModel.uiState.value.installedApps
        binding.tvPickerTitle.text = when {
            forKeyBind -> getString(R.string.picker_title_key_bind, pendingKeyDisplayName)
            assignSlot != null -> getString(R.string.picker_title_assign, apps.size)
            else -> getString(R.string.picker_title_launch, apps.size)
        }

        val container = binding.llAppListContainer
        container.removeAllViews()

        val dp = resources.displayMetrics.density
        val pad = (14 * dp).toInt()
        val iconPx = (44 * dp).toInt()
        val gap = (10 * dp).toInt()

        var firstFocusable: View? = null

        if (forKeyBind) {
            val specialActions = listOf(
                "ACTION_ALL_APPS" to getString(R.string.action_open_all_apps),
                "ACTION_SETTINGS" to getString(R.string.action_open_tv_settings),
                "ACTION_AI" to getString(R.string.action_open_ai_assistant),
                "" to getString(R.string.action_clear_binding)
            )
            specialActions.forEach { (actionCode, actionTitle) ->
                val row = createActionRow(actionTitle, dp) {
                    applyKeyOrPresetBinding(actionCode.ifEmpty { null }, actionTitle)
                }
                container.addView(row)
                if (firstFocusable == null) firstFocusable = row
            }
        }

        val columns = 4
        val chunked = apps.chunked(columns)
        chunked.forEach { rowApps ->
            val rowLayout = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                weightSum = columns.toFloat()
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    bottomMargin = gap
                }
            }

            for (col in 0 until columns) {
                val app = rowApps.getOrNull(col)
                if (app != null) {
                    val tile = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                        gravity = Gravity.CENTER
                        background = ContextCompat.getDrawable(this@LauncherActivity, R.drawable.bg_card_selector)
                        isFocusable = true
                        isClickable = true
                        isFocusableInTouchMode = false
                        setDefaultFocusHighlightEnabled(false)
                        setPadding(pad, pad, pad, pad)
                        layoutParams = LinearLayout.LayoutParams(
                            0,
                            (112 * dp).toInt(),
                            1f
                        ).apply {
                            if (col < columns - 1) marginEnd = gap
                        }
                    }

                    val iconView = ImageView(this).apply {
                        layoutParams = LinearLayout.LayoutParams(iconPx, iconPx)
                        scaleType = ImageView.ScaleType.FIT_CENTER
                        setImageDrawable(iconStylizer.getStylizedIcon(app.packageName, app.label))
                        setColorFilter(getColor(R.color.text_primary), PorterDuff.Mode.SRC_IN)
                    }

                    val titleView = TextView(this).apply {
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply {
                            topMargin = (8 * dp).toInt()
                        }
                        gravity = Gravity.CENTER
                        text = app.label
                        setTextColor(getColor(R.color.text_primary))
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                        maxLines = 1
                        ellipsize = TextUtils.TruncateAt.END
                    }

                    tile.setOnFocusChangeListener { _, hasFocus ->
                        val tint = if (hasFocus) getColor(R.color.accent_cyan) else getColor(R.color.text_primary)
                        iconView.setColorFilter(tint, PorterDuff.Mode.SRC_IN)
                        titleView.setTextColor(tint)
                    }

                    tile.setOnClickListener {
                        when {
                            forKeyBind -> applyKeyOrPresetBinding(app.packageName, app.label)
                            assignSlot != null -> {
                                viewModel.assignAppToSlot(assignSlot, app)
                                closeAllOverlays(restoreFocus = true)
                            }
                            else -> {
                                closeAllOverlays(restoreFocus = true)
                                viewModel.launchAppDirectly(app)
                            }
                        }
                    }

                    tile.addView(iconView)
                    tile.addView(titleView)
                    rowLayout.addView(tile)
                    if (firstFocusable == null) firstFocusable = tile
                } else {
                    val spacer = View(this).apply {
                        layoutParams = LinearLayout.LayoutParams(0, 1, 1f).apply {
                            if (col < columns - 1) marginEnd = gap
                        }
                    }
                    rowLayout.addView(spacer)
                }
            }
            container.addView(rowLayout)
        }

        binding.appPickerOverlay.visibility = View.VISIBLE
        firstFocusable?.requestFocus()
    }

    private fun createActionRow(title: String, dp: Float, onClick: () -> Unit): View {
        return TextView(this).apply {
            text = title
            setTextColor(getColor(R.color.text_primary))
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            background = ContextCompat.getDrawable(this@LauncherActivity, R.drawable.bg_menu_item_selector)
            isFocusable = true
            isClickable = true
            isFocusableInTouchMode = false
            setDefaultFocusHighlightEnabled(false)
            val pad = (14 * dp).toInt()
            setPadding(pad, pad, pad, pad)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                bottomMargin = (8 * dp).toInt()
            }
            setOnFocusChangeListener { _, hasFocus ->
                setTextColor(if (hasFocus) getColor(R.color.accent_cyan) else getColor(R.color.text_primary))
            }
            setOnClickListener { onClick() }
        }
    }

    private fun applyKeyOrPresetBinding(targetValue: String?, targetLabel: String) {
        val preset = pendingPresetId
        if (preset != null) {
            appLauncherDirect.savePresetBinding(preset, targetValue)
        } else {
            appLauncherDirect.saveKeyBinding(capturedKeyCode, capturedScanCode, targetValue)
        }
        Toast.makeText(
            this,
            getString(R.string.toast_key_bound, pendingKeyDisplayName, targetLabel),
            Toast.LENGTH_SHORT
        ).show()
        closeAllOverlays(restoreFocus = true)
    }

    private fun observeStateAndLifecycle() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                burnInProtector.onUserInteraction(this)

                val filter = IntentFilter().apply {
                    addAction(Intent.ACTION_TIME_CHANGED)
                    addAction(Intent.ACTION_TIMEZONE_CHANGED)
                    addAction(Intent.ACTION_LOCALE_CHANGED)
                }
                ContextCompat.registerReceiver(
                    this@LauncherActivity,
                    timeChangeReceiver,
                    filter,
                    ContextCompat.RECEIVER_EXPORTED
                )

                val volFilter = IntentFilter("android.media.VOLUME_CHANGED_ACTION")
                ContextCompat.registerReceiver(
                    this@LauncherActivity,
                    volumeChangeReceiver,
                    volFilter,
                    ContextCompat.RECEIVER_EXPORTED
                )

                val mediaFilter = IntentFilter().apply {
                    addAction("com.android.music.metachanged")
                    addAction("com.android.music.playstatechanged")
                    addAction("com.spotify.music.metadatachanged")
                    addAction("com.spotify.music.playbackstatechanged")
                }
                ContextCompat.registerReceiver(
                    this@LauncherActivity,
                    mediaBroadcastReceiver,
                    mediaFilter,
                    ContextCompat.RECEIVER_EXPORTED
                )

                // Единый лёгкий секундный цикл (без пережатия Bitmap каждую секунду!)
                launch {
                    while (isActive) {
                        viewModel.refreshTimeAndDate()
                        MediaStateBus.pollActiveControllerLight()
                        if (audioManager.isMusicActive && !MediaStateBus.state.value.isPlaying) {
                            MediaStateBus.updatePlayingFlag(true)
                        }
                        updateLiveTrackProgressTick()
                        delay(ClockFormatter.computeDelayToNextSecond(System.currentTimeMillis()))
                    }
                }

                launch {
                    MediaStateBus.state.collect { snapshot ->
                        renderNowPlayingWidget(snapshot)
                    }
                }

                launch {
                    viewModel.observeNetworkInForeground().collect { netStatus ->
                        viewModel.updateNetworkStatus(netStatus)
                    }
                }

                launch {
                    viewModel.uiState.collect { state ->
                        binding.tvClock.text = state.timeText
                        binding.tvDate.text = state.dateText
                        renderSlotCard(state.slot1App, binding.ivCard1, binding.tvCard1, binding.cardYoutube, R.string.card_slot_1_default)
                        renderSlotCard(state.slot2App, binding.ivCard2, binding.tvCard2, binding.cardBrowser, R.string.card_slot_2_default)
                        renderSlotCard(state.slot3App, binding.ivCard3, binding.tvCard3, binding.cardCast, R.string.card_slot_3_default)
                        renderNetworkCornerIcon(state.networkStatus)
                        renderAssistantState(state.assistantState, state.isOverlayVisible)
                    }
                }

                launch {
                    viewModel.events.collect { event ->
                        when (event) {
                            is LauncherUiEvent.ShowToastRes -> {
                                Toast.makeText(this@LauncherActivity, event.stringResId, Toast.LENGTH_SHORT).show()
                            }
                            is LauncherUiEvent.ShowBoundToast -> {
                                Toast.makeText(
                                    this@LauncherActivity,
                                    getString(R.string.toast_app_bound, event.appLabel),
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                            is LauncherUiEvent.OpenAppAssignPicker -> {
                                lastFocusedMainCard = currentFocus
                                openAppPickerOverlay(assignSlot = event.slot, forKeyBind = false)
                            }
                            LauncherUiEvent.RequestAudioPermission -> {
                                audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                            LauncherUiEvent.RestoreFocusToAiCard -> {
                                binding.cardAi.requestFocus()
                            }
                            LauncherUiEvent.RestoreFocusToYoutubeCard -> {
                                binding.cardYoutube.requestFocus()
                            }
                        }
                    }
                }

                try {
                    awaitCancellation()
                } finally {
                    unregisterReceiver(timeChangeReceiver)
                    unregisterReceiver(volumeChangeReceiver)
                    unregisterReceiver(mediaBroadcastReceiver)
                    burnInProtector.stop()
                }
            }
        }
    }

    private fun renderSlotCard(
        appInfo: InstalledAppInfo?,
        iconView: ImageView,
        titleView: TextView,
        cardView: View,
        defaultTitleRes: Int
    ) {
        if (appInfo != null) {
            titleView.text = appInfo.label
            cardView.contentDescription = appInfo.label
            iconView.setImageDrawable(iconStylizer.getStylizedIcon(appInfo.packageName, appInfo.label))
        } else {
            titleView.text = getString(defaultTitleRes)
            iconView.setImageResource(R.drawable.ic_grid_apps_64)
        }
        val tintColor = if (cardView.hasFocus()) getColor(R.color.accent_cyan) else getColor(R.color.text_primary)
        iconView.setColorFilter(tintColor, PorterDuff.Mode.SRC_IN)
    }

    private fun renderNetworkCornerIcon(status: NetworkStatus) {
        val resId = when (status) {
            is NetworkStatus.Wifi -> when {
                status.level >= 4 -> R.drawable.ic_wifi_neon_4
                status.level == 3 -> R.drawable.ic_wifi_neon_3
                status.level == 2 -> R.drawable.ic_wifi_neon_2
                else -> R.drawable.ic_wifi_neon_1
            }
            NetworkStatus.Ethernet -> R.drawable.ic_wifi_neon_4
            NetworkStatus.Disconnected -> R.drawable.ic_wifi_off
        }
        binding.ivWifiCorner.setImageResource(resId)
        binding.ivCcWifi.setImageResource(resId)
    }

    private fun renderAssistantState(aiState: AssistantState, isOverlayVisible: Boolean) {
        binding.assistantOverlay.visibility = if (isOverlayVisible) View.VISIBLE else View.GONE
        if (isOverlayVisible) {
            binding.assistantOverlay.requestFocus()
        }

        when (aiState) {
            AssistantState.Idle -> {}
            AssistantState.Listening -> {
                binding.tvOverlayTitle.text = getString(R.string.overlay_title_listening)
            }
            AssistantState.Processing -> {
                binding.tvOverlayTitle.text = getString(R.string.overlay_title_processing)
            }
            is AssistantState.Result -> {
                binding.tvOverlayTitle.text = getString(R.string.overlay_title_result)
                binding.tvOverlayBody.text = aiState.text
            }
            is AssistantState.Error -> {
                binding.tvOverlayTitle.text = getString(R.string.overlay_title_error)
            }
        }
    }

    private fun isAnyOverlayOpen(): Boolean {
        return binding.controlCenterPanel.visibility == View.VISIBLE ||
            binding.remoteKeySelectOverlay.visibility == View.VISIBLE ||
            binding.keyCaptureOverlay.visibility == View.VISIBLE ||
            binding.appPickerOverlay.visibility == View.VISIBLE ||
            binding.assistantOverlay.visibility == View.VISIBLE
    }

    private fun closeAllOverlays(restoreFocus: Boolean) {
        stopLiveKeyCapture()
        hideControlCenter(restoreFocus = false)
        binding.remoteKeySelectOverlay.visibility = View.GONE
        binding.appPickerOverlay.visibility = View.GONE
        if (binding.assistantOverlay.visibility == View.VISIBLE) {
            viewModel.closeAssistantOverlay(restoreFocusToAi = false)
        }
        if (restoreFocus) {
            (lastFocusedMainCard ?: binding.cardYoutube).requestFocus()
        }
    }

    private fun isCenterKey(keyCode: Int): Boolean {
        return keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
            keyCode == KeyEvent.KEYCODE_ENTER ||
            keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER ||
            keyCode == KeyEvent.KEYCODE_BUTTON_SELECT ||
            keyCode == KeyEvent.KEYCODE_BUTTON_A
    }

    private fun isDpadDirectionKey(keyCode: Int): Boolean {
        return keyCode == KeyEvent.KEYCODE_DPAD_UP ||
            keyCode == KeyEvent.KEYCODE_DPAD_DOWN ||
            keyCode == KeyEvent.KEYCODE_DPAD_LEFT ||
            keyCode == KeyEvent.KEYCODE_DPAD_RIGHT
    }

    private fun hasAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }
}
