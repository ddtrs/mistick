package com.mitv.customlauncher.ui

import android.animation.ValueAnimator
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.drawable.Drawable
import android.view.animation.DecelerateInterpolator

/**
 * Кольцо прогресса по контуру капсулы. Старт: верхний центр, направление: по часовой стрелке.
 * Рисуется поверх капсулы (View.foreground или ImageView), сам фон капсулы не трогает.
 */
class VolumeRingDrawable(private val strokePx: Float) : Drawable() {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeWidth = strokePx
    }
    private val path = Path()
    private val segment = Path()
    private val measure = PathMeasure()
    private var pathLength = 0f
    private var lastW = -1
    private var lastH = -1

    private var progress = 0f
    private var ringAlpha = 0f
    private var progressAnim: ValueAnimator? = null
    private var alphaAnim: ValueAnimator? = null

    var color: Int = 0xFF00F0FF.toInt()
        set(value) {
            field = value
            invalidateSelf()
        }

    private fun rebuildPath() {
        val b = bounds
        if (b.width() == lastW && b.height() == lastH) return
        lastW = b.width()
        lastH = b.height()
        val half = strokePx / 2f
        val l = b.left + half
        val t = b.top + half
        val r = b.right - half
        val btm = b.bottom - half
        val rad = (btm - t) / 2f
        val cx = (l + r) / 2f
        path.reset()
        path.moveTo(cx, t)
        path.lineTo(r - rad, t)
        path.arcTo(RectF(r - 2 * rad, t, r, btm), -90f, 180f)
        path.lineTo(l + rad, btm)
        path.arcTo(RectF(l, t, l + 2 * rad, btm), 90f, 180f)
        path.lineTo(cx, t)
        measure.setPath(path, false)
        pathLength = measure.length
    }

    override fun draw(canvas: Canvas) {
        if (ringAlpha <= 0.01f || progress <= 0.001f) return
        rebuildPath()
        if (pathLength <= 0f) return
        segment.reset()
        measure.getSegment(0f, pathLength * progress.coerceIn(0f, 1f), segment, true)
        paint.color = color
        paint.alpha = (255 * ringAlpha).toInt().coerceIn(0, 255)
        canvas.drawPath(segment, paint)
    }

    fun setProgress(target: Float, animate: Boolean = true) {
        val to = target.coerceIn(0f, 1f)
        progressAnim?.cancel()
        if (!animate) {
            progress = to
            invalidateSelf()
            return
        }
        progressAnim = ValueAnimator.ofFloat(progress, to).apply {
            duration = 160L
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                progress = it.animatedValue as Float
                invalidateSelf()
            }
            start()
        }
    }

    fun fadeTo(visible: Boolean) {
        alphaAnim?.cancel()
        alphaAnim = ValueAnimator.ofFloat(ringAlpha, if (visible) 1f else 0f).apply {
            duration = if (visible) 120L else 220L
            addUpdateListener {
                ringAlpha = it.animatedValue as Float
                invalidateSelf()
            }
            start()
        }
    }

    fun reset() {
        progressAnim?.cancel()
        alphaAnim?.cancel()
        progress = 0f
        ringAlpha = 0f
        invalidateSelf()
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity(): Int = PixelFormat.TRANSLUCENT
}
