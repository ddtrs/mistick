package com.mitv.customlauncher.data

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ClockFormatter {
    fun formatTime24(epochMillis: Long, locale: Locale = Locale.getDefault()): String {
        val sdf = SimpleDateFormat("HH:mm:ss", locale)
        return sdf.format(Date(epochMillis))
    }

    fun formatDate(epochMillis: Long, locale: Locale = Locale.getDefault()): String {
        val sdf = SimpleDateFormat("EEEE, d MMMM", locale)
        return sdf.format(Date(epochMillis))
    }

    fun computeDelayToNextSecond(nowMillis: Long): Long {
        val remainder = nowMillis % 1000L
        return if (remainder == 0L) 1000L else 1000L - remainder
    }
}
