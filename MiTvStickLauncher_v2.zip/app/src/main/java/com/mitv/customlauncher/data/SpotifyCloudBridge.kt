package com.mitv.customlauncher.data

import android.app.ActivityManager
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.isActive
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import android.graphics.Color
import kotlinx.coroutines.delay
import java.nio.ByteOrder
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import kotlin.math.sqrt
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.speech.tts.TextToSpeech
import com.mitv.customlauncher.service.DynamicIslandBus
import com.mitv.customlauncher.service.RemoteConsoleServer
import com.mitv.customlauncher.service.ShellKeyController
import android.util.Base64
import android.util.Log
import android.widget.Toast
import android.view.KeyEvent
import com.mitv.customlauncher.service.TvUiControllerBus
import com.mitv.customlauncher.service.MediaStateBus
import com.mitv.customlauncher.service.NavSoundPlayer
import com.mitv.customlauncher.service.VolumeHudBus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


/**
 * Долгосрочная энергонезависимая память ИИ (0 МБ фонового потребления ОЗУ):
 * хранит заметки, факты, коды и привычки пользователя в SharedPreferences и передаёт их в промпт Gemini.
 */
object SpotifyCloudBridge {
    private const val PREF_SPOTIFY_LINKED = "pref_spotify_cloud_linked_v89"
    private const val PREF_SPOTIFY_REFRESH_TOKEN = "pref_spotify_refresh_token_v91"
    private const val PREF_ECHO_PLAYLISTS_JSON = "pref_echo_playlists_v89"
    private const val PREF_ECHO_LIKED_JSON = "pref_echo_liked_tracks_v89"
    private const val PREF_ECHO_PLAYLIST_URIS_JSON = "pref_echo_playlist_uris_v89"
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    @Volatile
    var upNextTrackText: String = ""

    @Volatile
    private var lastQueueSeedTitle: String = ""

    @Volatile
    private var lastQueueFetchMs: Long = 0L

    fun fetchNextTrackInQueueIfNeeded(context: Context, currentTitle: String) {
        val cleanTitle = currentTitle.trim()
        if (cleanTitle.isEmpty()) {
            upNextTrackText = ""
            lastQueueSeedTitle = ""
            return
        }
        val now = SystemClock.elapsedRealtime()
        if (cleanTitle == lastQueueSeedTitle && now - lastQueueFetchMs < 45_000L) {
            return
        }
        lastQueueSeedTitle = cleanTitle
        lastQueueFetchMs = now
        upNextTrackText = ""
        val appCtx = context.applicationContext
        val devId = getDeviceId(appCtx)
        ioScope.launch {
            try {
                val conn = (URL("${LauncherConfig.CLOUDFLARE_GATEWAY_URL}/spotify/action").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 2500
                    readTimeout = 2800
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("x-app-secret", LauncherConfig.GATEWAY_APP_SECRET)
                }
                val payload = JSONObject().apply {
                    put("device_id", devId)
                    val savedRt = getSavedRefreshToken(appCtx)
                    if (savedRt.isNotEmpty()) put("refresh_token", savedRt)
                    put("action", "GET_QUEUE")
                }.toString()
                conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                if (conn.responseCode == 200) {
                    val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                    val nextLabel = json.optString("nextLabel", "").trim()
                    if (cleanTitle == lastQueueSeedTitle) {
                        upNextTrackText = nextLabel
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    fun getDeviceId(context: Context): String {
        val raw = try {
            Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "mitv_stick"
        } catch (_: Exception) {
            "mitv_stick"
        }
        return raw.take(16).ifEmpty { "mitv_stick" }
    }

    fun getSpotifyAuthUrl(context: Context): String {
        val devId = getDeviceId(context)
        return "${LauncherConfig.CLOUDFLARE_GATEWAY_URL}/auth/spotify/start?device_id=${Uri.encode(devId)}"
    }

    fun getSavedRefreshToken(context: Context): String {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getString(PREF_SPOTIFY_REFRESH_TOKEN, "").orEmpty().trim()
    }

    private fun saveRefreshToken(context: Context, refreshToken: String) {
        val clean = refreshToken.trim()
        if (clean.isEmpty()) return
        context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(PREF_SPOTIFY_REFRESH_TOKEN, clean)
            .putBoolean(PREF_SPOTIFY_LINKED, true)
            .apply()
    }

    fun isCloudLinkedCached(context: Context): Boolean {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        return prefs.getBoolean(PREF_SPOTIFY_LINKED, false) || getSavedRefreshToken(context).isNotEmpty()
    }

    fun checkCloudLinkStatusAsync(context: Context, onResult: ((Boolean) -> Unit)? = null) {
        val appCtx = context.applicationContext
        val devId = getDeviceId(appCtx)
        ioScope.launch {
            var linked = false
            try {
                val url = "${LauncherConfig.CLOUDFLARE_GATEWAY_URL}/auth/spotify/status?device_id=${Uri.encode(devId)}"
                val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 2800
                    readTimeout = 3000
                    setRequestProperty("x-app-secret", LauncherConfig.GATEWAY_APP_SECRET)
                }
                if (conn.responseCode == 200) {
                    val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                    linked = json.optBoolean("linked", false)
                    val rt = json.optString("refresh_token", "").trim()
                    if (linked && rt.isNotEmpty()) {
                        saveRefreshToken(appCtx, rt)
                    } else if (!linked) {
                        val savedRt = getSavedRefreshToken(appCtx)
                        if (savedRt.isNotEmpty()) {
                            linked = restoreSessionWithRefreshTokenBlocking(appCtx, devId, savedRt)
                        }
                    }
                    appCtx.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
                        .edit().putBoolean(PREF_SPOTIFY_LINKED, linked).apply()
                }
            } catch (_: Exception) {
            }
            if (onResult != null) {
                withContext(Dispatchers.Main) { onResult.invoke(linked) }
            }
        }
    }

    private fun restoreSessionWithRefreshTokenBlocking(context: Context, devId: String, refreshToken: String): Boolean {
        return try {
            val conn = (URL("${LauncherConfig.CLOUDFLARE_GATEWAY_URL}/auth/spotify/restore").openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                connectTimeout = 3000
                readTimeout = 3500
                doOutput = true
                setRequestProperty("Content-Type", "application/json; charset=utf-8")
                setRequestProperty("x-app-secret", LauncherConfig.GATEWAY_APP_SECRET)
            }
            val payload = JSONObject().apply {
                put("device_id", devId)
                put("refresh_token", refreshToken)
            }.toString()
            conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
            if (conn.responseCode == 200) {
                val resp = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                val ok = resp.optBoolean("linked", false)
                val newRt = resp.optString("refresh_token", "").trim()
                if (ok && newRt.isNotEmpty()) {
                    saveRefreshToken(context, newRt)
                }
                ok
            } else {
                false
            }
        } catch (_: Exception) {
            false
        }
    }

    fun tryCloudTransportAsync(context: Context, action: String) {
        val appCtx = context.applicationContext
        val devId = getDeviceId(appCtx)
        ioScope.launch {
            try {
                val conn = (URL("${LauncherConfig.CLOUDFLARE_GATEWAY_URL}/spotify/action").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 2000
                    readTimeout = 2200
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("x-app-secret", LauncherConfig.GATEWAY_APP_SECRET)
                }
                val payload = JSONObject().apply {
                    put("device_id", devId)
                    val savedRt = getSavedRefreshToken(appCtx)
                    if (savedRt.isNotEmpty()) put("refresh_token", savedRt)
                    put("action", action.uppercase(Locale.US))
                }.toString()
                conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                conn.responseCode
            } catch (_: Exception) {
            }
        }
    }

    fun searchAndOpenInSpotify(context: Context, spotifyPkg: String, query: String) {
        val appCtx = context.applicationContext
        val devId = getDeviceId(appCtx)
        ioScope.launch {
            var openedViaUri = false
            try {
                val conn = (URL("${LauncherConfig.CLOUDFLARE_GATEWAY_URL}/spotify/action").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 2500
                    readTimeout = 3000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("x-app-secret", LauncherConfig.GATEWAY_APP_SECRET)
                }
                val payload = JSONObject().apply {
                    put("device_id", devId)
                    val savedRt = getSavedRefreshToken(appCtx)
                    if (savedRt.isNotEmpty()) put("refresh_token", savedRt)
                    put("action", "SEARCH_URI")
                    put("query", query)
                }.toString()
                conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                if (conn.responseCode == 200) {
                    val resp = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                    val targetUri = resp.optString("uri", "").trim()
                    if (targetUri.startsWith("spotify:")) {
                        withContext(Dispatchers.Main) {
                            try {
                                val viewIntent = Intent(Intent.ACTION_VIEW, Uri.parse(targetUri)).apply {
                                    setPackage(spotifyPkg)
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                                }
                                appCtx.startActivity(viewIntent)
                                openedViaUri = true
                            } catch (_: Exception) {
                                try {
                                    val fallbackView = Intent(Intent.ACTION_VIEW, Uri.parse(targetUri)).apply {
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    appCtx.startActivity(fallbackView)
                                    openedViaUri = true
                                } catch (_: Exception) {
                                }
                            }
                        }
                    }
                }
            } catch (_: Exception) {
            }
            if (!openedViaUri) {
                withContext(Dispatchers.Main) {
                    try {
                        val uriIntent = Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:${Uri.encode(query)}")).apply {
                            setPackage(spotifyPkg)
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        }
                        appCtx.startActivity(uriIntent)
                    } catch (_: Exception) {
                        AppLauncher(appCtx).launchPackage(spotifyPkg)
                    }
                    TvUiControllerBus.scheduleInAppSearch(spotifyPkg, query)
                }
            }
        }
    }

    fun tryCloudPlayAsync(context: Context, query: String) {
        val appCtx = context.applicationContext
        val devId = getDeviceId(appCtx)
        ioScope.launch {
            for (attempt in 0..1) {
                if (attempt == 1) delay(2600L)
                try {
                    val conn = (URL("${LauncherConfig.CLOUDFLARE_GATEWAY_URL}/spotify/action").openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 2500
                        readTimeout = 3000
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json; charset=utf-8")
                        setRequestProperty("x-app-secret", LauncherConfig.GATEWAY_APP_SECRET)
                    }
                    val payload = JSONObject().apply {
                        put("device_id", devId)
                    val savedRt = getSavedRefreshToken(appCtx)
                    if (savedRt.isNotEmpty()) put("refresh_token", savedRt)
                        put("action", "PLAY_QUERY")
                        put("query", query)
                    }.toString()
                    conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                    if (conn.responseCode == 200) {
                        val json = JSONObject(conn.inputStream.bufferedReader().use { it.readText() })
                        if (json.optBoolean("played", false)) break
                        if (attempt == 0) {
                            val spPkg = AppLauncher(appCtx).getInstalledApps().firstOrNull {
                                it.packageName.lowercase(Locale.ROOT).contains("spotify")
                            }?.packageName
                            if (spPkg != null) {
                                withContext(Dispatchers.Main) {
                                    AppLauncher(appCtx).launchPackage(spPkg)
                                }
                            }
                        }
                    }
                } catch (_: Exception) {
                }
            }
        }
    }

    fun likeCurrentTrack(context: Context, fallbackTrackHint: String = "") {
        val appCtx = context.applicationContext
        val snap = MediaStateBus.state.value
        val currentTrackDesc = when {
            snap.title.isNotBlank() && snap.artist.isNotBlank() -> "${snap.artist} - ${snap.title}"
            snap.title.isNotBlank() -> snap.title
            fallbackTrackHint.isNotBlank() -> fallbackTrackHint
            else -> ""
        }
        if (currentTrackDesc.isNotBlank()) {
            saveLikedTrackLocally(appCtx, currentTrackDesc)
            AiMemoryStore.recordImplicitHabit(appCtx, "MUSIC", currentTrackDesc)
        }

        // 1. Локальный клик по сердечку / отправка рейтинга в активную MediaSession
        TvUiControllerBus.clickByText("Нравится")
        TvUiControllerBus.clickByText("Like")
        TvUiControllerBus.clickByText("Добавить в любимые")

        // 2. Облачный лайк через Cloudflare Worker Spotify Web API
        val devId = getDeviceId(appCtx)
        ioScope.launch {
            try {
                val conn = (URL("${LauncherConfig.CLOUDFLARE_GATEWAY_URL}/spotify/action").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 2500
                    readTimeout = 3000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("x-app-secret", LauncherConfig.GATEWAY_APP_SECRET)
                }
                val payload = JSONObject().apply {
                    put("device_id", devId)
                    val savedRt = getSavedRefreshToken(appCtx)
                    if (savedRt.isNotEmpty()) put("refresh_token", savedRt)
                    put("action", "LIKE_CURRENT")
                    put("query", currentTrackDesc)
                }.toString()
                conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                conn.responseCode
            } catch (_: Exception) {
            }
        }
    }

    fun createOrUpdatePlaylist(context: Context, rawName: String, seedTrackOrGenre: String = "") {
        val appCtx = context.applicationContext
        val name = rawName.trim().ifEmpty { "Плейлист Эхо" }
        val snap = MediaStateBus.state.value
        val currentPlaying = if (snap.title.isNotBlank()) {
            if (snap.artist.isNotBlank()) "${snap.artist} - ${snap.title}" else snap.title
        } else ""
        val trimmedSeed = seedTrackOrGenre.trim()
        val effectiveSeed = when {
            trimmedSeed.isEmpty() -> ""
            trimmedSeed.equals("CURRENT", ignoreCase = true) -> "CURRENT"
            else -> trimmedSeed
        }
        val existingUri = findPlaylistUri(appCtx, name)
        val existingPlaylistId = existingUri?.removePrefix("spotify:playlist:")?.trim().orEmpty()

        val prefs = appCtx.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val obj = try {
            JSONObject(prefs.getString(PREF_ECHO_PLAYLISTS_JSON, "{}") ?: "{}")
        } catch (_: Exception) {
            JSONObject()
        }
        val tracksArr = obj.optJSONArray(name) ?: JSONArray()
        if (effectiveSeed.isNotEmpty()) {
            tracksArr.put(effectiveSeed)
        }
        obj.put(name, tracksArr)
        prefs.edit().putString(PREF_ECHO_PLAYLISTS_JSON, obj.toString()).apply()
        AiMemoryStore.rememberFact(appCtx, "Плейлист пользователя «$name»${if (effectiveSeed.isNotEmpty()) " (треки: $effectiveSeed)" else ""}")

        val devId = getDeviceId(appCtx)
        ioScope.launch {
            try {
                val conn = (URL("${LauncherConfig.CLOUDFLARE_GATEWAY_URL}/spotify/action").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 4000
                    readTimeout = 9000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("x-app-secret", LauncherConfig.GATEWAY_APP_SECRET)
                }
                val payload = JSONObject().apply {
                    put("device_id", devId)
                    val savedRt = getSavedRefreshToken(appCtx)
                    if (savedRt.isNotEmpty()) put("refresh_token", savedRt)
                    put("action", "CREATE_PLAYLIST")
                    put("name", name)
                    put("playlist_id", existingPlaylistId)
                    put("seed_query", effectiveSeed)
                    put("fallback_query", currentPlaying)
                }.toString()
                conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val raw = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                val resp = try { JSONObject(raw) } catch (_: Exception) { JSONObject() }
                if (code == 200 && resp.optBoolean("ok", false)) {
                    val uri = resp.optString("uri", "")
                    if (uri.startsWith("spotify:playlist:")) savePlaylistUri(appCtx, name, uri)
                    val seeded = resp.optBoolean("seeded", false)
                    val seedErr = resp.optString("seedError", "").trim()
                    val toastMsg = if (effectiveSeed.isNotEmpty() && !seeded && seedErr.isNotEmpty()) {
                        "Spotify: плейлист «$name» создан, но трек не добавлен ($seedErr)"
                    } else {
                        "Spotify: плейлист «$name» создан"
                    }
                    withContext(Dispatchers.Main) {
                        Toast.makeText(appCtx, toastMsg, Toast.LENGTH_LONG).show()
                        if (uri.startsWith("spotify:playlist:")) {
                            try {
                                val viewIntent = Intent(Intent.ACTION_VIEW, Uri.parse(uri)).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                appCtx.startActivity(viewIntent)
                            } catch (_: Exception) {
                            }
                        }
                    }
                } else {
                    val reason = if (resp.optString("error") == "not_linked") {
                        "аккаунт Spotify не подключён к Эхо"
                    } else {
                        val msg = resp.optString("message", "").trim()
                        "HTTP ${resp.optInt("status", code)}" + if (msg.isNotEmpty()) ": $msg" else ""
                    }
                    Log.w("SpotifyCloudBridge", "CREATE_PLAYLIST failed: code=$code body=$raw")
                    withContext(Dispatchers.Main) {
                        Toast.makeText(appCtx, "Spotify: плейлист «$name» НЕ создан — $reason", Toast.LENGTH_LONG).show()
                    }
                }
            } catch (e: Exception) {
                Log.w("SpotifyCloudBridge", "CREATE_PLAYLIST exception", e)
                withContext(Dispatchers.Main) {
                    Toast.makeText(appCtx, "Spotify: нет связи с облаком Эхо (${e.javaClass.simpleName})", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun savePlaylistUri(context: Context, name: String, uri: String) {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val obj = try {
            JSONObject(prefs.getString(PREF_ECHO_PLAYLIST_URIS_JSON, "{}") ?: "{}")
        } catch (_: Exception) {
            JSONObject()
        }
        obj.put(name, uri)
        prefs.edit().putString(PREF_ECHO_PLAYLIST_URIS_JSON, obj.toString()).apply()
    }

    /**
     * Настоящий Spotify-плейлист, созданный Эхо, по голосовой фразе.
     * «плейлист Gym» (слово «плейлист» допускает неточное совпадение) или просто «Gym» (только точное имя),
     * чтобы название плейлиста не перехватывало обычные запросы треков.
     */
    fun findPlaylistUri(context: Context, query: String): String? {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val obj = try {
            JSONObject(prefs.getString(PREF_ECHO_PLAYLIST_URIS_JSON, "{}") ?: "{}")
        } catch (_: Exception) {
            return null
        }
        val q = query.trim().lowercase(Locale.ROOT)
        val explicit = q.startsWith("плейлист ") || q.startsWith("playlist ")
        val cleanQ = q.removePrefix("плейлист ").removePrefix("playlist ").trim()
        if (cleanQ.isEmpty()) return null
        val keys = obj.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            val kl = k.lowercase(Locale.ROOT)
            if (kl.isEmpty()) continue
            if (kl == cleanQ || (explicit && cleanQ.contains(kl))) {
                val uri = obj.optString(k, "")
                if (uri.startsWith("spotify:playlist:")) return uri
            }
        }
        return null
    }

    /** Запускает плейлист целиком через облако. Ждёт, пока приложение Spotify на ТВ станет активным устройством. */
    fun tryCloudPlayPlaylistAsync(context: Context, playlistUri: String) {
        val appCtx = context.applicationContext
        val devId = getDeviceId(appCtx)
        ioScope.launch {
            delay(2500L)
            var reason = ""
            for (attempt in 1..2) {
                try {
                    val conn = (URL("${LauncherConfig.CLOUDFLARE_GATEWAY_URL}/spotify/action").openConnection() as HttpURLConnection).apply {
                        requestMethod = "POST"
                        connectTimeout = 4000
                        readTimeout = 8000
                        doOutput = true
                        setRequestProperty("Content-Type", "application/json; charset=utf-8")
                        setRequestProperty("x-app-secret", LauncherConfig.GATEWAY_APP_SECRET)
                    }
                    val payload = JSONObject().apply {
                        put("device_id", devId)
                    val savedRt = getSavedRefreshToken(appCtx)
                    if (savedRt.isNotEmpty()) put("refresh_token", savedRt)
                        put("action", "PLAY_PLAYLIST")
                        put("uri", playlistUri)
                    }.toString()
                    conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                    val code = conn.responseCode
                    if (code in 200..299) return@launch
                    val raw = conn.errorStream?.bufferedReader()?.use { it.readText() }.orEmpty()
                    val errJson = try { JSONObject(raw) } catch (_: Exception) { JSONObject() }
                    val msg = errJson.optString("message", "").trim()
                    reason = if (errJson.optString("error") == "not_linked") {
                        "аккаунт Spotify не подключён к Эхо"
                    } else {
                        "HTTP $code" + if (msg.isNotEmpty()) ": $msg" else ""
                    }
                    // 404 = нет активного устройства (приложение ещё запускается) — пробуем ещё раз.
                    if (code != 404) break
                } catch (e: Exception) {
                    reason = e.javaClass.simpleName
                    break
                }
                if (attempt == 1) delay(3000L)
            }
            Log.w("SpotifyCloudBridge", "PLAY_PLAYLIST failed: $reason")
            withContext(Dispatchers.Main) {
                Toast.makeText(appCtx, "Spotify: плейлист открыт, но запустить не удалось — $reason", Toast.LENGTH_LONG).show()
            }
        }
    }

    fun resolvePlaylistOrQuery(context: Context, query: String): String {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val obj = try {
            JSONObject(prefs.getString(PREF_ECHO_PLAYLISTS_JSON, "{}") ?: "{}")
        } catch (_: Exception) {
            JSONObject()
        }
        val cleanQ = query.trim().lowercase(Locale.ROOT).removePrefix("плейлист ").trim()
        val keys = obj.keys()
        while (keys.hasNext()) {
            val k = keys.next()
            if (k.lowercase(Locale.ROOT) == cleanQ || cleanQ.contains(k.lowercase(Locale.ROOT))) {
                val arr = obj.optJSONArray(k)
                if (arr != null && arr.length() > 0) {
                    return arr.optString(arr.length() - 1, query)
                }
            }
        }
        return query
    }

    private fun saveLikedTrackLocally(context: Context, trackDesc: String) {
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val arr = try {
            JSONArray(prefs.getString(PREF_ECHO_LIKED_JSON, "[]") ?: "[]")
        } catch (_: Exception) {
            JSONArray()
        }
        val list = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            val s = arr.optString(i, "").trim()
            if (s.isNotEmpty() && !s.equals(trackDesc, ignoreCase = true)) {
                list.add(s)
            }
        }
        list.add(trackDesc)
        while (list.size > 25) list.removeAt(0)
        val out = JSONArray()
        for (s in list) out.put(s)
        prefs.edit().putString(PREF_ECHO_LIKED_JSON, out.toString()).apply()
    }
}
