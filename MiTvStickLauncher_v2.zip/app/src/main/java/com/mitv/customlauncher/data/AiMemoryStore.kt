package com.mitv.customlauncher.data

import android.app.ActivityManager
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Build
import android.media.AudioFormat
import android.media.AudioTrack
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.isActive
import kotlinx.coroutines.Deferred
import kotlinx.coroutines.async
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import android.graphics.Color
import kotlinx.coroutines.delay
import java.nio.ByteOrder
import java.security.MessageDigest
import javax.crypto.Mac
import javax.crypto.spec.SecretKeySpec
import kotlin.math.sqrt
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.provider.Settings
import android.speech.tts.TextToSpeech
import com.mitv.customlauncher.service.DynamicIslandBus
import com.mitv.customlauncher.service.RemoteConsoleServer
import com.mitv.customlauncher.service.ShellKeyController
import android.util.Base64
import android.util.Log
import android.widget.Toast
import android.view.KeyEvent
import com.mitv.customlauncher.service.TvUiControllerBus
import com.mitv.customlauncher.service.MediaStateBus
import com.mitv.customlauncher.service.NavSoundPlayer
import com.mitv.customlauncher.service.VolumeHudBus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


object AiMemoryStore {
    private const val PREF_MEMORY_JSON = "pref_ai_long_term_memory_v58"
    private const val PREF_HABITS_JSON = "pref_ai_implicit_habits_v89"
    private const val HABIT_DECAY_MS = 14L * 24L * 3600L * 1000L // 14 дней

    fun rememberFact(context: Context, rawFact: String) {
        // Старый вход (например, из SpotifyCloudBridge): простая заметка без субъекта.
        MindMapStore.addFact(context, "Заметки", rawFact)
    }

    /**
     * Пассивное самообучение Эхо с защитой от зацикливания:
     * запоминает частые предпочтения (музыка, каналы YouTube, стримеры) с автоматическим затуханием через 14 дней
     * и жёстким лимитом в 10 записей.
     */
    fun recordImplicitHabit(context: Context, category: String, rawValue: String) {
        val cleanVal = rawValue.trim().take(60)
        if (cleanVal.length < 2) return
        val now = System.currentTimeMillis()
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val arr = try {
            JSONArray(prefs.getString(PREF_HABITS_JSON, "[]") ?: "[]")
        } catch (_: Exception) {
            JSONArray()
        }
        val items = mutableListOf<JSONObject>()
        var matched = false
        for (i in 0 until arr.length()) {
            val obj = arr.optJSONObject(i) ?: continue
            val ts = obj.optLong("ts", 0L)
            if (now - ts > HABIT_DECAY_MS) continue
            val cat = obj.optString("cat", "")
            val v = obj.optString("val", "")
            if (cat.equals(category, ignoreCase = true) && v.equals(cleanVal, ignoreCase = true)) {
                obj.put("count", (obj.optInt("count", 1) + 1).coerceAtMost(15))
                obj.put("ts", now)
                matched = true
            }
            items.add(obj)
        }
        if (!matched) {
            items.add(JSONObject().apply {
                put("cat", category)
                put("val", cleanVal)
                put("count", 1)
                put("ts", now)
            })
        }
        items.sortByDescending { it.optInt("count", 1) * 1000000L + (it.optLong("ts", 0L) / 60000L) }
        val capped = items.take(10)
        val out = JSONArray()
        for (o in capped) out.put(o)
        prefs.edit().putString(PREF_HABITS_JSON, out.toString()).apply()
    }

    fun forgetFact(context: Context, keywordOrAll: String) {
        val kw = keywordOrAll.trim().lowercase(Locale.ROOT)
        if (kw == "all" || kw == "все" || kw == "всё") {
            val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            prefs.edit()
                .putString(PREF_MEMORY_JSON, "[]")
                .putString(PREF_HABITS_JSON, "[]")
                .apply()
            MindMapStore.clearAll(context)
            return
        }
        if (kw.isEmpty()) return
        MindMapStore.forget(context, kw)
    }

    fun getMemoryPromptBlock(context: Context, queryHint: String = ""): String {
        return MindMapStore.buildPromptBlock(context, queryHint)
    }
}
