package com.mitv.customlauncher.service

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.SoundPool
import android.media.MediaMetadata
import android.media.MediaRecorder
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Parcelable
import android.os.SystemClock
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.TextUtils
import android.util.Log
import android.util.LruCache
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.content.ClipData
import android.content.ClipboardManager
import java.util.Locale
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import com.mitv.customlauncher.R
import com.mitv.customlauncher.data.AssistantVoiceSpeaker
import com.mitv.customlauncher.data.GeminiCloudClient
import com.mitv.customlauncher.data.GeminiTurnResult
import com.mitv.customlauncher.data.LauncherConfig
import com.mitv.customlauncher.data.NativeCore
import com.mitv.customlauncher.data.LocalVoiceCommandRouter
import com.mitv.customlauncher.ui.EchoView
import com.mitv.customlauncher.ui.LauncherActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import org.json.JSONObject
import android.net.wifi.WifiManager
import android.os.PowerManager
import java.net.InetAddress
import java.net.InetSocketAddress
import com.mitv.customlauncher.data.TuyaSmartHomeController
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.net.URLEncoder
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sin
import kotlin.math.sqrt


object ServiceAutoActivator {
    fun isNotificationListenerEnabled(context: Context): Boolean {
        return try {
            val pkg = context.packageName
            val flat = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners").orEmpty()
            flat.contains(pkg)
        } catch (_: Exception) {
            false
        }
    }

    fun openNotificationListenerSettings(context: Context): Boolean {
        val intents = listOf(
            Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"),
            Intent(Settings.ACTION_SETTINGS)
        )
        for (intent in intents) {
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                return true
            } catch (_: Exception) {
            }
        }
        return false
    }

    fun hasWriteSecureSettings(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.WRITE_SECURE_SETTINGS
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun ensureNotificationListenerInSecureSettings(context: Context) {
        if (!hasWriteSecureSettings(context)) return
        try {
            val appCtx = context.applicationContext
            val pkg = appCtx.packageName
            val cr = appCtx.contentResolver
            val notifFlat = "$pkg/$pkg.service.MediaSessionListenerService"
            val notifShort = "$pkg/.service.MediaSessionListenerService"
            val curNotif = Settings.Secure.getString(cr, "enabled_notification_listeners").orEmpty()
            if (!curNotif.contains(notifFlat)) {
                val base = if (curNotif.isBlank()) "" else "$curNotif:"
                Settings.Secure.putString(cr, "enabled_notification_listeners", "$base$notifFlat:$notifShort")
            }
        } catch (_: Exception) {
        }
    }

    fun ensureServicesActive(context: Context) {
        val appCtx = context.applicationContext
        val pkg = appCtx.packageName
        val notifComp = ComponentName(appCtx, MediaSessionListenerService::class.java)

        try {
            val pm = appCtx.packageManager
            if (pm.getComponentEnabledSetting(notifComp) == PackageManager.COMPONENT_ENABLED_STATE_DISABLED) {
                pm.setComponentEnabledSetting(
                    notifComp,
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                    PackageManager.DONT_KILL_APP
                )
            }
        } catch (_: Exception) {
        }

        if (hasWriteSecureSettings(appCtx)) {
            val cr = appCtx.contentResolver
            val accFlat = "$pkg/$pkg.service.KeyMapperAccessibilityService"
            try {
                ensureNotificationListenerInSecureSettings(appCtx)

                val curAcc = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
                if (!curAcc.contains(pkg)) {
                    val updatedAcc = if (curAcc.isBlank()) accFlat else "$curAcc:$accFlat"
                    Settings.Secure.putString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, updatedAcc)
                    Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
                }

            } catch (_: Exception) {
            }
            // Лаунчер — системный ассистент: кнопка ассистента открывает нашу VoiceInteractionSession, а не Katniss.
            try {
                val ourVis = "$pkg/$pkg.service.LauncherVoiceInteractionService"
                val prevRecognizer = Settings.Secure.getString(cr, "voice_recognition_service").orEmpty()
                if (Settings.Secure.getString(cr, "voice_interaction_service") != ourVis) {
                    Settings.Secure.putString(cr, "voice_interaction_service", ourVis)
                    Log.i("AssistKey", "voice_interaction_service set to $ourVis")
                }
                if (Settings.Secure.getString(cr, "assistant") != ourVis) {
                    Settings.Secure.putString(cr, "assistant", ourVis)
                }
                // Система может заодно сделать нашу заглушку распознавателем речи по умолчанию — возвращаем прежний.
                if (prevRecognizer.isNotBlank() && !prevRecognizer.contains(pkg)) {
                    Handler(Looper.getMainLooper()).postDelayed({
                        try {
                            val now = Settings.Secure.getString(cr, "voice_recognition_service").orEmpty()
                            if (now.contains(pkg)) {
                                Settings.Secure.putString(cr, "voice_recognition_service", prevRecognizer)
                            }
                        } catch (_: Exception) {
                        }
                    }, 2000L)
                }
            } catch (_: Exception) {
            }
        }

        try {
            Settings.System.putInt(appCtx.contentResolver, Settings.System.SOUND_EFFECTS_ENABLED, 0)
        } catch (_: Exception) {
        }
        NavSoundPlayer.init(appCtx)

        if (MediaSessionListenerService.instance == null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try {
                NotificationListenerService.requestRebind(notifComp)
            } catch (_: Exception) {
            }
        }
    }
}
