package com.mitv.customlauncher.service

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.SoundPool
import android.media.MediaMetadata
import android.media.MediaRecorder
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Parcelable
import android.os.SystemClock
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.TextUtils
import android.util.LruCache
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.content.ClipData
import android.content.ClipboardManager
import java.util.Locale
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import com.mitv.customlauncher.R
import com.mitv.customlauncher.data.AssistantVoiceSpeaker
import com.mitv.customlauncher.data.GeminiCloudClient
import com.mitv.customlauncher.data.GeminiTurnResult
import com.mitv.customlauncher.data.LauncherConfig
import com.mitv.customlauncher.data.LocalVoiceCommandRouter
import com.mitv.customlauncher.ui.LauncherActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import org.json.JSONObject
import android.net.wifi.WifiManager
import android.os.PowerManager
import java.net.InetAddress
import java.net.InetSocketAddress
import com.mitv.customlauncher.data.TuyaSmartHomeController
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.net.URLEncoder
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sin
import kotlin.math.sqrt

data class NowPlayingSnapshot(
    val hasActiveSession: Boolean = false,
    val isPlaying: Boolean = false,
    val title: String = "",
    val artist: String = "",
    val sourcePackage: String = "",
    val sourceAppName: String = "",
    val coverBitmap: Bitmap? = null,
    val durationMs: Long = 0L,
    val basePositionMs: Long = 0L,
    val baseElapsedRealtime: Long = 0L,
    val playbackSpeed: Float = 1.0f
)

object VolumeHudBus {
    @Volatile
    var onVolumeIntercepted: (() -> Unit)? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    fun notifyVolumeChanged() {
        val listener = onVolumeIntercepted ?: return
        mainHandler.post { listener.invoke() }
    }
}

object DynamicIslandBus {
    @Volatile
    var onTriggerIslandInService: (() -> Unit)? = null

    @Volatile
    var onTriggerIslandInActivity: (() -> Unit)? = null

    @Volatile
    var onTriggerVoiceTextInService: ((String) -> Unit)? = null

    @Volatile
    var onTriggerVoiceTextInActivity: ((String) -> Unit)? = null

    @Volatile
    var onDispatchKeyInActivity: ((Int) -> Boolean)? = null

    @Volatile
    var onRequestAudioPermissionInActivity: (() -> Unit)? = null

    @Volatile
    var onAccentColorUpdated: ((String) -> Unit)? = null

    @Volatile
    var onIslandVisibilityChanged: ((Boolean) -> Unit)? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    fun triggerAssistant(context: Context) {
        val serviceTrigger = onTriggerIslandInService
        if (serviceTrigger != null && KeyMapperAccessibilityService.isServiceConnectedAlive) {
            mainHandler.post { serviceTrigger.invoke() }
            return
        }
        val activityTrigger = onTriggerIslandInActivity
        if (activityTrigger != null) {
            mainHandler.post { activityTrigger.invoke() }
            return
        }
        val intent = Intent(context, LauncherActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra("EXTRA_OPEN_AI", true)
        }
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
        }
    }

    fun triggerVoiceText(context: Context, rawText: String) {
        val clean = rawText.trim()
        if (clean.isEmpty()) {
            triggerAssistant(context)
            return
        }
        val serviceVoice = onTriggerVoiceTextInService
        if (serviceVoice != null && KeyMapperAccessibilityService.isServiceConnectedAlive) {
            mainHandler.post { serviceVoice.invoke(clean) }
            return
        }
        val activityVoice = onTriggerVoiceTextInActivity
        if (activityVoice != null) {
            mainHandler.post { activityVoice.invoke(clean) }
            return
        }
        val intent = Intent(context, LauncherActivity::class.java).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            putExtra("EXTRA_VOICE_QUERY", clean)
        }
        try {
            context.startActivity(intent)
        } catch (_: Exception) {
        }
    }

    fun notifyAccentColorChanged(hex: String) {
        mainHandler.post {
            onAccentColorUpdated?.invoke(hex)
        }
    }

    fun notifyIslandVisibility(visible: Boolean) {
        mainHandler.post {
            onIslandVisibilityChanged?.invoke(visible)
        }
    }
}

/**
 * Шина ИИ-управления всем телевизором через AccessibilityService:
 * - Автоматический поиск стримера/контента внутри открытого ТВ-приложения (например Kick на ТВ)
 * - Голосовой ввод текста в любое поле поиска на экране ТВ (без пульта!)
 * - Нажатие на любую кнопку или карточку на экране по её названию
 * - Глобальная навигация (Назад, Домой, стрелки, ОК)
 */
object TvUiControllerBus {
    @Volatile
    var onScheduleInAppSearch: ((targetPkg: String, query: String) -> Unit)? = null

    @Volatile
    var onTypeTextOnScreen: ((text: String) -> Boolean)? = null

    @Volatile
    var onClickNodeByText: ((text: String) -> Boolean)? = null

    @Volatile
    var onGlobalNavAction: ((action: String) -> Unit)? = null

    @Volatile
    var onInjectDpadAction: ((directionOrCenter: String) -> Boolean)? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    fun scheduleInAppSearch(targetPkg: String, query: String) {
        mainHandler.post {
            onScheduleInAppSearch?.invoke(targetPkg, query)
        }
    }

    fun typeText(text: String) {
        mainHandler.post {
            onTypeTextOnScreen?.invoke(text)
        }
    }

    fun clickByText(text: String) {
        mainHandler.post {
            onClickNodeByText?.invoke(text)
        }
    }

    fun performNav(action: String) {
        mainHandler.post {
            onGlobalNavAction?.invoke(action)
        }
    }
}

/**
 * Глобальный ультра-быстрый движок кастомного звука переключения (SoundPool < 1 мс)
 * Работает по всей приставке (в лаунчере и поверх всех приложений)!
 */

/**
 * Локальный сервер-приёмник команд со смартфона-пульта «Smart Touch Console» (Huawei Y5):
 * - Слушает порт 8765 по HTTP GET/POST и UDP (отклик < 2 мс в домашней Wi-Fi сети)
 * - /status или /ping -> возвращает JSON со статусом экрана ТВ (isInteractive / state) и подсветки Tuya
 * - /key?k=DPAD_UP|DPAD_DOWN|DPAD_LEFT|DPAD_RIGHT|DPAD_CENTER|BACK|HOME|VOL_UP|VOL_DOWN|PLAY_PAUSE|VOICE_ASSIST
 * - /app?pkg=com.google.android.youtube.tv (или youtube / kick / browser)
 * - /voice?text=... -> мгновенно открывает оверлей Gemini AI на экране телевизора с переданным запросом
 * - /light?power=true|false или /light?preset=cyber|sapphire|violet|raspberry|sunset|warm
 */
object ShellKeyController {
    private var process: Process? = null
    private var writer: BufferedWriter? = null

    init {
        try {
            process = ProcessBuilder("sh").start()
            writer = process?.outputStream?.bufferedWriter()
            writer?.write("settings put global wifi_sleep_policy 2\n")
            writer?.write("settings put global adaptive_battery_management_enabled 0\n")
            writer?.write("settings put global app_standby_enabled 0\n")
            writer?.write("dumpsys deviceidle whitelist +com.mitv.customlauncher\n")
            writer?.write("dumpsys deviceidle disable\n")
            writer?.flush()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    @Synchronized
    fun sendKeyEvent(keyCode: Int) {
        try {
            if (writer == null) {
                process = ProcessBuilder("sh").start()
                writer = process?.outputStream?.bufferedWriter()
            }
            writer?.write("input keyevent $keyCode\n")
            writer?.flush()
        } catch (e: Exception) {
            try {
                process?.destroy()
                process = ProcessBuilder("sh").start()
                writer = process?.outputStream?.bufferedWriter()
                writer?.write("input keyevent $keyCode\n")
                writer?.flush()
            } catch (_: Exception) {
            }
        }
    }
}

object RemoteConsoleServer {
    const val PORT = 8765

    @Volatile
    private var isRunning = false
    private var tcpServerSocket: ServerSocket? = null
    private var udpSocket: DatagramSocket? = null
    private var highPerfWifiLock: WifiManager.WifiLock? = null
    private var multicastArpLock: WifiManager.MulticastLock? = null
    private var partialWakeLock: PowerManager.WakeLock? = null
    private var screenStateReceiverRegistered = false
    @Volatile
    private var lastPhoneAddress: InetAddress? = null
    @Volatile
    private var forcedScreenStateOverride: Boolean? = null
    @Volatile
    private var forcedScreenStateUntilMs: Long = 0L
    private val serverScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val mainHandler = Handler(Looper.getMainLooper())

    @Suppress("DEPRECATION")
    private fun acquireLocks(context: Context) {
        val appCtx = context.applicationContext
        try {
            val cr = appCtx.contentResolver
            Settings.Global.putInt(cr, Settings.Global.WIFI_SLEEP_POLICY, Settings.Global.WIFI_SLEEP_POLICY_NEVER)
            Settings.Global.putInt(cr, "wifi_wakeup_enabled", 1)
            Settings.Global.putInt(cr, "wifi_scan_always_enabled", 1)
            Settings.Global.putInt(cr, "adaptive_battery_management_enabled", 0)
            Settings.Global.putInt(cr, "app_standby_enabled", 0)
        } catch (_: Exception) {
        }
        try {
            val wm = appCtx.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            if (highPerfWifiLock?.isHeld != true) {
                val lock = wm?.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "MiTvLauncher:RemoteConsoleWifiLock")
                lock?.setReferenceCounted(false)
                lock?.acquire()
                highPerfWifiLock = lock
            }
            // MulticastLock запрещает Wi-Fi чипу включать аппаратный фильтр Broadcast/ARP пакетов при выключении экрана!
            if (multicastArpLock?.isHeld != true) {
                val mLock = wm?.createMulticastLock("MiTvLauncher:ArpMulticastLock")
                mLock?.setReferenceCounted(false)
                mLock?.acquire()
                multicastArpLock = mLock
            }
        } catch (_: Exception) {
        }
        try {
            if (partialWakeLock?.isHeld != true) {
                val pm = appCtx.getSystemService(Context.POWER_SERVICE) as? PowerManager
                val wl = pm?.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "MiTvLauncher:RemoteConsoleWakeLock")
                wl?.setReferenceCounted(false)
                wl?.acquire()
                partialWakeLock = wl
            }
        } catch (_: Exception) {
        }
    }

    private fun registerScreenOffWakeGuard(context: Context) {
        if (screenStateReceiverRegistered) return
        screenStateReceiverRegistered = true
        val appCtx = context.applicationContext
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_SCREEN_OFF)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(Intent.ACTION_DREAMING_STARTED)
        }
        try {
            appCtx.registerReceiver(object : BroadcastReceiver() {
                override fun onReceive(ctx: Context?, intent: Intent?) {
                    acquireLocks(appCtx)
                    serverScope.launch {
                        sendArpKeepAliveBurst()
                    }
                }
            }, filter)
        } catch (_: Exception) {
        }
    }

    private fun sendArpKeepAliveBurst() {
        val keepAlivePayload = "KA".toByteArray(Charsets.UTF_8)
        try {
            DatagramSocket().use { ks ->
                ks.soTimeout = 400
                ks.broadcast = true
                val targets = mutableListOf<InetAddress>()
                lastPhoneAddress?.let { targets.add(it) }
                for (ip in listOf("192.168.0.1", "192.168.1.1", "192.168.0.255", "255.255.255.255")) {
                    try {
                        targets.add(InetAddress.getByName(ip))
                    } catch (_: Exception) {
                    }
                }
                for (addr in targets) {
                    try {
                        ks.send(DatagramPacket(keepAlivePayload, keepAlivePayload.size, addr, 9))
                    } catch (_: Exception) {
                    }
                }
            }
        } catch (_: Exception) {
        }
    }

    @Synchronized
    fun ensureStarted(context: Context) {
        val appCtx = context.applicationContext
        acquireLocks(appCtx)
        registerScreenOffWakeGuard(appCtx)
        TuyaSmartHomeController.ensureWarmupStarted()
        if (isRunning) return
        isRunning = true

        // 1. Постоянный TCP/HTTP сервер на порту 8765
        serverScope.launch {
            while (isActive && isRunning) {
                try {
                    val server = ServerSocket()
                    server.reuseAddress = true
                    server.bind(InetSocketAddress(PORT))
                    tcpServerSocket = server
                    while (isActive && !server.isClosed) {
                        val client = try {
                            server.accept()
                        } catch (_: Exception) {
                            break
                        }
                        client.inetAddress?.let { lastPhoneAddress = it }
                        serverScope.launch {
                            handleTcpClient(appCtx, client)
                        }
                    }
                } catch (_: Exception) {
                    delay(1500L)
                } finally {
                    try {
                        tcpServerSocket?.close()
                    } catch (_: Exception) {
                    }
                }
            }
        }

        // 2. Постоянный UDP сервер на порту 8765 с reuseAddress = true
        serverScope.launch {
            while (isActive && isRunning) {
                try {
                    val ds = DatagramSocket(null)
                    ds.reuseAddress = true
                    ds.bind(InetSocketAddress(PORT))
                    udpSocket = ds
                    val buf = ByteArray(1024)
                    while (isActive && !ds.isClosed) {
                        val packet = DatagramPacket(buf, buf.size)
                        ds.receive(packet)
                        packet.address?.let { lastPhoneAddress = it }
                        val msg = String(packet.data, 0, packet.length, Charsets.UTF_8).trim()
                        if (msg.isNotEmpty()) {
                            val reply = processIncomingCommand(appCtx, msg)
                            val replyBytes = reply.toByteArray(Charsets.UTF_8)
                            val outPacket = DatagramPacket(replyBytes, replyBytes.size, packet.address, packet.port)
                            try {
                                ds.send(outPacket)
                            } catch (_: Exception) {
                            }
                        }
                    }
                } catch (_: Exception) {
                    delay(1500L)
                } finally {
                    try {
                        udpSocket?.close()
                    } catch (_: Exception) {
                    }
                }
            }
        }

        // 3. Активный анти-сон (ARP & Wi-Fi Radio Keep-Alive каждые 8 секунд напрямую на IP телефона и роутер):
        serverScope.launch {
            while (isActive && isRunning) {
                acquireLocks(appCtx)
                sendArpKeepAliveBurst()
                delay(8_000L)
            }
        }
    }

    private fun handleTcpClient(context: Context, client: Socket) {
        try {
            client.soTimeout = 750
            client.tcpNoDelay = true
            val reader = BufferedReader(InputStreamReader(client.getInputStream(), Charsets.UTF_8))
            val firstLine = reader.readLine().orEmpty().trim()
            if (firstLine.isEmpty()) {
                client.close()
                return
            }

            val isHttp = firstLine.startsWith("GET ") || firstLine.startsWith("POST ")
            val targetPath = if (isHttp) {
                firstLine.split(" ").getOrNull(1).orEmpty()
            } else {
                firstLine
            }

            var contentLength = 0
            if (isHttp) {
                while (true) {
                    val headerLine = reader.readLine() ?: break
                    if (headerLine.isEmpty()) break
                    if (headerLine.lowercase(Locale.US).startsWith("content-length:")) {
                        contentLength = headerLine.substringAfter(":").trim().toIntOrNull() ?: 0
                    }
                }
            }

            val bodyStr = if (contentLength in 1..4096) {
                val chars = CharArray(contentLength)
                val readCount = reader.read(chars, 0, contentLength)
                if (readCount > 0) String(chars, 0, readCount) else ""
            } else ""

            val combinedCmd = if (bodyStr.isNotEmpty() && !targetPath.contains("?")) {
                "$targetPath?$bodyStr"
            } else {
                targetPath
            }

            val responseJson = processIncomingCommand(context, combinedCmd)
            val out = client.getOutputStream()
            if (isHttp) {
                val bodyBytes = responseJson.toByteArray(Charsets.UTF_8)
                val headers = "HTTP/1.1 200 OK\r\n" +
                    "Content-Type: application/json; charset=utf-8\r\n" +
                    "Access-Control-Allow-Origin: *\r\n" +
                    "Content-Length: ${bodyBytes.size}\r\n" +
                    "Connection: close\r\n\r\n"
                out.write(headers.toByteArray(Charsets.UTF_8))
                out.write(bodyBytes)
            } else {
                out.write((responseJson + "\n").toByteArray(Charsets.UTF_8))
            }
            out.flush()
        } catch (_: Exception) {
        } finally {
            try {
                client.close()
            } catch (_: Exception) {
            }
        }
    }

    private fun parseQueryParams(rawQuery: String): Map<String, String> {
        val map = mutableMapOf<String, String>()
        for (pair in rawQuery.split("&")) {
            if (pair.isBlank()) continue
            val idx = pair.indexOf('=')
            if (idx > 0) {
                val k = pair.substring(0, idx).trim()
                val v = try {
                    URLDecoder.decode(pair.substring(idx + 1).trim(), "UTF-8")
                } catch (_: Exception) {
                    pair.substring(idx + 1).trim()
                }
                map[k] = v
            } else {
                map[pair.trim()] = ""
            }
        }
        return map
    }

    private fun isScreenInteractive(context: Context): Boolean {
        val now = System.currentTimeMillis()
        val overrideVal = forcedScreenStateOverride
        if (overrideVal != null && now < forcedScreenStateUntilMs) {
            return overrideVal
        }
        return try {
            val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            pm?.isInteractive != false
        } catch (_: Exception) {
            true
        }
    }

    private fun executeHdmiSleepOrWakeup(context: Context, sleep: Boolean) {
        acquireLocks(context)
        forcedScreenStateOverride = !sleep
        forcedScreenStateUntilMs = System.currentTimeMillis() + 2500L
        val code = if (sleep) 223 else 224
        serverScope.launch {
            ShellKeyController.sendKeyEvent(code)
            delay(300L)
            acquireLocks(context)
            sendArpKeepAliveBurst()
        }
    }

    private fun buildStatusJson(context: Context, ok: Boolean = true, action: String = "status"): String {
        val interactive = isScreenInteractive(context)
        return JSONObject().apply {
            put("ok", ok)
            put("success", ok)
            put("action", action)
            put("isReachable", true)
            put("isInteractive", interactive)
            put("screenState", if (interactive) "ON" else "SLEEP")
            put("ledOn", TuyaSmartHomeController.isLedOn(context))
            put("ledMode", TuyaSmartHomeController.getCurrentModeLabel(context))
            put("ledBright", TuyaSmartHomeController.getBrightnessPct(context))
        }.toString()
    }

    private fun processIncomingCommand(context: Context, rawCmd: String): String {
        val trimmed = rawCmd.trim()
        val path = trimmed.substringBefore("?").lowercase(Locale.US)
        val query = if (trimmed.contains("?")) trimmed.substringAfter("?") else ""
        val params = parseQueryParams(query)

        return when {
            path == "/status" || path == "/ping" || path == "/" || trimmed.equals("PING", ignoreCase = true) || trimmed.equals("STATUS", ignoreCase = true) -> {
                buildStatusJson(context, ok = true, action = "status")
            }
            path == "/sleep" || trimmed.equals("SLEEP", ignoreCase = true) -> {
                executeHdmiSleepOrWakeup(context, sleep = true)
                buildStatusJson(context, ok = true, action = "key:SLEEP")
            }
            path == "/wakeup" || path == "/wake" || trimmed.equals("WAKEUP", ignoreCase = true) || trimmed.equals("WAKE", ignoreCase = true) -> {
                executeHdmiSleepOrWakeup(context, sleep = false)
                buildStatusJson(context, ok = true, action = "key:WAKEUP")
            }
            path == "/power" || trimmed.equals("POWER", ignoreCase = true) -> {
                val targetState = (params["state"] ?: params["action"] ?: params["power"] ?: "").lowercase(Locale.US)
                val shouldSleep = when (targetState) {
                    "sleep", "off", "0", "false", "223" -> true
                    "wakeup", "wake", "on", "1", "true", "224" -> false
                    else -> isScreenInteractive(context)
                }
                executeHdmiSleepOrWakeup(context, sleep = shouldSleep)
                buildStatusJson(context, ok = true, action = if (shouldSleep) "key:SLEEP" else "key:WAKEUP")
            }
            path.startsWith("/key") || trimmed.uppercase(Locale.US).startsWith("KEY:") -> {
                val keyName = if (trimmed.uppercase(Locale.US).startsWith("KEY:")) {
                    trimmed.substringAfter(":").trim()
                } else {
                    params["k"] ?: params["key"] ?: params["code"] ?: ""
                }
                handleRemoteKeyCommand(context, keyName)
                buildStatusJson(context, ok = true, action = "key:$keyName")
            }
            path.startsWith("/app") || trimmed.uppercase(Locale.US).startsWith("APP:") -> {
                val appTarget = if (trimmed.uppercase(Locale.US).startsWith("APP:")) {
                    trimmed.substringAfter(":").trim()
                } else {
                    params["pkg"] ?: params["app"] ?: params["name"] ?: ""
                }
                handleRemoteAppLaunch(context, appTarget)
                buildStatusJson(context, ok = true, action = "app:$appTarget")
            }
            path.startsWith("/voice") || trimmed.uppercase(Locale.US).startsWith("VOICE:") -> {
                val spoken = if (trimmed.uppercase(Locale.US).startsWith("VOICE:")) {
                    trimmed.substringAfter(":").trim()
                } else {
                    params["text"] ?: params["q"] ?: params["query"] ?: ""
                }
                mainHandler.post {
                    DynamicIslandBus.triggerVoiceText(context, spoken)
                }
                buildStatusJson(context, ok = true, action = "voice")
            }
            path.startsWith("/light") || trimmed.uppercase(Locale.US).startsWith("LIGHT:") -> {
                val presetName = params["preset"] ?: params["color"] ?: params["swatch"] ?: ""
                val powerStr = params["power"] ?: params["state"] ?: params["on"] ?: ""
                val toggleStr = params["toggle"] ?: ""
                val brightStr = params["bright"] ?: params["brightness"] ?: params["b"] ?: ""
                val sceneStr = params["scene"] ?: params["mode"] ?: ""
                val hueStr = params["hue"] ?: params["h"] ?: ""

                if (toggleStr.equals("1", ignoreCase = true) || toggleStr.equals("true", ignoreCase = true) || powerStr.equals("toggle", ignoreCase = true)) {
                    TuyaSmartHomeController.togglePower(context)
                } else if (powerStr.isNotEmpty()) {
                    val turnOn = powerStr.equals("true", ignoreCase = true) || powerStr == "1" || powerStr.equals("on", ignoreCase = true)
                    TuyaSmartHomeController.setPower(context, turnOn)
                }

                if (presetName.isNotEmpty()) {
                    val p = TuyaSmartHomeController.CURATED_SWATCHES.firstOrNull {
                        it.name.equals(presetName, ignoreCase = true) ||
                            (presetName.equals("cyber", ignoreCase = true) && it.name == "Кибер") ||
                            (presetName.equals("ocean", ignoreCase = true) && it.name == "Океан") ||
                            (presetName.equals("sapphire", ignoreCase = true) && it.name == "Сапфир") ||
                            (presetName.equals("indigo", ignoreCase = true) && it.name == "Индиго") ||
                            (presetName.equals("violet", ignoreCase = true) && it.name == "Фиолет") ||
                            (presetName.equals("fuchsia", ignoreCase = true) && it.name == "Фуксия") ||
                            (presetName.equals("raspberry", ignoreCase = true) && it.name == "Малина") ||
                            (presetName.equals("sunset", ignoreCase = true) && it.name == "Закат") ||
                            (presetName.equals("amber", ignoreCase = true) && it.name == "Янтарь") ||
                            (presetName.equals("lime", ignoreCase = true) && it.name == "Лайм") ||
                            (presetName.equals("emerald", ignoreCase = true) && it.name == "Изумруд") ||
                            (presetName.equals("warm", ignoreCase = true) && it.name == "Тёплый")
                    }
                    if (p != null) {
                        TuyaSmartHomeController.applySwatchPreset(context, p)
                    } else if (presetName.startsWith("#") || presetName.length == 6) {
                        TuyaSmartHomeController.setHexColor(context, presetName)
                    }
                }

                val hVal = hueStr.toIntOrNull()
                if (hVal != null) {
                    val curHue = TuyaSmartHomeController.getHue(context)
                    TuyaSmartHomeController.stepHueByDelta(context, hVal - curHue, immediate = true)
                }

                if (sceneStr.isNotEmpty()) {
                    TuyaSmartHomeController.activateDynamicScene(context, sceneStr)
                }

                val bVal = brightStr.toIntOrNull()
                if (bVal != null) {
                    TuyaSmartHomeController.setBrightnessPercent(context, bVal)
                }

                buildStatusJson(context, ok = true, action = "light")
            }
            else -> buildStatusJson(context, ok = true, action = "noop")
        }
    }

    private fun resolveAndroidKeyCode(context: Context, rawKey: String): Int? {
        val k = rawKey.trim().uppercase(Locale.US).removePrefix("KEYCODE_")
        when (k) {
            "SLEEP", "223", "SCREEN_OFF", "HDMI_OFF" -> return 223
            "WAKEUP", "WAKE", "224", "SCREEN_ON", "HDMI_ON" -> return 224
            "POWER", "26", "TOGGLE_POWER" -> {
                return if (isScreenInteractive(context)) 223 else 224
            }
        }
        val numeric = k.toIntOrNull()
        if (numeric != null && numeric > 0) return numeric
        return when (k) {
            "UP", "DPAD_UP" -> 19
            "DOWN", "DPAD_DOWN" -> 20
            "LEFT", "DPAD_LEFT" -> 21
            "RIGHT", "DPAD_RIGHT" -> 22
            "OK", "CENTER", "DPAD_CENTER", "ENTER" -> 23
            "BACK", "ESCAPE" -> 4
            "HOME" -> 3
            "MENU", "PATCHWALL", "ALL_APPS", "SETTINGS" -> 82
            "VOL_UP", "VOLUME_UP" -> 24
            "VOL_DOWN", "VOLUME_DOWN" -> 25
            "MUTE", "VOLUME_MUTE" -> 164
            "PLAY_PAUSE", "MEDIA_PLAY_PAUSE" -> 85
            "NEXT", "MEDIA_NEXT" -> 87
            "PREV", "MEDIA_PREVIOUS" -> 88
            else -> null
        }
    }

    private fun handleRemoteKeyCommand(context: Context, rawKey: String) {
        val k = rawKey.trim().uppercase(Locale.US).removePrefix("KEYCODE_")
        if (k == "ASSIST" || k == "VOICE_ASSIST" || k == "AI" || k == "219" || k == "231") {
            mainHandler.post {
                NavSoundPlayer.playClick(context)
                DynamicIslandBus.triggerAssistant(context)
            }
            return
        }

        val androidKeyCode = resolveAndroidKeyCode(context, rawKey) ?: return

        if (androidKeyCode == 223 || androidKeyCode == 224) {
            executeHdmiSleepOrWakeup(context, sleep = (androidKeyCode == 223))
            return
        }

        mainHandler.post {
            NavSoundPlayer.playClick(context)
            when (androidKeyCode) {
                24 -> {
                    val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    am?.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0)
                    VolumeHudBus.notifyVolumeChanged()
                    return@post
                }
                25 -> {
                    val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    am?.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0)
                    VolumeHudBus.notifyVolumeChanged()
                    return@post
                }
                164 -> {
                    val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    am?.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, 0)
                    VolumeHudBus.notifyVolumeChanged()
                    return@post
                }
                85 -> {
                    val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    if (am != null) {
                        MediaStateBus.dispatchTransportAction("PLAY_PAUSE", am)
                        return@post
                    }
                }
                87 -> {
                    val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    if (am != null) {
                        MediaStateBus.dispatchTransportAction("NEXT", am)
                        return@post
                    }
                }
                88 -> {
                    val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    if (am != null) {
                        MediaStateBus.dispatchTransportAction("PREV", am)
                        return@post
                    }
                }
                82 -> {
                    val intent = Intent(context, LauncherActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                        putExtra("EXTRA_OPEN_CONTROL_CENTER", true)
                    }
                    try {
                        context.startActivity(intent)
                        return@post
                    } catch (_: Exception) {
                    }
                }
            }

            val handledInLauncher = if (androidKeyCode == 3) {
                false
            } else {
                DynamicIslandBus.onDispatchKeyInActivity?.invoke(androidKeyCode) == true
            }
            if (!handledInLauncher) {
                serverScope.launch {
                    ShellKeyController.sendKeyEvent(androidKeyCode)
                }
                if (androidKeyCode == 4) {
                    TvUiControllerBus.performNav("BACK")
                } else if (androidKeyCode == 3) {
                    TvUiControllerBus.performNav("HOME")
                } else {
                    val dirName = when (androidKeyCode) {
                        19 -> "UP"
                        20 -> "DOWN"
                        21 -> "LEFT"
                        22 -> "RIGHT"
                        23 -> "CENTER"
                        else -> ""
                    }
                    if (dirName.isNotEmpty()) {
                        val a11yOk = TvUiControllerBus.onInjectDpadAction?.invoke(dirName) == true
                        if (!a11yOk && dirName == "CENTER") {
                            ShellKeyController.sendKeyEvent(66)
                        }
                    }
                }
            }
        }
    }

    private fun handleRemoteAppLaunch(context: Context, rawTarget: String) {
        val t = rawTarget.trim()
        if (t.isEmpty()) return
        mainHandler.post {
            val lower = t.lowercase(Locale.US)
            val pm = context.packageManager
            val candidates = when {
                lower.contains("youtube") || lower == "yt" -> listOf(
                    "com.google.android.youtube.tv",
                    "com.liskovsoft.smarttubetv.beta",
                    "com.liskovsoft.smarttubetv",
                    "com.google.android.youtube"
                )
                lower.contains("kick") -> listOf(
                    "com.kick.mobile",
                    "com.kick.tv",
                    "tv.kick.android"
                )
                lower.contains("browser") || lower.contains("chrome") -> listOf(
                    "com.android.chrome",
                    "com.tvwebbrowser.v22",
                    "org.mozilla.tv.firefox",
                    "com.opera.browser"
                )
                else -> listOf(t)
            }

            for (pkg in candidates) {
                val intent = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg)
                if (intent != null) {
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        context.startActivity(intent)
                        return@post
                    } catch (_: Exception) {
                    }
                }
            }

            if (lower.contains("browser") || lower.contains("chrome")) {
                try {
                    val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com")).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(webIntent)
                } catch (_: Exception) {
                }
            }
        }
    }
}

object NavSoundPlayer {
    private var soundPool: SoundPool? = null
    private var clickSoundId: Int = 0
    @Volatile
    private var isSoundLoaded: Boolean = false
    @Volatile
    private var lastPlayRealtimeMs: Long = 0L
    @Volatile
    private var cachedEnabled: Boolean? = null

    fun isSoundEnabled(context: Context): Boolean {
        val cached = cachedEnabled
        if (cached != null) return cached
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val enabled = prefs.getBoolean("pref_nav_sound_enabled", true)
        cachedEnabled = enabled
        return enabled
    }

    fun setSoundEnabled(context: Context, enabled: Boolean) {
        cachedEnabled = enabled
        val prefs = context.applicationContext.getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putBoolean("pref_nav_sound_enabled", enabled).apply()
    }

    @Synchronized
    fun init(context: Context) {
        if (soundPool != null) return
        try {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ASSISTANCE_SONIFICATION)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val sp = SoundPool.Builder()
                .setMaxStreams(3)
                .setAudioAttributes(attrs)
                .build()
            sp.setOnLoadCompleteListener { _, sampleId, status ->
                if (status == 0 && sampleId == clickSoundId) {
                    isSoundLoaded = true
                }
            }
            clickSoundId = sp.load(context.applicationContext, R.raw.nav_click, 1)
            soundPool = sp
        } catch (_: Exception) {
        }
    }

    fun playClick(context: Context) {
        if (!isSoundEnabled(context)) return
        val now = SystemClock.elapsedRealtime()
        if (now - lastPlayRealtimeMs < 45L) return
        lastPlayRealtimeMs = now

        if (soundPool == null) {
            init(context)
        }
        val sp = soundPool ?: return
        if (isSoundLoaded && clickSoundId != 0) {
            try {
                sp.play(clickSoundId, 0.9f, 0.9f, 1, 0, 1.0f)
            } catch (_: Exception) {
            }
        }
    }
}

object ServiceAutoActivator {
    fun isNotificationListenerEnabled(context: Context): Boolean {
        return try {
            val pkg = context.packageName
            val flat = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners").orEmpty()
            flat.contains(pkg)
        } catch (_: Exception) {
            false
        }
    }

    fun openNotificationListenerSettings(context: Context): Boolean {
        val intents = listOf(
            Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"),
            Intent(Settings.ACTION_SETTINGS)
        )
        for (intent in intents) {
            try {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
                return true
            } catch (_: Exception) {
            }
        }
        return false
    }

    fun hasWriteSecureSettings(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.WRITE_SECURE_SETTINGS
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun ensureNotificationListenerInSecureSettings(context: Context) {
        if (!hasWriteSecureSettings(context)) return
        try {
            val appCtx = context.applicationContext
            val pkg = appCtx.packageName
            val cr = appCtx.contentResolver
            val notifFlat = "$pkg/$pkg.service.MediaSessionListenerService"
            val notifShort = "$pkg/.service.MediaSessionListenerService"
            val curNotif = Settings.Secure.getString(cr, "enabled_notification_listeners").orEmpty()
            if (!curNotif.contains(notifFlat)) {
                val base = if (curNotif.isBlank()) "" else "$curNotif:"
                Settings.Secure.putString(cr, "enabled_notification_listeners", "$base$notifFlat:$notifShort")
            }
        } catch (_: Exception) {
        }
    }

    fun ensureServicesActive(context: Context) {
        val appCtx = context.applicationContext
        val pkg = appCtx.packageName
        val notifComp = ComponentName(appCtx, MediaSessionListenerService::class.java)

        try {
            val pm = appCtx.packageManager
            if (pm.getComponentEnabledSetting(notifComp) == PackageManager.COMPONENT_ENABLED_STATE_DISABLED) {
                pm.setComponentEnabledSetting(
                    notifComp,
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                    PackageManager.DONT_KILL_APP
                )
            }
        } catch (_: Exception) {
        }

        if (hasWriteSecureSettings(appCtx)) {
            val cr = appCtx.contentResolver
            val accFlat = "$pkg/$pkg.service.KeyMapperAccessibilityService"
            try {
                ensureNotificationListenerInSecureSettings(appCtx)

                val curAcc = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
                if (!curAcc.contains(pkg)) {
                    val updatedAcc = if (curAcc.isBlank()) accFlat else "$curAcc:$accFlat"
                    Settings.Secure.putString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, updatedAcc)
                    Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
                }

                val ourAssist = "$pkg/.ui.LauncherActivity"
                if (Settings.Secure.getString(cr, "assistant") != ourAssist) {
                    Settings.Secure.putString(cr, "assistant", ourAssist)
                }
                val curVoiceInteractor = Settings.Secure.getString(cr, "voice_interaction_service").orEmpty()
                if (curVoiceInteractor.isBlank()) {
                    Settings.Secure.putString(
                        cr,
                        "voice_interaction_service",
                        "com.google.android.katniss/com.google.android.katniss.search.serviceapi.KatnissVoiceInteractionService"
                    )
                }
            } catch (_: Exception) {
            }
        }

        try {
            Settings.System.putInt(appCtx.contentResolver, Settings.System.SOUND_EFFECTS_ENABLED, 0)
        } catch (_: Exception) {
        }
        NavSoundPlayer.init(appCtx)

        if (MediaSessionListenerService.instance == null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try {
                NotificationListenerService.requestRebind(notifComp)
            } catch (_: Exception) {
            }
        }
    }
}

object MediaStateBus {
    private val _state = MutableStateFlow(NowPlayingSnapshot())
    val state: StateFlow<NowPlayingSnapshot> = _state.asStateFlow()

    @Volatile
    var activeController: MediaController? = null

    @Volatile
    var lastForegroundMediaPkg: String = ""

    private val mainHandler = Handler(Looper.getMainLooper())
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val artUriCache = object : LruCache<String, Bitmap>(24) {}
    private var currentArtUri: String = ""
    private var lastFetchedArtUri: String = ""

    private var trackStartRealtime: Long = SystemClock.elapsedRealtime()
    private var lastPausedRealtime: Long = 0L
    private var lastLauncherPauseRealtime: Long = 0L
    private var currentTrackIdentity: String = ""
    private var currentCoverSignature: Int = 0
    private var currentControllerCallback: MediaController.Callback? = null
    private var sessionListenerRegistered = false

    private var lastObservedRawPos: Long = -1L
    private var lastObservedRawRealtime: Long = 0L

    private var dismissedTrackIdentity: String = ""
    private var dismissedAtRealtime: Long = 0L
    private var pausedByLauncherControl: Boolean = false

    private val catalogLookupCache = object : LruCache<String, Pair<String, Long>>(40) {}
    private var lastCatalogLookupKey: String = ""

    val UNIVERSAL_MEDIA_BROADCAST_ACTIONS = listOf(
        "com.android.music.metachanged",
        "com.android.music.playstatechanged",
        "com.android.music.playbackcomplete",
        "com.android.music.queuechanged",
        "com.spotify.music.metadatachanged",
        "com.spotify.music.playbackstatechanged",
        "com.spotify.tv.android.metadatachanged",
        "com.spotify.tv.android.playbackstatechanged",
        "com.soundcloud.android.metachanged",
        "com.soundcloud.android.playstatechanged",
        "deezer.android.app.metachanged",
        "deezer.android.app.playstatechanged",
        "com.aspiro.tidal.metachanged",
        "ru.yandex.music.metachanged",
        "ru.yandex.music.playstatechanged",
        "org.videolan.vlc.remote.PlayPause",
        "com.maxmpz.audioplayer.TRACK_CHANGED",
        "com.maxmpz.audioplayer.STATUS_CHANGED",
        "com.aimp.player.metachanged",
        "com.miui.player.metachanged",
        "com.miui.player.playstatechanged",
        "com.sec.android.app.music.metachanged",
        "com.htc.music.metachanged",
        "com.sonyericsson.music.metachanged",
        "fm.last.android.metachanged",
        "com.amazon.mp3.metachanged"
    )

    @Volatile
    private var hasObservedActivePlaybackSinceBoot: Boolean = false

    fun isExcludedVideoPackage(pkg: String): Boolean {
        val p = pkg.lowercase(Locale.ROOT)
        return p.contains("youtube") ||
            p.contains("smarttube") ||
            p.contains("newpipe") ||
            p.contains("revanced") ||
            p.contains("videomanager") ||
            p.contains("kick") ||
            p.contains("twitch") ||
            p.contains("netflix") ||
            p.contains("kinopoisk") ||
            p.contains("hdvideobox") ||
            p.contains("lampa")
    }

    fun isKnownMediaPackage(pkg: String): Boolean {
        if (pkg.isBlank() || isExcludedVideoPackage(pkg)) return false
        val p = pkg.lowercase(Locale.ROOT)
        return p.contains("spotify") ||
            p.contains("soundcloud") ||
            p.contains("music") ||
            p.contains("deezer") ||
            p.contains("tidal") ||
            p.contains("tunein") ||
            p.contains("vlc") ||
            p.contains("aimp") ||
            p.contains("audioplayer") ||
            p.contains("poweramp") ||
            p.contains("yandex") ||
            p.contains("vkontakte") ||
            p.contains("apple") ||
            p.contains("audio") ||
            p.contains("radio")
    }

    fun onMediaAppOpened(pkg: String) {
        if (pkg.isBlank()) return
        if (isKnownMediaPackage(pkg)) {
            lastForegroundMediaPkg = pkg
            pausedByLauncherControl = false
            dismissedTrackIdentity = ""
            val ctrl = activeController
            if (ctrl != null && ctrl.packageName != pkg && !isActivelyPlayingState(ctrl.playbackState?.state)) {
                unregisterCurrentCallback()
                activeController = null
            }
        }
    }

    /**
     * Мгновенно подставляет трек, обложку и длительность из каталога Deezer / iTunes,
     * когда пользователь запускает песню голосом или выбирает карточку трека внутри приложения!
     */
    fun seedTrackFromQuery(context: Context, pkg: String, rawQuery: String) {
        val clean = rawQuery.trim()
        if (clean.length < 2) return
        onMediaAppOpened(pkg)
        val appLabel = resolveAppLabel(context, pkg)
        updatePlayingFlag(true)
        updateMetadata(
            context = context,
            title = clean,
            artist = appLabel,
            sourcePackage = pkg,
            sourceAppName = appLabel,
            cover = null,
            durationMs = -1L,
            positionMs = 0L
        )
    }

    fun resolveActiveMediaPackage(context: Context): String {
        try {
            val mbr = Settings.Secure.getString(context.contentResolver, "media_button_receiver").orEmpty()
            if (mbr.contains("/")) {
                val mbrPkg = mbr.substringBefore("/").trim()
                if (mbrPkg.isNotEmpty() && mbrPkg != context.packageName && !isExcludedVideoPackage(mbrPkg)) {
                    return mbrPkg
                }
            }
        } catch (_: Exception) {
        }
        if (lastForegroundMediaPkg.isNotEmpty()) {
            return lastForegroundMediaPkg
        }
        val curPkg = _state.value.sourcePackage
        if (curPkg.isNotEmpty()) {
            return curPkg
        }
        return ""
    }

    private fun normalizeArtUri(rawUri: String): String {
        val trimmed = rawUri.trim()
        if (trimmed.startsWith("spotify:image:")) {
            val imageId = trimmed.removePrefix("spotify:image:").trim()
            if (imageId.isNotEmpty()) {
                return "https://i.scdn.co/image/$imageId"
            }
        }
        return trimmed
    }

    fun computeBitmapSignature(bmp: Bitmap?): Int {
        if (bmp == null || bmp.isRecycled) return 0
        val w = bmp.width
        val h = bmp.height
        if (w <= 0 || h <= 0) return 0
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && bmp.config == Bitmap.Config.HARDWARE) {
            val gen = bmp.generationId
            val hash = ((w * 31) xor h) xor (gen * 31)
            return if (hash == 0) 1 else hash
        }
        return try {
            var hash = (w * 31) xor h
            hash = (hash * 31) xor bmp.getPixel(w / 2, h / 2)
            hash = (hash * 31) xor bmp.getPixel(w / 4, h / 4)
            hash = (hash * 31) xor bmp.getPixel((w * 3) / 4, h / 4)
            hash = (hash * 31) xor bmp.getPixel(w / 4, (h * 3) / 4)
            hash = (hash * 31) xor bmp.getPixel((w * 3) / 4, (h * 3) / 4)
            if (hash == 0) 1 else hash
        } catch (_: Exception) {
            val gen = bmp.generationId
            if (gen == 0) 1 else gen
        }
    }

    fun safeScaleBitmap(raw: Bitmap?): Bitmap? {
        if (raw == null || raw.isRecycled) return null
        return try {
            val src = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && raw.config == Bitmap.Config.HARDWARE) {
                raw.copy(Bitmap.Config.ARGB_8888, false) ?: raw
            } else {
                raw
            }
            val scaled = Bitmap.createScaledBitmap(src, 112, 112, true)
            if (src !== raw && src !== scaled && !src.isRecycled) {
                src.recycle()
            }
            scaled
        } catch (_: Exception) {
            raw
        }
    }

    fun getCurrentCoverSignature(): Int = currentCoverSignature

    private fun isActivelyPlayingState(stateCode: Int?): Boolean {
        return stateCode == PlaybackState.STATE_PLAYING ||
            stateCode == PlaybackState.STATE_BUFFERING ||
            stateCode == PlaybackState.STATE_CONNECTING ||
            stateCode == PlaybackState.STATE_FAST_FORWARDING ||
            stateCode == PlaybackState.STATE_REWINDING ||
            stateCode == PlaybackState.STATE_SKIPPING_TO_NEXT ||
            stateCode == PlaybackState.STATE_SKIPPING_TO_PREVIOUS
    }

    private fun unregisterCurrentCallback() {
        val prev = activeController
        val prevCb = currentControllerCallback
        if (prev != null && prevCb != null) {
            try {
                prev.unregisterCallback(prevCb)
            } catch (_: Exception) {
            }
        }
        currentControllerCallback = null
    }

    fun queryMediaSessionManagerDirect(context: Context) {
        try {
            val appCtx = context.applicationContext
            ServiceAutoActivator.ensureNotificationListenerInSecureSettings(appCtx)
            val msm = appCtx.getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager ?: return
            val comp = ComponentName(appCtx, MediaSessionListenerService::class.java)

            if (!sessionListenerRegistered) {
                try {
                    val sessionListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
                        selectAndBindBestController(appCtx, list)
                    }
                    msm.addOnActiveSessionsChangedListener(sessionListener, comp, mainHandler)
                    sessionListenerRegistered = true
                } catch (_: Exception) {
                }
            }

            val sessions = msm.getActiveSessions(comp)
            selectAndBindBestController(appCtx, sessions)
        } catch (_: Exception) {
        }
    }

    private fun selectAndBindBestController(context: Context, controllers: List<MediaController>?) {
        if (controllers.isNullOrEmpty()) return
        val others = controllers.filter { it.packageName != context.packageName && !isExcludedVideoPackage(it.packageName) }
        if (others.isEmpty()) return

        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        val musicActive = am?.isMusicActive == true
        val activeMediaPkg = resolveActiveMediaPackage(context)

        val playing = others.firstOrNull {
            it.playbackState?.state == PlaybackState.STATE_PLAYING && it.packageName == activeMediaPkg
        } ?: others.firstOrNull {
            it.playbackState?.state == PlaybackState.STATE_PLAYING
        } ?: others.firstOrNull {
            isActivelyPlayingState(it.playbackState?.state)
        }

        if (playing != null) {
            bindController(context, playing)
            return
        }

        if (musicActive) {
            val byActivePkg = if (activeMediaPkg.isNotEmpty()) {
                others.firstOrNull { it.packageName == activeMediaPkg }
            } else null

            val byKnownMedia = others.firstOrNull {
                isKnownMediaPackage(it.packageName) && it.metadata != null
            } ?: others.firstOrNull {
                isKnownMediaPackage(it.packageName)
            }

            val byMetadata = others.firstOrNull { it.metadata != null } ?: others.firstOrNull()
            val candidate = byActivePkg ?: byKnownMedia ?: byMetadata
            if (candidate != null) {
                bindController(context, candidate)
                return
            }
        }

        val cur = _state.value
        if (cur.hasActiveSession && cur.sourcePackage.isNotEmpty()) {
            val matching = others.firstOrNull { it.packageName == cur.sourcePackage }
            if (matching != null) {
                bindController(context, matching)
                return
            }
        }
        val anyWithMeta = others.firstOrNull { it.metadata != null }
        if (anyWithMeta != null && cur.title.isBlank()) {
            bindController(context, anyWithMeta)
        }
    }

    fun bindController(context: Context, controller: MediaController) {
        val appCtx = context.applicationContext
        val prev = activeController
        if (prev != null && prev.sessionToken == controller.sessionToken) {
            syncControllerImmediate(appCtx, prev)
            return
        }
        unregisterCurrentCallback()
        activeController = controller

        val cb = object : MediaController.Callback() {
            override fun onPlaybackStateChanged(state: PlaybackState?) {
                if (state != null) {
                    val am = appCtx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    val musicActive = am?.isMusicActive == true
                    val playing = isActivelyPlayingState(state.state) || (musicActive && !pausedByLauncherControl)
                    if (playing) pausedByLauncherControl = false
                    updatePositionOnly(
                        positionMs = state.position,
                        positionUpdateRealtime = state.lastPositionUpdateTime,
                        speed = state.playbackSpeed,
                        isPlaying = playing
                    )
                }
            }

            override fun onMetadataChanged(metadata: MediaMetadata?) {
                syncControllerImmediate(appCtx, controller)
            }
        }
        currentControllerCallback = cb
        try {
            controller.registerCallback(cb, mainHandler)
        } catch (_: Exception) {
        }

        syncControllerImmediate(appCtx, controller)
    }

    fun syncControllerImmediate(context: Context, controller: MediaController) {
        try {
            val meta = controller.metadata
            val pb = controller.playbackState
            val cur = _state.value
            val pkg = controller.packageName.orEmpty().ifEmpty { cur.sourcePackage }
            if (isExcludedVideoPackage(pkg)) return

            val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            val musicActive = am?.isMusicActive == true
            val pbPlaying = isActivelyPlayingState(pb?.state)
            val now = SystemClock.elapsedRealtime()

            if (musicActive && pausedByLauncherControl && (now - lastLauncherPauseRealtime) > 2500L) {
                pausedByLauncherControl = false
                dismissedTrackIdentity = ""
            }

            if (!pbPlaying && musicActive) {
                val activePkg = resolveActiveMediaPackage(context)
                if (activePkg.isNotEmpty() && pkg.isNotEmpty() && activePkg != pkg) {
                    if (activeController === controller) {
                        unregisterCurrentCallback()
                        activeController = null
                    }
                    return
                }
            }

            val effectivePlaying = pbPlaying || (musicActive && !pausedByLauncherControl)

            if (!cur.hasActiveSession && !effectivePlaying) {
                return
            }

            val appName = resolveAppLabel(context, pkg)
            var title = ""
            var artist = ""
            var dur = -1L
            var artUri = ""
            var newCover: Bitmap? = null
            var newSig = 0

            if (meta != null) {
                val desc = meta.description
                title = (meta.getString(MediaMetadata.METADATA_KEY_TITLE)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
                    ?: desc?.title?.toString()).orEmpty().trim()
                artist = (meta.getString(MediaMetadata.METADATA_KEY_ARTIST)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_AUTHOR)
                    ?: desc?.subtitle?.toString()).orEmpty().trim()
                val d = meta.getLong(MediaMetadata.METADATA_KEY_DURATION)
                if (d > 0L) dur = d

                val rawUriStr = (meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_ART_URI)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)
                    ?: desc?.iconUri?.toString()).orEmpty()
                artUri = normalizeArtUri(rawUriStr)

                val rawArt = meta.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                    ?: meta.getBitmap(MediaMetadata.METADATA_KEY_ART)
                    ?: meta.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                    ?: desc?.iconBitmap
                if (rawArt != null) {
                    val sig = computeBitmapSignature(rawArt)
                    if (sig != 0 && (sig != currentCoverSignature || cur.coverBitmap == null)) {
                        newCover = safeScaleBitmap(rawArt)
                        newSig = sig
                    }
                }
            }

            var pos = -1L
            var posTime = 0L
            var spd = 1.0f
            if (pb != null) {
                pos = pb.position
                posTime = pb.lastPositionUpdateTime
                spd = pb.playbackSpeed
            }
            updatePlayingFlag(effectivePlaying)

            if (title.isNotEmpty() || artist.isNotEmpty() || newCover != null || artUri.isNotEmpty() || pos >= 0L || dur > 0L || effectivePlaying) {
                updateMetadata(
                    context = context,
                    title = title,
                    artist = artist,
                    sourcePackage = pkg,
                    sourceAppName = appName,
                    cover = newCover,
                    coverSignature = newSig,
                    artUri = artUri,
                    durationMs = dur,
                    positionMs = pos,
                    positionUpdateRealtime = posTime,
                    speed = spd
                )
            }
        } catch (_: Exception) {
        }
    }

    fun ingestNotification(
        context: Context,
        pkg: String,
        notif: Notification,
        requireActivePlaybackOrSession: Boolean = false,
        eventTexts: List<CharSequence>? = null
    ) {
        try {
            val appCtx = context.applicationContext
            val p = pkg.lowercase()
            if (pkg == appCtx.packageName || isExcludedVideoPackage(pkg) ||
                p.startsWith("com.android.packageinstaller") ||
                p.startsWith("com.google.android.packageinstaller") ||
                p.startsWith("com.android.vending") ||
                p.startsWith("com.android.systemui") ||
                p.startsWith("com.android.settings")
            ) {
                return
            }

            val extras = notif.extras ?: Bundle()
            @Suppress("DEPRECATION")
            var sessionToken: MediaSession.Token? = (extras.getParcelable<Parcelable>(Notification.EXTRA_MEDIA_SESSION) as? MediaSession.Token)
                ?: (extras.getParcelable<Parcelable>("android.support.v4.media.session.EXTRA_SESSION_TOKEN") as? MediaSession.Token)
            if (sessionToken == null) {
                try {
                    for (k in extras.keySet()) {
                        @Suppress("DEPRECATION")
                        val v = extras.get(k)
                        if (v is MediaSession.Token) {
                            sessionToken = v
                            break
                        }
                    }
                } catch (_: Exception) {
                }
            }

            val isKnownMedia = isKnownMediaPackage(p) || notif.category == Notification.CATEGORY_TRANSPORT
            if (sessionToken == null && !isKnownMedia) {
                return
            }

            if (isKnownMediaPackage(p)) {
                lastForegroundMediaPkg = pkg
            }

            if (sessionToken != null) {
                val curCtrl = activeController
                if (curCtrl == null || curCtrl.sessionToken != sessionToken) {
                    bindController(appCtx, MediaController(appCtx, sessionToken))
                }
            }

            val ctrl = activeController?.takeIf { it.packageName == pkg || sessionToken != null }
            val pb = ctrl?.playbackState
            val am = appCtx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            val isMusicCurrentlyActive = am?.isMusicActive == true
            val isCtrlPlaying = isActivelyPlayingState(pb?.state)
            val effectivePlaying = isCtrlPlaying || (isMusicCurrentlyActive && !pausedByLauncherControl)

            if (requireActivePlaybackOrSession && !_state.value.hasActiveSession && !effectivePlaying) {
                return
            }

            var notifTitle = (extras.getCharSequence(Notification.EXTRA_TITLE)
                ?: extras.getCharSequence(Notification.EXTRA_TITLE_BIG)
                ?: extras.getCharSequence("android.conversationTitle"))?.toString()?.trim().orEmpty()
            var notifArtist = (extras.getCharSequence(Notification.EXTRA_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_SUB_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_SUMMARY_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_INFO_TEXT))?.toString()?.trim().orEmpty()
            val appName = resolveAppLabel(appCtx, pkg)

            if (notifTitle.isBlank()) {
                val rvStrings = extractStringsFromRemoteViews(appCtx, notif)
                val filtered = rvStrings.filter { s ->
                    s.isNotBlank() && !s.equals(appName, ignoreCase = true) && !s.matches(Regex("^[0-9]{1,2}:[0-9]{2}( / [0-9]{1,2}:[0-9]{2})?$"))
                }
                if (filtered.isNotEmpty()) {
                    notifTitle = filtered[0]
                    if (notifArtist.isBlank() && filtered.size >= 2) {
                        notifArtist = filtered[1]
                    }
                }
            }
            if (notifTitle.isBlank() && !eventTexts.isNullOrEmpty()) {
                val cleaned = eventTexts.map { it.toString().trim() }
                    .filter { it.isNotBlank() && !it.equals(appName, ignoreCase = true) }
                if (cleaned.isNotEmpty()) {
                    notifTitle = cleaned[0]
                    if (notifArtist.isBlank() && cleaned.size >= 2) {
                        notifArtist = cleaned[1]
                    }
                }
            }
            if (notifTitle.isBlank() && !notif.tickerText.isNullOrBlank()) {
                notifTitle = notif.tickerText.toString().trim()
            }

            var durationMs = -1L
            var posMs = -1L
            var posRealtime = 0L
            var speed = 1.0f
            var artUri = ""
            var metaRawArt: Bitmap? = null

            if (ctrl != null) {
                val meta = ctrl.metadata
                if (meta != null) {
                    val desc = meta.description
                    val metaTitle = (meta.getString(MediaMetadata.METADATA_KEY_TITLE)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
                        ?: desc?.title?.toString())?.trim()
                    val metaArtist = (meta.getString(MediaMetadata.METADATA_KEY_ARTIST)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
                        ?: desc?.subtitle?.toString())?.trim()

                    if (notifTitle.isBlank() && !metaTitle.isNullOrBlank()) notifTitle = metaTitle
                    if (notifArtist.isBlank() && !metaArtist.isNullOrBlank()) notifArtist = metaArtist

                    val d = meta.getLong(MediaMetadata.METADATA_KEY_DURATION)
                    if (d > 0L) durationMs = d

                    val rawUriStr = (meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_ART_URI)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)
                        ?: desc?.iconUri?.toString()).orEmpty()
                    artUri = normalizeArtUri(rawUriStr)

                    metaRawArt = meta.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                        ?: meta.getBitmap(MediaMetadata.METADATA_KEY_ART)
                        ?: meta.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                        ?: desc?.iconBitmap
                }

                if (pb != null) {
                    posMs = pb.position
                    posRealtime = pb.lastPositionUpdateTime
                    speed = pb.playbackSpeed
                }
                updatePlayingFlag(effectivePlaying)
            } else if (isMusicCurrentlyActive) {
                updatePlayingFlag(true)
            }

            if (durationMs <= 0L) {
                val progMax = extras.getInt(Notification.EXTRA_PROGRESS_MAX, 0)
                if (progMax > 1000) {
                    durationMs = progMax.toLong()
                    val progCur = extras.getInt(Notification.EXTRA_PROGRESS, -1)
                    if (posMs < 0L && progCur >= 0) {
                        posMs = progCur.toLong()
                    }
                }
            }

            @Suppress("DEPRECATION")
            var rawCandidate: Bitmap? = (extras.getParcelable<Parcelable>(Notification.EXTRA_LARGE_ICON_BIG) as? Bitmap)
                ?: (extras.getParcelable<Parcelable>(Notification.EXTRA_LARGE_ICON) as? Bitmap)
                ?: (extras.getParcelable<Parcelable>(Notification.EXTRA_PICTURE) as? Bitmap)

            if (rawCandidate == null) {
                val largeIcon = notif.getLargeIcon()
                if (largeIcon != null) {
                    val d = largeIcon.loadDrawable(appCtx)
                    if (d is BitmapDrawable && d.bitmap != null) {
                        rawCandidate = d.bitmap
                    } else if (d != null) {
                        rawCandidate = drawableToSmallBitmap(d)
                    }
                }
            }

            if (rawCandidate == null) {
                rawCandidate = metaRawArt
            }

            var coverBmp: Bitmap? = null
            var sig = 0
            if (rawCandidate != null) {
                sig = computeBitmapSignature(rawCandidate)
                val curCover = _state.value.coverBitmap
                if (sig != 0 && sig == currentCoverSignature && curCover != null) {
                    coverBmp = curCover
                } else {
                    coverBmp = safeScaleBitmap(rawCandidate)
                }
            }

            if (notifTitle.isEmpty() && notifArtist.isEmpty() && coverBmp == null && artUri.isEmpty()) return

            updateMetadata(
                context = appCtx,
                title = notifTitle,
                artist = notifArtist,
                sourcePackage = pkg,
                sourceAppName = appName,
                cover = coverBmp,
                coverSignature = sig,
                artUri = artUri,
                durationMs = durationMs,
                positionMs = posMs,
                positionUpdateRealtime = posRealtime,
                speed = speed
            )
        } catch (_: Exception) {
        }
    }

    @Suppress("DEPRECATION")
    private fun extractStringsFromRemoteViews(context: Context, notif: Notification): List<String> {
        val result = mutableListOf<String>()
        val viewsToTry = listOfNotNull(notif.bigContentView, notif.contentView)
        for (rv in viewsToTry) {
            try {
                val container = FrameLayout(context)
                val applied = rv.apply(context, container)
                collectTextViewsFromViewTree(applied, result)
                if (result.isNotEmpty()) break
            } catch (_: Exception) {
            }
        }
        return result
    }

    private fun collectTextViewsFromViewTree(view: View?, out: MutableList<String>) {
        if (view == null) return
        if (view is TextView) {
            val t = view.text?.toString()?.trim().orEmpty()
            if (t.isNotEmpty() && !out.contains(t)) {
                out.add(t)
            }
        } else if (view is ViewGroup) {
            for (i in 0 until view.childCount) {
                collectTextViewsFromViewTree(view.getChildAt(i), out)
            }
        }
    }

    fun handleMediaBroadcastIntent(context: Context, intent: Intent) {
        try {
            val act = intent.action.orEmpty()
            if (intent.hasExtra("playing")) {
                updatePlayingFlag(intent.getBooleanExtra("playing", false))
            } else if (intent.hasExtra("playstate")) {
                updatePlayingFlag(intent.getBooleanExtra("playstate", false))
            } else if (intent.hasExtra("isPlaying")) {
                updatePlayingFlag(intent.getBooleanExtra("isPlaying", false))
            }
            val rawTrack = (intent.getStringExtra("track")
                ?: intent.getStringExtra("title")
                ?: intent.getStringExtra("android.intent.extra.TITLE")
                ?: intent.getStringExtra("name")).orEmpty().trim()
            val rawArtist = (intent.getStringExtra("artist")
                ?: intent.getStringExtra("author")
                ?: intent.getStringExtra("albumArtist")
                ?: intent.getStringExtra("album")
                ?: intent.getStringExtra("android.intent.extra.ARTIST")).orEmpty().trim()
            val duration = when {
                intent.hasExtra("duration") -> intent.getLongExtra("duration", -1L).let { if (it in 1..1000) it * 1000L else it }
                intent.hasExtra("length") -> intent.getLongExtra("length", -1L).let { if (it in 1..1000) it * 1000L else it }
                else -> -1L
            }
            val position = when {
                intent.hasExtra("position") -> intent.getLongExtra("position", -1L)
                intent.hasExtra("elapsed") -> intent.getLongExtra("elapsed", -1L)
                else -> -1L
            }
            val pkg = intent.`package` ?: when {
                act.contains("spotify") -> "com.spotify.tv.android"
                act.contains("soundcloud") -> "com.soundcloud.android"
                act.contains("deezer") -> "deezer.android.app"
                act.contains("yandex") -> "ru.yandex.music"
                act.contains("vlc") -> "org.videolan.vlc"
                act.contains("maxmpz") -> "com.maxmpz.audioplayer"
                act.contains("aimp") -> "com.aimp.player"
                act.contains("miui") -> "com.miui.player"
                else -> resolveActiveMediaPackage(context)
            }
            if (rawTrack.isNotEmpty() || rawArtist.isNotEmpty()) {
                val appLabel = resolveAppLabel(context, pkg)
                updateMetadata(
                    context = context,
                    title = rawTrack,
                    artist = rawArtist,
                    sourcePackage = pkg,
                    sourceAppName = appLabel,
                    cover = null,
                    durationMs = duration,
                    positionMs = position
                )
            }
        } catch (_: Exception) {
        }
    }

    private fun drawableToSmallBitmap(d: Drawable): Bitmap? {
        return try {
            if (d is BitmapDrawable && d.bitmap != null) {
                safeScaleBitmap(d.bitmap)
            } else {
                val bmp = Bitmap.createBitmap(112, 112, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bmp)
                d.setBounds(0, 0, 112, 112)
                d.draw(canvas)
                bmp
            }
        } catch (_: Exception) {
            null
        }
    }

    @Volatile
    private var lastDumpsysPollRealtime: Long = 0L

    @Volatile
    private var isDumpsysPolling: Boolean = false

    @Volatile
    private var lastDumpsysValidMetadataRealtime: Long = 0L

    private data class DumpedMediaSession(
        val pkg: String,
        val isActive: Boolean,
        val stateCode: Int,
        val positionMs: Long,
        val speed: Float,
        val updatedRealtime: Long,
        val title: String,
        val artist: String
    )

    fun hasRealControllerMetadata(): Boolean {
        val now = SystemClock.elapsedRealtime()
        if (lastDumpsysValidMetadataRealtime > 0L && (now - lastDumpsysValidMetadataRealtime) < 8000L && _state.value.title.isNotBlank()) {
            return true
        }
        return try {
            val meta = activeController?.metadata ?: return false
            val t = (meta.getString(MediaMetadata.METADATA_KEY_TITLE)
                ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
                ?: meta.description?.title?.toString()).orEmpty().trim()
            t.isNotEmpty()
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Обход системной блокировки NotificationListenerService на 1 ГБ ОЗУ (ActivityManager.isLowRamDevice() == true):
     * При выданном через ADB разрешении `pm grant com.mitv.customlauncher android.permission.DUMP`
     * напрямую читает системный стек `/system/bin/dumpsys media_session` за ~10 мс и получает точный трек,
     * исполнителя, статус воспроизведения и секунду трека из ядра Android!
     */
    fun pollDumpsysMediaSessionAsync(context: Context, force: Boolean = false) {
        val now = SystemClock.elapsedRealtime()
        if (!force && (now - lastDumpsysPollRealtime) < 1200L) return
        if (isDumpsysPolling) return
        lastDumpsysPollRealtime = now
        isDumpsysPolling = true

        val appCtx = context.applicationContext
        ioScope.launch {
            try {
                val proc = ProcessBuilder("/system/bin/dumpsys", "media_session")
                    .redirectErrorStream(true)
                    .start()
                val output = proc.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                proc.waitFor()
                if (output.isBlank() || output.contains("Permission Denial")) {
                    return@launch
                }

                val parsedSessions = parseDumpsysMediaSessionOutput(output, appCtx.packageName)
                if (parsedSessions.isEmpty()) return@launch

                val am = appCtx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                val musicActive = am?.isMusicActive == true
                val activePkg = resolveActiveMediaPackage(appCtx)

                val best = parsedSessions.firstOrNull {
                    isActivelyPlayingState(it.stateCode) && it.title.isNotEmpty() && it.pkg == activePkg
                } ?: parsedSessions.firstOrNull {
                    isActivelyPlayingState(it.stateCode) && it.title.isNotEmpty()
                } ?: parsedSessions.firstOrNull {
                    isActivelyPlayingState(it.stateCode)
                } ?: if (musicActive) {
                    parsedSessions.firstOrNull { it.pkg == activePkg && it.title.isNotEmpty() }
                        ?: parsedSessions.firstOrNull { it.isActive && it.title.isNotEmpty() }
                        ?: parsedSessions.firstOrNull { it.title.isNotEmpty() }
                } else {
                    parsedSessions.firstOrNull { it.isActive && it.title.isNotEmpty() && it.stateCode == PlaybackState.STATE_PAUSED }
                }

                if (best != null) {
                    val appLabel = resolveAppLabel(appCtx, best.pkg)
                    val hasRealTitle = best.title.isNotBlank() && !best.title.equals(appLabel, ignoreCase = true)
                    val activelyPlaying = isActivelyPlayingState(best.stateCode)
                    if (activelyPlaying && hasRealTitle) {
                        hasObservedActivePlaybackSinceBoot = true
                    }
                    val isPlayingNow = activelyPlaying || (hasObservedActivePlaybackSinceBoot && musicActive && best.pkg == activePkg && best.stateCode != PlaybackState.STATE_PAUSED && !pausedByLauncherControl)
                    // После перезагрузки приставки не показываем старую/спящую сессию без реального воспроизведения и без названия трека!
                    if (!hasRealTitle || (!isPlayingNow && !hasObservedActivePlaybackSinceBoot)) {
                        return@launch
                    }
                    lastDumpsysValidMetadataRealtime = SystemClock.elapsedRealtime()
                    if (isKnownMediaPackage(best.pkg)) {
                        lastForegroundMediaPkg = best.pkg
                    }
                    mainHandler.post {
                        updatePlayingFlag(isPlayingNow)
                        updateMetadata(
                            context = appCtx,
                            title = best.title,
                            artist = best.artist.ifEmpty { appLabel },
                            sourcePackage = best.pkg,
                            sourceAppName = appLabel,
                            cover = null,
                            durationMs = -1L,
                            positionMs = best.positionMs,
                            positionUpdateRealtime = best.updatedRealtime,
                            speed = best.speed
                        )
                    }
                }
            } catch (_: Exception) {
            } finally {
                isDumpsysPolling = false
            }
        }
    }

    private fun parseDumpsysMediaSessionOutput(rawDump: String, ownPkg: String): List<DumpedMediaSession> {
        val results = mutableListOf<DumpedMediaSession>()
        var curPkg = ""
        var curActive = false
        var curStateCode = 0
        var curPosMs = -1L
        var curSpeed = 1.0f
        var curUpdated = 0L
        var curTitle = ""
        var curArtist = ""

        fun flushCurrent() {
            if (curPkg.isNotEmpty() && curPkg != ownPkg && !isExcludedVideoPackage(curPkg) && (curTitle.isNotEmpty() || curStateCode != 0)) {
                results.add(
                    DumpedMediaSession(
                        pkg = curPkg,
                        isActive = curActive,
                        stateCode = curStateCode,
                        positionMs = curPosMs,
                        speed = curSpeed,
                        updatedRealtime = curUpdated,
                        title = curTitle,
                        artist = curArtist
                    )
                )
            }
            curPkg = ""
            curActive = false
            curStateCode = 0
            curPosMs = -1L
            curSpeed = 1.0f
            curUpdated = 0L
            curTitle = ""
            curArtist = ""
        }

        val stateRegex = Regex("state=(\\d+)")
        val posRegex = Regex("position=(-?\\d+)")
        val speedRegex = Regex("speed=([0-9.]+)")
        val updatedRegex = Regex("updated=(\\d+)")

        for (rawLine in rawDump.lineSequence()) {
            val line = rawLine.trim()
            if (line.isEmpty()) continue

            if (line.startsWith("package=")) {
                val newPkg = line.removePrefix("package=").trim()
                if (curPkg.isNotEmpty() && curPkg != newPkg) {
                    flushCurrent()
                }
                curPkg = newPkg
            } else if (line.startsWith("active=")) {
                curActive = line.removePrefix("active=").trim().equals("true", ignoreCase = true)
            } else if (line.startsWith("state=PlaybackState")) {
                curStateCode = stateRegex.find(line)?.groupValues?.getOrNull(1)?.toIntOrNull() ?: 0
                curPosMs = posRegex.find(line)?.groupValues?.getOrNull(1)?.toLongOrNull() ?: -1L
                curSpeed = speedRegex.find(line)?.groupValues?.getOrNull(1)?.toFloatOrNull() ?: 1.0f
                curUpdated = updatedRegex.find(line)?.groupValues?.getOrNull(1)?.toLongOrNull() ?: 0L
            } else if (line.startsWith("metadata:") && line.contains("description=")) {
                val descRaw = line.substringAfter("description=").trim()
                if (descRaw.isNotEmpty() && !descRaw.startsWith("null, null")) {
                    val parts = descRaw.split(", ")
                    val rawT = parts.getOrNull(0)?.trim().orEmpty()
                    val rawA = parts.getOrNull(1)?.trim().orEmpty()
                    if (rawT.isNotEmpty() && !rawT.equals("null", ignoreCase = true)) {
                        curTitle = rawT
                    }
                    if (rawA.isNotEmpty() && !rawA.equals("null", ignoreCase = true)) {
                        curArtist = rawA
                    }
                }
            }
        }
        flushCurrent()
        return results
    }

    fun resolveAppLabel(context: Context, pkg: String): String {
        if (pkg.isBlank()) return ""
        return try {
            val ai = context.packageManager.getApplicationInfo(pkg, 0)
            context.packageManager.getApplicationLabel(ai).toString()
        } catch (_: Exception) {
            when {
                pkg.lowercase().contains("spotify") -> "Spotify"
                pkg.lowercase().contains("mediashell") -> "Chromecast"
                pkg.lowercase().contains("soundcloud") -> "SoundCloud"
                pkg.lowercase().contains("youtube") -> "YouTube"
                else -> pkg.substringAfterLast('.')
            }
        }
    }

    fun dismissPlayerByUser(audioManager: AudioManager) {
        val cur = _state.value
        val now = SystemClock.elapsedRealtime()
        dismissedTrackIdentity = currentTrackIdentity.ifEmpty { "DISMISSED_SESSION" }
        dismissedAtRealtime = now
        lastLauncherPauseRealtime = now
        pausedByLauncherControl = true

        try {
            val ctrl = activeController
            if (ctrl != null && (isActivelyPlayingState(ctrl.playbackState?.state) || cur.isPlaying)) {
                ctrl.transportControls.pause()
            } else if (cur.isPlaying) {
                val upNow = SystemClock.uptimeMillis()
                audioManager.dispatchMediaKeyEvent(KeyEvent(upNow, upNow, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PAUSE, 0))
                audioManager.dispatchMediaKeyEvent(KeyEvent(upNow, upNow, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PAUSE, 0))
            }
        } catch (_: Exception) {
        }

        _state.value = NowPlayingSnapshot(
            hasActiveSession = false,
            isPlaying = false
        )
    }

    fun onContinuousBackgroundMusicDetected(context: Context? = null) {
        val now = SystemClock.elapsedRealtime()
        if (pausedByLauncherControl) {
            if ((now - lastLauncherPauseRealtime) > 2500L) {
                pausedByLauncherControl = false
                dismissedTrackIdentity = ""
            } else {
                return
            }
        }
        if (dismissedTrackIdentity.isNotEmpty() && (now - dismissedAtRealtime) < 3000L) return

        if (context != null) {
            queryMediaSessionManagerDirect(context)
            pollDumpsysMediaSessionAsync(context, force = false)
        }

        val cur = _state.value
        val hasRealTrack = cur.title.isNotBlank() && !cur.title.equals(cur.sourceAppName, ignoreCase = true)
        if (hasRealTrack && (!cur.hasActiveSession || !cur.isPlaying)) {
            updatePlayingFlag(true)
        }
    }

    private fun resolveRealtimeDeltaMs(reportedUpdateTime: Long, nowElapsed: Long): Long {
        if (reportedUpdateTime <= 0L) return -1L
        if (reportedUpdateTime in 1L..(nowElapsed + 2000L) && (nowElapsed - reportedUpdateTime) in 0L..14_400_000L) {
            return (nowElapsed - reportedUpdateTime).coerceAtLeast(0L)
        }
        val nowWall = System.currentTimeMillis()
        if (reportedUpdateTime in (nowWall - 14_400_000L)..(nowWall + 2000L)) {
            return (nowWall - reportedUpdateTime).coerceAtLeast(0L)
        }
        return -1L
    }

    fun updateMetadata(
        context: Context? = null,
        title: String,
        artist: String,
        sourcePackage: String,
        sourceAppName: String,
        cover: Bitmap?,
        coverSignature: Int = 0,
        artUri: String = "",
        durationMs: Long = -1L,
        positionMs: Long = -1L,
        positionUpdateRealtime: Long = 0L,
        speed: Float = 1.0f
    ) {
        val current = _state.value
        val now = SystemClock.elapsedRealtime()
        val resolvedPkg = if (sourcePackage.isNotBlank()) sourcePackage else current.sourcePackage
        val pkgChanged = resolvedPkg.isNotBlank() && current.sourcePackage.isNotBlank() && resolvedPkg != current.sourcePackage
        var resolvedTitle = if (title.isNotBlank()) title else if (!pkgChanged) current.title else ""
        var resolvedArtist = if (artist.isNotBlank()) artist else if (!pkgChanged) current.artist else ""
        val resolvedAppName = if (sourceAppName.isNotBlank()) sourceAppName else if (!pkgChanged) current.sourceAppName else ""

        // Если плеер (например SoundCloud или YouTube) передал "Artist - Track Title" в одной строке заголовка:
        if (resolvedTitle.isNotBlank() && (resolvedArtist.isBlank() || resolvedArtist.equals(resolvedAppName, ignoreCase = true))) {
            val separators = listOf(" — ", " – ", " - ")
            for (sep in separators) {
                if (resolvedTitle.contains(sep)) {
                    val left = resolvedTitle.substringBefore(sep).trim()
                    val right = resolvedTitle.substringAfter(sep).trim()
                    if (left.length in 2..45 && right.length >= 2) {
                        resolvedArtist = left
                        resolvedTitle = right
                        break
                    }
                }
            }
        }

        val newIdentity = "$resolvedPkg|$resolvedTitle"
        if (dismissedTrackIdentity.isNotEmpty()) {
            if ((now - dismissedAtRealtime) < 2500L) return
            if (newIdentity == dismissedTrackIdentity && !current.isPlaying) return
            if (newIdentity != dismissedTrackIdentity) {
                dismissedTrackIdentity = ""
                pausedByLauncherControl = false
            }
        }

        val trackChanged = (resolvedTitle.isNotBlank() && newIdentity != currentTrackIdentity) || pkgChanged
        if (trackChanged) {
            currentTrackIdentity = newIdentity
            trackStartRealtime = now
            lastObservedRawPos = -1L
            lastObservedRawRealtime = 0L
            pausedByLauncherControl = false
        }

        val posActuallyChanged = positionMs >= 0L && positionMs != lastObservedRawPos
        if (posActuallyChanged) {
            lastObservedRawPos = positionMs
            lastObservedRawRealtime = now
        }

        var resolvedCover: Bitmap? = when {
            cover != null -> {
                val incomingSig = if (coverSignature != 0) coverSignature else computeBitmapSignature(cover)
                if (trackChanged && incomingSig != 0 && incomingSig == currentCoverSignature && artUri.isNotBlank() && artUri != currentArtUri) {
                    null
                } else {
                    currentCoverSignature = incomingSig
                    cover
                }
            }
            !trackChanged && !pkgChanged -> current.coverBitmap
            else -> {
                currentCoverSignature = 0
                null
            }
        }

        val normalizedUri = normalizeArtUri(artUri)
        if (normalizedUri.isNotBlank() && (resolvedCover == null || normalizedUri != currentArtUri)) {
            currentArtUri = normalizedUri
            val cached = artUriCache.get(normalizedUri)
            if (cached != null) {
                resolvedCover = cached
                currentCoverSignature = computeBitmapSignature(cached)
            } else if (normalizedUri != lastFetchedArtUri) {
                lastFetchedArtUri = normalizedUri
                fetchArtFromUriAsync(context, normalizedUri, newIdentity)
            }
        }

        val resolvedDuration = if (durationMs > 0L) durationMs else if (trackChanged) 0L else current.durationMs
        val deltaFromReport = resolveRealtimeDeltaMs(positionUpdateRealtime, now)

        val resolvedPos = when {
            positionMs > 0L -> if (resolvedDuration > 0L) positionMs.coerceAtMost(resolvedDuration) else positionMs
            trackChanged -> 0L
            positionMs == 0L && deltaFromReport >= 0L -> 0L
            else -> current.basePositionMs
        }
        val resolvedRealtime = when {
            deltaFromReport >= 0L -> (now - deltaFromReport).coerceAtLeast(1L)
            posActuallyChanged && positionMs > 0L -> now
            trackChanged -> now
            current.baseElapsedRealtime > 0L -> current.baseElapsedRealtime
            else -> trackStartRealtime
        }

        val hasValidTrackTitle = resolvedTitle.isNotBlank() &&
            !resolvedTitle.equals(resolvedAppName, ignoreCase = true) &&
            !isExcludedVideoPackage(resolvedPkg)
        if (hasValidTrackTitle) {
            hasObservedActivePlaybackSinceBoot = true
        }
        val hasSession = hasValidTrackTitle
        val playingNow = if (trackChanged) true else current.isPlaying

        var finalDuration = resolvedDuration
        val lookupKey = "${resolvedArtist.lowercase()}|${resolvedTitle.lowercase()}"
        val cachedCat = catalogLookupCache.get(lookupKey)
        if (cachedCat != null) {
            if (finalDuration <= 0L && cachedCat.second > 0L) {
                finalDuration = cachedCat.second
            }
            if (resolvedCover == null && cachedCat.first.isNotBlank()) {
                val bmp = artUriCache.get(cachedCat.first)
                if (bmp != null) {
                    resolvedCover = bmp
                }
            }
        }

        _state.value = current.copy(
            hasActiveSession = hasSession,
            isPlaying = playingNow,
            title = resolvedTitle,
            artist = resolvedArtist,
            sourcePackage = resolvedPkg,
            sourceAppName = resolvedAppName,
            coverBitmap = resolvedCover,
            durationMs = finalDuration,
            basePositionMs = resolvedPos,
            baseElapsedRealtime = resolvedRealtime,
            playbackSpeed = if (speed > 0f) speed else 1.0f
        )

        if (resolvedTitle.isNotBlank() && (resolvedCover == null || finalDuration <= 0L) && lookupKey != lastCatalogLookupKey) {
            lastCatalogLookupKey = lookupKey
            fetchTrackArtAndDurationFromCatalog(context, resolvedTitle, resolvedArtist, resolvedAppName, lookupKey, newIdentity)
        }
    }

    /**
     * Если плеер не отдал картинку обложки или длительность трека (например SoundCloud / Bluetooth / локальный плеер),
     * за 150 мс находим официальную обложку и длительность через бесплатный открытый каталог Deezer / iTunes API!
     */
    private fun fetchTrackArtAndDurationFromCatalog(
        context: Context?,
        trackTitle: String,
        trackArtist: String,
        appName: String,
        lookupKey: String,
        expectedIdentity: String
    ) {
        val cleanArtist = if (trackArtist.equals(appName, ignoreCase = true)) "" else trackArtist
        val query = if (cleanArtist.isNotBlank()) "$cleanArtist $trackTitle" else trackTitle
        if (query.length < 3) return

        ioScope.launch {
            var foundArtUrl = ""
            var foundDurationMs = 0L
            var foundArtistName = ""
            var foundOfficialTitle = ""

            // 1. Быстрый запрос к публичному каталогу Deezer API (без ключа)
            try {
                val encoded = URLEncoder.encode(query, "UTF-8")
                val conn = (URL("https://api.deezer.com/search?q=$encoded&limit=1").openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 3000
                    readTimeout = 3500
                    doInput = true
                }
                if (conn.responseCode in 200..299) {
                    val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                    val root = JSONObject(body)
                    val dataArr = root.optJSONArray("data")
                    if (dataArr != null && dataArr.length() > 0) {
                        val item = dataArr.optJSONObject(0)
                        if (item != null) {
                            val durSec = item.optLong("duration", 0L)
                            if (durSec > 0L) foundDurationMs = durSec * 1000L
                            foundOfficialTitle = item.optString("title_short", "").ifEmpty { item.optString("title", "") }
                            foundArtistName = item.optJSONObject("artist")?.optString("name", "").orEmpty()
                            val albumObj = item.optJSONObject("album")
                            foundArtUrl = albumObj?.optString("cover_medium", "").orEmpty()
                                .ifEmpty { albumObj?.optString("cover", "").orEmpty() }
                        }
                    }
                }
                conn.disconnect()
            } catch (_: Exception) {
            }

            // 2. Резервный запрос к iTunes Search API (если в Deezer не нашлось)
            if (foundArtUrl.isBlank() && foundDurationMs <= 0L) {
                try {
                    val encoded = URLEncoder.encode(query, "UTF-8")
                    val conn = (URL("https://itunes.apple.com/search?term=$encoded&entity=song&limit=1").openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 3000
                        readTimeout = 3500
                        doInput = true
                    }
                    if (conn.responseCode in 200..299) {
                        val body = conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
                        val root = JSONObject(body)
                        val resultsArr = root.optJSONArray("results")
                        if (resultsArr != null && resultsArr.length() > 0) {
                            val item = resultsArr.optJSONObject(0)
                            if (item != null) {
                                val tMillis = item.optLong("trackTimeMillis", 0L)
                                if (tMillis > 0L) foundDurationMs = tMillis
                                foundOfficialTitle = item.optString("trackName", "")
                                foundArtistName = item.optString("artistName", "")
                                foundArtUrl = item.optString("artworkUrl100", "").replace("100x100bb", "300x300bb")
                            }
                        }
                    }
                    conn.disconnect()
                } catch (_: Exception) {
                }
            }

            if (foundArtUrl.isNotBlank() || foundDurationMs > 0L) {
                catalogLookupCache.put(lookupKey, foundArtUrl to foundDurationMs)
                var downloadedBmp: Bitmap? = null
                if (foundArtUrl.isNotBlank()) {
                    downloadedBmp = artUriCache.get(foundArtUrl)
                    if (downloadedBmp == null) {
                        try {
                            val c = (URL(foundArtUrl).openConnection() as HttpURLConnection).apply {
                                connectTimeout = 3500
                                readTimeout = 3500
                                doInput = true
                            }
                            if (c.responseCode in 200..299) {
                                val raw = c.inputStream.use { BitmapFactory.decodeStream(it) }
                                if (raw != null) {
                                    downloadedBmp = safeScaleBitmap(raw)
                                    if (downloadedBmp != null) {
                                        artUriCache.put(foundArtUrl, downloadedBmp)
                                    }
                                }
                            }
                            c.disconnect()
                        } catch (_: Exception) {
                        }
                    }
                }

                val cur = _state.value
                if (currentTrackIdentity == expectedIdentity || cur.title.equals(trackTitle, ignoreCase = true) || cur.title.isBlank()) {
                    val betterTitle = if (foundOfficialTitle.isNotBlank() && (cur.artist.isBlank() || cur.artist.equals(appName, ignoreCase = true))) {
                        foundOfficialTitle
                    } else {
                        cur.title.ifBlank { foundOfficialTitle }
                    }
                    val betterArtist = if (cur.artist.isBlank() || cur.artist.equals(appName, ignoreCase = true)) {
                        foundArtistName.ifBlank { cur.artist }
                    } else {
                        cur.artist
                    }
                    currentTrackIdentity = "${cur.sourcePackage}|$betterTitle"
                    _state.value = cur.copy(
                        title = betterTitle,
                        artist = betterArtist,
                        coverBitmap = downloadedBmp ?: cur.coverBitmap,
                        durationMs = if (cur.durationMs > 0L) cur.durationMs else foundDurationMs
                    )
                }
            }
        }
    }

    fun updatePositionOnly(positionMs: Long, positionUpdateRealtime: Long, speed: Float, isPlaying: Boolean) {
        val cur = _state.value
        val now = SystemClock.elapsedRealtime()
        if (dismissedTrackIdentity.isNotEmpty() && (now - dismissedAtRealtime) < 2500L && !isPlaying) return
        if (isPlaying) {
            dismissedTrackIdentity = ""
            pausedByLauncherControl = false
            lastPausedRealtime = 0L
        } else if (cur.isPlaying) {
            lastPausedRealtime = now
        }
        val posActuallyChanged = positionMs >= 0L && positionMs != lastObservedRawPos
        if (posActuallyChanged) {
            lastObservedRawPos = positionMs
            lastObservedRawRealtime = now
        }
        val deltaFromReport = resolveRealtimeDeltaMs(positionUpdateRealtime, now)
        val validPos = if (positionMs > 0L || (positionMs == 0L && deltaFromReport >= 0L)) {
            if (cur.durationMs > 0L) positionMs.coerceAtMost(cur.durationMs) else positionMs
        } else {
            cur.basePositionMs
        }
        val validRealtime = when {
            deltaFromReport >= 0L -> (now - deltaFromReport).coerceAtLeast(1L)
            posActuallyChanged && positionMs > 0L -> now
            cur.baseElapsedRealtime > 0L -> cur.baseElapsedRealtime
            else -> trackStartRealtime
        }
        _state.value = cur.copy(
            hasActiveSession = cur.hasActiveSession || isPlaying,
            isPlaying = isPlaying,
            basePositionMs = validPos,
            baseElapsedRealtime = validRealtime,
            playbackSpeed = if (speed > 0f) speed else 1.0f
        )
    }

    private fun fetchArtFromUriAsync(context: Context?, uriString: String, expectedIdentity: String) {
        val appCtx = context?.applicationContext
        val normalized = normalizeArtUri(uriString)
        ioScope.launch {
            try {
                val raw: Bitmap? = when {
                    normalized.startsWith("http://") || normalized.startsWith("https://") -> {
                        val conn = (URL(normalized).openConnection() as HttpURLConnection).apply {
                            connectTimeout = 3500
                            readTimeout = 3500
                            doInput = true
                        }
                        conn.connect()
                        val decoded = conn.inputStream.use { BitmapFactory.decodeStream(it) }
                        conn.disconnect()
                        decoded
                    }
                    (normalized.startsWith("content://") || normalized.startsWith("android.resource://") || normalized.startsWith("file://")) && appCtx != null -> {
                        appCtx.contentResolver.openInputStream(Uri.parse(normalized))?.use {
                            BitmapFactory.decodeStream(it)
                        }
                    }
                    else -> null
                }

                if (raw != null) {
                    val scaled = safeScaleBitmap(raw)
                    if (scaled != null && scaled !== raw && !raw.isRecycled) raw.recycle()
                    if (scaled != null) {
                        artUriCache.put(normalized, scaled)
                        if (currentTrackIdentity == expectedIdentity || _state.value.coverBitmap == null || currentArtUri == normalized) {
                            currentCoverSignature = computeBitmapSignature(scaled)
                            _state.value = _state.value.copy(coverBitmap = scaled)
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    fun updatePlayingFlag(isPlaying: Boolean) {
        val cur = _state.value
        val now = SystemClock.elapsedRealtime()
        if (isPlaying) {
            if (dismissedTrackIdentity.isNotEmpty() && (now - dismissedAtRealtime) < 2500L) return
            dismissedTrackIdentity = ""
            pausedByLauncherControl = false
            lastPausedRealtime = 0L
            if (!cur.isPlaying && cur.basePositionMs == 0L) {
                trackStartRealtime = now
            }
            if (!cur.isPlaying || !cur.hasActiveSession) {
                _state.value = cur.copy(
                    hasActiveSession = true,
                    isPlaying = true,
                    baseElapsedRealtime = if (cur.baseElapsedRealtime > 0L) cur.baseElapsedRealtime else now
                )
            }
        } else {
            if (cur.isPlaying) {
                val (frozenPos, _) = getLivePositionAndDuration()
                lastPausedRealtime = now
                _state.value = cur.copy(
                    isPlaying = false,
                    basePositionMs = frozenPos,
                    baseElapsedRealtime = now
                )
            } else if (cur.hasActiveSession && lastPausedRealtime > 0L && (now - lastPausedRealtime) > 20 * 60 * 1000L) {
                _state.value = cur.copy(hasActiveSession = false)
            }
        }
    }

    fun pollActiveControllerLight(context: Context? = null) {
        if (context != null) {
            queryMediaSessionManagerDirect(context)
            MediaSessionListenerService.instance?.pollActiveMediaNotifications(context)
            pollDumpsysMediaSessionAsync(context, force = false)
        }
        val ctrl = activeController ?: return
        if (context != null) {
            syncControllerImmediate(context, ctrl)
        }
    }

    fun getLivePositionAndDuration(): Pair<Long, Long> {
        val ctrl = activeController
        val snap = _state.value
        val now = SystemClock.elapsedRealtime()

        var dur = snap.durationMs.coerceAtLeast(0L)
        if (ctrl != null) {
            try {
                val metaDur = ctrl.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
                if (metaDur > 0L) dur = metaDur
            } catch (_: Exception) {
            }
        }

        if (!snap.isPlaying) {
            val frozen = if (dur > 0L) snap.basePositionMs.coerceIn(0L, dur) else snap.basePositionMs.coerceAtLeast(0L)
            return frozen to dur
        }

        if (ctrl != null) {
            try {
                val pb = ctrl.playbackState
                if (pb != null && pb.position >= 0L) {
                    val speed = if (pb.playbackSpeed > 0f) pb.playbackSpeed else 1.0f
                    val deltaReport = resolveRealtimeDeltaMs(pb.lastPositionUpdateTime, now)
                    if (pb.position > 0L || (pb.position == 0L && isActivelyPlayingState(pb.state) && deltaReport >= 0L)) {
                        var pos = pb.position
                        val delta = when {
                            deltaReport >= 0L -> deltaReport
                            lastObservedRawRealtime in 1L..now -> (now - lastObservedRawRealtime).coerceAtLeast(0L)
                            else -> 0L
                        }
                        pos += (delta * speed).toLong().coerceAtLeast(0L)
                        if (dur > 0L) pos = pos.coerceAtMost(dur)
                        return pos.coerceAtLeast(0L) to dur
                    }
                }
            } catch (_: Exception) {
            }
        }

        if (snap.basePositionMs > 0L && snap.baseElapsedRealtime > 0L) {
            val delta = (now - snap.baseElapsedRealtime).coerceAtLeast(0L)
            var pos = snap.basePositionMs + (delta * snap.playbackSpeed).toLong().coerceAtLeast(0L)
            if (dur > 0L) pos = pos.coerceAtMost(dur)
            return pos to dur
        }

        var elapsed = (now - trackStartRealtime).coerceAtLeast(0L)
        if (dur > 0L) elapsed = elapsed.coerceAtMost(dur)
        return elapsed to dur
    }

    fun dispatchTransportAction(action: String, audioManager: AudioManager) {
        val ctrl = activeController
        val now = SystemClock.elapsedRealtime()
        try {
            if (ctrl != null) {
                val tc = ctrl.transportControls
                val pbState = ctrl.playbackState?.state
                when (action) {
                    "PREV" -> {
                        pausedByLauncherControl = false
                        tc.skipToPrevious()
                        return
                    }
                    "NEXT" -> {
                        pausedByLauncherControl = false
                        tc.skipToNext()
                        return
                    }
                    "PLAY_PAUSE" -> {
                        if (isActivelyPlayingState(pbState) || _state.value.isPlaying) {
                            pausedByLauncherControl = true
                            lastLauncherPauseRealtime = now
                            tc.pause()
                            updatePlayingFlag(false)
                        } else {
                            pausedByLauncherControl = false
                            dismissedTrackIdentity = ""
                            tc.play()
                            updatePlayingFlag(true)
                        }
                        return
                    }
                }
            }
        } catch (_: Exception) {
        }

        val keyCode = when (action) {
            "PREV" -> {
                pausedByLauncherControl = false
                KeyEvent.KEYCODE_MEDIA_PREVIOUS
            }
            "NEXT" -> {
                pausedByLauncherControl = false
                KeyEvent.KEYCODE_MEDIA_NEXT
            }
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        try {
            val upNow = SystemClock.uptimeMillis()
            audioManager.dispatchMediaKeyEvent(KeyEvent(upNow, upNow, KeyEvent.ACTION_DOWN, keyCode, 0))
            audioManager.dispatchMediaKeyEvent(KeyEvent(upNow, upNow, KeyEvent.ACTION_UP, keyCode, 0))
            if (action == "PLAY_PAUSE") {
                val targetPlay = !_state.value.isPlaying
                pausedByLauncherControl = !targetPlay
                if (!targetPlay) lastLauncherPauseRealtime = now
                if (targetPlay) dismissedTrackIdentity = ""
                updatePlayingFlag(targetPlay)
            }
        } catch (_: Exception) {
        }
    }
}

object KeyCaptureBus {
    @Volatile
    var isCapturingKey: Boolean = false

    @Volatile
    var onKeyCapturedListener: ((keyCode: Int, scanCode: Int) -> Unit)? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    fun notifyKeyCaptured(keyCode: Int, scanCode: Int): Boolean {
        val listener = onKeyCapturedListener ?: return false
        isCapturingKey = false
        mainHandler.post {
            listener.invoke(keyCode, scanCode)
        }
        return true
    }
}

class MediaSessionListenerService : NotificationListenerService() {

    companion object {
        @Volatile
        var instance: MediaSessionListenerService? = null
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        pollActiveMediaNotifications(this)
        MediaStateBus.queryMediaSessionManagerDirect(this)
    }

    override fun onListenerDisconnected() {
        instance = null
        super.onListenerDisconnected()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try {
                requestRebind(ComponentName(this, MediaSessionListenerService::class.java))
            } catch (_: Exception) {
            }
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        instance = this
        if (sbn == null) return
        val pkg = sbn.packageName ?: return
        if (pkg == packageName) return
        val notif = sbn.notification ?: return
        MediaStateBus.ingestNotification(this, pkg, notif, requireActivePlaybackOrSession = false)
    }

    fun pollActiveMediaNotifications(context: Context) {
        try {
            val list = activeNotifications ?: return
            for (sbn in list) {
                val pkg = sbn.packageName ?: continue
                if (pkg == context.packageName) continue
                val notif = sbn.notification ?: continue
                MediaStateBus.ingestNotification(context, pkg, notif, requireActivePlaybackOrSession = true)
            }
        } catch (_: Exception) {
        }
    }
}

class KeyMapperAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var isServiceConnectedAlive: Boolean = false
    }

    private var lastInterceptMillis: Long = 0L
    private val uiHandler = Handler(Looper.getMainLooper())
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val decelerateInterpolator = DecelerateInterpolator()

    private var windowManager: WindowManager? = null
    private var overlayHudRoot: LinearLayout? = null
    private var overlayHudIcon: ImageView? = null
    private var overlayHudTrack: FrameLayout? = null
    private var overlayHudFill: View? = null
    private var overlayHudPct: TextView? = null
    private var lastKnownVolumePct: Int = -1
    private var receiversRegistered: Boolean = false

    private var islandLayoutParams: WindowManager.LayoutParams? = null
    private var islandRoot: LinearLayout? = null
    private var islandHeaderRow: LinearLayout? = null
    private var islandSparkIcon: ImageView? = null
    private var islandWaveContainer: LinearLayout? = null
    private val islandWaveBars = mutableListOf<View>()
    private var islandStatusText: TextView? = null
    private var islandHintText: TextView? = null
    private var islandBodyText: TextView? = null
    private var islandMorphAnimator: ValueAnimator? = null
    private var islandVisible: Boolean = false
    private var islandIsListening: Boolean = false
    private var islandIsSpeaking: Boolean = false
    private var islandIsFollowUpListen: Boolean = false

    private var speechRecognizer: SpeechRecognizer? = null
    private var audioRecordJob: Job? = null
    private var geminiQueryJob: Job? = null
    private var lastPartialTranscript: String = ""

    private val hideOverlayRunnable = Runnable {
        val root = overlayHudRoot ?: return@Runnable
        root.animate()
            .alpha(0f)
            .setDuration(180L)
            .withEndAction { root.visibility = View.GONE }
            .start()
    }

    private val hideIslandRunnable = Runnable {
        collapseDynamicIsland()
    }

    @Volatile
    private var targetVoiceLevel: Float = 0.35f
    private var smoothedVoiceLevel: Float = 0.35f
    private var wavePhaseRad: Double = 0.0

    private val pulseWaveRunnable = object : Runnable {
        override fun run() {
            if (!islandVisible) return
            if (islandWaveContainer?.visibility == View.VISIBLE) {
                val baseTarget = when {
                    islandIsListening -> targetVoiceLevel
                    islandIsSpeaking || AssistantVoiceSpeaker.isSpeakingNow -> AssistantVoiceSpeaker.currentVoiceWaveLevel
                    else -> 0.42f
                }
                smoothedVoiceLevel += (baseTarget - smoothedVoiceLevel) * 0.24f
                wavePhaseRad += if (islandIsListening || islandIsSpeaking) 0.26 else 0.16

                for (i in islandWaveBars.indices) {
                    val bar = islandWaveBars[i]
                    val wave = ((sin(wavePhaseRad + i * 1.15) + 1.0) * 0.5).toFloat()
                    val scale = (0.24f + smoothedVoiceLevel * (0.35f + 0.41f * wave)).coerceIn(0.22f, 1.0f)
                    bar.scaleY = scale
                }
                uiHandler.postDelayed(this, 16L)
            }
        }
    }

    private val globalMediaAndVolumeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val act = intent?.action ?: return
            if (act == "android.media.VOLUME_CHANGED_ACTION") {
                val streamType = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1)
                if (streamType == AudioManager.STREAM_MUSIC || streamType == -1) {
                    val pct = computeCurrentMusicVolumePct()
                    if (lastKnownVolumePct != -1 && pct != lastKnownVolumePct) {
                        lastKnownVolumePct = pct
                        showGlobalVolumeOverlay()
                        VolumeHudBus.notifyVolumeChanged()
                    } else if (lastKnownVolumePct == -1) {
                        lastKnownVolumePct = pct
                    }
                }
                return
            }

            MediaStateBus.handleMediaBroadcastIntent(this@KeyMapperAccessibilityService, intent)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        isServiceConnectedAlive = true
        try {
            val info = serviceInfo ?: AccessibilityServiceInfo()
            info.flags = info.flags or
                AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS or
                AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS or
                AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            serviceInfo = info
        } catch (_: Exception) {
        }

        TvUiControllerBus.onScheduleInAppSearch = { targetPkg, query ->
            runAutomatedInAppSearch(targetPkg, query)
        }
        TvUiControllerBus.onTypeTextOnScreen = { text ->
            typeTextIntoActiveField(text)
        }
        TvUiControllerBus.onClickNodeByText = { text ->
            clickElementOnScreenByText(text)
        }
        TvUiControllerBus.onGlobalNavAction = { action ->
            performGlobalNavigationCommand(action)
        }
        NavSoundPlayer.init(this)
        AssistantVoiceSpeaker.init(this)
        ServiceAutoActivator.ensureServicesActive(this)
        lastKnownVolumePct = computeCurrentMusicVolumePct()
        registerGlobalReceiversIfNeeded()
        ensureGlobalVolumeOverlayCreated()
        ensureDynamicIslandOverlayCreated()

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                val chanId = "mitv_remote_console_fg"
                val chan = NotificationChannel(chanId, "MiTV Remote Server", NotificationManager.IMPORTANCE_MIN).apply {
                    setShowBadge(false)
                }
                nm?.createNotificationChannel(chan)
                val notif = Notification.Builder(this, chanId)
                    .setContentTitle("Mi TV Stick Server")
                    .setContentText("Port 8765 active")
                    .setSmallIcon(R.drawable.ic_launcher_icon)
                    .build()
                startForeground(8765, notif)
            }
        } catch (_: Exception) {
        }
        RemoteConsoleServer.ensureStarted(this)
        TvUiControllerBus.onInjectDpadAction = { dir ->
            injectAccessibilityDpadOrCenter(dir)
        }
        DynamicIslandBus.onTriggerIslandInService = {
            triggerDynamicIslandAssistant()
        }
        DynamicIslandBus.onTriggerVoiceTextInService = { spokenText ->
            triggerDynamicIslandWithRemoteText(spokenText)
        }
        DynamicIslandBus.onAccentColorUpdated = {
            refreshOverlayAccentColors()
        }
        LocalVoiceCommandRouter.onVolumeChangedCallback = {
            showGlobalVolumeOverlay()
        }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        isServiceConnectedAlive = false
        DynamicIslandBus.onTriggerIslandInService = null
        cleanupGlobalOverlayAndReceivers()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        isServiceConnectedAlive = false
        DynamicIslandBus.onTriggerIslandInService = null
        cleanupGlobalOverlayAndReceivers()
        super.onDestroy()
    }

    private fun registerGlobalReceiversIfNeeded() {
        if (receiversRegistered) return
        try {
            val filter = IntentFilter().apply {
                addAction("android.media.VOLUME_CHANGED_ACTION")
                for (mediaAct in MediaStateBus.UNIVERSAL_MEDIA_BROADCAST_ACTIONS) {
                    addAction(mediaAct)
                }
            }
            ContextCompat.registerReceiver(
                this,
                globalMediaAndVolumeReceiver,
                filter,
                ContextCompat.RECEIVER_EXPORTED
            )
            receiversRegistered = true
        } catch (_: Exception) {
        }
    }

    private fun cleanupGlobalOverlayAndReceivers() {
        uiHandler.removeCallbacks(hideOverlayRunnable)
        uiHandler.removeCallbacks(hideIslandRunnable)
        uiHandler.removeCallbacks(pulseWaveRunnable)
        stopVoiceListeningInternal()
        if (receiversRegistered) {
            try {
                unregisterReceiver(globalMediaAndVolumeReceiver)
            } catch (_: Exception) {
            }
            receiversRegistered = false
        }
        val wm = windowManager
        val volRoot = overlayHudRoot
        if (wm != null && volRoot != null) {
            try {
                wm.removeViewImmediate(volRoot)
            } catch (_: Exception) {
            }
        }
        val islRoot = islandRoot
        if (wm != null && islRoot != null) {
            try {
                wm.removeViewImmediate(islRoot)
            } catch (_: Exception) {
            }
        }
        overlayHudRoot = null
        islandRoot = null
    }

    private fun dpPx(dpVal: Float): Int = (dpVal * resources.displayMetrics.density + 0.5f).toInt()

    private fun computeCurrentMusicVolumePct(): Int {
        return try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val isMuted = am.isStreamMute(AudioManager.STREAM_MUSIC)
            val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            val curVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            if (isMuted) 0 else ((curVol * 100f) / maxVol).toInt().coerceIn(0, 100)
        } catch (_: Exception) {
            0
        }
    }

    private fun resolveCurrentAccentColor(): Int {
        return try {
            val prefs = getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            val hex = prefs.getString("pref_accent_color", "#00F0FF") ?: "#00F0FF"
            Color.parseColor(hex)
        } catch (_: Exception) {
            Color.parseColor("#00F0FF")
        }
    }

    private fun refreshOverlayAccentColors() {
        val accent = resolveCurrentAccentColor()
        overlayHudRoot?.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(999f).toFloat()
            setColor(Color.parseColor("#F20D0F14"))
            setStroke(dpPx(1.5f), ColorUtils.setAlphaComponent(accent, 160))
        }
        overlayHudFill?.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(999f).toFloat()
            setColor(accent)
        }
        overlayHudIcon?.setColorFilter(accent, PorterDuff.Mode.SRC_IN)
        overlayHudPct?.setTextColor(accent)

        islandRoot?.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(22f).toFloat()
            setColor(Color.parseColor("#F5101218"))
            setStroke(dpPx(1.8f), accent)
        }
        islandSparkIcon?.setColorFilter(accent, PorterDuff.Mode.SRC_IN)
        islandWaveBars.forEach { bar ->
            bar.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpPx(99f).toFloat()
                setColor(accent)
            }
        }
    }

    private fun ensureGlobalVolumeOverlayCreated() {
        if (overlayHudRoot != null) return
        try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
            windowManager = wm
            val accent = resolveCurrentAccentColor()

            val root = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dpPx(18f), 0, dpPx(18f), 0)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpPx(999f).toFloat()
                    setColor(Color.parseColor("#F20D0F14"))
                    setStroke(dpPx(1.5f), ColorUtils.setAlphaComponent(accent, 160))
                }
                visibility = View.GONE
            }

            val icon = ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(dpPx(22f), dpPx(22f))
                setImageResource(R.drawable.ic_volume_24)
                setColorFilter(accent, PorterDuff.Mode.SRC_IN)
            }

            val track = FrameLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, dpPx(6f), 1f).apply {
                    marginStart = dpPx(14f)
                    marginEnd = dpPx(14f)
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpPx(999f).toFloat()
                    setColor(Color.parseColor("#26FFFFFF"))
                }
            }

            val fill = View(this).apply {
                layoutParams = FrameLayout.LayoutParams(dpPx(80f), FrameLayout.LayoutParams.MATCH_PARENT)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpPx(999f).toFloat()
                    setColor(accent)
                }
            }
            track.addView(fill)

            val pctText = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(dpPx(44f), LinearLayout.LayoutParams.WRAP_CONTENT)
                gravity = Gravity.END
                typeface = Typeface.MONOSPACE
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setTextColor(accent)
                text = "20%"
            }

            root.addView(icon)
            root.addView(track)
            root.addView(pctText)

            val lp = WindowManager.LayoutParams(
                dpPx(290f),
                dpPx(52f),
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.END
                x = dpPx(54f)
                y = dpPx(34f)
            }

            wm.addView(root, lp)
            overlayHudRoot = root
            overlayHudIcon = icon
            overlayHudTrack = track
            overlayHudFill = fill
            overlayHudPct = pctText
        } catch (_: Exception) {
        }
    }

    private fun showGlobalVolumeOverlay() {
        uiHandler.post {
            ensureGlobalVolumeOverlayCreated()
            val root = overlayHudRoot ?: return@post
            val icon = overlayHudIcon ?: return@post
            val track = overlayHudTrack ?: return@post
            val fill = overlayHudFill ?: return@post
            val pctView = overlayHudPct ?: return@post

            val pct = computeCurrentMusicVolumePct()
            lastKnownVolumePct = pct
            val accent = resolveCurrentAccentColor()
            val activeColor = if (pct > 0) accent else Color.parseColor("#FF5252")

            root.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpPx(999f).toFloat()
                setColor(Color.parseColor("#F20D0F14"))
                setStroke(dpPx(1.5f), ColorUtils.setAlphaComponent(accent, 160))
            }
            pctView.text = "$pct%"
            pctView.setTextColor(activeColor)
            icon.setColorFilter(activeColor, PorterDuff.Mode.SRC_IN)
            fill.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpPx(999f).toFloat()
                setColor(activeColor)
            }

            track.post {
                val totalW = track.width.coerceAtLeast(dpPx(140f))
                val fillW = ((totalW * pct) / 100).coerceAtLeast(if (pct > 0) dpPx(6f) else 0)
                val flp = fill.layoutParams
                if (flp.width != fillW) {
                    flp.width = fillW
                    fill.layoutParams = flp
                }
            }

            if (root.visibility != View.VISIBLE) {
                root.alpha = 0f
                root.visibility = View.VISIBLE
                root.animate().alpha(1f).setDuration(110L).start()
            } else {
                root.animate().cancel()
                root.alpha = 1f
            }

            uiHandler.removeCallbacks(hideOverlayRunnable)
            uiHandler.postDelayed(hideOverlayRunnable, 1600L)
        }
    }

    private fun ensureDynamicIslandOverlayCreated() {
        if (islandRoot != null) return
        try {
            val wm = (windowManager ?: getSystemService(Context.WINDOW_SERVICE) as? WindowManager) ?: return
            windowManager = wm
            val accent = resolveCurrentAccentColor()

            val root = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dpPx(18f), dpPx(12f), dpPx(18f), dpPx(12f))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpPx(22f).toFloat()
                    setColor(Color.parseColor("#F5101218"))
                    setStroke(dpPx(1.8f), accent)
                }
                visibility = View.GONE
            }

            val header = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }

            val spark = ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(dpPx(20f), dpPx(20f))
                setImageResource(R.drawable.ic_ai_64)
                setColorFilter(accent, PorterDuff.Mode.SRC_IN)
            }

            val waveBox = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    dpPx(22f)
                ).apply {
                    marginStart = dpPx(10f)
                }
            }
            islandWaveBars.clear()
            for (i in 0 until 4) {
                val bar = View(this).apply {
                    layoutParams = LinearLayout.LayoutParams(dpPx(3.5f), dpPx(18f)).apply {
                        marginEnd = dpPx(3.5f)
                    }
                    scaleY = 0.32f
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = dpPx(99f).toFloat()
                        setColor(accent)
                    }
                }
                islandWaveBars.add(bar)
                waveBox.addView(bar)
            }

            val statusTv = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = dpPx(10f)
                }
                setTextColor(Color.parseColor("#F3F4F6"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                text = "Слушаю..."
            }

            val hintTv = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    marginStart = dpPx(10f)
                }
                setTextColor(Color.parseColor("#9CA3AF"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                text = "OK — стоп"
            }

            header.addView(spark)
            header.addView(waveBox)
            header.addView(statusTv)
            header.addView(hintTv)

            val bodyTv = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    topMargin = dpPx(8f)
                }
                setTextColor(Color.parseColor("#E5E7EB"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
                setLineSpacing(dpPx(2f).toFloat(), 1.05f)
                maxLines = 7
                ellipsize = TextUtils.TruncateAt.END
                visibility = View.GONE
            }

            root.addView(header)
            root.addView(bodyTv)

            root.setOnClickListener {
                if (islandIsListening) {
                    finishListeningAndProcess()
                } else if (islandIsSpeaking || AssistantVoiceSpeaker.isSpeakingNow) {
                    AssistantVoiceSpeaker.stop(this@KeyMapperAccessibilityService)
                    islandIsSpeaking = false
                    startFollowUpListeningTurn()
                } else {
                    collapseDynamicIsland()
                }
            }

            val lp = WindowManager.LayoutParams(
                dpPx(460f),
                ViewGroup.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.BOTTOM or Gravity.START
                x = dpPx(54f)
                y = dpPx(38f)
            }

            wm.addView(root, lp)
            islandLayoutParams = lp
            islandRoot = root
            islandHeaderRow = header
            islandSparkIcon = spark
            islandWaveContainer = waveBox
            islandStatusText = statusTv
            islandHintText = hintTv
            islandBodyText = bodyTv
        } catch (_: Exception) {
        }
    }

    private fun morphDynamicIslandWidth(targetWidthDp: Float) {
        val wm = windowManager ?: return
        val root = islandRoot ?: return
        val lp = islandLayoutParams ?: return
        val endW = dpPx(targetWidthDp)

        islandMorphAnimator?.cancel()
        if (lp.width != endW) {
            val prevW = if (lp.width > 0) lp.width else dpPx(220f)
            lp.width = endW
            try {
                if (root.isAttachedToWindow) {
                    wm.updateViewLayout(root, lp)
                }
            } catch (_: Exception) {
            }
            root.pivotX = 0f
            root.pivotY = dpPx(26f).toFloat()
            val startScaleX = (prevW.toFloat() / endW.toFloat()).coerceIn(0.68f, 1.15f)
            root.scaleX = startScaleX
            root.animate()
                .scaleX(1f)
                .alpha(1f)
                .setDuration(210L)
                .setInterpolator(decelerateInterpolator)
                .start()
        }
    }

    fun triggerDynamicIslandAssistant(isFollowUp: Boolean = false) {
        uiHandler.post {
            ensureDynamicIslandOverlayCreated()
            refreshOverlayAccentColors()

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                val req = DynamicIslandBus.onRequestAudioPermissionInActivity
                if (req != null) {
                    req.invoke()
                } else {
                    val intent = Intent(this, LauncherActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        putExtra("EXTRA_OPEN_AI", true)
                    }
                    try {
                        startActivity(intent)
                    } catch (_: Exception) {
                    }
                }
                return@post
            }

            if (!isFollowUp && islandVisible && islandIsListening) {
                finishListeningAndProcess()
                return@post
            }

            AssistantVoiceSpeaker.stop(this)
            islandIsSpeaking = false
            uiHandler.removeCallbacks(hideIslandRunnable)
            geminiQueryJob?.cancel()
            stopVoiceListeningInternal()

            val root = islandRoot ?: return@post
            if (!isFollowUp || islandBodyText?.text.isNullOrBlank()) {
                islandBodyText?.visibility = View.GONE
            } else {
                islandBodyText?.visibility = View.VISIBLE
            }
            islandWaveContainer?.visibility = View.VISIBLE
            islandStatusText?.text = if (isFollowUp) "🎙 Ваш ответ (Назад — закрыть)" else "Слушаю... говорите"
            islandStatusText?.setTextColor(Color.parseColor("#F3F4F6"))
            islandHintText?.text = if (isFollowUp) "Назад — выход" else "OK — готово"
            islandVisible = true
            islandIsListening = true
            islandIsFollowUpListen = isFollowUp
            lastPartialTranscript = ""
            DynamicIslandBus.notifyIslandVisibility(true)

            if (root.visibility != View.VISIBLE) {
                root.alpha = 0f
                root.visibility = View.VISIBLE
                root.animate().alpha(1f).setDuration(140L).start()
            } else {
                root.animate().cancel()
                root.alpha = 1f
            }

            morphDynamicIslandWidth(470f)
            uiHandler.removeCallbacks(pulseWaveRunnable)
            uiHandler.post(pulseWaveRunnable)

            startSmartVoiceCapture()
        }
    }

    private fun startFollowUpListeningTurn() {
        if (!islandVisible) return
        triggerDynamicIslandAssistant(isFollowUp = true)
    }

    private fun startSmartVoiceCapture() {
        startDirectAudioRecordFallback()
    }

    private fun startSpeechRecognizerMultilingualFallback() {
        uiHandler.post {
            if (!islandVisible) return@post
            islandIsListening = true
            try {
                val sr = SpeechRecognizer.createSpeechRecognizer(this)
                speechRecognizer = sr
                sr.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {
                        updateWaveBarsFromRms(rmsdB)
                    }
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {
                        islandIsListening = false
                    }
                    override fun onError(error: Int) {
                        if (lastPartialTranscript.isNotBlank()) {
                            handleRecognizedVoiceText(lastPartialTranscript)
                        } else if (islandIsFollowUpListen) {
                            collapseDynamicIsland()
                        } else {
                            showIslandResult(GeminiTurnResult("✦ Не расслышал. Нажмите микрофон и скажите запрос.", false), isQuick = true)
                        }
                    }
                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull()?.trim().orEmpty().ifEmpty { lastPartialTranscript }
                        if (text.isNotBlank()) {
                            handleRecognizedVoiceText(text)
                        } else if (islandIsFollowUpListen) {
                            collapseDynamicIsland()
                        } else {
                            showIslandResult(GeminiTurnResult("✦ Не расслышал. Попробуйте ещё раз.", false), isQuick = true)
                        }
                    }
                    override fun onPartialResults(partialResults: Bundle?) {
                        val partial = partialResults
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                            ?.trim()
                            .orEmpty()
                        if (partial.isNotBlank()) {
                            lastPartialTranscript = partial
                            islandStatusText?.text = "«$partial»"
                        }
                    }
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })

                val recIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                }
                sr.startListening(recIntent)
            } catch (_: Exception) {
                showIslandResult(GeminiTurnResult("✦ Микрофон недоступен.", false), isQuick = true)
            }
        }
    }

    private fun updateWaveBarsFromRms(rmsdB: Float) {
        if (!islandVisible || !islandIsListening) return
        targetVoiceLevel = ((rmsdB + 2f) / 10f).coerceIn(0.28f, 1.0f)
    }

    @Suppress("MissingPermission")
    private fun createInitializedAudioRecord(sampleRate: Int, bufferSize: Int): AudioRecord? {
        val sources = intArrayOf(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            MediaRecorder.AudioSource.MIC,
            MediaRecorder.AudioSource.DEFAULT
        )
        for (attempt in 0 until 4) {
            for (src in sources) {
                try {
                    val candidate = AudioRecord(
                        src,
                        sampleRate,
                        AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT,
                        bufferSize
                    )
                    if (candidate.state == AudioRecord.STATE_INITIALIZED) {
                        return candidate
                    }
                    candidate.release()
                } catch (_: Exception) {
                }
            }
            try {
                Thread.sleep(90L)
            } catch (_: Exception) {
            }
        }
        return null
    }

    @Suppress("MissingPermission")
    private fun startDirectAudioRecordFallback() {
        val followUpMode = islandIsFollowUpListen
        audioRecordJob?.cancel()
        audioRecordJob = serviceScope.launch(Dispatchers.IO) {
            delay(if (followUpMode) 40L else 90L)
            val sampleRate = 16000
            val minBuf = AudioRecord.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(3200)

            var recorder: AudioRecord? = null
            val pcmOut = ByteArrayOutputStream()
            var maxObservedRms = 0.0
            var heardSpeech = false
            try {
                val rec = createInitializedAudioRecord(sampleRate, minBuf * 2)
                if (rec == null) {
                    startSpeechRecognizerMultilingualFallback()
                    return@launch
                }
                recorder = rec

                rec.startRecording()
                val buf = ShortArray(1024)
                val startMs = SystemClock.elapsedRealtime()
                var lastSpeechMs = startMs

                while (isActive && islandIsListening) {
                    val read = rec.read(buf, 0, buf.size)
                    if (read > 0) {
                        var sumSq = 0.0
                        val bb = ByteBuffer.allocate(read * 2).order(ByteOrder.LITTLE_ENDIAN)
                        for (i in 0 until read) {
                            val s = buf[i]
                            bb.putShort(s)
                            sumSq += (s.toDouble() * s.toDouble())
                        }
                        pcmOut.write(bb.array())

                        val rms = sqrt(sumSq / read)
                        if (rms > maxObservedRms) {
                            maxObservedRms = rms
                        }
                        val db = (rms / 170.0).toFloat().coerceIn(0f, 10f)
                        uiHandler.post { updateWaveBarsFromRms(db) }

                        val now = SystemClock.elapsedRealtime()
                        if (rms > 310) {
                            heardSpeech = true
                            lastSpeechMs = now
                        }
                        if (!heardSpeech && maxObservedRms < 15.0 && (now - startMs) > 1000L) {
                            break
                        }
                        // Если это авто-продолжение диалога и пользователь молчит 3.6 сек — тихо завершаем диалог
                        if (followUpMode && !heardSpeech && (now - startMs) > 5200L) {
                            break
                        }
                        // Fast VAD: как только речь закончилась и тишина длится 620 мс — мгновенно отправляем!
                        if (heardSpeech && (now - lastSpeechMs) > 620L && (now - startMs) > 780L) {
                            break
                        }
                        if ((now - startMs) > 5800L) {
                            break
                        }
                    } else {
                        delay(15L)
                    }
                }
            } catch (_: Exception) {
            } finally {
                try {
                    recorder?.stop()
                } catch (_: Exception) {
                }
                try {
                    recorder?.release()
                } catch (_: Exception) {
                }
            }

            if (maxObservedRms < 15.0 && islandIsListening) {
                startSpeechRecognizerMultilingualFallback()
                return@launch
            }

            val rawPcmBytes = pcmOut.toByteArray()
            withContext(Dispatchers.Main) {
                islandIsListening = false
                if (!heardSpeech && followUpMode) {
                    collapseDynamicIsland()
                    return@withContext
                }
                if (rawPcmBytes.size < 2800 || (!heardSpeech && maxObservedRms < 190.0)) {
                    if (followUpMode) {
                        collapseDynamicIsland()
                    } else {
                        showIslandResult(GeminiTurnResult("✦ Не расслышал запрос.", false), isQuick = true)
                    }
                } else {
                    val trimmedPcm = trimPcmSilence(rawPcmBytes, sampleRate)
                    val wavBytes = encodePcmToWav(trimmedPcm, sampleRate)
                    showIslandThinking("✦ Gemini думает...")
                    geminiQueryJob = serviceScope.launch {
                        val turnResult = GeminiCloudClient.askGeminiAudioTurn(this@KeyMapperAccessibilityService, wavBytes)
                        if (turnResult.isSilence && followUpMode) {
                            collapseDynamicIsland()
                        } else {
                            showIslandResult(
                                turnResult,
                                isQuick = turnResult.displayText.startsWith("✦") && turnResult.displayText.length <= 55 && !turnResult.shouldContinueDialog
                            )
                        }
                    }
                }
            }
        }
    }

    /**
     * Обрезает пустую тишину в начале и в конце аудиозаписи (оставляя 120 мс перед речью и 160 мс после),
     * чтобы WAV-файл был в 2–3 раза меньше и мгновенно улетал в Gemini!
     */
    private fun trimPcmSilence(pcmData: ByteArray, sampleRate: Int): ByteArray {
        val totalSamples = pcmData.size / 2
        if (totalSamples < 1600) return pcmData
        val frameSamples = 320 // 20 мс при 16 кГц
        val totalFrames = totalSamples / frameSamples
        var firstSpeechFrame = -1
        var lastSpeechFrame = -1

        val bb = ByteBuffer.wrap(pcmData).order(ByteOrder.LITTLE_ENDIAN)
        for (f in 0 until totalFrames) {
            var sumSq = 0.0
            val baseIdx = f * frameSamples * 2
            for (s in 0 until frameSamples) {
                val sample = bb.getShort(baseIdx + s * 2).toDouble()
                sumSq += sample * sample
            }
            val rms = sqrt(sumSq / frameSamples)
            if (rms > 240.0) {
                if (firstSpeechFrame == -1) firstSpeechFrame = f
                lastSpeechFrame = f
            }
        }

        if (firstSpeechFrame == -1 || lastSpeechFrame == -1) return pcmData
        val preRollFrames = (0.12 * sampleRate / frameSamples).toInt()
        val postRollFrames = (0.16 * sampleRate / frameSamples).toInt()
        val startFrame = (firstSpeechFrame - preRollFrames).coerceAtLeast(0)
        val endFrame = (lastSpeechFrame + postRollFrames + 1).coerceAtMost(totalFrames)
        val startByte = startFrame * frameSamples * 2
        val endByte = (endFrame * frameSamples * 2).coerceAtMost(pcmData.size)
        if (endByte <= startByte) return pcmData
        return pcmData.copyOfRange(startByte, endByte)
    }

    private fun encodePcmToWav(pcmData: ByteArray, sampleRate: Int): ByteArray {
        val totalDataLen = pcmData.size + 36
        val byteRate = sampleRate * 2
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray(Charsets.US_ASCII))
        header.putInt(totalDataLen)
        header.put("WAVE".toByteArray(Charsets.US_ASCII))
        header.put("fmt ".toByteArray(Charsets.US_ASCII))
        header.putInt(16)
        header.putShort(1.toShort())
        header.putShort(1.toShort())
        header.putInt(sampleRate)
        header.putInt(byteRate)
        header.putShort(2.toShort())
        header.putShort(16.toShort())
        header.put("data".toByteArray(Charsets.US_ASCII))
        header.putInt(pcmData.size)

        val out = ByteArray(44 + pcmData.size)
        System.arraycopy(header.array(), 0, out, 0, 44)
        System.arraycopy(pcmData, 0, out, 44, pcmData.size)
        return out
    }

    private fun finishListeningAndProcess() {
        if (!islandIsListening) return
        islandIsListening = false
        if (speechRecognizer != null) {
            try {
                speechRecognizer?.stopListening()
            } catch (_: Exception) {
            }
            if (lastPartialTranscript.isNotBlank()) {
                val captured = lastPartialTranscript
                stopSpeechRecognizerOnly()
                handleRecognizedVoiceText(captured)
            }
        }
    }

    private fun handleRecognizedVoiceText(recognizedText: String) {
        stopVoiceListeningInternal()
        val accent = resolveCurrentAccentColor()
        islandSparkIcon?.setColorFilter(accent, PorterDuff.Mode.SRC_IN)

        showIslandThinking("✦ Gemini думает: «$recognizedText»")
        geminiQueryJob?.cancel()
        geminiQueryJob = serviceScope.launch {
            val turnResult = GeminiCloudClient.askGeminiTextTurn(this@KeyMapperAccessibilityService, recognizedText)
            showIslandResult(turnResult, isQuick = turnResult.displayText.startsWith("✦") && !turnResult.shouldContinueDialog, queryTitle = recognizedText)
        }
    }

    private fun showIslandThinking(statusLabel: String) {
        islandIsListening = false
        islandIsSpeaking = false
        islandWaveContainer?.visibility = View.VISIBLE
        islandBodyText?.visibility = View.GONE
        islandStatusText?.text = statusLabel
        islandHintText?.text = "Назад — отмена"
        morphDynamicIslandWidth(460f)
    }

    private fun showIslandResult(turnResult: GeminiTurnResult, isQuick: Boolean, queryTitle: String = "") {
        val text = turnResult.displayText
        islandIsListening = false
        val accent = resolveCurrentAccentColor()
        islandSparkIcon?.setColorFilter(accent, PorterDuff.Mode.SRC_IN)
        uiHandler.removeCallbacks(hideIslandRunnable)

        val cleanDisplay = text.removePrefix("✦ ").trim()
        val isError = cleanDisplay.startsWith("Ошибка ответа") || cleanDisplay.startsWith("Не удалось")
        val ttsEnabled = AssistantVoiceSpeaker.isTtsEnabled(this)
        val shouldSpeak = ttsEnabled && !turnResult.isSilence && !isError
        val readingHoldMs = (6500L + cleanDisplay.length * 60L).coerceIn(8500L, 15000L)

        if (isQuick && !turnResult.shouldContinueDialog && cleanDisplay.length <= 48 && !shouldSpeak) {
            islandIsSpeaking = false
            islandWaveContainer?.visibility = View.GONE
            islandBodyText?.visibility = View.GONE
            islandStatusText?.text = cleanDisplay
            islandStatusText?.setTextColor(Color.parseColor("#F3F4F6"))
            islandHintText?.text = "OK — спросить ещё"
            morphDynamicIslandWidth(450f)
            uiHandler.postDelayed(hideIslandRunnable, 4200L)
            return
        }

        islandIsSpeaking = shouldSpeak
        islandWaveContainer?.visibility = if (shouldSpeak) View.VISIBLE else View.GONE
        islandStatusText?.text = when {
            shouldSpeak -> "🔊 Gemini отвечает..."
            turnResult.shouldContinueDialog -> "✦ Диалог · нажмите OK для ответа"
            queryTitle.isNotBlank() -> "Gemini · «$queryTitle»"
            else -> "Gemini"
        }
        islandStatusText?.setTextColor(accent)
        islandHintText?.text = "OK — ответить · Назад — закрыть"
        islandBodyText?.text = cleanDisplay
        islandBodyText?.visibility = View.VISIBLE
        morphDynamicIslandWidth(580f)

        if (shouldSpeak) {
            uiHandler.removeCallbacks(pulseWaveRunnable)
            uiHandler.post(pulseWaveRunnable)
            AssistantVoiceSpeaker.speak(this, cleanDisplay) { didPlayAudio ->
                islandIsSpeaking = false
                if (!islandVisible) return@speak
                if (turnResult.shouldContinueDialog) {
                    if (didPlayAudio) {
                        startFollowUpListeningTurn()
                    } else {
                        // Если аудио не воспроизводилось — даём спокойно прочитать текст перед авто-прослушиванием!
                        islandWaveContainer?.visibility = View.GONE
                        islandStatusText?.text = "✦ Gemini"
                        uiHandler.postDelayed({
                            if (islandVisible && !islandIsListening) {
                                startFollowUpListeningTurn()
                            }
                        }, 4500L)
                    }
                } else {
                    islandWaveContainer?.visibility = View.GONE
                    islandStatusText?.text = "✦ Gemini"
                    val holdAfterSpeech = if (didPlayAudio) 5500L else readingHoldMs
                    uiHandler.postDelayed(hideIslandRunnable, holdAfterSpeech)
                }
            }
        } else {
            uiHandler.removeCallbacks(pulseWaveRunnable)
            if (turnResult.shouldContinueDialog) {
                // Если озвучка выключена, даём 4.5 сек прочитать ответ, не пряча текст, и включаем микрофон
                uiHandler.postDelayed({
                    if (islandVisible && !islandIsListening) {
                        startFollowUpListeningTurn()
                    }
                }, 4500L)
            } else {
                uiHandler.postDelayed(hideIslandRunnable, readingHoldMs)
            }
        }
    }

    private fun collapseDynamicIsland() {
        uiHandler.removeCallbacks(hideIslandRunnable)
        uiHandler.removeCallbacks(pulseWaveRunnable)
        geminiQueryJob?.cancel()
        AssistantVoiceSpeaker.stop(this)
        islandIsSpeaking = false
        islandIsFollowUpListen = false
        stopVoiceListeningInternal()
        islandVisible = false
        val root = islandRoot ?: return
        if (root.visibility == View.VISIBLE) {
            morphDynamicIslandWidth(148f)
            root.animate()
                .alpha(0f)
                .setDuration(170L)
                .withEndAction {
                    root.visibility = View.GONE
                    islandBodyText?.visibility = View.GONE
                    DynamicIslandBus.notifyIslandVisibility(false)
                }
                .start()
        } else {
            DynamicIslandBus.notifyIslandVisibility(false)
        }
    }

    private fun stopSpeechRecognizerOnly() {
        val sr = speechRecognizer
        speechRecognizer = null
        if (sr != null) {
            try {
                sr.cancel()
            } catch (_: Exception) {
            }
            try {
                sr.destroy()
            } catch (_: Exception) {
            }
        }
    }

    private fun stopVoiceListeningInternal() {
        islandIsListening = false
        stopSpeechRecognizerOnly()
        audioRecordJob?.cancel()
        audioRecordJob = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        isServiceConnectedAlive = true
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return

        if (event.eventType == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            val notif = event.parcelableData as? Notification
            if (notif != null && pkg != packageName) {
                MediaStateBus.ingestNotification(
                    context = this,
                    pkg = pkg,
                    notif = notif,
                    requireActivePlaybackOrSession = false,
                    eventTexts = event.text
                )
            }
            return
        }

        if (isGoogleAssistantPackage(pkg)) {
            performGlobalAction(GLOBAL_ACTION_BACK)
            val now = SystemClock.elapsedRealtime()
            if (now - lastInterceptMillis > 450L) {
                lastInterceptMillis = now
                if (!islandVisible) {
                    triggerDynamicIslandAssistant()
                }
            }
            return
        }

        if (pkg != packageName && MediaStateBus.isKnownMediaPackage(pkg)) {
            if (event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
                event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            ) {
                tryScrapeMediaMetadataFromWindow(pkg)
            }
        }

        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && pkg != packageName) {

            MediaStateBus.onMediaAppOpened(pkg)

            val prefs = getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            val matchedPresetTarget: String? = when {
                isNetflixPackage(pkg) -> prefs.getString("preset_bind_NETFLIX", null)
                isPrimePackage(pkg) -> prefs.getString("preset_bind_PRIME", null)
                isPatchwallPackage(pkg) -> prefs.getString("preset_bind_PATCHWALL", "ACTION_CONTROL_CENTER")
                else -> null
            }

            if (!matchedPresetTarget.isNullOrEmpty()) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastInterceptMillis > 600L) {
                    lastInterceptMillis = now
                    executeBoundAction(matchedPresetTarget)
                }
            }
        }
    }

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        isServiceConnectedAlive = true
        val keyCode = event.keyCode
        val scanCode = event.scanCode

        if (event.action == KeyEvent.ACTION_DOWN && isSoundNavigationKey(keyCode)) {
            NavSoundPlayer.playClick(this)
        }

        if (islandVisible) {
            if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                    collapseDynamicIsland()
                }
                return true
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                    if (islandIsListening) {
                        finishListeningAndProcess()
                    } else if (islandIsSpeaking || AssistantVoiceSpeaker.isSpeakingNow) {
                        AssistantVoiceSpeaker.stop(this)
                        islandIsSpeaking = false
                        startFollowUpListeningTurn()
                    } else {
                        startFollowUpListeningTurn()
                    }
                }
                return true
            }
        }

        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
            keyCode == KeyEvent.KEYCODE_VOLUME_DOWN ||
            keyCode == KeyEvent.KEYCODE_VOLUME_MUTE
        ) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                try {
                    val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    when (keyCode) {
                        KeyEvent.KEYCODE_VOLUME_UP ->
                            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0)
                        KeyEvent.KEYCODE_VOLUME_DOWN ->
                            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0)
                        KeyEvent.KEYCODE_VOLUME_MUTE ->
                            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, 0)
                    }
                    lastKnownVolumePct = computeCurrentMusicVolumePct()
                    showGlobalVolumeOverlay()
                    VolumeHudBus.notifyVolumeChanged()
                } catch (_: Exception) {
                }
            }
            return true
        }

        if (KeyCaptureBus.isCapturingKey) {
            if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
                return false
            }
            if (isNavigationOrCenterKey(keyCode)) {
                return false
            }
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                KeyCaptureBus.notifyKeyCaptured(keyCode, scanCode)
            }
            return true
        }

        if (isNavigationOrCenterKey(keyCode)) {
            return false
        }

        val prefs = getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)

        if (keyCode == KeyEvent.KEYCODE_VOICE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_SEARCH ||
            scanCode == 582 || scanCode == 217 || scanCode == 221
        ) {
            val customAssistTarget = prefs.getString("key_bind_$keyCode", null) ?: "ACTION_AI"
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                executeBoundAction(customAssistTarget)
            }
            return true
        }

        val presetTarget = resolvePresetBinding(prefs, keyCode, scanCode)
        if (!presetTarget.isNullOrEmpty()) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                executeBoundAction(presetTarget)
            }
            return true
        }

        val boundTarget = prefs.getString("key_bind_$keyCode", null)
            ?: if (scanCode > 0) prefs.getString("scan_bind_$scanCode", null) else null

        if (boundTarget.isNullOrEmpty()) {
            return false
        }

        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            executeBoundAction(boundTarget)
        }
        return true
    }

    private fun resolvePresetBinding(
        prefs: android.content.SharedPreferences,
        keyCode: Int,
        scanCode: Int
    ): String? {
        if (keyCode == KeyEvent.KEYCODE_ALL_APPS ||
            keyCode == KeyEvent.KEYCODE_MENU ||
            keyCode == KeyEvent.KEYCODE_GUIDE ||
            keyCode == KeyEvent.KEYCODE_SETTINGS ||
            keyCode == KeyEvent.KEYCODE_TV_INPUT ||
            keyCode == KeyEvent.KEYCODE_BUTTON_1 ||
            scanCode == 139 || scanCode == 362 || scanCode == 172 || scanCode == 256
        ) {
            val target = prefs.getString("preset_bind_PATCHWALL", "ACTION_CONTROL_CENTER")
            if (!target.isNullOrEmpty()) return target
        }

        if (keyCode == KeyEvent.KEYCODE_BUTTON_2 ||
            keyCode == KeyEvent.KEYCODE_PROG_RED ||
            scanCode == 412 || scanCode == 398 || keyCode == 309
        ) {
            prefs.getString("preset_bind_NETFLIX", null)?.let { if (it.isNotEmpty()) return it }
        }

        if (keyCode == KeyEvent.KEYCODE_BUTTON_3 ||
            keyCode == KeyEvent.KEYCODE_PROG_BLUE ||
            scanCode == 413 || scanCode == 401 || keyCode == 310
        ) {
            prefs.getString("preset_bind_PRIME", null)?.let { if (it.isNotEmpty()) return it }
        }

        return null
    }

    private fun isGoogleAssistantPackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("katniss")
    }

    private fun isNetflixPackage(pkg: String): Boolean = pkg.lowercase().contains("netflix")

    private fun isPrimePackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("amazonvideo") || p.contains("amazon.avod") || p.contains("primevideo")
    }

    private fun isPatchwallPackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("patchwall") || p.contains("mitv.tvhome") || p.contains("mitv.smartshare")
    }

    private fun isSoundNavigationKey(keyCode: Int): Boolean {
        return keyCode == KeyEvent.KEYCODE_DPAD_UP ||
            keyCode == KeyEvent.KEYCODE_DPAD_DOWN ||
            keyCode == KeyEvent.KEYCODE_DPAD_LEFT ||
            keyCode == KeyEvent.KEYCODE_DPAD_RIGHT ||
            keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
            keyCode == KeyEvent.KEYCODE_ENTER ||
            keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER ||
            keyCode == KeyEvent.KEYCODE_BACK ||
            keyCode == KeyEvent.KEYCODE_HOME
    }

    private fun isNavigationOrCenterKey(keyCode: Int): Boolean {
        return keyCode == KeyEvent.KEYCODE_DPAD_UP ||
            keyCode == KeyEvent.KEYCODE_DPAD_DOWN ||
            keyCode == KeyEvent.KEYCODE_DPAD_LEFT ||
            keyCode == KeyEvent.KEYCODE_DPAD_RIGHT ||
            keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
            keyCode == KeyEvent.KEYCODE_ENTER ||
            keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER ||
            keyCode == KeyEvent.KEYCODE_HOME
    }

    private fun executeBoundAction(target: String) {
        when (target) {
            "ACTION_CONTROL_CENTER" -> {
                val intent = Intent(this, LauncherActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("EXTRA_OPEN_CONTROL_CENTER", true)
                }
                startActivity(intent)
            }
            "ACTION_ALL_APPS" -> {
                val intent = Intent(this, LauncherActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("EXTRA_OPEN_ALL_APPS", true)
                }
                startActivity(intent)
            }
            "ACTION_SETTINGS" -> {
                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    startActivity(intent)
                } catch (_: Exception) {
                }
            }
            "ACTION_AI" -> {
                triggerDynamicIslandAssistant()
            }
            else -> {
                MediaStateBus.onMediaAppOpened(target)
                val pm = packageManager
                val launchIntent = pm.getLeanbackLaunchIntentForPackage(target)
                    ?: pm.getLaunchIntentForPackage(target)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        startActivity(launchIntent)
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }

    private var lastScrapeRealtimeMs: Long = 0L
    private var inAppSearchJob: Job? = null

    private val UI_NOISE_WORDS = setOf(
        "home", "главная", "головна", "search", "поиск", "пошук",
        "library", "медиатека", "бібліотека", "settings", "настройки", "налаштування",
        "play", "pause", "next", "previous", "shuffle", "repeat", "like", "follow",
        "слушать", "слухати", "воспроизвести", "відтворити", "играть", "грати",
        "пауза", "далее", "далі", "назад", "перемешать", "повтор", "избранное", "нравится",
        "подписаться", "підписатися", "добавить", "додати", "ещё", "ще", "треки", "альбомы",
        "плейлисты", "исполнители", "рекомендации", "фоновое воспроизведение",
        "spotify", "soundcloud", "youtube", "smarttube", "deezer", "프리미엄", "premium",
        "войти", "увійти", "sign in", "log in", "back", "close", "закрыть",
        "очередь", "текст песни", "lyrics", "queue", "радио по треку", "поделиться",
        "перейти к альбому", "перейти к исполнителю", "похожие", "смотреть", "открыть"
    )

    private val DAY_OR_DATE_NOISE = listOf(
        "понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье",
        "понеділок", "вівторок", "середа", "четвер", "п'ятниця", "субота", "неділя",
        "января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа",
        "сентября", "октября", "ноября", "декабря", "в эфире"
    )

    private fun isNoiseUiText(text: String): Boolean {
        val clean = text.trim()
        if (clean.length < 2 || clean.length > 85) return true
        val lower = clean.lowercase(Locale.ROOT)
        if (lower in UI_NOISE_WORDS) return true
        if (DAY_OR_DATE_NOISE.any { lower.contains(it) }) return true
        if (clean.matches(Regex("^[0-9]{1,2}:[0-9]{2}(:[0-9]{2})?( / [0-9]{1,2}:[0-9]{2})?$"))) return true
        if (clean.matches(Regex("^[0-9]+$"))) return true
        return false
    }

    private fun parseTimeMmSsToMs(raw: String): Long {
        val parts = raw.trim().split(":")
        return try {
            when (parts.size) {
                2 -> (parts[0].toLong() * 60L + parts[1].toLong()) * 1000L
                3 -> (parts[0].toLong() * 3600L + parts[1].toLong() * 60L + parts[2].toLong()) * 1000L
                else -> -1L
            }
        } catch (_: Exception) {
            -1L
        }
    }

    /**
     * Чтение заголовка трека и исполнителя из окна медиа-приложения (включая WebView DOM внутри Spotify TV com.spotify.tv.android),
     * если системный MediaSession / dumpsys media_session ещё не отдал метаданные.
     * Никогда не считывает нажатия кнопок («Слушать») и никогда не читает окно лаунчера!
     */
    private fun tryScrapeMediaMetadataFromWindow(pkg: String) {
        if (pkg == packageName) return
        if (MediaStateBus.hasRealControllerMetadata()) return

        val now = SystemClock.elapsedRealtime()
        if (now - lastScrapeRealtimeMs < 1100L) return
        lastScrapeRealtimeMs = now

        val root = try {
            rootInActiveWindow
        } catch (_: Exception) {
            null
        } ?: return

        val rootPkg = root.packageName?.toString().orEmpty()
        if (rootPkg.isEmpty() || rootPkg == packageName || rootPkg != pkg || !MediaStateBus.isKnownMediaPackage(rootPkg)) return

        try {
            var idTitle = ""
            var idArtist = ""
            var scrapedPosMs = -1L
            var scrapedDurMs = -1L
            val allNodesFlat = mutableListOf<Pair<String, String>>()
            traverseMediaWindowNodes(root, allNodesFlat, depth = 0)

            // 1. Сначала проверяем явные Android resource ID (если приложение нативное)
            for ((vid, txt) in allNodesFlat) {
                val v = vid.lowercase(Locale.US)
                if (v.isEmpty()) continue
                if (idTitle.isEmpty() && (v.contains("track_title") || v.contains("now_playing_title") || v.contains("player_title") || v.contains("song_title") || v.contains("mini_player_title"))) {
                    if (!isNoiseUiText(txt)) idTitle = txt
                } else if (idArtist.isEmpty() && (v.contains("track_artist") || v.contains("now_playing_subtitle") || v.contains("player_artist") || v.contains("song_artist") || v.contains("mini_player_subtitle"))) {
                    if (!isNoiseUiText(txt) && txt != idTitle) idArtist = txt
                }
            }

            // 2. Если viewId пустые (например Spotify TV com.spotify.tv.android на WebView) — ищем пару (Трек + Артист) рядом с таймером воспроизведения 0:00..59:59
            if (idTitle.isEmpty()) {
                val timeRegex = Regex("^[0-9]{1,2}:[0-9]{2}$")
                val timeIdx = allNodesFlat.indexOfFirst { timeRegex.matches(it.second.trim()) }
                if (timeIdx >= 0) {
                    scrapedPosMs = parseTimeMmSsToMs(allNodesFlat[timeIdx].second)
                    for (j in (timeIdx + 1)..(timeIdx + 3).coerceAtMost(allNodesFlat.lastIndex)) {
                        val candidateTime = allNodesFlat[j].second.trim()
                        if (timeRegex.matches(candidateTime)) {
                            val dMs = parseTimeMmSsToMs(candidateTime)
                            if (dMs >= scrapedPosMs && dMs > 0L) {
                                scrapedDurMs = dMs
                            }
                            break
                        }
                    }

                    val beforeCandidates = mutableListOf<String>()
                    var k = timeIdx - 1
                    while (k >= 0 && beforeCandidates.size < 2) {
                        val candidate = allNodesFlat[k].second.trim()
                        if (!isNoiseUiText(candidate) && !beforeCandidates.contains(candidate)) {
                            beforeCandidates.add(0, candidate)
                        }
                        k--
                    }

                    if (beforeCandidates.isNotEmpty()) {
                        idTitle = beforeCandidates[0]
                        if (beforeCandidates.size >= 2) {
                            idArtist = beforeCandidates[1]
                        }
                    } else {
                        val afterCandidates = mutableListOf<String>()
                        var m = timeIdx + 1
                        while (m < allNodesFlat.size && afterCandidates.size < 2) {
                            val candidate = allNodesFlat[m].second.trim()
                            if (!isNoiseUiText(candidate) && !afterCandidates.contains(candidate)) {
                                afterCandidates.add(candidate)
                            }
                            m++
                        }
                        if (afterCandidates.isNotEmpty()) {
                            idTitle = afterCandidates[0]
                            if (afterCandidates.size >= 2) {
                                idArtist = afterCandidates[1]
                            }
                        }
                    }
                }
            }

            if (idTitle.isNotEmpty()) {
                val appLabel = MediaStateBus.resolveAppLabel(this, pkg)
                MediaStateBus.updateMetadata(
                    context = this,
                    title = idTitle,
                    artist = idArtist.ifEmpty { appLabel },
                    sourcePackage = pkg,
                    sourceAppName = appLabel,
                    cover = null,
                    durationMs = scrapedDurMs,
                    positionMs = scrapedPosMs
                )
            }
        } catch (_: Exception) {
        }
    }

    private fun traverseMediaWindowNodes(
        node: AccessibilityNodeInfo?,
        out: MutableList<Pair<String, String>>,
        depth: Int
    ) {
        if (node == null || depth > 14 || out.size > 120) return
        val vid = node.viewIdResourceName.orEmpty()
        val t = (node.text?.toString()?.trim().takeUnless { it.isNullOrEmpty() }
            ?: node.contentDescription?.toString()?.trim()).orEmpty()
        if (t.isNotEmpty()) {
            out.add(vid to t)
        }
        val count = node.childCount
        for (i in 0 until count) {
            val child = try { node.getChild(i) } catch (_: Exception) { null }
            if (child != null) {
                traverseMediaWindowNodes(child, out, depth + 1)
            }
        }
    }

    /**
     * ИИ-автоматизация внутри ТВ-приложений (например Kick на ТВ):
     * ждёт открытия окна приложения, находит кнопку «Поиск / Search», вводит имя стримера и открывает канал!
     */
    private fun runAutomatedInAppSearch(targetPkg: String, query: String) {
        val cleanQuery = query.trim()
        if (cleanQuery.isEmpty()) return
        inAppSearchJob?.cancel()
        inAppSearchJob = serviceScope.launch {
            copyToClipboard(cleanQuery)
            // Ждём загрузки интерфейса приложения (до 4.5 сек)
            var searchFieldFilled = false
            for (step in 0 until 7) {
                delay(if (step == 0) 1400L else 700L)
                val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: continue

                // 1. Если на экране уже есть активное или доступное поле ввода (EditText) — сразу вставляем текст!
                if (trySetTextInEditableNode(root, cleanQuery)) {
                    searchFieldFilled = true
                    break
                }

                // 2. Иначе ищем кнопку/вкладку «Search / Поиск / Пошук» в интерфейсе приложения и нажимаем её
                if (clickNodeMatchingKeywords(root, listOf("search", "поиск", "пошук", "find", "лупа"))) {
                    delay(850L)
                    val rootAfterClick = try { rootInActiveWindow } catch (_: Exception) { null }
                    if (rootAfterClick != null && trySetTextInEditableNode(rootAfterClick, cleanQuery)) {
                        searchFieldFilled = true
                        break
                    }
                }
            }

            if (searchFieldFilled) {
                delay(1100L)
                // Пробуем кликнуть по первому найденному каналу/результату с именем запроса
                val rootResult = try { rootInActiveWindow } catch (_: Exception) { null }
                if (rootResult != null) {
                    clickResultNodeMatchingQuery(rootResult, cleanQuery)
                }
            }
        }
    }

    private fun copyToClipboard(text: String) {
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return
            cm.setPrimaryClip(ClipData.newPlainText("ai_input", text))
        } catch (_: Exception) {
        }
    }

    private fun typeTextIntoActiveField(text: String): Boolean {
        val clean = text.trim()
        if (clean.isEmpty()) return false
        copyToClipboard(clean)
        val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: return false
        return trySetTextInEditableNode(root, clean)
    }

    private fun trySetTextInEditableNode(root: AccessibilityNodeInfo, text: String): Boolean {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        while (queue.isNotEmpty() && visited < 120) {
            val node = queue.removeFirst()
            visited++
            val cls = node.className?.toString().orEmpty()
            if (node.isEditable || cls.contains("EditText", ignoreCase = true) || cls.contains("AutoComplete", ignoreCase = true)) {
                node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                val args = Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
                }
                val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                if (!ok) {
                    node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
                }
                return true
            }
            for (i in 0 until node.childCount) {
                val c = try { node.getChild(i) } catch (_: Exception) { null }
                if (c != null) queue.add(c)
            }
        }
        return false
    }

    private fun clickElementOnScreenByText(targetText: String): Boolean {
        val clean = targetText.trim().lowercase(Locale.ROOT)
        if (clean.isEmpty()) return false
        val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: return false
        return clickNodeMatchingKeywords(root, listOf(clean))
    }

    private fun clickNodeMatchingKeywords(root: AccessibilityNodeInfo, keywords: List<String>): Boolean {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        while (queue.isNotEmpty() && visited < 140) {
            val node = queue.removeFirst()
            visited++
            val txt = node.text?.toString()?.lowercase(Locale.ROOT).orEmpty()
            val desc = node.contentDescription?.toString()?.lowercase(Locale.ROOT).orEmpty()
            val vid = node.viewIdResourceName?.lowercase(Locale.ROOT).orEmpty()
            val matched = keywords.any { kw ->
                txt.contains(kw) || desc.contains(kw) || vid.contains(kw)
            }
            if (matched) {
                var clickable: AccessibilityNodeInfo? = node
                var hops = 0
                while (clickable?.isClickable == false && hops < 4) {
                    clickable = clickable?.parent
                    hops++
                }
                val target = clickable ?: node
                target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                if (target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    return true
                }
            }
            for (i in 0 until node.childCount) {
                val c = try { node.getChild(i) } catch (_: Exception) { null }
                if (c != null) queue.add(c)
            }
        }
        return false
    }

    private fun clickResultNodeMatchingQuery(root: AccessibilityNodeInfo, query: String): Boolean {
        val kw = query.lowercase(Locale.ROOT)
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        while (queue.isNotEmpty() && visited < 140) {
            val node = queue.removeFirst()
            visited++
            val cls = node.className?.toString().orEmpty()
            if (node.isEditable || cls.contains("EditText", ignoreCase = true)) {
                continue
            }
            val txt = node.text?.toString()?.lowercase(Locale.ROOT).orEmpty()
            val desc = node.contentDescription?.toString()?.lowercase(Locale.ROOT).orEmpty()
            if (txt.contains(kw) || desc.contains(kw)) {
                var clickable: AccessibilityNodeInfo? = node
                var hops = 0
                while (clickable?.isClickable == false && hops < 4) {
                    clickable = clickable?.parent
                    hops++
                }
                val target = clickable ?: node
                target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                if (target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    return true
                }
            }
            for (i in 0 until node.childCount) {
                val c = try { node.getChild(i) } catch (_: Exception) { null }
                if (c != null) queue.add(c)
            }
        }
        return false
    }

    private fun triggerDynamicIslandWithRemoteText(spokenText: String) {
        uiHandler.post {
            ensureDynamicIslandOverlayCreated()
            refreshOverlayAccentColors()
            AssistantVoiceSpeaker.stop(this)
            islandIsSpeaking = false
            uiHandler.removeCallbacks(hideIslandRunnable)
            geminiQueryJob?.cancel()
            stopVoiceListeningInternal()

            val root = islandRoot ?: return@post
            islandVisible = true
            DynamicIslandBus.notifyIslandVisibility(true)
            if (root.visibility != View.VISIBLE) {
                root.alpha = 0f
                root.visibility = View.VISIBLE
                root.animate().alpha(1f).setDuration(140L).start()
            } else {
                root.animate().cancel()
                root.alpha = 1f
            }
            handleRecognizedVoiceText(spokenText)
        }
    }

    private fun injectAccessibilityDpadOrCenter(directionOrCenter: String): Boolean {
        val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: root
        return when (directionOrCenter.uppercase(Locale.US)) {
            "CENTER", "OK" -> focused.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            "UP" -> focused.focusSearch(View.FOCUS_UP)?.performAction(AccessibilityNodeInfo.ACTION_FOCUS) == true
            "DOWN" -> focused.focusSearch(View.FOCUS_DOWN)?.performAction(AccessibilityNodeInfo.ACTION_FOCUS) == true
            "LEFT" -> focused.focusSearch(View.FOCUS_LEFT)?.performAction(AccessibilityNodeInfo.ACTION_FOCUS) == true
            "RIGHT" -> focused.focusSearch(View.FOCUS_RIGHT)?.performAction(AccessibilityNodeInfo.ACTION_FOCUS) == true
            else -> false
        }
    }

    private fun performGlobalNavigationCommand(action: String) {
        when (action.uppercase(Locale.US)) {
            "BACK" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "HOME" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "RECENTS" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "NOTIFICATIONS" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        }
    }
}
