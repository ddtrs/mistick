package com.mitv.customlauncher.service

import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.Parcelable
import android.os.SystemClock
import android.provider.Settings
import android.util.LruCache
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.mitv.customlauncher.data.LauncherConfig
import com.mitv.customlauncher.ui.LauncherActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.net.HttpURLConnection
import java.net.URL

data class NowPlayingSnapshot(
    val isPlaying: Boolean = false,
    val title: String = "",
    val artist: String = "",
    val upNextTitle: String = "",
    val sourcePackage: String = "",
    val sourceAppName: String = "",
    val coverBitmap: Bitmap? = null,
    val durationMs: Long = 0L,
    val basePositionMs: Long = 0L,
    val baseElapsedRealtime: Long = 0L,
    val playbackSpeed: Float = 1.0f
)

object VolumeHudBus {
    @Volatile
    var onVolumeIntercepted: (() -> Unit)? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    fun notifyVolumeChanged() {
        val listener = onVolumeIntercepted ?: return
        mainHandler.post { listener.invoke() }
    }
}

object MediaStateBus {
    private val _state = MutableStateFlow(NowPlayingSnapshot())
    val state: StateFlow<NowPlayingSnapshot> = _state.asStateFlow()

    @Volatile
    var activeController: MediaController? = null

    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val artUriCache = object : LruCache<String, Bitmap>(16) {}
    private var lastFetchedArtUri: String = ""

    private var trackStartRealtime: Long = SystemClock.elapsedRealtime()
    private var lastTrackTitle: String = ""

    fun updateMetadata(
        title: String,
        artist: String,
        sourcePackage: String,
        sourceAppName: String,
        cover: Bitmap?,
        artUri: String = "",
        upNextTitle: String = "",
        durationMs: Long = -1L,
        positionMs: Long = -1L,
        positionUpdateRealtime: Long = 0L,
        speed: Float = 1.0f
    ) {
        val current = _state.value
        val resolvedTitle = if (title.isNotBlank()) title else current.title
        val titleChanged = resolvedTitle.isNotBlank() && resolvedTitle != lastTrackTitle
        if (titleChanged) {
            lastTrackTitle = resolvedTitle
            trackStartRealtime = SystemClock.elapsedRealtime()
        }

        var resolvedCover = cover ?: if (!titleChanged) current.coverBitmap else null
        if (resolvedCover == null && artUri.isNotBlank()) {
            resolvedCover = artUriCache.get(artUri)
            if (resolvedCover == null && artUri != lastFetchedArtUri) {
                lastFetchedArtUri = artUri
                fetchArtFromUriAsync(artUri)
            }
        }

        val resolvedDuration = if (durationMs >= 0L) durationMs else if (titleChanged) 0L else current.durationMs
        val resolvedPos = if (positionMs >= 0L) positionMs else if (titleChanged) 0L else current.basePositionMs
        val resolvedRealtime = if (positionUpdateRealtime > 0L) positionUpdateRealtime else SystemClock.elapsedRealtime()

        _state.value = current.copy(
            title = resolvedTitle,
            artist = if (artist.isNotBlank()) artist else current.artist,
            upNextTitle = if (upNextTitle.isNotBlank()) upNextTitle else if (titleChanged) "" else current.upNextTitle,
            sourcePackage = if (sourcePackage.isNotBlank()) sourcePackage else current.sourcePackage,
            sourceAppName = if (sourceAppName.isNotBlank()) sourceAppName else current.sourceAppName,
            coverBitmap = resolvedCover,
            durationMs = resolvedDuration,
            basePositionMs = resolvedPos,
            baseElapsedRealtime = resolvedRealtime,
            playbackSpeed = if (speed > 0f) speed else 1.0f
        )
    }

    private fun fetchArtFromUriAsync(uriString: String) {
        ioScope.launch {
            try {
                if (!uriString.startsWith("http://") && !uriString.startsWith("https://")) return@launch
                val conn = (URL(uriString).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 3500
                    readTimeout = 3500
                    doInput = true
                }
                conn.connect()
                val raw = conn.inputStream.use { BitmapFactory.decodeStream(it) }
                conn.disconnect()
                if (raw != null) {
                    val scaled = Bitmap.createScaledBitmap(raw, 112, 112, true)
                    artUriCache.put(uriString, scaled)
                    _state.value = _state.value.copy(coverBitmap = scaled)
                }
            } catch (_: Exception) {
            }
        }
    }

    fun updatePlayingFlag(isPlaying: Boolean) {
        val cur = _state.value
        if (cur.isPlaying != isPlaying) {
            if (isPlaying && !cur.isPlaying && cur.basePositionMs == 0L) {
                trackStartRealtime = SystemClock.elapsedRealtime()
            }
            _state.value = cur.copy(isPlaying = isPlaying)
        }
    }

    /**
     * Живой опрос активного MediaController раз в секунду (чтобы на самой приставке тайминг, обложка и «Далее» обновлялись в реальном времени!)
     */
    fun pollActiveController() {
        val ctrl = activeController ?: return
        try {
            val meta = ctrl.metadata
            val pb = ctrl.playbackState
            var title = ""
            var artist = ""
            var dur = -1L
            var cover: Bitmap? = null
            var artUri = ""

            if (meta != null) {
                title = meta.getString(MediaMetadata.METADATA_KEY_TITLE)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
                    ?: ""
                artist = meta.getString(MediaMetadata.METADATA_KEY_ARTIST)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
                    ?: ""
                val d = meta.getLong(MediaMetadata.METADATA_KEY_DURATION)
                if (d > 0L) dur = d

                val rawArt = meta.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                    ?: meta.getBitmap(MediaMetadata.METADATA_KEY_ART)
                    ?: meta.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                if (rawArt != null) {
                    cover = Bitmap.createScaledBitmap(rawArt, 112, 112, true)
                } else {
                    artUri = meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_ART_URI)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)
                        ?: ""
                }
            }

            var pos = -1L
            var posTime = 0L
            var spd = 1.0f
            var activeQueueId = MediaSession.QueueItem.UNKNOWN_ID.toLong()

            if (pb != null) {
                pos = pb.position
                posTime = pb.lastPositionUpdateTime
                spd = pb.playbackSpeed
                activeQueueId = pb.activeQueueItemId
                updatePlayingFlag(pb.state == PlaybackState.STATE_PLAYING)
            }

            // Проверяем следующий трек в очереди только когда до конца осталось <= 14 секунд
            var nextTitle = _state.value.upNextTitle
            if (dur > 0L && pos >= 0L && (dur - pos) in 1L..14000L && nextTitle.isEmpty()) {
                nextTitle = extractNextTrackFromQueue(ctrl, activeQueueId, title.ifEmpty { _state.value.title })
            }

            if (title.isNotEmpty() || artist.isNotEmpty() || cover != null || artUri.isNotEmpty() || pos >= 0L) {
                updateMetadata(
                    title = title,
                    artist = artist,
                    sourcePackage = ctrl.packageName ?: "",
                    sourceAppName = "",
                    cover = cover,
                    artUri = artUri,
                    upNextTitle = nextTitle,
                    durationMs = dur,
                    positionMs = pos,
                    positionUpdateRealtime = posTime,
                    speed = spd
                )
            }
        } catch (_: Exception) {
        }
    }

    private fun extractNextTrackFromQueue(
        ctrl: MediaController,
        activeQueueId: Long,
        currentTitle: String
    ): String {
        return try {
            val queue = ctrl.queue ?: return ""
            if (queue.size < 2) return ""
            var activeIdx = -1
            if (activeQueueId != MediaSession.QueueItem.UNKNOWN_ID.toLong()) {
                activeIdx = queue.indexOfFirst { it.queueId == activeQueueId }
            }
            if (activeIdx == -1 && currentTitle.isNotBlank()) {
                activeIdx = queue.indexOfFirst {
                    it.description.title?.toString()?.equals(currentTitle, ignoreCase = true) == true
                }
            }
            if (activeIdx in 0 until (queue.size - 1)) {
                val nextItem = queue[activeIdx + 1].description
                val nt = nextItem.title?.toString()?.trim().orEmpty()
                val na = nextItem.subtitle?.toString()?.trim().orEmpty()
                if (nt.isNotEmpty() && na.isNotEmpty()) "$nt · $na" else nt
            } else {
                ""
            }
        } catch (_: Exception) {
            ""
        }
    }

    fun getLivePositionAndDuration(): Pair<Long, Long> {
        val ctrl = activeController
        if (ctrl != null) {
            try {
                val meta = ctrl.metadata
                val pb = ctrl.playbackState
                val dur = meta?.getLong(MediaMetadata.METADATA_KEY_DURATION)?.coerceAtLeast(0L)
                    ?: _state.value.durationMs
                if (pb != null && pb.position >= 0L) {
                    var pos = pb.position
                    if (pb.state == PlaybackState.STATE_PLAYING && pb.lastPositionUpdateTime > 0L) {
                        val delta = SystemClock.elapsedRealtime() - pb.lastPositionUpdateTime
                        pos += (delta * pb.playbackSpeed).toLong().coerceAtLeast(0L)
                    }
                    if (dur > 0L) pos = pos.coerceAtMost(dur)
                    return pos to dur
                }
            } catch (_: Exception) {
            }
        }

        val snap = _state.value
        val dur = snap.durationMs.coerceAtLeast(0L)
        if (snap.basePositionMs > 0L && snap.baseElapsedRealtime > 0L) {
            val delta = if (snap.isPlaying) SystemClock.elapsedRealtime() - snap.baseElapsedRealtime else 0L
            var pos = snap.basePositionMs + (delta * snap.playbackSpeed).toLong().coerceAtLeast(0L)
            if (dur > 0L) pos = pos.coerceAtMost(dur)
            return pos to dur
        }

        val elapsed = (SystemClock.elapsedRealtime() - trackStartRealtime).coerceAtLeast(0L)
        return elapsed to dur
    }

    fun dispatchTransportAction(action: String, audioManager: AudioManager) {
        val ctrl = activeController
        try {
            if (ctrl != null) {
                val tc = ctrl.transportControls
                val pbState = ctrl.playbackState?.state
                when (action) {
                    "PREV" -> {
                        tc.skipToPrevious()
                        return
                    }
                    "NEXT" -> {
                        tc.skipToNext()
                        return
                    }
                    "PLAY_PAUSE" -> {
                        if (pbState == PlaybackState.STATE_PLAYING || audioManager.isMusicActive) {
                            tc.pause()
                        } else {
                            tc.play()
                        }
                        return
                    }
                }
            }
        } catch (_: Exception) {
        }

        val keyCode = when (action) {
            "PREV" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "NEXT" -> KeyEvent.KEYCODE_MEDIA_NEXT
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        try {
            val now = SystemClock.uptimeMillis()
            audioManager.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0))
            audioManager.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_UP, keyCode, 0))
        } catch (_: Exception) {
        }
    }
}

object KeyCaptureBus {
    @Volatile
    var isCapturingKey: Boolean = false

    @Volatile
    var onKeyCapturedListener: ((keyCode: Int, scanCode: Int) -> Unit)? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    fun notifyKeyCaptured(keyCode: Int, scanCode: Int): Boolean {
        val listener = onKeyCapturedListener ?: return false
        isCapturingKey = false
        mainHandler.post {
            listener.invoke(keyCode, scanCode)
        }
        return true
    }
}

class KeyMapperAccessibilityService : AccessibilityService() {

    private var lastInterceptMillis: Long = 0L
    private var currentControllerCallback: MediaController.Callback? = null

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return

        if (event.eventType == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            val notif = event.parcelableData as? Notification
            if (notif != null && pkg != packageName) {
                extractMediaFromNotification(pkg, notif)
            }
            return
        }

        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && pkg != packageName) {
            if (isKnownMediaApp(pkg)) {
                val appLabel = resolveAppLabel(pkg)
                MediaStateBus.updateMetadata(
                    title = "",
                    artist = "",
                    sourcePackage = pkg,
                    sourceAppName = appLabel,
                    cover = null
                )
            }

            val prefs = getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            val matchedPresetTarget: String? = when {
                isNetflixPackage(pkg) -> prefs.getString("preset_bind_NETFLIX", null)
                isPrimePackage(pkg) -> prefs.getString("preset_bind_PRIME", null)
                isPatchwallPackage(pkg) -> prefs.getString("preset_bind_PATCHWALL", null)
                else -> null
            }

            if (!matchedPresetTarget.isNullOrEmpty()) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastInterceptMillis > 600L) {
                    lastInterceptMillis = now
                    executeBoundAction(matchedPresetTarget)
                }
            }
        }
    }

    private fun extractMediaFromNotification(pkg: String, notif: Notification) {
        try {
            val extras = notif.extras ?: return
            var title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
            var text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
            val appName = resolveAppLabel(pkg)

            var coverBmp: Bitmap? = null
            var artUri = ""
            var durationMs = -1L
            var posMs = -1L
            var posRealtime = 0L
            var speed = 1.0f

            @Suppress("DEPRECATION")
            val sessionToken = extras.getParcelable<Parcelable>(Notification.EXTRA_MEDIA_SESSION) as? MediaSession.Token
            if (sessionToken != null) {
                try {
                    val controller = MediaController(this, sessionToken)
                    attachControllerCallback(pkg, appName, controller)

                    val meta = controller.metadata
                    if (meta != null) {
                        val metaTitle = meta.getString(MediaMetadata.METADATA_KEY_TITLE)
                            ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
                        val metaArtist = meta.getString(MediaMetadata.METADATA_KEY_ARTIST)
                            ?: meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                            ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
                        if (!metaTitle.isNullOrBlank()) title = metaTitle
                        if (!metaArtist.isNullOrBlank()) text = metaArtist

                        val d = meta.getLong(MediaMetadata.METADATA_KEY_DURATION)
                        if (d > 0L) durationMs = d

                        val rawArt = meta.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                            ?: meta.getBitmap(MediaMetadata.METADATA_KEY_ART)
                            ?: meta.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                        if (rawArt != null) {
                            coverBmp = Bitmap.createScaledBitmap(rawArt, 112, 112, true)
                        } else {
                            artUri = meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
                                ?: meta.getString(MediaMetadata.METADATA_KEY_ART_URI)
                                ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)
                                ?: ""
                        }
                    }

                    val pb = controller.playbackState
                    if (pb != null) {
                        posMs = pb.position
                        posRealtime = pb.lastPositionUpdateTime
                        speed = pb.playbackSpeed
                        MediaStateBus.updatePlayingFlag(pb.state == PlaybackState.STATE_PLAYING)
                    }
                } catch (_: Exception) {
                }
            }

            if (coverBmp == null) {
                val largeIcon = notif.getLargeIcon()
                if (largeIcon != null) {
                    val d = largeIcon.loadDrawable(this)
                    if (d != null) {
                        coverBmp = drawableToSmallBitmap(d)
                    }
                }
            }
            if (coverBmp == null) {
                @Suppress("DEPRECATION")
                val extraBmp = (extras.getParcelable<Parcelable>(Notification.EXTRA_LARGE_ICON_BIG) as? Bitmap)
                    ?: (extras.getParcelable<Parcelable>(Notification.EXTRA_LARGE_ICON) as? Bitmap)
                    ?: (extras.getParcelable<Parcelable>(Notification.EXTRA_PICTURE) as? Bitmap)
                if (extraBmp != null) {
                    coverBmp = Bitmap.createScaledBitmap(extraBmp, 112, 112, true)
                }
            }

            if (title.isEmpty() && text.isEmpty() && coverBmp == null && artUri.isEmpty()) return

            MediaStateBus.updateMetadata(
                title = title,
                artist = text,
                sourcePackage = pkg,
                sourceAppName = appName,
                cover = coverBmp,
                artUri = artUri,
                durationMs = durationMs,
                positionMs = posMs,
                positionUpdateRealtime = posRealtime,
                speed = speed
            )
        } catch (_: Exception) {
        }
    }

    private fun attachControllerCallback(pkg: String, appName: String, controller: MediaController) {
        try {
            val prev = MediaStateBus.activeController
            val prevCb = currentControllerCallback
            if (prev != null && prevCb != null) {
                try {
                    prev.unregisterCallback(prevCb)
                } catch (_: Exception) {
                }
            }

            MediaStateBus.activeController = controller
            val cb = object : MediaController.Callback() {
                override fun onPlaybackStateChanged(state: PlaybackState?) {
                    if (state != null) {
                        MediaStateBus.updatePlayingFlag(state.state == PlaybackState.STATE_PLAYING)
                        MediaStateBus.updateMetadata(
                            title = "",
                            artist = "",
                            sourcePackage = pkg,
                            sourceAppName = appName,
                            cover = null,
                            positionMs = state.position,
                            positionUpdateRealtime = state.lastPositionUpdateTime,
                            speed = state.playbackSpeed
                        )
                    }
                }

                override fun onMetadataChanged(metadata: MediaMetadata?) {
                    if (metadata != null) {
                        val t = metadata.getString(MediaMetadata.METADATA_KEY_TITLE).orEmpty()
                        val a = metadata.getString(MediaMetadata.METADATA_KEY_ARTIST).orEmpty()
                        val dur = metadata.getLong(MediaMetadata.METADATA_KEY_DURATION)
                        val art = metadata.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                            ?: metadata.getBitmap(MediaMetadata.METADATA_KEY_ART)
                        val scaled = if (art != null) Bitmap.createScaledBitmap(art, 112, 112, true) else null
                        val uri = metadata.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
                            ?: metadata.getString(MediaMetadata.METADATA_KEY_ART_URI)
                            ?: ""
                        MediaStateBus.updateMetadata(
                            title = t,
                            artist = a,
                            sourcePackage = pkg,
                            sourceAppName = appName,
                            cover = scaled,
                            artUri = uri,
                            durationMs = if (dur > 0L) dur else -1L
                        )
                    }
                }
            }
            currentControllerCallback = cb
            controller.registerCallback(cb, Handler(Looper.getMainLooper()))
        } catch (_: Exception) {
        }
    }

    private fun drawableToSmallBitmap(d: Drawable): Bitmap? {
        return try {
            if (d is BitmapDrawable && d.bitmap != null) {
                Bitmap.createScaledBitmap(d.bitmap, 112, 112, true)
            } else {
                val bmp = Bitmap.createBitmap(112, 112, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bmp)
                d.setBounds(0, 0, 112, 112)
                d.draw(canvas)
                bmp
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun resolveAppLabel(pkg: String): String {
        return try {
            val ai = packageManager.getApplicationInfo(pkg, 0)
            packageManager.getApplicationLabel(ai).toString()
        } catch (_: Exception) {
            pkg.substringAfterLast('.')
        }
    }

    private fun isKnownMediaApp(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("youtube") || p.contains("smarttube") || p.contains("spotify") ||
            p.contains("soundcloud") || p.contains("music") || p.contains("vlc") ||
            p.contains("kodi") || p.contains("lampa") || p.contains("kino") || p.contains("mediashell")
    }

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val keyCode = event.keyCode
        val scanCode = event.scanCode

        // 0. Глобальный перехват качельки громкости (+ / - / Mute) ДО системы Android TV!
        // Возврат true полностью блокирует появление стокового серого ползунка громкости Android!
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
            keyCode == KeyEvent.KEYCODE_VOLUME_DOWN ||
            keyCode == KeyEvent.KEYCODE_VOLUME_MUTE
        ) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                try {
                    val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    when (keyCode) {
                        KeyEvent.KEYCODE_VOLUME_UP ->
                            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0)
                        KeyEvent.KEYCODE_VOLUME_DOWN ->
                            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0)
                        KeyEvent.KEYCODE_VOLUME_MUTE ->
                            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, 0)
                    }
                    VolumeHudBus.notifyVolumeChanged()
                } catch (_: Exception) {
                }
            }
            return true
        }

        if (isNavigationOrCenterKey(keyCode)) {
            return false
        }

        if (KeyCaptureBus.isCapturingKey) {
            if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
                return false
            }
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                KeyCaptureBus.notifyKeyCaptured(keyCode, scanCode)
            }
            return true
        }

        val prefs = getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)

        if (keyCode == KeyEvent.KEYCODE_VOICE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_SEARCH
        ) {
            val customAssistTarget = prefs.getString("key_bind_$keyCode", null) ?: "ACTION_AI"
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                executeBoundAction(customAssistTarget)
            }
            return true
        }

        val presetTarget = resolvePresetBinding(prefs, keyCode, scanCode)
        if (!presetTarget.isNullOrEmpty()) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                executeBoundAction(presetTarget)
            }
            return true
        }

        val boundTarget = prefs.getString("key_bind_$keyCode", null)
            ?: if (scanCode > 0) prefs.getString("scan_bind_$scanCode", null) else null

        if (boundTarget.isNullOrEmpty()) {
            return false
        }

        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            executeBoundAction(boundTarget)
        }
        return true
    }

    private fun resolvePresetBinding(
        prefs: android.content.SharedPreferences,
        keyCode: Int,
        scanCode: Int
    ): String? {
        if (keyCode == KeyEvent.KEYCODE_ALL_APPS ||
            keyCode == KeyEvent.KEYCODE_MENU ||
            keyCode == KeyEvent.KEYCODE_GUIDE ||
            keyCode == KeyEvent.KEYCODE_SETTINGS ||
            keyCode == KeyEvent.KEYCODE_TV_INPUT ||
            keyCode == KeyEvent.KEYCODE_BUTTON_1 ||
            scanCode == 139 || scanCode == 362 || scanCode == 172 || scanCode == 256
        ) {
            prefs.getString("preset_bind_PATCHWALL", null)?.let { if (it.isNotEmpty()) return it }
        }

        if (keyCode == KeyEvent.KEYCODE_BUTTON_2 ||
            keyCode == KeyEvent.KEYCODE_PROG_RED ||
            scanCode == 412 || scanCode == 398 || keyCode == 309
        ) {
            prefs.getString("preset_bind_NETFLIX", null)?.let { if (it.isNotEmpty()) return it }
        }

        if (keyCode == KeyEvent.KEYCODE_BUTTON_3 ||
            keyCode == KeyEvent.KEYCODE_PROG_BLUE ||
            scanCode == 413 || scanCode == 401 || keyCode == 310
        ) {
            prefs.getString("preset_bind_PRIME", null)?.let { if (it.isNotEmpty()) return it }
        }

        return null
    }

    private fun isNetflixPackage(pkg: String): Boolean = pkg.lowercase().contains("netflix")

    private fun isPrimePackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("amazonvideo") || p.contains("amazon.avod") || p.contains("primevideo")
    }

    private fun isPatchwallPackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("patchwall") || p.contains("mitv.tvhome") || p.contains("mitv.smartshare")
    }

    private fun isNavigationOrCenterKey(keyCode: Int): Boolean {
        return keyCode == KeyEvent.KEYCODE_DPAD_UP ||
            keyCode == KeyEvent.KEYCODE_DPAD_DOWN ||
            keyCode == KeyEvent.KEYCODE_DPAD_LEFT ||
            keyCode == KeyEvent.KEYCODE_DPAD_RIGHT ||
            keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
            keyCode == KeyEvent.KEYCODE_ENTER ||
            keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER ||
            keyCode == KeyEvent.KEYCODE_HOME
    }

    private fun executeBoundAction(target: String) {
        when (target) {
            "ACTION_ALL_APPS" -> {
                val intent = Intent(this, LauncherActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("EXTRA_OPEN_ALL_APPS", true)
                }
                startActivity(intent)
            }
            "ACTION_SETTINGS" -> {
                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    startActivity(intent)
                } catch (_: Exception) {
                }
            }
            "ACTION_AI" -> {
                val intent = Intent(this, LauncherActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("EXTRA_OPEN_AI", true)
                }
                startActivity(intent)
            }
            else -> {
                val pm = packageManager
                val launchIntent = pm.getLeanbackLaunchIntentForPackage(target)
                    ?: pm.getLaunchIntentForPackage(target)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        startActivity(launchIntent)
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }
}
