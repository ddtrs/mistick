package com.mitv.customlauncher.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Parcelable
import android.os.SystemClock
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.LruCache
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import androidx.core.content.ContextCompat
import com.mitv.customlauncher.data.LauncherConfig
import com.mitv.customlauncher.ui.LauncherActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.net.HttpURLConnection
import java.net.URL

data class NowPlayingSnapshot(
    val hasActiveSession: Boolean = false,
    val isPlaying: Boolean = false,
    val title: String = "",
    val artist: String = "",
    val sourcePackage: String = "",
    val sourceAppName: String = "",
    val coverBitmap: Bitmap? = null,
    val durationMs: Long = 0L,
    val basePositionMs: Long = 0L,
    val baseElapsedRealtime: Long = 0L,
    val playbackSpeed: Float = 1.0f
)

object ServiceAutoActivator {
    private val mainHandler = Handler(Looper.getMainLooper())
    private var lastRebindAttemptMs: Long = 0L

    fun hasWriteSecureSettings(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.WRITE_SECURE_SETTINGS
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun ensureServicesActive(context: Context) {
        if (!hasWriteSecureSettings(context)) return
        val cr = context.contentResolver
        val pkg = context.packageName
        val accFlat = "$pkg/$pkg.service.KeyMapperAccessibilityService"
        val accShort = "$pkg/.service.KeyMapperAccessibilityService"
        val notifFlat = "$pkg/$pkg.service.MediaSessionListenerService"
        val notifShort = "$pkg/.service.MediaSessionListenerService"

        try {
            // 1. Записываем наш компонент в enabled_notification_listeners.
            // В Android 9/10 MediaSessionService.isEnabledNotificationListener проверяет ТОЛЬКО эту строку в Settings.Secure!
            val curNotif = Settings.Secure.getString(cr, "enabled_notification_listeners").orEmpty()
            if (!curNotif.contains(notifFlat)) {
                val base = if (curNotif.isBlank()) "" else "$curNotif:"
                Settings.Secure.putString(cr, "enabled_notification_listeners", "$base$notifFlat:$notifShort")
            }

            // 2. Авто-пробуждение KeyMapperAccessibilityService после установки обновлений APK
            if (!KeyMapperAccessibilityService.isServiceConnectedAlive) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastRebindAttemptMs > 4000L) {
                    lastRebindAttemptMs = now
                    val curAcc = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
                    val cleaned = curAcc.split(':')
                        .filter { it.isNotBlank() && it != accFlat && it != accShort && !it.startsWith("$pkg/") }
                        .joinToString(":")

                    Settings.Secure.putString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, cleaned)
                    mainHandler.postDelayed({
                        try {
                            val reEnabled = if (cleaned.isBlank()) accFlat else "$cleaned:$accFlat"
                            Settings.Secure.putString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, reEnabled)
                            Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
                        } catch (_: Exception) {
                        }
                    }, 120L)
                }
            }
        } catch (_: Exception) {
        }
    }
}

object MediaStateBus {
    private val _state = MutableStateFlow(NowPlayingSnapshot())
    val state: StateFlow<NowPlayingSnapshot> = _state.asStateFlow()

    @Volatile
    var activeController: MediaController? = null

    private val mainHandler = Handler(Looper.getMainLooper())
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val artUriCache = object : LruCache<String, Bitmap>(20) {}
    private var lastFetchedArtUri: String = ""

    private var trackStartRealtime: Long = SystemClock.elapsedRealtime()
    private var lastPausedRealtime: Long = 0L
    private var currentTrackIdentity: String = ""
    private var currentCoverSignature: Int = 0
    private var currentControllerCallback: MediaController.Callback? = null
    private var sessionListenerRegistered = false

    private var dismissedTrackIdentity: String = ""
    private var dismissedAtRealtime: Long = 0L

    fun computeBitmapSignature(bmp: Bitmap?): Int {
        if (bmp == null || bmp.isRecycled) return 0
        val w = bmp.width
        val h = bmp.height
        if (w <= 0 || h <= 0) return 0
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && bmp.config == Bitmap.Config.HARDWARE) {
            val gen = bmp.generationId
            val hash = ((w * 31) xor h) xor (gen * 31)
            return if (hash == 0) 1 else hash
        }
        return try {
            var hash = (w * 31) xor h
            hash = (hash * 31) xor bmp.getPixel(w / 2, h / 2)
            hash = (hash * 31) xor bmp.getPixel(w / 4, h / 4)
            hash = (hash * 31) xor bmp.getPixel((w * 3) / 4, h / 4)
            hash = (hash * 31) xor bmp.getPixel(w / 4, (h * 3) / 4)
            hash = (hash * 31) xor bmp.getPixel((w * 3) / 4, (h * 3) / 4)
            if (hash == 0) 1 else hash
        } catch (_: Exception) {
            val gen = bmp.generationId
            if (gen == 0) 1 else gen
        }
    }

    fun safeScaleBitmap(raw: Bitmap?): Bitmap? {
        if (raw == null || raw.isRecycled) return null
        return try {
            val src = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && raw.config == Bitmap.Config.HARDWARE) {
                raw.copy(Bitmap.Config.ARGB_8888, false) ?: raw
            } else {
                raw
            }
            val scaled = Bitmap.createScaledBitmap(src, 112, 112, true)
            if (src !== raw && src !== scaled && !src.isRecycled) {
                src.recycle()
            }
            scaled
        } catch (_: Exception) {
            raw
        }
    }

    fun getCurrentCoverSignature(): Int = currentCoverSignature

    /**
     * Прямое чтение активных сессий из MediaSessionManager в обход ограничения isLowRamDevice() на 1 ГБ ОЗУ!
     * Работает сразу после выдачи WRITE_SECURE_SETTINGS (или разрешения enabled_notification_listeners по ADB).
     */
    fun queryMediaSessionManagerDirect(context: Context) {
        try {
            val appCtx = context.applicationContext
            val msm = appCtx.getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager ?: return
            val comp = ComponentName(appCtx, MediaSessionListenerService::class.java)

            if (!sessionListenerRegistered) {
                try {
                    val sessionListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
                        selectAndBindBestController(appCtx, list)
                    }
                    msm.addOnActiveSessionsChangedListener(sessionListener, comp, mainHandler)
                    sessionListenerRegistered = true
                } catch (_: Exception) {
                }
            }

            val sessions = msm.getActiveSessions(comp)
            selectAndBindBestController(appCtx, sessions)
        } catch (_: Exception) {
        }
    }

    private fun selectAndBindBestController(context: Context, controllers: List<MediaController>?) {
        if (controllers.isNullOrEmpty()) return
        val others = controllers.filter { it.packageName != context.packageName }
        if (others.isEmpty()) return

        val best = others.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: others.firstOrNull {
                val st = it.playbackState?.state
                st == PlaybackState.STATE_PAUSED || st == PlaybackState.STATE_BUFFERING
            }
            ?: others.firstOrNull { it.metadata != null }
            ?: others.firstOrNull()

        if (best != null) {
            bindController(context, best)
        }
    }

    fun bindController(context: Context, controller: MediaController) {
        val prev = activeController
        if (prev != null && prev.sessionToken == controller.sessionToken) {
            return
        }
        val prevCb = currentControllerCallback
        if (prev != null && prevCb != null) {
            try {
                prev.unregisterCallback(prevCb)
            } catch (_: Exception) {
            }
        }
        activeController = controller
        val pkg = controller.packageName.orEmpty()
        val appName = try {
            val ai = context.packageManager.getApplicationInfo(pkg, 0)
            context.packageManager.getApplicationLabel(ai).toString()
        } catch (_: Exception) {
            pkg.substringAfterLast('.')
        }

        val cb = object : MediaController.Callback() {
            override fun onPlaybackStateChanged(state: PlaybackState?) {
                if (state != null) {
                    val playing = state.state == PlaybackState.STATE_PLAYING
                    updatePositionOnly(
                        positionMs = state.position,
                        positionUpdateRealtime = state.lastPositionUpdateTime,
                        speed = state.playbackSpeed,
                        isPlaying = playing
                    )
                }
            }

            override fun onMetadataChanged(metadata: MediaMetadata?) {
                if (metadata != null) {
                    val t = (metadata.getString(MediaMetadata.METADATA_KEY_TITLE)
                        ?: metadata.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)).orEmpty()
                    val a = (metadata.getString(MediaMetadata.METADATA_KEY_ARTIST)
                        ?: metadata.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                        ?: metadata.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)).orEmpty()
                    val dur = metadata.getLong(MediaMetadata.METADATA_KEY_DURATION)
                    val art = metadata.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                        ?: metadata.getBitmap(MediaMetadata.METADATA_KEY_ART)
                        ?: metadata.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                    var sig = 0
                    val scaled = if (art != null) {
                        sig = computeBitmapSignature(art)
                        val curBmp = _state.value.coverBitmap
                        if (sig != 0 && sig == currentCoverSignature && curBmp != null) {
                            curBmp
                        } else {
                            safeScaleBitmap(art)
                        }
                    } else null
                    val uri = metadata.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
                        ?: metadata.getString(MediaMetadata.METADATA_KEY_ART_URI)
                        ?: metadata.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)
                        ?: ""
                    val pb = controller.playbackState
                    if (pb != null) {
                        updatePlayingFlag(pb.state == PlaybackState.STATE_PLAYING)
                    }
                    updateMetadata(
                        title = t,
                        artist = a,
                        sourcePackage = pkg,
                        sourceAppName = appName,
                        cover = scaled,
                        coverSignature = sig,
                        artUri = uri,
                        durationMs = if (dur > 0L) dur else -1L,
                        positionMs = pb?.position ?: -1L,
                        positionUpdateRealtime = pb?.lastPositionUpdateTime ?: 0L,
                        speed = pb?.playbackSpeed ?: 1.0f
                    )
                }
            }
        }
        currentControllerCallback = cb
        try {
            controller.registerCallback(cb, mainHandler)
        } catch (_: Exception) {
        }
    }

    fun dismissPlayerByUser(audioManager: AudioManager) {
        val cur = _state.value
        val now = SystemClock.elapsedRealtime()
        dismissedTrackIdentity = currentTrackIdentity.ifEmpty { "${cur.sourcePackage}|${cur.title}" }
        dismissedAtRealtime = now

        try {
            val ctrl = activeController
            if (ctrl != null && (ctrl.playbackState?.state == PlaybackState.STATE_PLAYING || cur.isPlaying)) {
                ctrl.transportControls.pause()
            } else if (cur.isPlaying) {
                val upNow = SystemClock.uptimeMillis()
                audioManager.dispatchMediaKeyEvent(KeyEvent(upNow, upNow, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PAUSE, 0))
                audioManager.dispatchMediaKeyEvent(KeyEvent(upNow, upNow, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PAUSE, 0))
            }
        } catch (_: Exception) {
        }

        _state.value = NowPlayingSnapshot(
            hasActiveSession = false,
            isPlaying = false
        )
    }

    fun updateMetadata(
        title: String,
        artist: String,
        sourcePackage: String,
        sourceAppName: String,
        cover: Bitmap?,
        coverSignature: Int = 0,
        artUri: String = "",
        durationMs: Long = -1L,
        positionMs: Long = -1L,
        positionUpdateRealtime: Long = 0L,
        speed: Float = 1.0f
    ) {
        val current = _state.value
        val now = SystemClock.elapsedRealtime()
        val resolvedPkg = if (sourcePackage.isNotBlank()) sourcePackage else current.sourcePackage
        val resolvedTitle = if (title.isNotBlank()) title else if (resolvedPkg == current.sourcePackage) current.title else ""
        val resolvedArtist = if (artist.isNotBlank()) artist else if (resolvedPkg == current.sourcePackage) current.artist else ""
        val resolvedAppName = if (sourceAppName.isNotBlank()) sourceAppName else if (resolvedPkg == current.sourcePackage) current.sourceAppName else ""

        if (resolvedTitle.isBlank() && !current.hasActiveSession) return

        val newIdentity = "$resolvedPkg|$resolvedTitle"
        if (dismissedTrackIdentity.isNotEmpty()) {
            if ((now - dismissedAtRealtime) < 3000L) return
            if (newIdentity == dismissedTrackIdentity && !current.isPlaying) return
            if (newIdentity != dismissedTrackIdentity) {
                dismissedTrackIdentity = ""
            }
        }

        val trackChanged = resolvedTitle.isNotBlank() && newIdentity != currentTrackIdentity
        if (trackChanged) {
            currentTrackIdentity = newIdentity
            trackStartRealtime = now
            lastFetchedArtUri = ""
        }

        var resolvedCover: Bitmap? = when {
            cover != null -> {
                currentCoverSignature = if (coverSignature != 0) coverSignature else computeBitmapSignature(cover)
                cover
            }
            !trackChanged && resolvedPkg == current.sourcePackage -> current.coverBitmap
            else -> {
                currentCoverSignature = 0
                null
            }
        }

        if (resolvedCover == null && artUri.isNotBlank()) {
            val cached = artUriCache.get(artUri)
            if (cached != null) {
                resolvedCover = cached
                currentCoverSignature = computeBitmapSignature(cached)
            } else if (artUri != lastFetchedArtUri) {
                lastFetchedArtUri = artUri
                fetchArtFromUriAsync(artUri, newIdentity)
            }
        }

        val resolvedDuration = if (durationMs > 0L) durationMs else if (trackChanged) 0L else current.durationMs
        val resolvedPos = when {
            trackChanged -> if (positionMs in 0L..15000L) positionMs else 0L
            positionMs >= 0L -> positionMs
            else -> current.basePositionMs
        }
        val resolvedRealtime = when {
            trackChanged -> now
            positionUpdateRealtime > 0L && positionUpdateRealtime >= trackStartRealtime - 2000L -> positionUpdateRealtime
            positionMs >= 0L -> now
            else -> current.baseElapsedRealtime
        }

        val hasSession = current.hasActiveSession || resolvedTitle.isNotBlank() || current.isPlaying
        val playingNow = if (trackChanged && !current.isPlaying) true else current.isPlaying

        _state.value = current.copy(
            hasActiveSession = hasSession,
            isPlaying = playingNow,
            title = resolvedTitle,
            artist = resolvedArtist,
            sourcePackage = resolvedPkg,
            sourceAppName = resolvedAppName,
            coverBitmap = resolvedCover,
            durationMs = resolvedDuration,
            basePositionMs = resolvedPos,
            baseElapsedRealtime = resolvedRealtime,
            playbackSpeed = if (speed > 0f) speed else 1.0f
        )
    }

    fun updatePositionOnly(positionMs: Long, positionUpdateRealtime: Long, speed: Float, isPlaying: Boolean) {
        val cur = _state.value
        val now = SystemClock.elapsedRealtime()
        if (dismissedTrackIdentity.isNotEmpty() && (now - dismissedAtRealtime) < 3000L && !isPlaying) return
        if (isPlaying) {
            dismissedTrackIdentity = ""
            lastPausedRealtime = 0L
        } else if (cur.isPlaying) {
            lastPausedRealtime = now
        }
        val validPos = if (positionMs >= 0L) {
            if (cur.durationMs > 0L) positionMs.coerceAtMost(cur.durationMs) else positionMs
        } else {
            cur.basePositionMs
        }
        val validRealtime = if (positionUpdateRealtime > 0L && positionUpdateRealtime >= trackStartRealtime - 2000L) {
            positionUpdateRealtime
        } else {
            now
        }
        _state.value = cur.copy(
            hasActiveSession = cur.hasActiveSession || (isPlaying && cur.title.isNotBlank()),
            isPlaying = isPlaying,
            basePositionMs = validPos,
            baseElapsedRealtime = validRealtime,
            playbackSpeed = if (speed > 0f) speed else 1.0f
        )
    }

    private fun fetchArtFromUriAsync(uriString: String, expectedIdentity: String) {
        ioScope.launch {
            try {
                if (!uriString.startsWith("http://") && !uriString.startsWith("https://")) return@launch
                val conn = (URL(uriString).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 3500
                    readTimeout = 3500
                    doInput = true
                }
                conn.connect()
                val raw = conn.inputStream.use { BitmapFactory.decodeStream(it) }
                conn.disconnect()
                if (raw != null) {
                    val scaled = safeScaleBitmap(raw)
                    if (scaled != null && scaled !== raw && !raw.isRecycled) raw.recycle()
                    if (scaled != null) {
                        artUriCache.put(uriString, scaled)
                        if (currentTrackIdentity == expectedIdentity || _state.value.coverBitmap == null) {
                            currentCoverSignature = computeBitmapSignature(scaled)
                            _state.value = _state.value.copy(coverBitmap = scaled)
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    fun updatePlayingFlag(isPlaying: Boolean) {
        val cur = _state.value
        val now = SystemClock.elapsedRealtime()
        if (isPlaying) {
            if (dismissedTrackIdentity.isNotEmpty() && (now - dismissedAtRealtime) < 2500L) return
            dismissedTrackIdentity = ""
            lastPausedRealtime = 0L
            if (!cur.isPlaying && cur.basePositionMs == 0L) {
                trackStartRealtime = now
            }
            if (cur.title.isNotBlank()) {
                _state.value = cur.copy(
                    hasActiveSession = true,
                    isPlaying = true,
                    baseElapsedRealtime = now
                )
            }
        } else {
            if (cur.isPlaying) {
                val (frozenPos, _) = getLivePositionAndDuration()
                lastPausedRealtime = now
                _state.value = cur.copy(
                    isPlaying = false,
                    basePositionMs = frozenPos,
                    baseElapsedRealtime = now
                )
            } else if (cur.hasActiveSession && lastPausedRealtime > 0L && (now - lastPausedRealtime) > 20 * 60 * 1000L) {
                _state.value = cur.copy(hasActiveSession = false)
            }
        }
    }

    fun pollActiveControllerLight(context: Context? = null) {
        if (context != null) {
            queryMediaSessionManagerDirect(context)
        }
        val ctrl = activeController ?: return
        try {
            val meta = ctrl.metadata
            val pb = ctrl.playbackState
            val cur = _state.value
            val pkg = ctrl.packageName ?: cur.sourcePackage

            var title = ""
            var artist = ""
            var dur = -1L
            var artUri = ""
            var newCover: Bitmap? = null
            var newSig = 0

            if (meta != null) {
                title = meta.getString(MediaMetadata.METADATA_KEY_TITLE)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
                    ?: ""
                artist = meta.getString(MediaMetadata.METADATA_KEY_ARTIST)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
                    ?: ""
                val d = meta.getLong(MediaMetadata.METADATA_KEY_DURATION)
                if (d > 0L) dur = d

                artUri = meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_ART_URI)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)
                    ?: ""

                val rawArt = meta.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                    ?: meta.getBitmap(MediaMetadata.METADATA_KEY_ART)
                    ?: meta.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                if (rawArt != null) {
                    val sig = computeBitmapSignature(rawArt)
                    val candidateIdentity = "$pkg|${title.ifEmpty { cur.title }}"
                    val isDifferentTrack = title.isNotBlank() && candidateIdentity != currentTrackIdentity
                    if (sig != 0 && (sig != currentCoverSignature || cur.coverBitmap == null || isDifferentTrack)) {
                        newCover = safeScaleBitmap(rawArt)
                        newSig = sig
                    }
                }
            }

            var pos = -1L
            var posTime = 0L
            var spd = 1.0f
            if (pb != null) {
                pos = pb.position
                posTime = pb.lastPositionUpdateTime
                spd = pb.playbackSpeed
                updatePlayingFlag(pb.state == PlaybackState.STATE_PLAYING)
            }

            if (title.isNotEmpty() || artist.isNotEmpty() || newCover != null || artUri.isNotEmpty() || pos >= 0L) {
                updateMetadata(
                    title = title,
                    artist = artist,
                    sourcePackage = pkg,
                    sourceAppName = "",
                    cover = newCover,
                    coverSignature = newSig,
                    artUri = artUri,
                    durationMs = dur,
                    positionMs = pos,
                    positionUpdateRealtime = posTime,
                    speed = spd
                )
            }
        } catch (_: Exception) {
        }
    }

    fun getLivePositionAndDuration(): Pair<Long, Long> {
        val ctrl = activeController
        val snap = _state.value
        val now = SystemClock.elapsedRealtime()

        var dur = snap.durationMs.coerceAtLeast(0L)
        if (ctrl != null) {
            try {
                val metaDur = ctrl.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
                if (metaDur > 0L) dur = metaDur
            } catch (_: Exception) {
            }
        }

        if (!snap.isPlaying) {
            val frozen = if (dur > 0L) snap.basePositionMs.coerceIn(0L, dur) else snap.basePositionMs.coerceAtLeast(0L)
            return frozen to dur
        }

        if (ctrl != null) {
            try {
                val pb = ctrl.playbackState
                if (pb != null && pb.position >= 0L) {
                    val lastUpdate = pb.lastPositionUpdateTime
                    if (lastUpdate >= trackStartRealtime - 2000L) {
                        var pos = pb.position
                        if (pb.state == PlaybackState.STATE_PLAYING && lastUpdate > 0L) {
                            val delta = (now - lastUpdate).coerceAtLeast(0L)
                            pos += (delta * pb.playbackSpeed).toLong().coerceAtLeast(0L)
                        }
                        if (dur > 0L) pos = pos.coerceAtMost(dur)
                        return pos.coerceAtLeast(0L) to dur
                    }
                }
            } catch (_: Exception) {
            }
        }

        if (snap.basePositionMs > 0L && snap.baseElapsedRealtime >= trackStartRealtime - 2000L) {
            val delta = (now - snap.baseElapsedRealtime).coerceAtLeast(0L)
            var pos = snap.basePositionMs + (delta * snap.playbackSpeed).toLong().coerceAtLeast(0L)
            if (dur > 0L) pos = pos.coerceAtMost(dur)
            return pos to dur
        }

        var elapsed = (now - trackStartRealtime).coerceAtLeast(0L)
        if (dur > 0L) elapsed = elapsed.coerceAtMost(dur)
        return elapsed to dur
    }

    fun dispatchTransportAction(action: String, audioManager: AudioManager) {
        val ctrl = activeController
        try {
            if (ctrl != null) {
                val tc = ctrl.transportControls
                val pbState = ctrl.playbackState?.state
                when (action) {
                    "PREV" -> {
                        tc.skipToPrevious()
                        return
                    }
                    "NEXT" -> {
                        tc.skipToNext()
                        return
                    }
                    "PLAY_PAUSE" -> {
                        if (pbState == PlaybackState.STATE_PLAYING || _state.value.isPlaying) {
                            tc.pause()
                            updatePlayingFlag(false)
                        } else {
                            dismissedTrackIdentity = ""
                            tc.play()
                            updatePlayingFlag(true)
                        }
                        return
                    }
                }
            }
        } catch (_: Exception) {
        }

        val keyCode = when (action) {
            "PREV" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "NEXT" -> KeyEvent.KEYCODE_MEDIA_NEXT
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        try {
            val now = SystemClock.uptimeMillis()
            audioManager.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0))
            audioManager.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_UP, keyCode, 0))
            if (action == "PLAY_PAUSE") {
                val targetPlay = !_state.value.isPlaying
                if (targetPlay) dismissedTrackIdentity = ""
                updatePlayingFlag(targetPlay)
            }
        } catch (_: Exception) {
        }
    }
}

object KeyCaptureBus {
    @Volatile
    var isCapturingKey: Boolean = false

    @Volatile
    var onKeyCapturedListener: ((keyCode: Int, scanCode: Int) -> Unit)? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    fun notifyKeyCaptured(keyCode: Int, scanCode: Int): Boolean {
        val listener = onKeyCapturedListener ?: return false
        isCapturingKey = false
        mainHandler.post {
            listener.invoke(keyCode, scanCode)
        }
        return true
    }
}

class MediaSessionListenerService : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        val pkg = sbn.packageName ?: return
        if (pkg == packageName) return
        val notif = sbn.notification ?: return
        try {
            @Suppress("DEPRECATION")
            val token = notif.extras?.getParcelable<Parcelable>(Notification.EXTRA_MEDIA_SESSION) as? MediaSession.Token
            if (token != null) {
                MediaStateBus.bindController(this, MediaController(this, token))
            }
        } catch (_: Exception) {
        }
    }
}

class KeyMapperAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var isServiceConnectedAlive: Boolean = false
    }

    private var lastInterceptMillis: Long = 0L
    private var lastSessionToken: MediaSession.Token? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        isServiceConnectedAlive = true
        try {
            val info = serviceInfo ?: AccessibilityServiceInfo()
            info.flags = info.flags or AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
            serviceInfo = info
        } catch (_: Exception) {
        }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        isServiceConnectedAlive = false
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        isServiceConnectedAlive = false
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        isServiceConnectedAlive = true
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return

        if (event.eventType == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            val notif = event.parcelableData as? Notification
            if (notif != null && pkg != packageName) {
                extractMediaFromNotificationLight(pkg, notif)
            }
            return
        }

        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && pkg != packageName) {
            val prefs = getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            val matchedPresetTarget: String? = when {
                isNetflixPackage(pkg) -> prefs.getString("preset_bind_NETFLIX", null)
                isPrimePackage(pkg) -> prefs.getString("preset_bind_PRIME", null)
                isPatchwallPackage(pkg) -> prefs.getString("preset_bind_PATCHWALL", "ACTION_CONTROL_CENTER")
                else -> null
            }

            if (!matchedPresetTarget.isNullOrEmpty()) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastInterceptMillis > 600L) {
                    lastInterceptMillis = now
                    executeBoundAction(matchedPresetTarget)
                }
            }
        }
    }

    private fun isMediaNotification(pkg: String, notif: Notification, sessionToken: MediaSession.Token?): Boolean {
        if (sessionToken != null) return true
        val p = pkg.lowercase()
        if (p == "android" ||
            p.startsWith("com.android.systemui") ||
            p.startsWith("com.google.android.gms") ||
            p.startsWith("com.android.vending") ||
            p.startsWith("com.android.packageinstaller") ||
            p.startsWith("com.android.settings")
        ) {
            return false
        }
        if (notif.category == Notification.CATEGORY_TRANSPORT) return true
        val template = notif.extras?.getString(Notification.EXTRA_TEMPLATE).orEmpty()
        if (template.contains("MediaStyle", ignoreCase = true)) return true
        return p.contains("spotify") ||
            p.contains("soundcloud") ||
            p.contains("mediashell") ||
            p.contains("chromecast") ||
            p.contains("youtube") ||
            p.contains("music") ||
            p.contains("vlc") ||
            p.contains("kodi") ||
            p.contains("plex") ||
            p.contains("deezer") ||
            p.contains("yandex")
    }

    private fun extractMediaFromNotificationLight(pkg: String, notif: Notification) {
        try {
            val extras = notif.extras ?: return
            @Suppress("DEPRECATION")
            val sessionToken = extras.getParcelable<Parcelable>(Notification.EXTRA_MEDIA_SESSION) as? MediaSession.Token
            if (!isMediaNotification(pkg, notif, sessionToken)) return

            var title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
            var text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
            val appName = resolveAppLabel(pkg)

            if (sessionToken != null && sessionToken != lastSessionToken) {
                lastSessionToken = sessionToken
                MediaStateBus.bindController(this, MediaController(this, sessionToken))
            }

            val ctrl = MediaStateBus.activeController
            var durationMs = -1L
            var posMs = -1L
            var posRealtime = 0L
            var speed = 1.0f
            var artUri = ""

            if (ctrl != null) {
                val meta = ctrl.metadata
                if (meta != null) {
                    val metaTitle = meta.getString(MediaMetadata.METADATA_KEY_TITLE)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
                    val metaArtist = meta.getString(MediaMetadata.METADATA_KEY_ARTIST)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
                    if (!metaTitle.isNullOrBlank()) title = metaTitle
                    if (!metaArtist.isNullOrBlank()) text = metaArtist

                    val d = meta.getLong(MediaMetadata.METADATA_KEY_DURATION)
                    if (d > 0L) durationMs = d

                    artUri = meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_ART_URI)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)
                        ?: ""
                }

                val pb = ctrl.playbackState
                if (pb != null) {
                    posMs = pb.position
                    posRealtime = pb.lastPositionUpdateTime
                    speed = pb.playbackSpeed
                    MediaStateBus.updatePlayingFlag(pb.state == PlaybackState.STATE_PLAYING)
                }
            }

            var rawCandidate: Bitmap? = null
            if (ctrl != null) {
                val meta = ctrl.metadata
                rawCandidate = meta?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                    ?: meta?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                    ?: meta?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
            }

            if (rawCandidate == null) {
                @Suppress("DEPRECATION")
                rawCandidate = (extras.getParcelable<Parcelable>(Notification.EXTRA_LARGE_ICON_BIG) as? Bitmap)
                    ?: (extras.getParcelable<Parcelable>(Notification.EXTRA_LARGE_ICON) as? Bitmap)
                    ?: (extras.getParcelable<Parcelable>(Notification.EXTRA_PICTURE) as? Bitmap)
            }

            if (rawCandidate == null) {
                val largeIcon = notif.getLargeIcon()
                if (largeIcon != null) {
                    val d = largeIcon.loadDrawable(this)
                    if (d is BitmapDrawable && d.bitmap != null) {
                        rawCandidate = d.bitmap
                    } else if (d != null) {
                        rawCandidate = drawableToSmallBitmap(d)
                    }
                }
            }

            var coverBmp: Bitmap? = null
            var sig = 0
            if (rawCandidate != null) {
                sig = MediaStateBus.computeBitmapSignature(rawCandidate)
                val curCover = MediaStateBus.state.value.coverBitmap
                if (sig != 0 && sig == MediaStateBus.getCurrentCoverSignature() && curCover != null) {
                    coverBmp = curCover
                } else {
                    coverBmp = MediaStateBus.safeScaleBitmap(rawCandidate)
                }
            }

            if (title.isEmpty() && text.isEmpty() && coverBmp == null && artUri.isEmpty()) return

            MediaStateBus.updateMetadata(
                title = title,
                artist = text,
                sourcePackage = pkg,
                sourceAppName = appName,
                cover = coverBmp,
                coverSignature = sig,
                artUri = artUri,
                durationMs = durationMs,
                positionMs = posMs,
                positionUpdateRealtime = posRealtime,
                speed = speed
            )
        } catch (_: Exception) {
        }
    }

    private fun drawableToSmallBitmap(d: Drawable): Bitmap? {
        return try {
            if (d is BitmapDrawable && d.bitmap != null) {
                MediaStateBus.safeScaleBitmap(d.bitmap)
            } else {
                val bmp = Bitmap.createBitmap(112, 112, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bmp)
                d.setBounds(0, 0, 112, 112)
                d.draw(canvas)
                bmp
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun resolveAppLabel(pkg: String): String {
        return try {
            val ai = packageManager.getApplicationInfo(pkg, 0)
            packageManager.getApplicationLabel(ai).toString()
        } catch (_: Exception) {
            pkg.substringAfterLast('.')
        }
    }

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        isServiceConnectedAlive = true
        val keyCode = event.keyCode
        val scanCode = event.scanCode

        // Кнопки громкости НЕ перехватываем — работает только один штатный ползунок системы!
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
            keyCode == KeyEvent.KEYCODE_VOLUME_DOWN ||
            keyCode == KeyEvent.KEYCODE_VOLUME_MUTE
        ) {
            return false
        }

        if (KeyCaptureBus.isCapturingKey) {
            if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
                return false
            }
            if (isNavigationOrCenterKey(keyCode)) {
                return false
            }
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                KeyCaptureBus.notifyKeyCaptured(keyCode, scanCode)
            }
            return true
        }

        if (isNavigationOrCenterKey(keyCode)) {
            return false
        }

        val prefs = getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)

        if (keyCode == KeyEvent.KEYCODE_VOICE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_SEARCH
        ) {
            val customAssistTarget = prefs.getString("key_bind_$keyCode", null) ?: "ACTION_AI"
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                executeBoundAction(customAssistTarget)
            }
            return true
        }

        val presetTarget = resolvePresetBinding(prefs, keyCode, scanCode)
        if (!presetTarget.isNullOrEmpty()) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                executeBoundAction(presetTarget)
            }
            return true
        }

        val boundTarget = prefs.getString("key_bind_$keyCode", null)
            ?: if (scanCode > 0) prefs.getString("scan_bind_$scanCode", null) else null

        if (boundTarget.isNullOrEmpty()) {
            return false
        }

        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            executeBoundAction(boundTarget)
        }
        return true
    }

    private fun resolvePresetBinding(
        prefs: android.content.SharedPreferences,
        keyCode: Int,
        scanCode: Int
    ): String? {
        if (keyCode == KeyEvent.KEYCODE_ALL_APPS ||
            keyCode == KeyEvent.KEYCODE_MENU ||
            keyCode == KeyEvent.KEYCODE_GUIDE ||
            keyCode == KeyEvent.KEYCODE_SETTINGS ||
            keyCode == KeyEvent.KEYCODE_TV_INPUT ||
            keyCode == KeyEvent.KEYCODE_BUTTON_1 ||
            scanCode == 139 || scanCode == 362 || scanCode == 172 || scanCode == 256
        ) {
            val target = prefs.getString("preset_bind_PATCHWALL", "ACTION_CONTROL_CENTER")
            if (!target.isNullOrEmpty()) return target
        }

        if (keyCode == KeyEvent.KEYCODE_BUTTON_2 ||
            keyCode == KeyEvent.KEYCODE_PROG_RED ||
            scanCode == 412 || scanCode == 398 || keyCode == 309
        ) {
            prefs.getString("preset_bind_NETFLIX", null)?.let { if (it.isNotEmpty()) return it }
        }

        if (keyCode == KeyEvent.KEYCODE_BUTTON_3 ||
            keyCode == KeyEvent.KEYCODE_PROG_BLUE ||
            scanCode == 413 || scanCode == 401 || keyCode == 310
        ) {
            prefs.getString("preset_bind_PRIME", null)?.let { if (it.isNotEmpty()) return it }
        }

        return null
    }

    private fun isNetflixPackage(pkg: String): Boolean = pkg.lowercase().contains("netflix")

    private fun isPrimePackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("amazonvideo") || p.contains("amazon.avod") || p.contains("primevideo")
    }

    private fun isPatchwallPackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("patchwall") || p.contains("mitv.tvhome") || p.contains("mitv.smartshare")
    }

    private fun isNavigationOrCenterKey(keyCode: Int): Boolean {
        return keyCode == KeyEvent.KEYCODE_DPAD_UP ||
            keyCode == KeyEvent.KEYCODE_DPAD_DOWN ||
            keyCode == KeyEvent.KEYCODE_DPAD_LEFT ||
            keyCode == KeyEvent.KEYCODE_DPAD_RIGHT ||
            keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
            keyCode == KeyEvent.KEYCODE_ENTER ||
            keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER ||
            keyCode == KeyEvent.KEYCODE_HOME
    }

    private fun executeBoundAction(target: String) {
        when (target) {
            "ACTION_CONTROL_CENTER" -> {
                val intent = Intent(this, LauncherActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("EXTRA_OPEN_CONTROL_CENTER", true)
                }
                startActivity(intent)
            }
            "ACTION_ALL_APPS" -> {
                val intent = Intent(this, LauncherActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("EXTRA_OPEN_ALL_APPS", true)
                }
                startActivity(intent)
            }
            "ACTION_SETTINGS" -> {
                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    startActivity(intent)
                } catch (_: Exception) {
                }
            }
            "ACTION_AI" -> {
                val intent = Intent(this, LauncherActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("EXTRA_OPEN_AI", true)
                }
                startActivity(intent)
            }
            else -> {
                val pm = packageManager
                val launchIntent = pm.getLeanbackLaunchIntentForPackage(target)
                    ?: pm.getLaunchIntentForPackage(target)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        startActivity(launchIntent)
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }
}
