package com.mitv.customlauncher.service

import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.Parcelable
import android.os.SystemClock
import android.provider.Settings
import android.util.LruCache
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.mitv.customlauncher.data.LauncherConfig
import com.mitv.customlauncher.ui.LauncherActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.net.HttpURLConnection
import java.net.URL

data class NowPlayingSnapshot(
    val hasActiveSession: Boolean = false,
    val isPlaying: Boolean = false,
    val title: String = "",
    val artist: String = "",
    val sourcePackage: String = "",
    val sourceAppName: String = "",
    val coverBitmap: Bitmap? = null,
    val durationMs: Long = 0L,
    val basePositionMs: Long = 0L,
    val baseElapsedRealtime: Long = 0L,
    val playbackSpeed: Float = 1.0f
)

object VolumeHudBus {
    @Volatile
    var onVolumeIntercepted: (() -> Unit)? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    fun notifyVolumeChanged() {
        val listener = onVolumeIntercepted ?: return
        mainHandler.post { listener.invoke() }
    }
}

object MediaStateBus {
    private val _state = MutableStateFlow(NowPlayingSnapshot())
    val state: StateFlow<NowPlayingSnapshot> = _state.asStateFlow()

    @Volatile
    var activeController: MediaController? = null

    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val artUriCache = object : LruCache<String, Bitmap>(20) {}
    private var lastFetchedArtUri: String = ""

    private var trackStartRealtime: Long = SystemClock.elapsedRealtime()
    private var lastPausedRealtime: Long = 0L
    private var currentTrackIdentity: String = ""

    fun updateMetadata(
        title: String,
        artist: String,
        sourcePackage: String,
        sourceAppName: String,
        cover: Bitmap?,
        artUri: String = "",
        durationMs: Long = -1L,
        positionMs: Long = -1L,
        positionUpdateRealtime: Long = 0L,
        speed: Float = 1.0f
    ) {
        val current = _state.value
        val resolvedPkg = if (sourcePackage.isNotBlank()) sourcePackage else current.sourcePackage
        val resolvedTitle = if (title.isNotBlank()) title else if (resolvedPkg == current.sourcePackage) current.title else ""
        val resolvedArtist = if (artist.isNotBlank()) artist else if (resolvedPkg == current.sourcePackage) current.artist else ""
        val resolvedAppName = if (sourceAppName.isNotBlank()) sourceAppName else if (resolvedPkg == current.sourcePackage) current.sourceAppName else ""

        // Уникальный ключ трека: пакет приложения + название песни
        val newIdentity = "$resolvedPkg|$resolvedTitle"
        val trackChanged = resolvedTitle.isNotBlank() && newIdentity != currentTrackIdentity
        if (trackChanged) {
            currentTrackIdentity = newIdentity
            trackStartRealtime = SystemClock.elapsedRealtime()
            lastFetchedArtUri = ""
        }

        // Если трек и приложение те же самые — НИКОГДА не затираем уже загруженную обложку значением null!
        // Если же сменился трек или приложение (например SoundCloud -> Spotify) — старая обложка сразу сбрасывается!
        var resolvedCover: Bitmap? = when {
            cover != null -> cover
            !trackChanged && resolvedPkg == current.sourcePackage -> current.coverBitmap
            else -> null
        }

        if (resolvedCover == null && artUri.isNotBlank()) {
            resolvedCover = artUriCache.get(artUri)
            if (resolvedCover == null && artUri != lastFetchedArtUri) {
                lastFetchedArtUri = artUri
                fetchArtFromUriAsync(artUri, newIdentity)
            }
        }

        val resolvedDuration = if (durationMs > 0L) durationMs else if (trackChanged) 0L else current.durationMs
        val resolvedPos = if (positionMs >= 0L) positionMs else if (trackChanged) 0L else current.basePositionMs
        val resolvedRealtime = if (positionUpdateRealtime > 0L) positionUpdateRealtime else if (positionMs >= 0L) SystemClock.elapsedRealtime() else current.baseElapsedRealtime

        val hasSession = current.hasActiveSession || resolvedTitle.isNotBlank() || current.isPlaying

        _state.value = current.copy(
            hasActiveSession = hasSession,
            title = resolvedTitle,
            artist = resolvedArtist,
            sourcePackage = resolvedPkg,
            sourceAppName = resolvedAppName,
            coverBitmap = resolvedCover,
            durationMs = resolvedDuration,
            basePositionMs = resolvedPos,
            baseElapsedRealtime = resolvedRealtime,
            playbackSpeed = if (speed > 0f) speed else 1.0f
        )
    }

    /**
     * Лёгкое обновление только позиции времени (вызывается при перемотке трека -> 0 аллокаций памяти, 0 треска!)
     */
    fun updatePositionOnly(positionMs: Long, positionUpdateRealtime: Long, speed: Float, isPlaying: Boolean) {
        val cur = _state.value
        if (!cur.isPlaying && isPlaying) {
            lastPausedRealtime = 0L
        } else if (cur.isPlaying && !isPlaying) {
            lastPausedRealtime = SystemClock.elapsedRealtime()
        }
        _state.value = cur.copy(
            hasActiveSession = cur.hasActiveSession || isPlaying || cur.title.isNotBlank(),
            isPlaying = isPlaying,
            basePositionMs = if (positionMs >= 0L) positionMs else cur.basePositionMs,
            baseElapsedRealtime = if (positionUpdateRealtime > 0L) positionUpdateRealtime else SystemClock.elapsedRealtime(),
            playbackSpeed = if (speed > 0f) speed else 1.0f
        )
    }

    private fun fetchArtFromUriAsync(uriString: String, expectedIdentity: String) {
        ioScope.launch {
            try {
                if (!uriString.startsWith("http://") && !uriString.startsWith("https://")) return@launch
                val conn = (URL(uriString).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 3500
                    readTimeout = 3500
                    doInput = true
                }
                conn.connect()
                val raw = conn.inputStream.use { BitmapFactory.decodeStream(it) }
                conn.disconnect()
                if (raw != null) {
                    val scaled = Bitmap.createScaledBitmap(raw, 112, 112, true)
                    if (scaled != raw) raw.recycle()
                    artUriCache.put(uriString, scaled)
                    if (currentTrackIdentity == expectedIdentity || _state.value.coverBitmap == null) {
                        _state.value = _state.value.copy(coverBitmap = scaled)
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    fun updatePlayingFlag(isPlaying: Boolean) {
        val cur = _state.value
        val now = SystemClock.elapsedRealtime()
        if (isPlaying) {
            lastPausedRealtime = 0L
            if (!cur.isPlaying && cur.basePositionMs == 0L) {
                trackStartRealtime = now
            }
            if (!cur.isPlaying || !cur.hasActiveSession) {
                _state.value = cur.copy(hasActiveSession = true, isPlaying = true)
            }
        } else {
            if (cur.isPlaying) {
                // Фиксируем текущую секунду в момент нажатия паузы, чтобы таймер замер ровно на ней!
                val (frozenPos, _) = getLivePositionAndDuration()
                lastPausedRealtime = now
                _state.value = cur.copy(
                    isPlaying = false,
                    basePositionMs = frozenPos,
                    baseElapsedRealtime = now
                )
            } else if (cur.hasActiveSession && lastPausedRealtime > 0L && (now - lastPausedRealtime) > 20 * 60 * 1000L) {
                // Если трек стоит на паузе дольше 20 минут — закрываем сессию
                _state.value = cur.copy(hasActiveSession = false)
            }
        }
    }

    /**
     * Сверхлёгкий опрос активного MediaController раз в секунду:
     * НЕ декодирует Bitmap каждую секунду (читает Bitmap только если сменился трек или обложки ещё нет)!
     */
    fun pollActiveControllerLight() {
        val ctrl = activeController ?: return
        try {
            val meta = ctrl.metadata
            val pb = ctrl.playbackState
            val cur = _state.value
            val pkg = ctrl.packageName ?: cur.sourcePackage

            var title = ""
            var artist = ""
            var dur = -1L
            var artUri = ""

            if (meta != null) {
                title = meta.getString(MediaMetadata.METADATA_KEY_TITLE)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
                    ?: ""
                artist = meta.getString(MediaMetadata.METADATA_KEY_ARTIST)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
                    ?: ""
                val d = meta.getLong(MediaMetadata.METADATA_KEY_DURATION)
                if (d > 0L) dur = d

                artUri = meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_ART_URI)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)
                    ?: ""
            }

            val candidateIdentity = "$pkg|${title.ifEmpty { cur.title }}"
            val needNewBitmap = (candidateIdentity != currentTrackIdentity) || (cur.coverBitmap == null)

            var newCover: Bitmap? = null
            if (needNewBitmap && meta != null) {
                val rawArt = meta.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                    ?: meta.getBitmap(MediaMetadata.METADATA_KEY_ART)
                    ?: meta.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                if (rawArt != null) {
                    newCover = Bitmap.createScaledBitmap(rawArt, 112, 112, true)
                }
            }

            var pos = -1L
            var posTime = 0L
            var spd = 1.0f
            if (pb != null) {
                pos = pb.position
                posTime = pb.lastPositionUpdateTime
                spd = pb.playbackSpeed
                updatePlayingFlag(pb.state == PlaybackState.STATE_PLAYING)
            }

            if (title.isNotEmpty() || artist.isNotEmpty() || newCover != null || artUri.isNotEmpty() || pos >= 0L) {
                updateMetadata(
                    title = title,
                    artist = artist,
                    sourcePackage = pkg,
                    sourceAppName = "",
                    cover = newCover,
                    artUri = artUri,
                    durationMs = dur,
                    positionMs = pos,
                    positionUpdateRealtime = posTime,
                    speed = spd
                )
            }
        } catch (_: Exception) {
        }
    }

    fun getLivePositionAndDuration(): Pair<Long, Long> {
        val ctrl = activeController
        val snap = _state.value
        if (ctrl != null) {
            try {
                val meta = ctrl.metadata
                val pb = ctrl.playbackState
                val dur = meta?.getLong(MediaMetadata.METADATA_KEY_DURATION)?.coerceAtLeast(0L)
                    ?: snap.durationMs
                if (pb != null && pb.position >= 0L) {
                    var pos = pb.position
                    if (pb.state == PlaybackState.STATE_PLAYING && pb.lastPositionUpdateTime > 0L) {
                        val delta = SystemClock.elapsedRealtime() - pb.lastPositionUpdateTime
                        pos += (delta * pb.playbackSpeed).toLong().coerceAtLeast(0L)
                    }
                    if (dur > 0L) pos = pos.coerceAtMost(dur)
                    return pos to dur
                }
            } catch (_: Exception) {
            }
        }

        val dur = snap.durationMs.coerceAtLeast(0L)
        if (snap.basePositionMs > 0L && snap.baseElapsedRealtime > 0L) {
            val delta = if (snap.isPlaying) SystemClock.elapsedRealtime() - snap.baseElapsedRealtime else 0L
            var pos = snap.basePositionMs + (delta * snap.playbackSpeed).toLong().coerceAtLeast(0L)
            if (dur > 0L) pos = pos.coerceAtMost(dur)
            return pos to dur
        }

        val elapsed = if (snap.isPlaying) {
            (SystemClock.elapsedRealtime() - trackStartRealtime).coerceAtLeast(0L)
        } else {
            snap.basePositionMs.coerceAtLeast(0L)
        }
        return elapsed to dur
    }

    fun dispatchTransportAction(action: String, audioManager: AudioManager) {
        val ctrl = activeController
        try {
            if (ctrl != null) {
                val tc = ctrl.transportControls
                val pbState = ctrl.playbackState?.state
                when (action) {
                    "PREV" -> {
                        tc.skipToPrevious()
                        return
                    }
                    "NEXT" -> {
                        tc.skipToNext()
                        return
                    }
                    "PLAY_PAUSE" -> {
                        if (pbState == PlaybackState.STATE_PLAYING || _state.value.isPlaying) {
                            tc.pause()
                            updatePlayingFlag(false)
                        } else {
                            tc.play()
                            updatePlayingFlag(true)
                        }
                        return
                    }
                }
            }
        } catch (_: Exception) {
        }

        val keyCode = when (action) {
            "PREV" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "NEXT" -> KeyEvent.KEYCODE_MEDIA_NEXT
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        try {
            val now = SystemClock.uptimeMillis()
            audioManager.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0))
            audioManager.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_UP, keyCode, 0))
            if (action == "PLAY_PAUSE") {
                updatePlayingFlag(!_state.value.isPlaying)
            }
        } catch (_: Exception) {
        }
    }
}

object KeyCaptureBus {
    @Volatile
    var isCapturingKey: Boolean = false

    @Volatile
    var onKeyCapturedListener: ((keyCode: Int, scanCode: Int) -> Unit)? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    fun notifyKeyCaptured(keyCode: Int, scanCode: Int): Boolean {
        val listener = onKeyCapturedListener ?: return false
        isCapturingKey = false
        mainHandler.post {
            listener.invoke(keyCode, scanCode)
        }
        return true
    }
}

class KeyMapperAccessibilityService : AccessibilityService() {

    private var lastInterceptMillis: Long = 0L
    private var lastSessionToken: MediaSession.Token? = null
    private var lastNotificationTrackKey: String = ""
    private var currentControllerCallback: MediaController.Callback? = null

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return

        if (event.eventType == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            val notif = event.parcelableData as? Notification
            if (notif != null && pkg != packageName) {
                extractMediaFromNotificationLight(pkg, notif)
            }
            return
        }

        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && pkg != packageName) {
            val prefs = getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            val matchedPresetTarget: String? = when {
                isNetflixPackage(pkg) -> prefs.getString("preset_bind_NETFLIX", null)
                isPrimePackage(pkg) -> prefs.getString("preset_bind_PRIME", null)
                isPatchwallPackage(pkg) -> prefs.getString("preset_bind_PATCHWALL", null)
                else -> null
            }

            if (!matchedPresetTarget.isNullOrEmpty()) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastInterceptMillis > 600L) {
                    lastInterceptMillis = now
                    executeBoundAction(matchedPresetTarget)
                }
            }
        }
    }

    /**
     * Оптимизированный разбор уведомления:
     * Не пересоздаёт MediaController и не сжимает Bitmap повторно при перемотке того же трека!
     */
    private fun extractMediaFromNotificationLight(pkg: String, notif: Notification) {
        try {
            val extras = notif.extras ?: return
            var title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
            var text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
            val appName = resolveAppLabel(pkg)

            @Suppress("DEPRECATION")
            val sessionToken = extras.getParcelable<Parcelable>(Notification.EXTRA_MEDIA_SESSION) as? MediaSession.Token
            if (sessionToken != null && sessionToken != lastSessionToken) {
                lastSessionToken = sessionToken
                val controller = MediaController(this, sessionToken)
                attachControllerCallback(pkg, appName, controller)
            }

            val ctrl = MediaStateBus.activeController
            var durationMs = -1L
            var posMs = -1L
            var posRealtime = 0L
            var speed = 1.0f
            var artUri = ""

            if (ctrl != null) {
                val meta = ctrl.metadata
                if (meta != null) {
                    val metaTitle = meta.getString(MediaMetadata.METADATA_KEY_TITLE)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
                    val metaArtist = meta.getString(MediaMetadata.METADATA_KEY_ARTIST)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
                    if (!metaTitle.isNullOrBlank()) title = metaTitle
                    if (!metaArtist.isNullOrBlank()) text = metaArtist

                    val d = meta.getLong(MediaMetadata.METADATA_KEY_DURATION)
                    if (d > 0L) durationMs = d

                    artUri = meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_ART_URI)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)
                        ?: ""
                }

                val pb = ctrl.playbackState
                if (pb != null) {
                    posMs = pb.position
                    posRealtime = pb.lastPositionUpdateTime
                    speed = pb.playbackSpeed
                    MediaStateBus.updatePlayingFlag(pb.state == PlaybackState.STATE_PLAYING)
                }
            }

            val trackKey = "$pkg|$title|$text"
            val isSameTrack = (trackKey == lastNotificationTrackKey) && (MediaStateBus.state.value.coverBitmap != null)

            // Если это просто событие перемотки того же трека и обложка уже есть — вообще не трогаем Bitmap!
            if (isSameTrack) {
                MediaStateBus.updateMetadata(
                    title = title,
                    artist = text,
                    sourcePackage = pkg,
                    sourceAppName = appName,
                    cover = null,
                    artUri = artUri,
                    durationMs = durationMs,
                    positionMs = posMs,
                    positionUpdateRealtime = posRealtime,
                    speed = speed
                )
                return
            }

            lastNotificationTrackKey = trackKey

            // Декодируем обложку только 1 раз для нового трека!
            var coverBmp: Bitmap? = null
            if (ctrl != null) {
                val meta = ctrl.metadata
                val rawArt = meta?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                    ?: meta?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                    ?: meta?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                if (rawArt != null) {
                    coverBmp = Bitmap.createScaledBitmap(rawArt, 112, 112, true)
                }
            }

            if (coverBmp == null) {
                @Suppress("DEPRECATION")
                val extraBmp = (extras.getParcelable<Parcelable>(Notification.EXTRA_LARGE_ICON_BIG) as? Bitmap)
                    ?: (extras.getParcelable<Parcelable>(Notification.EXTRA_LARGE_ICON) as? Bitmap)
                    ?: (extras.getParcelable<Parcelable>(Notification.EXTRA_PICTURE) as? Bitmap)
                if (extraBmp != null) {
                    coverBmp = Bitmap.createScaledBitmap(extraBmp, 112, 112, true)
                }
            }

            if (coverBmp == null) {
                val largeIcon = notif.getLargeIcon()
                if (largeIcon != null) {
                    val d = largeIcon.loadDrawable(this)
                    if (d != null) {
                        coverBmp = drawableToSmallBitmap(d)
                    }
                }
            }

            if (title.isEmpty() && text.isEmpty() && coverBmp == null && artUri.isEmpty()) return

            MediaStateBus.updateMetadata(
                title = title,
                artist = text,
                sourcePackage = pkg,
                sourceAppName = appName,
                cover = coverBmp,
                artUri = artUri,
                durationMs = durationMs,
                positionMs = posMs,
                positionUpdateRealtime = posRealtime,
                speed = speed
            )
        } catch (_: Exception) {
        }
    }

    private fun attachControllerCallback(pkg: String, appName: String, controller: MediaController) {
        try {
            val prev = MediaStateBus.activeController
            val prevCb = currentControllerCallback
            if (prev != null && prevCb != null) {
                try {
                    prev.unregisterCallback(prevCb)
                } catch (_: Exception) {
                }
            }

            MediaStateBus.activeController = controller
            val cb = object : MediaController.Callback() {
                override fun onPlaybackStateChanged(state: PlaybackState?) {
                    if (state != null) {
                        val playing = state.state == PlaybackState.STATE_PLAYING
                        // При перемотке меняем только числа времени, без работы с Bitmap!
                        MediaStateBus.updatePositionOnly(
                            positionMs = state.position,
                            positionUpdateRealtime = state.lastPositionUpdateTime,
                            speed = state.playbackSpeed,
                            isPlaying = playing
                        )
                    }
                }

                override fun onMetadataChanged(metadata: MediaMetadata?) {
                    if (metadata != null) {
                        val t = metadata.getString(MediaMetadata.METADATA_KEY_TITLE).orEmpty()
                        val a = metadata.getString(MediaMetadata.METADATA_KEY_ARTIST).orEmpty()
                        val dur = metadata.getLong(MediaMetadata.METADATA_KEY_DURATION)
                        val art = metadata.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                            ?: metadata.getBitmap(MediaMetadata.METADATA_KEY_ART)
                        val scaled = if (art != null) Bitmap.createScaledBitmap(art, 112, 112, true) else null
                        val uri = metadata.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
                            ?: metadata.getString(MediaMetadata.METADATA_KEY_ART_URI)
                            ?: ""
                        MediaStateBus.updateMetadata(
                            title = t,
                            artist = a,
                            sourcePackage = pkg,
                            sourceAppName = appName,
                            cover = scaled,
                            artUri = uri,
                            durationMs = if (dur > 0L) dur else -1L
                        )
                    }
                }
            }
            currentControllerCallback = cb
            controller.registerCallback(cb, Handler(Looper.getMainLooper()))
        } catch (_: Exception) {
        }
    }

    private fun drawableToSmallBitmap(d: Drawable): Bitmap? {
        return try {
            if (d is BitmapDrawable && d.bitmap != null) {
                Bitmap.createScaledBitmap(d.bitmap, 112, 112, true)
            } else {
                val bmp = Bitmap.createBitmap(112, 112, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bmp)
                d.setBounds(0, 0, 112, 112)
                d.draw(canvas)
                bmp
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun resolveAppLabel(pkg: String): String {
        return try {
            val ai = packageManager.getApplicationInfo(pkg, 0)
            packageManager.getApplicationLabel(ai).toString()
        } catch (_: Exception) {
            pkg.substringAfterLast('.')
        }
    }

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val keyCode = event.keyCode
        val scanCode = event.scanCode

        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
            keyCode == KeyEvent.KEYCODE_VOLUME_DOWN ||
            keyCode == KeyEvent.KEYCODE_VOLUME_MUTE
        ) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                try {
                    val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    when (keyCode) {
                        KeyEvent.KEYCODE_VOLUME_UP ->
                            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0)
                        KeyEvent.KEYCODE_VOLUME_DOWN ->
                            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0)
                        KeyEvent.KEYCODE_VOLUME_MUTE ->
                            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, 0)
                    }
                    VolumeHudBus.notifyVolumeChanged()
                } catch (_: Exception) {
                }
            }
            return true
        }

        if (isNavigationOrCenterKey(keyCode)) {
            return false
        }

        if (KeyCaptureBus.isCapturingKey) {
            if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
                return false
            }
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                KeyCaptureBus.notifyKeyCaptured(keyCode, scanCode)
            }
            return true
        }

        val prefs = getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)

        if (keyCode == KeyEvent.KEYCODE_VOICE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_SEARCH
        ) {
            val customAssistTarget = prefs.getString("key_bind_$keyCode", null) ?: "ACTION_AI"
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                executeBoundAction(customAssistTarget)
            }
            return true
        }

        val presetTarget = resolvePresetBinding(prefs, keyCode, scanCode)
        if (!presetTarget.isNullOrEmpty()) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                executeBoundAction(presetTarget)
            }
            return true
        }

        val boundTarget = prefs.getString("key_bind_$keyCode", null)
            ?: if (scanCode > 0) prefs.getString("scan_bind_$scanCode", null) else null

        if (boundTarget.isNullOrEmpty()) {
            return false
        }

        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            executeBoundAction(boundTarget)
        }
        return true
    }

    private fun resolvePresetBinding(
        prefs: android.content.SharedPreferences,
        keyCode: Int,
        scanCode: Int
    ): String? {
        if (keyCode == KeyEvent.KEYCODE_ALL_APPS ||
            keyCode == KeyEvent.KEYCODE_MENU ||
            keyCode == KeyEvent.KEYCODE_GUIDE ||
            keyCode == KeyEvent.KEYCODE_SETTINGS ||
            keyCode == KeyEvent.KEYCODE_TV_INPUT ||
            keyCode == KeyEvent.KEYCODE_BUTTON_1 ||
            scanCode == 139 || scanCode == 362 || scanCode == 172 || scanCode == 256
        ) {
            prefs.getString("preset_bind_PATCHWALL", null)?.let { if (it.isNotEmpty()) return it }
        }

        if (keyCode == KeyEvent.KEYCODE_BUTTON_2 ||
            keyCode == KeyEvent.KEYCODE_PROG_RED ||
            scanCode == 412 || scanCode == 398 || keyCode == 309
        ) {
            prefs.getString("preset_bind_NETFLIX", null)?.let { if (it.isNotEmpty()) return it }
        }

        if (keyCode == KeyEvent.KEYCODE_BUTTON_3 ||
            keyCode == KeyEvent.KEYCODE_PROG_BLUE ||
            scanCode == 413 || scanCode == 401 || keyCode == 310
        ) {
            prefs.getString("preset_bind_PRIME", null)?.let { if (it.isNotEmpty()) return it }
        }

        return null
    }

    private fun isNetflixPackage(pkg: String): Boolean = pkg.lowercase().contains("netflix")

    private fun isPrimePackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("amazonvideo") || p.contains("amazon.avod") || p.contains("primevideo")
    }

    private fun isPatchwallPackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("patchwall") || p.contains("mitv.tvhome") || p.contains("mitv.smartshare")
    }

    private fun isNavigationOrCenterKey(keyCode: Int): Boolean {
        return keyCode == KeyEvent.KEYCODE_DPAD_UP ||
            keyCode == KeyEvent.KEYCODE_DPAD_DOWN ||
            keyCode == KeyEvent.KEYCODE_DPAD_LEFT ||
            keyCode == KeyEvent.KEYCODE_DPAD_RIGHT ||
            keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
            keyCode == KeyEvent.KEYCODE_ENTER ||
            keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER ||
            keyCode == KeyEvent.KEYCODE_HOME
    }

    private fun executeBoundAction(target: String) {
        when (target) {
            "ACTION_ALL_APPS" -> {
                val intent = Intent(this, LauncherActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("EXTRA_OPEN_ALL_APPS", true)
                }
                startActivity(intent)
            }
            "ACTION_SETTINGS" -> {
                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    startActivity(intent)
                } catch (_: Exception) {
                }
            }
            "ACTION_AI" -> {
                val intent = Intent(this, LauncherActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("EXTRA_OPEN_AI", true)
                }
                startActivity(intent)
            }
            else -> {
                val pm = packageManager
                val launchIntent = pm.getLeanbackLaunchIntentForPackage(target)
                    ?: pm.getLaunchIntentForPackage(target)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        startActivity(launchIntent)
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }
}
