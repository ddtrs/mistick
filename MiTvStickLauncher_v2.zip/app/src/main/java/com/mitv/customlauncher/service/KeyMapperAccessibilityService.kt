package com.mitv.customlauncher.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Parcelable
import android.os.SystemClock
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.LruCache
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import androidx.core.content.ContextCompat
import com.mitv.customlauncher.data.LauncherConfig
import com.mitv.customlauncher.ui.LauncherActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.net.HttpURLConnection
import java.net.URL

data class NowPlayingSnapshot(
    val hasActiveSession: Boolean = false,
    val isPlaying: Boolean = false,
    val title: String = "",
    val artist: String = "",
    val sourcePackage: String = "",
    val sourceAppName: String = "",
    val coverBitmap: Bitmap? = null,
    val durationMs: Long = 0L,
    val basePositionMs: Long = 0L,
    val baseElapsedRealtime: Long = 0L,
    val playbackSpeed: Float = 1.0f
)

object VolumeHudBus {
    @Volatile
    var onVolumeIntercepted: (() -> Unit)? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    fun notifyVolumeChanged() {
        val listener = onVolumeIntercepted ?: return
        mainHandler.post { listener.invoke() }
    }
}

object ServiceAutoActivator {
    @Volatile
    private var notifComponentToggledOnce = false

    fun hasWriteSecureSettings(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.WRITE_SECURE_SETTINGS
        ) == PackageManager.PERMISSION_GRANTED
    }

    /**
     * Безопасная активация служб:
     * 1) НИКОГДА не отключает KeyMapperAccessibilityService (добавляет только если его нет в списке).
     * 2) Принудительно вызывает requestRebind для MediaSessionListenerService (чтобы после обновления APK
     *    NotificationListenerService всегда переподключался и ловил все обновления треков Spotify!).
     */
    fun ensureServicesActive(context: Context) {
        val appCtx = context.applicationContext
        val pkg = appCtx.packageName
        val notifComp = ComponentName(appCtx, MediaSessionListenerService::class.java)

        if (hasWriteSecureSettings(appCtx)) {
            val cr = appCtx.contentResolver
            val accFlat = "$pkg/$pkg.service.KeyMapperAccessibilityService"
            val notifFlat = "$pkg/$pkg.service.MediaSessionListenerService"
            val notifShort = "$pkg/.service.MediaSessionListenerService"

            try {
                val curNotif = Settings.Secure.getString(cr, "enabled_notification_listeners").orEmpty()
                if (!curNotif.contains(notifFlat)) {
                    val base = if (curNotif.isBlank()) "" else "$curNotif:"
                    Settings.Secure.putString(cr, "enabled_notification_listeners", "$base$notifFlat:$notifShort")
                }

                val curAcc = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
                if (!curAcc.contains(pkg)) {
                    val updatedAcc = if (curAcc.isBlank()) accFlat else "$curAcc:$accFlat"
                    Settings.Secure.putString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, updatedAcc)
                    Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
                }
            } catch (_: Exception) {
            }
        }

        // Если NotificationListenerService отвязался после обновления APK — перепривязываем его (не трогая Accessibility!)
        if (MediaSessionListenerService.instance == null) {
            try {
                if (!notifComponentToggledOnce) {
                    notifComponentToggledOnce = true
                    val pm = appCtx.packageManager
                    pm.setComponentEnabledSetting(
                        notifComp,
                        PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                        PackageManager.DONT_KILL_APP
                    )
                    pm.setComponentEnabledSetting(
                        notifComp,
                        PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                        PackageManager.DONT_KILL_APP
                    )
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                    NotificationListenerService.requestRebind(notifComp)
                }
            } catch (_: Exception) {
            }
        }
    }
}

object MediaStateBus {
    private val _state = MutableStateFlow(NowPlayingSnapshot())
    val state: StateFlow<NowPlayingSnapshot> = _state.asStateFlow()

    @Volatile
    var activeController: MediaController? = null

    private val mainHandler = Handler(Looper.getMainLooper())
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val artUriCache = object : LruCache<String, Bitmap>(24) {}
    private var currentArtUri: String = ""
    private var lastFetchedArtUri: String = ""

    private var trackStartRealtime: Long = SystemClock.elapsedRealtime()
    private var lastPausedRealtime: Long = 0L
    private var currentTrackIdentity: String = ""
    private var currentCoverSignature: Int = 0
    private var currentControllerCallback: MediaController.Callback? = null
    private var sessionListenerRegistered = false

    private var lastObservedRawPos: Long = -1L
    private var lastObservedRawRealtime: Long = 0L

    private var dismissedTrackIdentity: String = ""
    private var dismissedAtRealtime: Long = 0L
    private var pausedByLauncherControl: Boolean = false

    fun computeBitmapSignature(bmp: Bitmap?): Int {
        if (bmp == null || bmp.isRecycled) return 0
        val w = bmp.width
        val h = bmp.height
        if (w <= 0 || h <= 0) return 0
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && bmp.config == Bitmap.Config.HARDWARE) {
            val gen = bmp.generationId
            val hash = ((w * 31) xor h) xor (gen * 31)
            return if (hash == 0) 1 else hash
        }
        return try {
            var hash = (w * 31) xor h
            hash = (hash * 31) xor bmp.getPixel(w / 2, h / 2)
            hash = (hash * 31) xor bmp.getPixel(w / 4, h / 4)
            hash = (hash * 31) xor bmp.getPixel((w * 3) / 4, h / 4)
            hash = (hash * 31) xor bmp.getPixel(w / 4, (h * 3) / 4)
            hash = (hash * 31) xor bmp.getPixel((w * 3) / 4, (h * 3) / 4)
            if (hash == 0) 1 else hash
        } catch (_: Exception) {
            val gen = bmp.generationId
            if (gen == 0) 1 else gen
        }
    }

    fun safeScaleBitmap(raw: Bitmap?): Bitmap? {
        if (raw == null || raw.isRecycled) return null
        return try {
            val src = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && raw.config == Bitmap.Config.HARDWARE) {
                raw.copy(Bitmap.Config.ARGB_8888, false) ?: raw
            } else {
                raw
            }
            val scaled = Bitmap.createScaledBitmap(src, 112, 112, true)
            if (src !== raw && src !== scaled && !src.isRecycled) {
                src.recycle()
            }
            scaled
        } catch (_: Exception) {
            raw
        }
    }

    fun getCurrentCoverSignature(): Int = currentCoverSignature

    private fun isActivelyPlayingState(stateCode: Int?): Boolean {
        return stateCode == PlaybackState.STATE_PLAYING ||
            stateCode == PlaybackState.STATE_BUFFERING ||
            stateCode == PlaybackState.STATE_FAST_FORWARDING ||
            stateCode == PlaybackState.STATE_REWINDING ||
            stateCode == PlaybackState.STATE_SKIPPING_TO_NEXT ||
            stateCode == PlaybackState.STATE_SKIPPING_TO_PREVIOUS
    }

    fun queryMediaSessionManagerDirect(context: Context) {
        try {
            val appCtx = context.applicationContext
            val msm = appCtx.getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager ?: return
            val comp = ComponentName(appCtx, MediaSessionListenerService::class.java)

            if (!sessionListenerRegistered) {
                try {
                    val sessionListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
                        selectAndBindBestController(appCtx, list)
                    }
                    msm.addOnActiveSessionsChangedListener(sessionListener, comp, mainHandler)
                    sessionListenerRegistered = true
                } catch (_: Exception) {
                }
            }

            val sessions = msm.getActiveSessions(comp)
            selectAndBindBestController(appCtx, sessions)
        } catch (_: Exception) {
        }
    }

    /**
     * Выбирает только реально играющий контроллер (или контроллер текущей активной сессии),
     * чтобы:
     * 1) Плеер НИКОГДА не загорался сам на старте лаунчера от старых поставленных на паузу приложений.
     * 2) Чужая старая сессия на паузе НИКОГДА не перебивала активный контроллер Spotify!
     */
    private fun selectAndBindBestController(context: Context, controllers: List<MediaController>?) {
        if (controllers.isNullOrEmpty()) return
        val others = controllers.filter { it.packageName != context.packageName }
        if (others.isEmpty()) return

        val playing = others.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: others.firstOrNull { isActivelyPlayingState(it.playbackState?.state) }

        if (playing != null) {
            bindController(context, playing)
            return
        }

        val cur = _state.value
        if (cur.hasActiveSession && cur.sourcePackage.isNotEmpty()) {
            val matching = others.firstOrNull { it.packageName == cur.sourcePackage }
            if (matching != null) {
                bindController(context, matching)
            }
        }
    }

    fun bindController(context: Context, controller: MediaController) {
        val appCtx = context.applicationContext
        val prev = activeController
        if (prev != null && prev.sessionToken == controller.sessionToken) {
            // Даже если токен тот же самый (Spotify не меняет токен между песнями!), сразу читаем свежие данные!
            syncControllerImmediate(appCtx, prev)
            return
        }
        val prevCb = currentControllerCallback
        if (prev != null && prevCb != null) {
            try {
                prev.unregisterCallback(prevCb)
            } catch (_: Exception) {
            }
        }
        activeController = controller

        val cb = object : MediaController.Callback() {
            override fun onPlaybackStateChanged(state: PlaybackState?) {
                if (state != null) {
                    val playing = isActivelyPlayingState(state.state)
                    if (playing) pausedByLauncherControl = false
                    updatePositionOnly(
                        positionMs = state.position,
                        positionUpdateRealtime = state.lastPositionUpdateTime,
                        speed = state.playbackSpeed,
                        isPlaying = playing
                    )
                }
            }

            override fun onMetadataChanged(metadata: MediaMetadata?) {
                syncControllerImmediate(appCtx, controller)
            }
        }
        currentControllerCallback = cb
        try {
            controller.registerCallback(cb, mainHandler)
        } catch (_: Exception) {
        }

        syncControllerImmediate(appCtx, controller)
    }

    fun syncControllerImmediate(context: Context, controller: MediaController) {
        try {
            val meta = controller.metadata
            val pb = controller.playbackState
            val cur = _state.value
            val pkg = controller.packageName.orEmpty().ifEmpty { cur.sourcePackage }
            val appName = resolveAppLabel(context, pkg)

            val playing = isActivelyPlayingState(pb?.state)
            // Если плеер сейчас скрыт и контроллер НЕ играет — не зажигаем плеер вхолостую!
            if (!cur.hasActiveSession && !playing) {
                return
            }

            var title = ""
            var artist = ""
            var dur = -1L
            var artUri = ""
            var newCover: Bitmap? = null
            var newSig = 0

            if (meta != null) {
                title = (meta.getString(MediaMetadata.METADATA_KEY_TITLE)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)).orEmpty().trim()
                artist = (meta.getString(MediaMetadata.METADATA_KEY_ARTIST)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)).orEmpty().trim()
                val d = meta.getLong(MediaMetadata.METADATA_KEY_DURATION)
                if (d > 0L) dur = d

                artUri = (meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_ART_URI)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)).orEmpty().trim()

                val rawArt = meta.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                    ?: meta.getBitmap(MediaMetadata.METADATA_KEY_ART)
                    ?: meta.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                if (rawArt != null) {
                    val sig = computeBitmapSignature(rawArt)
                    if (sig != 0 && (sig != currentCoverSignature || cur.coverBitmap == null)) {
                        newCover = safeScaleBitmap(rawArt)
                        newSig = sig
                    }
                }
            }

            var pos = -1L
            var posTime = 0L
            var spd = 1.0f
            if (pb != null) {
                pos = pb.position
                posTime = pb.lastPositionUpdateTime
                spd = pb.playbackSpeed
                updatePlayingFlag(playing)
            }

            if (title.isNotEmpty() || artist.isNotEmpty() || newCover != null || artUri.isNotEmpty() || pos >= 0L || dur > 0L) {
                updateMetadata(
                    context = context,
                    title = title,
                    artist = artist,
                    sourcePackage = pkg,
                    sourceAppName = appName,
                    cover = newCover,
                    coverSignature = newSig,
                    artUri = artUri,
                    durationMs = dur,
                    positionMs = pos,
                    positionUpdateRealtime = posTime,
                    speed = spd
                )
            }
        } catch (_: Exception) {
        }
    }

    /**
     * Единый полный разбор уведомления от Spotify / Chromecast (mediashell) / SoundCloud / YouTube:
     * Вызывается как из MediaSessionListenerService (который видит ВСЕ тихие FLAG_ONLY_ALERT_ONCE смены треков!),
     * так и из KeyMapperAccessibilityService и секундного опроса activeNotifications.
     */
    fun ingestNotification(
        context: Context,
        pkg: String,
        notif: Notification,
        requireActivePlaybackOrSession: Boolean = false
    ) {
        try {
            val appCtx = context.applicationContext
            val p = pkg.lowercase()
            if (pkg == appCtx.packageName ||
                p.startsWith("com.android.packageinstaller") ||
                p.startsWith("com.google.android.packageinstaller") ||
                p.startsWith("com.android.vending") ||
                p.startsWith("com.android.systemui") ||
                p.startsWith("com.android.settings")
            ) {
                return
            }

            val extras = notif.extras ?: return
            @Suppress("DEPRECATION")
            val sessionToken = (extras.getParcelable<Parcelable>(Notification.EXTRA_MEDIA_SESSION) as? MediaSession.Token)
                ?: (extras.getParcelable<Parcelable>("android.support.v4.media.session.EXTRA_SESSION_TOKEN") as? MediaSession.Token)

            val isKnownMediaPkg = p.contains("spotify") ||
                p.contains("mediashell") ||
                p.contains("chromecast") ||
                p.contains("soundcloud") ||
                p.contains("youtube") ||
                p.contains("music") ||
                notif.category == Notification.CATEGORY_TRANSPORT

            if (sessionToken == null && !isKnownMediaPkg) {
                return
            }

            if (sessionToken != null) {
                val curCtrl = activeController
                if (curCtrl == null || curCtrl.sessionToken != sessionToken) {
                    bindController(appCtx, MediaController(appCtx, sessionToken))
                }
            }

            val ctrl = activeController?.takeIf { it.packageName == pkg || sessionToken != null }
            val pb = ctrl?.playbackState
            val am = appCtx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            val isMusicCurrentlyActive = am?.isMusicActive == true
            val isCtrlPlaying = isActivelyPlayingState(pb?.state)

            if (requireActivePlaybackOrSession && !_state.value.hasActiveSession && !isCtrlPlaying && !isMusicCurrentlyActive) {
                return
            }

            var notifTitle = (extras.getCharSequence(Notification.EXTRA_TITLE)
                ?: extras.getCharSequence(Notification.EXTRA_TITLE_BIG))?.toString()?.trim().orEmpty()
            var notifArtist = (extras.getCharSequence(Notification.EXTRA_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_SUB_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_SUMMARY_TEXT))?.toString()?.trim().orEmpty()
            val appName = resolveAppLabel(appCtx, pkg)

            var durationMs = -1L
            var posMs = -1L
            var posRealtime = 0L
            var speed = 1.0f
            var artUri = ""
            var metaRawArt: Bitmap? = null

            if (ctrl != null) {
                val meta = ctrl.metadata
                if (meta != null) {
                    val metaTitle = (meta.getString(MediaMetadata.METADATA_KEY_TITLE)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE))?.trim()
                    val metaArtist = (meta.getString(MediaMetadata.METADATA_KEY_ARTIST)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE))?.trim()

                    if (notifTitle.isBlank() && !metaTitle.isNullOrBlank()) notifTitle = metaTitle
                    if (notifArtist.isBlank() && !metaArtist.isNullOrBlank()) notifArtist = metaArtist

                    val d = meta.getLong(MediaMetadata.METADATA_KEY_DURATION)
                    if (d > 0L) durationMs = d

                    artUri = (meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_ART_URI)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)).orEmpty().trim()

                    metaRawArt = meta.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                        ?: meta.getBitmap(MediaMetadata.METADATA_KEY_ART)
                        ?: meta.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                }

                if (pb != null) {
                    posMs = pb.position
                    posRealtime = pb.lastPositionUpdateTime
                    speed = pb.playbackSpeed
                    updatePlayingFlag(isCtrlPlaying)
                }
            } else if (isMusicCurrentlyActive) {
                updatePlayingFlag(true)
            }

            if (durationMs <= 0L) {
                val progMax = extras.getInt(Notification.EXTRA_PROGRESS_MAX, 0)
                if (progMax > 1000) {
                    durationMs = progMax.toLong()
                    val progCur = extras.getInt(Notification.EXTRA_PROGRESS, -1)
                    if (posMs < 0L && progCur >= 0) {
                        posMs = progCur.toLong()
                    }
                }
            }

            // Приоритет обложки из самого уведомления (Spotify / Cast кладет свежую обложку в largeIcon уведомления!)
            @Suppress("DEPRECATION")
            var rawCandidate: Bitmap? = (extras.getParcelable<Parcelable>(Notification.EXTRA_LARGE_ICON_BIG) as? Bitmap)
                ?: (extras.getParcelable<Parcelable>(Notification.EXTRA_LARGE_ICON) as? Bitmap)
                ?: (extras.getParcelable<Parcelable>(Notification.EXTRA_PICTURE) as? Bitmap)

            if (rawCandidate == null) {
                val largeIcon = notif.getLargeIcon()
                if (largeIcon != null) {
                    val d = largeIcon.loadDrawable(appCtx)
                    if (d is BitmapDrawable && d.bitmap != null) {
                        rawCandidate = d.bitmap
                    } else if (d != null) {
                        rawCandidate = drawableToSmallBitmap(d)
                    }
                }
            }

            if (rawCandidate == null) {
                rawCandidate = metaRawArt
            }

            var coverBmp: Bitmap? = null
            var sig = 0
            if (rawCandidate != null) {
                sig = computeBitmapSignature(rawCandidate)
                val curCover = _state.value.coverBitmap
                if (sig != 0 && sig == currentCoverSignature && curCover != null) {
                    coverBmp = curCover
                } else {
                    coverBmp = safeScaleBitmap(rawCandidate)
                }
            }

            if (notifTitle.isEmpty() && notifArtist.isEmpty() && coverBmp == null && artUri.isEmpty()) return

            updateMetadata(
                context = appCtx,
                title = notifTitle,
                artist = notifArtist,
                sourcePackage = pkg,
                sourceAppName = appName,
                cover = coverBmp,
                coverSignature = sig,
                artUri = artUri,
                durationMs = durationMs,
                positionMs = posMs,
                positionUpdateRealtime = posRealtime,
                speed = speed
            )
        } catch (_: Exception) {
        }
    }

    private fun drawableToSmallBitmap(d: Drawable): Bitmap? {
        return try {
            if (d is BitmapDrawable && d.bitmap != null) {
                safeScaleBitmap(d.bitmap)
            } else {
                val bmp = Bitmap.createBitmap(112, 112, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bmp)
                d.setBounds(0, 0, 112, 112)
                d.draw(canvas)
                bmp
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun resolveAppLabel(context: Context, pkg: String): String {
        if (pkg.isBlank()) return ""
        return try {
            val ai = context.packageManager.getApplicationInfo(pkg, 0)
            context.packageManager.getApplicationLabel(ai).toString()
        } catch (_: Exception) {
            pkg.substringAfterLast('.')
        }
    }

    fun dismissPlayerByUser(audioManager: AudioManager) {
        val cur = _state.value
        val now = SystemClock.elapsedRealtime()
        dismissedTrackIdentity = currentTrackIdentity.ifEmpty { "DISMISSED_SESSION" }
        dismissedAtRealtime = now
        pausedByLauncherControl = true

        try {
            val ctrl = activeController
            if (ctrl != null && (isActivelyPlayingState(ctrl.playbackState?.state) || cur.isPlaying)) {
                ctrl.transportControls.pause()
            } else if (cur.isPlaying) {
                val upNow = SystemClock.uptimeMillis()
                audioManager.dispatchMediaKeyEvent(KeyEvent(upNow, upNow, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PAUSE, 0))
                audioManager.dispatchMediaKeyEvent(KeyEvent(upNow, upNow, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PAUSE, 0))
            }
        } catch (_: Exception) {
        }

        _state.value = NowPlayingSnapshot(
            hasActiveSession = false,
            isPlaying = false
        )
    }

    fun onContinuousBackgroundMusicDetected() {
        val now = SystemClock.elapsedRealtime()
        if (pausedByLauncherControl) return
        if (dismissedTrackIdentity.isNotEmpty() && (now - dismissedAtRealtime) < 8000L) return
        val cur = _state.value
        if (!cur.hasActiveSession || !cur.isPlaying) {
            updatePlayingFlag(true)
        }
    }

    fun updateMetadata(
        context: Context? = null,
        title: String,
        artist: String,
        sourcePackage: String,
        sourceAppName: String,
        cover: Bitmap?,
        coverSignature: Int = 0,
        artUri: String = "",
        durationMs: Long = -1L,
        positionMs: Long = -1L,
        positionUpdateRealtime: Long = 0L,
        speed: Float = 1.0f
    ) {
        val current = _state.value
        val now = SystemClock.elapsedRealtime()
        val resolvedPkg = if (sourcePackage.isNotBlank()) sourcePackage else current.sourcePackage
        val resolvedTitle = if (title.isNotBlank()) title else if (resolvedPkg == current.sourcePackage) current.title else ""
        val resolvedArtist = if (artist.isNotBlank()) artist else if (resolvedPkg == current.sourcePackage) current.artist else ""
        val resolvedAppName = if (sourceAppName.isNotBlank()) sourceAppName else if (resolvedPkg == current.sourcePackage) current.sourceAppName else ""

        val newIdentity = "$resolvedPkg|$resolvedTitle"
        if (dismissedTrackIdentity.isNotEmpty()) {
            if ((now - dismissedAtRealtime) < 3000L) return
            if (newIdentity == dismissedTrackIdentity && !current.isPlaying) return
            if (newIdentity != dismissedTrackIdentity) {
                dismissedTrackIdentity = ""
                pausedByLauncherControl = false
            }
        }

        val trackChanged = resolvedTitle.isNotBlank() && newIdentity != currentTrackIdentity
        if (trackChanged) {
            currentTrackIdentity = newIdentity
            trackStartRealtime = now
            lastObservedRawPos = -1L
            lastObservedRawRealtime = 0L
            pausedByLauncherControl = false
        }

        if (positionMs >= 0L && positionMs != lastObservedRawPos) {
            lastObservedRawPos = positionMs
            lastObservedRawRealtime = now
        }

        var resolvedCover: Bitmap? = when {
            cover != null -> {
                val incomingSig = if (coverSignature != 0) coverSignature else computeBitmapSignature(cover)
                // Если трек сменился, а в MediaMetadata ещё лежит старый Bitmap с точно такой же сигнатурой —
                // ждём настоящую новую обложку (или грузим по новому artUri)!
                if (trackChanged && incomingSig != 0 && incomingSig == currentCoverSignature && artUri.isNotBlank() && artUri != currentArtUri) {
                    null
                } else {
                    currentCoverSignature = incomingSig
                    cover
                }
            }
            !trackChanged && resolvedPkg == current.sourcePackage -> current.coverBitmap
            else -> {
                currentCoverSignature = 0
                null
            }
        }

        // Если ссылка на обложку (artUri) изменилась или обложки ещё нет — мгновенно берём из кэша или скачиваем!
        if (artUri.isNotBlank() && (resolvedCover == null || artUri != currentArtUri)) {
            currentArtUri = artUri
            val cached = artUriCache.get(artUri)
            if (cached != null) {
                resolvedCover = cached
                currentCoverSignature = computeBitmapSignature(cached)
            } else if (artUri != lastFetchedArtUri) {
                lastFetchedArtUri = artUri
                fetchArtFromUriAsync(context, artUri, newIdentity)
            }
        }

        val resolvedDuration = if (durationMs > 0L) durationMs else if (trackChanged) 0L else current.durationMs
        val resolvedPos = when {
            positionMs >= 0L -> if (resolvedDuration > 0L) positionMs.coerceAtMost(resolvedDuration) else positionMs
            trackChanged -> 0L
            else -> current.basePositionMs
        }
        val resolvedRealtime = when {
            positionUpdateRealtime in 1L..(now + 1000L) && (now - positionUpdateRealtime) in 0L..7_200_000L -> positionUpdateRealtime
            positionMs >= 0L -> now
            trackChanged -> now
            else -> current.baseElapsedRealtime
        }

        val hasSession = current.hasActiveSession ||
            resolvedTitle.isNotBlank() ||
            resolvedArtist.isNotBlank() ||
            resolvedCover != null ||
            current.isPlaying
        val playingNow = if (trackChanged) true else current.isPlaying

        _state.value = current.copy(
            hasActiveSession = hasSession,
            isPlaying = playingNow,
            title = resolvedTitle,
            artist = resolvedArtist,
            sourcePackage = resolvedPkg,
            sourceAppName = resolvedAppName,
            coverBitmap = resolvedCover,
            durationMs = resolvedDuration,
            basePositionMs = resolvedPos,
            baseElapsedRealtime = resolvedRealtime,
            playbackSpeed = if (speed > 0f) speed else 1.0f
        )
    }

    fun updatePositionOnly(positionMs: Long, positionUpdateRealtime: Long, speed: Float, isPlaying: Boolean) {
        val cur = _state.value
        val now = SystemClock.elapsedRealtime()
        if (dismissedTrackIdentity.isNotEmpty() && (now - dismissedAtRealtime) < 3000L && !isPlaying) return
        if (isPlaying) {
            dismissedTrackIdentity = ""
            pausedByLauncherControl = false
            lastPausedRealtime = 0L
        } else if (cur.isPlaying) {
            lastPausedRealtime = now
        }
        if (positionMs >= 0L && positionMs != lastObservedRawPos) {
            lastObservedRawPos = positionMs
            lastObservedRawRealtime = now
        }
        val validPos = if (positionMs >= 0L) {
            if (cur.durationMs > 0L) positionMs.coerceAtMost(cur.durationMs) else positionMs
        } else {
            cur.basePositionMs
        }
        val validRealtime = if (positionUpdateRealtime in 1L..(now + 1000L) && (now - positionUpdateRealtime) in 0L..7_200_000L) {
            positionUpdateRealtime
        } else {
            now
        }
        _state.value = cur.copy(
            hasActiveSession = cur.hasActiveSession || isPlaying,
            isPlaying = isPlaying,
            basePositionMs = validPos,
            baseElapsedRealtime = validRealtime,
            playbackSpeed = if (speed > 0f) speed else 1.0f
        )
    }

    private fun fetchArtFromUriAsync(context: Context?, uriString: String, expectedIdentity: String) {
        val appCtx = context?.applicationContext
        ioScope.launch {
            try {
                val raw: Bitmap? = when {
                    uriString.startsWith("http://") || uriString.startsWith("https://") -> {
                        val conn = (URL(uriString).openConnection() as HttpURLConnection).apply {
                            connectTimeout = 3500
                            readTimeout = 3500
                            doInput = true
                        }
                        conn.connect()
                        val decoded = conn.inputStream.use { BitmapFactory.decodeStream(it) }
                        conn.disconnect()
                        decoded
                    }
                    (uriString.startsWith("content://") || uriString.startsWith("android.resource://") || uriString.startsWith("file://")) && appCtx != null -> {
                        appCtx.contentResolver.openInputStream(Uri.parse(uriString))?.use {
                            BitmapFactory.decodeStream(it)
                        }
                    }
                    else -> null
                }

                if (raw != null) {
                    val scaled = safeScaleBitmap(raw)
                    if (scaled != null && scaled !== raw && !raw.isRecycled) raw.recycle()
                    if (scaled != null) {
                        artUriCache.put(uriString, scaled)
                        if (currentTrackIdentity == expectedIdentity || _state.value.coverBitmap == null || currentArtUri == uriString) {
                            currentCoverSignature = computeBitmapSignature(scaled)
                            _state.value = _state.value.copy(coverBitmap = scaled)
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    fun updatePlayingFlag(isPlaying: Boolean) {
        val cur = _state.value
        val now = SystemClock.elapsedRealtime()
        if (isPlaying) {
            if (dismissedTrackIdentity.isNotEmpty() && (now - dismissedAtRealtime) < 2500L) return
            dismissedTrackIdentity = ""
            pausedByLauncherControl = false
            lastPausedRealtime = 0L
            if (!cur.isPlaying && cur.basePositionMs == 0L) {
                trackStartRealtime = now
            }
            if (!cur.isPlaying || !cur.hasActiveSession) {
                _state.value = cur.copy(
                    hasActiveSession = true,
                    isPlaying = true,
                    baseElapsedRealtime = now
                )
            }
        } else {
            if (cur.isPlaying) {
                val (frozenPos, _) = getLivePositionAndDuration()
                lastPausedRealtime = now
                _state.value = cur.copy(
                    isPlaying = false,
                    basePositionMs = frozenPos,
                    baseElapsedRealtime = now
                )
            } else if (cur.hasActiveSession && lastPausedRealtime > 0L && (now - lastPausedRealtime) > 20 * 60 * 1000L) {
                _state.value = cur.copy(hasActiveSession = false)
            }
        }
    }

    /**
     * Полный живой опрос всех источников медиа (вызывается каждые 500 мс):
     * 1) MediaSessionManager.getActiveSessions
     * 2) MediaSessionListenerService.instance?.activeNotifications (ловит все тихие смены треков Spotify!)
     * 3) activeController.metadata & playbackState
     */
    fun pollActiveControllerLight(context: Context? = null) {
        if (context != null) {
            queryMediaSessionManagerDirect(context)
            MediaSessionListenerService.instance?.pollActiveMediaNotifications(context)
        }
        val ctrl = activeController ?: return
        if (context != null) {
            syncControllerImmediate(context, ctrl)
        }
    }

    fun getLivePositionAndDuration(): Pair<Long, Long> {
        val ctrl = activeController
        val snap = _state.value
        val now = SystemClock.elapsedRealtime()

        var dur = snap.durationMs.coerceAtLeast(0L)
        if (ctrl != null) {
            try {
                val metaDur = ctrl.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
                if (metaDur > 0L) dur = metaDur
            } catch (_: Exception) {
            }
        }

        if (!snap.isPlaying) {
            val frozen = if (dur > 0L) snap.basePositionMs.coerceIn(0L, dur) else snap.basePositionMs.coerceAtLeast(0L)
            return frozen to dur
        }

        if (ctrl != null) {
            try {
                val pb = ctrl.playbackState
                if (pb != null && pb.position >= 0L) {
                    var pos = pb.position
                    val speed = if (pb.playbackSpeed > 0f) pb.playbackSpeed else 1.0f
                    if (isActivelyPlayingState(pb.state)) {
                        val lastUpdate = pb.lastPositionUpdateTime
                        val delta = when {
                            lastUpdate in 1L..(now + 1000L) && (now - lastUpdate) in 0L..7_200_000L -> {
                                (now - lastUpdate).coerceAtLeast(0L)
                            }
                            lastObservedRawRealtime in 1L..now -> {
                                (now - lastObservedRawRealtime).coerceAtLeast(0L)
                            }
                            else -> 0L
                        }
                        pos += (delta * speed).toLong().coerceAtLeast(0L)
                    }
                    if (dur > 0L) pos = pos.coerceAtMost(dur)
                    return pos.coerceAtLeast(0L) to dur
                }
            } catch (_: Exception) {
            }
        }

        if (snap.basePositionMs > 0L && snap.baseElapsedRealtime > 0L) {
            val delta = (now - snap.baseElapsedRealtime).coerceAtLeast(0L)
            var pos = snap.basePositionMs + (delta * snap.playbackSpeed).toLong().coerceAtLeast(0L)
            if (dur > 0L) pos = pos.coerceAtMost(dur)
            return pos to dur
        }

        var elapsed = (now - trackStartRealtime).coerceAtLeast(0L)
        if (dur > 0L) elapsed = elapsed.coerceAtMost(dur)
        return elapsed to dur
    }

    fun dispatchTransportAction(action: String, audioManager: AudioManager) {
        val ctrl = activeController
        try {
            if (ctrl != null) {
                val tc = ctrl.transportControls
                val pbState = ctrl.playbackState?.state
                when (action) {
                    "PREV" -> {
                        pausedByLauncherControl = false
                        tc.skipToPrevious()
                        return
                    }
                    "NEXT" -> {
                        pausedByLauncherControl = false
                        tc.skipToNext()
                        return
                    }
                    "PLAY_PAUSE" -> {
                        if (isActivelyPlayingState(pbState) || _state.value.isPlaying) {
                            pausedByLauncherControl = true
                            tc.pause()
                            updatePlayingFlag(false)
                        } else {
                            pausedByLauncherControl = false
                            dismissedTrackIdentity = ""
                            tc.play()
                            updatePlayingFlag(true)
                        }
                        return
                    }
                }
            }
        } catch (_: Exception) {
        }

        val keyCode = when (action) {
            "PREV" -> {
                pausedByLauncherControl = false
                KeyEvent.KEYCODE_MEDIA_PREVIOUS
            }
            "NEXT" -> {
                pausedByLauncherControl = false
                KeyEvent.KEYCODE_MEDIA_NEXT
            }
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        try {
            val now = SystemClock.uptimeMillis()
            audioManager.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0))
            audioManager.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_UP, keyCode, 0))
            if (action == "PLAY_PAUSE") {
                val targetPlay = !_state.value.isPlaying
                pausedByLauncherControl = !targetPlay
                if (targetPlay) dismissedTrackIdentity = ""
                updatePlayingFlag(targetPlay)
            }
        } catch (_: Exception) {
        }
    }
}

object KeyCaptureBus {
    @Volatile
    var isCapturingKey: Boolean = false

    @Volatile
    var onKeyCapturedListener: ((keyCode: Int, scanCode: Int) -> Unit)? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    fun notifyKeyCaptured(keyCode: Int, scanCode: Int): Boolean {
        val listener = onKeyCapturedListener ?: return false
        isCapturingKey = false
        mainHandler.post {
            listener.invoke(keyCode, scanCode)
        }
        return true
    }
}

class MediaSessionListenerService : NotificationListenerService() {

    companion object {
        @Volatile
        var instance: MediaSessionListenerService? = null
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        pollActiveMediaNotifications(this)
        MediaStateBus.queryMediaSessionManagerDirect(this)
    }

    override fun onListenerDisconnected() {
        instance = null
        super.onListenerDisconnected()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try {
                requestRebind(ComponentName(this, MediaSessionListenerService::class.java))
            } catch (_: Exception) {
            }
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        instance = this
        if (sbn == null) return
        val pkg = sbn.packageName ?: return
        if (pkg == packageName) return
        val notif = sbn.notification ?: return
        MediaStateBus.ingestNotification(this, pkg, notif, requireActivePlaybackOrSession = false)
    }

    fun pollActiveMediaNotifications(context: Context) {
        try {
            val list = activeNotifications ?: return
            for (sbn in list) {
                val pkg = sbn.packageName ?: continue
                if (pkg == context.packageName) continue
                val notif = sbn.notification ?: continue
                MediaStateBus.ingestNotification(context, pkg, notif, requireActivePlaybackOrSession = true)
            }
        } catch (_: Exception) {
        }
    }
}

class KeyMapperAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var isServiceConnectedAlive: Boolean = false
    }

    private var lastInterceptMillis: Long = 0L

    override fun onServiceConnected() {
        super.onServiceConnected()
        isServiceConnectedAlive = true
        try {
            val info = serviceInfo ?: AccessibilityServiceInfo()
            info.flags = info.flags or AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
            serviceInfo = info
        } catch (_: Exception) {
        }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        isServiceConnectedAlive = false
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        isServiceConnectedAlive = false
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        isServiceConnectedAlive = true
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return

        if (event.eventType == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            val notif = event.parcelableData as? Notification
            if (notif != null && pkg != packageName) {
                MediaStateBus.ingestNotification(this, pkg, notif, requireActivePlaybackOrSession = false)
            }
            return
        }

        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && pkg != packageName) {
            val prefs = getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            val matchedPresetTarget: String? = when {
                isNetflixPackage(pkg) -> prefs.getString("preset_bind_NETFLIX", null)
                isPrimePackage(pkg) -> prefs.getString("preset_bind_PRIME", null)
                isPatchwallPackage(pkg) -> prefs.getString("preset_bind_PATCHWALL", "ACTION_CONTROL_CENTER")
                else -> null
            }

            if (!matchedPresetTarget.isNullOrEmpty()) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastInterceptMillis > 600L) {
                    lastInterceptMillis = now
                    executeBoundAction(matchedPresetTarget)
                }
            }
        }
    }

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        isServiceConnectedAlive = true
        val keyCode = event.keyCode
        val scanCode = event.scanCode

        // Перехват кнопок громкости с флагом 0 (блокирует штатный белый ползунок и показывает наш кастомный HUD!)
        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
            keyCode == KeyEvent.KEYCODE_VOLUME_DOWN ||
            keyCode == KeyEvent.KEYCODE_VOLUME_MUTE
        ) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                try {
                    val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    when (keyCode) {
                        KeyEvent.KEYCODE_VOLUME_UP ->
                            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0)
                        KeyEvent.KEYCODE_VOLUME_DOWN ->
                            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0)
                        KeyEvent.KEYCODE_VOLUME_MUTE ->
                            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, 0)
                    }
                    VolumeHudBus.notifyVolumeChanged()
                } catch (_: Exception) {
                }
            }
            return true
        }

        if (KeyCaptureBus.isCapturingKey) {
            if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
                return false
            }
            if (isNavigationOrCenterKey(keyCode)) {
                return false
            }
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                KeyCaptureBus.notifyKeyCaptured(keyCode, scanCode)
            }
            return true
        }

        if (isNavigationOrCenterKey(keyCode)) {
            return false
        }

        val prefs = getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)

        if (keyCode == KeyEvent.KEYCODE_VOICE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_SEARCH
        ) {
            val customAssistTarget = prefs.getString("key_bind_$keyCode", null) ?: "ACTION_AI"
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                executeBoundAction(customAssistTarget)
            }
            return true
        }

        val presetTarget = resolvePresetBinding(prefs, keyCode, scanCode)
        if (!presetTarget.isNullOrEmpty()) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                executeBoundAction(presetTarget)
            }
            return true
        }

        val boundTarget = prefs.getString("key_bind_$keyCode", null)
            ?: if (scanCode > 0) prefs.getString("scan_bind_$scanCode", null) else null

        if (boundTarget.isNullOrEmpty()) {
            return false
        }

        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            executeBoundAction(boundTarget)
        }
        return true
    }

    private fun resolvePresetBinding(
        prefs: android.content.SharedPreferences,
        keyCode: Int,
        scanCode: Int
    ): String? {
        if (keyCode == KeyEvent.KEYCODE_ALL_APPS ||
            keyCode == KeyEvent.KEYCODE_MENU ||
            keyCode == KeyEvent.KEYCODE_GUIDE ||
            keyCode == KeyEvent.KEYCODE_SETTINGS ||
            keyCode == KeyEvent.KEYCODE_TV_INPUT ||
            keyCode == KeyEvent.KEYCODE_BUTTON_1 ||
            scanCode == 139 || scanCode == 362 || scanCode == 172 || scanCode == 256
        ) {
            val target = prefs.getString("preset_bind_PATCHWALL", "ACTION_CONTROL_CENTER")
            if (!target.isNullOrEmpty()) return target
        }

        if (keyCode == KeyEvent.KEYCODE_BUTTON_2 ||
            keyCode == KeyEvent.KEYCODE_PROG_RED ||
            scanCode == 412 || scanCode == 398 || keyCode == 309
        ) {
            prefs.getString("preset_bind_NETFLIX", null)?.let { if (it.isNotEmpty()) return it }
        }

        if (keyCode == KeyEvent.KEYCODE_BUTTON_3 ||
            keyCode == KeyEvent.KEYCODE_PROG_BLUE ||
            scanCode == 413 || scanCode == 401 || keyCode == 310
        ) {
            prefs.getString("preset_bind_PRIME", null)?.let { if (it.isNotEmpty()) return it }
        }

        return null
    }

    private fun isNetflixPackage(pkg: String): Boolean = pkg.lowercase().contains("netflix")

    private fun isPrimePackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("amazonvideo") || p.contains("amazon.avod") || p.contains("primevideo")
    }

    private fun isPatchwallPackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("patchwall") || p.contains("mitv.tvhome") || p.contains("mitv.smartshare")
    }

    private fun isNavigationOrCenterKey(keyCode: Int): Boolean {
        return keyCode == KeyEvent.KEYCODE_DPAD_UP ||
            keyCode == KeyEvent.KEYCODE_DPAD_DOWN ||
            keyCode == KeyEvent.KEYCODE_DPAD_LEFT ||
            keyCode == KeyEvent.KEYCODE_DPAD_RIGHT ||
            keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
            keyCode == KeyEvent.KEYCODE_ENTER ||
            keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER ||
            keyCode == KeyEvent.KEYCODE_HOME
    }

    private fun executeBoundAction(target: String) {
        when (target) {
            "ACTION_CONTROL_CENTER" -> {
                val intent = Intent(this, LauncherActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("EXTRA_OPEN_CONTROL_CENTER", true)
                }
                startActivity(intent)
            }
            "ACTION_ALL_APPS" -> {
                val intent = Intent(this, LauncherActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("EXTRA_OPEN_ALL_APPS", true)
                }
                startActivity(intent)
            }
            "ACTION_SETTINGS" -> {
                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    startActivity(intent)
                } catch (_: Exception) {
                }
            }
            "ACTION_AI" -> {
                val intent = Intent(this, LauncherActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("EXTRA_OPEN_AI", true)
                }
                startActivity(intent)
            }
            else -> {
                val pm = packageManager
                val launchIntent = pm.getLeanbackLaunchIntentForPackage(target)
                    ?: pm.getLaunchIntentForPackage(target)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        startActivity(launchIntent)
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }
}
