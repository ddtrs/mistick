package com.mitv.customlauncher.service

import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.Settings
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.mitv.customlauncher.data.LauncherConfig
import com.mitv.customlauncher.ui.LauncherActivity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class NowPlayingSnapshot(
    val isPlaying: Boolean = false,
    val title: String = "",
    val artist: String = "",
    val sourcePackage: String = "",
    val sourceAppName: String = "",
    val coverBitmap: Bitmap? = null,
    val accentColor: Int = Color.parseColor("#00F0FF")
)

object MediaStateBus {
    private val _state = MutableStateFlow(NowPlayingSnapshot())
    val state: StateFlow<NowPlayingSnapshot> = _state.asStateFlow()

    fun updateMetadata(
        title: String,
        artist: String,
        sourcePackage: String,
        sourceAppName: String,
        cover: Bitmap?
    ) {
        val current = _state.value
        val newCover = cover ?: current.coverBitmap
        val accent = if (newCover != null) extractVibrantAccent(newCover) else Color.parseColor("#00F0FF")
        _state.value = current.copy(
            title = if (title.isNotBlank()) title else current.title,
            artist = if (artist.isNotBlank()) artist else current.artist,
            sourcePackage = if (sourcePackage.isNotBlank()) sourcePackage else current.sourcePackage,
            sourceAppName = if (sourceAppName.isNotBlank()) sourceAppName else current.sourceAppName,
            coverBitmap = newCover,
            accentColor = accent
        )
    }

    fun updatePlayingFlag(isPlaying: Boolean) {
        if (_state.value.isPlaying != isPlaying) {
            _state.value = _state.value.copy(isPlaying = isPlaying)
        }
    }

    private fun extractVibrantAccent(bmp: Bitmap): Int {
        return try {
            val w = bmp.width
            val h = bmp.height
            val cx = w / 2
            val cy = h / 2
            val c = bmp.getPixel(cx, cy)
            val r = Color.red(c)
            val g = Color.green(c)
            val b = Color.blue(c)
            // Делаем цвет достаточно ярким для тёмного фона #08080A
            if (r + g + b < 140) {
                Color.parseColor("#00F0FF")
            } else {
                Color.rgb(
                    (r + 80).coerceAtMost(255),
                    (g + 80).coerceAtMost(255),
                    (b + 80).coerceAtMost(255)
                )
            }
        } catch (_: Exception) {
            Color.parseColor("#00F0FF")
        }
    }
}

object KeyCaptureBus {
    @Volatile
    var isCapturingKey: Boolean = false

    @Volatile
    var onKeyCapturedListener: ((keyCode: Int, scanCode: Int) -> Unit)? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    fun notifyKeyCaptured(keyCode: Int, scanCode: Int): Boolean {
        val listener = onKeyCapturedListener ?: return false
        isCapturingKey = false
        mainHandler.post {
            listener.invoke(keyCode, scanCode)
        }
        return true
    }
}

class KeyMapperAccessibilityService : AccessibilityService() {

    private var lastInterceptMillis: Long = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return

        // 1. Ловим медиа-уведомления от Spotify, SoundCloud, SmartTube, YouTube, браузера и плееров
        if (event.eventType == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            val notif = event.parcelableData as? Notification
            if (notif != null && pkg != packageName) {
                extractMediaFromNotification(pkg, notif)
            }
            return
        }

        // 2. Перехват окон Netflix / Prime / PatchWall и запоминание последнего медиа-приложения
        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && pkg != packageName) {
            if (isKnownMediaApp(pkg)) {
                val appLabel = resolveAppLabel(pkg)
                MediaStateBus.updateMetadata(
                    title = "",
                    artist = "",
                    sourcePackage = pkg,
                    sourceAppName = appLabel,
                    cover = null
                )
            }

            val prefs = getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            val matchedPresetTarget: String? = when {
                isNetflixPackage(pkg) -> prefs.getString("preset_bind_NETFLIX", null)
                isPrimePackage(pkg) -> prefs.getString("preset_bind_PRIME", null)
                isPatchwallPackage(pkg) -> prefs.getString("preset_bind_PATCHWALL", null)
                else -> null
            }

            if (!matchedPresetTarget.isNullOrEmpty()) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastInterceptMillis > 600L) {
                    lastInterceptMillis = now
                    executeBoundAction(matchedPresetTarget)
                }
            }
        }
    }

    private fun extractMediaFromNotification(pkg: String, notif: Notification) {
        try {
            val extras = notif.extras ?: return
            val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
            val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
            if (title.isEmpty() && text.isEmpty()) return

            val appName = resolveAppLabel(pkg)
            var coverBmp: Bitmap? = null
            val largeIcon = notif.getLargeIcon()
            if (largeIcon != null) {
                val d = largeIcon.loadDrawable(this)
                if (d != null) {
                    coverBmp = drawableToSmallBitmap(d)
                }
            }

            MediaStateBus.updateMetadata(
                title = title,
                artist = text,
                sourcePackage = pkg,
                sourceAppName = appName,
                cover = coverBmp
            )
        } catch (_: Exception) {
        }
    }

    private fun drawableToSmallBitmap(d: Drawable): Bitmap? {
        return try {
            if (d is BitmapDrawable && d.bitmap != null) {
                Bitmap.createScaledBitmap(d.bitmap, 96, 96, true)
            } else {
                val bmp = Bitmap.createBitmap(96, 96, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bmp)
                d.setBounds(0, 0, 96, 96)
                d.draw(canvas)
                bmp
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun resolveAppLabel(pkg: String): String {
        return try {
            val ai = packageManager.getApplicationInfo(pkg, 0)
            packageManager.getApplicationLabel(ai).toString()
        } catch (_: Exception) {
            pkg.substringAfterLast('.')
        }
    }

    private fun isKnownMediaApp(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("youtube") || p.contains("smarttube") || p.contains("spotify") ||
            p.contains("soundcloud") || p.contains("music") || p.contains("vlc") ||
            p.contains("kodi") || p.contains("lampa") || p.contains("kino") || p.contains("browser")
    }

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val keyCode = event.keyCode
        val scanCode = event.scanCode

        if (isNavigationOrCenterKey(keyCode)) {
            return false
        }

        // 1. В режиме обучения кнопки перехватываем любую нажатую кнопку пульта!
        if (KeyCaptureBus.isCapturingKey) {
            if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
                return false
            }
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                KeyCaptureBus.notifyKeyCaptured(keyCode, scanCode)
            }
            return true
        }

        val prefs = getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)

        // 2. Перехват верхней кнопки Ассистента (с цветными точками) под личного ИИ (или пользовательский бинд)!
        if (keyCode == KeyEvent.KEYCODE_VOICE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_SEARCH
        ) {
            val customAssistTarget = prefs.getString("key_bind_$keyCode", null) ?: "ACTION_AI"
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                executeBoundAction(customAssistTarget)
            }
            return true
        }

        // 3. Пресеты фирменных кнопок пульта Xiaomi
        val presetTarget = resolvePresetBinding(prefs, keyCode, scanCode)
        if (!presetTarget.isNullOrEmpty()) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                executeBoundAction(presetTarget)
            }
            return true
        }

        // 4. Индивидуально забинженные кнопки
        val boundTarget = prefs.getString("key_bind_$keyCode", null)
            ?: if (scanCode > 0) prefs.getString("scan_bind_$scanCode", null) else null

        if (boundTarget.isNullOrEmpty()) {
            return false
        }

        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            executeBoundAction(boundTarget)
        }
        return true
    }

    private fun resolvePresetBinding(
        prefs: android.content.SharedPreferences,
        keyCode: Int,
        scanCode: Int
    ): String? {
        if (keyCode == KeyEvent.KEYCODE_ALL_APPS ||
            keyCode == KeyEvent.KEYCODE_MENU ||
            keyCode == KeyEvent.KEYCODE_GUIDE ||
            keyCode == KeyEvent.KEYCODE_SETTINGS ||
            keyCode == KeyEvent.KEYCODE_TV_INPUT ||
            keyCode == KeyEvent.KEYCODE_BUTTON_1 ||
            scanCode == 139 || scanCode == 362 || scanCode == 172 || scanCode == 256
        ) {
            prefs.getString("preset_bind_PATCHWALL", null)?.let { if (it.isNotEmpty()) return it }
        }

        if (keyCode == KeyEvent.KEYCODE_BUTTON_2 ||
            keyCode == KeyEvent.KEYCODE_PROG_RED ||
            scanCode == 412 || scanCode == 398 || keyCode == 309
        ) {
            prefs.getString("preset_bind_NETFLIX", null)?.let { if (it.isNotEmpty()) return it }
        }

        if (keyCode == KeyEvent.KEYCODE_BUTTON_3 ||
            keyCode == KeyEvent.KEYCODE_PROG_BLUE ||
            scanCode == 413 || scanCode == 401 || keyCode == 310
        ) {
            prefs.getString("preset_bind_PRIME", null)?.let { if (it.isNotEmpty()) return it }
        }

        return null
    }

    private fun isNetflixPackage(pkg: String): Boolean = pkg.lowercase().contains("netflix")

    private fun isPrimePackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("amazonvideo") || p.contains("amazon.avod") || p.contains("primevideo")
    }

    private fun isPatchwallPackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("patchwall") || p.contains("mitv.tvhome") || p.contains("mitv.smartshare")
    }

    private fun isNavigationOrCenterKey(keyCode: Int): Boolean {
        return keyCode == KeyEvent.KEYCODE_DPAD_UP ||
            keyCode == KeyEvent.KEYCODE_DPAD_DOWN ||
            keyCode == KeyEvent.KEYCODE_DPAD_LEFT ||
            keyCode == KeyEvent.KEYCODE_DPAD_RIGHT ||
            keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
            keyCode == KeyEvent.KEYCODE_ENTER ||
            keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER ||
            keyCode == KeyEvent.KEYCODE_HOME
    }

    private fun executeBoundAction(target: String) {
        when (target) {
            "ACTION_ALL_APPS" -> {
                val intent = Intent(this, LauncherActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("EXTRA_OPEN_ALL_APPS", true)
                }
                startActivity(intent)
            }
            "ACTION_SETTINGS" -> {
                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    startActivity(intent)
                } catch (_: Exception) {
                }
            }
            "ACTION_AI" -> {
                val intent = Intent(this, LauncherActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("EXTRA_OPEN_AI", true)
                }
                startActivity(intent)
            }
            else -> {
                val pm = packageManager
                val launchIntent = pm.getLeanbackLaunchIntentForPackage(target)
                    ?: pm.getLaunchIntentForPackage(target)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        startActivity(launchIntent)
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }
}
