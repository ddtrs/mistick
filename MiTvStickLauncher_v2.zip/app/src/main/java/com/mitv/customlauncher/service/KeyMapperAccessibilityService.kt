package com.mitv.customlauncher.service

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.animation.ValueAnimator
import android.app.Notification
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaMetadata
import android.media.MediaRecorder
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Parcelable
import android.os.SystemClock
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.TextUtils
import android.util.LruCache
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import com.mitv.customlauncher.R
import com.mitv.customlauncher.data.GeminiCloudClient
import com.mitv.customlauncher.data.LauncherConfig
import com.mitv.customlauncher.data.LocalVoiceCommandRouter
import com.mitv.customlauncher.ui.LauncherActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sqrt

data class NowPlayingSnapshot(
    val hasActiveSession: Boolean = false,
    val isPlaying: Boolean = false,
    val title: String = "",
    val artist: String = "",
    val sourcePackage: String = "",
    val sourceAppName: String = "",
    val coverBitmap: Bitmap? = null,
    val durationMs: Long = 0L,
    val basePositionMs: Long = 0L,
    val baseElapsedRealtime: Long = 0L,
    val playbackSpeed: Float = 1.0f
)

object VolumeHudBus {
    @Volatile
    var onVolumeIntercepted: (() -> Unit)? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    fun notifyVolumeChanged() {
        val listener = onVolumeIntercepted ?: return
        mainHandler.post { listener.invoke() }
    }
}

object DynamicIslandBus {
    @Volatile
    var onTriggerIslandInService: (() -> Unit)? = null

    @Volatile
    var onRequestAudioPermissionInActivity: (() -> Unit)? = null

    @Volatile
    var onAccentColorUpdated: ((String) -> Unit)? = null

    @Volatile
    var onIslandVisibilityChanged: ((Boolean) -> Unit)? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    fun triggerAssistant(context: Context) {
        val serviceTrigger = onTriggerIslandInService
        if (serviceTrigger != null && KeyMapperAccessibilityService.isServiceConnectedAlive) {
            mainHandler.post { serviceTrigger.invoke() }
        } else {
            val intent = Intent(context, LauncherActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                putExtra("EXTRA_OPEN_AI", true)
            }
            try {
                context.startActivity(intent)
            } catch (_: Exception) {
            }
        }
    }

    fun notifyAccentColorChanged(hex: String) {
        mainHandler.post {
            onAccentColorUpdated?.invoke(hex)
        }
    }

    fun notifyIslandVisibility(visible: Boolean) {
        mainHandler.post {
            onIslandVisibilityChanged?.invoke(visible)
        }
    }
}

object ServiceAutoActivator {
    fun hasWriteSecureSettings(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            android.Manifest.permission.WRITE_SECURE_SETTINGS
        ) == PackageManager.PERMISSION_GRANTED
    }

    fun ensureNotificationListenerInSecureSettings(context: Context) {
        if (!hasWriteSecureSettings(context)) return
        try {
            val appCtx = context.applicationContext
            val pkg = appCtx.packageName
            val cr = appCtx.contentResolver
            val notifFlat = "$pkg/$pkg.service.MediaSessionListenerService"
            val notifShort = "$pkg/.service.MediaSessionListenerService"
            val curNotif = Settings.Secure.getString(cr, "enabled_notification_listeners").orEmpty()
            if (!curNotif.contains(notifFlat)) {
                val base = if (curNotif.isBlank()) "" else "$curNotif:"
                Settings.Secure.putString(cr, "enabled_notification_listeners", "$base$notifFlat:$notifShort")
            }
        } catch (_: Exception) {
        }
    }

    fun ensureServicesActive(context: Context) {
        val appCtx = context.applicationContext
        val pkg = appCtx.packageName
        val notifComp = ComponentName(appCtx, MediaSessionListenerService::class.java)

        try {
            val pm = appCtx.packageManager
            if (pm.getComponentEnabledSetting(notifComp) == PackageManager.COMPONENT_ENABLED_STATE_DISABLED) {
                pm.setComponentEnabledSetting(
                    notifComp,
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                    PackageManager.DONT_KILL_APP
                )
            }
        } catch (_: Exception) {
        }

        if (hasWriteSecureSettings(appCtx)) {
            val cr = appCtx.contentResolver
            val accFlat = "$pkg/$pkg.service.KeyMapperAccessibilityService"
            try {
                ensureNotificationListenerInSecureSettings(appCtx)

                val curAcc = Settings.Secure.getString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES).orEmpty()
                if (!curAcc.contains(pkg)) {
                    val updatedAcc = if (curAcc.isBlank()) accFlat else "$curAcc:$accFlat"
                    Settings.Secure.putString(cr, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, updatedAcc)
                    Settings.Secure.putInt(cr, Settings.Secure.ACCESSIBILITY_ENABLED, 1)
                }
            } catch (_: Exception) {
            }
        }

        if (MediaSessionListenerService.instance == null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try {
                NotificationListenerService.requestRebind(notifComp)
            } catch (_: Exception) {
            }
        }
    }
}

object MediaStateBus {
    private val _state = MutableStateFlow(NowPlayingSnapshot())
    val state: StateFlow<NowPlayingSnapshot> = _state.asStateFlow()

    @Volatile
    var activeController: MediaController? = null

    @Volatile
    var lastForegroundMediaPkg: String = ""

    private val mainHandler = Handler(Looper.getMainLooper())
    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val artUriCache = object : LruCache<String, Bitmap>(24) {}
    private var currentArtUri: String = ""
    private var lastFetchedArtUri: String = ""

    private var trackStartRealtime: Long = SystemClock.elapsedRealtime()
    private var lastPausedRealtime: Long = 0L
    private var lastLauncherPauseRealtime: Long = 0L
    private var currentTrackIdentity: String = ""
    private var currentCoverSignature: Int = 0
    private var currentControllerCallback: MediaController.Callback? = null
    private var sessionListenerRegistered = false

    private var lastObservedRawPos: Long = -1L
    private var lastObservedRawRealtime: Long = 0L

    private var dismissedTrackIdentity: String = ""
    private var dismissedAtRealtime: Long = 0L
    private var pausedByLauncherControl: Boolean = false

    fun isKnownMediaPackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("spotify") ||
            p.contains("mediashell") ||
            p.contains("chromecast") ||
            p.contains("soundcloud") ||
            p.contains("youtube") ||
            p.contains("music") ||
            p.contains("deezer") ||
            p.contains("tidal") ||
            p.contains("tunein") ||
            p.contains("vlc") ||
            p.contains("kodi")
    }

    fun onMediaAppOpened(pkg: String) {
        if (pkg.isBlank()) return
        if (isKnownMediaPackage(pkg)) {
            lastForegroundMediaPkg = pkg
            pausedByLauncherControl = false
            dismissedTrackIdentity = ""
            val ctrl = activeController
            if (ctrl != null && ctrl.packageName != pkg && !isActivelyPlayingState(ctrl.playbackState?.state)) {
                unregisterCurrentCallback()
                activeController = null
            }
        }
    }

    fun resolveActiveMediaPackage(context: Context): String {
        try {
            val mbr = Settings.Secure.getString(context.contentResolver, "media_button_receiver").orEmpty()
            if (mbr.contains("/")) {
                val mbrPkg = mbr.substringBefore("/").trim()
                if (mbrPkg.isNotEmpty() && mbrPkg != context.packageName) {
                    return mbrPkg
                }
            }
        } catch (_: Exception) {
        }
        if (lastForegroundMediaPkg.isNotEmpty()) {
            return lastForegroundMediaPkg
        }
        val curPkg = _state.value.sourcePackage
        if (curPkg.isNotEmpty()) {
            return curPkg
        }
        return ""
    }

    private fun normalizeArtUri(rawUri: String): String {
        val trimmed = rawUri.trim()
        if (trimmed.startsWith("spotify:image:")) {
            val imageId = trimmed.removePrefix("spotify:image:").trim()
            if (imageId.isNotEmpty()) {
                return "https://i.scdn.co/image/$imageId"
            }
        }
        return trimmed
    }

    fun computeBitmapSignature(bmp: Bitmap?): Int {
        if (bmp == null || bmp.isRecycled) return 0
        val w = bmp.width
        val h = bmp.height
        if (w <= 0 || h <= 0) return 0
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && bmp.config == Bitmap.Config.HARDWARE) {
            val gen = bmp.generationId
            val hash = ((w * 31) xor h) xor (gen * 31)
            return if (hash == 0) 1 else hash
        }
        return try {
            var hash = (w * 31) xor h
            hash = (hash * 31) xor bmp.getPixel(w / 2, h / 2)
            hash = (hash * 31) xor bmp.getPixel(w / 4, h / 4)
            hash = (hash * 31) xor bmp.getPixel((w * 3) / 4, h / 4)
            hash = (hash * 31) xor bmp.getPixel(w / 4, (h * 3) / 4)
            hash = (hash * 31) xor bmp.getPixel((w * 3) / 4, (h * 3) / 4)
            if (hash == 0) 1 else hash
        } catch (_: Exception) {
            val gen = bmp.generationId
            if (gen == 0) 1 else gen
        }
    }

    fun safeScaleBitmap(raw: Bitmap?): Bitmap? {
        if (raw == null || raw.isRecycled) return null
        return try {
            val src = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && raw.config == Bitmap.Config.HARDWARE) {
                raw.copy(Bitmap.Config.ARGB_8888, false) ?: raw
            } else {
                raw
            }
            val scaled = Bitmap.createScaledBitmap(src, 112, 112, true)
            if (src !== raw && src !== scaled && !src.isRecycled) {
                src.recycle()
            }
            scaled
        } catch (_: Exception) {
            raw
        }
    }

    fun getCurrentCoverSignature(): Int = currentCoverSignature

    private fun isActivelyPlayingState(stateCode: Int?): Boolean {
        return stateCode == PlaybackState.STATE_PLAYING ||
            stateCode == PlaybackState.STATE_BUFFERING ||
            stateCode == PlaybackState.STATE_CONNECTING ||
            stateCode == PlaybackState.STATE_FAST_FORWARDING ||
            stateCode == PlaybackState.STATE_REWINDING ||
            stateCode == PlaybackState.STATE_SKIPPING_TO_NEXT ||
            stateCode == PlaybackState.STATE_SKIPPING_TO_PREVIOUS
    }

    private fun unregisterCurrentCallback() {
        val prev = activeController
        val prevCb = currentControllerCallback
        if (prev != null && prevCb != null) {
            try {
                prev.unregisterCallback(prevCb)
            } catch (_: Exception) {
            }
        }
        currentControllerCallback = null
    }

    fun queryMediaSessionManagerDirect(context: Context) {
        try {
            val appCtx = context.applicationContext
            ServiceAutoActivator.ensureNotificationListenerInSecureSettings(appCtx)
            val msm = appCtx.getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager ?: return
            val comp = ComponentName(appCtx, MediaSessionListenerService::class.java)

            if (!sessionListenerRegistered) {
                try {
                    val sessionListener = MediaSessionManager.OnActiveSessionsChangedListener { list ->
                        selectAndBindBestController(appCtx, list)
                    }
                    msm.addOnActiveSessionsChangedListener(sessionListener, comp, mainHandler)
                    sessionListenerRegistered = true
                } catch (_: Exception) {
                }
            }

            val sessions = msm.getActiveSessions(comp)
            selectAndBindBestController(appCtx, sessions)
        } catch (_: Exception) {
        }
    }

    private fun selectAndBindBestController(context: Context, controllers: List<MediaController>?) {
        if (controllers.isNullOrEmpty()) return
        val others = controllers.filter { it.packageName != context.packageName }
        if (others.isEmpty()) return

        val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        val musicActive = am?.isMusicActive == true
        val activeMediaPkg = resolveActiveMediaPackage(context)

        val playing = others.firstOrNull {
            it.playbackState?.state == PlaybackState.STATE_PLAYING && it.packageName == activeMediaPkg
        } ?: others.firstOrNull {
            it.playbackState?.state == PlaybackState.STATE_PLAYING
        } ?: others.firstOrNull {
            isActivelyPlayingState(it.playbackState?.state)
        }

        if (playing != null) {
            bindController(context, playing)
            return
        }

        if (musicActive) {
            val byActivePkg = if (activeMediaPkg.isNotEmpty()) {
                others.firstOrNull { it.packageName == activeMediaPkg }
            } else null

            val bySpotify = others.firstOrNull {
                it.packageName.lowercase().contains("spotify") && (it.metadata != null || it.playbackState != null)
            } ?: others.firstOrNull {
                it.packageName.lowercase().contains("spotify")
            }

            val byMetadata = others.firstOrNull { it.metadata != null } ?: others.firstOrNull()
            val candidate = byActivePkg ?: bySpotify ?: byMetadata
            if (candidate != null) {
                bindController(context, candidate)
                return
            }
        }

        val cur = _state.value
        if (cur.hasActiveSession && cur.sourcePackage.isNotEmpty()) {
            val matching = others.firstOrNull { it.packageName == cur.sourcePackage }
            if (matching != null) {
                bindController(context, matching)
            }
        }
    }

    fun bindController(context: Context, controller: MediaController) {
        val appCtx = context.applicationContext
        val prev = activeController
        if (prev != null && prev.sessionToken == controller.sessionToken) {
            syncControllerImmediate(appCtx, prev)
            return
        }
        unregisterCurrentCallback()
        activeController = controller

        val cb = object : MediaController.Callback() {
            override fun onPlaybackStateChanged(state: PlaybackState?) {
                if (state != null) {
                    val am = appCtx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                    val musicActive = am?.isMusicActive == true
                    val playing = isActivelyPlayingState(state.state) || (musicActive && !pausedByLauncherControl)
                    if (playing) pausedByLauncherControl = false
                    updatePositionOnly(
                        positionMs = state.position,
                        positionUpdateRealtime = state.lastPositionUpdateTime,
                        speed = state.playbackSpeed,
                        isPlaying = playing
                    )
                }
            }

            override fun onMetadataChanged(metadata: MediaMetadata?) {
                syncControllerImmediate(appCtx, controller)
            }
        }
        currentControllerCallback = cb
        try {
            controller.registerCallback(cb, mainHandler)
        } catch (_: Exception) {
        }

        syncControllerImmediate(appCtx, controller)
    }

    fun syncControllerImmediate(context: Context, controller: MediaController) {
        try {
            val meta = controller.metadata
            val pb = controller.playbackState
            val cur = _state.value
            val pkg = controller.packageName.orEmpty().ifEmpty { cur.sourcePackage }

            val am = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            val musicActive = am?.isMusicActive == true
            val pbPlaying = isActivelyPlayingState(pb?.state)
            val now = SystemClock.elapsedRealtime()

            if (musicActive && pausedByLauncherControl && (now - lastLauncherPauseRealtime) > 2500L) {
                pausedByLauncherControl = false
                dismissedTrackIdentity = ""
            }

            if (!pbPlaying && musicActive) {
                val activePkg = resolveActiveMediaPackage(context)
                if (activePkg.isNotEmpty() && pkg.isNotEmpty() && activePkg != pkg) {
                    if (activeController === controller) {
                        unregisterCurrentCallback()
                        activeController = null
                    }
                    return
                }
            }

            val effectivePlaying = pbPlaying || (musicActive && !pausedByLauncherControl)

            if (!cur.hasActiveSession && !effectivePlaying) {
                return
            }

            val appName = resolveAppLabel(context, pkg)
            var title = ""
            var artist = ""
            var dur = -1L
            var artUri = ""
            var newCover: Bitmap? = null
            var newSig = 0

            if (meta != null) {
                val desc = meta.description
                title = (meta.getString(MediaMetadata.METADATA_KEY_TITLE)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
                    ?: desc?.title?.toString()).orEmpty().trim()
                artist = (meta.getString(MediaMetadata.METADATA_KEY_ARTIST)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_AUTHOR)
                    ?: desc?.subtitle?.toString()).orEmpty().trim()
                val d = meta.getLong(MediaMetadata.METADATA_KEY_DURATION)
                if (d > 0L) dur = d

                val rawUriStr = (meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_ART_URI)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)
                    ?: desc?.iconUri?.toString()).orEmpty()
                artUri = normalizeArtUri(rawUriStr)

                val rawArt = meta.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                    ?: meta.getBitmap(MediaMetadata.METADATA_KEY_ART)
                    ?: meta.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                    ?: desc?.iconBitmap
                if (rawArt != null) {
                    val sig = computeBitmapSignature(rawArt)
                    if (sig != 0 && (sig != currentCoverSignature || cur.coverBitmap == null)) {
                        newCover = safeScaleBitmap(rawArt)
                        newSig = sig
                    }
                }
            }

            var pos = -1L
            var posTime = 0L
            var spd = 1.0f
            if (pb != null) {
                pos = pb.position
                posTime = pb.lastPositionUpdateTime
                spd = pb.playbackSpeed
            }
            updatePlayingFlag(effectivePlaying)

            if (title.isNotEmpty() || artist.isNotEmpty() || newCover != null || artUri.isNotEmpty() || pos >= 0L || dur > 0L || effectivePlaying) {
                updateMetadata(
                    context = context,
                    title = title,
                    artist = artist,
                    sourcePackage = pkg,
                    sourceAppName = appName,
                    cover = newCover,
                    coverSignature = newSig,
                    artUri = artUri,
                    durationMs = dur,
                    positionMs = pos,
                    positionUpdateRealtime = posTime,
                    speed = spd
                )
            }
        } catch (_: Exception) {
        }
    }

    fun ingestNotification(
        context: Context,
        pkg: String,
        notif: Notification,
        requireActivePlaybackOrSession: Boolean = false
    ) {
        try {
            val appCtx = context.applicationContext
            val p = pkg.lowercase()
            if (pkg == appCtx.packageName ||
                p.startsWith("com.android.packageinstaller") ||
                p.startsWith("com.google.android.packageinstaller") ||
                p.startsWith("com.android.vending") ||
                p.startsWith("com.android.systemui") ||
                p.startsWith("com.android.settings")
            ) {
                return
            }

            val extras = notif.extras ?: return
            @Suppress("DEPRECATION")
            val sessionToken = (extras.getParcelable<Parcelable>(Notification.EXTRA_MEDIA_SESSION) as? MediaSession.Token)
                ?: (extras.getParcelable<Parcelable>("android.support.v4.media.session.EXTRA_SESSION_TOKEN") as? MediaSession.Token)

            val isKnownMedia = isKnownMediaPackage(p) || notif.category == Notification.CATEGORY_TRANSPORT
            if (sessionToken == null && !isKnownMedia) {
                return
            }

            if (isKnownMediaPackage(p)) {
                lastForegroundMediaPkg = pkg
            }

            if (sessionToken != null) {
                val curCtrl = activeController
                if (curCtrl == null || curCtrl.sessionToken != sessionToken) {
                    bindController(appCtx, MediaController(appCtx, sessionToken))
                }
            }

            val ctrl = activeController?.takeIf { it.packageName == pkg || sessionToken != null }
            val pb = ctrl?.playbackState
            val am = appCtx.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
            val isMusicCurrentlyActive = am?.isMusicActive == true
            val isCtrlPlaying = isActivelyPlayingState(pb?.state)
            val effectivePlaying = isCtrlPlaying || (isMusicCurrentlyActive && !pausedByLauncherControl)

            if (requireActivePlaybackOrSession && !_state.value.hasActiveSession && !effectivePlaying) {
                return
            }

            var notifTitle = (extras.getCharSequence(Notification.EXTRA_TITLE)
                ?: extras.getCharSequence(Notification.EXTRA_TITLE_BIG))?.toString()?.trim().orEmpty()
            var notifArtist = (extras.getCharSequence(Notification.EXTRA_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_SUB_TEXT)
                ?: extras.getCharSequence(Notification.EXTRA_SUMMARY_TEXT))?.toString()?.trim().orEmpty()
            val appName = resolveAppLabel(appCtx, pkg)

            var durationMs = -1L
            var posMs = -1L
            var posRealtime = 0L
            var speed = 1.0f
            var artUri = ""
            var metaRawArt: Bitmap? = null

            if (ctrl != null) {
                val meta = ctrl.metadata
                if (meta != null) {
                    val desc = meta.description
                    val metaTitle = (meta.getString(MediaMetadata.METADATA_KEY_TITLE)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
                        ?: desc?.title?.toString())?.trim()
                    val metaArtist = (meta.getString(MediaMetadata.METADATA_KEY_ARTIST)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
                        ?: desc?.subtitle?.toString())?.trim()

                    if (notifTitle.isBlank() && !metaTitle.isNullOrBlank()) notifTitle = metaTitle
                    if (notifArtist.isBlank() && !metaArtist.isNullOrBlank()) notifArtist = metaArtist

                    val d = meta.getLong(MediaMetadata.METADATA_KEY_DURATION)
                    if (d > 0L) durationMs = d

                    val rawUriStr = (meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_ART_URI)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)
                        ?: desc?.iconUri?.toString()).orEmpty()
                    artUri = normalizeArtUri(rawUriStr)

                    metaRawArt = meta.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                        ?: meta.getBitmap(MediaMetadata.METADATA_KEY_ART)
                        ?: meta.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                        ?: desc?.iconBitmap
                }

                if (pb != null) {
                    posMs = pb.position
                    posRealtime = pb.lastPositionUpdateTime
                    speed = pb.playbackSpeed
                }
                updatePlayingFlag(effectivePlaying)
            } else if (isMusicCurrentlyActive) {
                updatePlayingFlag(true)
            }

            if (durationMs <= 0L) {
                val progMax = extras.getInt(Notification.EXTRA_PROGRESS_MAX, 0)
                if (progMax > 1000) {
                    durationMs = progMax.toLong()
                    val progCur = extras.getInt(Notification.EXTRA_PROGRESS, -1)
                    if (posMs < 0L && progCur >= 0) {
                        posMs = progCur.toLong()
                    }
                }
            }

            @Suppress("DEPRECATION")
            var rawCandidate: Bitmap? = (extras.getParcelable<Parcelable>(Notification.EXTRA_LARGE_ICON_BIG) as? Bitmap)
                ?: (extras.getParcelable<Parcelable>(Notification.EXTRA_LARGE_ICON) as? Bitmap)
                ?: (extras.getParcelable<Parcelable>(Notification.EXTRA_PICTURE) as? Bitmap)

            if (rawCandidate == null) {
                val largeIcon = notif.getLargeIcon()
                if (largeIcon != null) {
                    val d = largeIcon.loadDrawable(appCtx)
                    if (d is BitmapDrawable && d.bitmap != null) {
                        rawCandidate = d.bitmap
                    } else if (d != null) {
                        rawCandidate = drawableToSmallBitmap(d)
                    }
                }
            }

            if (rawCandidate == null) {
                rawCandidate = metaRawArt
            }

            var coverBmp: Bitmap? = null
            var sig = 0
            if (rawCandidate != null) {
                sig = computeBitmapSignature(rawCandidate)
                val curCover = _state.value.coverBitmap
                if (sig != 0 && sig == currentCoverSignature && curCover != null) {
                    coverBmp = curCover
                } else {
                    coverBmp = safeScaleBitmap(rawCandidate)
                }
            }

            if (notifTitle.isEmpty() && notifArtist.isEmpty() && coverBmp == null && artUri.isEmpty()) return

            updateMetadata(
                context = appCtx,
                title = notifTitle,
                artist = notifArtist,
                sourcePackage = pkg,
                sourceAppName = appName,
                cover = coverBmp,
                coverSignature = sig,
                artUri = artUri,
                durationMs = durationMs,
                positionMs = posMs,
                positionUpdateRealtime = posRealtime,
                speed = speed
            )
        } catch (_: Exception) {
        }
    }

    private fun drawableToSmallBitmap(d: Drawable): Bitmap? {
        return try {
            if (d is BitmapDrawable && d.bitmap != null) {
                safeScaleBitmap(d.bitmap)
            } else {
                val bmp = Bitmap.createBitmap(112, 112, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bmp)
                d.setBounds(0, 0, 112, 112)
                d.draw(canvas)
                bmp
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun resolveAppLabel(context: Context, pkg: String): String {
        if (pkg.isBlank()) return ""
        return try {
            val ai = context.packageManager.getApplicationInfo(pkg, 0)
            context.packageManager.getApplicationLabel(ai).toString()
        } catch (_: Exception) {
            when {
                pkg.lowercase().contains("spotify") -> "Spotify"
                pkg.lowercase().contains("mediashell") -> "Chromecast"
                pkg.lowercase().contains("soundcloud") -> "SoundCloud"
                pkg.lowercase().contains("youtube") -> "YouTube"
                else -> pkg.substringAfterLast('.')
            }
        }
    }

    fun dismissPlayerByUser(audioManager: AudioManager) {
        val cur = _state.value
        val now = SystemClock.elapsedRealtime()
        dismissedTrackIdentity = currentTrackIdentity.ifEmpty { "DISMISSED_SESSION" }
        dismissedAtRealtime = now
        lastLauncherPauseRealtime = now
        pausedByLauncherControl = true

        try {
            val ctrl = activeController
            if (ctrl != null && (isActivelyPlayingState(ctrl.playbackState?.state) || cur.isPlaying)) {
                ctrl.transportControls.pause()
            } else if (cur.isPlaying) {
                val upNow = SystemClock.uptimeMillis()
                audioManager.dispatchMediaKeyEvent(KeyEvent(upNow, upNow, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PAUSE, 0))
                audioManager.dispatchMediaKeyEvent(KeyEvent(upNow, upNow, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PAUSE, 0))
            }
        } catch (_: Exception) {
        }

        _state.value = NowPlayingSnapshot(
            hasActiveSession = false,
            isPlaying = false
        )
    }

    fun onContinuousBackgroundMusicDetected(context: Context? = null) {
        val now = SystemClock.elapsedRealtime()
        if (pausedByLauncherControl) {
            if ((now - lastLauncherPauseRealtime) > 2500L) {
                pausedByLauncherControl = false
                dismissedTrackIdentity = ""
            } else {
                return
            }
        }
        if (dismissedTrackIdentity.isNotEmpty() && (now - dismissedAtRealtime) < 3000L) return

        val cur = _state.value
        if (context != null) {
            val activePkg = resolveActiveMediaPackage(context)
            if (activePkg.isNotEmpty() && activePkg != cur.sourcePackage) {
                val ctrl = activeController
                if (ctrl != null && ctrl.packageName != activePkg && !isActivelyPlayingState(ctrl.playbackState?.state)) {
                    unregisterCurrentCallback()
                    activeController = null
                }
                val label = resolveAppLabel(context, activePkg)
                trackStartRealtime = now
                currentTrackIdentity = "$activePkg|${cur.title}"
                _state.value = cur.copy(
                    hasActiveSession = true,
                    isPlaying = true,
                    sourcePackage = activePkg,
                    sourceAppName = label,
                    artist = cur.artist.ifEmpty { label },
                    baseElapsedRealtime = now
                )
                queryMediaSessionManagerDirect(context)
                return
            }
        }

        if (!cur.hasActiveSession || !cur.isPlaying) {
            if (context != null && cur.sourcePackage.isEmpty()) {
                val activePkg = resolveActiveMediaPackage(context)
                if (activePkg.isNotEmpty()) {
                    val label = resolveAppLabel(context, activePkg)
                    _state.value = cur.copy(
                        hasActiveSession = true,
                        isPlaying = true,
                        sourcePackage = activePkg,
                        sourceAppName = label,
                        artist = cur.artist.ifEmpty { label },
                        baseElapsedRealtime = now
                    )
                    return
                }
            }
            updatePlayingFlag(true)
        }
    }

    private fun resolveRealtimeDeltaMs(reportedUpdateTime: Long, nowElapsed: Long): Long {
        if (reportedUpdateTime <= 0L) return -1L
        if (reportedUpdateTime in 1L..(nowElapsed + 2000L) && (nowElapsed - reportedUpdateTime) in 0L..14_400_000L) {
            return (nowElapsed - reportedUpdateTime).coerceAtLeast(0L)
        }
        val nowWall = System.currentTimeMillis()
        if (reportedUpdateTime in (nowWall - 14_400_000L)..(nowWall + 2000L)) {
            return (nowWall - reportedUpdateTime).coerceAtLeast(0L)
        }
        return -1L
    }

    fun updateMetadata(
        context: Context? = null,
        title: String,
        artist: String,
        sourcePackage: String,
        sourceAppName: String,
        cover: Bitmap?,
        coverSignature: Int = 0,
        artUri: String = "",
        durationMs: Long = -1L,
        positionMs: Long = -1L,
        positionUpdateRealtime: Long = 0L,
        speed: Float = 1.0f
    ) {
        val current = _state.value
        val now = SystemClock.elapsedRealtime()
        val resolvedPkg = if (sourcePackage.isNotBlank()) sourcePackage else current.sourcePackage
        val pkgChanged = resolvedPkg.isNotBlank() && current.sourcePackage.isNotBlank() && resolvedPkg != current.sourcePackage
        val resolvedTitle = if (title.isNotBlank()) title else if (!pkgChanged) current.title else ""
        val resolvedArtist = if (artist.isNotBlank()) artist else if (!pkgChanged) current.artist else ""
        val resolvedAppName = if (sourceAppName.isNotBlank()) sourceAppName else if (!pkgChanged) current.sourceAppName else ""

        val newIdentity = "$resolvedPkg|$resolvedTitle"
        if (dismissedTrackIdentity.isNotEmpty()) {
            if ((now - dismissedAtRealtime) < 2500L) return
            if (newIdentity == dismissedTrackIdentity && !current.isPlaying) return
            if (newIdentity != dismissedTrackIdentity) {
                dismissedTrackIdentity = ""
                pausedByLauncherControl = false
            }
        }

        val trackChanged = (resolvedTitle.isNotBlank() && newIdentity != currentTrackIdentity) || pkgChanged
        if (trackChanged) {
            currentTrackIdentity = newIdentity
            trackStartRealtime = now
            lastObservedRawPos = -1L
            lastObservedRawRealtime = 0L
            pausedByLauncherControl = false
        }

        val posActuallyChanged = positionMs >= 0L && positionMs != lastObservedRawPos
        if (posActuallyChanged) {
            lastObservedRawPos = positionMs
            lastObservedRawRealtime = now
        }

        var resolvedCover: Bitmap? = when {
            cover != null -> {
                val incomingSig = if (coverSignature != 0) coverSignature else computeBitmapSignature(cover)
                if (trackChanged && incomingSig != 0 && incomingSig == currentCoverSignature && artUri.isNotBlank() && artUri != currentArtUri) {
                    null
                } else {
                    currentCoverSignature = incomingSig
                    cover
                }
            }
            !trackChanged && !pkgChanged -> current.coverBitmap
            else -> {
                currentCoverSignature = 0
                null
            }
        }

        val normalizedUri = normalizeArtUri(artUri)
        if (normalizedUri.isNotBlank() && (resolvedCover == null || normalizedUri != currentArtUri)) {
            currentArtUri = normalizedUri
            val cached = artUriCache.get(normalizedUri)
            if (cached != null) {
                resolvedCover = cached
                currentCoverSignature = computeBitmapSignature(cached)
            } else if (normalizedUri != lastFetchedArtUri) {
                lastFetchedArtUri = normalizedUri
                fetchArtFromUriAsync(context, normalizedUri, newIdentity)
            }
        }

        val resolvedDuration = if (durationMs > 0L) durationMs else if (trackChanged) 0L else current.durationMs
        val deltaFromReport = resolveRealtimeDeltaMs(positionUpdateRealtime, now)

        val resolvedPos = when {
            positionMs > 0L -> if (resolvedDuration > 0L) positionMs.coerceAtMost(resolvedDuration) else positionMs
            trackChanged -> 0L
            positionMs == 0L && deltaFromReport >= 0L -> 0L
            else -> current.basePositionMs
        }
        val resolvedRealtime = when {
            deltaFromReport >= 0L -> (now - deltaFromReport).coerceAtLeast(1L)
            posActuallyChanged && positionMs > 0L -> now
            trackChanged -> now
            current.baseElapsedRealtime > 0L -> current.baseElapsedRealtime
            else -> trackStartRealtime
        }

        val hasSession = current.hasActiveSession ||
            resolvedTitle.isNotBlank() ||
            resolvedArtist.isNotBlank() ||
            resolvedCover != null ||
            current.isPlaying
        val playingNow = if (trackChanged) true else current.isPlaying

        _state.value = current.copy(
            hasActiveSession = hasSession,
            isPlaying = playingNow,
            title = resolvedTitle,
            artist = resolvedArtist,
            sourcePackage = resolvedPkg,
            sourceAppName = resolvedAppName,
            coverBitmap = resolvedCover,
            durationMs = resolvedDuration,
            basePositionMs = resolvedPos,
            baseElapsedRealtime = resolvedRealtime,
            playbackSpeed = if (speed > 0f) speed else 1.0f
        )
    }

    fun updatePositionOnly(positionMs: Long, positionUpdateRealtime: Long, speed: Float, isPlaying: Boolean) {
        val cur = _state.value
        val now = SystemClock.elapsedRealtime()
        if (dismissedTrackIdentity.isNotEmpty() && (now - dismissedAtRealtime) < 2500L && !isPlaying) return
        if (isPlaying) {
            dismissedTrackIdentity = ""
            pausedByLauncherControl = false
            lastPausedRealtime = 0L
        } else if (cur.isPlaying) {
            lastPausedRealtime = now
        }
        val posActuallyChanged = positionMs >= 0L && positionMs != lastObservedRawPos
        if (posActuallyChanged) {
            lastObservedRawPos = positionMs
            lastObservedRawRealtime = now
        }
        val deltaFromReport = resolveRealtimeDeltaMs(positionUpdateRealtime, now)
        val validPos = if (positionMs > 0L || (positionMs == 0L && deltaFromReport >= 0L)) {
            if (cur.durationMs > 0L) positionMs.coerceAtMost(cur.durationMs) else positionMs
        } else {
            cur.basePositionMs
        }
        val validRealtime = when {
            deltaFromReport >= 0L -> (now - deltaFromReport).coerceAtLeast(1L)
            posActuallyChanged && positionMs > 0L -> now
            cur.baseElapsedRealtime > 0L -> cur.baseElapsedRealtime
            else -> trackStartRealtime
        }
        _state.value = cur.copy(
            hasActiveSession = cur.hasActiveSession || isPlaying,
            isPlaying = isPlaying,
            basePositionMs = validPos,
            baseElapsedRealtime = validRealtime,
            playbackSpeed = if (speed > 0f) speed else 1.0f
        )
    }

    private fun fetchArtFromUriAsync(context: Context?, uriString: String, expectedIdentity: String) {
        val appCtx = context?.applicationContext
        val normalized = normalizeArtUri(uriString)
        ioScope.launch {
            try {
                val raw: Bitmap? = when {
                    normalized.startsWith("http://") || normalized.startsWith("https://") -> {
                        val conn = (URL(normalized).openConnection() as HttpURLConnection).apply {
                            connectTimeout = 3500
                            readTimeout = 3500
                            doInput = true
                        }
                        conn.connect()
                        val decoded = conn.inputStream.use { BitmapFactory.decodeStream(it) }
                        conn.disconnect()
                        decoded
                    }
                    (normalized.startsWith("content://") || normalized.startsWith("android.resource://") || normalized.startsWith("file://")) && appCtx != null -> {
                        appCtx.contentResolver.openInputStream(Uri.parse(normalized))?.use {
                            BitmapFactory.decodeStream(it)
                        }
                    }
                    else -> null
                }

                if (raw != null) {
                    val scaled = safeScaleBitmap(raw)
                    if (scaled != null && scaled !== raw && !raw.isRecycled) raw.recycle()
                    if (scaled != null) {
                        artUriCache.put(normalized, scaled)
                        if (currentTrackIdentity == expectedIdentity || _state.value.coverBitmap == null || currentArtUri == normalized) {
                            currentCoverSignature = computeBitmapSignature(scaled)
                            _state.value = _state.value.copy(coverBitmap = scaled)
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    fun updatePlayingFlag(isPlaying: Boolean) {
        val cur = _state.value
        val now = SystemClock.elapsedRealtime()
        if (isPlaying) {
            if (dismissedTrackIdentity.isNotEmpty() && (now - dismissedAtRealtime) < 2500L) return
            dismissedTrackIdentity = ""
            pausedByLauncherControl = false
            lastPausedRealtime = 0L
            if (!cur.isPlaying && cur.basePositionMs == 0L) {
                trackStartRealtime = now
            }
            if (!cur.isPlaying || !cur.hasActiveSession) {
                _state.value = cur.copy(
                    hasActiveSession = true,
                    isPlaying = true,
                    baseElapsedRealtime = if (cur.baseElapsedRealtime > 0L) cur.baseElapsedRealtime else now
                )
            }
        } else {
            if (cur.isPlaying) {
                val (frozenPos, _) = getLivePositionAndDuration()
                lastPausedRealtime = now
                _state.value = cur.copy(
                    isPlaying = false,
                    basePositionMs = frozenPos,
                    baseElapsedRealtime = now
                )
            } else if (cur.hasActiveSession && lastPausedRealtime > 0L && (now - lastPausedRealtime) > 20 * 60 * 1000L) {
                _state.value = cur.copy(hasActiveSession = false)
            }
        }
    }

    fun pollActiveControllerLight(context: Context? = null) {
        if (context != null) {
            queryMediaSessionManagerDirect(context)
            MediaSessionListenerService.instance?.pollActiveMediaNotifications(context)
        }
        val ctrl = activeController ?: return
        if (context != null) {
            syncControllerImmediate(context, ctrl)
        }
    }

    fun getLivePositionAndDuration(): Pair<Long, Long> {
        val ctrl = activeController
        val snap = _state.value
        val now = SystemClock.elapsedRealtime()

        var dur = snap.durationMs.coerceAtLeast(0L)
        if (ctrl != null) {
            try {
                val metaDur = ctrl.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
                if (metaDur > 0L) dur = metaDur
            } catch (_: Exception) {
            }
        }

        if (!snap.isPlaying) {
            val frozen = if (dur > 0L) snap.basePositionMs.coerceIn(0L, dur) else snap.basePositionMs.coerceAtLeast(0L)
            return frozen to dur
        }

        if (ctrl != null) {
            try {
                val pb = ctrl.playbackState
                if (pb != null && pb.position >= 0L) {
                    val speed = if (pb.playbackSpeed > 0f) pb.playbackSpeed else 1.0f
                    val deltaReport = resolveRealtimeDeltaMs(pb.lastPositionUpdateTime, now)
                    if (pb.position > 0L || (pb.position == 0L && isActivelyPlayingState(pb.state) && deltaReport >= 0L)) {
                        var pos = pb.position
                        val delta = when {
                            deltaReport >= 0L -> deltaReport
                            lastObservedRawRealtime in 1L..now -> (now - lastObservedRawRealtime).coerceAtLeast(0L)
                            else -> 0L
                        }
                        pos += (delta * speed).toLong().coerceAtLeast(0L)
                        if (dur > 0L) pos = pos.coerceAtMost(dur)
                        return pos.coerceAtLeast(0L) to dur
                    }
                }
            } catch (_: Exception) {
            }
        }

        if (snap.basePositionMs > 0L && snap.baseElapsedRealtime > 0L) {
            val delta = (now - snap.baseElapsedRealtime).coerceAtLeast(0L)
            var pos = snap.basePositionMs + (delta * snap.playbackSpeed).toLong().coerceAtLeast(0L)
            if (dur > 0L) pos = pos.coerceAtMost(dur)
            return pos to dur
        }

        var elapsed = (now - trackStartRealtime).coerceAtLeast(0L)
        if (dur > 0L) elapsed = elapsed.coerceAtMost(dur)
        return elapsed to dur
    }

    fun dispatchTransportAction(action: String, audioManager: AudioManager) {
        val ctrl = activeController
        val now = SystemClock.elapsedRealtime()
        try {
            if (ctrl != null) {
                val tc = ctrl.transportControls
                val pbState = ctrl.playbackState?.state
                when (action) {
                    "PREV" -> {
                        pausedByLauncherControl = false
                        tc.skipToPrevious()
                        return
                    }
                    "NEXT" -> {
                        pausedByLauncherControl = false
                        tc.skipToNext()
                        return
                    }
                    "PLAY_PAUSE" -> {
                        if (isActivelyPlayingState(pbState) || _state.value.isPlaying) {
                            pausedByLauncherControl = true
                            lastLauncherPauseRealtime = now
                            tc.pause()
                            updatePlayingFlag(false)
                        } else {
                            pausedByLauncherControl = false
                            dismissedTrackIdentity = ""
                            tc.play()
                            updatePlayingFlag(true)
                        }
                        return
                    }
                }
            }
        } catch (_: Exception) {
        }

        val keyCode = when (action) {
            "PREV" -> {
                pausedByLauncherControl = false
                KeyEvent.KEYCODE_MEDIA_PREVIOUS
            }
            "NEXT" -> {
                pausedByLauncherControl = false
                KeyEvent.KEYCODE_MEDIA_NEXT
            }
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        try {
            val upNow = SystemClock.uptimeMillis()
            audioManager.dispatchMediaKeyEvent(KeyEvent(upNow, upNow, KeyEvent.ACTION_DOWN, keyCode, 0))
            audioManager.dispatchMediaKeyEvent(KeyEvent(upNow, upNow, KeyEvent.ACTION_UP, keyCode, 0))
            if (action == "PLAY_PAUSE") {
                val targetPlay = !_state.value.isPlaying
                pausedByLauncherControl = !targetPlay
                if (!targetPlay) lastLauncherPauseRealtime = now
                if (targetPlay) dismissedTrackIdentity = ""
                updatePlayingFlag(targetPlay)
            }
        } catch (_: Exception) {
        }
    }
}

object KeyCaptureBus {
    @Volatile
    var isCapturingKey: Boolean = false

    @Volatile
    var onKeyCapturedListener: ((keyCode: Int, scanCode: Int) -> Unit)? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    fun notifyKeyCaptured(keyCode: Int, scanCode: Int): Boolean {
        val listener = onKeyCapturedListener ?: return false
        isCapturingKey = false
        mainHandler.post {
            listener.invoke(keyCode, scanCode)
        }
        return true
    }
}

class MediaSessionListenerService : NotificationListenerService() {

    companion object {
        @Volatile
        var instance: MediaSessionListenerService? = null
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        pollActiveMediaNotifications(this)
        MediaStateBus.queryMediaSessionManagerDirect(this)
    }

    override fun onListenerDisconnected() {
        instance = null
        super.onListenerDisconnected()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try {
                requestRebind(ComponentName(this, MediaSessionListenerService::class.java))
            } catch (_: Exception) {
            }
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        instance = this
        if (sbn == null) return
        val pkg = sbn.packageName ?: return
        if (pkg == packageName) return
        val notif = sbn.notification ?: return
        MediaStateBus.ingestNotification(this, pkg, notif, requireActivePlaybackOrSession = false)
    }

    fun pollActiveMediaNotifications(context: Context) {
        try {
            val list = activeNotifications ?: return
            for (sbn in list) {
                val pkg = sbn.packageName ?: continue
                if (pkg == context.packageName) continue
                val notif = sbn.notification ?: continue
                MediaStateBus.ingestNotification(context, pkg, notif, requireActivePlaybackOrSession = true)
            }
        } catch (_: Exception) {
        }
    }
}

class KeyMapperAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var isServiceConnectedAlive: Boolean = false
    }

    private var lastInterceptMillis: Long = 0L
    private val uiHandler = Handler(Looper.getMainLooper())
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val decelerateInterpolator = DecelerateInterpolator()

    private var windowManager: WindowManager? = null
    private var overlayHudRoot: LinearLayout? = null
    private var overlayHudIcon: ImageView? = null
    private var overlayHudTrack: FrameLayout? = null
    private var overlayHudFill: View? = null
    private var overlayHudPct: TextView? = null
    private var lastKnownVolumePct: Int = -1
    private var receiversRegistered: Boolean = false

    private var islandLayoutParams: WindowManager.LayoutParams? = null
    private var islandRoot: LinearLayout? = null
    private var islandHeaderRow: LinearLayout? = null
    private var islandSparkIcon: ImageView? = null
    private var islandWaveContainer: LinearLayout? = null
    private val islandWaveBars = mutableListOf<View>()
    private var islandStatusText: TextView? = null
    private var islandHintText: TextView? = null
    private var islandBodyText: TextView? = null
    private var islandMorphAnimator: ValueAnimator? = null
    private var islandVisible: Boolean = false
    private var islandIsListening: Boolean = false

    private var speechRecognizer: SpeechRecognizer? = null
    private var audioRecordJob: Job? = null
    private var geminiQueryJob: Job? = null
    private var lastPartialTranscript: String = ""

    private val hideOverlayRunnable = Runnable {
        val root = overlayHudRoot ?: return@Runnable
        root.animate()
            .alpha(0f)
            .setDuration(180L)
            .withEndAction { root.visibility = View.GONE }
            .start()
    }

    private val hideIslandRunnable = Runnable {
        collapseDynamicIsland()
    }

    private val pulseWaveRunnable = object : Runnable {
        private var tick = 0
        override fun run() {
            if (!islandVisible) return
            tick++
            if (islandWaveContainer?.visibility == View.VISIBLE) {
                val baseHeights = intArrayOf(8, 16, 12, 18)
                for (i in islandWaveBars.indices) {
                    val bar = islandWaveBars[i]
                    val phase = (tick + i * 2) % 6
                    val hDp = if (islandIsListening) {
                        baseHeights[i % baseHeights.size] + (if (phase < 3) phase * 3 else (6 - phase) * 3)
                    } else {
                        6 + ((tick + i) % 3) * 4
                    }
                    val lp = bar.layoutParams
                    lp.height = dpPx(hDp.toFloat())
                    bar.layoutParams = lp
                }
                uiHandler.postDelayed(this, 90L)
            }
        }
    }

    private val globalMediaAndVolumeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val act = intent?.action ?: return
            if (act == "android.media.VOLUME_CHANGED_ACTION") {
                val streamType = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1)
                if (streamType == AudioManager.STREAM_MUSIC || streamType == -1) {
                    val pct = computeCurrentMusicVolumePct()
                    if (lastKnownVolumePct != -1 && pct != lastKnownVolumePct) {
                        lastKnownVolumePct = pct
                        showGlobalVolumeOverlay()
                        VolumeHudBus.notifyVolumeChanged()
                    } else if (lastKnownVolumePct == -1) {
                        lastKnownVolumePct = pct
                    }
                }
                return
            }

            if (intent.hasExtra("playing")) {
                MediaStateBus.updatePlayingFlag(intent.getBooleanExtra("playing", false))
            } else if (intent.hasExtra("playstate")) {
                MediaStateBus.updatePlayingFlag(intent.getBooleanExtra("playstate", false))
            }
            val track = intent.getStringExtra("track")
                ?: intent.getStringExtra("title")
                ?: intent.getStringExtra("android.intent.extra.TITLE")
                ?: ""
            val artist = intent.getStringExtra("artist")
                ?: intent.getStringExtra("album")
                ?: ""
            val duration = intent.getLongExtra("duration", -1L)
            val position = intent.getLongExtra("position", -1L)
            val pkg = intent.`package`
                ?: if (act.contains("spotify")) "com.spotify.tv.android" else ""
            if (track.isNotEmpty() || artist.isNotEmpty()) {
                MediaStateBus.updateMetadata(
                    context = this@KeyMapperAccessibilityService,
                    title = track,
                    artist = artist,
                    sourcePackage = pkg,
                    sourceAppName = if (pkg.contains("spotify")) "Spotify" else pkg.substringAfterLast('.'),
                    cover = null,
                    durationMs = duration,
                    positionMs = position
                )
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        isServiceConnectedAlive = true
        try {
            val info = serviceInfo ?: AccessibilityServiceInfo()
            info.flags = info.flags or AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
            serviceInfo = info
        } catch (_: Exception) {
        }
        lastKnownVolumePct = computeCurrentMusicVolumePct()
        registerGlobalReceiversIfNeeded()
        ensureGlobalVolumeOverlayCreated()
        ensureDynamicIslandOverlayCreated()

        DynamicIslandBus.onTriggerIslandInService = {
            triggerDynamicIslandAssistant()
        }
        DynamicIslandBus.onAccentColorUpdated = {
            refreshOverlayAccentColors()
        }
        LocalVoiceCommandRouter.onVolumeChangedCallback = {
            showGlobalVolumeOverlay()
        }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        isServiceConnectedAlive = false
        DynamicIslandBus.onTriggerIslandInService = null
        cleanupGlobalOverlayAndReceivers()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        isServiceConnectedAlive = false
        DynamicIslandBus.onTriggerIslandInService = null
        cleanupGlobalOverlayAndReceivers()
        super.onDestroy()
    }

    private fun registerGlobalReceiversIfNeeded() {
        if (receiversRegistered) return
        try {
            val filter = IntentFilter().apply {
                addAction("android.media.VOLUME_CHANGED_ACTION")
                addAction("com.android.music.metachanged")
                addAction("com.android.music.playstatechanged")
                addAction("com.spotify.music.metadatachanged")
                addAction("com.spotify.music.playbackstatechanged")
                addAction("com.spotify.tv.android.metadatachanged")
                addAction("com.spotify.tv.android.playbackstatechanged")
            }
            ContextCompat.registerReceiver(
                this,
                globalMediaAndVolumeReceiver,
                filter,
                ContextCompat.RECEIVER_EXPORTED
            )
            receiversRegistered = true
        } catch (_: Exception) {
        }
    }

    private fun cleanupGlobalOverlayAndReceivers() {
        uiHandler.removeCallbacks(hideOverlayRunnable)
        uiHandler.removeCallbacks(hideIslandRunnable)
        uiHandler.removeCallbacks(pulseWaveRunnable)
        stopVoiceListeningInternal()
        if (receiversRegistered) {
            try {
                unregisterReceiver(globalMediaAndVolumeReceiver)
            } catch (_: Exception) {
            }
            receiversRegistered = false
        }
        val wm = windowManager
        val volRoot = overlayHudRoot
        if (wm != null && volRoot != null) {
            try {
                wm.removeViewImmediate(volRoot)
            } catch (_: Exception) {
            }
        }
        val islRoot = islandRoot
        if (wm != null && islRoot != null) {
            try {
                wm.removeViewImmediate(islRoot)
            } catch (_: Exception) {
            }
        }
        overlayHudRoot = null
        islandRoot = null
    }

    private fun dpPx(dpVal: Float): Int = (dpVal * resources.displayMetrics.density + 0.5f).toInt()

    private fun computeCurrentMusicVolumePct(): Int {
        return try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val isMuted = am.isStreamMute(AudioManager.STREAM_MUSIC)
            val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            val curVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            if (isMuted) 0 else ((curVol * 100f) / maxVol).toInt().coerceIn(0, 100)
        } catch (_: Exception) {
            0
        }
    }

    private fun resolveCurrentAccentColor(): Int {
        return try {
            val prefs = getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            val hex = prefs.getString("pref_accent_color", "#00F0FF") ?: "#00F0FF"
            Color.parseColor(hex)
        } catch (_: Exception) {
            Color.parseColor("#00F0FF")
        }
    }

    private fun refreshOverlayAccentColors() {
        val accent = resolveCurrentAccentColor()
        overlayHudRoot?.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(999f).toFloat()
            setColor(Color.parseColor("#F20D0F14"))
            setStroke(dpPx(1.5f), ColorUtils.setAlphaComponent(accent, 160))
        }
        overlayHudFill?.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(999f).toFloat()
            setColor(accent)
        }
        overlayHudIcon?.setColorFilter(accent, PorterDuff.Mode.SRC_IN)
        overlayHudPct?.setTextColor(accent)

        islandRoot?.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(22f).toFloat()
            setColor(Color.parseColor("#F5101218"))
            setStroke(dpPx(1.8f), accent)
        }
        islandSparkIcon?.setColorFilter(accent, PorterDuff.Mode.SRC_IN)
        islandWaveBars.forEach { bar ->
            bar.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpPx(99f).toFloat()
                setColor(accent)
            }
        }
    }

    private fun ensureGlobalVolumeOverlayCreated() {
        if (overlayHudRoot != null) return
        try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
            windowManager = wm
            val accent = resolveCurrentAccentColor()

            val root = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dpPx(18f), 0, dpPx(18f), 0)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpPx(999f).toFloat()
                    setColor(Color.parseColor("#F20D0F14"))
                    setStroke(dpPx(1.5f), ColorUtils.setAlphaComponent(accent, 160))
                }
                visibility = View.GONE
            }

            val icon = ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(dpPx(22f), dpPx(22f))
                setImageResource(R.drawable.ic_volume_24)
                setColorFilter(accent, PorterDuff.Mode.SRC_IN)
            }

            val track = FrameLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, dpPx(6f), 1f).apply {
                    marginStart = dpPx(14f)
                    marginEnd = dpPx(14f)
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpPx(999f).toFloat()
                    setColor(Color.parseColor("#26FFFFFF"))
                }
            }

            val fill = View(this).apply {
                layoutParams = FrameLayout.LayoutParams(dpPx(80f), FrameLayout.LayoutParams.MATCH_PARENT)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpPx(999f).toFloat()
                    setColor(accent)
                }
            }
            track.addView(fill)

            val pctText = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(dpPx(44f), LinearLayout.LayoutParams.WRAP_CONTENT)
                gravity = Gravity.END
                typeface = Typeface.MONOSPACE
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setTextColor(accent)
                text = "20%"
            }

            root.addView(icon)
            root.addView(track)
            root.addView(pctText)

            val lp = WindowManager.LayoutParams(
                dpPx(290f),
                dpPx(52f),
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.END
                x = dpPx(54f)
                y = dpPx(34f)
            }

            wm.addView(root, lp)
            overlayHudRoot = root
            overlayHudIcon = icon
            overlayHudTrack = track
            overlayHudFill = fill
            overlayHudPct = pctText
        } catch (_: Exception) {
        }
    }

    private fun showGlobalVolumeOverlay() {
        uiHandler.post {
            ensureGlobalVolumeOverlayCreated()
            val root = overlayHudRoot ?: return@post
            val icon = overlayHudIcon ?: return@post
            val track = overlayHudTrack ?: return@post
            val fill = overlayHudFill ?: return@post
            val pctView = overlayHudPct ?: return@post

            val pct = computeCurrentMusicVolumePct()
            lastKnownVolumePct = pct
            val accent = resolveCurrentAccentColor()
            val activeColor = if (pct > 0) accent else Color.parseColor("#FF5252")

            root.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpPx(999f).toFloat()
                setColor(Color.parseColor("#F20D0F14"))
                setStroke(dpPx(1.5f), ColorUtils.setAlphaComponent(accent, 160))
            }
            pctView.text = "$pct%"
            pctView.setTextColor(activeColor)
            icon.setColorFilter(activeColor, PorterDuff.Mode.SRC_IN)
            fill.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpPx(999f).toFloat()
                setColor(activeColor)
            }

            track.post {
                val totalW = track.width.coerceAtLeast(dpPx(140f))
                val fillW = ((totalW * pct) / 100).coerceAtLeast(if (pct > 0) dpPx(6f) else 0)
                val flp = fill.layoutParams
                if (flp.width != fillW) {
                    flp.width = fillW
                    fill.layoutParams = flp
                }
            }

            if (root.visibility != View.VISIBLE) {
                root.alpha = 0f
                root.visibility = View.VISIBLE
                root.animate().alpha(1f).setDuration(110L).start()
            } else {
                root.animate().cancel()
                root.alpha = 1f
            }

            uiHandler.removeCallbacks(hideOverlayRunnable)
            uiHandler.postDelayed(hideOverlayRunnable, 1600L)
        }
    }

    private fun ensureDynamicIslandOverlayCreated() {
        if (islandRoot != null) return
        try {
            val wm = (windowManager ?: getSystemService(Context.WINDOW_SERVICE) as? WindowManager) ?: return
            windowManager = wm
            val accent = resolveCurrentAccentColor()

            val root = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dpPx(18f), dpPx(12f), dpPx(18f), dpPx(12f))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpPx(22f).toFloat()
                    setColor(Color.parseColor("#F5101218"))
                    setStroke(dpPx(1.8f), accent)
                }
                visibility = View.GONE
            }

            val header = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }

            val spark = ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(dpPx(20f), dpPx(20f))
                setImageResource(R.drawable.ic_ai_64)
                setColorFilter(accent, PorterDuff.Mode.SRC_IN)
            }

            val waveBox = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    dpPx(22f)
                ).apply {
                    marginStart = dpPx(10f)
                }
            }
            islandWaveBars.clear()
            for (i in 0 until 4) {
                val bar = View(this).apply {
                    layoutParams = LinearLayout.LayoutParams(dpPx(3.5f), dpPx(10f)).apply {
                        marginEnd = dpPx(3f)
                    }
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.RECTANGLE
                        cornerRadius = dpPx(99f).toFloat()
                        setColor(accent)
                    }
                }
                islandWaveBars.add(bar)
                waveBox.addView(bar)
            }

            val statusTv = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = dpPx(10f)
                }
                setTextColor(Color.parseColor("#F3F4F6"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                text = "Слушаю..."
            }

            val hintTv = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    marginStart = dpPx(10f)
                }
                setTextColor(Color.parseColor("#9CA3AF"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                text = "OK — стоп"
            }

            header.addView(spark)
            header.addView(waveBox)
            header.addView(statusTv)
            header.addView(hintTv)

            val bodyTv = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    topMargin = dpPx(8f)
                }
                setTextColor(Color.parseColor("#E5E7EB"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
                setLineSpacing(dpPx(2f).toFloat(), 1.05f)
                maxLines = 7
                ellipsize = TextUtils.TruncateAt.END
                visibility = View.GONE
            }

            root.addView(header)
            root.addView(bodyTv)

            val lp = WindowManager.LayoutParams(
                dpPx(460f),
                ViewGroup.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.BOTTOM or Gravity.START
                x = dpPx(54f)
                y = dpPx(38f)
            }

            wm.addView(root, lp)
            islandLayoutParams = lp
            islandRoot = root
            islandHeaderRow = header
            islandSparkIcon = spark
            islandWaveContainer = waveBox
            islandStatusText = statusTv
            islandHintText = hintTv
            islandBodyText = bodyTv
        } catch (_: Exception) {
        }
    }

    private fun morphDynamicIslandWidth(targetWidthDp: Float) {
        val wm = windowManager ?: return
        val root = islandRoot ?: return
        val lp = islandLayoutParams ?: return
        val startW = if (root.visibility == View.VISIBLE && lp.width > 0) lp.width else dpPx(148f)
        val endW = dpPx(targetWidthDp)

        islandMorphAnimator?.cancel()
        islandMorphAnimator = ValueAnimator.ofInt(startW, endW).apply {
            duration = 190L
            interpolator = decelerateInterpolator
            addUpdateListener { anim ->
                lp.width = anim.animatedValue as Int
                try {
                    if (root.isAttachedToWindow) {
                        wm.updateViewLayout(root, lp)
                    }
                } catch (_: Exception) {
                }
            }
            start()
        }
    }

    fun triggerDynamicIslandAssistant() {
        uiHandler.post {
            ensureDynamicIslandOverlayCreated()
            refreshOverlayAccentColors()

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                val req = DynamicIslandBus.onRequestAudioPermissionInActivity
                if (req != null) {
                    req.invoke()
                } else {
                    val intent = Intent(this, LauncherActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        putExtra("EXTRA_OPEN_AI", true)
                    }
                    try {
                        startActivity(intent)
                    } catch (_: Exception) {
                    }
                }
                return@post
            }

            if (islandVisible && islandIsListening) {
                finishListeningAndProcess()
                return@post
            }

            uiHandler.removeCallbacks(hideIslandRunnable)
            geminiQueryJob?.cancel()
            stopVoiceListeningInternal()

            val root = islandRoot ?: return@post
            islandBodyText?.visibility = View.GONE
            islandWaveContainer?.visibility = View.VISIBLE
            islandStatusText?.text = "Слушаю... говорите в пульт"
            islandStatusText?.setTextColor(Color.parseColor("#F3F4F6"))
            islandHintText?.text = "OK — готово"
            islandVisible = true
            islandIsListening = true
            lastPartialTranscript = ""
            DynamicIslandBus.notifyIslandVisibility(true)

            if (root.visibility != View.VISIBLE) {
                root.alpha = 0f
                root.visibility = View.VISIBLE
                root.animate().alpha(1f).setDuration(140L).start()
            } else {
                root.animate().cancel()
                root.alpha = 1f
            }

            morphDynamicIslandWidth(470f)
            uiHandler.removeCallbacks(pulseWaveRunnable)
            uiHandler.post(pulseWaveRunnable)

            startSmartVoiceCapture()
        }
    }

    private fun startSmartVoiceCapture() {
        val canUseSpeechRecognizer = try {
            SpeechRecognizer.isRecognitionAvailable(this)
        } catch (_: Exception) {
            false
        }

        if (canUseSpeechRecognizer) {
            try {
                val sr = SpeechRecognizer.createSpeechRecognizer(this)
                speechRecognizer = sr
                sr.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {
                        updateWaveBarsFromRms(rmsdB)
                    }
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {
                        islandIsListening = false
                    }
                    override fun onError(error: Int) {
                        if (islandIsListening && lastPartialTranscript.isBlank()) {
                            stopSpeechRecognizerOnly()
                            startDirectAudioRecordFallback()
                        } else if (lastPartialTranscript.isNotBlank()) {
                            handleRecognizedVoiceText(lastPartialTranscript)
                        } else {
                            showIslandResult("✦ Не расслышал. Нажмите кнопку микрофона и скажите запрос.", isQuick = true)
                        }
                    }
                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull()?.trim().orEmpty().ifEmpty { lastPartialTranscript }
                        if (text.isNotBlank()) {
                            handleRecognizedVoiceText(text)
                        } else {
                            showIslandResult("✦ Не расслышал. Попробуйте ещё раз.", isQuick = true)
                        }
                    }
                    override fun onPartialResults(partialResults: Bundle?) {
                        val partial = partialResults
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                            ?.trim()
                            .orEmpty()
                        if (partial.isNotBlank()) {
                            lastPartialTranscript = partial
                            islandStatusText?.text = "«$partial»"
                        }
                    }
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })

                val recIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                }
                sr.startListening(recIntent)
                return
            } catch (_: Exception) {
                stopSpeechRecognizerOnly()
            }
        }

        startDirectAudioRecordFallback()
    }

    private fun updateWaveBarsFromRms(rmsdB: Float) {
        if (!islandVisible || !islandIsListening) return
        val normalized = ((rmsdB + 2f) / 10f).coerceIn(0.15f, 1.0f)
        val multipliers = floatArrayOf(0.65f, 1.0f, 0.85f, 0.7f)
        for (i in islandWaveBars.indices) {
            val bar = islandWaveBars[i]
            val hDp = (6f + 16f * normalized * multipliers[i % multipliers.size]).coerceIn(6f, 22f)
            val lp = bar.layoutParams
            lp.height = dpPx(hDp)
            bar.layoutParams = lp
        }
    }

    @Suppress("MissingPermission")
    private fun startDirectAudioRecordFallback() {
        audioRecordJob?.cancel()
        audioRecordJob = serviceScope.launch(Dispatchers.IO) {
            val sampleRate = 16000
            val minBuf = AudioRecord.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(3200)

            var recorder: AudioRecord? = null
            val pcmOut = ByteArrayOutputStream()
            try {
                val rec: AudioRecord = try {
                    AudioRecord(
                        MediaRecorder.AudioSource.VOICE_RECOGNITION,
                        sampleRate,
                        AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT,
                        minBuf * 2
                    )
                } catch (_: Exception) {
                    AudioRecord(
                        MediaRecorder.AudioSource.MIC,
                        sampleRate,
                        AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT,
                        minBuf * 2
                    )
                }
                recorder = rec

                if (rec.state != AudioRecord.STATE_INITIALIZED) {
                    withContext(Dispatchers.Main) {
                        showIslandResult("✦ Микрофон пульта сейчас недоступен.", isQuick = true)
                    }
                    return@launch
                }

                rec.startRecording()
                val buf = ShortArray(1024)
                val startMs = SystemClock.elapsedRealtime()
                var heardSpeech = false
                var lastSpeechMs = startMs

                while (isActive && islandIsListening) {
                    val read = rec.read(buf, 0, buf.size)
                    if (read > 0) {
                        var sumSq = 0.0
                        val bb = ByteBuffer.allocate(read * 2).order(ByteOrder.LITTLE_ENDIAN)
                        for (i in 0 until read) {
                            val s = buf[i]
                            bb.putShort(s)
                            sumSq += (s.toDouble() * s.toDouble())
                        }
                        pcmOut.write(bb.array())

                        val rms = sqrt(sumSq / read)
                        val db = (rms / 180.0).toFloat().coerceIn(0f, 10f)
                        uiHandler.post { updateWaveBarsFromRms(db) }

                        val now = SystemClock.elapsedRealtime()
                        if (rms > 420) {
                            heardSpeech = true
                            lastSpeechMs = now
                        }
                        if (heardSpeech && (now - lastSpeechMs) > 1250L && (now - startMs) > 1300L) {
                            break
                        }
                        if ((now - startMs) > 5200L) {
                            break
                        }
                    } else {
                        delay(20L)
                    }
                }
            } catch (_: Exception) {
            } finally {
                try {
                    recorder?.stop()
                } catch (_: Exception) {
                }
                try {
                    recorder?.release()
                } catch (_: Exception) {
                }
            }

            val pcmBytes = pcmOut.toByteArray()
            withContext(Dispatchers.Main) {
                islandIsListening = false
                if (pcmBytes.size < 3200) {
                    showIslandResult("✦ Не расслышал запрос.", isQuick = true)
                } else {
                    val wavBytes = encodePcmToWav(pcmBytes, sampleRate)
                    showIslandThinking("✦ Gemini обрабатывает голос...")
                    geminiQueryJob = serviceScope.launch {
                        val answer = GeminiCloudClient.askGeminiAudio(this@KeyMapperAccessibilityService, wavBytes)
                        showIslandResult(answer, isQuick = answer.startsWith("✦"))
                    }
                }
            }
        }
    }

    private fun encodePcmToWav(pcmData: ByteArray, sampleRate: Int): ByteArray {
        val totalDataLen = pcmData.size + 36
        val byteRate = sampleRate * 2
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray(Charsets.US_ASCII))
        header.putInt(totalDataLen)
        header.put("WAVE".toByteArray(Charsets.US_ASCII))
        header.put("fmt ".toByteArray(Charsets.US_ASCII))
        header.putInt(16)
        header.putShort(1.toShort())
        header.putShort(1.toShort())
        header.putInt(sampleRate)
        header.putInt(byteRate)
        header.putShort(2.toShort())
        header.putShort(16.toShort())
        header.put("data".toByteArray(Charsets.US_ASCII))
        header.putInt(pcmData.size)

        val out = ByteArray(44 + pcmData.size)
        System.arraycopy(header.array(), 0, out, 0, 44)
        System.arraycopy(pcmData, 0, out, 44, pcmData.size)
        return out
    }

    private fun finishListeningAndProcess() {
        if (!islandIsListening) return
        islandIsListening = false
        if (speechRecognizer != null) {
            try {
                speechRecognizer?.stopListening()
            } catch (_: Exception) {
            }
            if (lastPartialTranscript.isNotBlank()) {
                val captured = lastPartialTranscript
                stopSpeechRecognizerOnly()
                handleRecognizedVoiceText(captured)
            }
        }
    }

    private fun handleRecognizedVoiceText(recognizedText: String) {
        stopVoiceListeningInternal()
        val accent = resolveCurrentAccentColor()
        islandSparkIcon?.setColorFilter(accent, PorterDuff.Mode.SRC_IN)

        val localResult = LocalVoiceCommandRouter.tryExecuteLocalCommand(this, recognizedText)
        if (localResult != null) {
            showIslandResult(localResult.confirmationText, isQuick = localResult.isQuickCommand)
            return
        }

        showIslandThinking("✦ Gemini думает: «$recognizedText»")
        geminiQueryJob?.cancel()
        geminiQueryJob = serviceScope.launch {
            val reply = GeminiCloudClient.askGeminiText(this@KeyMapperAccessibilityService, recognizedText)
            showIslandResult(reply, isQuick = reply.startsWith("✦"), queryTitle = recognizedText)
        }
    }

    private fun showIslandThinking(statusLabel: String) {
        islandIsListening = false
        islandWaveContainer?.visibility = View.VISIBLE
        islandBodyText?.visibility = View.GONE
        islandStatusText?.text = statusLabel
        islandHintText?.text = "Назад — отмена"
        morphDynamicIslandWidth(460f)
    }

    private fun showIslandResult(text: String, isQuick: Boolean, queryTitle: String = "") {
        islandIsListening = false
        uiHandler.removeCallbacks(pulseWaveRunnable)
        islandWaveContainer?.visibility = View.GONE

        val accent = resolveCurrentAccentColor()
        islandSparkIcon?.setColorFilter(accent, PorterDuff.Mode.SRC_IN)

        if (isQuick || text.length <= 55) {
            islandBodyText?.visibility = View.GONE
            islandStatusText?.text = text.removePrefix("✦ ").trim()
            islandStatusText?.setTextColor(Color.parseColor("#F3F4F6"))
            islandHintText?.text = ""
            morphDynamicIslandWidth(430f)
            uiHandler.removeCallbacks(hideIslandRunnable)
            uiHandler.postDelayed(hideIslandRunnable, 2200L)
        } else {
            islandStatusText?.text = if (queryTitle.isNotBlank()) "Gemini · «$queryTitle»" else "Gemini"
            islandStatusText?.setTextColor(accent)
            islandHintText?.text = "OK / Назад — скрыть"
            islandBodyText?.text = text
            islandBodyText?.visibility = View.VISIBLE
            morphDynamicIslandWidth(580f)
            uiHandler.removeCallbacks(hideIslandRunnable)
            uiHandler.postDelayed(hideIslandRunnable, LauncherConfig.ASSISTANT_AUTO_HIDE_MS)
        }
    }

    private fun collapseDynamicIsland() {
        uiHandler.removeCallbacks(hideIslandRunnable)
        uiHandler.removeCallbacks(pulseWaveRunnable)
        geminiQueryJob?.cancel()
        stopVoiceListeningInternal()
        islandVisible = false
        val root = islandRoot ?: return
        if (root.visibility == View.VISIBLE) {
            morphDynamicIslandWidth(148f)
            root.animate()
                .alpha(0f)
                .setDuration(170L)
                .withEndAction {
                    root.visibility = View.GONE
                    islandBodyText?.visibility = View.GONE
                    DynamicIslandBus.notifyIslandVisibility(false)
                }
                .start()
        } else {
            DynamicIslandBus.notifyIslandVisibility(false)
        }
    }

    private fun stopSpeechRecognizerOnly() {
        val sr = speechRecognizer
        speechRecognizer = null
        if (sr != null) {
            try {
                sr.cancel()
            } catch (_: Exception) {
            }
            try {
                sr.destroy()
            } catch (_: Exception) {
            }
        }
    }

    private fun stopVoiceListeningInternal() {
        islandIsListening = false
        stopSpeechRecognizerOnly()
        audioRecordJob?.cancel()
        audioRecordJob = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        isServiceConnectedAlive = true
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return

        if (event.eventType == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            val notif = event.parcelableData as? Notification
            if (notif != null && pkg != packageName) {
                MediaStateBus.ingestNotification(this, pkg, notif, requireActivePlaybackOrSession = false)
            }
            return
        }

        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && pkg != packageName) {
            if (isGoogleAssistantPackage(pkg)) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastInterceptMillis > 500L) {
                    lastInterceptMillis = now
                    performGlobalAction(GLOBAL_ACTION_BACK)
                    triggerDynamicIslandAssistant()
                }
                return
            }

            MediaStateBus.onMediaAppOpened(pkg)

            val prefs = getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            val matchedPresetTarget: String? = when {
                isNetflixPackage(pkg) -> prefs.getString("preset_bind_NETFLIX", null)
                isPrimePackage(pkg) -> prefs.getString("preset_bind_PRIME", null)
                isPatchwallPackage(pkg) -> prefs.getString("preset_bind_PATCHWALL", "ACTION_CONTROL_CENTER")
                else -> null
            }

            if (!matchedPresetTarget.isNullOrEmpty()) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastInterceptMillis > 600L) {
                    lastInterceptMillis = now
                    executeBoundAction(matchedPresetTarget)
                }
            }
        }
    }

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        isServiceConnectedAlive = true
        val keyCode = event.keyCode
        val scanCode = event.scanCode

        if (islandVisible) {
            if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                    collapseDynamicIsland()
                }
                return true
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                    if (islandIsListening) {
                        finishListeningAndProcess()
                    } else {
                        collapseDynamicIsland()
                    }
                }
                return true
            }
        }

        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
            keyCode == KeyEvent.KEYCODE_VOLUME_DOWN ||
            keyCode == KeyEvent.KEYCODE_VOLUME_MUTE
        ) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                try {
                    val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    when (keyCode) {
                        KeyEvent.KEYCODE_VOLUME_UP ->
                            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0)
                        KeyEvent.KEYCODE_VOLUME_DOWN ->
                            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0)
                        KeyEvent.KEYCODE_VOLUME_MUTE ->
                            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, 0)
                    }
                    lastKnownVolumePct = computeCurrentMusicVolumePct()
                    showGlobalVolumeOverlay()
                    VolumeHudBus.notifyVolumeChanged()
                } catch (_: Exception) {
                }
            }
            return true
        }

        if (KeyCaptureBus.isCapturingKey) {
            if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
                return false
            }
            if (isNavigationOrCenterKey(keyCode)) {
                return false
            }
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                KeyCaptureBus.notifyKeyCaptured(keyCode, scanCode)
            }
            return true
        }

        if (isNavigationOrCenterKey(keyCode)) {
            return false
        }

        val prefs = getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)

        if (keyCode == KeyEvent.KEYCODE_VOICE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_SEARCH ||
            scanCode == 582 || scanCode == 217 || scanCode == 221
        ) {
            val customAssistTarget = prefs.getString("key_bind_$keyCode", null) ?: "ACTION_AI"
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                executeBoundAction(customAssistTarget)
            }
            return true
        }

        val presetTarget = resolvePresetBinding(prefs, keyCode, scanCode)
        if (!presetTarget.isNullOrEmpty()) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                executeBoundAction(presetTarget)
            }
            return true
        }

        val boundTarget = prefs.getString("key_bind_$keyCode", null)
            ?: if (scanCode > 0) prefs.getString("scan_bind_$scanCode", null) else null

        if (boundTarget.isNullOrEmpty()) {
            return false
        }

        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            executeBoundAction(boundTarget)
        }
        return true
    }

    private fun resolvePresetBinding(
        prefs: android.content.SharedPreferences,
        keyCode: Int,
        scanCode: Int
    ): String? {
        if (keyCode == KeyEvent.KEYCODE_ALL_APPS ||
            keyCode == KeyEvent.KEYCODE_MENU ||
            keyCode == KeyEvent.KEYCODE_GUIDE ||
            keyCode == KeyEvent.KEYCODE_SETTINGS ||
            keyCode == KeyEvent.KEYCODE_TV_INPUT ||
            keyCode == KeyEvent.KEYCODE_BUTTON_1 ||
            scanCode == 139 || scanCode == 362 || scanCode == 172 || scanCode == 256
        ) {
            val target = prefs.getString("preset_bind_PATCHWALL", "ACTION_CONTROL_CENTER")
            if (!target.isNullOrEmpty()) return target
        }

        if (keyCode == KeyEvent.KEYCODE_BUTTON_2 ||
            keyCode == KeyEvent.KEYCODE_PROG_RED ||
            scanCode == 412 || scanCode == 398 || keyCode == 309
        ) {
            prefs.getString("preset_bind_NETFLIX", null)?.let { if (it.isNotEmpty()) return it }
        }

        if (keyCode == KeyEvent.KEYCODE_BUTTON_3 ||
            keyCode == KeyEvent.KEYCODE_PROG_BLUE ||
            scanCode == 413 || scanCode == 401 || keyCode == 310
        ) {
            prefs.getString("preset_bind_PRIME", null)?.let { if (it.isNotEmpty()) return it }
        }

        return null
    }

    private fun isGoogleAssistantPackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("katniss") || p.contains("google.android.tts")
    }

    private fun isNetflixPackage(pkg: String): Boolean = pkg.lowercase().contains("netflix")

    private fun isPrimePackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("amazonvideo") || p.contains("amazon.avod") || p.contains("primevideo")
    }

    private fun isPatchwallPackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("patchwall") || p.contains("mitv.tvhome") || p.contains("mitv.smartshare")
    }

    private fun isNavigationOrCenterKey(keyCode: Int): Boolean {
        return keyCode == KeyEvent.KEYCODE_DPAD_UP ||
            keyCode == KeyEvent.KEYCODE_DPAD_DOWN ||
            keyCode == KeyEvent.KEYCODE_DPAD_LEFT ||
            keyCode == KeyEvent.KEYCODE_DPAD_RIGHT ||
            keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
            keyCode == KeyEvent.KEYCODE_ENTER ||
            keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER ||
            keyCode == KeyEvent.KEYCODE_HOME
    }

    private fun executeBoundAction(target: String) {
        when (target) {
            "ACTION_CONTROL_CENTER" -> {
                val intent = Intent(this, LauncherActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("EXTRA_OPEN_CONTROL_CENTER", true)
                }
                startActivity(intent)
            }
            "ACTION_ALL_APPS" -> {
                val intent = Intent(this, LauncherActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("EXTRA_OPEN_ALL_APPS", true)
                }
                startActivity(intent)
            }
            "ACTION_SETTINGS" -> {
                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    startActivity(intent)
                } catch (_: Exception) {
                }
            }
            "ACTION_AI" -> {
                triggerDynamicIslandAssistant()
            }
            else -> {
                MediaStateBus.onMediaAppOpened(target)
                val pm = packageManager
                val launchIntent = pm.getLeanbackLaunchIntentForPackage(target)
                    ?: pm.getLaunchIntentForPackage(target)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        startActivity(launchIntent)
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }
}
