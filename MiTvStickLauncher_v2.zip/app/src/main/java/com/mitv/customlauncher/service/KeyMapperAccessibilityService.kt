package com.mitv.customlauncher.service

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.mitv.customlauncher.data.LauncherConfig
import com.mitv.customlauncher.ui.LauncherActivity

class KeyMapperAccessibilityService : AccessibilityService() {

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Не читаем содержимое окон — только фильтруем нажатия кнопок пульта (0 МБ расхода)
    }

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val prefs = getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
        val boundTarget = prefs.getString("key_bind_${event.keyCode}", null)
            ?: if (event.scanCode > 0) prefs.getString("scan_bind_${event.scanCode}", null) else null

        if (boundTarget.isNullOrEmpty()) {
            return false
        }

        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            executeBoundAction(boundTarget)
        }
        return true
    }

    private fun executeBoundAction(target: String) {
        when (target) {
            "ACTION_ALL_APPS" -> {
                val intent = Intent(this, LauncherActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    putExtra("EXTRA_OPEN_ALL_APPS", true)
                }
                startActivity(intent)
            }
            "ACTION_SETTINGS" -> {
                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    startActivity(intent)
                } catch (_: Exception) {
                }
            }
            "ACTION_AI" -> {
                val intent = Intent(this, LauncherActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                    putExtra("EXTRA_OPEN_AI", true)
                }
                startActivity(intent)
            }
            else -> {
                val pm = packageManager
                val launchIntent = pm.getLeanbackLaunchIntentForPackage(target)
                    ?: pm.getLaunchIntentForPackage(target)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        startActivity(launchIntent)
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }
}
