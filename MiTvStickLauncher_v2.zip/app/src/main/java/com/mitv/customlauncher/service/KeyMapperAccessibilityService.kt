package com.mitv.customlauncher.service

import android.accessibilityservice.AccessibilityService
import android.app.Notification
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.os.Parcelable
import android.os.SystemClock
import android.provider.Settings
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import com.mitv.customlauncher.data.LauncherConfig
import com.mitv.customlauncher.ui.LauncherActivity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.max
import kotlin.math.min

data class NowPlayingSnapshot(
    val isPlaying: Boolean = false,
    val title: String = "",
    val artist: String = "",
    val sourcePackage: String = "",
    val sourceAppName: String = "",
    val coverBitmap: Bitmap? = null,
    val accentColor: Int = Color.parseColor("#00F0FF"),
    val durationMs: Long = 0L,
    val basePositionMs: Long = 0L,
    val baseElapsedRealtime: Long = 0L,
    val playbackSpeed: Float = 1.0f
)

object MediaStateBus {
    private val _state = MutableStateFlow(NowPlayingSnapshot())
    val state: StateFlow<NowPlayingSnapshot> = _state.asStateFlow()

    @Volatile
    var activeController: MediaController? = null

    private var trackStartRealtime: Long = SystemClock.elapsedRealtime()
    private var lastTrackTitle: String = ""

    fun updateMetadata(
        title: String,
        artist: String,
        sourcePackage: String,
        sourceAppName: String,
        cover: Bitmap?,
        durationMs: Long = -1L,
        positionMs: Long = -1L,
        positionUpdateRealtime: Long = 0L,
        speed: Float = 1.0f
    ) {
        val current = _state.value
        val resolvedTitle = if (title.isNotBlank()) title else current.title
        if (resolvedTitle.isNotBlank() && resolvedTitle != lastTrackTitle) {
            lastTrackTitle = resolvedTitle
            trackStartRealtime = SystemClock.elapsedRealtime()
        }

        val newCover = cover ?: if (resolvedTitle == current.title) current.coverBitmap else null
        val accent = if (newCover != null) extractVibrantAccent(newCover) else Color.parseColor("#00F0FF")

        val resolvedDuration = if (durationMs >= 0L) durationMs else current.durationMs
        val resolvedPos = if (positionMs >= 0L) positionMs else current.basePositionMs
        val resolvedRealtime = if (positionUpdateRealtime > 0L) positionUpdateRealtime else SystemClock.elapsedRealtime()

        _state.value = current.copy(
            title = resolvedTitle,
            artist = if (artist.isNotBlank()) artist else current.artist,
            sourcePackage = if (sourcePackage.isNotBlank()) sourcePackage else current.sourcePackage,
            sourceAppName = if (sourceAppName.isNotBlank()) sourceAppName else current.sourceAppName,
            coverBitmap = newCover,
            accentColor = accent,
            durationMs = resolvedDuration,
            basePositionMs = resolvedPos,
            baseElapsedRealtime = resolvedRealtime,
            playbackSpeed = if (speed > 0f) speed else 1.0f
        )
    }

    fun updatePlayingFlag(isPlaying: Boolean) {
        val cur = _state.value
        if (cur.isPlaying != isPlaying) {
            if (isPlaying && !cur.isPlaying && cur.basePositionMs == 0L) {
                trackStartRealtime = SystemClock.elapsedRealtime()
            }
            _state.value = cur.copy(isPlaying = isPlaying)
        }
    }

    /**
     * Вычисляет живую текущую позицию трека и длительность (в мс) прямо из MediaController или интерполяцией
     */
    fun getLivePositionAndDuration(): Pair<Long, Long> {
        val ctrl = activeController
        if (ctrl != null) {
            try {
                val meta = ctrl.metadata
                val pb = ctrl.playbackState
                val dur = meta?.getLong(MediaMetadata.METADATA_KEY_DURATION)?.coerceAtLeast(0L)
                    ?: _state.value.durationMs
                if (pb != null) {
                    var pos = pb.position.coerceAtLeast(0L)
                    if (pb.state == PlaybackState.STATE_PLAYING && pb.lastPositionUpdateTime > 0L) {
                        val delta = SystemClock.elapsedRealtime() - pb.lastPositionUpdateTime
                        pos += (delta * pb.playbackSpeed).toLong().coerceAtLeast(0L)
                    }
                    if (dur > 0L) pos = pos.coerceAtMost(dur)
                    return pos to dur
                }
            } catch (_: Exception) {
            }
        }

        val snap = _state.value
        val dur = snap.durationMs.coerceAtLeast(0L)
        if (snap.basePositionMs > 0L && snap.baseElapsedRealtime > 0L) {
            val delta = if (snap.isPlaying) SystemClock.elapsedRealtime() - snap.baseElapsedRealtime else 0L
            var pos = snap.basePositionMs + (delta * snap.playbackSpeed).toLong().coerceAtLeast(0L)
            if (dur > 0L) pos = pos.coerceAtMost(dur)
            return pos to dur
        }

        // Если плеер (например Google Cast без метаданных длительности) не отдал position, считаем секунды с начала трека
        val elapsed = (SystemClock.elapsedRealtime() - trackStartRealtime).coerceAtLeast(0L)
        return elapsed to dur
    }

    /**
     * Отправляет команду управления треком напрямую в активный MediaController (включая Google Cast!) + системный фоллбэк
     */
    fun dispatchTransportAction(action: String, audioManager: AudioManager) {
        val ctrl = activeController
        try {
            if (ctrl != null) {
                val tc = ctrl.transportControls
                val pbState = ctrl.playbackState?.state
                when (action) {
                    "PREV" -> {
                        tc.skipToPrevious()
                        return
                    }
                    "NEXT" -> {
                        tc.skipToNext()
                        return
                    }
                    "PLAY_PAUSE" -> {
                        if (pbState == PlaybackState.STATE_PLAYING || audioManager.isMusicActive) {
                            tc.pause()
                        } else {
                            tc.play()
                        }
                        return
                    }
                }
            }
        } catch (_: Exception) {
        }

        // Системный фоллбэк через AudioManager
        val keyCode = when (action) {
            "PREV" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "NEXT" -> KeyEvent.KEYCODE_MEDIA_NEXT
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        try {
            val now = SystemClock.uptimeMillis()
            audioManager.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0))
            audioManager.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_UP, keyCode, 0))
        } catch (_: Exception) {
        }
    }

    /**
     * Многоточечный алгоритм выбора самого сочного оттенка с обложки трека
     */
    private fun extractVibrantAccent(bmp: Bitmap): Int {
        return try {
            val w = bmp.width
            val h = bmp.height
            var bestColor = Color.parseColor("#00F0FF")
            var bestScore = -1

            for (gx in 1..4) {
                for (gy in 1..4) {
                    val px = (w * gx) / 5
                    val py = (h * gy) / 5
                    val c = bmp.getPixel(px, py)
                    val r = Color.red(c)
                    val g = Color.green(c)
                    val b = Color.blue(c)
                    val maxC = max(r, max(g, b))
                    val minC = min(r, min(g, b))
                    val saturation = maxC - minC
                    val brightness = r + g + b
                    if (brightness in 90..700 && saturation > bestScore) {
                        bestScore = saturation
                        bestColor = Color.rgb(
                            (r + 55).coerceAtMost(255),
                            (g + 55).coerceAtMost(255),
                            (b + 55).coerceAtMost(255)
                        )
                    }
                }
            }
            bestColor
        } catch (_: Exception) {
            Color.parseColor("#00F0FF")
        }
    }
}

object KeyCaptureBus {
    @Volatile
    var isCapturingKey: Boolean = false

    @Volatile
    var onKeyCapturedListener: ((keyCode: Int, scanCode: Int) -> Unit)? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    fun notifyKeyCaptured(keyCode: Int, scanCode: Int): Boolean {
        val listener = onKeyCapturedListener ?: return false
        isCapturingKey = false
        mainHandler.post {
            listener.invoke(keyCode, scanCode)
        }
        return true
    }
}

class KeyMapperAccessibilityService : AccessibilityService() {

    private var lastInterceptMillis: Long = 0L
    private var currentControllerCallback: MediaController.Callback? = null

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return

        if (event.eventType == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            val notif = event.parcelableData as? Notification
            if (notif != null && pkg != packageName) {
                extractMediaFromNotification(pkg, notif)
            }
            return
        }

        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && pkg != packageName) {
            if (isKnownMediaApp(pkg)) {
                val appLabel = resolveAppLabel(pkg)
                MediaStateBus.updateMetadata(
                    title = "",
                    artist = "",
                    sourcePackage = pkg,
                    sourceAppName = appLabel,
                    cover = null
                )
            }

            val prefs = getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            val matchedPresetTarget: String? = when {
                isNetflixPackage(pkg) -> prefs.getString("preset_bind_NETFLIX", null)
                isPrimePackage(pkg) -> prefs.getString("preset_bind_PRIME", null)
                isPatchwallPackage(pkg) -> prefs.getString("preset_bind_PATCHWALL", null)
                else -> null
            }

            if (!matchedPresetTarget.isNullOrEmpty()) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastInterceptMillis > 600L) {
                    lastInterceptMillis = now
                    executeBoundAction(matchedPresetTarget)
                }
            }
        }
    }

    private fun extractMediaFromNotification(pkg: String, notif: Notification) {
        try {
            val extras = notif.extras ?: return
            var title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
            var text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
            val appName = resolveAppLabel(pkg)

            var coverBmp: Bitmap? = null
            var durationMs = -1L
            var posMs = -1L
            var posRealtime = 0L
            var speed = 1.0f

            // 1. Проверяем токен MediaSession прямо внутри уведомления (Notification.EXTRA_MEDIA_SESSION)!
            @Suppress("DEPRECATION")
            val sessionToken = extras.getParcelable< Parcelable >(Notification.EXTRA_MEDIA_SESSION) as? MediaSession.Token
            if (sessionToken != null) {
                try {
                    val controller = MediaController(this, sessionToken)
                    attachControllerCallback(pkg, appName, controller)

                    val meta = controller.metadata
                    if (meta != null) {
                        val metaTitle = meta.getString(MediaMetadata.METADATA_KEY_TITLE)
                            ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
                        val metaArtist = meta.getString(MediaMetadata.METADATA_KEY_ARTIST)
                            ?: meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                            ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
                        if (!metaTitle.isNullOrBlank()) title = metaTitle
                        if (!metaArtist.isNullOrBlank()) text = metaArtist

                        val d = meta.getLong(MediaMetadata.METADATA_KEY_DURATION)
                        if (d > 0L) durationMs = d

                        val rawArt = meta.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                            ?: meta.getBitmap(MediaMetadata.METADATA_KEY_ART)
                            ?: meta.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                        if (rawArt != null) {
                            coverBmp = Bitmap.createScaledBitmap(rawArt, 112, 112, true)
                        }
                    }

                    val pb = controller.playbackState
                    if (pb != null) {
                        posMs = pb.position
                        posRealtime = pb.lastPositionUpdateTime
                        speed = pb.playbackSpeed
                        MediaStateBus.updatePlayingFlag(pb.state == PlaybackState.STATE_PLAYING)
                    }
                } catch (_: Exception) {
                }
            }

            // 2. Если обложки не было в MediaMetadata, достаём из Notification.getLargeIcon() или EXTRA_PICTURE / EXTRA_LARGE_ICON
            if (coverBmp == null) {
                val largeIcon = notif.getLargeIcon()
                if (largeIcon != null) {
                    val d = largeIcon.loadDrawable(this)
                    if (d != null) {
                        coverBmp = drawableToSmallBitmap(d)
                    }
                }
            }
            if (coverBmp == null) {
                @Suppress("DEPRECATION")
                val extraBmp = (extras.getParcelable<Parcelable>(Notification.EXTRA_LARGE_ICON_BIG) as? Bitmap)
                    ?: (extras.getParcelable<Parcelable>(Notification.EXTRA_LARGE_ICON) as? Bitmap)
                    ?: (extras.getParcelable<Parcelable>(Notification.EXTRA_PICTURE) as? Bitmap)
                if (extraBmp != null) {
                    coverBmp = Bitmap.createScaledBitmap(extraBmp, 112, 112, true)
                }
            }

            if (title.isEmpty() && text.isEmpty() && coverBmp == null) return

            MediaStateBus.updateMetadata(
                title = title,
                artist = text,
                sourcePackage = pkg,
                sourceAppName = appName,
                cover = coverBmp,
                durationMs = durationMs,
                positionMs = posMs,
                positionUpdateRealtime = posRealtime,
                speed = speed
            )
        } catch (_: Exception) {
        }
    }

    private fun attachControllerCallback(pkg: String, appName: String, controller: MediaController) {
        try {
            val prev = MediaStateBus.activeController
            val prevCb = currentControllerCallback
            if (prev != null && prevCb != null) {
                try {
                    prev.unregisterCallback(prevCb)
                } catch (_: Exception) {
                }
            }

            MediaStateBus.activeController = controller
            val cb = object : MediaController.Callback() {
                override fun onPlaybackStateChanged(state: PlaybackState?) {
                    if (state != null) {
                        MediaStateBus.updatePlayingFlag(state.state == PlaybackState.STATE_PLAYING)
                        MediaStateBus.updateMetadata(
                            title = "",
                            artist = "",
                            sourcePackage = pkg,
                            sourceAppName = appName,
                            cover = null,
                            positionMs = state.position,
                            positionUpdateRealtime = state.lastPositionUpdateTime,
                            speed = state.playbackSpeed
                        )
                    }
                }

                override fun onMetadataChanged(metadata: MediaMetadata?) {
                    if (metadata != null) {
                        val t = metadata.getString(MediaMetadata.METADATA_KEY_TITLE).orEmpty()
                        val a = metadata.getString(MediaMetadata.METADATA_KEY_ARTIST).orEmpty()
                        val dur = metadata.getLong(MediaMetadata.METADATA_KEY_DURATION)
                        val art = metadata.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                            ?: metadata.getBitmap(MediaMetadata.METADATA_KEY_ART)
                        val scaled = if (art != null) Bitmap.createScaledBitmap(art, 112, 112, true) else null
                        MediaStateBus.updateMetadata(
                            title = t,
                            artist = a,
                            sourcePackage = pkg,
                            sourceAppName = appName,
                            cover = scaled,
                            durationMs = if (dur > 0L) dur else -1L
                        )
                    }
                }
            }
            currentControllerCallback = cb
            controller.registerCallback(cb, Handler(Looper.getMainLooper()))
        } catch (_: Exception) {
        }
    }

    private fun drawableToSmallBitmap(d: Drawable): Bitmap? {
        return try {
            if (d is BitmapDrawable && d.bitmap != null) {
                Bitmap.createScaledBitmap(d.bitmap, 112, 112, true)
            } else {
                val bmp = Bitmap.createBitmap(112, 112, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bmp)
                d.setBounds(0, 0, 112, 112)
                d.draw(canvas)
                bmp
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun resolveAppLabel(pkg: String): String {
        return try {
            val ai = packageManager.getApplicationInfo(pkg, 0)
            packageManager.getApplicationLabel(ai).toString()
        } catch (_: Exception) {
            pkg.substringAfterLast('.')
        }
    }

    private fun isKnownMediaApp(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("youtube") || p.contains("smarttube") || p.contains("spotify") ||
            p.contains("soundcloud") || p.contains("music") || p.contains("vlc") ||
            p.contains("kodi") || p.contains("lampa") || p.contains("kino") || p.contains("mediashell")
    }

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val keyCode = event.keyCode
        val scanCode = event.scanCode

        if (isNavigationOrCenterKey(keyCode)) {
            return false
        }

        if (KeyCaptureBus.isCapturingKey) {
            if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
                return false
            }
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                KeyCaptureBus.notifyKeyCaptured(keyCode, scanCode)
            }
            return true
        }

        val prefs = getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)

        if (keyCode == KeyEvent.KEYCODE_VOICE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_SEARCH
        ) {
            val customAssistTarget = prefs.getString("key_bind_$keyCode", null) ?: "ACTION_AI"
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                executeBoundAction(customAssistTarget)
            }
            return true
        }

        val presetTarget = resolvePresetBinding(prefs, keyCode, scanCode)
        if (!presetTarget.isNullOrEmpty()) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                executeBoundAction(presetTarget)
            }
            return true
        }

        val boundTarget = prefs.getString("key_bind_$keyCode", null)
            ?: if (scanCode > 0) prefs.getString("scan_bind_$scanCode", null) else null

        if (boundTarget.isNullOrEmpty()) {
            return false
        }

        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            executeBoundAction(boundTarget)
        }
        return true
    }

    private fun resolvePresetBinding(
        prefs: android.content.SharedPreferences,
        keyCode: Int,
        scanCode: Int
    ): String? {
        if (keyCode == KeyEvent.KEYCODE_ALL_APPS ||
            keyCode == KeyEvent.KEYCODE_MENU ||
            keyCode == KeyEvent.KEYCODE_GUIDE ||
            keyCode == KeyEvent.KEYCODE_SETTINGS ||
            keyCode == KeyEvent.KEYCODE_TV_INPUT ||
            keyCode == KeyEvent.KEYCODE_BUTTON_1 ||
            scanCode == 139 || scanCode == 362 || scanCode == 172 || scanCode == 256
        ) {
            prefs.getString("preset_bind_PATCHWALL", null)?.let { if (it.isNotEmpty()) return it }
        }

        if (keyCode == KeyEvent.KEYCODE_BUTTON_2 ||
            keyCode == KeyEvent.KEYCODE_PROG_RED ||
            scanCode == 412 || scanCode == 398 || keyCode == 309
        ) {
            prefs.getString("preset_bind_NETFLIX", null)?.let { if (it.isNotEmpty()) return it }
        }

        if (keyCode == KeyEvent.KEYCODE_BUTTON_3 ||
            keyCode == KeyEvent.KEYCODE_PROG_BLUE ||
            scanCode == 413 || scanCode == 401 || keyCode == 310
        ) {
            prefs.getString("preset_bind_PRIME", null)?.let { if (it.isNotEmpty()) return it }
        }

        return null
    }

    private fun isNetflixPackage(pkg: String): Boolean = pkg.lowercase().contains("netflix")

    private fun isPrimePackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("amazonvideo") || p.contains("amazon.avod") || p.contains("primevideo")
    }

    private fun isPatchwallPackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("patchwall") || p.contains("mitv.tvhome") || p.contains("mitv.smartshare")
    }

    private fun isNavigationOrCenterKey(keyCode: Int): Boolean {
        return keyCode == KeyEvent.KEYCODE_DPAD_UP ||
            keyCode == KeyEvent.KEYCODE_DPAD_DOWN ||
            keyCode == KeyEvent.KEYCODE_DPAD_LEFT ||
            keyCode == KeyEvent.KEYCODE_DPAD_RIGHT ||
            keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
            keyCode == KeyEvent.KEYCODE_ENTER ||
            keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER ||
            keyCode == KeyEvent.KEYCODE_HOME
    }

    private fun executeBoundAction(target: String) {
        when (target) {
            "ACTION_ALL_APPS" -> {
                val intent = Intent(this, LauncherActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("EXTRA_OPEN_ALL_APPS", true)
                }
                startActivity(intent)
            }
            "ACTION_SETTINGS" -> {
                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    startActivity(intent)
                } catch (_: Exception) {
                }
            }
            "ACTION_AI" -> {
                val intent = Intent(this, LauncherActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("EXTRA_OPEN_AI", true)
                }
                startActivity(intent)
            }
            else -> {
                val pm = packageManager
                val launchIntent = pm.getLeanbackLaunchIntentForPackage(target)
                    ?: pm.getLaunchIntentForPackage(target)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        startActivity(launchIntent)
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }
}
