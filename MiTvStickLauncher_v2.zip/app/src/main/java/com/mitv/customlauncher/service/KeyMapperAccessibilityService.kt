package com.mitv.customlauncher.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Notification
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.PlaybackState
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.Parcelable
import android.os.SystemClock
import android.provider.Settings
import android.util.LruCache
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import com.mitv.customlauncher.R
import com.mitv.customlauncher.data.LauncherConfig
import com.mitv.customlauncher.ui.LauncherActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.net.HttpURLConnection
import java.net.URL

data class NowPlayingSnapshot(
    val hasActiveSession: Boolean = false,
    val isPlaying: Boolean = false,
    val title: String = "",
    val artist: String = "",
    val sourcePackage: String = "",
    val sourceAppName: String = "",
    val coverBitmap: Bitmap? = null,
    val durationMs: Long = 0L,
    val basePositionMs: Long = 0L,
    val baseElapsedRealtime: Long = 0L,
    val playbackSpeed: Float = 1.0f
)

object VolumeHudBus {
    @Volatile
    var onVolumeIntercepted: (() -> Unit)? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    fun notifyVolumeChanged() {
        val listener = onVolumeIntercepted ?: return
        mainHandler.post { listener.invoke() }
    }

    /**
     * Принудительно закрывает штатный белый ползунок громкости Android TV (SystemUI VolumeDialogControllerImpl)
     * через системный интент ACTION_CLOSE_SYSTEM_DIALOGS (работает без root на Android 9-11!).
     */
    fun dismissStockSystemVolumeUi(context: Context) {
        val appCtx = context.applicationContext
        val sendDismiss = {
            try {
                @Suppress("DEPRECATION")
                appCtx.sendBroadcast(Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS).apply {
                    putExtra("reason", "volume")
                })
            } catch (_: Exception) {
            }
        }
        sendDismiss()
        mainHandler.postDelayed(sendDismiss, 25L)
        mainHandler.postDelayed(sendDismiss, 65L)
        mainHandler.postDelayed(sendDismiss, 130L)
    }
}

object MediaStateBus {
    private val _state = MutableStateFlow(NowPlayingSnapshot())
    val state: StateFlow<NowPlayingSnapshot> = _state.asStateFlow()

    @Volatile
    var activeController: MediaController? = null

    private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val artUriCache = object : LruCache<String, Bitmap>(20) {}
    private var lastFetchedArtUri: String = ""

    private var trackStartRealtime: Long = SystemClock.elapsedRealtime()
    private var lastPausedRealtime: Long = 0L
    private var currentTrackIdentity: String = ""
    private var currentCoverSignature: Int = 0

    // Если пользователь нажал [X] "Закрыть плеер" — запоминаем закрытый трек, чтобы он не выскакивал снова сам!
    private var dismissedTrackIdentity: String = ""
    private var dismissedAtRealtime: Long = 0L

    /**
     * Безопасный и сверхбыстрый хэш картинки (поддерживает в том числе Bitmap.Config.HARDWARE в Spotify!).
     */
    fun computeBitmapSignature(bmp: Bitmap?): Int {
        if (bmp == null || bmp.isRecycled) return 0
        val w = bmp.width
        val h = bmp.height
        if (w <= 0 || h <= 0) return 0
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && bmp.config == Bitmap.Config.HARDWARE) {
            val gen = bmp.generationId
            val hash = ((w * 31) xor h) xor (gen * 31)
            return if (hash == 0) 1 else hash
        }
        return try {
            var hash = (w * 31) xor h
            hash = (hash * 31) xor bmp.getPixel(w / 2, h / 2)
            hash = (hash * 31) xor bmp.getPixel(w / 4, h / 4)
            hash = (hash * 31) xor bmp.getPixel((w * 3) / 4, h / 4)
            hash = (hash * 31) xor bmp.getPixel(w / 4, (h * 3) / 4)
            hash = (hash * 31) xor bmp.getPixel((w * 3) / 4, (h * 3) / 4)
            if (hash == 0) 1 else hash
        } catch (_: Exception) {
            val gen = bmp.generationId
            if (gen == 0) 1 else gen
        }
    }

    /**
     * Безопасно сжимает любой Bitmap (включая HARDWARE Bitmap от Spotify) до 112x112.
     */
    fun safeScaleBitmap(raw: Bitmap?): Bitmap? {
        if (raw == null || raw.isRecycled) return null
        return try {
            val src = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && raw.config == Bitmap.Config.HARDWARE) {
                raw.copy(Bitmap.Config.ARGB_8888, false) ?: raw
            } else {
                raw
            }
            val scaled = Bitmap.createScaledBitmap(src, 112, 112, true)
            if (src !== raw && src !== scaled && !src.isRecycled) {
                src.recycle()
            }
            scaled
        } catch (_: Exception) {
            raw
        }
    }

    fun getCurrentCoverSignature(): Int = currentCoverSignature

    /**
     * Закрытие плеера кнопкой [X]: ставит трек на паузу (если играл) и скрывает карточку плеера.
     */
    fun dismissPlayerByUser(audioManager: AudioManager) {
        val cur = _state.value
        val now = SystemClock.elapsedRealtime()
        dismissedTrackIdentity = currentTrackIdentity.ifEmpty { "${cur.sourcePackage}|${cur.title}" }
        dismissedAtRealtime = now

        try {
            val ctrl = activeController
            if (ctrl != null && (ctrl.playbackState?.state == PlaybackState.STATE_PLAYING || cur.isPlaying)) {
                ctrl.transportControls.pause()
            } else if (cur.isPlaying) {
                val upNow = SystemClock.uptimeMillis()
                audioManager.dispatchMediaKeyEvent(KeyEvent(upNow, upNow, KeyEvent.ACTION_DOWN, KeyEvent.KEYCODE_MEDIA_PAUSE, 0))
                audioManager.dispatchMediaKeyEvent(KeyEvent(upNow, upNow, KeyEvent.ACTION_UP, KeyEvent.KEYCODE_MEDIA_PAUSE, 0))
            }
        } catch (_: Exception) {
        }

        _state.value = NowPlayingSnapshot(
            hasActiveSession = false,
            isPlaying = false
        )
    }

    fun updateMetadata(
        title: String,
        artist: String,
        sourcePackage: String,
        sourceAppName: String,
        cover: Bitmap?,
        coverSignature: Int = 0,
        artUri: String = "",
        durationMs: Long = -1L,
        positionMs: Long = -1L,
        positionUpdateRealtime: Long = 0L,
        speed: Float = 1.0f,
        explicitIsPlaying: Boolean? = null
    ) {
        val current = _state.value
        val now = SystemClock.elapsedRealtime()
        val resolvedPkg = if (sourcePackage.isNotBlank()) sourcePackage else current.sourcePackage
        val resolvedTitle = if (title.isNotBlank()) title else if (resolvedPkg == current.sourcePackage) current.title else ""
        val resolvedArtist = if (artist.isNotBlank()) artist else if (resolvedPkg == current.sourcePackage) current.artist else ""
        val resolvedAppName = if (sourceAppName.isNotBlank()) sourceAppName else if (resolvedPkg == current.sourcePackage) current.sourceAppName else ""

        val newIdentity = "$resolvedPkg|$resolvedTitle"
        val isNowPlaying = explicitIsPlaying ?: current.isPlaying

        // Если пользователь только что закрыл этот трек кнопкой [X], и он не запущен заново — не открываем плеер обратно!
        if (dismissedTrackIdentity.isNotEmpty()) {
            if ((now - dismissedAtRealtime) < 3500L) {
                return
            }
            if (newIdentity == dismissedTrackIdentity && !isNowPlaying) {
                return
            }
            if (isNowPlaying || newIdentity != dismissedTrackIdentity) {
                dismissedTrackIdentity = ""
            }
        }

        val trackChanged = resolvedTitle.isNotBlank() && newIdentity != currentTrackIdentity
        if (trackChanged) {
            currentTrackIdentity = newIdentity
            trackStartRealtime = now
            lastFetchedArtUri = ""
        }

        var resolvedCover: Bitmap? = when {
            cover != null -> {
                currentCoverSignature = if (coverSignature != 0) coverSignature else computeBitmapSignature(cover)
                cover
            }
            !trackChanged && resolvedPkg == current.sourcePackage -> current.coverBitmap
            else -> {
                currentCoverSignature = 0
                null
            }
        }

        if (resolvedCover == null && artUri.isNotBlank()) {
            val cached = artUriCache.get(artUri)
            if (cached != null) {
                resolvedCover = cached
                currentCoverSignature = computeBitmapSignature(cached)
            } else if (artUri != lastFetchedArtUri) {
                lastFetchedArtUri = artUri
                fetchArtFromUriAsync(artUri, newIdentity)
            }
        }

        val resolvedDuration = when {
            durationMs > 0L -> durationMs
            trackChanged -> 0L
            else -> current.durationMs
        }

        val resolvedPos = when {
            trackChanged -> if (positionMs in 0L..15000L) positionMs else 0L
            positionMs >= 0L -> positionMs
            else -> current.basePositionMs
        }

        val resolvedRealtime = when {
            trackChanged -> now
            positionUpdateRealtime > 0L && positionUpdateRealtime >= trackStartRealtime - 2000L -> positionUpdateRealtime
            positionMs >= 0L -> now
            else -> current.baseElapsedRealtime
        }

        // ВАЖНО: Плеер НИКОГДА не появляется сам при старте ТВ, пока реально не началось воспроизведение (isNowPlaying == true)!
        // А когда воспроизведение уже шло (current.hasActiveSession == true), он остаётся видимым и на паузе.
        val hasSession = current.hasActiveSession || isNowPlaying

        _state.value = current.copy(
            hasActiveSession = hasSession,
            isPlaying = isNowPlaying,
            title = resolvedTitle,
            artist = resolvedArtist,
            sourcePackage = resolvedPkg,
            sourceAppName = resolvedAppName,
            coverBitmap = resolvedCover,
            durationMs = resolvedDuration,
            basePositionMs = resolvedPos,
            baseElapsedRealtime = resolvedRealtime,
            playbackSpeed = if (speed > 0f) speed else 1.0f
        )
    }

    /**
     * Лёгкое обновление только позиции времени (вызывается при перемотке трека -> 0 аллокаций памяти, 0 треска!)
     */
    fun updatePositionOnly(positionMs: Long, positionUpdateRealtime: Long, speed: Float, isPlaying: Boolean) {
        val cur = _state.value
        val now = SystemClock.elapsedRealtime()
        if (dismissedTrackIdentity.isNotEmpty() && (now - dismissedAtRealtime) < 3500L && !isPlaying) {
            return
        }
        if (isPlaying) {
            dismissedTrackIdentity = ""
            lastPausedRealtime = 0L
        } else if (cur.isPlaying) {
            lastPausedRealtime = now
        }
        val validPos = if (positionMs >= 0L) {
            if (cur.durationMs > 0L) positionMs.coerceAtMost(cur.durationMs) else positionMs
        } else {
            cur.basePositionMs
        }
        val validRealtime = if (positionUpdateRealtime > 0L && positionUpdateRealtime >= trackStartRealtime - 2000L) {
            positionUpdateRealtime
        } else {
            now
        }
        _state.value = cur.copy(
            hasActiveSession = cur.hasActiveSession || isPlaying,
            isPlaying = isPlaying,
            basePositionMs = validPos,
            baseElapsedRealtime = validRealtime,
            playbackSpeed = if (speed > 0f) speed else 1.0f
        )
    }

    private fun fetchArtFromUriAsync(uriString: String, expectedIdentity: String) {
        ioScope.launch {
            try {
                if (!uriString.startsWith("http://") && !uriString.startsWith("https://")) return@launch
                val conn = (URL(uriString).openConnection() as HttpURLConnection).apply {
                    connectTimeout = 3500
                    readTimeout = 3500
                    doInput = true
                }
                conn.connect()
                val raw = conn.inputStream.use { BitmapFactory.decodeStream(it) }
                conn.disconnect()
                if (raw != null) {
                    val scaled = safeScaleBitmap(raw)
                    if (scaled != null && scaled !== raw && !raw.isRecycled) raw.recycle()
                    if (scaled != null) {
                        artUriCache.put(uriString, scaled)
                        if (currentTrackIdentity == expectedIdentity || _state.value.coverBitmap == null) {
                            currentCoverSignature = computeBitmapSignature(scaled)
                            _state.value = _state.value.copy(coverBitmap = scaled)
                        }
                    }
                }
            } catch (_: Exception) {
            }
        }
    }

    fun updatePlayingFlag(isPlaying: Boolean) {
        val cur = _state.value
        val now = SystemClock.elapsedRealtime()
        if (isPlaying) {
            if (dismissedTrackIdentity.isNotEmpty() && (now - dismissedAtRealtime) < 2500L) {
                return
            }
            dismissedTrackIdentity = ""
            lastPausedRealtime = 0L
            if (!cur.isPlaying) {
                if (cur.basePositionMs <= 0L) {
                    trackStartRealtime = now
                }
                _state.value = cur.copy(
                    hasActiveSession = true,
                    isPlaying = true,
                    baseElapsedRealtime = now
                )
            } else if (!cur.hasActiveSession) {
                _state.value = cur.copy(hasActiveSession = true)
            }
        } else {
            if (cur.isPlaying) {
                val (frozenPos, _) = getLivePositionAndDuration()
                lastPausedRealtime = now
                _state.value = cur.copy(
                    isPlaying = false,
                    basePositionMs = frozenPos,
                    baseElapsedRealtime = now
                )
            } else if (cur.hasActiveSession && lastPausedRealtime > 0L && (now - lastPausedRealtime) > 3 * 60 * 1000L) {
                // Если трек стоит на паузе дольше 3 минут — автоматически скрываем плеер
                _state.value = cur.copy(hasActiveSession = false)
            }
        }
    }

    /**
     * Сверхлёгкий опрос активного MediaController раз в секунду:
     * Сверяет название трека и сигнатуру обложки (включая HARDWARE Bitmap от Spotify!).
     */
    fun pollActiveControllerLight() {
        val ctrl = activeController ?: return
        try {
            val meta = ctrl.metadata
            val pb = ctrl.playbackState
            val cur = _state.value
            val pkg = ctrl.packageName ?: cur.sourcePackage

            var title = ""
            var artist = ""
            var dur = -1L
            var artUri = ""
            var newCover: Bitmap? = null
            var newSig = 0

            if (meta != null) {
                title = meta.getString(MediaMetadata.METADATA_KEY_TITLE)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
                    ?: ""
                artist = meta.getString(MediaMetadata.METADATA_KEY_ARTIST)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
                    ?: ""
                val d = meta.getLong(MediaMetadata.METADATA_KEY_DURATION)
                if (d > 0L) dur = d

                artUri = meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_ART_URI)
                    ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)
                    ?: ""

                val rawArt = meta.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                    ?: meta.getBitmap(MediaMetadata.METADATA_KEY_ART)
                    ?: meta.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                if (rawArt != null) {
                    val sig = computeBitmapSignature(rawArt)
                    val candidateIdentity = "$pkg|${title.ifEmpty { cur.title }}"
                    val isDifferentTrack = title.isNotBlank() && candidateIdentity != currentTrackIdentity
                    if (sig != 0 && (sig != currentCoverSignature || cur.coverBitmap == null || isDifferentTrack)) {
                        newCover = safeScaleBitmap(rawArt)
                        newSig = sig
                    }
                }
            }

            var pos = -1L
            var posTime = 0L
            var spd = 1.0f
            var explicitPlaying: Boolean? = null
            if (pb != null) {
                pos = pb.position
                posTime = pb.lastPositionUpdateTime
                spd = pb.playbackSpeed
                val state = pb.state
                if (state == PlaybackState.STATE_PLAYING) {
                    explicitPlaying = true
                    updatePlayingFlag(true)
                } else if (state == PlaybackState.STATE_PAUSED) {
                    explicitPlaying = false
                    updatePlayingFlag(false)
                } else if (state == PlaybackState.STATE_STOPPED ||
                    state == PlaybackState.STATE_NONE ||
                    state == PlaybackState.STATE_ERROR
                ) {
                    explicitPlaying = false
                    _state.value = _state.value.copy(hasActiveSession = false, isPlaying = false)
                    return
                }
            }

            if (title.isNotEmpty() || artist.isNotEmpty() || newCover != null || artUri.isNotEmpty() || pos >= 0L) {
                updateMetadata(
                    title = title,
                    artist = artist,
                    sourcePackage = pkg,
                    sourceAppName = "",
                    cover = newCover,
                    coverSignature = newSig,
                    artUri = artUri,
                    durationMs = dur,
                    positionMs = pos,
                    positionUpdateRealtime = posTime,
                    speed = spd,
                    explicitIsPlaying = explicitPlaying
                )
            }
        } catch (_: Exception) {
        }
    }

    fun getLivePositionAndDuration(): Pair<Long, Long> {
        val snap = _state.value
        val now = SystemClock.elapsedRealtime()
        val ctrl = activeController

        var dur = snap.durationMs.coerceAtLeast(0L)
        if (ctrl != null) {
            try {
                val metaDur = ctrl.metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
                if (metaDur > 0L) dur = metaDur
            } catch (_: Exception) {
            }
        }

        // Если трек стоит на ПАУЗЕ — секунды стоят колом на замороженной отметке basePositionMs!
        if (!snap.isPlaying) {
            val frozen = if (dur > 0L) snap.basePositionMs.coerceIn(0L, dur) else snap.basePositionMs.coerceAtLeast(0L)
            return frozen to dur
        }

        if (ctrl != null) {
            try {
                val pb = ctrl.playbackState
                if (pb != null && pb.position >= 0L) {
                    val lastUpdate = pb.lastPositionUpdateTime
                    if (lastUpdate >= trackStartRealtime - 2000L) {
                        var pos = pb.position
                        if (pb.state == PlaybackState.STATE_PLAYING && lastUpdate > 0L) {
                            val delta = (now - lastUpdate).coerceAtLeast(0L)
                            pos += (delta * pb.playbackSpeed).toLong().coerceAtLeast(0L)
                        }
                        if (dur > 0L && pos > dur) {
                            pos = (now - trackStartRealtime).coerceIn(0L, dur)
                        }
                        return pos.coerceAtLeast(0L) to dur
                    }
                }
            } catch (_: Exception) {
            }
        }

        if (snap.basePositionMs > 0L && snap.baseElapsedRealtime >= trackStartRealtime - 2000L) {
            val delta = (now - snap.baseElapsedRealtime).coerceAtLeast(0L)
            var pos = snap.basePositionMs + (delta * snap.playbackSpeed).toLong().coerceAtLeast(0L)
            if (dur > 0L) pos = pos.coerceAtMost(dur)
            return pos to dur
        }

        var elapsed = (now - trackStartRealtime).coerceAtLeast(0L)
        if (dur > 0L) elapsed = elapsed.coerceAtMost(dur)
        return elapsed to dur
    }

    fun dispatchTransportAction(action: String, audioManager: AudioManager) {
        val ctrl = activeController
        try {
            if (ctrl != null) {
                val tc = ctrl.transportControls
                val pbState = ctrl.playbackState?.state
                when (action) {
                    "PREV" -> {
                        tc.skipToPrevious()
                        return
                    }
                    "NEXT" -> {
                        tc.skipToNext()
                        return
                    }
                    "PLAY_PAUSE" -> {
                        if (pbState == PlaybackState.STATE_PLAYING || _state.value.isPlaying) {
                            tc.pause()
                            updatePlayingFlag(false)
                        } else {
                            dismissedTrackIdentity = ""
                            tc.play()
                            updatePlayingFlag(true)
                        }
                        return
                    }
                }
            }
        } catch (_: Exception) {
        }

        val keyCode = when (action) {
            "PREV" -> KeyEvent.KEYCODE_MEDIA_PREVIOUS
            "NEXT" -> KeyEvent.KEYCODE_MEDIA_NEXT
            else -> KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE
        }
        try {
            val now = SystemClock.uptimeMillis()
            audioManager.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_DOWN, keyCode, 0))
            audioManager.dispatchMediaKeyEvent(KeyEvent(now, now, KeyEvent.ACTION_UP, keyCode, 0))
            if (action == "PLAY_PAUSE") {
                val targetPlay = !_state.value.isPlaying
                if (targetPlay) dismissedTrackIdentity = ""
                updatePlayingFlag(targetPlay)
            }
        } catch (_: Exception) {
        }
    }
}

object KeyCaptureBus {
    @Volatile
    var isCapturingKey: Boolean = false

    @Volatile
    var onKeyCapturedListener: ((keyCode: Int, scanCode: Int) -> Unit)? = null

    private val mainHandler = Handler(Looper.getMainLooper())

    fun notifyKeyCaptured(keyCode: Int, scanCode: Int): Boolean {
        val listener = onKeyCapturedListener ?: return false
        isCapturingKey = false
        mainHandler.post {
            listener.invoke(keyCode, scanCode)
        }
        return true
    }
}

class KeyMapperAccessibilityService : AccessibilityService() {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var lastInterceptMillis: Long = 0L
    private var lastSessionToken: MediaSession.Token? = null
    private var currentControllerCallback: MediaController.Callback? = null

    private var overlayWindowManager: WindowManager? = null
    private var volumeOverlayRoot: FrameLayout? = null
    private var volumeOverlayParams: WindowManager.LayoutParams? = null
    private var tvOverlayPct: TextView? = null
    private var flOverlayTrack: FrameLayout? = null
    private var vOverlayFill: View? = null
    private var ivOverlayIcon: ImageView? = null
    private var isVolumeReceiverRegistered = false

    private val hideOverlayRunnable = Runnable {
        volumeOverlayRoot?.visibility = View.GONE
    }

    private val systemVolumeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            VolumeHudBus.dismissStockSystemVolumeUi(this@KeyMapperAccessibilityService)
            mainHandler.post {
                showAccessibilityVolumeOverlay()
                VolumeHudBus.notifyVolumeChanged()
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        ensureServiceInitialized()
    }

    private fun ensureServiceInitialized() {
        try {
            val info = serviceInfo
            if (info != null && (info.flags and AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS) == 0) {
                info.flags = info.flags or AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS
                serviceInfo = info
            }
        } catch (_: Exception) {
        }

        if (volumeOverlayRoot == null) {
            setupAccessibilityVolumeOverlay()
        }

        if (!isVolumeReceiverRegistered) {
            try {
                val filter = IntentFilter("android.media.VOLUME_CHANGED_ACTION")
                ContextCompat.registerReceiver(
                    this,
                    systemVolumeReceiver,
                    filter,
                    ContextCompat.RECEIVER_EXPORTED
                )
                isVolumeReceiverRegistered = true
            } catch (_: Exception) {
            }
        }
    }

    override fun onDestroy() {
        if (isVolumeReceiverRegistered) {
            try {
                unregisterReceiver(systemVolumeReceiver)
            } catch (_: Exception) {
            }
            isVolumeReceiverRegistered = false
        }
        removeAccessibilityVolumeOverlay()
        super.onDestroy()
    }

    private fun setupAccessibilityVolumeOverlay() {
        if (volumeOverlayRoot != null) return
        try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
            overlayWindowManager = wm
            val dp = resources.displayMetrics.density
            fun dpPx(v: Int): Int = (v * dp + 0.5f).toInt()

            val rootMask = FrameLayout(this).apply {
                // 100% НЕПРОЗРАЧНЫЙ графитовый фон (#FF08080A), ни один пиксель белого ползунка не просветит!
                setBackgroundColor(Color.parseColor("#FF08080A"))
                setPadding(dpPx(14), dpPx(24), dpPx(14), dpPx(24))
                visibility = View.GONE
            }

            val pillBg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 26f * dp
                setColor(Color.parseColor("#FF0E1015"))
                setStroke(dpPx(2), Color.parseColor("#00F0FF"))
            }

            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_HORIZONTAL
                background = pillBg
                setPadding(0, dpPx(18), 0, dpPx(18))
                layoutParams = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    FrameLayout.LayoutParams.MATCH_PARENT
                )
            }

            val pctText = TextView(this).apply {
                text = "40%"
                typeface = Typeface.MONOSPACE
                gravity = Gravity.CENTER
                setTextColor(Color.parseColor("#00F0FF"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                layoutParams = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
            }

            val trackBg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 4f * dp
                setColor(Color.parseColor("#FF1F2229"))
            }

            val trackLayout = FrameLayout(this).apply {
                background = trackBg
                layoutParams = LinearLayout.LayoutParams(dpPx(8), 0, 1f).apply {
                    topMargin = dpPx(14)
                    bottomMargin = dpPx(14)
                }
            }

            val fillBg = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 4f * dp
                setColor(Color.parseColor("#00F0FF"))
            }

            val fillView = View(this).apply {
                background = fillBg
                layoutParams = FrameLayout.LayoutParams(
                    FrameLayout.LayoutParams.MATCH_PARENT,
                    dpPx(80),
                    Gravity.BOTTOM
                )
            }
            trackLayout.addView(fillView)

            val iconView = ImageView(this).apply {
                setImageResource(R.drawable.ic_volume_24)
                setColorFilter(Color.parseColor("#00F0FF"), PorterDuff.Mode.SRC_IN)
                layoutParams = LinearLayout.LayoutParams(dpPx(22), dpPx(22))
            }

            card.addView(pctText)
            card.addView(trackLayout)
            card.addView(iconView)
            rootMask.addView(card)

            val lp = WindowManager.LayoutParams(
                dpPx(96),
                dpPx(360),
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                x = 0
                y = 0
            }

            wm.addView(rootMask, lp)
            volumeOverlayRoot = rootMask
            volumeOverlayParams = lp
            tvOverlayPct = pctText
            flOverlayTrack = trackLayout
            vOverlayFill = fillView
            ivOverlayIcon = iconView
        } catch (_: Exception) {
        }
    }

    private fun removeAccessibilityVolumeOverlay() {
        val root = volumeOverlayRoot ?: return
        try {
            overlayWindowManager?.removeViewImmediate(root)
        } catch (_: Exception) {
        }
        volumeOverlayRoot = null
    }

    private fun showAccessibilityVolumeOverlay() {
        if (volumeOverlayRoot == null) {
            setupAccessibilityVolumeOverlay()
        }
        val root = volumeOverlayRoot ?: return
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val isMuted = try {
                am.isStreamMute(AudioManager.STREAM_MUSIC)
            } catch (_: Exception) {
                false
            }
            val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            val curVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            val pct = if (isMuted) 0 else ((curVol * 100f) / maxVol).toInt().coerceIn(0, 100)

            val activeColor = if (pct > 0) Color.parseColor("#00F0FF") else Color.parseColor("#FF5252")
            tvOverlayPct?.text = "$pct%"
            tvOverlayPct?.setTextColor(activeColor)
            ivOverlayIcon?.setColorFilter(activeColor, PorterDuff.Mode.SRC_IN)

            root.visibility = View.VISIBLE
            root.bringToFront()
            volumeOverlayParams?.let { lp ->
                try {
                    overlayWindowManager?.updateViewLayout(root, lp)
                } catch (_: Exception) {
                }
            }

            flOverlayTrack?.post {
                val trackH = (flOverlayTrack?.height ?: 0).coerceAtLeast(120)
                val fillH = ((trackH * pct) / 100).coerceAtLeast(if (pct > 0) 8 else 0)
                val fill = vOverlayFill ?: return@post
                val flp = fill.layoutParams as FrameLayout.LayoutParams
                flp.height = fillH
                flp.gravity = Gravity.BOTTOM
                fill.layoutParams = flp
            }

            mainHandler.removeCallbacks(hideOverlayRunnable)
            mainHandler.postDelayed(hideOverlayRunnable, 2800L)
        } catch (_: Exception) {
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        ensureServiceInitialized()
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return

        // Если SystemUI пытается открыть системный диалог громкости — тут же гасим его!
        if (pkg == "com.android.systemui" && event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            val cls = event.className?.toString()?.lowercase().orEmpty()
            if (cls.contains("volume")) {
                VolumeHudBus.dismissStockSystemVolumeUi(this)
                mainHandler.post { showAccessibilityVolumeOverlay() }
                return
            }
        }

        if (event.eventType == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            val notif = event.parcelableData as? Notification
            if (notif != null && pkg != packageName) {
                extractMediaFromNotificationLight(pkg, notif)
            }
            return
        }

        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && pkg != packageName) {
            val prefs = getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            val matchedPresetTarget: String? = when {
                isNetflixPackage(pkg) -> prefs.getString("preset_bind_NETFLIX", null)
                isPrimePackage(pkg) -> prefs.getString("preset_bind_PRIME", null)
                isPatchwallPackage(pkg) -> prefs.getString("preset_bind_PATCHWALL", null)
                else -> null
            }

            if (!matchedPresetTarget.isNullOrEmpty()) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastInterceptMillis > 600L) {
                    lastInterceptMillis = now
                    executeBoundAction(matchedPresetTarget)
                }
            }
        }
    }

    /**
     * Жёсткий фильтр: пропускает ТОЛЬКО настоящие медиа-уведомления и отсекает системный мусор!
     */
    private fun isRealMediaNotification(pkg: String, notif: Notification, sessionToken: MediaSession.Token?): Boolean {
        if (sessionToken != null) return true
        val p = pkg.lowercase()
        // Отсекаем системные пакеты, если у них нет MediaSession.Token
        if (p == "android" ||
            p.startsWith("com.android.systemui") ||
            p.startsWith("com.google.android.gms") ||
            p.startsWith("com.android.vending") ||
            p.startsWith("com.android.packageinstaller") ||
            p.startsWith("com.google.android.packageinstaller") ||
            p.startsWith("com.android.settings") ||
            p.startsWith("com.xiaomi.mitv.settings")
        ) {
            return false
        }
        if (notif.category == Notification.CATEGORY_TRANSPORT) return true
        val template = notif.extras?.getString(Notification.EXTRA_TEMPLATE).orEmpty()
        if (template.contains("MediaStyle", ignoreCase = true)) return true

        return p.contains("spotify") ||
            p.contains("soundcloud") ||
            p.contains("mediashell") ||
            p.contains("chromecast") ||
            p.contains("youtube") ||
            p.contains("music") ||
            p.contains("audio") ||
            p.contains("player") ||
            p.contains("vlc") ||
            p.contains("kodi") ||
            p.contains("plex") ||
            p.contains("deezer") ||
            p.contains("yandex") ||
            p.contains("vk") ||
            p.contains("aimp")
    }

    private fun extractMediaFromNotificationLight(pkg: String, notif: Notification) {
        try {
            val extras = notif.extras ?: return
            @Suppress("DEPRECATION")
            val sessionToken = extras.getParcelable<Parcelable>(Notification.EXTRA_MEDIA_SESSION) as? MediaSession.Token

            // Игнорируем все не-медийные системные уведомления (чтобы плеер не появлялся на старте и не сбивал Spotify!)
            if (!isRealMediaNotification(pkg, notif, sessionToken)) return

            var title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
            var text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()?.trim().orEmpty()
            val appName = resolveAppLabel(pkg)

            // Привязываем новый MediaController ТОЛЬКО когда пришёл реальный sessionToken (никогда не убиваем живой контроллер пустыми уведомлениями!)
            if (sessionToken != null && sessionToken != lastSessionToken) {
                lastSessionToken = sessionToken
                val controller = MediaController(this, sessionToken)
                attachControllerCallback(pkg, appName, controller)
            }

            var explicitPlaying: Boolean? = detectPlayPauseFromNotificationActions(notif)

            val ctrl = MediaStateBus.activeController
            var durationMs = -1L
            var posMs = -1L
            var posRealtime = 0L
            var speed = 1.0f
            var artUri = ""

            if (ctrl != null) {
                val meta = ctrl.metadata
                if (meta != null) {
                    val metaTitle = meta.getString(MediaMetadata.METADATA_KEY_TITLE)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
                    val metaArtist = meta.getString(MediaMetadata.METADATA_KEY_ARTIST)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
                    if (!metaTitle.isNullOrBlank()) title = metaTitle
                    if (!metaArtist.isNullOrBlank()) text = metaArtist

                    val d = meta.getLong(MediaMetadata.METADATA_KEY_DURATION)
                    if (d > 0L) durationMs = d

                    artUri = meta.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_ART_URI)
                        ?: meta.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)
                        ?: ""
                }

                val pb = ctrl.playbackState
                if (pb != null) {
                    posMs = pb.position
                    posRealtime = pb.lastPositionUpdateTime
                    speed = pb.playbackSpeed
                    val st = pb.state
                    if (st == PlaybackState.STATE_PLAYING) {
                        explicitPlaying = true
                        MediaStateBus.updatePlayingFlag(true)
                    } else if (st == PlaybackState.STATE_PAUSED || st == PlaybackState.STATE_STOPPED) {
                        explicitPlaying = false
                        MediaStateBus.updatePlayingFlag(false)
                    }
                }
            }

            var rawCandidate: Bitmap? = null
            if (ctrl != null) {
                val meta = ctrl.metadata
                rawCandidate = meta?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                    ?: meta?.getBitmap(MediaMetadata.METADATA_KEY_ART)
                    ?: meta?.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
            }

            if (rawCandidate == null) {
                @Suppress("DEPRECATION")
                rawCandidate = (extras.getParcelable<Parcelable>(Notification.EXTRA_LARGE_ICON_BIG) as? Bitmap)
                    ?: (extras.getParcelable<Parcelable>(Notification.EXTRA_LARGE_ICON) as? Bitmap)
                    ?: (extras.getParcelable<Parcelable>(Notification.EXTRA_PICTURE) as? Bitmap)
            }

            if (rawCandidate == null) {
                val largeIcon = notif.getLargeIcon()
                if (largeIcon != null) {
                    val d = largeIcon.loadDrawable(this)
                    if (d is BitmapDrawable && d.bitmap != null) {
                        rawCandidate = d.bitmap
                    } else if (d != null) {
                        rawCandidate = drawableToSmallBitmap(d)
                    }
                }
            }

            var scaledCover: Bitmap? = null
            var candidateSig = 0
            if (rawCandidate != null) {
                candidateSig = MediaStateBus.computeBitmapSignature(rawCandidate)
                val currentCover = MediaStateBus.state.value.coverBitmap
                if (candidateSig != 0 && candidateSig == MediaStateBus.getCurrentCoverSignature() && currentCover != null) {
                    scaledCover = currentCover
                } else {
                    scaledCover = MediaStateBus.safeScaleBitmap(rawCandidate)
                }
            }

            if (title.isEmpty() && text.isEmpty() && scaledCover == null && artUri.isEmpty()) return

            MediaStateBus.updateMetadata(
                title = title,
                artist = text,
                sourcePackage = pkg,
                sourceAppName = appName,
                cover = scaledCover,
                coverSignature = candidateSig,
                artUri = artUri,
                durationMs = durationMs,
                positionMs = posMs,
                positionUpdateRealtime = posRealtime,
                speed = speed,
                explicitIsPlaying = explicitPlaying
            )
        } catch (_: Exception) {
        }
    }

    private fun detectPlayPauseFromNotificationActions(notif: Notification): Boolean? {
        try {
            val actions = notif.actions ?: return null
            for (action in actions) {
                val label = action.title?.toString()?.lowercase()?.trim() ?: continue
                if (label == "pause" || label == "пауза" || label.contains("pause") || label.contains("пауз")) {
                    MediaStateBus.updatePlayingFlag(true)
                    return true
                }
                if (label == "play" || label == "воспроизвести" || label.contains("play") || label.contains("воспр")) {
                    MediaStateBus.updatePlayingFlag(false)
                    return false
                }
            }
        } catch (_: Exception) {
        }
        return null
    }

    private fun detachActiveController() {
        val prev = MediaStateBus.activeController
        val prevCb = currentControllerCallback
        if (prev != null && prevCb != null) {
            try {
                prev.unregisterCallback(prevCb)
            } catch (_: Exception) {
            }
        }
        MediaStateBus.activeController = null
        currentControllerCallback = null
        lastSessionToken = null
    }

    private fun attachControllerCallback(pkg: String, appName: String, controller: MediaController) {
        try {
            detachActiveController()
            MediaStateBus.activeController = controller
            val cb = object : MediaController.Callback() {
                override fun onPlaybackStateChanged(state: PlaybackState?) {
                    if (state != null) {
                        val playing = state.state == PlaybackState.STATE_PLAYING
                        MediaStateBus.updatePositionOnly(
                            positionMs = state.position,
                            positionUpdateRealtime = state.lastPositionUpdateTime,
                            speed = state.playbackSpeed,
                            isPlaying = playing
                        )
                    }
                }

                override fun onMetadataChanged(metadata: MediaMetadata?) {
                    if (metadata != null) {
                        val t = (metadata.getString(MediaMetadata.METADATA_KEY_TITLE)
                            ?: metadata.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)).orEmpty()
                        val a = (metadata.getString(MediaMetadata.METADATA_KEY_ARTIST)
                            ?: metadata.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST)
                            ?: metadata.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)).orEmpty()
                        val dur = metadata.getLong(MediaMetadata.METADATA_KEY_DURATION)
                        val art = metadata.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                            ?: metadata.getBitmap(MediaMetadata.METADATA_KEY_ART)
                            ?: metadata.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
                        var sig = 0
                        val scaled = if (art != null) {
                            sig = MediaStateBus.computeBitmapSignature(art)
                            val curBmp = MediaStateBus.state.value.coverBitmap
                            if (sig != 0 && sig == MediaStateBus.getCurrentCoverSignature() && curBmp != null) {
                                curBmp
                            } else {
                                MediaStateBus.safeScaleBitmap(art)
                            }
                        } else null
                        val uri = metadata.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
                            ?: metadata.getString(MediaMetadata.METADATA_KEY_ART_URI)
                            ?: metadata.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)
                            ?: ""
                        val isCtrlPlaying = controller.playbackState?.state == PlaybackState.STATE_PLAYING
                        MediaStateBus.updateMetadata(
                            title = t,
                            artist = a,
                            sourcePackage = pkg,
                            sourceAppName = appName,
                            cover = scaled,
                            coverSignature = sig,
                            artUri = uri,
                            durationMs = if (dur > 0L) dur else -1L,
                            explicitIsPlaying = if (controller.playbackState != null) isCtrlPlaying else null
                        )
                    }
                }
            }
            currentControllerCallback = cb
            controller.registerCallback(cb, Handler(Looper.getMainLooper()))
        } catch (_: Exception) {
        }
    }

    private fun drawableToSmallBitmap(d: Drawable): Bitmap? {
        return try {
            if (d is BitmapDrawable && d.bitmap != null) {
                MediaStateBus.safeScaleBitmap(d.bitmap)
            } else {
                val bmp = Bitmap.createBitmap(112, 112, Bitmap.Config.ARGB_8888)
                val canvas = Canvas(bmp)
                d.setBounds(0, 0, 112, 112)
                d.draw(canvas)
                bmp
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun resolveAppLabel(pkg: String): String {
        return try {
            val ai = packageManager.getApplicationInfo(pkg, 0)
            packageManager.getApplicationLabel(ai).toString()
        } catch (_: Exception) {
            pkg.substringAfterLast('.')
        }
    }

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        ensureServiceInitialized()
        val keyCode = event.keyCode
        val scanCode = event.scanCode

        if (KeyCaptureBus.isCapturingKey) {
            if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
                return false
            }
            if (isNavigationOrCenterKey(keyCode)) {
                return false
            }
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                KeyCaptureBus.notifyKeyCaptured(keyCode, scanCode)
            }
            return true
        }

        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
            keyCode == KeyEvent.KEYCODE_VOLUME_DOWN ||
            keyCode == KeyEvent.KEYCODE_VOLUME_MUTE
        ) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                try {
                    val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    when (keyCode) {
                        KeyEvent.KEYCODE_VOLUME_UP ->
                            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0)
                        KeyEvent.KEYCODE_VOLUME_DOWN ->
                            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0)
                        KeyEvent.KEYCODE_VOLUME_MUTE ->
                            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, 0)
                    }
                    VolumeHudBus.dismissStockSystemVolumeUi(this)
                    mainHandler.post {
                        showAccessibilityVolumeOverlay()
                    }
                    VolumeHudBus.notifyVolumeChanged()
                } catch (_: Exception) {
                }
            }
            return true
        }

        if (isNavigationOrCenterKey(keyCode)) {
            return false
        }

        val prefs = getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)

        if (keyCode == KeyEvent.KEYCODE_VOICE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_SEARCH
        ) {
            val customAssistTarget = prefs.getString("key_bind_$keyCode", null) ?: "ACTION_AI"
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                executeBoundAction(customAssistTarget)
            }
            return true
        }

        val presetTarget = resolvePresetBinding(prefs, keyCode, scanCode)
        if (!presetTarget.isNullOrEmpty()) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                executeBoundAction(presetTarget)
            }
            return true
        }

        val boundTarget = prefs.getString("key_bind_$keyCode", null)
            ?: if (scanCode > 0) prefs.getString("scan_bind_$scanCode", null) else null

        if (boundTarget.isNullOrEmpty()) {
            return false
        }

        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            executeBoundAction(boundTarget)
        }
        return true
    }

    private fun resolvePresetBinding(
        prefs: android.content.SharedPreferences,
        keyCode: Int,
        scanCode: Int
    ): String? {
        if (keyCode == KeyEvent.KEYCODE_ALL_APPS ||
            keyCode == KeyEvent.KEYCODE_MENU ||
            keyCode == KeyEvent.KEYCODE_GUIDE ||
            keyCode == KeyEvent.KEYCODE_SETTINGS ||
            keyCode == KeyEvent.KEYCODE_TV_INPUT ||
            keyCode == KeyEvent.KEYCODE_BUTTON_1 ||
            scanCode == 139 || scanCode == 362 || scanCode == 172 || scanCode == 256
        ) {
            prefs.getString("preset_bind_PATCHWALL", null)?.let { if (it.isNotEmpty()) return it }
        }

        if (keyCode == KeyEvent.KEYCODE_BUTTON_2 ||
            keyCode == KeyEvent.KEYCODE_PROG_RED ||
            scanCode == 412 || scanCode == 398 || keyCode == 309
        ) {
            prefs.getString("preset_bind_NETFLIX", null)?.let { if (it.isNotEmpty()) return it }
        }

        if (keyCode == KeyEvent.KEYCODE_BUTTON_3 ||
            keyCode == KeyEvent.KEYCODE_PROG_BLUE ||
            scanCode == 413 || scanCode == 401 || keyCode == 310
        ) {
            prefs.getString("preset_bind_PRIME", null)?.let { if (it.isNotEmpty()) return it }
        }

        return null
    }

    private fun isNetflixPackage(pkg: String): Boolean = pkg.lowercase().contains("netflix")

    private fun isPrimePackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("amazonvideo") || p.contains("amazon.avod") || p.contains("primevideo")
    }

    private fun isPatchwallPackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("patchwall") || p.contains("mitv.tvhome") || p.contains("mitv.smartshare")
    }

    private fun isNavigationOrCenterKey(keyCode: Int): Boolean {
        return keyCode == KeyEvent.KEYCODE_DPAD_UP ||
            keyCode == KeyEvent.KEYCODE_DPAD_DOWN ||
            keyCode == KeyEvent.KEYCODE_DPAD_LEFT ||
            keyCode == KeyEvent.KEYCODE_DPAD_RIGHT ||
            keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
            keyCode == KeyEvent.KEYCODE_ENTER ||
            keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER ||
            keyCode == KeyEvent.KEYCODE_HOME
    }

    private fun executeBoundAction(target: String) {
        when (target) {
            "ACTION_ALL_APPS" -> {
                val intent = Intent(this, LauncherActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("EXTRA_OPEN_ALL_APPS", true)
                }
                startActivity(intent)
            }
            "ACTION_SETTINGS" -> {
                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    startActivity(intent)
                } catch (_: Exception) {
                }
            }
            "ACTION_AI" -> {
                val intent = Intent(this, LauncherActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("EXTRA_OPEN_AI", true)
                }
                startActivity(intent)
            }
            else -> {
                val pm = packageManager
                val launchIntent = pm.getLeanbackLaunchIntentForPackage(target)
                    ?: pm.getLaunchIntentForPackage(target)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        startActivity(launchIntent)
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }
}
