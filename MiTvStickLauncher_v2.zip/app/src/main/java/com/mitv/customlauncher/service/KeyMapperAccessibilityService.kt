package com.mitv.customlauncher.service

import android.Manifest
import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.animation.ValueAnimator
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.PorterDuff
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.SoundPool
import android.media.MediaMetadata
import android.media.MediaRecorder
import android.media.session.MediaController
import android.media.session.MediaSession
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Parcelable
import android.os.SystemClock
import android.provider.Settings
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.TextUtils
import android.util.Log
import android.util.LruCache
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.content.ClipData
import android.content.ClipboardManager
import java.util.Locale
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import com.mitv.customlauncher.R
import com.mitv.customlauncher.data.AssistantVoiceSpeaker
import com.mitv.customlauncher.data.GeminiCloudClient
import com.mitv.customlauncher.data.GeminiTurnResult
import com.mitv.customlauncher.data.LauncherConfig
import com.mitv.customlauncher.data.NativeCore
import com.mitv.customlauncher.ui.MotionPhysics
import com.mitv.customlauncher.data.LocalVoiceCommandRouter
import com.mitv.customlauncher.ui.EchoView
import com.mitv.customlauncher.ui.LauncherActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import org.json.JSONObject
import android.net.wifi.WifiManager
import android.os.PowerManager
import java.net.InetAddress
import java.net.InetSocketAddress
import com.mitv.customlauncher.data.TuyaSmartHomeController
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.HttpURLConnection
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder
import java.net.URLEncoder
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.sin
import kotlin.math.sqrt


class MediaSessionListenerService : NotificationListenerService() {

    companion object {
        @Volatile
        var instance: MediaSessionListenerService? = null
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        instance = this
        pollActiveMediaNotifications(this)
        MediaStateBus.queryMediaSessionManagerDirect(this)
    }

    override fun onListenerDisconnected() {
        instance = null
        super.onListenerDisconnected()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            try {
                requestRebind(ComponentName(this, MediaSessionListenerService::class.java))
            } catch (_: Exception) {
            }
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        instance = this
        if (sbn == null) return
        val pkg = sbn.packageName ?: return
        if (pkg == packageName) return
        val notif = sbn.notification ?: return
        MediaStateBus.ingestNotification(this, pkg, notif, requireActivePlaybackOrSession = false)
    }

    fun pollActiveMediaNotifications(context: Context) {
        try {
            val list = activeNotifications ?: return
            for (sbn in list) {
                val pkg = sbn.packageName ?: continue
                if (pkg == context.packageName) continue
                val notif = sbn.notification ?: continue
                MediaStateBus.ingestNotification(context, pkg, notif, requireActivePlaybackOrSession = true)
            }
        } catch (_: Exception) {
        }
    }
}

class KeyMapperAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile
        var isServiceConnectedAlive: Boolean = false
    }

    private var lastInterceptMillis: Long = 0L
    private val uiHandler = Handler(Looper.getMainLooper())
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val decelerateInterpolator = DecelerateInterpolator()

    private var windowManager: WindowManager? = null
    private var overlayHudRoot: LinearLayout? = null
    private var overlayHudIcon: ImageView? = null
    private var overlayHudTrack: FrameLayout? = null
    private var overlayHudFill: View? = null
    private var overlayHudPct: TextView? = null
    private var overlayControlCenter: OverlayControlCenterController? = null
    private var lastKnownVolumePct: Int = -1
    private var receiversRegistered: Boolean = false

    private var islandLayoutParams: WindowManager.LayoutParams? = null
    private var islandRoot: LinearLayout? = null
    private var islandBgDrawable: GradientDrawable? = null
    private var islandLastStrokeColor: Int = 0
    private var islandHeaderRow: LinearLayout? = null
    private var islandEchoView: EchoView? = null
    private var islandStatusText: TextView? = null
    private var islandHintText: TextView? = null
    private var islandBodyText: TextView? = null
    private var islandMorphAnimator: ValueAnimator? = null
    private var islandVisible: Boolean = false
    private var islandIsListening: Boolean = false
    private var islandIsSpeaking: Boolean = false
    private var islandIsFollowUpListen: Boolean = false

    private var speechRecognizer: SpeechRecognizer? = null
    private var audioRecordJob: Job? = null
    private var geminiQueryJob: Job? = null
    private var lastPartialTranscript: String = ""

    private val hideOverlayRunnable = Runnable {
        val root = overlayHudRoot ?: return@Runnable
        root.animate()
            .alpha(0f)
            .setDuration(180L)
            .withEndAction { root.visibility = View.GONE }
            .start()
    }

    private val hideIslandRunnable = Runnable {
        collapseDynamicIsland()
    }

    @Volatile
    private var targetVoiceLevel: Float = 0.35f

    private val pulseWaveRunnable = object : Runnable {
        override fun run() {
            if (!islandVisible) return
            val echo = islandEchoView
            if (echo != null) {
                if (islandIsSpeaking || AssistantVoiceSpeaker.isSpeakingNow) {
                    if (echo.mood != EchoView.Mood.SPEAKING) {
                        echo.mood = EchoView.Mood.SPEAKING
                    }
                }
                if (islandIsListening || islandIsSpeaking || AssistantVoiceSpeaker.isSpeakingNow) {
                    uiHandler.postDelayed(this, 32L)
                }
            }
        }
    }

    private val globalMediaAndVolumeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val act = intent?.action ?: return
            if (act == "android.media.VOLUME_CHANGED_ACTION") {
                val streamType = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1)
                if (streamType == AudioManager.STREAM_MUSIC || streamType == -1) {
                    val pct = computeCurrentMusicVolumePct()
                    if (lastKnownVolumePct != -1 && pct != lastKnownVolumePct) {
                        lastKnownVolumePct = pct
                        showGlobalVolumeOverlay()
                        VolumeHudBus.notifyVolumeChanged()
                    } else if (lastKnownVolumePct == -1) {
                        lastKnownVolumePct = pct
                    }
                }
                return
            }

            MediaStateBus.handleMediaBroadcastIntent(this@KeyMapperAccessibilityService, intent)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        isServiceConnectedAlive = true
        try {
            val info = serviceInfo ?: AccessibilityServiceInfo()
            info.flags = info.flags or
                AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS or
                AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                AccessibilityServiceInfo.FLAG_INCLUDE_NOT_IMPORTANT_VIEWS or
                AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
            serviceInfo = info
        } catch (_: Exception) {
        }

        TvUiControllerBus.onScheduleInAppSearch = { targetPkg, query ->
            runAutomatedInAppSearch(targetPkg, query)
        }
        TvUiControllerBus.onScheduleYouTubeAutoPlay = { targetPkg, query ->
            runAutomatedYouTubeAutoPlay(targetPkg, query)
        }
        DynamicIslandBus.onShowAnnouncementInService = { displayText, speakText ->
            showGlobalReminderOrAnnouncement(displayText, speakText)
        }
        if (overlayControlCenter == null) {
            overlayControlCenter = OverlayControlCenterController(this)
        }
        DynamicIslandBus.onToggleControlCenterInService = {
            if (overlayControlCenter == null) {
                overlayControlCenter = OverlayControlCenterController(this)
            }
            overlayControlCenter?.toggle()
        }
        DynamicIslandBus.onHideControlCenterOverlayInService = {
            overlayControlCenter?.hide(immediate = true)
        }
        TvUiControllerBus.onTypeTextOnScreen = { text ->
            typeTextIntoActiveField(text)
        }
        TvUiControllerBus.onClickNodeByText = { text ->
            clickElementOnScreenByText(text)
        }
        TvUiControllerBus.onGlobalNavAction = { action ->
            performGlobalNavigationCommand(action)
        }
        TvUiControllerBus.onGetScreenSummary = {
            extractCleanScreenSummaryForAgent()
        }
        NavSoundPlayer.init(this)
        AssistantVoiceSpeaker.init(this)
        ServiceAutoActivator.ensureServicesActive(this)
        lastKnownVolumePct = computeCurrentMusicVolumePct()
        registerGlobalReceiversIfNeeded()
        ensureGlobalVolumeOverlayCreated()
        ensureDynamicIslandOverlayCreated()

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                val chanId = "mitv_remote_console_fg"
                val chan = NotificationChannel(chanId, "MiTV Remote Server", NotificationManager.IMPORTANCE_MIN).apply {
                    setShowBadge(false)
                }
                nm?.createNotificationChannel(chan)
                val notif = Notification.Builder(this, chanId)
                    .setContentTitle("Mi TV Stick Server")
                    .setContentText("Port 8765 active")
                    .setSmallIcon(R.drawable.ic_launcher_icon)
                    .build()
                startForeground(8765, notif)
            }
        } catch (_: Exception) {
        }
        RemoteConsoleServer.ensureStarted(this)
        TvUiControllerBus.onInjectDpadAction = { dir ->
            injectAccessibilityDpadOrCenter(dir)
        }
        DynamicIslandBus.onTriggerIslandInService = {
            triggerDynamicIslandAssistant()
        }
        DynamicIslandBus.onTriggerVoiceTextInService = { spokenText ->
            triggerDynamicIslandWithRemoteText(spokenText)
        }
        DynamicIslandBus.onAccentColorUpdated = {
            refreshOverlayAccentColors()
        }
        LocalVoiceCommandRouter.onVolumeChangedCallback = {
            showGlobalVolumeOverlay()
        }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        isServiceConnectedAlive = false
        DynamicIslandBus.onTriggerIslandInService = null
        cleanupGlobalOverlayAndReceivers()
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        isServiceConnectedAlive = false
        DynamicIslandBus.onTriggerIslandInService = null
        DynamicIslandBus.onToggleControlCenterInService = null
        DynamicIslandBus.onHideControlCenterOverlayInService = null
        overlayControlCenter?.destroy()
        overlayControlCenter = null
        cleanupGlobalOverlayAndReceivers()
        super.onDestroy()
    }

    private fun registerGlobalReceiversIfNeeded() {
        if (receiversRegistered) return
        try {
            val filter = IntentFilter().apply {
                addAction("android.media.VOLUME_CHANGED_ACTION")
                for (mediaAct in MediaStateBus.UNIVERSAL_MEDIA_BROADCAST_ACTIONS) {
                    addAction(mediaAct)
                }
            }
            ContextCompat.registerReceiver(
                this,
                globalMediaAndVolumeReceiver,
                filter,
                ContextCompat.RECEIVER_EXPORTED
            )
            receiversRegistered = true
        } catch (_: Exception) {
        }
    }

    private fun cleanupGlobalOverlayAndReceivers() {
        uiHandler.removeCallbacks(hideOverlayRunnable)
        uiHandler.removeCallbacks(hideIslandRunnable)
        uiHandler.removeCallbacks(pulseWaveRunnable)
        stopVoiceListeningInternal()
        if (receiversRegistered) {
            try {
                unregisterReceiver(globalMediaAndVolumeReceiver)
            } catch (_: Exception) {
            }
            receiversRegistered = false
        }
        val wm = windowManager
        val volRoot = overlayHudRoot
        if (wm != null && volRoot != null) {
            try {
                wm.removeViewImmediate(volRoot)
            } catch (_: Exception) {
            }
        }
        val islRoot = islandRoot
        if (wm != null && islRoot != null) {
            try {
                wm.removeViewImmediate(islRoot)
            } catch (_: Exception) {
            }
        }
        overlayHudRoot = null
        islandRoot = null
    }

    private fun dpPx(dpVal: Float): Int = (dpVal * resources.displayMetrics.density + 0.5f).toInt()

    private fun computeCurrentMusicVolumePct(): Int {
        return try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val isMuted = am.isStreamMute(AudioManager.STREAM_MUSIC)
            val maxVol = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            val curVol = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            if (isMuted) 0 else ((curVol * 100f) / maxVol).toInt().coerceIn(0, 100)
        } catch (_: Exception) {
            0
        }
    }

    private fun resolveCurrentAccentColor(): Int {
        return try {
            val prefs = getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            val hex = prefs.getString("pref_accent_color", "#00F0FF") ?: "#00F0FF"
            Color.parseColor(hex)
        } catch (_: Exception) {
            Color.parseColor("#00F0FF")
        }
    }

    private fun refreshOverlayAccentColors() {
        val accent = resolveCurrentAccentColor()
        overlayHudRoot?.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(999f).toFloat()
            setColor(Color.parseColor("#F20D0F14"))
            setStroke(dpPx(1.5f), ColorUtils.setAlphaComponent(accent, 160))
        }
        overlayHudFill?.background = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dpPx(999f).toFloat()
            setColor(accent)
        }
        overlayHudIcon?.setColorFilter(accent, PorterDuff.Mode.SRC_IN)
        overlayHudPct?.setTextColor(accent)

        islandEchoView?.accentColor = accent
        val echo = islandEchoView
        updateIslandStroke(
            level = echo?.level ?: 0f,
            isActiveVoice = echo?.mood == EchoView.Mood.LISTENING || echo?.mood == EchoView.Mood.SPEAKING,
            isError = echo?.mood == EchoView.Mood.ERROR,
            force = true
        )
    }

    private fun ensureGlobalVolumeOverlayCreated() {
        if (overlayHudRoot != null) return
        try {
            val wm = getSystemService(Context.WINDOW_SERVICE) as? WindowManager ?: return
            windowManager = wm
            val accent = resolveCurrentAccentColor()

            val root = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dpPx(18f), 0, dpPx(18f), 0)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpPx(999f).toFloat()
                    setColor(Color.parseColor("#F20D0F14"))
                    setStroke(dpPx(1.5f), ColorUtils.setAlphaComponent(accent, 160))
                }
                visibility = View.GONE
            }

            val icon = ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(dpPx(22f), dpPx(22f))
                setImageResource(R.drawable.ic_volume_24)
                setColorFilter(accent, PorterDuff.Mode.SRC_IN)
            }

            val track = FrameLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, dpPx(6f), 1f).apply {
                    marginStart = dpPx(14f)
                    marginEnd = dpPx(14f)
                }
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpPx(999f).toFloat()
                    setColor(Color.parseColor("#26FFFFFF"))
                }
            }

            val fill = View(this).apply {
                layoutParams = FrameLayout.LayoutParams(dpPx(80f), FrameLayout.LayoutParams.MATCH_PARENT)
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpPx(999f).toFloat()
                    setColor(accent)
                }
            }
            track.addView(fill)

            val pctText = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(dpPx(44f), LinearLayout.LayoutParams.WRAP_CONTENT)
                gravity = Gravity.END
                typeface = Typeface.MONOSPACE
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setTextColor(accent)
                text = "20%"
            }

            root.addView(icon)
            root.addView(track)
            root.addView(pctText)

            val lp = WindowManager.LayoutParams(
                dpPx(290f),
                dpPx(52f),
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.TOP or Gravity.END
                x = dpPx(54f)
                y = dpPx(34f)
            }

            wm.addView(root, lp)
            overlayHudRoot = root
            overlayHudIcon = icon
            overlayHudTrack = track
            overlayHudFill = fill
            overlayHudPct = pctText
        } catch (_: Exception) {
        }
    }

    private fun showGlobalVolumeOverlay() {
        uiHandler.post {
            ensureGlobalVolumeOverlayCreated()
            val root = overlayHudRoot ?: return@post
            val icon = overlayHudIcon ?: return@post
            val track = overlayHudTrack ?: return@post
            val fill = overlayHudFill ?: return@post
            val pctView = overlayHudPct ?: return@post

            val pct = computeCurrentMusicVolumePct()
            lastKnownVolumePct = pct
            val accent = resolveCurrentAccentColor()
            val activeColor = if (pct > 0) accent else Color.parseColor("#FF5252")

            root.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpPx(999f).toFloat()
                setColor(Color.parseColor("#F20D0F14"))
                setStroke(dpPx(1.5f), ColorUtils.setAlphaComponent(accent, 160))
            }
            pctView.text = "$pct%"
            pctView.setTextColor(activeColor)
            icon.setColorFilter(activeColor, PorterDuff.Mode.SRC_IN)
            fill.background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpPx(999f).toFloat()
                setColor(activeColor)
            }

            track.post {
                val totalW = track.width.coerceAtLeast(dpPx(140f))
                val fillW = ((totalW * pct) / 100).coerceAtLeast(if (pct > 0) dpPx(6f) else 0)
                val flp = fill.layoutParams
                if (flp.width != fillW) {
                    flp.width = fillW
                    fill.layoutParams = flp
                }
            }

            if (root.visibility != View.VISIBLE) {
                root.alpha = 0f
                root.visibility = View.VISIBLE
                root.animate().alpha(1f).setDuration(110L).start()
            } else {
                root.animate().cancel()
                root.alpha = 1f
            }

            uiHandler.removeCallbacks(hideOverlayRunnable)
            uiHandler.postDelayed(hideOverlayRunnable, 1600L)
        }
    }

    private fun updateIslandStroke(level: Float, isActiveVoice: Boolean, isError: Boolean, force: Boolean) {
        val drawable = islandBgDrawable ?: return
        val baseAlpha = 0.52f
        val alphaFloat = if (isActiveVoice) {
            (baseAlpha + (1f - baseAlpha) * 0.60f * level.coerceIn(0f, 1f)).coerceIn(baseAlpha, 1f)
        } else {
            baseAlpha
        }
        val baseRgb = if (isError) Color.parseColor("#FF5A5F") else resolveCurrentAccentColor()
        val strokeColor = ColorUtils.setAlphaComponent(baseRgb, (alphaFloat * 255f).toInt().coerceIn(0, 255))
        if (force || strokeColor != islandLastStrokeColor) {
            islandLastStrokeColor = strokeColor
            drawable.setStroke(dpPx(1.5f), strokeColor)
        }
    }

    private fun applyIslandShape(isExpandedCard: Boolean) {
        val root = islandRoot ?: return
        val bg = islandBgDrawable ?: return
        if (isExpandedCard) {
            bg.cornerRadius = dpPx(26f).toFloat()
            root.setPadding(dpPx(18f), dpPx(13f), dpPx(18f), dpPx(14f))
        } else {
            bg.cornerRadius = dpPx(999f).toFloat()
            root.setPadding(dpPx(14f), dpPx(9f), dpPx(20f), dpPx(9f))
        }
    }

    private fun ensureDynamicIslandOverlayCreated() {
        if (islandRoot != null) return
        try {
            val wm = (windowManager ?: getSystemService(Context.WINDOW_SERVICE) as? WindowManager) ?: return
            windowManager = wm
            val accent = resolveCurrentAccentColor()

            val bgDrawable = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = dpPx(999f).toFloat()
                setColor(Color.parseColor("#CC0D0F14"))
                val initStroke = ColorUtils.setAlphaComponent(accent, (0.52f * 255f).toInt())
                islandLastStrokeColor = initStroke
                setStroke(dpPx(1.5f), initStroke)
            }
            islandBgDrawable = bgDrawable

            val root = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dpPx(14f), dpPx(9f), dpPx(20f), dpPx(9f))
                background = bgDrawable
                visibility = View.GONE
            }

            val header = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }

            val echoView = EchoView(this).apply {
                layoutParams = LinearLayout.LayoutParams(dpPx(50f), dpPx(34f))
                accentColor = accent
                showRings = true
                mood = EchoView.Mood.IDLE
                levelProvider = {
                    when {
                        islandIsListening -> targetVoiceLevel
                        islandIsSpeaking || AssistantVoiceSpeaker.isSpeakingNow -> AssistantVoiceSpeaker.currentVoiceWaveLevel
                        else -> 0f
                    }
                }
                onFrameLevelUpdated = { lvl, isActive, isErr ->
                    updateIslandStroke(lvl, isActive, isErr, force = false)
                }
            }

            val statusTv = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = dpPx(10f)
                }
                setTextColor(Color.parseColor("#FFFFFF"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
                text = EchoView.listeningPhrase(false)
            }

            val hintTv = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    marginStart = dpPx(10f)
                }
                setPadding(dpPx(10f), dpPx(4f), dpPx(10f), dpPx(4f))
                background = GradientDrawable().apply {
                    shape = GradientDrawable.RECTANGLE
                    cornerRadius = dpPx(999f).toFloat()
                    setColor(Color.parseColor("#08FFFFFF"))
                    setStroke(dpPx(1f), Color.parseColor("#14FFFFFF"))
                }
                setTextColor(Color.parseColor("#99FFFFFF"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                text = "OK — ответить"
                visibility = View.GONE
            }

            header.addView(echoView)
            header.addView(statusTv)
            header.addView(hintTv)

            val bodyTv = TextView(this).apply {
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply {
                    topMargin = dpPx(8f)
                }
                setTextColor(Color.parseColor("#FFFFFF"))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14.5f)
                typeface = Typeface.create("sans-serif", Typeface.NORMAL)
                setLineSpacing(dpPx(2f).toFloat(), 1.08f)
                maxLines = 8
                ellipsize = TextUtils.TruncateAt.END
                visibility = View.GONE
            }

            root.addView(header)
            root.addView(bodyTv)

            root.setOnClickListener {
                if (islandIsListening) {
                    finishListeningAndProcess()
                } else if (islandIsSpeaking || AssistantVoiceSpeaker.isSpeakingNow) {
                    AssistantVoiceSpeaker.stop(this@KeyMapperAccessibilityService)
                    islandIsSpeaking = false
                    startFollowUpListeningTurn()
                } else {
                    collapseDynamicIsland()
                }
            }

            val lp = WindowManager.LayoutParams(
                dpPx(265f),
                ViewGroup.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = Gravity.BOTTOM or Gravity.START
                x = dpPx(54f)
                y = dpPx(38f)
            }

            wm.addView(root, lp)
            islandLayoutParams = lp
            islandRoot = root
            islandHeaderRow = header
            islandEchoView = echoView
            islandStatusText = statusTv
            islandHintText = hintTv
            islandBodyText = bodyTv
        } catch (_: Exception) {
        }
    }

    private fun morphDynamicIslandWidth(targetWidthDp: Float) {
        val wm = windowManager ?: return
        val root = islandRoot ?: return
        val lp = islandLayoutParams ?: return
        val endW = dpPx(targetWidthDp)

        islandMorphAnimator?.cancel()
        if (lp.width != endW) {
            val prevW = if (lp.width > 0) lp.width else dpPx(220f)
            lp.width = endW
            try {
                if (root.isAttachedToWindow) {
                    wm.updateViewLayout(root, lp)
                }
            } catch (_: Exception) {
            }
            root.pivotX = 0f
            root.pivotY = dpPx(26f).toFloat()
            val startScaleX = (prevW.toFloat() / endW.toFloat()).coerceIn(0.68f, 1.15f)
            root.animate().cancel()
            root.scaleX = startScaleX
            MotionPhysics.springTo(root, MotionPhysics.Prop.SCALE_X, 1f, MotionPhysics.SHEET)
            MotionPhysics.springTo(root, MotionPhysics.Prop.ALPHA, 1f, MotionPhysics.SHEET)
        }
    }

    fun triggerDynamicIslandAssistant(isFollowUp: Boolean = false) {
        uiHandler.post {
            ensureDynamicIslandOverlayCreated()
            refreshOverlayAccentColors()

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                val req = DynamicIslandBus.onRequestAudioPermissionInActivity
                if (req != null) {
                    req.invoke()
                } else {
                    val intent = Intent(this, LauncherActivity::class.java).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP)
                        putExtra("EXTRA_OPEN_AI", true)
                    }
                    try {
                        startActivity(intent)
                    } catch (_: Exception) {
                    }
                }
                return@post
            }

            if (!isFollowUp && islandVisible && islandIsListening) {
                finishListeningAndProcess()
                return@post
            }

            AssistantVoiceSpeaker.stop(this)
            islandIsSpeaking = false
            uiHandler.removeCallbacks(hideIslandRunnable)
            geminiQueryJob?.cancel()
            stopVoiceListeningInternal()

            val root = islandRoot ?: return@post
            val keepPreviousBody = isFollowUp && !islandBodyText?.text.isNullOrBlank()
            if (!keepPreviousBody) {
                islandBodyText?.visibility = View.GONE
                islandHintText?.visibility = View.GONE
                applyIslandShape(isExpandedCard = false)
            } else {
                islandBodyText?.visibility = View.VISIBLE
                islandHintText?.visibility = View.GONE
                applyIslandShape(isExpandedCard = true)
            }
            islandEchoView?.mood = EchoView.Mood.LISTENING
            islandStatusText?.text = EchoView.listeningPhrase(isFollowUp)
            islandStatusText?.setTextColor(Color.parseColor("#FFFFFF"))
            islandVisible = true
            islandIsListening = true
            islandIsFollowUpListen = isFollowUp
            lastPartialTranscript = ""
            DynamicIslandBus.notifyIslandVisibility(true)

            if (root.visibility != View.VISIBLE) {
                MotionPhysics.cancelView(root)
                root.animate().cancel()
                root.alpha = 0f
                root.scaleX = 0.92f
                root.scaleY = 0.92f
                root.visibility = View.VISIBLE
                MotionPhysics.springTo(root, MotionPhysics.Prop.ALPHA, 1f, MotionPhysics.SHEET)
                MotionPhysics.springTo(root, MotionPhysics.Prop.SCALE_X, 1f, MotionPhysics.SHEET)
                MotionPhysics.springTo(root, MotionPhysics.Prop.SCALE_Y, 1f, MotionPhysics.SHEET)
            } else {
                MotionPhysics.cancelView(root)
                root.animate().cancel()
                root.alpha = 1f
                root.scaleX = 1f
                root.scaleY = 1f
            }

            morphDynamicIslandWidth(if (keepPreviousBody) 440f else 265f)
            uiHandler.removeCallbacks(pulseWaveRunnable)
            uiHandler.post(pulseWaveRunnable)

            startSmartVoiceCapture()
        }
    }

    private fun startFollowUpListeningTurn() {
        if (!islandVisible) return
        triggerDynamicIslandAssistant(isFollowUp = true)
    }

    private fun startSmartVoiceCapture() {
        startDirectAudioRecordFallback()
    }

    private fun startSpeechRecognizerMultilingualFallback() {
        uiHandler.post {
            if (!islandVisible) return@post
            islandIsListening = true
            islandEchoView?.mood = EchoView.Mood.LISTENING
            try {
                val sr = SpeechRecognizer.createSpeechRecognizer(this)
                speechRecognizer = sr
                sr.setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {}
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {
                        updateWaveBarsFromRms(rmsdB)
                    }
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {
                        islandIsListening = false
                    }
                    override fun onError(error: Int) {
                        if (lastPartialTranscript.isNotBlank()) {
                            handleRecognizedVoiceText(lastPartialTranscript)
                        } else if (islandIsFollowUpListen) {
                            collapseDynamicIsland()
                        } else {
                            showIslandResult(GeminiTurnResult("Не расслышал. Нажмите микрофон и скажите запрос.", false), isQuick = true)
                        }
                    }
                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        val text = matches?.firstOrNull()?.trim().orEmpty().ifEmpty { lastPartialTranscript }
                        if (text.isNotBlank()) {
                            handleRecognizedVoiceText(text)
                        } else if (islandIsFollowUpListen) {
                            collapseDynamicIsland()
                        } else {
                            showIslandResult(GeminiTurnResult("Не расслышал. Попробуйте ещё раз.", false), isQuick = true)
                        }
                    }
                    override fun onPartialResults(partialResults: Bundle?) {
                        val partial = partialResults
                            ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            ?.firstOrNull()
                            ?.trim()
                            .orEmpty()
                        if (partial.isNotBlank()) {
                            lastPartialTranscript = partial
                            islandStatusText?.text = "«$partial»"
                        }
                    }
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })

                val recIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                }
                sr.startListening(recIntent)
            } catch (_: Exception) {
                showIslandResult(GeminiTurnResult("Микрофон недоступен.", false), isQuick = true)
            }
        }
    }

    private fun updateWaveBarsFromRms(rmsdB: Float) {
        if (!islandVisible || !islandIsListening) return
        val lvl = ((rmsdB + 2f) / 10f).coerceIn(0.28f, 1.0f)
        targetVoiceLevel = lvl
        AssistantVoiceSpeaker.currentVoiceWaveLevel = lvl
    }

    @Suppress("MissingPermission")
    private fun createInitializedAudioRecord(sampleRate: Int, bufferSize: Int): AudioRecord? {
        val sources = intArrayOf(
            MediaRecorder.AudioSource.VOICE_RECOGNITION,
            MediaRecorder.AudioSource.MIC,
            MediaRecorder.AudioSource.DEFAULT
        )
        for (attempt in 0 until 4) {
            for (src in sources) {
                try {
                    val candidate = AudioRecord(
                        src,
                        sampleRate,
                        AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT,
                        bufferSize
                    )
                    if (candidate.state == AudioRecord.STATE_INITIALIZED) {
                        return candidate
                    }
                    candidate.release()
                } catch (_: Exception) {
                }
            }
            try {
                Thread.sleep(90L)
            } catch (_: Exception) {
            }
        }
        return null
    }

    @Suppress("MissingPermission")
    private fun startDirectAudioRecordFallback() {
        GeminiCloudClient.warmupConnectionAsync(this)
        val followUpMode = islandIsFollowUpListen
        audioRecordJob?.cancel()
        audioRecordJob = serviceScope.launch(Dispatchers.IO) {
            delay(if (followUpMode) 40L else 90L)
            val sampleRate = 16000
            val minBuf = AudioRecord.getMinBufferSize(
                sampleRate,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT
            ).coerceAtLeast(3200)

            var recorder: AudioRecord? = null
            val pcmOut = ByteArrayOutputStream()
            var maxObservedRms = 0.0
            var heardSpeech = false
            try {
                val rec = createInitializedAudioRecord(sampleRate, minBuf * 2)
                if (rec == null) {
                    startSpeechRecognizerMultilingualFallback()
                    return@launch
                }
                recorder = rec

                rec.startRecording()
                val buf = ShortArray(1024)
                val startMs = SystemClock.elapsedRealtime()
                var lastSpeechMs = startMs

                while (isActive && islandIsListening) {
                    val read = rec.read(buf, 0, buf.size)
                    if (read > 0) {
                        var sumSq = 0.0
                        val bb = ByteBuffer.allocate(read * 2).order(ByteOrder.LITTLE_ENDIAN)
                        for (i in 0 until read) {
                            val s = buf[i]
                            bb.putShort(s)
                            sumSq += (s.toDouble() * s.toDouble())
                        }
                        pcmOut.write(bb.array())

                        val rms = sqrt(sumSq / read)
                        if (rms > maxObservedRms) {
                            maxObservedRms = rms
                        }
                        val db = (rms / 170.0).toFloat().coerceIn(0f, 10f)
                        uiHandler.post { updateWaveBarsFromRms(db) }

                        val now = SystemClock.elapsedRealtime()
                        if (rms > 310) {
                            heardSpeech = true
                            lastSpeechMs = now
                        }
                        if (!heardSpeech && maxObservedRms < 15.0 && (now - startMs) > 1000L) {
                            break
                        }
                        // Если это авто-продолжение диалога и пользователь молчит 3.6 сек — тихо завершаем диалог
                        if (followUpMode && !heardSpeech && (now - startMs) > 5200L) {
                            break
                        }
                        // Fast VAD: как только речь закончилась и тишина длится 620 мс — мгновенно отправляем!
                        if (heardSpeech && (now - lastSpeechMs) > 450L && (now - startMs) > 720L) {
                            break
                        }
                        if ((now - startMs) > 5800L) {
                            break
                        }
                    } else {
                        delay(15L)
                    }
                }
            } catch (_: Exception) {
            } finally {
                try {
                    recorder?.stop()
                } catch (_: Exception) {
                }
                try {
                    recorder?.release()
                } catch (_: Exception) {
                }
            }

            if (maxObservedRms < 15.0 && islandIsListening) {
                startSpeechRecognizerMultilingualFallback()
                return@launch
            }

            val rawPcmBytes = pcmOut.toByteArray()
            withContext(Dispatchers.Main) {
                islandIsListening = false
                AssistantVoiceSpeaker.currentVoiceWaveLevel = 0f
                if (!heardSpeech && followUpMode) {
                    collapseDynamicIsland()
                    return@withContext
                }
                if (rawPcmBytes.size < 2800 || (!heardSpeech && maxObservedRms < 190.0)) {
                    if (followUpMode) {
                        collapseDynamicIsland()
                    } else {
                        showIslandResult(GeminiTurnResult("Не расслышал, повтори?", false), isQuick = true)
                    }
                } else {
                    val trimmedPcm = trimPcmSilence(rawPcmBytes, sampleRate)
                    val wavBytes = encodePcmToWav(trimmedPcm, sampleRate)
                    showIslandThinking(EchoView.thinkingPhrase())
                    GeminiCloudClient.onLiveThinkingHint = { partialRaw ->
                        uiHandler.post {
                            if (islandVisible && islandEchoView?.mood == EchoView.Mood.THINKING) {
                                islandStatusText?.text = EchoView.thinkingPhrase(partialRaw)
                            }
                        }
                    }
                    geminiQueryJob = serviceScope.launch {
                        val turnResult = GeminiCloudClient.askGeminiAudioTurn(this@KeyMapperAccessibilityService, wavBytes)
                        GeminiCloudClient.onLiveThinkingHint = null
                        if (turnResult.isSilence && followUpMode) {
                            collapseDynamicIsland()
                        } else {
                            showIslandResult(
                                turnResult,
                                isQuick = turnResult.displayText.startsWith("✦") && turnResult.displayText.length <= 46 && !turnResult.shouldContinueDialog
                            )
                        }
                    }
                }
            }
        }
    }

    /**
     * Обрезает пустую тишину в начале и в конце аудиозаписи (оставляя 120 мс перед речью и 160 мс после),
     * чтобы WAV-файл был в 2–3 раза меньше и мгновенно улетал в Gemini!
     */
    private fun trimPcmSilence(pcmData: ByteArray, sampleRate: Int): ByteArray {
        val totalSamples = pcmData.size / 2
        if (totalSamples < 1600) return pcmData
        val frameSamples = 320 // 20 мс при 16 кГц
        val totalFrames = totalSamples / frameSamples
        var firstSpeechFrame = -1
        var lastSpeechFrame = -1

        val bb = ByteBuffer.wrap(pcmData).order(ByteOrder.LITTLE_ENDIAN)
        for (f in 0 until totalFrames) {
            var sumSq = 0.0
            val baseIdx = f * frameSamples * 2
            for (s in 0 until frameSamples) {
                val sample = bb.getShort(baseIdx + s * 2).toDouble()
                sumSq += sample * sample
            }
            val rms = sqrt(sumSq / frameSamples)
            if (rms > 240.0) {
                if (firstSpeechFrame == -1) firstSpeechFrame = f
                lastSpeechFrame = f
            }
        }

        if (firstSpeechFrame == -1 || lastSpeechFrame == -1) return pcmData
        val preRollFrames = (0.12 * sampleRate / frameSamples).toInt()
        val postRollFrames = (0.16 * sampleRate / frameSamples).toInt()
        val startFrame = (firstSpeechFrame - preRollFrames).coerceAtLeast(0)
        val endFrame = (lastSpeechFrame + postRollFrames + 1).coerceAtMost(totalFrames)
        val startByte = startFrame * frameSamples * 2
        val endByte = (endFrame * frameSamples * 2).coerceAtMost(pcmData.size)
        if (endByte <= startByte) return pcmData
        return pcmData.copyOfRange(startByte, endByte)
    }

    private fun encodePcmToWav(pcmData: ByteArray, sampleRate: Int): ByteArray {
        val totalDataLen = pcmData.size + 36
        val byteRate = sampleRate * 2
        val header = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        header.put("RIFF".toByteArray(Charsets.US_ASCII))
        header.putInt(totalDataLen)
        header.put("WAVE".toByteArray(Charsets.US_ASCII))
        header.put("fmt ".toByteArray(Charsets.US_ASCII))
        header.putInt(16)
        header.putShort(1.toShort())
        header.putShort(1.toShort())
        header.putInt(sampleRate)
        header.putInt(byteRate)
        header.putShort(2.toShort())
        header.putShort(16.toShort())
        header.put("data".toByteArray(Charsets.US_ASCII))
        header.putInt(pcmData.size)

        val out = ByteArray(44 + pcmData.size)
        System.arraycopy(header.array(), 0, out, 0, 44)
        System.arraycopy(pcmData, 0, out, 44, pcmData.size)
        return out
    }

    private fun finishListeningAndProcess() {
        if (!islandIsListening) return
        islandIsListening = false
        if (speechRecognizer != null) {
            try {
                speechRecognizer?.stopListening()
            } catch (_: Exception) {
            }
            if (lastPartialTranscript.isNotBlank()) {
                val captured = lastPartialTranscript
                stopSpeechRecognizerOnly()
                handleRecognizedVoiceText(captured)
            }
        }
    }

    private fun handleRecognizedVoiceText(recognizedText: String) {
        stopVoiceListeningInternal()
        val accent = resolveCurrentAccentColor()
        islandEchoView?.accentColor = accent

        showIslandThinking(EchoView.thinkingPhrase(recognizedText))
        geminiQueryJob?.cancel()
        geminiQueryJob = serviceScope.launch {
            val turnResult = GeminiCloudClient.askGeminiTextTurn(this@KeyMapperAccessibilityService, recognizedText)
            showIslandResult(turnResult, isQuick = turnResult.displayText.startsWith("✦") && !turnResult.shouldContinueDialog, queryTitle = recognizedText)
        }
    }

    private fun showIslandThinking(statusLabel: String) {
        islandIsListening = false
        islandIsSpeaking = false
        islandEchoView?.mood = EchoView.Mood.THINKING
        islandBodyText?.visibility = View.GONE
        islandHintText?.visibility = View.GONE
        applyIslandShape(isExpandedCard = false)
        islandStatusText?.text = statusLabel
        islandStatusText?.setTextColor(Color.parseColor("#FFFFFF"))
        morphDynamicIslandWidth(275f)
    }

    private fun showIslandResult(turnResult: GeminiTurnResult, isQuick: Boolean, queryTitle: String = "") {
        val text = turnResult.displayText
        islandIsListening = false
        val accent = resolveCurrentAccentColor()
        islandEchoView?.accentColor = accent
        uiHandler.removeCallbacks(hideIslandRunnable)

        val cleanDisplay = text.removePrefix("✦ ").trim()
        val isError = cleanDisplay.startsWith("Ошибка ответа") ||
            cleanDisplay.startsWith("Не удалось") ||
            cleanDisplay.startsWith("Не расслышал") ||
            cleanDisplay.startsWith("Микрофон недоступен") ||
            cleanDisplay.startsWith("Лимиты Gemini исчерпаны")
        val ttsEnabled = AssistantVoiceSpeaker.isTtsEnabled(this)
        val shouldSpeak = ttsEnabled && !turnResult.isSilence && !isError
        val readingHoldMs = (6500L + cleanDisplay.length * 60L).coerceIn(8500L, 15000L)

        if (isQuick && !turnResult.shouldContinueDialog && cleanDisplay.length <= 46 && !shouldSpeak) {
            islandIsSpeaking = false
            islandEchoView?.mood = if (isError) EchoView.Mood.ERROR else EchoView.Mood.IDLE
            islandBodyText?.visibility = View.GONE
            islandHintText?.visibility = View.GONE
            applyIslandShape(isExpandedCard = false)
            islandStatusText?.text = cleanDisplay
            islandStatusText?.setTextColor(Color.parseColor("#FFFFFF"))
            morphDynamicIslandWidth(330f)
            uiHandler.postDelayed(hideIslandRunnable, 4000L)
            return
        }

        islandIsSpeaking = shouldSpeak
        islandEchoView?.mood = when {
            isError -> EchoView.Mood.ERROR
            shouldSpeak -> EchoView.Mood.SPEAKING
            else -> EchoView.Mood.IDLE
        }
        val effectiveUserSaid = turnResult.userSaid.ifBlank { queryTitle }
        val headerTitle = EchoView.resultHeaderPhrase(
            commandType = turnResult.executedCommandType,
            cleanDisplay = cleanDisplay,
            isError = isError,
            shouldSpeak = shouldSpeak,
            shouldContinueDialog = turnResult.shouldContinueDialog,
            userSaid = effectiveUserSaid
        )
        applyIslandShape(isExpandedCard = true)
        islandStatusText?.text = headerTitle
        islandStatusText?.setTextColor(if (isError) Color.parseColor("#FF5A5F") else accent)
        islandHintText?.text = "OK — ответить"
        islandHintText?.visibility = View.VISIBLE
        islandBodyText?.text = cleanDisplay
        islandBodyText?.visibility = View.VISIBLE
        morphDynamicIslandWidth(440f)

        if (shouldSpeak) {
            uiHandler.removeCallbacks(pulseWaveRunnable)
            uiHandler.post(pulseWaveRunnable)
            AssistantVoiceSpeaker.speak(this, cleanDisplay) { didPlayAudio ->
                islandIsSpeaking = false
                if (!islandVisible) return@speak
                islandEchoView?.mood = EchoView.Mood.IDLE
                if (turnResult.shouldContinueDialog) {
                    if (didPlayAudio) {
                        startFollowUpListeningTurn()
                    } else {
                        // Если аудио не воспроизводилось — даём спокойно прочитать текст перед авто-прослушиванием!
                        islandStatusText?.text = "Эхо · жду ответ"
                        uiHandler.postDelayed({
                            if (islandVisible && !islandIsListening) {
                                startFollowUpListeningTurn()
                            }
                        }, 4500L)
                    }
                } else {
                    val holdAfterSpeech = if (didPlayAudio) 5500L else readingHoldMs
                    uiHandler.postDelayed(hideIslandRunnable, holdAfterSpeech)
                }
            }
        } else {
            uiHandler.removeCallbacks(pulseWaveRunnable)
            if (turnResult.shouldContinueDialog) {
                // Если озвучка выключена, даём 4.5 сек прочитать ответ, не пряча текст, и включаем микрофон
                uiHandler.postDelayed({
                    if (islandVisible && !islandIsListening) {
                        startFollowUpListeningTurn()
                    }
                }, 4500L)
            } else {
                uiHandler.postDelayed(hideIslandRunnable, readingHoldMs)
            }
        }
    }

    private fun collapseDynamicIsland() {
        uiHandler.removeCallbacks(hideIslandRunnable)
        uiHandler.removeCallbacks(pulseWaveRunnable)
        geminiQueryJob?.cancel()
        AssistantVoiceSpeaker.stop(this)
        AssistantVoiceSpeaker.currentVoiceWaveLevel = 0f
        islandIsSpeaking = false
        islandIsFollowUpListen = false
        stopVoiceListeningInternal()
        islandVisible = false
        islandEchoView?.mood = EchoView.Mood.IDLE
        val root = islandRoot ?: return
        if (root.visibility == View.VISIBLE) {
            morphDynamicIslandWidth(148f)
            root.animate()
                .alpha(0f)
                .setDuration(170L)
                .withEndAction {
                    root.visibility = View.GONE
                    islandBodyText?.visibility = View.GONE
                    DynamicIslandBus.notifyIslandVisibility(false)
                }
                .start()
        } else {
            DynamicIslandBus.notifyIslandVisibility(false)
        }
    }

    private fun stopSpeechRecognizerOnly() {
        val sr = speechRecognizer
        speechRecognizer = null
        if (sr != null) {
            try {
                sr.cancel()
            } catch (_: Exception) {
            }
            try {
                sr.destroy()
            } catch (_: Exception) {
            }
        }
    }

    private fun stopVoiceListeningInternal() {
        islandIsListening = false
        stopSpeechRecognizerOnly()
        audioRecordJob?.cancel()
        audioRecordJob = null
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        isServiceConnectedAlive = true
        if (event == null) return
        val pkg = event.packageName?.toString() ?: return

        if (event.eventType == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            val notif = event.parcelableData as? Notification
            if (notif != null && pkg != packageName) {
                MediaStateBus.ingestNotification(
                    context = this,
                    pkg = pkg,
                    notif = notif,
                    requireActivePlaybackOrSession = false,
                    eventTexts = event.text
                )
            }
            return
        }

        if (isGoogleAssistantPackage(pkg)) {
            // Запасной вариант: основной путь — onKeyEvent. Сюда попадаем, только если Katniss всё же открылся.
            if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastInterceptMillis > 450L) {
                    lastInterceptMillis = now
                    Log.i("AssistKey", "fallback: katniss window opened, sending BACK")
                    performGlobalAction(GLOBAL_ACTION_BACK)
                    if (!islandVisible && !DynamicIslandBus.isAssistKeyRecentlyTriggered()) {
                        DynamicIslandBus.markAssistKeyTriggered()
                        triggerDynamicIslandAssistant()
                    }
                }
            }
            return
        }

        if (pkg != packageName && MediaStateBus.isKnownMediaPackage(pkg)) {
            if (event.eventType == AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED ||
                event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            ) {
                tryScrapeMediaMetadataFromWindow(pkg)
            }
        }

        if (event.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED && pkg != packageName) {

            MediaStateBus.onMediaAppOpened(pkg)
            com.mitv.customlauncher.ui.RecentAppsTracker.onForegroundPackage(this, pkg)

            val prefs = getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            val matchedPresetTarget: String? = when {
                isNetflixPackage(pkg) -> prefs.getString("preset_bind_NETFLIX", null)
                isPrimePackage(pkg) -> prefs.getString("preset_bind_PRIME", null)
                isPatchwallPackage(pkg) -> prefs.getString("preset_bind_PATCHWALL", "ACTION_CONTROL_CENTER")
                else -> null
            }

            if (!matchedPresetTarget.isNullOrEmpty()) {
                val now = SystemClock.elapsedRealtime()
                if (now - lastInterceptMillis > 600L) {
                    lastInterceptMillis = now
                    executeBoundAction(matchedPresetTarget)
                }
            }
        }
    }

    override fun onInterrupt() {}

    override fun onKeyEvent(event: KeyEvent): Boolean {
        isServiceConnectedAlive = true
        val keyCode = event.keyCode
        val scanCode = event.scanCode

        if (event.action == KeyEvent.ACTION_DOWN && isSoundNavigationKey(keyCode)) {
            NavSoundPlayer.playClick(this)
        }

        if (islandVisible) {
            if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                    collapseDynamicIsland()
                }
                return true
            }
            if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER || keyCode == KeyEvent.KEYCODE_ENTER) {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                    if (islandIsListening) {
                        finishListeningAndProcess()
                    } else if (islandIsSpeaking || AssistantVoiceSpeaker.isSpeakingNow) {
                        AssistantVoiceSpeaker.stop(this)
                        islandIsSpeaking = false
                        startFollowUpListeningTurn()
                    } else {
                        startFollowUpListeningTurn()
                    }
                }
                return true
            }
        }

        if (keyCode == KeyEvent.KEYCODE_VOLUME_UP ||
            keyCode == KeyEvent.KEYCODE_VOLUME_DOWN ||
            keyCode == KeyEvent.KEYCODE_VOLUME_MUTE
        ) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                try {
                    val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    when (keyCode) {
                        KeyEvent.KEYCODE_VOLUME_UP ->
                            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0)
                        KeyEvent.KEYCODE_VOLUME_DOWN ->
                            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0)
                        KeyEvent.KEYCODE_VOLUME_MUTE ->
                            am.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_TOGGLE_MUTE, 0)
                    }
                    lastKnownVolumePct = computeCurrentMusicVolumePct()
                    showGlobalVolumeOverlay()
                    VolumeHudBus.notifyVolumeChanged()
                    if (overlayControlCenter?.isVisible == true) {
                        overlayControlCenter?.refreshControlCenterToggles()
                    }
                } catch (_: Exception) {
                }
            }
            return true
        }

        if (overlayControlCenter?.isVisible == true) {
            val prefsForCc = getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)
            val presetForCc = resolvePresetBinding(prefsForCc, keyCode, scanCode)
            val boundForCc = prefsForCc.getString("key_bind_$keyCode", null)
                ?: if (scanCode > 0) prefsForCc.getString("scan_bind_$scanCode", null) else null
            if (presetForCc == "ACTION_CONTROL_CENTER" || boundForCc == "ACTION_CONTROL_CENTER") {
                if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                    overlayControlCenter?.hide(immediate = false)
                }
                return true
            }
            return overlayControlCenter?.handleKeyEvent(event) ?: true
        }

        if (KeyCaptureBus.isCapturingKey) {
            if (keyCode == KeyEvent.KEYCODE_BACK || keyCode == KeyEvent.KEYCODE_ESCAPE) {
                return false
            }
            if (isNavigationOrCenterKey(keyCode)) {
                return false
            }
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                KeyCaptureBus.notifyKeyCaptured(keyCode, scanCode)
            }
            return true
        }

        if (keyCode == KeyEvent.KEYCODE_HOME && event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            DynamicIslandBus.onHomePressedInActivity?.invoke()
        }

        if (isNavigationOrCenterKey(keyCode)) {
            return false
        }

        val prefs = getSharedPreferences(LauncherConfig.PREFS_NAME, Context.MODE_PRIVATE)

        Log.i(
            "AssistKey",
            "key=${KeyEvent.keyCodeToString(keyCode)}($keyCode) scan=$scanCode action=${event.action} repeat=${event.repeatCount}"
        )

        if (keyCode == KeyEvent.KEYCODE_VOICE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_ASSIST ||
            keyCode == KeyEvent.KEYCODE_SEARCH ||
            scanCode == 582 || scanCode == 217 || scanCode == 221
        ) {
            val customAssistTarget = prefs.getString("key_bind_$keyCode", null) ?: "ACTION_AI"
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                if (customAssistTarget == "ACTION_AI") {
                    DynamicIslandBus.markAssistKeyTriggered()
                }
                executeBoundAction(customAssistTarget)
            }
            return true
        }

        val presetTarget = resolvePresetBinding(prefs, keyCode, scanCode)
        if (!presetTarget.isNullOrEmpty()) {
            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
                executeBoundAction(presetTarget)
            }
            return true
        }

        val boundTarget = prefs.getString("key_bind_$keyCode", null)
            ?: if (scanCode > 0) prefs.getString("scan_bind_$scanCode", null) else null

        if (boundTarget.isNullOrEmpty()) {
            return false
        }

        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) {
            executeBoundAction(boundTarget)
        }
        return true
    }

    private fun resolvePresetBinding(
        prefs: android.content.SharedPreferences,
        keyCode: Int,
        scanCode: Int
    ): String? {
        // Пульт Xiaomi RC (Mi TV Stick), реальные коды из getevent:
        // Netflix = KEY_VIDEO (scan 393), Prime Video = KEY_YELLOW (scan 400).
        // Если бинд не задан — возвращаем null, и система запускает приложение как обычно.
        if (scanCode == 393) {
            return prefs.getString("preset_bind_NETFLIX", null)?.takeIf { it.isNotEmpty() }
        }
        if (scanCode == 400) {
            return prefs.getString("preset_bind_PRIME", null)?.takeIf { it.isNotEmpty() }
        }
        when (NativeCore.classifyRemoteKey(keyCode, scanCode)) {
            NativeCore.KEY_CLASS_PATCHWALL -> {
                val target = prefs.getString("preset_bind_PATCHWALL", "ACTION_CONTROL_CENTER")
                if (!target.isNullOrEmpty()) return target
            }
            NativeCore.KEY_CLASS_NETFLIX -> {
                prefs.getString("preset_bind_NETFLIX", null)?.let { if (it.isNotEmpty()) return it }
            }
            NativeCore.KEY_CLASS_PRIME -> {
                prefs.getString("preset_bind_PRIME", null)?.let { if (it.isNotEmpty()) return it }
            }
        }
        if (keyCode == KeyEvent.KEYCODE_ALL_APPS ||
            keyCode == KeyEvent.KEYCODE_MENU ||
            keyCode == KeyEvent.KEYCODE_GUIDE ||
            keyCode == KeyEvent.KEYCODE_SETTINGS ||
            keyCode == KeyEvent.KEYCODE_TV_INPUT ||
            keyCode == KeyEvent.KEYCODE_BUTTON_1 ||
            scanCode == 139 || scanCode == 362 || scanCode == 172 || scanCode == 256
        ) {
            val target = prefs.getString("preset_bind_PATCHWALL", "ACTION_CONTROL_CENTER")
            if (!target.isNullOrEmpty()) return target
        }

        if (keyCode == KeyEvent.KEYCODE_BUTTON_2 ||
            keyCode == KeyEvent.KEYCODE_PROG_RED ||
            scanCode == 412 || scanCode == 398 || keyCode == 309
        ) {
            prefs.getString("preset_bind_NETFLIX", null)?.let { if (it.isNotEmpty()) return it }
        }

        if (keyCode == KeyEvent.KEYCODE_BUTTON_3 ||
            keyCode == KeyEvent.KEYCODE_PROG_BLUE ||
            scanCode == 413 || scanCode == 401 || keyCode == 310
        ) {
            prefs.getString("preset_bind_PRIME", null)?.let { if (it.isNotEmpty()) return it }
        }

        return null
    }

    private fun isGoogleAssistantPackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("katniss")
    }

    private fun isNetflixPackage(pkg: String): Boolean = pkg.lowercase().contains("netflix")

    private fun isPrimePackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("amazonvideo") || p.contains("amazon.avod") || p.contains("primevideo")
    }

    private fun isPatchwallPackage(pkg: String): Boolean {
        val p = pkg.lowercase()
        return p.contains("patchwall") || p.contains("mitv.tvhome") || p.contains("mitv.smartshare")
    }

    private fun isSoundNavigationKey(keyCode: Int): Boolean {
        return keyCode == KeyEvent.KEYCODE_DPAD_UP ||
            keyCode == KeyEvent.KEYCODE_DPAD_DOWN ||
            keyCode == KeyEvent.KEYCODE_DPAD_LEFT ||
            keyCode == KeyEvent.KEYCODE_DPAD_RIGHT ||
            keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
            keyCode == KeyEvent.KEYCODE_ENTER ||
            keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER ||
            keyCode == KeyEvent.KEYCODE_BACK ||
            keyCode == KeyEvent.KEYCODE_HOME
    }

    private fun isNavigationOrCenterKey(keyCode: Int): Boolean {
        return keyCode == KeyEvent.KEYCODE_DPAD_UP ||
            keyCode == KeyEvent.KEYCODE_DPAD_DOWN ||
            keyCode == KeyEvent.KEYCODE_DPAD_LEFT ||
            keyCode == KeyEvent.KEYCODE_DPAD_RIGHT ||
            keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
            keyCode == KeyEvent.KEYCODE_ENTER ||
            keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER ||
            keyCode == KeyEvent.KEYCODE_HOME
    }

    private fun executeBoundAction(target: String) {
        when (target) {
            "ACTION_CONTROL_CENTER" -> {
                if (DynamicIslandBus.isLauncherInForeground && DynamicIslandBus.onToggleControlCenterInActivity != null) {
                    overlayControlCenter?.hide(immediate = true)
                    uiHandler.post {
                        DynamicIslandBus.onToggleControlCenterInActivity?.invoke()
                    }
                } else {
                    if (overlayControlCenter == null) {
                        overlayControlCenter = OverlayControlCenterController(this)
                    }
                    overlayControlCenter?.toggle()
                }
            }
            "ACTION_ALL_APPS" -> {
                val intent = Intent(this, LauncherActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("EXTRA_OPEN_ALL_APPS", true)
                }
                startActivity(intent)
            }
            "ACTION_SETTINGS" -> {
                val intent = Intent(Settings.ACTION_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                try {
                    startActivity(intent)
                } catch (_: Exception) {
                }
            }
            "ACTION_AI" -> {
                triggerDynamicIslandAssistant()
            }
            else -> {
                MediaStateBus.onMediaAppOpened(target)
                val pm = packageManager
                val launchIntent = pm.getLeanbackLaunchIntentForPackage(target)
                    ?: pm.getLaunchIntentForPackage(target)
                if (launchIntent != null) {
                    launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    try {
                        startActivity(launchIntent)
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }

    private var lastScrapeRealtimeMs: Long = 0L
    private var inAppSearchJob: Job? = null

    private val UI_NOISE_WORDS = setOf(
        "home", "главная", "головна", "search", "поиск", "пошук",
        "library", "медиатека", "бібліотека", "settings", "настройки", "налаштування",
        "play", "pause", "next", "previous", "shuffle", "repeat", "like", "follow",
        "слушать", "слухати", "воспроизвести", "відтворити", "играть", "грати",
        "пауза", "далее", "далі", "назад", "перемешать", "повтор", "избранное", "нравится",
        "подписаться", "підписатися", "добавить", "додати", "ещё", "ще", "треки", "альбомы",
        "плейлисты", "исполнители", "рекомендации", "фоновое воспроизведение",
        "spotify", "soundcloud", "youtube", "smarttube", "deezer", "프리미엄", "premium",
        "войти", "увійти", "sign in", "log in", "back", "close", "закрыть",
        "очередь", "текст песни", "lyrics", "queue", "радио по треку", "поделиться",
        "перейти к альбому", "перейти к исполнителю", "похожие", "смотреть", "открыть"
    )

    private val DAY_OR_DATE_NOISE = listOf(
        "понедельник", "вторник", "среда", "четверг", "пятница", "суббота", "воскресенье",
        "понеділок", "вівторок", "середа", "четвер", "п'ятниця", "субота", "неділя",
        "января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа",
        "сентября", "октября", "ноября", "декабря", "в эфире"
    )

    private fun isNoiseUiText(text: String): Boolean {
        val clean = text.trim()
        if (clean.length < 2 || clean.length > 85) return true
        val lower = clean.lowercase(Locale.ROOT)
        if (lower in UI_NOISE_WORDS) return true
        if (DAY_OR_DATE_NOISE.any { lower.contains(it) }) return true
        if (clean.matches(Regex("^[0-9]{1,2}:[0-9]{2}(:[0-9]{2})?( / [0-9]{1,2}:[0-9]{2})?$"))) return true
        if (clean.matches(Regex("^[0-9]+$"))) return true
        return false
    }

    private fun parseTimeMmSsToMs(raw: String): Long {
        val parts = raw.trim().split(":")
        return try {
            when (parts.size) {
                2 -> (parts[0].toLong() * 60L + parts[1].toLong()) * 1000L
                3 -> (parts[0].toLong() * 3600L + parts[1].toLong() * 60L + parts[2].toLong()) * 1000L
                else -> -1L
            }
        } catch (_: Exception) {
            -1L
        }
    }

    /**
     * Чтение заголовка трека и исполнителя из окна медиа-приложения (включая WebView DOM внутри Spotify TV com.spotify.tv.android),
     * если системный MediaSession / dumpsys media_session ещё не отдал метаданные.
     * Никогда не считывает нажатия кнопок («Слушать») и никогда не читает окно лаунчера!
     */
    private fun tryScrapeMediaMetadataFromWindow(pkg: String) {
        if (pkg == packageName) return
        if (MediaStateBus.hasRealControllerMetadata()) return

        val now = SystemClock.elapsedRealtime()
        if (now - lastScrapeRealtimeMs < 1100L) return
        lastScrapeRealtimeMs = now

        val root = try {
            rootInActiveWindow
        } catch (_: Exception) {
            null
        } ?: return

        val rootPkg = root.packageName?.toString().orEmpty()
        if (rootPkg.isEmpty() || rootPkg == packageName || rootPkg != pkg || !MediaStateBus.isKnownMediaPackage(rootPkg)) return

        try {
            var idTitle = ""
            var idArtist = ""
            var scrapedPosMs = -1L
            var scrapedDurMs = -1L
            val allNodesFlat = mutableListOf<Pair<String, String>>()
            traverseMediaWindowNodes(root, allNodesFlat, depth = 0)

            // 1. Сначала проверяем явные Android resource ID (если приложение нативное)
            for ((vid, txt) in allNodesFlat) {
                val v = vid.lowercase(Locale.US)
                if (v.isEmpty()) continue
                if (idTitle.isEmpty() && (v.contains("track_title") || v.contains("now_playing_title") || v.contains("player_title") || v.contains("song_title") || v.contains("mini_player_title"))) {
                    if (!isNoiseUiText(txt)) idTitle = txt
                } else if (idArtist.isEmpty() && (v.contains("track_artist") || v.contains("now_playing_subtitle") || v.contains("player_artist") || v.contains("song_artist") || v.contains("mini_player_subtitle"))) {
                    if (!isNoiseUiText(txt) && txt != idTitle) idArtist = txt
                }
            }

            // 2. Если viewId пустые (например Spotify TV com.spotify.tv.android на WebView) — ищем пару (Трек + Артист) рядом с таймером воспроизведения 0:00..59:59
            if (idTitle.isEmpty()) {
                val timeRegex = Regex("^[0-9]{1,2}:[0-9]{2}$")
                val timeIdx = allNodesFlat.indexOfFirst { timeRegex.matches(it.second.trim()) }
                if (timeIdx >= 0) {
                    scrapedPosMs = parseTimeMmSsToMs(allNodesFlat[timeIdx].second)
                    for (j in (timeIdx + 1)..(timeIdx + 3).coerceAtMost(allNodesFlat.lastIndex)) {
                        val candidateTime = allNodesFlat[j].second.trim()
                        if (timeRegex.matches(candidateTime)) {
                            val dMs = parseTimeMmSsToMs(candidateTime)
                            if (dMs >= scrapedPosMs && dMs > 0L) {
                                scrapedDurMs = dMs
                            }
                            break
                        }
                    }

                    val beforeCandidates = mutableListOf<String>()
                    var k = timeIdx - 1
                    while (k >= 0 && beforeCandidates.size < 2) {
                        val candidate = allNodesFlat[k].second.trim()
                        if (!isNoiseUiText(candidate) && !beforeCandidates.contains(candidate)) {
                            beforeCandidates.add(0, candidate)
                        }
                        k--
                    }

                    if (beforeCandidates.isNotEmpty()) {
                        idTitle = beforeCandidates[0]
                        if (beforeCandidates.size >= 2) {
                            idArtist = beforeCandidates[1]
                        }
                    } else {
                        val afterCandidates = mutableListOf<String>()
                        var m = timeIdx + 1
                        while (m < allNodesFlat.size && afterCandidates.size < 2) {
                            val candidate = allNodesFlat[m].second.trim()
                            if (!isNoiseUiText(candidate) && !afterCandidates.contains(candidate)) {
                                afterCandidates.add(candidate)
                            }
                            m++
                        }
                        if (afterCandidates.isNotEmpty()) {
                            idTitle = afterCandidates[0]
                            if (afterCandidates.size >= 2) {
                                idArtist = afterCandidates[1]
                            }
                        }
                    }
                }
            }

            if (idTitle.isNotEmpty()) {
                val am = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                if (am?.isMusicActive != true && !MediaStateBus.state.value.isPlaying) {
                    return
                }
                val appLabel = MediaStateBus.resolveAppLabel(this, pkg)
                MediaStateBus.updateMetadata(
                    context = this,
                    title = idTitle,
                    artist = idArtist.ifEmpty { appLabel },
                    sourcePackage = pkg,
                    sourceAppName = appLabel,
                    cover = null,
                    durationMs = scrapedDurMs,
                    positionMs = scrapedPosMs
                )
            }
        } catch (_: Exception) {
        }
    }

    private fun traverseMediaWindowNodes(
        node: AccessibilityNodeInfo?,
        out: MutableList<Pair<String, String>>,
        depth: Int
    ) {
        if (node == null || depth > 14 || out.size > 120) return
        val vid = node.viewIdResourceName.orEmpty()
        val t = (node.text?.toString()?.trim().takeUnless { it.isNullOrEmpty() }
            ?: node.contentDescription?.toString()?.trim()).orEmpty()
        if (t.isNotEmpty()) {
            out.add(vid to t)
        }
        val count = node.childCount
        for (i in 0 until count) {
            val child = try { node.getChild(i) } catch (_: Exception) { null }
            if (child != null) {
                traverseMediaWindowNodes(child, out, depth + 1)
            }
        }
    }

    /**
     * ИИ-автоматизация внутри ТВ-приложений (например Kick на ТВ):
     * ждёт открытия окна приложения, находит кнопку «Поиск / Search», вводит имя стримера и открывает канал!
     */
    /**
     * Автоматический запуск первого найденного видео на YouTube TV / SmartTube после голосового запроса:
     * ждёт загрузки карточек результатов и нажимает на первое видео!
     */
    private fun runAutomatedYouTubeAutoPlay(targetPkg: String, query: String) {
        val cleanQuery = query.trim()
        if (cleanQuery.isEmpty()) return
        inAppSearchJob?.cancel()
        inAppSearchJob = serviceScope.launch {
            // Ждём открытия YouTube TV / SmartTube и полной отрисовки карточек результатов поиска
            delay(2700L)
            for (attempt in 0 until 4) {
                val root = try { rootInActiveWindow } catch (_: Exception) { null }
                val activePkg = root?.packageName?.toString()?.lowercase(Locale.ROOT).orEmpty()
                if (activePkg.contains("youtube") || activePkg.contains("smarttube")) {
                    val firstWord = cleanQuery.split(" ").firstOrNull { it.length >= 2 } ?: cleanQuery
                    if (root != null && clickResultNodeMatchingQuery(root, firstWord)) {
                        delay(300L)
                        ShellKeyController.sendKeyEvent(KeyEvent.KEYCODE_DPAD_CENTER)
                        return@launch
                    }
                    // Если фокус после открытия ACTION_SEARCH остался на верхней строке поиска или фильтрах,
                    // проверяем фокус: если в фокусе EditText/поиск — спускаемся ВНИЗ на карточку видео и жмём ОК!
                    val focusedNode = try { root?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) } catch (_: Exception) { null }
                    val fCls = focusedNode?.className?.toString().orEmpty()
                    val fTxt = focusedNode?.text?.toString()?.lowercase(Locale.ROOT).orEmpty()
                    if (focusedNode?.isEditable == true || fCls.contains("EditText", ignoreCase = true) || fTxt == cleanQuery.lowercase(Locale.ROOT)) {
                        ShellKeyController.sendKeyEvent(KeyEvent.KEYCODE_DPAD_DOWN)
                        delay(320L)
                    }
                    ShellKeyController.sendKeyEvent(KeyEvent.KEYCODE_DPAD_CENTER)
                    delay(900L)
                    // Контрольное подтверждение, если первый клик перевёл фокус с фильтра на карточку видео
                    val rootAfter = try { rootInActiveWindow } catch (_: Exception) { null }
                    val focusedAfter = try { rootAfter?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) } catch (_: Exception) { null }
                    if (focusedAfter != null && focusedAfter.isClickable) {
                        focusedAfter.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    }
                    return@launch
                }
                delay(800L)
            }
        }
    }

    private fun showGlobalReminderOrAnnouncement(displayText: String, speakText: String) {
        uiHandler.post {
            ensureDynamicIslandOverlayCreated()
            refreshOverlayAccentColors()
            AssistantVoiceSpeaker.stop(this)
            uiHandler.removeCallbacks(hideIslandRunnable)
            val root = islandRoot ?: return@post
            islandVisible = true
            DynamicIslandBus.notifyIslandVisibility(true)
            if (root.visibility != View.VISIBLE) {
                root.alpha = 0f
                root.visibility = View.VISIBLE
                root.animate().alpha(1f).setDuration(140L).start()
            } else {
                root.animate().cancel()
                root.alpha = 1f
            }
            showIslandResult(
                GeminiTurnResult(displayText = displayText, shouldContinueDialog = false, isSilence = false),
                isQuick = false,
                queryTitle = "Напоминание"
            )
        }
    }

    private val inAppSearchKeywords = listOf(
        "search", "поиск", "пошук", "find", "лупа", "magnif",
        "ic_search", "icon_search", "btn_search", "nav_search", "search_button"
    )

    private fun nodeMatchesKeywords(node: AccessibilityNodeInfo?, keywords: List<String>, depth: Int = 0): Boolean {
        if (node == null) return false
        val txt = node.text?.toString()?.lowercase(Locale.ROOT).orEmpty()
        val desc = node.contentDescription?.toString()?.lowercase(Locale.ROOT).orEmpty()
        val vid = node.viewIdResourceName?.lowercase(Locale.ROOT).orEmpty()
        if (keywords.any { kw -> txt.contains(kw) || desc.contains(kw) || vid.contains(kw) }) return true
        if (depth >= 3) return false
        for (i in 0 until node.childCount) {
            val c = try { node.getChild(i) } catch (_: Exception) { null }
            if (nodeMatchesKeywords(c, keywords, depth + 1)) return true
        }
        return false
    }

    /**
     * Запасной путь для ТВ-версии Kick: поле поиска не нашлось по тексту/id — уходим в левую навигационную панель
     * (DPAD_LEFT), листаем пункты сверху вниз и открываем тот, что похож на поиск.
     */
    private suspend fun focusSearchInLeftNavPanel(targetPkg: String): Boolean {
        repeat(3) {
            ShellKeyController.sendKeyEvent(KeyEvent.KEYCODE_DPAD_LEFT)
            delay(260L)
        }
        repeat(3) {
            ShellKeyController.sendKeyEvent(KeyEvent.KEYCODE_DPAD_UP)
            delay(200L)
        }
        for (i in 0 until 8) {
            val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: break
            if (root.packageName?.toString() != targetPkg) break
            val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
                ?: root.findFocus(AccessibilityNodeInfo.FOCUS_ACCESSIBILITY)
            if (focused != null && nodeMatchesKeywords(focused, inAppSearchKeywords)) {
                ShellKeyController.sendKeyEvent(KeyEvent.KEYCODE_DPAD_CENTER)
                return true
            }
            ShellKeyController.sendKeyEvent(KeyEvent.KEYCODE_DPAD_DOWN)
            delay(300L)
        }
        return false
    }

    /** Ищет экранную клавишу (Compose-кнопку) с буквой/цифрой и возвращает её кликабельного предка. */
    private fun findKeyboardKeyNode(root: AccessibilityNodeInfo, key: String): AccessibilityNodeInfo? {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        while (queue.isNotEmpty() && visited < 400) {
            val node = queue.removeFirst()
            visited++
            val txt = node.text?.toString().orEmpty()
            if (txt.equals(key, ignoreCase = true) && node.childCount == 0) {
                var clickable: AccessibilityNodeInfo? = node
                var hops = 0
                while (clickable != null && !clickable.isClickable && hops < 4) {
                    clickable = clickable.parent
                    hops++
                }
                return clickable ?: node
            }
            for (i in 0 until node.childCount) {
                val c = try { node.getChild(i) } catch (_: Exception) { null }
                if (c != null) queue.add(c)
            }
        }
        return null
    }

    /** В ТВ-версии Kick нет поля ввода: поиск рисует собственную клавиатуру из кнопок a..z, 0..9 и «_». */
    private fun hasOnScreenKeyboard(root: AccessibilityNodeInfo): Boolean {
        return findKeyboardKeyNode(root, "a") != null &&
            findKeyboardKeyNode(root, "z") != null &&
            findKeyboardKeyNode(root, "5") != null
    }

    private suspend fun typeViaOnScreenKeyboard(query: String): Boolean {
        var typed = 0
        for (ch in query.lowercase(Locale.ROOT)) {
            if (!(ch in 'a'..'z' || ch in '0'..'9' || ch == '_')) continue
            val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: return typed > 0
            val key = findKeyboardKeyNode(root, ch.toString()) ?: continue
            key.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            if (!key.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                ShellKeyController.sendKeyEvent(KeyEvent.KEYCODE_DPAD_CENTER)
            }
            typed++
            delay(160L)
        }
        return typed > 0
    }

    private fun findClickableInSubtree(node: AccessibilityNodeInfo, depth: Int = 0): AccessibilityNodeInfo? {
        if (node.isClickable) return node
        if (depth >= 5) return null
        for (i in 0 until node.childCount) {
            val c = try { node.getChild(i) } catch (_: Exception) { null } ?: continue
            val found = findClickableInSubtree(c, depth + 1)
            if (found != null) return found
        }
        return null
    }

    /**
     * В Compose-карточке канала текст ника и кликабельная область (аватар) лежат в РАЗНЫХ ветках дерева,
     * поэтому поднимаемся от текста к контейнеру карточки и кликаем первый кликабельный узел внутри него.
     */
    private fun clickCardContaining(textNode: AccessibilityNodeInfo): Boolean {
        var cur: AccessibilityNodeInfo? = textNode
        var hops = 0
        while (cur != null && hops < 5) {
            val target = findClickableInSubtree(cur)
            if (target != null) {
                target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                if (target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
            }
            cur = cur.parent
            hops++
        }
        return false
    }

    /** Нажимает карточку канала с ником slug; если точного совпадения нет — первую карточку в области результатов. */
    private fun clickChannelCard(root: AccessibilityNodeInfo, slug: String): Boolean {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        val resultClickables = ArrayList<Pair<Int, AccessibilityNodeInfo>>()
        val rect = android.graphics.Rect()
        while (queue.isNotEmpty() && visited < 700) {
            val node = queue.removeFirst()
            visited++
            val txt = node.text?.toString().orEmpty()
            if (node.childCount == 0 && txt.equals(slug, ignoreCase = true)) {
                if (clickCardContaining(node)) return true
            }
            if (node.isClickable) {
                node.getBoundsInScreen(rect)
                // область результатов: правее экранной клавиатуры и ниже верхней панели
                if (rect.left >= 536 && rect.top in 300..700) {
                    resultClickables.add((rect.top * 10000 + rect.left) to node)
                }
            }
            for (i in 0 until node.childCount) {
                val c = try { node.getChild(i) } catch (_: Exception) { null }
                if (c != null) queue.add(c)
            }
        }
        for ((_, n) in resultClickables.sortedBy { it.first }) {
            n.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
            if (n.performAction(AccessibilityNodeInfo.ACTION_CLICK)) return true
        }
        return false
    }

    /** 0 — ничего не получилось, 1 — текст введён в поле, 2 — набран на экранной клавиатуре. */
    private suspend fun fillSearchQuery(root: AccessibilityNodeInfo, query: String): Int {
        if (hasOnScreenKeyboard(root)) {
            return if (typeViaOnScreenKeyboard(query)) 2 else 0
        }
        return if (trySetTextInEditableNode(root, query)) 1 else 0
    }

    private fun runAutomatedInAppSearch(targetPkg: String, query: String) {
        val cleanQuery = query.trim()
        if (cleanQuery.isEmpty()) return
        inAppSearchJob?.cancel()
        inAppSearchJob = serviceScope.launch {
            copyToClipboard(cleanQuery)

            // Ждём, пока окно целевого приложения реально окажется на переднем плане (до ~9 секунд)
            var waitedMs = 0L
            while (waitedMs < 9000L) {
                val r = try { rootInActiveWindow } catch (_: Exception) { null }
                if (r?.packageName?.toString() == targetPkg) break
                delay(400L)
                waitedMs += 400L
            }

            var fillMode = 0
            var leftPanelTried = false
            for (step in 0 until 8) {
                delay(if (step == 0) 1000L else 700L)
                val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: continue
                if (root.packageName?.toString() != targetPkg) continue

                fillMode = fillSearchQuery(root, cleanQuery)
                if (fillMode != 0) break

                if (clickNodeMatchingKeywords(root, inAppSearchKeywords)) {
                    delay(1000L)
                    val rootAfterClick = try { rootInActiveWindow } catch (_: Exception) { null }
                    if (rootAfterClick != null) {
                        fillMode = fillSearchQuery(rootAfterClick, cleanQuery)
                        if (fillMode != 0) break
                    }
                } else if (step >= 2 && !leftPanelTried) {
                    leftPanelTried = true
                    if (focusSearchInLeftNavPanel(targetPkg)) {
                        delay(900L)
                        val rootAfterNav = try { rootInActiveWindow } catch (_: Exception) { null }
                        if (rootAfterNav != null) {
                            fillMode = fillSearchQuery(rootAfterNav, cleanQuery)
                            if (fillMode != 0) break
                        }
                    }
                }
            }

            if (fillMode == 0) return@launch

            val isSpotifySearch = targetPkg.lowercase(Locale.ROOT).contains("spotify")
            if (fillMode == 2) {
                // Экранная клавиатура обновляет выдачу сразу при наборе, Enter не нужен
                if (isSpotifySearch) return@launch
                delay(1500L)
                val rootResult = try { rootInActiveWindow } catch (_: Exception) { null }
                if (rootResult != null) {
                    if (!clickChannelCard(rootResult, cleanQuery)) {
                        clickResultNodeMatchingQuery(rootResult, cleanQuery)
                    }
                }
                return@launch
            }

            delay(400L)
            ShellKeyController.sendKeyEvent(KeyEvent.KEYCODE_ENTER)
            if (isSpotifySearch) return@launch
            delay(1000L)
            val rootResult = try { rootInActiveWindow } catch (_: Exception) { null }
            if (rootResult == null || !(clickChannelCard(rootResult, cleanQuery) || clickResultNodeMatchingQuery(rootResult, cleanQuery))) {
                ShellKeyController.sendKeyEvent(KeyEvent.KEYCODE_DPAD_DOWN)
                delay(250L)
                ShellKeyController.sendKeyEvent(KeyEvent.KEYCODE_DPAD_CENTER)
            }
        }
    }

    private fun copyToClipboard(text: String) {
        try {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return
            cm.setPrimaryClip(ClipData.newPlainText("ai_input", text))
        } catch (_: Exception) {
        }
    }

    private fun typeTextIntoActiveField(text: String): Boolean {
        val clean = text.trim()
        if (clean.isEmpty()) return false
        copyToClipboard(clean)
        val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: return false
        return trySetTextInEditableNode(root, clean)
    }

    private fun trySetTextInEditableNode(root: AccessibilityNodeInfo, text: String): Boolean {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        while (queue.isNotEmpty() && visited < 120) {
            val node = queue.removeFirst()
            visited++
            val cls = node.className?.toString().orEmpty()
            if (node.isEditable || cls.contains("EditText", ignoreCase = true) || cls.contains("AutoComplete", ignoreCase = true)) {
                node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                val args = Bundle().apply {
                    putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
                }
                val ok = node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
                if (!ok) {
                    node.performAction(AccessibilityNodeInfo.ACTION_PASTE)
                }
                return true
            }
            for (i in 0 until node.childCount) {
                val c = try { node.getChild(i) } catch (_: Exception) { null }
                if (c != null) queue.add(c)
            }
        }
        return false
    }

    private fun extractCleanScreenSummaryForAgent(): String {
        val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: return "Главный экран лаунчера"
        val pkg = root.packageName?.toString().orEmpty()
        if (pkg.isEmpty() || pkg == packageName) {
            return "Главный экран лаунчера"
        }
        val appName = MediaStateBus.resolveAppLabel(this, pkg)
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        val items = mutableListOf<String>()
        var visited = 0
        while (queue.isNotEmpty() && visited < 110 && items.size < 6) {
            val node = queue.removeFirst()
            visited++
            val raw = (node.text ?: node.contentDescription)?.toString()
                ?.replace("[", "")
                ?.replace("]", "")
                ?.replace("\n", " ")
                ?.trim()
                .orEmpty()
            if (raw.length in 2..48 && !isNoiseUiText(raw) && !raw.equals(appName, ignoreCase = true) && !items.contains(raw)) {
                items.add(raw)
            }
            for (i in 0 until node.childCount) {
                val c = try { node.getChild(i) } catch (_: Exception) { null }
                if (c != null) queue.add(c)
            }
        }
        return if (items.isEmpty()) {
            "Открыто приложение: $appName"
        } else {
            "Открыто приложение: $appName (на экране: ${items.joinToString(", ")})"
        }
    }

    private fun clickElementOnScreenByText(targetText: String): Boolean {
        val clean = targetText.trim().lowercase(Locale.ROOT)
        if (clean.isEmpty()) return false
        val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: return false
        return clickNodeMatchingKeywords(root, listOf(clean))
    }

    private fun clickNodeMatchingKeywords(root: AccessibilityNodeInfo, keywords: List<String>): Boolean {
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        while (queue.isNotEmpty() && visited < 140) {
            val node = queue.removeFirst()
            visited++
            val txt = node.text?.toString()?.lowercase(Locale.ROOT).orEmpty()
            val desc = node.contentDescription?.toString()?.lowercase(Locale.ROOT).orEmpty()
            val vid = node.viewIdResourceName?.lowercase(Locale.ROOT).orEmpty()
            val matched = keywords.any { kw ->
                txt.contains(kw) || desc.contains(kw) || vid.contains(kw)
            }
            if (matched) {
                var clickable: AccessibilityNodeInfo? = node
                var hops = 0
                while (clickable?.isClickable == false && hops < 4) {
                    clickable = clickable?.parent
                    hops++
                }
                val target = clickable ?: node
                target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                if (target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    return true
                }
            }
            for (i in 0 until node.childCount) {
                val c = try { node.getChild(i) } catch (_: Exception) { null }
                if (c != null) queue.add(c)
            }
        }
        return false
    }

    private fun clickResultNodeMatchingQuery(root: AccessibilityNodeInfo, query: String): Boolean {
        val kw = query.lowercase(Locale.ROOT)
        val queue = ArrayDeque<AccessibilityNodeInfo>()
        queue.add(root)
        var visited = 0
        while (queue.isNotEmpty() && visited < 140) {
            val node = queue.removeFirst()
            visited++
            val cls = node.className?.toString().orEmpty()
            if (node.isEditable || cls.contains("EditText", ignoreCase = true)) {
                continue
            }
            val txt = node.text?.toString()?.lowercase(Locale.ROOT).orEmpty()
            val desc = node.contentDescription?.toString()?.lowercase(Locale.ROOT).orEmpty()
            if (txt.contains(kw) || desc.contains(kw)) {
                var clickable: AccessibilityNodeInfo? = node
                var hops = 0
                while (clickable?.isClickable == false && hops < 4) {
                    clickable = clickable?.parent
                    hops++
                }
                val target = clickable ?: node
                target.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
                if (target.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                    return true
                }
            }
            for (i in 0 until node.childCount) {
                val c = try { node.getChild(i) } catch (_: Exception) { null }
                if (c != null) queue.add(c)
            }
        }
        return false
    }

    private fun triggerDynamicIslandWithRemoteText(spokenText: String) {
        uiHandler.post {
            ensureDynamicIslandOverlayCreated()
            refreshOverlayAccentColors()
            AssistantVoiceSpeaker.stop(this)
            islandIsSpeaking = false
            uiHandler.removeCallbacks(hideIslandRunnable)
            geminiQueryJob?.cancel()
            stopVoiceListeningInternal()

            val root = islandRoot ?: return@post
            islandVisible = true
            DynamicIslandBus.notifyIslandVisibility(true)
            if (root.visibility != View.VISIBLE) {
                root.alpha = 0f
                root.visibility = View.VISIBLE
                root.animate().alpha(1f).setDuration(140L).start()
            } else {
                root.animate().cancel()
                root.alpha = 1f
            }
            handleRecognizedVoiceText(spokenText)
        }
    }

    private fun injectAccessibilityDpadOrCenter(directionOrCenter: String): Boolean {
        val root = try { rootInActiveWindow } catch (_: Exception) { null } ?: return false
        val focused = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: root
        return when (directionOrCenter.uppercase(Locale.US)) {
            "CENTER", "OK" -> focused.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            "UP" -> focused.focusSearch(View.FOCUS_UP)?.performAction(AccessibilityNodeInfo.ACTION_FOCUS) == true
            "DOWN" -> focused.focusSearch(View.FOCUS_DOWN)?.performAction(AccessibilityNodeInfo.ACTION_FOCUS) == true
            "LEFT" -> focused.focusSearch(View.FOCUS_LEFT)?.performAction(AccessibilityNodeInfo.ACTION_FOCUS) == true
            "RIGHT" -> focused.focusSearch(View.FOCUS_RIGHT)?.performAction(AccessibilityNodeInfo.ACTION_FOCUS) == true
            else -> false
        }
    }

    private fun performGlobalNavigationCommand(action: String) {
        when (action.uppercase(Locale.US)) {
            "BACK" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "HOME" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "RECENTS" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "NOTIFICATIONS" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
        }
    }
}
