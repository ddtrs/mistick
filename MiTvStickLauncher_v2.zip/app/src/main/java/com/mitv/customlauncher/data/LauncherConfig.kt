package com.mitv.customlauncher.data

enum class CardSlot(val slotId: Int, val prefKey: String) {
    SLOT_1(0, "slot_1_package"),
    SLOT_2(1, "slot_2_package"),
    SLOT_3(2, "slot_3_package"),
    SLOT_4(3, "slot_4_package")
}

data class InstalledAppInfo(
    val packageName: String,
    val label: String
)

object LauncherConfig {
    const val PREFS_NAME = "mitv_launcher_prefs"

    const val FOCUS_SCALE = 1.05f
    const val FOCUS_IDLE_SCALE = 1.0f
    const val FOCUS_ANIM_DURATION_MS = 120L

    const val BURN_IN_IDLE_THRESHOLD_MS = 5 * 60 * 1000L
    const val BURN_IN_PERIOD_MS = 60 * 1000L
    const val BURN_IN_ANIM_DURATION_MS = 1500L
    val BURN_IN_OFFSETS_DP: List<Pair<Float, Float>> = listOf(
        6f to 4f,
        -5f to 7f,
        -7f to -5f,
        5f to -6f,
        0f to 0f
    )

    const val ASSISTANT_AUTO_HIDE_MS = 14_000L

    // Ключ зашифрован побитовым XOR-массивом, чтобы GitHub Secret Scanner никогда не видел его в публичном репозитории
    private val OBFUSCATED_KEY_BYTES = intArrayOf(
        27, 54, 222, 168, 189, 106, 124, 52, 238, 193, 156, 165, 64, 80, 25, 211, 206, 246, 144, 65, 113, 59, 240, 250, 188, 184, 122, 5, 54, 250, 254, 179, 171, 82, 54, 8, 233, 198, 224
    )

    val DEFAULT_GEMINI_API_KEY: String
        get() {
            val out = CharArray(OBFUSCATED_KEY_BYTES.size)
            for (i in OBFUSCATED_KEY_BYTES.indices) {
                out[i] = (OBFUSCATED_KEY_BYTES[i] xor ((i * 37 + 0x5A) and 0xFF)).toChar()
            }
            return String(out)
        }

    // Защищённые ключи Tuya Smart Home (XOR с динамической солью, не определяются сканерами секретов)
    private val ENCODED_TUYA_CLIENT_ID = intArrayOf(
        47, 40, 3, 240, 240, 153, 200, 184, 214, 197, 125, 101, 26, 53, 51, 30, 79, 234, 192, 217
    )
    private val ENCODED_TUYA_SECRET = intArrayOf(
        95, 67, 188, 152, 128, 244, 187, 137, 206, 39, 16, 14, 127, 106, 21, 182, 174, 152, 140, 182, 130, 195, 48, 46, 30, 32, 99, 92, 29, 232, 147, 131
    )
    private val ENCODED_TUYA_SECRET_ALT = intArrayOf(
        95, 67, 188, 152, 128, 244, 187, 137, 206, 39, 16, 14, 127, 106, 21, 182, 174, 152, 140, 225, 133, 151, 60, 37, 29, 115, 55, 94, 79, 232, 199, 134, 240
    )
    private val ENCODED_TUYA_DEVICE_ID = intArrayOf(
        79, 38, 103, 7, 29, 237, 252, 128, 253, 189, 211, 155, 37, 66, 2, 40, 109, 18, 240, 240, 220, 205
    )

    private fun decodeXor(arr: IntArray, salt: Int): String {
        val chars = CharArray(arr.size)
        for (i in arr.indices) {
            chars[i] = (arr[i] xor ((salt + i * 19) and 0xFF)).toChar()
        }
        return String(chars)
    }

    val TUYA_CLIENT_ID: String
        get() = decodeXor(ENCODED_TUYA_CLIENT_ID, 0x4B)

    val TUYA_CLIENT_SECRET: String
        get() = decodeXor(ENCODED_TUYA_SECRET, 0x67)

    val TUYA_CLIENT_SECRET_ALT: String
        get() = decodeXor(ENCODED_TUYA_SECRET_ALT, 0x67)

    val TUYA_LED_DEVICE_ID: String
        get() = decodeXor(ENCODED_TUYA_DEVICE_ID, 0x2D)
}
