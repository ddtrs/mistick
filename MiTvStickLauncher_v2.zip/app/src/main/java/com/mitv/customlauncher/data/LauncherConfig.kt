package com.mitv.customlauncher.data

enum class CardSlot(val slotId: Int, val prefKey: String) {
    SLOT_1(0, "slot_1_package"),
    SLOT_2(1, "slot_2_package"),
    SLOT_3(2, "slot_3_package"),
    SLOT_4(3, "slot_4_package")
}

data class InstalledAppInfo(
    val packageName: String,
    val label: String
)

/**
 * Конфигурация лаунчера с двухконтурной защитой секретов:
 * 1. Облачный прокси-шлюз Cloudflare Worker (https://delicate-hill-35ee.ddtrs66.workers.dev)
 * 2. Нативное аппаратное хранилище в скомпилированном Rust-бинарнике (liblauncher_native.so через NativeCore)
 */
object LauncherConfig {
    const val PREFS_NAME = "mitv_launcher_prefs"

    const val FOCUS_SCALE = 1.05f
    const val FOCUS_IDLE_SCALE = 1.0f
    const val FOCUS_ANIM_DURATION_MS = 120L

    const val BURN_IN_IDLE_THRESHOLD_MS = 5 * 60 * 1000L
    const val BURN_IN_PERIOD_MS = 60 * 1000L
    const val BURN_IN_ANIM_DURATION_MS = 1500L
    val BURN_IN_OFFSETS_DP: List<Pair<Float, Float>> = listOf(
        6f to 4f,
        -5f to 7f,
        -7f to -5f,
        5f to -6f,
        0f to 0f
    )

    const val ASSISTANT_AUTO_HIDE_MS = 14_000L

    // Защищённый облачный шлюз Cloudflare Worker
    const val CLOUDFLARE_GATEWAY_URL = "https://delicate-hill-35ee.ddtrs66.workers.dev"

    val GATEWAY_APP_SECRET: String
        get() = NativeCore.readVaultEntry(105)

    val GEMINI_KEYS: List<String>
        get() = (0 until NativeCore.VAULT_GEMINI_COUNT)
            .map { NativeCore.readVaultEntry(it) }
            .filter { it.isNotEmpty() }

    val DEFAULT_GEMINI_API_KEY: String
        get() = GEMINI_KEYS.firstOrNull().orEmpty()

    val TUYA_CLIENT_ID: String
        get() = NativeCore.readVaultEntry(100)

    val TUYA_CLIENT_SECRET: String
        get() = NativeCore.readVaultEntry(101)

    val TUYA_CLIENT_SECRET_ALT: String
        get() = NativeCore.readVaultEntry(102)

    val TUYA_LED_DEVICE_ID: String
        get() = NativeCore.readVaultEntry(103)

    val TUYA_BULB_DEVICE_ID: String
        get() = NativeCore.readVaultEntry(104)
}
