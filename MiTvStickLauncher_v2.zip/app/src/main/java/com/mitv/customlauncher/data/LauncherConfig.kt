package com.mitv.customlauncher.data

enum class CardSlot(val slotId: Int, val prefKey: String) {
    SLOT_1(0, "slot_1_package"),
    SLOT_2(1, "slot_2_package"),
    SLOT_3(2, "slot_3_package"),
    SLOT_4(3, "slot_4_package")
}

object LauncherConfig {
    const val PREFS_NAME = "mitv_launcher_prefs"
    const val FOCUS_SCALE = 1.045f
    const val FOCUS_IDLE_SCALE = 1.0f
    const val FOCUS_ANIM_DURATION_MS = 110L
    const val BURN_IN_INTERVAL_MS = 180_000L
    const val BURN_IN_MAX_OFFSET_DP = 3f
    const val ASSISTANT_AUTO_HIDE_MS = 14_000L
    const val DEFAULT_GEMINI_API_KEY = "AQ.Ab8RN6IQYg0Rj62WlpcPbj6Bfulr0lrCDHRyDQnqkhUeTjCjpQ"
}
