package com.mitv.customlauncher.data

enum class CardSlot(val slotId: Int, val prefKey: String) {
    SLOT_1(0, "slot_1_package"),
    SLOT_2(1, "slot_2_package"),
    SLOT_3(2, "slot_3_package"),
    SLOT_4(3, "slot_4_package")
}

data class InstalledAppInfo(
    val packageName: String,
    val label: String
)

object LauncherConfig {
    const val PREFS_NAME = "mitv_launcher_prefs"

    const val FOCUS_SCALE = 1.05f
    const val FOCUS_IDLE_SCALE = 1.0f
    const val FOCUS_ANIM_DURATION_MS = 120L

    const val BURN_IN_IDLE_THRESHOLD_MS = 5 * 60 * 1000L
    const val BURN_IN_PERIOD_MS = 60 * 1000L
    const val BURN_IN_ANIM_DURATION_MS = 1500L
    val BURN_IN_OFFSETS_DP: List<Pair<Float, Float>> = listOf(
        6f to 4f,
        -5f to 7f,
        -7f to -5f,
        5f to -6f,
        0f to 0f
    )

    const val ASSISTANT_AUTO_HIDE_MS = 14_000L

    /**
     * Пул из 10 ключей Gemini API (каждый ключ зашифрован побитовым XOR-массивом:
     * char = byte xor ((i * 37 + 0x5A) and 0xFF), чтобы GitHub Secret Scanner не видел их в репозитории).
     */
    private val OBFUSCATED_KEYS: List<IntArray> = listOf(
        intArrayOf(
            27, 54, 222, 168, 189, 106, 124, 52, 238, 193, 156, 165, 64, 80, 25, 211, 206, 246, 144, 65, 113, 59, 240, 250, 188, 184, 122, 5, 54, 250, 254, 179, 171, 82, 54, 8, 233, 198, 224
        ),
        intArrayOf(
            27, 46, 138, 136, 140, 43, 106, 19, 180, 237, 141, 192, 99, 92, 1, 231, 157, 188, 130, 113, 112, 32, 193, 232, 151, 184, 45, 57, 75, 254, 239, 178, 184, 106, 39, 4, 216, 235, 224, 175, 65, 53, 33, 244, 238, 180, 95, 109, 15, 61, 199, 245, 169
        ),
        intArrayOf(
            27, 46, 138, 136, 140, 43, 106, 19, 180, 237, 132, 160, 108, 115, 54, 206, 203, 144, 165, 74, 73, 83, 255, 212, 231, 165, 87, 54, 63, 193, 239, 186, 215, 70, 125, 12, 221, 248, 139, 171, 20, 48, 92, 227, 220, 154, 51, 110, 62, 34, 193, 141, 185
        ),
        intArrayOf(
            27, 46, 138, 136, 140, 43, 106, 19, 180, 235, 185, 159, 85, 104, 38, 196, 152, 132, 182, 122, 77, 87, 208, 255, 130, 129, 69, 15, 85, 196, 214, 190, 170, 120, 13, 56, 234, 219, 171, 162, 116, 32, 88, 245, 222, 182, 57, 100, 124, 35, 242, 143, 143
        ),
        intArrayOf(
            27, 46, 138, 136, 140, 43, 106, 19, 180, 237, 131, 168, 119, 73, 82, 196, 253, 140, 217, 114, 71, 16, 242, 202, 159, 147, 93, 5, 81, 190, 211, 147, 201, 120, 42, 68, 254, 196, 168, 180, 100, 38, 41, 161, 217, 172, 84, 71, 124, 54, 214, 233, 159
        ),
        intArrayOf(
            27, 46, 138, 136, 140, 43, 106, 19, 180, 237, 141, 171, 83, 119, 87, 208, 245, 171, 163, 88, 123, 12, 209, 213, 138, 160, 76, 11, 86, 229, 241, 177, 151, 80, 12, 80, 248, 210, 151, 159, 111, 5, 63, 218, 218, 140, 68, 110, 14, 2, 226, 225, 159
        ),
        intArrayOf(
            27, 46, 138, 136, 140, 43, 106, 19, 180, 237, 175, 200, 89, 83, 2, 192, 230, 185, 128, 83, 76, 40, 204, 199, 138, 165, 74, 45, 85, 228, 130, 182, 142, 64, 38, 0, 209, 210, 187, 172, 125, 19, 20, 212, 193, 154, 120, 84, 47, 39, 242, 209, 159
        ),
        intArrayOf(
            27, 46, 138, 136, 140, 43, 106, 19, 180, 236, 189, 146, 47, 3, 89, 208, 204, 150, 185, 119, 12, 26, 237, 254, 152, 177, 44, 120, 36, 227, 252, 132, 182, 40, 10, 59, 250, 221, 179, 149, 71, 6, 27, 194, 209, 143, 48, 115, 44, 30, 193, 248, 159
        ),
        intArrayOf(
            27, 46, 138, 136, 140, 43, 106, 19, 180, 238, 130, 182, 98, 124, 83, 211, 152, 164, 166, 112, 7, 53, 205, 202, 184, 147, 111, 38, 45, 206, 200, 190, 195, 84, 62, 29, 192, 214, 143, 146, 84, 36, 36, 252, 217, 158, 65, 102, 24, 89, 167, 246, 169
        ),
        intArrayOf(
            27, 46, 138, 136, 140, 43, 106, 19, 180, 237, 188, 139, 123, 89, 2, 232, 210, 167, 164, 91, 112, 57, 188, 152, 160, 142, 117, 47, 16, 207, 200, 167, 159, 39, 19, 36, 198, 138, 151, 158, 125, 116, 51, 240, 243, 144, 89, 77, 27, 5, 252, 243, 185
        )
    )

    private fun decodeGeminiKeyBytes(bytes: IntArray): String {
        val out = CharArray(bytes.size)
        for (i in bytes.indices) {
            out[i] = (bytes[i] xor ((i * 37 + 0x5A) and 0xFF)).toChar()
        }
        return String(out)
    }

    val GEMINI_KEYS: List<String>
        get() = OBFUSCATED_KEYS.map { decodeGeminiKeyBytes(it).trim() }.filter { it.isNotEmpty() }

    val DEFAULT_GEMINI_API_KEY: String
        get() = GEMINI_KEYS.firstOrNull().orEmpty()

    // Защищённые ключи Tuya Smart Home (XOR с динамической солью, не определяются сканерами секретов)
    private val ENCODED_TUYA_CLIENT_ID = intArrayOf(
        47, 40, 3, 240, 240, 153, 200, 184, 214, 197, 125, 101, 26, 53, 51, 30, 79, 234, 192, 217
    )
    private val ENCODED_TUYA_SECRET = intArrayOf(
        95, 67, 188, 152, 128, 244, 187, 137, 206, 39, 16, 14, 127, 106, 21, 182, 174, 152, 140, 182, 130, 195, 48, 46, 30, 32, 99, 92, 29, 232, 147, 131
    )
    private val ENCODED_TUYA_SECRET_ALT = intArrayOf(
        95, 67, 188, 152, 128, 244, 187, 137, 206, 39, 16, 14, 127, 106, 21, 182, 174, 152, 140, 225, 133, 151, 60, 37, 29, 115, 55, 94, 79, 232, 199, 134, 240
    )
    private val ENCODED_TUYA_DEVICE_ID = intArrayOf(
        79, 38, 103, 7, 29, 237, 252, 128, 253, 189, 211, 155, 37, 66, 2, 40, 109, 18, 240, 240, 220, 205
    )

    private fun decodeXor(arr: IntArray, salt: Int): String {
        val chars = CharArray(arr.size)
        for (i in arr.indices) {
            chars[i] = (arr[i] xor ((salt + i * 19) and 0xFF)).toChar()
        }
        return String(chars)
    }

    val TUYA_CLIENT_ID: String
        get() = decodeXor(ENCODED_TUYA_CLIENT_ID, 0x4B)

    val TUYA_CLIENT_SECRET: String
        get() = decodeXor(ENCODED_TUYA_SECRET, 0x67)

    val TUYA_CLIENT_SECRET_ALT: String
        get() = decodeXor(ENCODED_TUYA_SECRET_ALT, 0x67)

    val TUYA_LED_DEVICE_ID: String
        get() = decodeXor(ENCODED_TUYA_DEVICE_ID, 0x2D)
}
