#![allow(non_snake_case)]

mod jni_sys;
mod blur_engine;
mod ambilight_core;
mod glyph_extractor;
mod spring_physics;
mod voice_audio;
mod input_interceptor;

use jni_sys::*;
use std::slice;

#[no_mangle]
pub unsafe extern "system" fn Java_com_mitv_customlauncher_data_NativeCore_nativeBlurAndTint(
    env: *mut JNIEnv,
    _clazz: jclass,
    pixels_arr: jintArray,
    width: jint,
    height: jint,
    radius: jint,
    tint_argb: jint,
) {
    let len = get_array_length(env, pixels_arr);
    if len == 0 || width <= 0 || height <= 0 {
        return;
    }
    let ptr = lock_primitive_array(env, pixels_arr) as *mut u32;
    if !ptr.is_null() {
        let slice = slice::from_raw_parts_mut(ptr, len);
        blur_engine::fast_blur_and_tint(
            slice,
            width as usize,
            height as usize,
            radius as usize,
            tint_argb as u32,
        );
        unlock_primitive_array(env, pixels_arr, ptr as *mut _, 0);
    }
}

#[no_mangle]
pub unsafe extern "system" fn Java_com_mitv_customlauncher_data_NativeCore_nativeExtractDominantCoverHsv(
    env: *mut JNIEnv,
    _clazz: jclass,
    pixels_arr: jintArray,
    width: jint,
    height: jint,
) -> jint {
    let len = get_array_length(env, pixels_arr);
    if len == 0 || width <= 0 || height <= 0 {
        return (184 << 16) | 95;
    }
    let ptr = lock_primitive_array(env, pixels_arr) as *const u32;
    if ptr.is_null() {
        return (184 << 16) | 95;
    }
    let slice = slice::from_raw_parts(ptr, len);
    let packed = ambilight_core::extract_dominant_cover_hsv(slice, width as usize, height as usize);
    unlock_primitive_array(env, pixels_arr, ptr as *mut _, JNI_ABORT);
    packed
}

#[no_mangle]
pub unsafe extern "system" fn Java_com_mitv_customlauncher_data_NativeCore_nativeExtractMonochromeGlyph(
    env: *mut JNIEnv,
    _clazz: jclass,
    pixels_arr: jintArray,
    size: jint,
) -> jint {
    let len = get_array_length(env, pixels_arr);
    if len == 0 || size <= 0 {
        return 0;
    }
    let ptr = lock_primitive_array(env, pixels_arr) as *mut u32;
    if ptr.is_null() {
        return 0;
    }
    let slice = slice::from_raw_parts_mut(ptr, len);
    let visible = glyph_extractor::extract_monochrome_glyph(slice, size as usize);
    unlock_primitive_array(env, pixels_arr, ptr as *mut _, 0);
    visible
}

#[no_mangle]
pub unsafe extern "system" fn Java_com_mitv_customlauncher_data_NativeCore_nativeEvaluateSpring(
    _env: *mut JNIEnv,
    _clazz: jclass,
    progress: jfloat,
    damping_ratio: jfloat,
    angular_freq: jfloat,
) -> jfloat {
    spring_physics::evaluate_spring(progress, damping_ratio, angular_freq)
}

#[no_mangle]
pub unsafe extern "system" fn Java_com_mitv_customlauncher_data_NativeCore_nativeComputePcmRms(
    env: *mut JNIEnv,
    _clazz: jclass,
    pcm_arr: jbyteArray,
    valid_len: jint,
) -> jint {
    let arr_len = get_array_length(env, pcm_arr);
    let len = if valid_len > 0 {
        (valid_len as usize).min(arr_len)
    } else {
        arr_len
    };
    if len < 2 {
        return 0;
    }
    let ptr = lock_primitive_array(env, pcm_arr) as *const u8;
    if ptr.is_null() {
        return 0;
    }
    let slice = slice::from_raw_parts(ptr, len);
    let rms = voice_audio::compute_pcm_rms(slice);
    unlock_primitive_array(env, pcm_arr, ptr as *mut _, JNI_ABORT);
    rms
}

#[no_mangle]
pub unsafe extern "system" fn Java_com_mitv_customlauncher_data_NativeCore_nativeTrimPcmSilenceBounds(
    env: *mut JNIEnv,
    _clazz: jclass,
    pcm_arr: jbyteArray,
    sample_rate: jint,
) -> jlong {
    let len = get_array_length(env, pcm_arr);
    if len < 4 {
        return len as jlong;
    }
    let ptr = lock_primitive_array(env, pcm_arr) as *const u8;
    if ptr.is_null() {
        return len as jlong;
    }
    let slice = slice::from_raw_parts(ptr, len);
    let bounds = voice_audio::trim_pcm_silence_bounds(slice, sample_rate);
    unlock_primitive_array(env, pcm_arr, ptr as *mut _, JNI_ABORT);
    bounds
}

#[no_mangle]
pub unsafe extern "system" fn Java_com_mitv_customlauncher_data_NativeCore_nativeClassifyRemoteKey(
    _env: *mut JNIEnv,
    _clazz: jclass,
    key_code: jint,
    scan_code: jint,
) -> jint {
    input_interceptor::classify_remote_key(key_code, scan_code)
}
