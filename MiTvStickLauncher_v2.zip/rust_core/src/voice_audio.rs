/// Native 16-bit PCM Voice Activity Detection (VAD) & Silence Trimmer for Gemini AI Assistant
pub fn compute_pcm_rms(bytes: &[u8]) -> i32 {
    let sample_count = bytes.len() / 2;
    if sample_count == 0 {
        return 0;
    }
    let mut sum_sq: f64 = 0.0;
    for chunk in bytes.chunks_exact(2) {
        let sample = i16::from_le_bytes([chunk[0], chunk[1]]) as f64;
        sum_sq += sample * sample;
    }
    (sum_sq / (sample_count as f64)).sqrt() as i32
}

/// Returns packed `((start_byte as i64) << 32) | (end_byte as i64)`
pub fn trim_pcm_silence_bounds(bytes: &[u8], sample_rate: i32) -> i64 {
    let total_samples = bytes.len() / 2;
    if total_samples < 1600 {
        return bytes.len() as i64;
    }
    let frame_samples = 320usize;
    let total_frames = total_samples / frame_samples;
    let mut first_speech: Option<usize> = None;
    let mut last_speech: Option<usize> = None;

    for f in 0..total_frames {
        let base_byte = f * frame_samples * 2;
        let mut sum_sq: f64 = 0.0;
        for s in 0..frame_samples {
            let idx = base_byte + s * 2;
            let sample = i16::from_le_bytes([bytes[idx], bytes[idx + 1]]) as f64;
            sum_sq += sample * sample;
        }
        let rms = (sum_sq / (frame_samples as f64)).sqrt();
        if rms > 240.0 {
            if first_speech.is_none() {
                first_speech = Some(f);
            }
            last_speech = Some(f);
        }
    }

    if let (Some(first), Some(last)) = (first_speech, last_speech) {
        let sr = sample_rate.max(8000) as usize;
        let pre_frames = (sr * 12) / (100 * frame_samples);
        let post_frames = (sr * 16) / (100 * frame_samples);
        let start_frame = first.saturating_sub(pre_frames);
        let end_frame = (last + post_frames + 1).min(total_frames);
        let start_byte = (start_frame * frame_samples * 2).min(bytes.len());
        let end_byte = (end_frame * frame_samples * 2).min(bytes.len());
        if end_byte > start_byte {
            return ((start_byte as i64) << 32) | (end_byte as i64);
        }
    }

    bytes.len() as i64
}
