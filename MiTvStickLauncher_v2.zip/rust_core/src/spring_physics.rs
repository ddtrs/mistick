/// Analytical Underdamped Spring Physics Evaluator (Apple TV / tvOS feel)
#[inline]
pub fn evaluate_spring(progress: f32, damping_ratio: f32, angular_freq: f32) -> f32 {
    let t = progress.clamp(0.0, 1.0);
    if t <= 0.0 {
        return 0.0;
    }
    if t >= 1.0 {
        return 1.0;
    }
    let zeta = damping_ratio.clamp(0.45, 0.99);
    let omega = angular_freq.clamp(6.0, 22.0);
    let omega_d = omega * (1.0 - zeta * zeta).sqrt();
    let decay = (-zeta * omega * t).exp();
    let cos_part = (omega_d * t).cos();
    let sin_part = ((zeta * omega) / omega_d) * (omega_d * t).sin();
    let raw = 1.0 - decay * (cos_part + sin_part);

    // Ensure exact 1.0 convergence at t = 1.0
    let end_decay = (-zeta * omega).exp();
    let end_val = 1.0 - end_decay * (omega_d.cos() + ((zeta * omega) / omega_d) * omega_d.sin());
    if end_val.abs() > 1e-4 {
        (raw / end_val).clamp(0.0, 1.08)
    } else {
        raw.clamp(0.0, 1.08)
    }
}

/// Exact analytical batch stepper for stateful velocity-preserving springs.
///
/// Layout per spring (stride = 5 floats):
///   [base + 0] = pos (in/out)
///   [base + 1] = vel (in/out, units/sec)
///   [base + 2] = target (in)
///   [base + 3] = stiffness k = omega^2 (in)
///   [base + 4] = damping_ratio zeta (in)
pub fn step_springs_batch(data: &mut [f32], count: usize, dt_raw: f32) {
    let dt = dt_raw.clamp(0.001, 0.05);
    let max_count = count.min(data.len() / 5);
    for i in 0..max_count {
        let base = i * 5;
        let pos = data[base];
        let vel = data[base + 1];
        let target = data[base + 2];
        let stiffness = data[base + 3].clamp(25.0, 4000.0);
        let zeta = data[base + 4].clamp(0.35, 1.6);

        let x0 = pos - target;
        let v0 = vel;
        let omega = stiffness.sqrt();

        let (x1, v1) = if zeta < 0.999 {
            // Underdamped spring: smooth overshoot & velocity preservation
            let omega_d = omega * (1.0 - zeta * zeta).sqrt();
            let decay = (-zeta * omega * dt).exp();
            let c = (omega_d * dt).cos();
            let s = (omega_d * dt).sin();
            let a = x0;
            let b = (v0 + zeta * omega * x0) / omega_d;
            let nx = decay * (a * c + b * s);
            let nv = decay * ((b * omega_d - a * zeta * omega) * c - (a * omega_d + b * zeta * omega) * s);
            (nx, nv)
        } else if zeta <= 1.001 {
            // Critically damped spring: fastest zero-overshoot settle
            let decay = (-omega * dt).exp();
            let a = x0;
            let b = v0 + omega * x0;
            let nx = decay * (a + b * dt);
            let nv = decay * (b - omega * (a + b * dt));
            (nx, nv)
        } else {
            // Overdamped spring
            let gamma = omega * (zeta * zeta - 1.0).sqrt();
            let r1 = -omega * zeta + gamma;
            let r2 = -omega * zeta - gamma;
            let denom = r1 - r2;
            if denom.abs() < 1e-6 {
                (0.0, 0.0)
            } else {
                let c1 = (v0 - r2 * x0) / denom;
                let c2 = x0 - c1;
                let e1 = (r1 * dt).exp();
                let e2 = (r2 * dt).exp();
                let nx = c1 * e1 + c2 * e2;
                let nv = c1 * r1 * e1 + c2 * r2 * e2;
                (nx, nv)
            }
        };

        data[base] = target + x1;
        data[base + 1] = v1;
    }
}
