/// Analytical Underdamped Spring Physics Evaluator (Apple TV / tvOS feel)
#[inline]
pub fn evaluate_spring(progress: f32, damping_ratio: f32, angular_freq: f32) -> f32 {
    let t = progress.clamp(0.0, 1.0);
    if t <= 0.0 {
        return 0.0;
    }
    if t >= 1.0 {
        return 1.0;
    }
    let zeta = damping_ratio.clamp(0.45, 0.99);
    let omega = angular_freq.clamp(6.0, 22.0);
    let omega_d = omega * (1.0 - zeta * zeta).sqrt();
    let decay = (-zeta * omega * t).exp();
    let cos_part = (omega_d * t).cos();
    let sin_part = ((zeta * omega) / omega_d) * (omega_d * t).sin();
    let raw = 1.0 - decay * (cos_part + sin_part);

    // Ensure exact 1.0 convergence at t = 1.0
    let end_decay = (-zeta * omega).exp();
    let end_val = 1.0 - end_decay * (omega_d.cos() + ((zeta * omega) / omega_d) * omega_d.sin());
    if end_val.abs() > 1e-4 {
        (raw / end_val).clamp(0.0, 1.08)
    } else {
        raw.clamp(0.0, 1.08)
    }
}
