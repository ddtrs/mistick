/// Ultra-fast Hardware KeyCode & ScanCode Classifier for Xiaomi Mi TV Stick Remote
/// Returns:
/// 0 = normal key
/// 1 = VOICE_ASSIST (Gemini AI Dynamic Island)
/// 2 = PATCHWALL / MI / MENU (Control Center)
/// 3 = NETFLIX preset button
/// 4 = PRIME VIDEO preset button
#[inline]
pub fn classify_remote_key(key_code: i32, scan_code: i32) -> i32 {
    // Voice Assistant (KEYCODE_VOICE_ASSIST=231, KEYCODE_ASSIST=219, KEYCODE_SEARCH=84, scanCodes 582/217/221)
    if key_code == 231 || key_code == 219 || key_code == 84 || scan_code == 582 || scan_code == 217 || scan_code == 221 {
        return 1;
    }
    // PatchWall / Mi / Menu / Settings / Guide / Live TV
    if key_code == 284 || key_code == 82 || key_code == 172 || key_code == 176 || key_code == 178 || key_code == 188
        || scan_code == 139 || scan_code == 362 || scan_code == 172 || scan_code == 256
    {
        return 2;
    }
    // Netflix dedicated button
    if key_code == 189 || key_code == 183 || key_code == 309 || scan_code == 412 || scan_code == 398 || scan_code == 393 {
        return 3;
    }
    // Prime Video dedicated button
    if key_code == 190 || key_code == 186 || key_code == 310 || scan_code == 413 || scan_code == 401 || scan_code == 400 {
        return 4;
    }
    0
}
