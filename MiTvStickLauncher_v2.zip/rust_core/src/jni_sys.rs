#![allow(non_snake_case, non_camel_case_types, dead_code)]

use std::os::raw::{c_char, c_int, c_uchar, c_void};

pub type jint = i32;
pub type jlong = i64;
pub type jfloat = f32;
pub type jboolean = u8;
pub type jbyte = i8;
pub type jsize = jint;

#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct jobject(pub *mut c_void);

pub type jclass = jobject;
pub type jintArray = jobject;
pub type jbyteArray = jobject;

pub const JNI_FALSE: jboolean = 0;
pub const JNI_TRUE: jboolean = 1;
pub const JNI_COMMIT: jint = 1;
pub const JNI_ABORT: jint = 2;

#[repr(C)]
pub struct JNINativeInterface {
    pub reserved0: *mut c_void,
    pub reserved1: *mut c_void,
    pub reserved2: *mut c_void,
    pub reserved3: *mut c_void,
    pub _pad1: [*mut c_void; 167],
    pub GetArrayLength: unsafe extern "system" fn(env: *mut JNIEnv, array: jobject) -> jsize,
    pub _pad2: [*mut c_void; 11],
    pub GetByteArrayElements: unsafe extern "system" fn(
        env: *mut JNIEnv,
        array: jbyteArray,
        isCopy: *mut jboolean,
    ) -> *mut jbyte,
    pub _pad3: [*mut c_void; 3],
    pub GetIntArrayElements: unsafe extern "system" fn(
        env: *mut JNIEnv,
        array: jintArray,
        isCopy: *mut jboolean,
    ) -> *mut jint,
    pub _pad4: [*mut c_void; 4],
    pub ReleaseByteArrayElements: unsafe extern "system" fn(
        env: *mut JNIEnv,
        array: jbyteArray,
        elems: *mut jbyte,
        mode: jint,
    ),
    pub _pad5: [*mut c_void; 3],
    pub ReleaseIntArrayElements: unsafe extern "system" fn(
        env: *mut JNIEnv,
        array: jintArray,
        elems: *mut jint,
        mode: jint,
    ),
    pub _pad6: [*mut c_void; 26],
    pub GetPrimitiveArrayCritical: unsafe extern "system" fn(
        env: *mut JNIEnv,
        array: jobject,
        isCopy: *mut jboolean,
    ) -> *mut c_void,
    pub ReleasePrimitiveArrayCritical: unsafe extern "system" fn(
        env: *mut JNIEnv,
        array: jobject,
        carray: *mut c_void,
        mode: jint,
    ),
    pub _pad7: [*mut c_void; 9],
    pub NewStringUTF: unsafe extern "system" fn(
        env: *mut JNIEnv,
        utf: *const c_char,
    ) -> jobject,
    pub _pad8: [*mut c_void; 65],
}

pub type JNIEnv = *const JNINativeInterface;

#[inline(always)]
pub unsafe fn get_array_length(env: *mut JNIEnv, array: jobject) -> usize {
    if env.is_null() || array.0.is_null() {
        return 0;
    }
    let tbl = &*(*env);
    let len = (tbl.GetArrayLength)(env, array);
    if len > 0 { len as usize } else { 0 }
}

#[inline(always)]
pub unsafe fn lock_primitive_array(env: *mut JNIEnv, array: jobject) -> *mut c_void {
    if env.is_null() || array.0.is_null() {
        return std::ptr::null_mut();
    }
    let tbl = &*(*env);
    let mut is_copy: jboolean = JNI_FALSE;
    (tbl.GetPrimitiveArrayCritical)(env, array, &mut is_copy)
}

#[inline(always)]
pub unsafe fn unlock_primitive_array(env: *mut JNIEnv, array: jobject, ptr: *mut c_void, mode: jint) {
    if env.is_null() || array.0.is_null() || ptr.is_null() {
        return;
    }
    let tbl = &*(*env);
    (tbl.ReleasePrimitiveArrayCritical)(env, array, ptr, mode);
}
