#![allow(non_snake_case, non_camel_case_types, dead_code)]

use std::os::raw::c_void;

pub type jint = i32;
pub type jlong = i64;
pub type jfloat = f32;
pub type jboolean = u8;
pub type jbyte = i8;
pub type jsize = jint;

#[repr(transparent)]
#[derive(Copy, Clone)]
pub struct jobject(pub *mut c_void);

pub type jclass = jobject;
pub type jintArray = jobject;
pub type jbyteArray = jobject;

pub const JNI_FALSE: jboolean = 0;
pub const JNI_TRUE: jboolean = 1;
pub const JNI_COMMIT: jint = 1;
pub const JNI_ABORT: jint = 2;

// JNIEnv = указатель на указатель на таблицу функций. Таблица — просто массив
// указателей; нужные функции берём по ТОЧНОМУ индексу из jni.h (никаких _padN,
// в которых легко ошибиться на единицу).
pub type JNIEnv = *const *const c_void;

const IDX_GET_ARRAY_LENGTH: usize = 171;
const IDX_GET_PRIMITIVE_ARRAY_CRITICAL: usize = 222;
const IDX_RELEASE_PRIMITIVE_ARRAY_CRITICAL: usize = 223;

type GetArrayLengthFn = unsafe extern "system" fn(*mut JNIEnv, jobject) -> jsize;
type GetCriticalFn = unsafe extern "system" fn(*mut JNIEnv, jobject, *mut jboolean) -> *mut c_void;
type ReleaseCriticalFn = unsafe extern "system" fn(*mut JNIEnv, jobject, *mut c_void, jint);

#[inline(always)]
unsafe fn slot(env: *mut JNIEnv, idx: usize) -> *const c_void {
    *(*env).add(idx)
}

#[inline(always)]
pub unsafe fn get_array_length(env: *mut JNIEnv, array: jobject) -> usize {
    if env.is_null() || array.0.is_null() {
        return 0;
    }
    let f: GetArrayLengthFn = std::mem::transmute(slot(env, IDX_GET_ARRAY_LENGTH));
    let len = f(env, array);
    if len > 0 { len as usize } else { 0 }
}

#[inline(always)]
pub unsafe fn lock_primitive_array(env: *mut JNIEnv, array: jobject) -> *mut c_void {
    if env.is_null() || array.0.is_null() {
        return std::ptr::null_mut();
    }
    let f: GetCriticalFn = std::mem::transmute(slot(env, IDX_GET_PRIMITIVE_ARRAY_CRITICAL));
    let mut is_copy: jboolean = JNI_FALSE;
    f(env, array, &mut is_copy)
}

#[inline(always)]
pub unsafe fn unlock_primitive_array(env: *mut JNIEnv, array: jobject, ptr: *mut c_void, mode: jint) {
    if env.is_null() || array.0.is_null() || ptr.is_null() {
        return;
    }
    let f: ReleaseCriticalFn = std::mem::transmute(slot(env, IDX_RELEASE_PRIMITIVE_ARRAY_CRITICAL));
    f(env, array, ptr, mode);
}
