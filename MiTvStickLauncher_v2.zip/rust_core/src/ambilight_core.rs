/// High-speed RGB -> HSV Chroma Spectrum Analyzer for Spotify / Music Album Art.
/// Returns packed `(hue << 16) | sat_pct` calibrated for Tuya RGB LED strips.
pub fn extract_dominant_cover_hsv(pixels: &[u32], width: usize, height: usize) -> i32 {
    if width == 0 || height == 0 || pixels.len() < width * height {
        return (184 << 16) | 95;
    }

    let mut bucket_weights = [0.0f32; 36];
    let mut bucket_hue_sum = [0.0f32; 36];
    let mut bucket_sat_sum = [0.0f32; 36];

    let step_x = (width / 24).max(1);
    let step_y = (height / 24).max(1);

    let mut y = step_y / 2;
    while y < height {
        let row = y * width;
        let mut x = step_x / 2;
        while x < width {
            let px = pixels[row + x];
            let a = (px >> 24) & 0xFF;
            if a > 140 {
                let r = ((px >> 16) & 0xFF) as f32 / 255.0;
                let g = ((px >> 8) & 0xFF) as f32 / 255.0;
                let b = (px & 0xFF) as f32 / 255.0;

                let max_c = r.max(g).max(b);
                let min_c = r.min(g).min(b);
                let delta = max_c - min_c;

                if max_c > 0.18 && delta > 0.04 {
                    let sat = delta / max_c;
                    if sat > 0.24 {
                        let mut hue = if (max_c - r).abs() < 1e-5 {
                            60.0 * (((g - b) / delta) % 6.0)
                        } else if (max_c - g).abs() < 1e-5 {
                            60.0 * (((b - r) / delta) + 2.0)
                        } else {
                            60.0 * (((r - g) / delta) + 4.0)
                        };
                        if hue < 0.0 {
                            hue += 360.0;
                        }

                        let bucket = ((hue as usize) / 10).min(35);
                        // Suppress muddy skin/brown tones (14..44 deg with medium saturation)
                        let skin_penalty = if (14.0..=44.0).contains(&hue) && sat < 0.68 {
                            0.20
                        } else {
                            1.0
                        };
                        let weight = sat * sat * sat * max_c * skin_penalty;
                        bucket_weights[bucket] += weight;
                        bucket_hue_sum[bucket] += hue * weight;
                        bucket_sat_sum[bucket] += sat * weight;
                    }
                }
            }
            x += step_x;
        }
        y += step_y;
    }

    let mut best_bucket = None;
    let mut best_weight = 0.0f32;
    for i in 0..36 {
        if bucket_weights[i] > best_weight {
            best_weight = bucket_weights[i];
            best_bucket = Some(i);
        }
    }

    if let Some(b) = best_bucket {
        if best_weight > 0.02 {
            let dom_hue = ((bucket_hue_sum[b] / best_weight) as i32).clamp(0, 360);
            let avg_sat = (((bucket_sat_sum[b] / best_weight).clamp(0.75, 1.0)) * 100.0) as i32;
            return (dom_hue << 16) | avg_sat.clamp(80, 100);
        }
    }

    // Monochrome cover fallback -> crisp ice blue
    (195 << 16) | 60
}
