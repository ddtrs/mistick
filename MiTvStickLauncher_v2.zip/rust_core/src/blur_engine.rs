/// O(1) Sliding-Window 3-Pass Box/Stack Blur + Frosted Glass Tint in Rust
/// Designed for Amlogic S805Y ARMv8 NEON auto-vectorization (0 GC allocations).
pub fn fast_blur_and_tint(pixels: &mut [u32], width: usize, height: usize, radius: usize, tint_argb: u32) {
    let total = width.saturating_mul(height);
    if width < 4 || height < 4 || total == 0 || pixels.len() < total {
        return;
    }
    let r = radius.clamp(1, 16);
    let mut tmp = vec![0u32; total];

    for _pass in 0..3 {
        // Horizontal sliding-window pass
        for y in 0..height {
            let row = y * width;
            let mut r_sum: u32 = 0;
            let mut g_sum: u32 = 0;
            let mut b_sum: u32 = 0;
            let mut count: u32 = 0;

            for dx in 0..=r.min(width - 1) {
                let c = pixels[row + dx];
                r_sum += (c >> 16) & 0xFF;
                g_sum += (c >> 8) & 0xFF;
                b_sum += c & 0xFF;
                count += 1;
            }

            for x in 0..width {
                if x > 0 {
                    let add_x = x + r;
                    if add_x < width {
                        let c = pixels[row + add_x];
                        r_sum += (c >> 16) & 0xFF;
                        g_sum += (c >> 8) & 0xFF;
                        b_sum += c & 0xFF;
                        count += 1;
                    }
                    if x > r {
                        let rem_x = x - r - 1;
                        let c = pixels[row + rem_x];
                        r_sum -= (c >> 16) & 0xFF;
                        g_sum -= (c >> 8) & 0xFF;
                        b_sum -= c & 0xFF;
                        count -= 1;
                    }
                }
                let inv = count.max(1);
                tmp[row + x] = 0xFF00_0000
                    | ((r_sum / inv) << 16)
                    | ((g_sum / inv) << 8)
                    | (b_sum / inv);
            }
        }

        // Vertical sliding-window pass
        for x in 0..width {
            let mut r_sum: u32 = 0;
            let mut g_sum: u32 = 0;
            let mut b_sum: u32 = 0;
            let mut count: u32 = 0;

            for dy in 0..=r.min(height - 1) {
                let c = tmp[dy * width + x];
                r_sum += (c >> 16) & 0xFF;
                g_sum += (c >> 8) & 0xFF;
                b_sum += c & 0xFF;
                count += 1;
            }

            for y in 0..height {
                if y > 0 {
                    let add_y = y + r;
                    if add_y < height {
                        let c = tmp[add_y * width + x];
                        r_sum += (c >> 16) & 0xFF;
                        g_sum += (c >> 8) & 0xFF;
                        b_sum += c & 0xFF;
                        count += 1;
                    }
                    if y > r {
                        let rem_y = y - r - 1;
                        let c = tmp[rem_y * width + x];
                        r_sum -= (c >> 16) & 0xFF;
                        g_sum -= (c >> 8) & 0xFF;
                        b_sum -= c & 0xFF;
                        count -= 1;
                    }
                }
                let inv = count.max(1);
                pixels[y * width + x] = 0xFF00_0000
                    | ((r_sum / inv) << 16)
                    | ((g_sum / inv) << 8)
                    | (b_sum / inv);
            }
        }
    }

    // Apply dark frosted glass tint in-place
    let ta = (tint_argb >> 24) & 0xFF;
    if ta > 0 {
        let tr = (tint_argb >> 16) & 0xFF;
        let tg = (tint_argb >> 8) & 0xFF;
        let tb = tint_argb & 0xFF;
        let inv_a = 255 - ta;

        for px in pixels.iter_mut().take(total) {
            let c = *px;
            let r_ch = (((c >> 16) & 0xFF) * inv_a + tr * ta) / 255;
            let g_ch = (((c >> 8) & 0xFF) * inv_a + tg * ta) / 255;
            let b_ch = ((c & 0xFF) * inv_a + tb * ta) / 255;
            *px = 0xFF00_0000 | (r_ch << 16) | (g_ch << 8) | b_ch;
        }
    }
}
