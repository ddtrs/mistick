/// High-speed Monochrome Glyph Silhouette Extractor in Rust for IconStylizer.
/// Transforms raw app icon pixels into a clean white silhouette (#FFFFFF with smooth alpha) in-place.
pub fn extract_monochrome_glyph(pixels: &mut [u32], size: usize) -> i32 {
    let total = size.saturating_mul(size);
    if size < 8 || pixels.len() < total {
        return 0;
    }

    let corner = pixels[5 * size + 5];
    let corner_a = ((corner >> 24) & 0xFF) as i32;
    let corner_r = ((corner >> 16) & 0xFF) as i32;
    let corner_g = ((corner >> 8) & 0xFF) as i32;
    let corner_b = (corner & 0xFF) as i32;
    let has_solid_bg = corner_a > 200;

    let mut visible_count: i32 = 0;

    for px in pixels.iter_mut().take(total) {
        let c = *px;
        let a = ((c >> 24) & 0xFF) as i32;
        if a < 30 {
            *px = 0;
            continue;
        }
        let r = ((c >> 16) & 0xFF) as i32;
        let g = ((c >> 8) & 0xFF) as i32;
        let b = (c & 0xFF) as i32;

        let out_alpha = if has_solid_bg {
            let diff = ((r - corner_r).abs() + (g - corner_g).abs() + (b - corner_b).abs()) / 3;
            if diff < 24 {
                0
            } else {
                (diff * 2).min(255)
            }
        } else {
            let lum = (299 * r + 587 * g + 114 * b) / 1000;
            let boost = lum.max(140);
            (a * boost) / 255
        };

        if out_alpha > 35 {
            visible_count += 1;
            *px = ((out_alpha as u32) << 24) | 0x00FF_FFFF;
        } else {
            *px = 0;
        }
    }

    visible_count
}
