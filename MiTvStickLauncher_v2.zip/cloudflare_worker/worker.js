/**
 * Cloudflare Worker Gateway for Mi TV Stick Custom Launcher (v0.8.9 Super-Echo)
 * Routes:
 *  - /gemini/*          -> Google Gemini API proxy with key pool rotation
 *  - /tuya/*            -> Tuya OpenAPI EU proxy
 *  - /yt/resolve?q=...  -> Fast YouTube search-to-videoId resolver (<200ms at edge)
 *  - /auth/spotify/*    -> Spotify OAuth 2.0 QR / Device flow (start, callback, status)
 *  - /spotify/action    -> Spotify Web API actions (PLAY_QUERY, LIKE_CURRENT, CREATE_PLAYLIST, ADD_TO_PLAYLIST)
 */

const memoryStore = new Map();
const SPOTIFY_CLIENT_ID_FALLBACK = "45a111277ceb41c198cb4c1f4b2e30b9";
const SPOTIFY_CLIENT_SECRET_FALLBACK = "1b42813da0bc4452b488f5c6135916fd";

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;

    const corsHeaders = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization, x-app-secret, client_id, sign, t, sign_method, access_token"
    };

    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: corsHeaders });
    }

    // 1. Fast YouTube videoId Resolver
    if (path === "/yt/resolve") {
      const q = (url.searchParams.get("q") || "").trim();
      if (!q) {
        return jsonResponse({ ok: false, error: "empty_query" }, 400, corsHeaders);
      }
      try {
        const ytUrl = "https://www.youtube.com/results?search_query=" + encodeURIComponent(q) + "&hl=ru&sp=EgIQAQ%253D%253D";
        const resp = await fetch(ytUrl, {
          headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
            "Accept-Language": "ru-RU,ru;q=0.9,en-US;q=0.8"
          }
        });
        const html = await resp.text();
        const match = html.match(/"videoId":"([a-zA-Z0-9_-]{11})"/);
        if (match && match[1]) {
          return jsonResponse({ ok: true, videoId: match[1], query: q }, 200, corsHeaders);
        }
      } catch (e) {}
      return jsonResponse({ ok: false, error: "not_found" }, 404, corsHeaders);
    }

    // 2. Spotify OAuth 2.0 QR Flow
    if (path === "/auth/spotify/start") {
      const deviceId = (url.searchParams.get("device_id") || "default_tv").trim();
      const clientId = env.SPOTIFY_CLIENT_ID || url.searchParams.get("client_id") || SPOTIFY_CLIENT_ID_FALLBACK;
      const redirectUri = `${url.origin}/auth/spotify/callback`;
      if (!clientId) {
        return new Response(renderSpotifySetupHtml(url.origin, deviceId), {
          status: 200,
          headers: { "Content-Type": "text/html; charset=utf-8", ...corsHeaders }
        });
      }
      const scopes = [
        "user-modify-playback-state",
        "user-read-playback-state",
        "user-read-currently-playing",
        "user-library-modify",
        "user-library-read",
        "playlist-modify-public",
        "playlist-modify-private",
        "playlist-read-private"
      ].join(" ");
      const authUrl = "https://accounts.spotify.com/authorize" +
        `?response_type=code` +
        `&client_id=${encodeURIComponent(clientId)}` +
        `&scope=${encodeURIComponent(scopes)}` +
        `&redirect_uri=${encodeURIComponent(redirectUri)}` +
        `&state=${encodeURIComponent(deviceId)}`;
      return Response.redirect(authUrl, 302);
    }

    if (path === "/auth/spotify/callback") {
      const code = url.searchParams.get("code") || "";
      const deviceId = url.searchParams.get("state") || "default_tv";
      const clientId = env.SPOTIFY_CLIENT_ID || SPOTIFY_CLIENT_ID_FALLBACK;
      const clientSecret = env.SPOTIFY_CLIENT_SECRET || SPOTIFY_CLIENT_SECRET_FALLBACK;
      const redirectUri = `${url.origin}/auth/spotify/callback`;

      if (!code || !clientId || !clientSecret) {
        return new Response("Ошибка авторизации Spotify: проверьте SPOTIFY_CLIENT_ID / SPOTIFY_CLIENT_SECRET в настройках Worker.", {
          status: 400,
          headers: { "Content-Type": "text/plain; charset=utf-8" }
        });
      }

      const tokenResp = await fetch("https://accounts.spotify.com/api/token", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          "Authorization": "Basic " + btoa(`${clientId}:${clientSecret}`)
        },
        body: new URLSearchParams({
          grant_type: "authorization_code",
          code,
          redirect_uri: redirectUri
        })
      });
      const tokenJson = await tokenResp.json();
      if (tokenJson.access_token) {
        const record = {
          access_token: tokenJson.access_token,
          refresh_token: tokenJson.refresh_token || "",
          expires_at: Date.now() + ((tokenJson.expires_in || 3600) * 1000)
        };
        await saveDeviceToken(env, deviceId, record);
        return new Response(
          "<html><body style='background:#0D0F14;color:#fff;font-family:sans-serif;text-align:center;padding:48px;'>" +
          "<h2 style='color:#00F0FF;'>Эхо · Spotify подключён!</h2>" +
          "<p>Теперь можно закрыть эту страницу и управлять плейлистами и лайками голосом на телевизоре.</p></body></html>",
          { status: 200, headers: { "Content-Type": "text/html; charset=utf-8" } }
        );
      }
      return jsonResponse({ ok: false, error: tokenJson }, 400, corsHeaders);
    }

    if (path === "/auth/spotify/status") {
      const deviceId = (url.searchParams.get("device_id") || "default_tv").trim();
      const rec = await getDeviceToken(env, deviceId);
      const linked = !!(rec && rec.access_token);
      return jsonResponse({
        ok: true,
        linked,
        refresh_token: linked ? (rec.refresh_token || "") : ""
      }, 200, corsHeaders);
    }

    if (path === "/auth/spotify/restore" && request.method === "POST") {
      const body = await request.json().catch(() => ({}));
      const deviceId = (body.device_id || "default_tv").trim();
      const rt = (body.refresh_token || "").trim();
      if (!rt) {
        return jsonResponse({ ok: false, error: "missing_refresh_token" }, 400, corsHeaders);
      }
      const restored = await refreshAndSaveWithToken(env, deviceId, rt);
      return jsonResponse({
        ok: !!restored,
        linked: !!restored,
        refresh_token: restored ? (restored.refresh_token || rt) : ""
      }, restored ? 200 : 401, corsHeaders);
    }

    if (path === "/spotify/action" && request.method === "POST") {
      const body = await request.json().catch(() => ({}));
      const deviceId = body.device_id || "default_tv";
      const action = (body.action || "").toUpperCase();
      let token = await getValidSpotifyAccessToken(env, deviceId);
      if (!token && body.refresh_token) {
        const restored = await refreshAndSaveWithToken(env, deviceId, String(body.refresh_token).trim());
        if (restored) token = restored.access_token;
      }
      if (!token) {
        return jsonResponse({ ok: false, error: "not_linked" }, 401, corsHeaders);
      }

      if (action === "LIKE_CURRENT") {
        let trackId = "";
        const curResp = await fetch("https://api.spotify.com/v1/me/player/currently-playing", {
          headers: { "Authorization": `Bearer ${token}` }
        });
        if (curResp.status === 200) {
          const curJson = await curResp.json().catch(() => ({}));
          trackId = (curJson.item && curJson.item.id) || "";
        }
        if (!trackId && body.query) {
          trackId = await searchSpotifyTrackId(token, body.query);
        }
        if (!trackId) {
          return jsonResponse({ ok: false, error: "no_track_found" }, 404, corsHeaders);
        }
        // Spotify (февраль 2026): PUT /me/tracks?ids= удалён -> PUT /me/library?uris=
        const likeResp = await fetch(
          `https://api.spotify.com/v1/me/library?uris=${encodeURIComponent("spotify:track:" + trackId)}`,
          { method: "PUT", headers: { "Authorization": `Bearer ${token}` } }
        );
        if (!likeResp.ok) {
          const likeText = await likeResp.text();
          let likeJson = {};
          try { likeJson = JSON.parse(likeText); } catch (e) {}
          return jsonResponse({
            ok: false,
            error: "like_failed",
            status: likeResp.status,
            message: spotifyErrorMessage(likeJson, likeText)
          }, likeResp.status, corsHeaders);
        }
        return jsonResponse({ ok: true, likedTrackId: trackId }, 200, corsHeaders);
      }

      if (action === "CREATE_PLAYLIST" || action === "ADD_TO_PLAYLIST") {
        const name = (body.name || "Плейлист Эхо").trim();
        const rawSeed = (body.seed_query || "").trim();
        const fallbackQuery = (body.fallback_query || "").trim();
        let targetPlaylistId = (body.playlist_id || "").trim();
        let targetPlaylistUri = targetPlaylistId ? `spotify:playlist:${targetPlaylistId}` : "";

        // Если передан трек и плейлист с таким именем уже есть у пользователя — добавляем в него, не плодя пустые дубли
        if (!targetPlaylistId && rawSeed) {
          try {
            const listResp = await fetch("https://api.spotify.com/v1/me/playlists?limit=50", {
              headers: { "Authorization": `Bearer ${token}` }
            });
            if (listResp.status === 200) {
              const listJson = await listResp.json().catch(() => ({}));
              const found = (listJson.items || []).find(
                p => p && p.name && p.name.trim().toLowerCase() === name.toLowerCase()
              );
              if (found && found.id) {
                targetPlaylistId = found.id;
                targetPlaylistUri = found.uri || `spotify:playlist:${found.id}`;
              }
            }
          } catch (e) {}
        }

        if (!targetPlaylistId) {
          const createResp = await fetch("https://api.spotify.com/v1/me/playlists", {
            method: "POST",
            headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json" },
            body: JSON.stringify({ name, description: "Создано голосовым ассистентом Эхо", public: false })
          });
          const createText = await createResp.text();
          let plJson = {};
          try { plJson = JSON.parse(createText); } catch (e) {}
          if (!createResp.ok || !plJson.id) {
            return jsonResponse({
              ok: false,
              error: "playlist_create_failed",
              status: createResp.status,
              message: spotifyErrorMessage(plJson, createText)
            }, createResp.status >= 400 ? createResp.status : 502, corsHeaders);
          }
          targetPlaylistId = plJson.id;
          targetPlaylistUri = plJson.uri || `spotify:playlist:${plJson.id}`;
        }

        let seeded = false;
        let seedError = "";
        if (rawSeed) {
          let tid = "";
          if (rawSeed.toUpperCase() === "CURRENT") {
            const curResp = await fetch("https://api.spotify.com/v1/me/player/currently-playing", {
              headers: { "Authorization": `Bearer ${token}` }
            });
            if (curResp.status === 200) {
              const curJson = await curResp.json().catch(() => ({}));
              tid = (curJson.item && curJson.item.id) || "";
            }
            if (!tid) {
              const plResp = await fetch("https://api.spotify.com/v1/me/player", {
                headers: { "Authorization": `Bearer ${token}` }
              });
              if (plResp.status === 200) {
                const plData = await plResp.json().catch(() => ({}));
                tid = (plData.item && plData.item.id) || "";
              }
            }
            if (!tid && fallbackQuery) {
              tid = await searchSpotifyTrackId(token, fallbackQuery);
            }
          } else {
            tid = await searchSpotifyTrackId(token, rawSeed);
          }
          if (tid) {
            // Сначала стандартный /tracks, затем /items (февраль 2026)
            let addResp = await fetch(`https://api.spotify.com/v1/playlists/${targetPlaylistId}/tracks`, {
              method: "POST",
              headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json" },
              body: JSON.stringify({ uris: [`spotify:track:${tid}`] })
            });
            if (!addResp.ok) {
              addResp = await fetch(`https://api.spotify.com/v1/playlists/${targetPlaylistId}/items`, {
                method: "POST",
                headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json" },
                body: JSON.stringify({ uris: [`spotify:track:${tid}`] })
              });
            }
            seeded = addResp.ok;
            if (!addResp.ok) {
              const errTxt = await addResp.text().catch(() => "add_failed");
              let errJson = {};
              try { errJson = JSON.parse(errTxt); } catch (e) {}
              seedError = spotifyErrorMessage(errJson, errTxt);
            }
          } else {
            seedError = "track_not_found";
          }
        }
        return jsonResponse({ ok: true, playlistId: targetPlaylistId, uri: targetPlaylistUri, name, seeded, seedError }, 200, corsHeaders);
      }

      if (action === "PLAY_PLAYLIST") {
        const plUri = (body.uri || "").trim();
        if (!/^spotify:playlist:[A-Za-z0-9]+$/.test(plUri)) {
          return jsonResponse({ ok: false, error: "bad_playlist_uri" }, 400, corsHeaders);
        }
        // Запуск плейлиста целиком на активном устройстве (нужен Spotify Premium и открытое приложение на ТВ).
        const playResp = await fetch("https://api.spotify.com/v1/me/player/play", {
          method: "PUT",
          headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json" },
          body: JSON.stringify({ context_uri: plUri })
        });
        if (!playResp.ok) {
          const playText = await playResp.text();
          let playJson = {};
          try { playJson = JSON.parse(playText); } catch (e) {}
          return jsonResponse({
            ok: false,
            error: "play_playlist_failed",
            status: playResp.status,
            message: spotifyErrorMessage(playJson, playText)
          }, playResp.status, corsHeaders);
        }
        return jsonResponse({ ok: true, uri: plUri }, 200, corsHeaders);
      }

      if (action === "GET_QUEUE") {
        const qResp = await fetch("https://api.spotify.com/v1/me/player/queue", {
          headers: { "Authorization": `Bearer ${token}` }
        });
        if (qResp.status === 200) {
          const qJson = await qResp.json().catch(() => ({}));
          const nextItem = Array.isArray(qJson.queue) && qJson.queue.length > 0 ? qJson.queue[0] : null;
          if (nextItem && nextItem.name) {
            const artist = (Array.isArray(nextItem.artists) && nextItem.artists[0] && nextItem.artists[0].name) || "";
            const label = artist ? `${artist} — ${nextItem.name}` : nextItem.name;
            return jsonResponse({
              ok: true,
              nextTitle: nextItem.name,
              nextArtist: artist,
              nextLabel: label
            }, 200, corsHeaders);
          }
        }
        return jsonResponse({ ok: false, nextLabel: "" }, 200, corsHeaders);
      }

      if (action === "SEARCH_URI") {
        const q = (body.query || "").trim();
        if (!q) return jsonResponse({ ok: false }, 400, corsHeaders);
        const sResp = await fetch(
          `https://api.spotify.com/v1/search?type=track,artist,album,playlist&limit=3&q=${encodeURIComponent(q)}`,
          { headers: { "Authorization": `Bearer ${token}` } }
        );
        const sData = await sResp.json().catch(() => ({}));
        const qLower = q.toLowerCase();
        const topArtist = sData?.artists?.items?.[0];
        const topTrack = sData?.tracks?.items?.[0];
        const topAlbum = sData?.albums?.items?.[0];
        const topPlaylist = sData?.playlists?.items?.[0];

        let targetUri = "";
        if (topArtist && topArtist.name && topArtist.name.toLowerCase() === qLower) {
          targetUri = topArtist.uri || `spotify:artist:${topArtist.id}`;
        } else if (topTrack && topTrack.album && topTrack.album.id) {
          targetUri = topTrack.album.uri || `spotify:album:${topTrack.album.id}`;
        } else if (topArtist && topArtist.id) {
          targetUri = topArtist.uri || `spotify:artist:${topArtist.id}`;
        } else if (topAlbum && topAlbum.id) {
          targetUri = topAlbum.uri || `spotify:album:${topAlbum.id}`;
        } else if (topPlaylist && topPlaylist.id) {
          targetUri = topPlaylist.uri || `spotify:playlist:${topPlaylist.id}`;
        }
        return jsonResponse({
          ok: !!targetUri,
          uri: targetUri,
          trackUri: topTrack ? (`spotify:track:${topTrack.id}`) : "",
          albumUri: (topTrack && topTrack.album && topTrack.album.id) ? (`spotify:album:${topTrack.album.id}`) : "",
          artistUri: topArtist ? (`spotify:artist:${topArtist.id}`) : ""
        }, 200, corsHeaders);
      }

      if (action === "PAUSE" || action === "PLAY" || action === "NEXT" || action === "PREV") {
        let ep = "https://api.spotify.com/v1/me/player/pause";
        let method = "PUT";
        if (action === "PLAY") { ep = "https://api.spotify.com/v1/me/player/play"; method = "PUT"; }
        else if (action === "NEXT") { ep = "https://api.spotify.com/v1/me/player/next"; method = "POST"; }
        else if (action === "PREV") { ep = "https://api.spotify.com/v1/me/player/previous"; method = "POST"; }
        const r = await fetch(ep, { method, headers: { "Authorization": `Bearer ${token}` } });
        return jsonResponse({ ok: r.ok || r.status === 204, status: r.status }, 200, corsHeaders);
      }

      if (action === "PLAY_QUERY") {
        const q = (body.query || "").trim();
        const tid = await searchSpotifyTrackId(token, q);
        if (!tid) {
          return jsonResponse({ ok: false, error: "track_not_found" }, 404, corsHeaders);
        }
        let playResp = await fetch("https://api.spotify.com/v1/me/player/play", {
          method: "PUT",
          headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json" },
          body: JSON.stringify({ uris: [`spotify:track:${tid}`] })
        });
        if (playResp.status === 404) {
          const devResp = await fetch("https://api.spotify.com/v1/me/player/devices", {
            headers: { "Authorization": `Bearer ${token}` }
          });
          const devJson = await devResp.json().catch(() => ({}));
          const devices = devJson.devices || [];
          const tvDev = devices.find(d => d && (d.type === "TV" || (d.name || "").toLowerCase().includes("tv") || (d.name || "").toLowerCase().includes("stick"))) || devices[0];
          if (tvDev && tvDev.id) {
            playResp = await fetch(`https://api.spotify.com/v1/me/player/play?device_id=${encodeURIComponent(tvDev.id)}`, {
              method: "PUT",
              headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json" },
              body: JSON.stringify({ uris: [`spotify:track:${tid}`] })
            });
          }
        }
        return jsonResponse({ ok: true, played: playResp.ok || playResp.status === 204, trackId: tid, uri: `spotify:track:${tid}` }, 200, corsHeaders);
      }
    }

    // 3. Tuya OpenAPI Proxy (/tuya/...)
    if (path.startsWith("/tuya/")) {
      const tuyaPath = path.replace(/^\/tuya/, "") + url.search;
      const targetUrl = "https://openapi.tuyaeu.com" + tuyaPath;
      const headers = new Headers();
      for (const [k, v] of request.headers.entries()) {
        if (["client_id", "sign", "t", "sign_method", "access_token", "content-type"].includes(k.toLowerCase())) {
          headers.set(k, v);
        }
      }
      const resp = await fetch(targetUrl, {
        method: request.method,
        headers,
        body: ["GET", "HEAD"].includes(request.method) ? undefined : await request.arrayBuffer()
      });
      return new Response(resp.body, { status: resp.status, headers: corsHeaders });
    }

    // 4. Gemini API Proxy (/gemini/...)
    if (path.startsWith("/gemini/")) {
      const geminiPath = path.replace(/^\/gemini/, "") + url.search;
      const targetUrl = "https://generativelanguage.googleapis.com" + geminiPath;
      const resp = await fetch(targetUrl, {
        method: request.method,
        headers: { "Content-Type": "application/json" },
        body: ["GET", "HEAD"].includes(request.method) ? undefined : await request.arrayBuffer()
      });
      return new Response(resp.body, { status: resp.status, headers: corsHeaders });
    }

    return jsonResponse({ ok: true, service: "MiTvStick Super-Echo Gateway v0.8.9" }, 200, corsHeaders);
  }
};

function spotifyErrorMessage(json, rawText) {
  const e = json && json.error;
  if (e && typeof e === "object" && e.message) return String(e.message);
  if (typeof e === "string" && e) return e;
  return String(rawText || "").slice(0, 200);
}

function jsonResponse(obj, status, extraHeaders) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", ...extraHeaders }
  });
}

async function saveDeviceToken(env, deviceId, record) {
  memoryStore.set(deviceId, record);
  if (env.ECHO_KV) {
    await env.ECHO_KV.put(`spotify:${deviceId}`, JSON.stringify(record));
  }
}

async function getDeviceToken(env, deviceId) {
  if (memoryStore.has(deviceId)) return memoryStore.get(deviceId);
  if (env.ECHO_KV) {
    const raw = await env.ECHO_KV.get(`spotify:${deviceId}`);
    if (raw) {
      const parsed = JSON.parse(raw);
      memoryStore.set(deviceId, parsed);
      return parsed;
    }
  }
  return null;
}

async function refreshAndSaveWithToken(env, deviceId, refreshToken) {
  const cid = env.SPOTIFY_CLIENT_ID || SPOTIFY_CLIENT_ID_FALLBACK;
  const csec = env.SPOTIFY_CLIENT_SECRET || SPOTIFY_CLIENT_SECRET_FALLBACK;
  if (!refreshToken || !cid || !csec) return null;
  const resp = await fetch("https://accounts.spotify.com/api/token", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "Authorization": "Basic " + btoa(`${cid}:${csec}`)
    },
    body: new URLSearchParams({
      grant_type: "refresh_token",
      refresh_token: refreshToken
    })
  });
  const data = await resp.json().catch(() => ({}));
  if (data.access_token) {
    const rec = {
      access_token: data.access_token,
      refresh_token: data.refresh_token || refreshToken,
      expires_at: Date.now() + ((data.expires_in || 3600) * 1000)
    };
    await saveDeviceToken(env, deviceId, rec);
    return rec;
  }
  return null;
}

async function getValidSpotifyAccessToken(env, deviceId) {
  const rec = await getDeviceToken(env, deviceId);
  if (!rec) return null;
  if (Date.now() < (rec.expires_at || 0) - 60000) {
    return rec.access_token;
  }
  const cid = env.SPOTIFY_CLIENT_ID || SPOTIFY_CLIENT_ID_FALLBACK;
  const csec = env.SPOTIFY_CLIENT_SECRET || SPOTIFY_CLIENT_SECRET_FALLBACK;
  if (!rec.refresh_token || !cid || !csec) {
    return rec.access_token;
  }
  const resp = await fetch("https://accounts.spotify.com/api/token", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "Authorization": "Basic " + btoa(`${cid}:${csec}`)
    },
    body: new URLSearchParams({
      grant_type: "refresh_token",
      refresh_token: rec.refresh_token
    })
  });
  const data = await resp.json().catch(() => ({}));
  if (data.access_token) {
    rec.access_token = data.access_token;
    rec.expires_at = Date.now() + ((data.expires_in || 3600) * 1000);
    await saveDeviceToken(env, deviceId, rec);
  }
  return rec.access_token;
}

async function searchSpotifyTrackId(token, query) {
  const resp = await fetch(
    `https://api.spotify.com/v1/search?type=track&limit=1&q=${encodeURIComponent(query)}`,
    { headers: { "Authorization": `Bearer ${token}` } }
  );
  const data = await resp.json().catch(() => ({}));
  return data?.tracks?.items?.[0]?.id || "";
}

function renderSpotifySetupHtml(origin, deviceId) {
  return `<!DOCTYPE html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Эхо · Подключение Spotify</title>
  <style>body{background:#0D0F14;color:#fff;font-family:sans-serif;padding:28px;max-width:460px;margin:0 auto;text-align:center}
  .card{background:#161922;border:1px solid #3300F0FF;border-radius:20px;padding:24px;margin-top:20px}
  a.btn{display:inline-block;background:#00F0FF;color:#000;font-weight:600;padding:12px 24px;border-radius:999px;text-decoration:none;margin-top:16px}</style></head>
  <body><h2 style="color:#00F0FF">Эхо · Музыкальный мост</h2>
  <div class="card"><p>Устройство ТВ: <b>${deviceId}</b></p>
  <p style="color:#99FFFFFF;font-size:14px">Для облачного создания плейлистов укажите SPOTIFY_CLIENT_ID и SPOTIFY_CLIENT_SECRET в переменных Cloudflare Worker и обновите страницу.</p>
  </div></body></html>`;
}
