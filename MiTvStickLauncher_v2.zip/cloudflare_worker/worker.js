/**
 * Cloudflare Worker Gateway for Mi TV Stick Custom Launcher (v0.8.9 Super-Echo)
 * Routes:
 *  - /gemini/*          -> Google Gemini API proxy with key pool rotation
 *  - /tuya/*            -> Tuya OpenAPI EU proxy
 *  - /yt/resolve?q=...  -> Fast YouTube search-to-videoId resolver (<200ms at edge)
 *  - /auth/spotify/*    -> Spotify OAuth 2.0 QR / Device flow (start, callback, status)
 *  - /spotify/action    -> Spotify Web API actions (PLAY_QUERY, LIKE_CURRENT, CREATE_PLAYLIST, ADD_TO_PLAYLIST)
 */

const memoryStore = new Map();
const SPOTIFY_CLIENT_ID_FALLBACK = "45a111277ceb41c198cb4c1f4b2e30b9";
const SPOTIFY_CLIENT_SECRET_FALLBACK = "1b42813da0bc4452b488f5c6135916fd";

export default {
  async scheduled(event, env, ctx) {
    await runInsulinTick(env);
  },
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;

    const corsHeaders = {
      "Access-Control-Allow-Origin": "*",
      "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
      "Access-Control-Allow-Headers": "Content-Type, Authorization, x-app-secret, client_id, sign, t, sign_method, access_token"
    };

    if (request.method === "OPTIONS") {
      return new Response(null, { status: 204, headers: corsHeaders });
    }

    if (path === "/tg/webhook" && request.method === "POST") {
      return await handleTelegramWebhook(request, env);
    }

    // 0. World Context (Weather in Berezan via Open-Meteo + NBU FX rates) & Fast Web Search
    if (path === "/world/context") {
      const lat = url.searchParams.get("lat") || "50.3075";
      const lon = url.searchParams.get("lon") || "31.4744";
      let weatherSummary = "";
      let fxSummary = "";
      try {
        const wUrl = `https://api.open-meteo.com/v1/forecast?latitude=${encodeURIComponent(lat)}&longitude=${encodeURIComponent(lon)}&current=temperature_2m,weather_code,wind_speed_10m&daily=temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=Europe%2FKyiv&forecast_days=2`;
        const wResp = await fetch(wUrl);
        if (wResp.ok) {
          const wJson = await wResp.json();
          const curTemp = Math.round(wJson?.current?.temperature_2m ?? 0);
          const wind = Math.round(wJson?.current?.wind_speed_10m ?? 0);
          const code = wJson?.current?.weather_code ?? 0;
          const desc = describeWmoCodeRu(code);
          const max0 = Math.round(wJson?.daily?.temperature_2m_max?.[0] ?? curTemp);
          const min0 = Math.round(wJson?.daily?.temperature_2m_min?.[0] ?? curTemp);
          const max1 = Math.round(wJson?.daily?.temperature_2m_max?.[1] ?? curTemp);
          const min1 = Math.round(wJson?.daily?.temperature_2m_min?.[1] ?? curTemp);
          const rain1 = wJson?.daily?.precipitation_probability_max?.[1] ?? 0;
          weatherSummary = `сейчас ${curTemp >= 0 ? "+" + curTemp : curTemp}°C (${desc}, ветер ${wind} км/ч), сегодня ${min0 >= 0 ? "+" + min0 : min0}..${max0 >= 0 ? "+" + max0 : max0}°C, завтра ${min1 >= 0 ? "+" + min1 : min1}..${max1 >= 0 ? "+" + max1 : max1}°C (осадки ${rain1}%)`;
        }
      } catch (e) {}
      try {
        const fxResp = await fetch("https://bank.gov.ua/NBUStatService/v1/statdirectory/exchange?json");
        if (fxResp.ok) {
          const fxArr = await fxResp.json();
          const usd = (fxArr || []).find(x => x && x.cc === "USD");
          const eur = (fxArr || []).find(x => x && x.cc === "EUR");
          const parts = [];
          if (usd && usd.rate) parts.push(`1 USD = ${Number(usd.rate).toFixed(2)} грн`);
          if (eur && eur.rate) parts.push(`1 EUR = ${Number(eur.rate).toFixed(2)} грн`);
          fxSummary = parts.join(", ");
        }
      } catch (e) {}
      return jsonResponse({ ok: true, weatherSummary, fxSummary }, 200, corsHeaders);
    }

    if (path === "/web/search") {
      const q = (url.searchParams.get("q") || "").trim();
      if (!q) return jsonResponse({ ok: false, snippets: [] }, 400, corsHeaders);
      const snippets = [];
      try {
        const wikiResp = await fetch(
          `https://ru.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(q)}&utf8=&format=json&srlimit=3`,
          { headers: { "User-Agent": "MiTvEchoAgent/1.0" } }
        );
        if (wikiResp.ok) {
          const wikiJson = await wikiResp.json();
          for (const item of (wikiJson?.query?.search || [])) {
            const clean = String(item.snippet || "").replace(/<[^>]+>/g, "").trim();
            if (clean) snippets.push(`${item.title}: ${clean}`);
          }
        }
      } catch (e) {}
      try {
        const newsResp = await fetch(
          `https://news.google.com/rss/search?q=${encodeURIComponent(q)}&hl=ru&gl=UA&ceid=UA:ru`,
          { headers: { "User-Agent": "Mozilla/5.0" } }
        );
        if (newsResp.ok) {
          const xml = await newsResp.text();
          const matches = [...xml.matchAll(/<item>[\s\S]*?<title><!\[CDATA\[([^\]]+)\]\]><\/title>|<item>[\s\S]*?<title>([^<]+)<\/title>/g)];
          for (const m of matches.slice(0, 4)) {
            const t = (m[1] || m[2] || "").replace(/&quot;/g, '"').replace(/&amp;/g, "&").trim();
            if (t && !t.includes("Google Новости")) snippets.push(t);
          }
        }
      } catch (e) {}
      return jsonResponse({ ok: true, query: q, snippets: snippets.slice(0, 6) }, 200, corsHeaders);
    }

    // 1. Fast YouTube videoId Resolver
    if (path === "/yt/resolve") {
      const q = (url.searchParams.get("q") || "").trim();
      if (!q) {
        return jsonResponse({ ok: false, error: "empty_query" }, 400, corsHeaders);
      }
      try {
        const ytUrl = "https://www.youtube.com/results?search_query=" + encodeURIComponent(q) + "&hl=ru&sp=EgIQAQ%253D%253D";
        const resp = await fetch(ytUrl, {
          headers: {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
            "Accept-Language": "ru-RU,ru;q=0.9,en-US;q=0.8"
          }
        });
        const html = await resp.text();
        const match = html.match(/"videoId":"([a-zA-Z0-9_-]{11})"/);
        if (match && match[1]) {
          return jsonResponse({ ok: true, videoId: match[1], query: q }, 200, corsHeaders);
        }
      } catch (e) {}
      return jsonResponse({ ok: false, error: "not_found" }, 404, corsHeaders);
    }

    // 2. Spotify OAuth 2.0 QR Flow
    if (path === "/auth/spotify/start") {
      const deviceId = (url.searchParams.get("device_id") || "default_tv").trim();
      const clientId = env.SPOTIFY_CLIENT_ID || url.searchParams.get("client_id") || SPOTIFY_CLIENT_ID_FALLBACK;
      const redirectUri = `${url.origin}/auth/spotify/callback`;
      if (!clientId) {
        return new Response(renderSpotifySetupHtml(url.origin, deviceId), {
          status: 200,
          headers: { "Content-Type": "text/html; charset=utf-8", ...corsHeaders }
        });
      }
      const scopes = [
        "user-modify-playback-state",
        "user-read-playback-state",
        "user-read-currently-playing",
        "user-library-modify",
        "user-library-read",
        "playlist-modify-public",
        "playlist-modify-private",
        "playlist-read-private"
      ].join(" ");
      const authUrl = "https://accounts.spotify.com/authorize" +
        `?response_type=code` +
        `&client_id=${encodeURIComponent(clientId)}` +
        `&scope=${encodeURIComponent(scopes)}` +
        `&redirect_uri=${encodeURIComponent(redirectUri)}` +
        `&state=${encodeURIComponent(deviceId)}`;
      return Response.redirect(authUrl, 302);
    }

    if (path === "/auth/spotify/callback") {
      const code = url.searchParams.get("code") || "";
      const deviceId = url.searchParams.get("state") || "default_tv";
      const clientId = env.SPOTIFY_CLIENT_ID || SPOTIFY_CLIENT_ID_FALLBACK;
      const clientSecret = env.SPOTIFY_CLIENT_SECRET || SPOTIFY_CLIENT_SECRET_FALLBACK;
      const redirectUri = `${url.origin}/auth/spotify/callback`;

      if (!code || !clientId || !clientSecret) {
        return new Response("Ошибка авторизации Spotify: проверьте SPOTIFY_CLIENT_ID / SPOTIFY_CLIENT_SECRET в настройках Worker.", {
          status: 400,
          headers: { "Content-Type": "text/plain; charset=utf-8" }
        });
      }

      const tokenResp = await fetch("https://accounts.spotify.com/api/token", {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          "Authorization": "Basic " + btoa(`${clientId}:${clientSecret}`)
        },
        body: new URLSearchParams({
          grant_type: "authorization_code",
          code,
          redirect_uri: redirectUri
        })
      });
      const tokenJson = await tokenResp.json();
      if (tokenJson.access_token) {
        const record = {
          access_token: tokenJson.access_token,
          refresh_token: tokenJson.refresh_token || "",
          expires_at: Date.now() + ((tokenJson.expires_in || 3600) * 1000)
        };
        await saveDeviceToken(env, deviceId, record);
        return new Response(
          "<html><body style='background:#0D0F14;color:#fff;font-family:sans-serif;text-align:center;padding:48px;'>" +
          "<h2 style='color:#00F0FF;'>Эхо · Spotify подключён!</h2>" +
          "<p>Теперь можно закрыть эту страницу и управлять плейлистами и лайками голосом на телевизоре.</p></body></html>",
          { status: 200, headers: { "Content-Type": "text/html; charset=utf-8" } }
        );
      }
      return jsonResponse({ ok: false, error: tokenJson }, 400, corsHeaders);
    }

    if (path === "/auth/spotify/status") {
      const deviceId = (url.searchParams.get("device_id") || "default_tv").trim();
      const rec = await getDeviceToken(env, deviceId);
      const linked = !!(rec && rec.access_token);
      return jsonResponse({
        ok: true,
        linked,
        refresh_token: linked ? (rec.refresh_token || "") : ""
      }, 200, corsHeaders);
    }

    if (path === "/auth/spotify/restore" && request.method === "POST") {
      const body = await request.json().catch(() => ({}));
      const deviceId = (body.device_id || "default_tv").trim();
      const rt = (body.refresh_token || "").trim();
      if (!rt) {
        return jsonResponse({ ok: false, error: "missing_refresh_token" }, 400, corsHeaders);
      }
      const restored = await refreshAndSaveWithToken(env, deviceId, rt);
      return jsonResponse({
        ok: !!restored,
        linked: !!restored,
        refresh_token: restored ? (restored.refresh_token || rt) : ""
      }, restored ? 200 : 401, corsHeaders);
    }

    if (path === "/spotify/action" && request.method === "POST") {
      const body = await request.json().catch(() => ({}));
      const deviceId = body.device_id || "default_tv";
      const action = (body.action || "").toUpperCase();
      let token = await getValidSpotifyAccessToken(env, deviceId);
      if (!token && body.refresh_token) {
        const restored = await refreshAndSaveWithToken(env, deviceId, String(body.refresh_token).trim());
        if (restored) token = restored.access_token;
      }
      if (!token) {
        return jsonResponse({ ok: false, error: "not_linked" }, 401, corsHeaders);
      }

      if (action === "LIKE_CURRENT") {
        let trackId = "";
        const curResp = await fetch("https://api.spotify.com/v1/me/player/currently-playing", {
          headers: { "Authorization": `Bearer ${token}` }
        });
        if (curResp.status === 200) {
          const curJson = await curResp.json().catch(() => ({}));
          trackId = (curJson.item && curJson.item.id) || "";
        }
        if (!trackId && body.query) {
          trackId = await searchSpotifyTrackId(token, body.query);
        }
        if (!trackId) {
          return jsonResponse({ ok: false, error: "no_track_found" }, 404, corsHeaders);
        }
        // Spotify (февраль 2026): PUT /me/tracks?ids= удалён -> PUT /me/library?uris=
        const likeResp = await fetch(
          `https://api.spotify.com/v1/me/library?uris=${encodeURIComponent("spotify:track:" + trackId)}`,
          { method: "PUT", headers: { "Authorization": `Bearer ${token}` } }
        );
        if (!likeResp.ok) {
          const likeText = await likeResp.text();
          let likeJson = {};
          try { likeJson = JSON.parse(likeText); } catch (e) {}
          return jsonResponse({
            ok: false,
            error: "like_failed",
            status: likeResp.status,
            message: spotifyErrorMessage(likeJson, likeText)
          }, likeResp.status, corsHeaders);
        }
        return jsonResponse({ ok: true, likedTrackId: trackId }, 200, corsHeaders);
      }

      if (action === "CREATE_PLAYLIST" || action === "ADD_TO_PLAYLIST") {
        const name = (body.name || "Плейлист Эхо").trim();
        const rawSeed = (body.seed_query || "").trim();
        const fallbackQuery = (body.fallback_query || "").trim();
        let targetPlaylistId = (body.playlist_id || "").trim();
        let targetPlaylistUri = targetPlaylistId ? `spotify:playlist:${targetPlaylistId}` : "";

        // Если передан трек и плейлист с таким именем уже есть у пользователя — добавляем в него, не плодя пустые дубли
        if (!targetPlaylistId && rawSeed) {
          try {
            const listResp = await fetch("https://api.spotify.com/v1/me/playlists?limit=50", {
              headers: { "Authorization": `Bearer ${token}` }
            });
            if (listResp.status === 200) {
              const listJson = await listResp.json().catch(() => ({}));
              const found = (listJson.items || []).find(
                p => p && p.name && p.name.trim().toLowerCase() === name.toLowerCase()
              );
              if (found && found.id) {
                targetPlaylistId = found.id;
                targetPlaylistUri = found.uri || `spotify:playlist:${found.id}`;
              }
            }
          } catch (e) {}
        }

        if (!targetPlaylistId) {
          const createResp = await fetch("https://api.spotify.com/v1/me/playlists", {
            method: "POST",
            headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json" },
            body: JSON.stringify({ name, description: "Создано голосовым ассистентом Эхо", public: false })
          });
          const createText = await createResp.text();
          let plJson = {};
          try { plJson = JSON.parse(createText); } catch (e) {}
          if (!createResp.ok || !plJson.id) {
            return jsonResponse({
              ok: false,
              error: "playlist_create_failed",
              status: createResp.status,
              message: spotifyErrorMessage(plJson, createText)
            }, createResp.status >= 400 ? createResp.status : 502, corsHeaders);
          }
          targetPlaylistId = plJson.id;
          targetPlaylistUri = plJson.uri || `spotify:playlist:${plJson.id}`;
        }

        let seeded = false;
        let seedError = "";
        if (rawSeed) {
          let tid = "";
          if (rawSeed.toUpperCase() === "CURRENT") {
            const curResp = await fetch("https://api.spotify.com/v1/me/player/currently-playing", {
              headers: { "Authorization": `Bearer ${token}` }
            });
            if (curResp.status === 200) {
              const curJson = await curResp.json().catch(() => ({}));
              tid = (curJson.item && curJson.item.id) || "";
            }
            if (!tid) {
              const plResp = await fetch("https://api.spotify.com/v1/me/player", {
                headers: { "Authorization": `Bearer ${token}` }
              });
              if (plResp.status === 200) {
                const plData = await plResp.json().catch(() => ({}));
                tid = (plData.item && plData.item.id) || "";
              }
            }
            if (!tid && fallbackQuery) {
              tid = await searchSpotifyTrackId(token, fallbackQuery);
            }
          } else {
            tid = await searchSpotifyTrackId(token, rawSeed);
          }
          if (tid) {
            // Сначала стандартный /tracks, затем /items (февраль 2026)
            let addResp = await fetch(`https://api.spotify.com/v1/playlists/${targetPlaylistId}/tracks`, {
              method: "POST",
              headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json" },
              body: JSON.stringify({ uris: [`spotify:track:${tid}`] })
            });
            if (!addResp.ok) {
              addResp = await fetch(`https://api.spotify.com/v1/playlists/${targetPlaylistId}/items`, {
                method: "POST",
                headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json" },
                body: JSON.stringify({ uris: [`spotify:track:${tid}`] })
              });
            }
            seeded = addResp.ok;
            if (!addResp.ok) {
              const errTxt = await addResp.text().catch(() => "add_failed");
              let errJson = {};
              try { errJson = JSON.parse(errTxt); } catch (e) {}
              seedError = spotifyErrorMessage(errJson, errTxt);
            }
          } else {
            seedError = "track_not_found";
          }
        }
        return jsonResponse({ ok: true, playlistId: targetPlaylistId, uri: targetPlaylistUri, name, seeded, seedError }, 200, corsHeaders);
      }

      if (action === "PLAY_PLAYLIST") {
        const plUri = (body.uri || "").trim();
        if (!/^spotify:playlist:[A-Za-z0-9]+$/.test(plUri)) {
          return jsonResponse({ ok: false, error: "bad_playlist_uri" }, 400, corsHeaders);
        }
        // Запуск плейлиста целиком на активном устройстве (нужен Spotify Premium и открытое приложение на ТВ).
        const playResp = await fetch("https://api.spotify.com/v1/me/player/play", {
          method: "PUT",
          headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json" },
          body: JSON.stringify({ context_uri: plUri })
        });
        if (!playResp.ok) {
          const playText = await playResp.text();
          let playJson = {};
          try { playJson = JSON.parse(playText); } catch (e) {}
          return jsonResponse({
            ok: false,
            error: "play_playlist_failed",
            status: playResp.status,
            message: spotifyErrorMessage(playJson, playText)
          }, playResp.status, corsHeaders);
        }
        return jsonResponse({ ok: true, uri: plUri }, 200, corsHeaders);
      }

      if (action === "GET_QUEUE") {
        const qResp = await fetch("https://api.spotify.com/v1/me/player/queue", {
          headers: { "Authorization": `Bearer ${token}` }
        });
        if (qResp.status === 200) {
          const qJson = await qResp.json().catch(() => ({}));
          const nextItem = Array.isArray(qJson.queue) && qJson.queue.length > 0 ? qJson.queue[0] : null;
          if (nextItem && nextItem.name) {
            const artist = (Array.isArray(nextItem.artists) && nextItem.artists[0] && nextItem.artists[0].name) || "";
            const label = artist ? `${artist} — ${nextItem.name}` : nextItem.name;
            return jsonResponse({
              ok: true,
              nextTitle: nextItem.name,
              nextArtist: artist,
              nextLabel: label
            }, 200, corsHeaders);
          }
        }
        return jsonResponse({ ok: false, nextLabel: "" }, 200, corsHeaders);
      }

      if (action === "SEARCH_URI") {
        const q = (body.query || "").trim();
        if (!q) return jsonResponse({ ok: false }, 400, corsHeaders);
        const sResp = await fetch(
          `https://api.spotify.com/v1/search?type=track,artist,album,playlist&limit=3&q=${encodeURIComponent(q)}`,
          { headers: { "Authorization": `Bearer ${token}` } }
        );
        const sData = await sResp.json().catch(() => ({}));
        const qLower = q.toLowerCase();
        const topArtist = sData?.artists?.items?.[0];
        const topTrack = sData?.tracks?.items?.[0];
        const topAlbum = sData?.albums?.items?.[0];
        const topPlaylist = sData?.playlists?.items?.[0];

        let targetUri = "";
        if (topArtist && topArtist.name && topArtist.name.toLowerCase() === qLower) {
          targetUri = topArtist.uri || `spotify:artist:${topArtist.id}`;
        } else if (topTrack && topTrack.album && topTrack.album.id) {
          targetUri = topTrack.album.uri || `spotify:album:${topTrack.album.id}`;
        } else if (topArtist && topArtist.id) {
          targetUri = topArtist.uri || `spotify:artist:${topArtist.id}`;
        } else if (topAlbum && topAlbum.id) {
          targetUri = topAlbum.uri || `spotify:album:${topAlbum.id}`;
        } else if (topPlaylist && topPlaylist.id) {
          targetUri = topPlaylist.uri || `spotify:playlist:${topPlaylist.id}`;
        }
        return jsonResponse({
          ok: !!targetUri,
          uri: targetUri,
          trackUri: topTrack ? (`spotify:track:${topTrack.id}`) : "",
          albumUri: (topTrack && topTrack.album && topTrack.album.id) ? (`spotify:album:${topTrack.album.id}`) : "",
          artistUri: topArtist ? (`spotify:artist:${topArtist.id}`) : ""
        }, 200, corsHeaders);
      }

      if (action === "PAUSE" || action === "PLAY" || action === "NEXT" || action === "PREV") {
        let ep = "https://api.spotify.com/v1/me/player/pause";
        let method = "PUT";
        if (action === "PLAY") { ep = "https://api.spotify.com/v1/me/player/play"; method = "PUT"; }
        else if (action === "NEXT") { ep = "https://api.spotify.com/v1/me/player/next"; method = "POST"; }
        else if (action === "PREV") { ep = "https://api.spotify.com/v1/me/player/previous"; method = "POST"; }
        const r = await fetch(ep, { method, headers: { "Authorization": `Bearer ${token}` } });
        return jsonResponse({ ok: r.ok || r.status === 204, status: r.status }, 200, corsHeaders);
      }

      if (action === "PLAY_QUERY") {
        const q = (body.query || "").trim();
        const tid = await searchSpotifyTrackId(token, q);
        if (!tid) {
          return jsonResponse({ ok: false, error: "track_not_found" }, 404, corsHeaders);
        }
        let playResp = await fetch("https://api.spotify.com/v1/me/player/play", {
          method: "PUT",
          headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json" },
          body: JSON.stringify({ uris: [`spotify:track:${tid}`] })
        });
        if (playResp.status === 404) {
          const devResp = await fetch("https://api.spotify.com/v1/me/player/devices", {
            headers: { "Authorization": `Bearer ${token}` }
          });
          const devJson = await devResp.json().catch(() => ({}));
          const devices = devJson.devices || [];
          const tvDev = devices.find(d => d && (d.type === "TV" || (d.name || "").toLowerCase().includes("tv") || (d.name || "").toLowerCase().includes("stick"))) || devices[0];
          if (tvDev && tvDev.id) {
            playResp = await fetch(`https://api.spotify.com/v1/me/player/play?device_id=${encodeURIComponent(tvDev.id)}`, {
              method: "PUT",
              headers: { "Authorization": `Bearer ${token}`, "Content-Type": "application/json" },
              body: JSON.stringify({ uris: [`spotify:track:${tid}`] })
            });
          }
        }
        return jsonResponse({ ok: true, played: playResp.ok || playResp.status === 204, trackId: tid, uri: `spotify:track:${tid}` }, 200, corsHeaders);
      }
    }

    // 3. Tuya OpenAPI Proxy (/tuya/...)
    if (path.startsWith("/tuya/")) {
      const tuyaPath = path.replace(/^\/tuya/, "") + url.search;
      const targetUrl = "https://openapi.tuyaeu.com" + tuyaPath;
      const headers = new Headers();
      for (const [k, v] of request.headers.entries()) {
        if (["client_id", "sign", "t", "sign_method", "access_token", "content-type"].includes(k.toLowerCase())) {
          headers.set(k, v);
        }
      }
      const resp = await fetch(targetUrl, {
        method: request.method,
        headers,
        body: ["GET", "HEAD"].includes(request.method) ? undefined : await request.arrayBuffer()
      });
      return new Response(resp.body, { status: resp.status, headers: corsHeaders });
    }

    // 4. Gemini API Proxy (/gemini/...)
    if (path.startsWith("/gemini/")) {
      const geminiPath = path.replace(/^\/gemini/, "") + url.search;
      const targetUrl = "https://generativelanguage.googleapis.com" + geminiPath;
      const resp = await fetch(targetUrl, {
        method: request.method,
        headers: { "Content-Type": "application/json" },
        body: ["GET", "HEAD"].includes(request.method) ? undefined : await request.arrayBuffer()
      });
      return new Response(resp.body, { status: resp.status, headers: corsHeaders });
    }

    return jsonResponse({ ok: true, service: "MiTvStick Super-Echo Gateway v0.8.9" }, 200, corsHeaders);
  }
};

function spotifyErrorMessage(json, rawText) {
  const e = json && json.error;
  if (e && typeof e === "object" && e.message) return String(e.message);
  if (typeof e === "string" && e) return e;
  return String(rawText || "").slice(0, 200);
}

function jsonResponse(obj, status, extraHeaders) {
  return new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", ...extraHeaders }
  });
}

async function saveDeviceToken(env, deviceId, record) {
  memoryStore.set(deviceId, record);
  if (env.ECHO_KV) {
    await env.ECHO_KV.put(`spotify:${deviceId}`, JSON.stringify(record));
  }
}

async function getDeviceToken(env, deviceId) {
  if (memoryStore.has(deviceId)) return memoryStore.get(deviceId);
  if (env.ECHO_KV) {
    const raw = await env.ECHO_KV.get(`spotify:${deviceId}`);
    if (raw) {
      const parsed = JSON.parse(raw);
      memoryStore.set(deviceId, parsed);
      return parsed;
    }
  }
  return null;
}

async function refreshAndSaveWithToken(env, deviceId, refreshToken) {
  const cid = env.SPOTIFY_CLIENT_ID || SPOTIFY_CLIENT_ID_FALLBACK;
  const csec = env.SPOTIFY_CLIENT_SECRET || SPOTIFY_CLIENT_SECRET_FALLBACK;
  if (!refreshToken || !cid || !csec) return null;
  const resp = await fetch("https://accounts.spotify.com/api/token", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "Authorization": "Basic " + btoa(`${cid}:${csec}`)
    },
    body: new URLSearchParams({
      grant_type: "refresh_token",
      refresh_token: refreshToken
    })
  });
  const data = await resp.json().catch(() => ({}));
  if (data.access_token) {
    const rec = {
      access_token: data.access_token,
      refresh_token: data.refresh_token || refreshToken,
      expires_at: Date.now() + ((data.expires_in || 3600) * 1000)
    };
    await saveDeviceToken(env, deviceId, rec);
    return rec;
  }
  return null;
}

async function getValidSpotifyAccessToken(env, deviceId) {
  const rec = await getDeviceToken(env, deviceId);
  if (!rec) return null;
  if (Date.now() < (rec.expires_at || 0) - 60000) {
    return rec.access_token;
  }
  const cid = env.SPOTIFY_CLIENT_ID || SPOTIFY_CLIENT_ID_FALLBACK;
  const csec = env.SPOTIFY_CLIENT_SECRET || SPOTIFY_CLIENT_SECRET_FALLBACK;
  if (!rec.refresh_token || !cid || !csec) {
    return rec.access_token;
  }
  const resp = await fetch("https://accounts.spotify.com/api/token", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      "Authorization": "Basic " + btoa(`${cid}:${csec}`)
    },
    body: new URLSearchParams({
      grant_type: "refresh_token",
      refresh_token: rec.refresh_token
    })
  });
  const data = await resp.json().catch(() => ({}));
  if (data.access_token) {
    rec.access_token = data.access_token;
    rec.expires_at = Date.now() + ((data.expires_in || 3600) * 1000);
    await saveDeviceToken(env, deviceId, rec);
  }
  return rec.access_token;
}

async function searchSpotifyTrackId(token, query) {
  const resp = await fetch(
    `https://api.spotify.com/v1/search?type=track&limit=1&q=${encodeURIComponent(query)}`,
    { headers: { "Authorization": `Bearer ${token}` } }
  );
  const data = await resp.json().catch(() => ({}));
  return data?.tracks?.items?.[0]?.id || "";
}

function renderSpotifySetupHtml(origin, deviceId) {
  return `<!DOCTYPE html><html lang="ru"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
  <title>Эхо · Подключение Spotify</title>
  <style>body{background:#0D0F14;color:#fff;font-family:sans-serif;padding:28px;max-width:460px;margin:0 auto;text-align:center}
  .card{background:#161922;border:1px solid #3300F0FF;border-radius:20px;padding:24px;margin-top:20px}
  a.btn{display:inline-block;background:#00F0FF;color:#000;font-weight:600;padding:12px 24px;border-radius:999px;text-decoration:none;margin-top:16px}</style></head>
  <body><h2 style="color:#00F0FF">Эхо · Музыкальный мост</h2>
  <div class="card"><p>Устройство ТВ: <b>${deviceId}</b></p>
  <p style="color:#99FFFFFF;font-size:14px">Для облачного создания плейлистов укажите SPOTIFY_CLIENT_ID и SPOTIFY_CLIENT_SECRET в переменных Cloudflare Worker и обновите страницу.</p>
  </div></body></html>`;
}

function describeWmoCodeRu(code) {
  if (code === 0) return "ясно";
  if (code === 1 || code === 2) return "переменная облачность";
  if (code === 3) return "пасмурно";
  if (code === 45 || code === 48) return "туман";
  if (code >= 51 && code <= 67) return "дождь";
  if (code >= 71 && code <= 77) return "снег";
  if (code >= 80 && code <= 82) return "ливень";
  if (code >= 95) return "гроза";
  return "облачно";
}


// ============================================================================
// Telegram-бот напоминаний и журнала отметок (этап 1, Durable Object InsulinBot)
// ============================================================================

const INS_TZ = "Europe/Kyiv";
const ASK_AT = "21:30";
const DEFAULT_AT = "23:15";
const DEADLINE_AT = "01:00";
const EVENING_FROM = "18:00";
const DAY_ROLLOVER_HOUR = 3;
const PLAN_DELAY_MIN = 10;
const HOME_DELAY_MIN = 5;
const REPEAT_MIN = 10;
const SNOOZE_MIN = 15;
const DOUBLE_TAP_MIN = 3;
const UNDO_WINDOW_MIN = 30;
const LOG_MAX = 200;
const EVENTS_MAX = 100;

const insKyivFormatter = new Intl.DateTimeFormat("en-CA", {
  timeZone: INS_TZ,
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
  hour: "2-digit",
  minute: "2-digit",
  second: "2-digit",
  hourCycle: "h23"
});

function insKyivParts(ms) {
  const parts = insKyivFormatter.formatToParts(new Date(ms));
  const map = {};
  for (const p of parts) {
    if (p.type !== "literal") map[p.type] = p.value;
  }
  const year = Number(map.year);
  const month = Number(map.month);
  const day = Number(map.day);
  const rawHour = Number(map.hour);
  const hour = rawHour === 24 ? 0 : rawHour;
  const minute = Number(map.minute);
  const second = Number(map.second);
  const yStr = String(year).padStart(4, "0");
  const mStr = String(month).padStart(2, "0");
  const dStr = String(day).padStart(2, "0");
  const hhStr = String(hour).padStart(2, "0");
  const mmStr = String(minute).padStart(2, "0");
  return {
    year,
    month,
    day,
    hour,
    minute,
    second,
    dateStr: `${yStr}-${mStr}-${dStr}`,
    hmStr: `${hhStr}:${mmStr}`
  };
}

function insAddDays(dateStr, deltaDays) {
  const [y, m, d] = String(dateStr).split("-").map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d + deltaDays, 12, 0, 0));
  const yy = dt.getUTCFullYear();
  const mm = String(dt.getUTCMonth() + 1).padStart(2, "0");
  const dd = String(dt.getUTCDate()).padStart(2, "0");
  return `${yy}-${mm}-${dd}`;
}

function insKyivToMs(dateStr, hmStr) {
  const [y, m, d] = String(dateStr).split("-").map(Number);
  const [hh, mm] = String(hmStr).split(":").map(Number);
  const targetAsUtc = Date.UTC(y, m - 1, d, hh, mm, 0, 0);
  let guess = targetAsUtc;
  for (let i = 0; i < 3; i++) {
    const p = insKyivParts(guess);
    const curAsUtc = Date.UTC(p.year, p.month - 1, p.day, p.hour, p.minute, p.second, 0);
    const diff = targetAsUtc - curAsUtc;
    if (diff === 0) break;
    guess += diff;
  }
  return guess;
}

function insFmtHm(ms) {
  return insKyivParts(ms).hmStr;
}

function insFmtDayWordAndHm(ms, nowMs) {
  const mp = insKyivParts(ms);
  const np = insKyivParts(nowMs);
  const yesterdayStr = insAddDays(np.dateStr, -1);
  if (mp.dateStr === np.dateStr) {
    return `сегодня в ${mp.hmStr}`;
  }
  if (mp.dateStr === yesterdayStr) {
    return `вчера в ${mp.hmStr}`;
  }
  const dd = String(mp.day).padStart(2, "0");
  const mm = String(mp.month).padStart(2, "0");
  return `${dd}.${mm} в ${mp.hmStr}`;
}

function insFmtRel(diffMs) {
  const totalMin = Math.max(0, Math.floor(diffMs / 60000));
  if (totalMin < 60) {
    return `${totalMin} мин назад`;
  }
  const h = Math.floor(totalMin / 60);
  const m = totalMin % 60;
  return `${h} ч ${m} мин назад`;
}

function insSanitizeErr(raw) {
  return String(raw || "error")
    .replace(/https?:\/\/[^\s)]+/gi, "[url]")
    .replace(/bot\d+:[A-Za-z0-9_-]+/g, "[token]")
    .slice(0, 120);
}

function insReplyKeyboard() {
  return {
    keyboard: [[{ text: "💉 Сделал" }, { text: "🕘 Когда колол?" }]],
    resize_keyboard: true,
    is_persistent: true
  };
}

async function insTelegram(env, method, payload) {
  if (!env || !env.BOT_TOKEN) {
    return { ok: false, status: 503, errorCode: 503, description: "no_bot_token" };
  }
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 8000);
  try {
    const resp = await fetch(`https://api.telegram.org/bot${env.BOT_TOKEN}/${method}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload || {}),
      signal: controller.signal
    });
    const data = await resp.json().catch(() => ({}));
    if (resp.ok && data && data.ok) {
      return { ok: true, status: resp.status, result: data.result };
    }
    const code = (data && data.error_code) || resp.status || 500;
    const desc = insSanitizeErr((data && data.description) || `http_${code}`);
    return { ok: false, status: resp.status, errorCode: code, description: desc };
  } catch (e) {
    const name = e && e.name === "AbortError" ? "timeout" : insSanitizeErr(e && e.message);
    return { ok: false, status: 0, errorCode: 0, description: name };
  } finally {
    clearTimeout(timer);
  }
}

export async function handleTelegramWebhook(request, env) {
  if (!env || !env.BOT_TOKEN || !env.OWNER_CHAT_ID || !env.WEBHOOK_SECRET) {
    return new Response("Service Unavailable", { status: 503 });
  }
  const secretHeader = request.headers.get("X-Telegram-Bot-Api-Secret-Token") || "";
  if (secretHeader !== String(env.WEBHOOK_SECRET)) {
    return new Response("Forbidden", { status: 403 });
  }
  let update;
  try {
    update = await request.json();
  } catch (e) {
    return new Response("OK", { status: 200 });
  }
  if (!update || typeof update !== "object") {
    return new Response("OK", { status: 200 });
  }
  const hasMessage = !!update.message;
  const hasCallback = !!update.callback_query;
  if (!hasMessage && !hasCallback) {
    return new Response("OK", { status: 200 });
  }
  const ownerId = Number(env.OWNER_CHAT_ID);
  const authorId = hasMessage
    ? Number(update.message?.chat?.id)
    : Number(update.callback_query?.from?.id);
  const chatId = hasMessage
    ? Number(update.message?.chat?.id)
    : Number(update.callback_query?.message?.chat?.id ?? update.callback_query?.from?.id);
  if (!Number.isFinite(ownerId) || authorId !== ownerId || chatId !== ownerId) {
    return new Response("OK", { status: 200 });
  }
  try {
    if (env.INSULIN_BOT) {
      const stub = env.INSULIN_BOT.get(env.INSULIN_BOT.idFromName("owner"));
      await stub.fetch("https://insulin.internal/update", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(update)
      });
    }
  } catch (e) {
    // Всегда возвращаем 200 Telegram после прохождения проверок
  }
  return new Response("OK", { status: 200 });
}

export async function runInsulinTick(env) {
  if (!env || !env.INSULIN_BOT) return;
  try {
    const stub = env.INSULIN_BOT.get(env.INSULIN_BOT.idFromName("owner"));
    await stub.fetch("https://insulin.internal/tick", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: "{}"
    });
  } catch (e) {}
}

export class InsulinBot {
  constructor(state, env) {
    this.state = state;
    this.env = env;
  }

  async fetch(request) {
    const url = new URL(request.url);
    try {
      if (url.pathname === "/update" && request.method === "POST") {
        const update = await request.json();
        await this.handleUpdate(update);
        return new Response(JSON.stringify({ ok: true }), {
          status: 200,
          headers: { "Content-Type": "application/json" }
        });
      }
      if (url.pathname === "/tick" && request.method === "POST") {
        const body = await request.json().catch(() => ({}));
        const now = typeof body.now === "number" ? body.now : Date.now();
        await this.tick(now);
        return new Response(JSON.stringify({ ok: true }), {
          status: 200,
          headers: { "Content-Type": "application/json" }
        });
      }
      return new Response(JSON.stringify({ ok: false }), {
        status: 404,
        headers: { "Content-Type": "application/json" }
      });
    } catch (e) {
      return new Response(JSON.stringify({ ok: false }), {
        status: 200,
        headers: { "Content-Type": "application/json" }
      });
    }
  }

  async alarm() {
    const now = Date.now();
    try {
      await this.tick(now);
    } catch (e) {
      try {
        await this.recordEvent(now, "error", "alarm_exception");
      } catch (_) {}
    } finally {
      try {
        await this.scheduleNextAlarm(Date.now());
      } catch (_) {}
    }
  }

  eveningDay(now) {
    const p = insKyivParts(now);
    if (p.hour < DAY_ROLLOVER_HOUR) {
      return insAddDays(p.dateStr, -1);
    }
    return p.dateStr;
  }

  dayBounds(dayStr) {
    const nextDay = insAddDays(dayStr, 1);
    return {
      day: dayStr,
      nextDay,
      eveningFromMs: insKyivToMs(dayStr, EVENING_FROM),
      askAtMs: insKyivToMs(dayStr, ASK_AT),
      defaultAtMs: insKyivToMs(dayStr, DEFAULT_AT),
      deadlineMs: insKyivToMs(nextDay, DEADLINE_AT),
      rolloverMs: insKyivToMs(nextDay, `${String(DAY_ROLLOVER_HOUR).padStart(2, "0")}:00`),
      nextDayAskAtMs: insKyivToMs(nextDay, ASK_AT)
    };
  }

  createFreshState(dayStr) {
    return {
      day: dayStr,
      askSentAt: null,
      askMessageId: null,
      awaitingCustomTime: false,
      plannedAt: null,
      lastRemindAt: null,
      nextRemindAt: null,
      remindCount: 0,
      lastReminderMessageId: null,
      expiredSentAt: null,
      closedAt: null,
      consecutiveSendErrors: 0,
      retryAt: null
    };
  }

  async getLog() {
    const arr = await this.state.storage.get("log");
    return Array.isArray(arr) ? arr : [];
  }

  async saveLog(arr) {
    while (arr.length > LOG_MAX) arr.shift();
    await this.state.storage.put("log", arr);
  }

  async getEvents() {
    const arr = await this.state.storage.get("events");
    return Array.isArray(arr) ? arr : [];
  }

  async recordEvent(ts, type, info = "") {
    const events = await this.getEvents();
    events.push({ ts, type, info: String(info || "").slice(0, 60) });
    while (events.length > EVENTS_MAX) events.shift();
    await this.state.storage.put("events", events);
  }

  findEveningMark(log, dayStr) {
    const b = this.dayBounds(dayStr);
    for (let i = log.length - 1; i >= 0; i--) {
      const item = log[i];
      if (item && item.ts >= b.eveningFromMs && item.ts < b.rolloverMs) {
        return item;
      }
    }
    return null;
  }

  async clearInlineMarkupBestEffort(messageId) {
    if (!messageId || !this.env || !this.env.OWNER_CHAT_ID) return;
    try {
      await insTelegram(this.env, "editMessageReplyMarkup", {
        chat_id: Number(this.env.OWNER_CHAT_ID),
        message_id: messageId,
        reply_markup: { inline_keyboard: [] }
      });
    } catch (_) {}
  }

  async sendOwnerMessage(text, extra = {}) {
    if (!this.env || !this.env.BOT_TOKEN || !this.env.OWNER_CHAT_ID) {
      return { ok: false, errorCode: 503, description: "missing_env" };
    }
    const payload = {
      chat_id: Number(this.env.OWNER_CHAT_ID),
      text,
      reply_markup: extra.reply_markup || insReplyKeyboard()
    };
    return await insTelegram(this.env, "sendMessage", payload);
  }

  async addMark(ts, src, now = Date.now(), isStaleButton = false) {
    const log = await this.getLog();
    const isNowMark = src !== "manual" && Math.abs(now - ts) < 5000;
    if (isNowMark && log.length > 0) {
      const last = log[log.length - 1];
      if (last && now - last.ts >= 0 && now - last.ts < DOUBLE_TAP_MIN * 60000) {
        const minAgo = Math.max(0, Math.floor((now - last.ts) / 60000));
        return {
          added: false,
          replyText: `Уже отмечено в ${insFmtHm(last.ts)} (${minAgo} мин назад). Повторно не записываю.`
        };
      }
    }

    const nextId = log.length > 0 ? (Number(log[log.length - 1].id) || log.length) + 1 : 1;
    const entry = { id: nextId, ts, src };
    log.push(entry);
    log.sort((a, b) => a.ts - b.ts);
    await this.saveLog(log);

    const curDay = this.eveningDay(now);
    const bounds = this.dayBounds(curDay);
    const afterDeadline = ts >= bounds.deadlineMs && ts < bounds.rolloverMs;
    await this.recordEvent(now, "mark", afterDeadline ? "after_deadline" : src);

    let replyText = `✅ Отмечено: ${insFmtDayWordAndHm(ts, now)}.`;
    if (isStaleButton) {
      replyText += " Это было старое сообщение, записано текущее время.";
    }
    return { added: true, entry, replyText };
  }

  async runSingleChainTick(now, chainState, cfg, hasMark, isTest) {
    let dirty = false;

    if (hasMark) {
      if (!chainState.closedAt) {
        chainState.closedAt = now;
        chainState.awaitingCustomTime = false;
        chainState.retryAt = null;
        chainState.consecutiveSendErrors = 0;
        dirty = true;
        if (chainState.askMessageId) {
          await this.clearInlineMarkupBestEffort(chainState.askMessageId);
        }
        if (chainState.lastReminderMessageId) {
          await this.clearInlineMarkupBestEffort(chainState.lastReminderMessageId);
        }
      }
      return dirty;
    } else if (chainState.closedAt) {
      // Если отметку отменили через /undo — цепочка снова открыта
      chainState.closedAt = null;
      dirty = true;
    }

    if (now < cfg.askAtMs) {
      return dirty;
    }

    if (chainState.retryAt && now < chainState.retryAt) {
      return dirty;
    }

    // Шаг 4: вопрос не отправлялся
    if (!chainState.askSentAt) {
      if (now < cfg.defaultAtMs) {
        const res = await this.sendOwnerMessage(
          `${cfg.prefix}🕘 Вечерний укол сегодня. Во сколько освободитесь?`,
          {
            reply_markup: {
              inline_keyboard: [
                [
                  { text: "22:00", callback_data: `${cfg.cbPrefix}ask:2200` },
                  { text: "23:00", callback_data: `${cfg.cbPrefix}ask:2300` }
                ],
                [
                  { text: "Уже дома", callback_data: `${cfg.cbPrefix}ask:home` },
                  { text: "Другое время", callback_data: `${cfg.cbPrefix}ask:other` }
                ]
              ]
            }
          }
        );
        if (res.ok) {
          chainState.askSentAt = now;
          chainState.askMessageId = res.result?.message_id || null;
          chainState.consecutiveSendErrors = 0;
          chainState.retryAt = null;
          dirty = true;
          await this.recordEvent(now, "ask", isTest ? "test" : "");
        } else {
          await this.handleSendFailure(now, chainState, res);
          dirty = true;
          return dirty;
        }
      } else {
        // Бот «проснулся» поздно — вопрос пропускаем
        chainState.askSentAt = now;
        if (!chainState.plannedAt) {
          chainState.plannedAt = now;
        }
        dirty = true;
      }
    }

    // Шаг 5: определяем эффективный plannedAt (если не задан пользователем — DEFAULT_AT суток D)
    const effectivePlannedAt = chainState.plannedAt || cfg.defaultAtMs;

    if (now >= effectivePlannedAt && now < cfg.deadlineMs) {
      if (!chainState.lastRemindAt || (chainState.nextRemindAt && now >= chainState.nextRemindAt)) {
        const prevRemMsgId = chainState.lastReminderMessageId;
        const snoozeLabel = isTest ? `⏰ Через ${cfg.snoozeMin} мин` : "⏰ Через 15 мин";
        const res = await this.sendOwnerMessage(
          `${cfg.prefix}💉 Вечерний укол. Отметки пока нет. Если уже сделали, нажмите «Сделал».`,
          {
            reply_markup: {
              inline_keyboard: [
                [
                  { text: "✅ Сделал", callback_data: `${cfg.cbPrefix}mark` },
                  { text: snoozeLabel, callback_data: `${cfg.cbPrefix}snooze` }
                ]
              ]
            }
          }
        );
        if (res.ok) {
          if (prevRemMsgId) {
            await this.clearInlineMarkupBestEffort(prevRemMsgId);
          }
          chainState.remindCount = (chainState.remindCount || 0) + 1;
          chainState.lastRemindAt = now;
          chainState.nextRemindAt = now + cfg.repeatMin * 60000;
          chainState.lastReminderMessageId = res.result?.message_id || null;
          chainState.consecutiveSendErrors = 0;
          chainState.retryAt = null;
          dirty = true;
          await this.recordEvent(now, "remind", isTest ? `test#${chainState.remindCount}` : `#${chainState.remindCount}`);
        } else {
          await this.handleSendFailure(now, chainState, res);
          dirty = true;
          return dirty;
        }
      }
    } else if (now >= cfg.deadlineMs && !chainState.expiredSentAt) {
      const prevRemMsgId = chainState.lastReminderMessageId;
      const res = await this.sendOwnerMessage(
        `${cfg.prefix}⚠️ Вечерней отметки до 01:00 нет. Это не значит, что укол пропущен: если вы его сделали, нажмите «Сделал» или напишите, например: сделал 23:40. Как действовать при сомнении, решайте по рекомендациям врача.`,
        {
          reply_markup: {
            inline_keyboard: [
              [{ text: "✅ Сделал", callback_data: `${cfg.cbPrefix}mark` }]
            ]
          }
        }
      );
      if (res.ok) {
        if (prevRemMsgId) {
          await this.clearInlineMarkupBestEffort(prevRemMsgId);
        }
        chainState.expiredSentAt = now;
        chainState.consecutiveSendErrors = 0;
        chainState.retryAt = null;
        dirty = true;
        await this.recordEvent(now, "expired", isTest ? "test" : "");
      } else {
        await this.handleSendFailure(now, chainState, res);
        dirty = true;
        return dirty;
      }
    }

    return dirty;
  }

  async handleSendFailure(now, chainState, res) {
    const errs = (chainState.consecutiveSendErrors || 0) + 1;
    chainState.consecutiveSendErrors = errs;
    const isBlockedOrNotFound = res && (res.errorCode === 403 || res.errorCode === 400);
    const delayMs = isBlockedOrNotFound
      ? 5 * 60000
      : errs === 1
      ? 60000
      : errs === 2
      ? 2 * 60000
      : 5 * 60000;
    chainState.retryAt = now + delayMs;
    if (errs === 1) {
      await this.recordEvent(now, "error", res?.description || `err_${res?.errorCode || 0}`);
    }
  }

  async tick(now = Date.now()) {
    if (!this.env || !this.env.BOT_TOKEN || !this.env.OWNER_CHAT_ID || !this.env.WEBHOOK_SECRET) {
      await this.scheduleNextAlarm(now);
      return;
    }

    const D = this.eveningDay(now);
    const bounds = this.dayBounds(D);
    const log = await this.getLog();

    let state = await this.state.storage.get("state");
    if (!state || state.day !== D) {
      if (state && state.day && state.day !== D) {
        const outcome = state.closedAt ? "closed" : state.expiredSentAt ? "expired" : "rollover";
        await this.recordEvent(now, outcome === "expired" ? "expired" : "mark", `day_end:${state.day}:${outcome}`);
      }
      state = this.createFreshState(D);
      await this.state.storage.put("state", state);
    }

    const eveningMark = this.findEveningMark(log, D);
    const realCfg = {
      askAtMs: bounds.askAtMs,
      defaultAtMs: bounds.defaultAtMs,
      deadlineMs: bounds.deadlineMs,
      repeatMin: REPEAT_MIN,
      snoozeMin: SNOOZE_MIN,
      prefix: "",
      cbPrefix: ""
    };

    const realDirty = await this.runSingleChainTick(now, state, realCfg, !!eveningMark, false);
    if (realDirty) {
      await this.state.storage.put("state", state);
    }

    const testState = await this.state.storage.get("testState");
    if (testState && testState.active) {
      const testCfg = {
        askAtMs: testState.askAtMs,
        defaultAtMs: testState.defaultAtMs,
        deadlineMs: testState.deadlineMs,
        repeatMin: testState.repeatMin || 1,
        snoozeMin: testState.snoozeMin || 1,
        prefix: "🧪 ТЕСТ: ",
        cbPrefix: "t:"
      };
      const testHasMark = !!testState.testMarkedAt;
      const testDirty = await this.runSingleChainTick(now, testState, testCfg, testHasMark, true);
      if (testState.closedAt || testState.expiredSentAt) {
        testState.active = false;
      }
      if (testDirty || !testState.active) {
        await this.state.storage.put("testState", testState);
      }
    }

    await this.scheduleNextAlarm(now);
  }

  computeChainNextWakeMs(now, chainState, cfg, hasMark, nextDayAskAtMs) {
    if (hasMark || chainState.closedAt || chainState.expiredSentAt) {
      return nextDayAskAtMs;
    }
    const candidates = [];
    if (chainState.retryAt && chainState.retryAt > now) {
      candidates.push(chainState.retryAt);
    }
    if (!chainState.askSentAt && cfg.askAtMs > now) {
      candidates.push(cfg.askAtMs);
    }
    const effectivePlannedAt = chainState.plannedAt || cfg.defaultAtMs;
    if (!chainState.lastRemindAt && effectivePlannedAt > now && effectivePlannedAt < cfg.deadlineMs) {
      candidates.push(effectivePlannedAt);
    }
    if (chainState.nextRemindAt && chainState.nextRemindAt > now && chainState.nextRemindAt < cfg.deadlineMs) {
      candidates.push(chainState.nextRemindAt);
    }
    if (cfg.deadlineMs > now) {
      candidates.push(cfg.deadlineMs);
    }
    if (candidates.length === 0) {
      return nextDayAskAtMs || now + 60000;
    }
    return Math.min(...candidates);
  }

  async scheduleNextAlarm(now = Date.now()) {
    const D = this.eveningDay(now);
    const bounds = this.dayBounds(D);
    const log = await this.getLog();
    const eveningMark = this.findEveningMark(log, D);
    const state = (await this.state.storage.get("state")) || this.createFreshState(D);

    const realCfg = {
      askAtMs: bounds.askAtMs,
      defaultAtMs: bounds.defaultAtMs,
      deadlineMs: bounds.deadlineMs
    };
    let nextWakeMs = this.computeChainNextWakeMs(
      now,
      state,
      realCfg,
      !!eveningMark,
      bounds.nextDayAskAtMs
    );

    const testState = await this.state.storage.get("testState");
    if (testState && testState.active) {
      const testCfg = {
        askAtMs: testState.askAtMs,
        defaultAtMs: testState.defaultAtMs,
        deadlineMs: testState.deadlineMs
      };
      const testWake = this.computeChainNextWakeMs(
        now,
        testState,
        testCfg,
        !!testState.testMarkedAt,
        bounds.nextDayAskAtMs
      );
      if (testWake && testWake < nextWakeMs) {
        nextWakeMs = testWake;
      }
    }

    const safeWakeMs = Math.max(now + 1000, nextWakeMs || bounds.nextDayAskAtMs);
    await this.state.storage.setAlarm(safeWakeMs);
    return safeWakeMs;
  }

  async handleUpdate(update) {
    const now = Date.now();
    const updateId = Number(update.update_id || 0);
    const lastUpdateId = Number((await this.state.storage.get("lastUpdateId")) || 0);
    if (updateId > 0 && updateId <= lastUpdateId) {
      return;
    }
    if (updateId > 0) {
      await this.state.storage.put("lastUpdateId", updateId);
    }

    if (update.callback_query) {
      await this.handleCallbackQuery(update.callback_query, now);
      return;
    }
    if (update.message) {
      await this.handleMessage(update.message, now);
    }
  }

  async handleCallbackQuery(cbq, now) {
    const data = String(cbq.data || "");
    const cbId = cbq.id;
    const msgId = cbq.message?.message_id || null;
    const msgDateSec = Number(cbq.message?.date || 0);
    const isStale = msgDateSec > 0 && now - msgDateSec * 1000 > 6 * 3600 * 1000;

    if (cbId) {
      await insTelegram(this.env, "answerCallbackQuery", { callback_query_id: cbId });
    }

    const isTest = data.startsWith("t:");
    const cleanData = isTest ? data.slice(2) : data;
    const prefix = isTest ? "🧪 ТЕСТ: " : "";

    if (isTest) {
      const testState = await this.state.storage.get("testState");
      if (!testState) return;
      if (cleanData === "mark") {
        testState.testMarkedAt = now;
        testState.closedAt = now;
        testState.active = false;
        await this.state.storage.put("testState", testState);
        if (msgId) await this.clearInlineMarkupBestEffort(msgId);
        let txt = `${prefix}✅ Отмечено: ${insFmtDayWordAndHm(now, now)}.`;
        if (isStale) txt += " Это было старое сообщение, записано текущее время.";
        await this.sendOwnerMessage(txt);
        await this.tick(now);
        return;
      }
      if (cleanData === "snooze") {
        const snoozed = Math.min(now + (testState.snoozeMin || 1) * 60000, testState.deadlineMs);
        testState.nextRemindAt = snoozed;
        await this.state.storage.put("testState", testState);
        if (msgId) await this.clearInlineMarkupBestEffort(msgId);
        await this.recordEvent(now, "snooze", "test");
        await this.sendOwnerMessage(`${prefix}Ок, напомню в ${insFmtHm(snoozed)}.`);
        await this.tick(now);
        return;
      }
      if (cleanData.startsWith("ask:")) {
        const choice = cleanData.slice(4);
        if (msgId) await this.clearInlineMarkupBestEffort(msgId);
        if (choice === "other") {
          testState.awaitingCustomTime = true;
          await this.state.storage.put("testState", testState);
          await this.sendOwnerMessage(`${prefix}Напишите время, например 22:40.`);
          return;
        }
        if (choice === "home") {
          testState.plannedAt = now + (testState.homeDelayMin || 1) * 60000;
        } else if (choice === "2200" || choice === "2300") {
          testState.plannedAt = now + (testState.planDelayMin || 1) * 60000;
        }
        testState.awaitingCustomTime = false;
        await this.state.storage.put("testState", testState);
        await this.sendOwnerMessage(`${prefix}Хорошо, напомню в ${insFmtHm(testState.plannedAt)}.`);
        await this.tick(now);
        return;
      }
      return;
    }

    // Реальная цепочка
    const D = this.eveningDay(now);
    const bounds = this.dayBounds(D);
    let state = (await this.state.storage.get("state")) || this.createFreshState(D);
    if (state.day !== D) {
      state = this.createFreshState(D);
    }

    if (cleanData === "mark") {
      if (msgId) await this.clearInlineMarkupBestEffort(msgId);
      const res = await this.addMark(now, "button", now, isStale);
      await this.sendOwnerMessage(res.replyText);
      await this.tick(now);
      return;
    }

    if (cleanData === "snooze") {
      if (msgId) await this.clearInlineMarkupBestEffort(msgId);
      const snoozed = Math.min(now + SNOOZE_MIN * 60000, bounds.deadlineMs);
      state.nextRemindAt = snoozed;
      if (!state.plannedAt) state.plannedAt = now;
      await this.state.storage.put("state", state);
      await this.recordEvent(now, "snooze", insFmtHm(snoozed));
      await this.sendOwnerMessage(`Ок, напомню в ${insFmtHm(snoozed)}.`);
      await this.tick(now);
      return;
    }

    if (cleanData.startsWith("ask:")) {
      const choice = cleanData.slice(4);
      if (msgId) await this.clearInlineMarkupBestEffort(msgId);
      if (choice === "other") {
        state.awaitingCustomTime = true;
        await this.state.storage.put("state", state);
        await this.sendOwnerMessage("Напишите время, например 22:40.");
        await this.scheduleNextAlarm(now);
        return;
      }
      let planned = bounds.defaultAtMs;
      if (choice === "2200") {
        planned = insKyivToMs(D, "22:00") + PLAN_DELAY_MIN * 60000;
      } else if (choice === "2300") {
        planned = insKyivToMs(D, "23:00") + PLAN_DELAY_MIN * 60000;
      } else if (choice === "home") {
        planned = now + HOME_DELAY_MIN * 60000;
      }
      if (planned > bounds.deadlineMs - 5 * 60000) {
        planned = bounds.deadlineMs - 5 * 60000;
      }
      state.plannedAt = planned;
      state.awaitingCustomTime = false;
      await this.state.storage.put("state", state);
      await this.sendOwnerMessage(`Хорошо, напомню в ${insFmtHm(planned)}.`);
      await this.tick(now);
    }
  }

  async handleMessage(msg, now) {
    const rawText = String(msg.text || "").trim();
    if (!rawText) return;
    const lower = rawText.toLowerCase();

    const D = this.eveningDay(now);
    const bounds = this.dayBounds(D);
    let state = (await this.state.storage.get("state")) || this.createFreshState(D);
    if (state.day !== D) {
      state = this.createFreshState(D);
    }
    const testState = await this.state.storage.get("testState");

    // 1. /start
    if (lower === "/start" || lower === "start") {
      state.awaitingCustomTime = false;
      await this.state.storage.put("state", state);
      await this.sendOwnerMessage(
        "Привет! Я веду журнал отметок. Нажимайте «💉 Сделал», когда сделали, и «🕘 Когда колол?», чтобы посмотреть последние отметки. Вечером я сам спрошу про вас."
      );
      await this.tick(now);
      return;
    }

    // 2. Быстрая отметка «сейчас»
    if (lower === "💉 сделал" || lower === "сделал" || lower === "/done" || lower === "done") {
      state.awaitingCustomTime = false;
      await this.state.storage.put("state", state);
      const res = await this.addMark(now, lower.startsWith("💉") ? "button" : "text", now, false);
      await this.sendOwnerMessage(res.replyText);
      await this.tick(now);
      return;
    }

    // 3. Отметка с временем: «сделал ЧЧ:ММ» или «/done ЧЧ:ММ»
    if (lower.startsWith("сделал ") || lower.startsWith("/done ") || lower.startsWith("done ")) {
      const arg = rawText.replace(/^(\/done|done|сделал)\s+/i, "").trim();
      const m = /^(\d{1,2})[:.](\d{2})$/.exec(arg);
      if (!m) {
        await this.sendOwnerMessage("Не понял время. Напишите, например: сделал 22:40.");
        return;
      }
      const hh = Number(m[1]);
      const mm = Number(m[2]);
      if (hh < 0 || hh > 23 || mm < 0 || mm > 59) {
        await this.sendOwnerMessage("Не понял время. Напишите, например: сделал 22:40.");
        return;
      }
      const hm = `${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}`;
      const np = insKyivParts(now);
      let targetMs = insKyivToMs(np.dateStr, hm);
      if (targetMs > now + 5 * 60000) {
        targetMs = insKyivToMs(insAddDays(np.dateStr, -1), hm);
      }
      if (targetMs > now + 5 * 60000 || now - targetMs > 36 * 3600 * 1000) {
        await this.sendOwnerMessage("Не понял время. Напишите, например: сделал 22:40.");
        return;
      }
      state.awaitingCustomTime = false;
      await this.state.storage.put("state", state);
      const res = await this.addMark(targetMs, "manual", now, false);
      await this.sendOwnerMessage(res.replyText);
      await this.tick(now);
      return;
    }

    // 4. Последние отметки: «🕘 Когда колол?», «когда», «/last»
    if (lower === "🕘 когда колол?" || lower === "когда колол?" || lower === "когда" || lower === "/last" || lower === "last") {
      const log = await this.getLog();
      if (log.length === 0) {
        await this.sendOwnerMessage("Отметок пока нет.");
        return;
      }
      const recent = log.slice(-5).reverse();
      const first = recent[0];
      const lines = [
        `Последняя отметка: ${insFmtDayWordAndHm(first.ts, now)} (${insFmtRel(now - first.ts)}).`
      ];
      for (let i = 1; i < recent.length; i++) {
        lines.push(`Раньше: ${insFmtDayWordAndHm(recent[i].ts, now)}`);
      }
      await this.sendOwnerMessage(lines.join("\n"));
      return;
    }

    // 5. /undo
    if (lower === "/undo" || lower === "undo") {
      const log = await this.getLog();
      if (log.length === 0) {
        await this.sendOwnerMessage("Удалять нечего.");
        return;
      }
      const last = log[log.length - 1];
      if (now - last.ts > UNDO_WINDOW_MIN * 60000) {
        await this.sendOwnerMessage("Последняя отметка старше 30 минут, удалять не буду.");
        return;
      }
      log.pop();
      await this.saveLog(log);
      await this.recordEvent(now, "undo", insFmtHm(last.ts));
      await this.sendOwnerMessage(`Последняя отметка (${insFmtHm(last.ts)}) удалена.`);
      await this.tick(now);
      return;
    }

    // 6. /status
    if (lower === "/status" || lower === "status") {
      const log = await this.getLog();
      const eveningMark = this.findEveningMark(log, D);
      let stageText = "ждём вопрос";
      if (eveningMark || state.closedAt) {
        stageText = "закрыта отметкой";
      } else if (state.expiredSentAt || now >= bounds.deadlineMs) {
        stageText = "срок истёк";
      } else if (state.remindCount > 0) {
        stageText = "повторяем";
      } else if (state.plannedAt) {
        stageText = `напомним в ${insFmtHm(state.plannedAt)}`;
      } else if (state.askSentAt) {
        stageText = "вопрос отправлен";
      }
      const events = await this.getEvents();
      const lastEv = events.slice(-5).reverse();
      const evLines = lastEv.map(e => `${insFmtHm(e.ts)} ${e.type}`);
      const statusMsg = [
        `Сутки: ${D}`,
        `Вечерняя отметка: ${eveningMark ? `есть (${insFmtHm(eveningMark.ts)})` : "нет"}`,
        `Стадия: ${stageText}`,
        `Напоминаний отправлено: ${state.remindCount || 0}`,
        evLines.length > 0 ? `События:\n${evLines.join("\n")}` : "События: нет"
      ].join("\n");
      await this.sendOwnerMessage(statusMsg);
      return;
    }

    // 7. /test
    if (lower === "/test" || lower === "test") {
      const newTest = {
        active: true,
        askAtMs: now,
        defaultAtMs: now + 2 * 60000,
        deadlineMs: now + 7 * 60000,
        repeatMin: 1,
        snoozeMin: 1,
        homeDelayMin: 1,
        planDelayMin: 1,
        askSentAt: null,
        askMessageId: null,
        awaitingCustomTime: false,
        plannedAt: null,
        lastRemindAt: null,
        nextRemindAt: null,
        remindCount: 0,
        lastReminderMessageId: null,
        expiredSentAt: null,
        closedAt: null,
        testMarkedAt: null,
        consecutiveSendErrors: 0,
        retryAt: null
      };
      await this.state.storage.put("testState", newTest);
      await this.tick(now);
      return;
    }

    // 8. Ожидание ввода времени после кнопки «Другое время»
    const activeTestAwaiting = testState && testState.active && testState.awaitingCustomTime;
    if (activeTestAwaiting || state.awaitingCustomTime) {
      const m = /^(\d{1,2})[:.](\d{2})$/.exec(rawText);
      if (!m) {
        await this.sendOwnerMessage(
          `${activeTestAwaiting ? "🧪 ТЕСТ: " : ""}Не понял время. Напишите, например: сделал 22:40.`
        );
        return;
      }
      const hh = Number(m[1]);
      const mm = Number(m[2]);
      if (hh < 0 || hh > 23 || mm < 0 || mm > 59) {
        await this.sendOwnerMessage(
          `${activeTestAwaiting ? "🧪 ТЕСТ: " : ""}Не понял время. Напишите, например: сделал 22:40.`
        );
        return;
      }
      if (hh >= 3 && hh <= 17) {
        await this.sendOwnerMessage(
          `${activeTestAwaiting ? "🧪 ТЕСТ: " : ""}Это не вечернее время. Напишите время от 18:00 до 02:59.`
        );
        return;
      }
      const hm = `${String(hh).padStart(2, "0")}:${String(mm).padStart(2, "0")}`;
      const targetDate = hh <= 2 ? bounds.nextDay : D;
      const chosenMs = insKyivToMs(targetDate, hm);

      if (activeTestAwaiting) {
        let planned = chosenMs + (testState.planDelayMin || 1) * 60000;
        if (planned > testState.deadlineMs - 60000) {
          planned = testState.deadlineMs - 60000;
        }
        testState.plannedAt = planned;
        testState.awaitingCustomTime = false;
        await this.state.storage.put("testState", testState);
        await this.sendOwnerMessage(`🧪 ТЕСТ: Хорошо, напомню в ${insFmtHm(planned)}.`);
        await this.tick(now);
        return;
      }

      let planned = chosenMs + PLAN_DELAY_MIN * 60000;
      if (planned > bounds.deadlineMs - 5 * 60000) {
        planned = bounds.deadlineMs - 5 * 60000;
      }
      state.plannedAt = planned;
      state.awaitingCustomTime = false;
      await this.state.storage.put("state", state);
      await this.sendOwnerMessage(`Хорошо, напомню в ${insFmtHm(planned)}.`);
      await this.tick(now);
      return;
    }

    // 9. Неизвестный ввод
    await this.sendOwnerMessage("Не понял. Используйте кнопки внизу или команды /last, /undo, /status.");
  }
}
