# MiTV Launcher — Assistant latency optimizations

Changes in this archive:
- Main text/audio turns now try Gemini `streamGenerateContent?alt=sse` first.
- Partial text is delivered to the existing callback as SSE chunks arrive.
- Models that reject streaming are remembered for this app session and use `generateContent` fallback.
- Text turn budget reduced from 25s to 18s; key attempts reduced from 3 to 2.
- Text SSE connection/read timeouts are bounded to avoid one slow request consuming the whole turn.
- Voice turns now prefer the configured Flash-Lite model rather than forcing the heavier Flash model.
- TTS socket timeouts are bounded by the first-audio budget.
- SSE connections are always disconnected in `finally`.

Validation:
- Source archive structure and modified call paths were inspected.
- This environment does not have Gradle, Android SDK, or Android NDK installed, so an APK build and device-level latency test could not be run here.
- Build the project in Android Studio with Android SDK 34 and JDK 17, then test text, voice, TTS, and remote-control commands on the target TV stick.

Security:
- The original project contains embedded Gemini/Tuya credentials and a release signing keystore/password. Treat these as secrets. Rotate exposed API credentials and move them to a private local configuration before sharing the project. Do not publish this archive.
