# Разбивка больших файлов (механическая)

Что сделано: `AssistantEngine.kt` (6388 строк) и `KeyMapperAccessibilityService.kt` (5168 строк) разрезаны по объектам верхнего уровня. Код каждого блока скопирован без изменений, меняется только расположение по файлам. Пакеты и манифест не менялись. Версия: versionCode 95.

## Новая карта файлов

Пакет `com.mitv.customlauncher.data` (папка `app/src/main/java/com/mitv/customlauncher/data/`):

| Файл | Строк | Что внутри |
|---|---|---|
| `AssistantEngine.kt` | 84 | AssistantState, AssistantEngine, FakeAssistantEngine |
| `LocalVoiceCommandRouter.kt` | 763 | LocalVoiceCommandRouter |
| `TuyaSmartHomeController.kt` | 1954 | LedSwatchPreset, SmartLightTarget, TuyaSmartHomeController |
| `SpotifyCloudBridge.kt` | 637 | SpotifyCloudBridge |
| `AiMemoryStore.kt` | 133 | AiMemoryStore |
| `LiveWorldContextRepository.kt` | 216 | LiveWorldContextRepository |
| `ScheduledTaskManager.kt` | 326 | ScheduledTaskManager |
| `AssistantVoiceSpeaker.kt` | 1265 | AssistantVoiceSpeaker |
| `GeminiCloudClient.kt` | 1474 | GeminiTurnResult, GeminiCloudClient |

Пакет `com.mitv.customlauncher.service` (папка `app/src/main/java/com/mitv/customlauncher/service/`):

| Файл | Строк | Что внутри |
|---|---|---|
| `KeyMapperAccessibilityService.kt` | 2429 | KeyMapperAccessibilityService, MediaSessionListenerService |
| `MediaStateBus.kt` | 1746 | NowPlayingSnapshot, MediaStateBus |
| `RemoteConsoleServer.kt` | 739 | RemoteConsoleServer |
| `DynamicIslandBus.kt` | 240 | DynamicIslandBus |
| `TvUiControllerBus.kt` | 183 | TvUiControllerBus |
| `ShellKeyController.kt` | 173 | ShellKeyController |
| `NavSoundPlayer.kt` | 180 | NavSoundPlayer |
| `ServiceAutoActivator.kt` | 238 | ServiceAutoActivator |
| `SmallBuses.kt` | 144 | VolumeHudBus, KeyCaptureBus |

## Правило для будущих ТЗ

В ТЗ указывать путь к конкретному файлу из этой карты, а не «AssistantEngine.kt целиком». Новые крупные функции выносить в новые файлы рядом, а в существующих оставлять только короткие вызовы.
