# 0.8.1 — единый стиль виджетов (капсулы как в Центре управления)

- Общая фабрика `createCapsuleDrawable(accent, CapsuleState, radiusDp)` (NEUTRAL / ACCENT / DANGER) с кэшем; `createToggleDrawable` оставлен как обёртка, Центр управления не изменился.
- Плеер: без общей подложки; капсула трека 64dp, прогресс-линия 4dp, ряд кнопок 40dp. Состояние «в фокусе» (рамка 2dp акцента) включается через `updateNowPlayingCardHoverBorder`.
- График света: плавающие плитки (шапка 56dp ACCENT/DANGER, вкладки 34dp, плитка шкалы, слоты 36dp, не больше 3). Подложка `bg_control_center_panel` больше не используется.
- Нижние капсулы: `statusCornerPill` — нейтральная капсула, `outageCornerPill` — круг 44x44 с одной молнией и закэшированным ореолом (`ivOutageCornerGlow`); текст статуса в `contentDescription`.
- Блюр за капсулами (п. 5 ТЗ) в этот патч не входит.
- Все цвета берутся из `currentAccentColor`; id и цепочки `nextFocus*` сохранены.
