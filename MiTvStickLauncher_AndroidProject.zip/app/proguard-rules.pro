# Оптимизация R8 под лимит размера APK <= 5 МБ и ОЗУ <= 50 МБ PSS (§3, §5)
-keep class com.mitv.customlauncher.ui.LauncherActivity { *; }
-dontwarn kotlin.**
