package com.mitv.customlauncher.data

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.provider.Settings

class AppLauncher(private val appContext: Context) {

    /**
     * Алгоритм §4.4: для каждого кандидата getLeanbackLaunchIntentForPackage,
     * затем getLaunchIntentForPackage; первый найденный запускается с FLAG_ACTIVITY_NEW_TASK.
     * Проверка в момент нажатия, без кэша.
     */
    fun launchCardApp(cardType: AppCardType): Boolean {
        val pm = appContext.packageManager
        for (pkg in cardType.packagesByPriority) {
            val intent = resolveLaunchIntent(pm, pkg) ?: continue
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            return try {
                appContext.startActivity(intent)
                true
            } catch (_: ActivityNotFoundException) {
                false
            } catch (_: SecurityException) {
                false
            }
        }
        return false
    }

    /**
     * Долгое нажатие центра (§4.3, §4.4): Settings.ACTION_SETTINGS в том же try/catch
     */
    fun launchSystemSettings(): Boolean {
        val intent = Intent(Settings.ACTION_SETTINGS).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        return try {
            appContext.startActivity(intent)
            true
        } catch (_: ActivityNotFoundException) {
            false
        } catch (_: SecurityException) {
            false
        }
    }

    private fun resolveLaunchIntent(pm: PackageManager, packageName: String): Intent? {
        return pm.getLeanbackLaunchIntentForPackage(packageName)
            ?: pm.getLaunchIntentForPackage(packageName)
    }
}
