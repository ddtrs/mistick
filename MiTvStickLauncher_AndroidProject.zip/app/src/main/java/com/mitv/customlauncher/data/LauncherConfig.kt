package com.mitv.customlauncher.data

import com.mitv.customlauncher.R

enum class AppCardType(
    val packagesByPriority: List<String>,
    val notInstalledMsgRes: Int
) {
    YOUTUBE(
        packagesByPriority = listOf(
            "com.teamsmart.videomanager.tv",
            "com.liskovsoft.smarttubetv.beta"
        ),
        notInstalledMsgRes = R.string.err_youtube_not_installed
    ),
    BROWSER(
        packagesByPriority = listOf("com.phlox.tvwebbrowser"),
        notInstalledMsgRes = R.string.err_browser_not_installed
    ),
    CAST(
        packagesByPriority = listOf("com.ionitech.airscreen"),
        notInstalledMsgRes = R.string.err_cast_not_installed
    )
}

object LauncherConfig {
    // §4.3, §6 Анимация фокуса
    const val FOCUS_SCALE = 1.05f
    const val FOCUS_IDLE_SCALE = 1.0f
    const val FOCUS_ANIM_DURATION_MS = 120L

    // §4.3 Долгое нажатие центра (>= 500 мс)
    const val LONG_PRESS_CENTER_MS = 500L

    // §4.6 Защита от выгорания (5 мин простоя, шаг раз в 60 с, сдвиг 4–8 dp за 1.5 с)
    const val BURN_IN_IDLE_THRESHOLD_MS = 5 * 60 * 1000L
    const val BURN_IN_PERIOD_MS = 60 * 1000L
    const val BURN_IN_ANIM_DURATION_MS = 1500L
    val BURN_IN_OFFSETS_DP: List<Pair<Float, Float>> = listOf(
        6f to 4f,
        -5f to 7f,
        -7f to -5f,
        5f to -6f,
        0f to 0f
    )

    // §4.7 Таймаут автоскрытия оверлея ИИ после ответа
    const val ASSISTANT_AUTO_HIDE_MS = 6000L

    /**
     * Чистая функция выбора первого доступного пакета из приоритетного списка (§8 Unit-тесты)
     */
    fun selectTargetPackage(
        candidates: List<String>,
        isPackageResolvable: (String) -> Boolean
    ): String? {
        return candidates.firstOrNull { isPackageResolvable(it) }
    }
}
