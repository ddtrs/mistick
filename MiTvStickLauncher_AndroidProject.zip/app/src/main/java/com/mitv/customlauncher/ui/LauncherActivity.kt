package com.mitv.customlauncher.ui

import android.Manifest
import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.view.KeyEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.mitv.customlauncher.R
import com.mitv.customlauncher.data.AppCardType
import com.mitv.customlauncher.data.AppLauncher
import com.mitv.customlauncher.data.AssistantState
import com.mitv.customlauncher.data.ClockFormatter
import com.mitv.customlauncher.data.LauncherConfig
import com.mitv.customlauncher.data.NetworkMonitor
import com.mitv.customlauncher.data.NetworkStatus
import com.mitv.customlauncher.databinding.ActivityLauncherBinding
import com.mitv.customlauncher.presentation.LauncherUiEvent
import com.mitv.customlauncher.presentation.LauncherViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

class LauncherActivity : ComponentActivity() {

    private lateinit var binding: ActivityLauncherBinding
    private lateinit var burnInProtector: BurnInProtector

    // Переиспользуемые аниматоры фокуса (§4.3: не создаются на каждое событие)
    private val focusAnimators = mutableMapOf<View, ObjectAnimator>()
    private val decelerateInterpolator = DecelerateInterpolator()
    private var aiPulseAnimator: ObjectAnimator? = null

    private val viewModel: LauncherViewModel by viewModels {
        LauncherViewModel.Factory(
            appLauncher = AppLauncher(applicationContext),
            networkMonitor = NetworkMonitor(applicationContext),
            demoReplyText = getString(R.string.fake_ai_demo_response)
        )
    }

    private val audioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            viewModel.onAssistantTrigger(hasAudioPermission = true)
        }
    }

    // Реакция на смену часового пояса, времени и формата (§4.5)
    private val timeChangeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            viewModel.refreshTimeAndDate(forceDate = true)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLauncherBinding.inflate(layoutInflater)
        setContentView(binding.root)

        burnInProtector = BurnInProtector(
            targetView = binding.contentContainer,
            density = resources.displayMetrics.density
        )

        setupCardsAndFocusAnimation()
        setupBackNavigation()
        observeStateAndLifecycle()

        // Стартовый фокус — всегда YouTube (§4.3)
        binding.cardYoutube.requestFocus()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        // §4.1 Home: в onNewIntent закрыть оверлей и вернуть фокус на YouTube
        burnInProtector.onUserInteraction(lifecycleScope)
        viewModel.onHomeIntentReceived()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN) {
            burnInProtector.onUserInteraction(lifecycleScope)
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        // Аппаратная кнопка голоса на пульте (§4.7)
        if (keyCode == KeyEvent.KEYCODE_SEARCH || keyCode == KeyEvent.KEYCODE_VOICE_ASSIST) {
            Log.d("MiTvLauncher", "Voice keycode received: $keyCode")
            viewModel.onAssistantTrigger(hasAudioPermission())
            return true
        }

        // Отслеживание короткого и долгого нажатия центра (§4.3: startTracking + onKeyLongPress)
        if (isCenterKey(keyCode)) {
            if (event.repeatCount == 0) {
                event.startTracking()
            }
            return true
        }

        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyLongPress(keyCode: Int, event: KeyEvent): Boolean {
        if (isCenterKey(keyCode)) {
            // Долгое нажатие центра (>= 500 мс) открывает системные настройки;
            // возврат true ставит флаг KeyEvent.FLAG_CANCELED_LONG_PRESS, чтобы onKeyUp не сработал
            viewModel.onCenterLongPressed()
            return true
        }
        return super.onKeyLongPress(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if (isCenterKey(keyCode)) {
            if (!event.isCanceled) {
                handleShortCenterClick()
            }
            return true
        }
        return super.onKeyUp(keyCode, event)
    }

    private fun handleShortCenterClick() {
        if (binding.assistantOverlay.visibility == View.VISIBLE) {
            return
        }
        when (currentFocus?.id) {
            R.id.cardYoutube -> viewModel.onCardClicked(AppCardType.YOUTUBE)
            R.id.cardBrowser -> viewModel.onCardClicked(AppCardType.BROWSER)
            R.id.cardCast -> viewModel.onCardClicked(AppCardType.CAST)
            R.id.cardAi -> viewModel.onAssistantTrigger(hasAudioPermission())
        }
    }

    private fun setupCardsAndFocusAnimation() {
        val cards = listOf(
            binding.cardYoutube,
            binding.cardBrowser,
            binding.cardCast,
            binding.cardAi
        )

        cards.forEach { card ->
            val pvhX = PropertyValuesHolder.ofFloat(View.SCALE_X, LauncherConfig.FOCUS_IDLE_SCALE, LauncherConfig.FOCUS_SCALE)
            val pvhY = PropertyValuesHolder.ofFloat(View.SCALE_Y, LauncherConfig.FOCUS_IDLE_SCALE, LauncherConfig.FOCUS_SCALE)
            val animator = ObjectAnimator.ofPropertyValuesHolder(card, pvhX, pvhY).apply {
                duration = LauncherConfig.FOCUS_ANIM_DURATION_MS
                interpolator = decelerateInterpolator
                addListener(object : AnimatorListenerAdapter() {
                    override fun onAnimationStart(animation: Animator) {
                        // Hardware layer только на время анимации (§4.3, §9)
                        card.setLayerType(View.LAYER_TYPE_HARDWARE, null)
                    }

                    override fun onAnimationEnd(animation: Animator) {
                        card.setLayerType(View.LAYER_TYPE_NONE, null)
                    }

                    override fun onAnimationCancel(animation: Animator) {
                        card.setLayerType(View.LAYER_TYPE_NONE, null)
                    }
                })
            }
            focusAnimators[card] = animator

            card.setOnFocusChangeListener { v, hasFocus ->
                val anim = focusAnimators[v] ?: return@setOnFocusChangeListener
                if (hasFocus) {
                    anim.setFloatValues(v.scaleX, LauncherConfig.FOCUS_SCALE)
                    anim.start()
                } else {
                    anim.reverse()
                }
            }

            card.setOnClickListener {
                handleShortCenterClick()
            }
        }
    }

    private fun setupBackNavigation() {
        // §4.1, §4.7: если открыт оверлей — закрыть и вернуть фокус на AI-карточку;
        // иначе Back ничего не делает (лончер никогда не закрывается)
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (binding.assistantOverlay.visibility == View.VISIBLE) {
                    viewModel.closeAssistantOverlay(restoreFocusToAi = true)
                }
            }
        })
    }

    private fun observeStateAndLifecycle() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                burnInProtector.onUserInteraction(this)

                // Регистрация receiver смены времени и часового пояса в STARTED (§4.5)
                val filter = IntentFilter().apply {
                    addAction(Intent.ACTION_TIME_CHANGED)
                    addAction(Intent.ACTION_TIMEZONE_CHANGED)
                    addAction(Intent.ACTION_LOCALE_CHANGED)
                }
                registerReceiver(timeChangeReceiver, filter)

                // Корутина часов с выравниванием по границе секунды (§4.5)
                launch {
                    while (isActive) {
                        viewModel.refreshTimeAndDate()
                        delay(ClockFormatter.computeDelayToNextSecond(System.currentTimeMillis()))
                    }
                }

                // Мониторинг сети в STARTED и автоотписка в STOPPED (§4.5)
                launch {
                    viewModel.observeNetworkInForeground().collect { netStatus ->
                        viewModel.updateNetworkStatus(netStatus)
                    }
                }

                // Подписка на единый StateFlow<LauncherUiState> (§3)
                launch {
                    viewModel.uiState.collect { state ->
                        binding.tvClock.text = state.timeText
                        binding.tvDate.text = state.dateText
                        renderNetworkStatus(state.networkStatus)
                        renderAssistantState(state.assistantState, state.isOverlayVisible)
                    }
                }

                // Одноразовые события через SharedFlow (§3)
                launch {
                    viewModel.events.collect { event ->
                        when (event) {
                            is LauncherUiEvent.ShowToastRes -> {
                                Toast.makeText(this@LauncherActivity, event.stringResId, Toast.LENGTH_SHORT).show()
                            }
                            LauncherUiEvent.RequestAudioPermission -> {
                                audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                            LauncherUiEvent.RestoreFocusToAiCard -> {
                                binding.cardAi.requestFocus()
                            }
                            LauncherUiEvent.RestoreFocusToYoutubeCard -> {
                                binding.cardYoutube.requestFocus()
                            }
                        }
                    }
                }

                try {
                     kotlinx.coroutines.awaitCancellation()
                } finally {
                    unregisterReceiver(timeChangeReceiver)
                    burnInProtector.stop()
                }
            }
        }
    }

    private fun renderNetworkStatus(status: NetworkStatus) {
        when (status) {
            is NetworkStatus.Wifi -> {
                binding.tvNetworkStatus.text = getString(R.string.net_wifi_level, status.level)
                binding.tvNetworkStatus.setTextColor(getColor(R.color.text_secondary))
            }
            NetworkStatus.Ethernet -> {
                binding.tvNetworkStatus.text = getString(R.string.net_ethernet)
                binding.tvNetworkStatus.setTextColor(getColor(R.color.text_secondary))
            }
            NetworkStatus.Disconnected -> {
                binding.tvNetworkStatus.text = getString(R.string.net_disconnected)
                binding.tvNetworkStatus.setTextColor(getColor(R.color.status_error))
            }
        }
    }

    private fun renderAssistantState(aiState: AssistantState, isOverlayVisible: Boolean) {
        binding.assistantOverlay.visibility = if (isOverlayVisible) View.VISIBLE else View.GONE
        if (isOverlayVisible) {
            binding.assistantOverlay.requestFocus()
        }

        // Управление пульсацией alpha в режиме Listening (§6 — единственная постоянная анимация)
        if (aiState is AssistantState.Listening) {
            if (aiPulseAnimator == null) {
                aiPulseAnimator = ObjectAnimator.ofFloat(binding.tvAiStatus, View.ALPHA, 1f, 0.35f).apply {
                    duration = 650L
                    repeatMode = ObjectAnimator.REVERSE
                    repeatCount = ObjectAnimator.INFINITE
                    interpolator = LinearInterpolator()
                }
            }
            if (aiPulseAnimator?.isStarted == false) {
                aiPulseAnimator?.start()
            }
        } else {
            aiPulseAnimator?.cancel()
            binding.tvAiStatus.alpha = 1f
        }

        when (aiState) {
            AssistantState.Idle -> {
                binding.tvAiStatus.text = getString(R.string.ai_status_idle)
                binding.tvAiStatus.setTextColor(getColor(R.color.text_secondary))
            }
            AssistantState.Listening -> {
                binding.tvAiStatus.text = getString(R.string.ai_status_listening)
                binding.tvAiStatus.setTextColor(getColor(R.color.accent_cyan))
                binding.tvOverlayTitle.text = getString(R.string.overlay_title_listening)
            }
            AssistantState.Processing -> {
                binding.tvAiStatus.text = getString(R.string.ai_status_processing)
                binding.tvAiStatus.setTextColor(getColor(R.color.accent_cyan))
                binding.tvOverlayTitle.text = getString(R.string.overlay_title_processing)
            }
            is AssistantState.Result -> {
                binding.tvAiStatus.text = getString(R.string.ai_status_idle)
                binding.tvAiStatus.setTextColor(getColor(R.color.accent_cyan))
                binding.tvOverlayTitle.text = getString(R.string.overlay_title_result)
                binding.tvOverlayBody.text = aiState.text
            }
            is AssistantState.Error -> {
                binding.tvAiStatus.text = getString(R.string.ai_status_error, aiState.code)
                binding.tvAiStatus.setTextColor(getColor(R.color.status_error))
                binding.tvOverlayTitle.text = getString(R.string.overlay_title_error)
            }
        }
    }

    private fun isCenterKey(keyCode: Int): Boolean {
        return keyCode == KeyEvent.KEYCODE_DPAD_CENTER ||
            keyCode == KeyEvent.KEYCODE_ENTER ||
            keyCode == KeyEvent.KEYCODE_NUMPAD_ENTER
    }

    private fun hasAudioPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
    }
}
