package com.mitv.customlauncher.presentation

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.mitv.customlauncher.R
import com.mitv.customlauncher.data.AppCardType
import com.mitv.customlauncher.data.AppLauncher
import com.mitv.customlauncher.data.AssistantEngine
import com.mitv.customlauncher.data.AssistantState
import com.mitv.customlauncher.data.ClockFormatter
import com.mitv.customlauncher.data.FakeAssistantEngine
import com.mitv.customlauncher.data.LauncherConfig
import com.mitv.customlauncher.data.NetworkMonitor
import com.mitv.customlauncher.data.NetworkStatus
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.Calendar

data class LauncherUiState(
    val timeText: String = "00:00:00",
    val dateText: String = "",
    val networkStatus: NetworkStatus = NetworkStatus.Disconnected,
    val assistantState: AssistantState = AssistantState.Idle,
    val isOverlayVisible: Boolean = false
)

sealed interface LauncherUiEvent {
    data class ShowToastRes(val stringResId: Int) : LauncherUiEvent
    data object RequestAudioPermission : LauncherUiEvent
    data object RestoreFocusToAiCard : LauncherUiEvent
    data object RestoreFocusToYoutubeCard : LauncherUiEvent
}

/**
 * ViewModel не знает о View и Context Activity (§3).
 */
class LauncherViewModel(
    private val appLauncher: AppLauncher,
    private val networkMonitor: NetworkMonitor,
    demoReplyText: String
) : ViewModel() {

    private val assistantEngine: AssistantEngine = FakeAssistantEngine(viewModelScope, demoReplyText)

    private val _uiState = MutableStateFlow(LauncherUiState())
    val uiState: StateFlow<LauncherUiState> = _uiState.asStateFlow()

    private val _events = MutableSharedFlow<LauncherUiEvent>(extraBufferCapacity = 4)
    val events: SharedFlow<LauncherUiEvent> = _events.asSharedFlow()

    private var lastDayOfYear: Int = -1
    private var autoHideJob: Job? = null

    init {
        refreshTimeAndDate(forceDate = true)
        viewModelScope.launch {
            assistantEngine.state.collect { aiState ->
                _uiState.update { it.copy(assistantState = aiState) }
                if (aiState is AssistantState.Result || aiState is AssistantState.Error) {
                    scheduleOverlayAutoHide()
                }
            }
        }
    }

    fun refreshTimeAndDate(forceDate: Boolean = false) {
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance().apply { timeInMillis = now }
        val dayOfYear = cal.get(Calendar.DAY_OF_YEAR)
        val shouldUpdateDate = forceDate || (dayOfYear != lastDayOfYear)
        if (shouldUpdateDate) {
            lastDayOfYear = dayOfYear
        }
        _uiState.update { current ->
            current.copy(
                timeText = ClockFormatter.formatTime24(now),
                dateText = if (shouldUpdateDate) ClockFormatter.formatDate(now) else current.dateText
            )
        }
    }

    fun observeNetworkInForeground() = networkMonitor.observeNetworkStatus()

    fun updateNetworkStatus(status: NetworkStatus) {
        _uiState.update { it.copy(networkStatus = status) }
    }

    fun onCardClicked(cardType: AppCardType) {
        val launched = appLauncher.launchCardApp(cardType)
        if (!launched) {
            _events.tryEmit(LauncherUiEvent.ShowToastRes(cardType.notInstalledMsgRes))
        }
    }

    fun onCenterLongPressed() {
        val opened = appLauncher.launchSystemSettings()
        if (!opened) {
            _events.tryEmit(LauncherUiEvent.ShowToastRes(R.string.err_settings_unavailable))
        }
    }

    fun onAssistantTrigger(hasAudioPermission: Boolean) {
        if (!hasAudioPermission) {
            _events.tryEmit(LauncherUiEvent.RequestAudioPermission)
            return
        }
        autoHideJob?.cancel()
        _uiState.update { it.copy(isOverlayVisible = true) }
        assistantEngine.startSession()
    }

    fun closeAssistantOverlay(restoreFocusToAi: Boolean) {
        autoHideJob?.cancel()
        assistantEngine.cancelSession()
        _uiState.update { it.copy(isOverlayVisible = false) }
        if (restoreFocusToAi) {
            _events.tryEmit(LauncherUiEvent.RestoreFocusToAiCard)
        }
    }

    fun onHomeIntentReceived() {
        if (_uiState.value.isOverlayVisible) {
            closeAssistantOverlay(restoreFocusToAi = false)
        }
        _events.tryEmit(LauncherUiEvent.RestoreFocusToYoutubeCard)
    }

    private fun scheduleOverlayAutoHide() {
        autoHideJob?.cancel()
        autoHideJob = viewModelScope.launch {
            delay(LauncherConfig.ASSISTANT_AUTO_HIDE_MS)
            closeAssistantOverlay(restoreFocusToAi = true)
        }
    }

    class Factory(
        private val appLauncher: AppLauncher,
        private val networkMonitor: NetworkMonitor,
        private val demoReplyText: String
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return LauncherViewModel(appLauncher, networkMonitor, demoReplyText) as T
        }
    }
}
