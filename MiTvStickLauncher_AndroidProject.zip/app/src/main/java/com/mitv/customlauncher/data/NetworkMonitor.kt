package com.mitv.customlauncher.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.wifi.WifiManager
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged

sealed interface NetworkStatus {
    data class Wifi(val level: Int) : NetworkStatus // 0..4
    data object Ethernet : NetworkStatus
    data object Disconnected : NetworkStatus
}

class NetworkMonitor(context: Context) {
    private val appContext = context.applicationContext
    private val connectivityManager =
        appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val wifiManager =
        appContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager

    fun observeNetworkStatus(): Flow<NetworkStatus> = callbackFlow {
        trySend(readCurrentStatus())

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                trySend(readCurrentStatus())
            }

            override fun onLost(network: Network) {
                trySend(readCurrentStatus())
            }

            override fun onCapabilitiesChanged(
                network: Network,
                networkCapabilities: NetworkCapabilities
            ) {
                trySend(readCurrentStatus())
            }
        }

        try {
            connectivityManager.registerDefaultNetworkCallback(callback)
        } catch (_: SecurityException) {
            trySend(NetworkStatus.Disconnected)
        }

        awaitClose {
            try {
                connectivityManager.unregisterNetworkCallback(callback)
            } catch (_: Exception) {
            }
        }
    }.distinctUntilChanged()

    fun readCurrentStatus(): NetworkStatus {
        val activeNetwork = connectivityManager.activeNetwork ?: return NetworkStatus.Disconnected
        val caps = connectivityManager.getNetworkCapabilities(activeNetwork)
            ?: return NetworkStatus.Disconnected

        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> NetworkStatus.Ethernet
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> {
                @Suppress("DEPRECATION")
                val rssi = wifiManager?.connectionInfo?.rssi ?: -100
                @Suppress("DEPRECATION")
                val level = WifiManager.calculateSignalLevel(rssi, 5).coerceIn(0, 4)
                NetworkStatus.Wifi(level)
            }
            else -> NetworkStatus.Disconnected
        }
    }
}
