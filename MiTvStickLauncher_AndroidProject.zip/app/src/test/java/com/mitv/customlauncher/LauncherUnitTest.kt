package com.mitv.customlauncher

import com.mitv.customlauncher.data.ClockFormatter
import com.mitv.customlauncher.data.LauncherConfig
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class LauncherUnitTest {

    @Test
    fun `selectTargetPackage picks first installed candidate by priority`() {
        val candidates = listOf(
            "com.teamsmart.videomanager.tv",
            "com.liskovsoft.smarttubetv.beta"
        )
        val installed = setOf("com.liskovsoft.smarttubetv.beta")

        val chosen = LauncherConfig.selectTargetPackage(candidates) { it in installed }
        assertEquals("com.liskovsoft.smarttubetv.beta", chosen)
    }

    @Test
    fun `selectTargetPackage returns null when no candidate is installed`() {
        val candidates = listOf("com.phlox.tvwebbrowser")
        val chosen = LauncherConfig.selectTargetPackage(candidates) { false }
        assertNull(chosen)
    }

    @Test
    fun `computeDelayToNextSecond aligns strictly to 1000ms boundary`() {
        assertEquals(750L, ClockFormatter.computeDelayToNextSecond(1000_250L))
        assertEquals(1000L, ClockFormatter.computeDelayToNextSecond(1000_000L))
    }

    @Test
    fun `burn in offsets stay within 4 to 8 dp amplitude or zero reset`() {
        LauncherConfig.BURN_IN_OFFSETS_DP.forEach { (x, y) ->
            assertTrue(kotlin.math.abs(x) <= 8f)
            assertTrue(kotlin.math.abs(y) <= 8f)
        }
    }
}
