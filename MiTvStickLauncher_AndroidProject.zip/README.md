# Кастомный лончер для Xiaomi Mi TV Stick (Версия 2.0)

Лёгкий кастомный домашний экран (`Ambient + Grid`) для Android TV 9–11 (API 28–30), разработанный строго по ТЗ v2.0.

## 1. Как получить готовый `.apk` (2 способа)

### Способ А — Без установки программ на ПК (через GitHub Actions за 2 минуты)
В проект уже встроен облачный сборщик `.github/workflows/build-apk.yml`:
1. Создайте бесплатный приватный или публичный репозиторий на GitHub и загрузите туда содержимое этого архива.
2. Перейдите во вкладку **Actions** → выберите **Build Mi TV Stick Launcher APK** → нажмите **Run workflow**.
3. Через ~1.5 минуты скачайте готовый архив `MiTvStickLauncher-APKs` с подписанным файлом `MiTvStickLauncher-release-signed.apk` и `app-debug.apk`.

### Способ Б — Локально в Android Studio
1. Откройте распакованную папку в Android Studio (Hedgehog / Iguana / Jellyfish или новее).
2. Выберите в верхнем меню **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
3. Готовый APK появится в `app/build/outputs/apk/release/`.

---

## 2. Установка на Xiaomi Mi TV Stick и режим «Кастомной прошивки» (постоянного лончера)

1. Включите на приставке **Настройки → Об устройстве → Сборка** (нажмите 7 раз на «Сборка», чтобы открыть «Для разработчиков») и включите **Отладку по USB / по сети (ADB)**.
2. Подключитесь с компьютера к приставке по IP-адресу в вашей Wi-Fi сети:
   ```bash
   adb connect <IP_ВАШЕЙ_ПРИСТАВКИ>:5555
   ```
3. Установите APK:
   ```bash
   adb install -r MiTvStickLauncher-release-signed.apk
   ```
4. **Назначение единственным системным лончером (замена стоковой оболочки, §4.1 ТЗ):**
   Чтобы стоковый лончер Google/Xiaomi не перехватывал кнопку `Home` и приставка при включении сразу загружалась в наш дашборд:
   ```bash
   # Отключаем штатный лончер Android TV для текущего пользователя:
   adb shell pm disable-user --user 0 com.google.android.tvlauncher
   adb shell pm disable-user --user 0 com.google.android.leanbacklauncher
   ```
   После этого нажмите кнопку `Home` на пульте — откроется наш дашборд и будет работать постоянно.

5. **Обязательный откат к заводскому лончеру (при необходимости, §4.1 ТЗ):**
   ```bash
   adb shell pm enable com.google.android.tvlauncher
   adb shell pm enable com.google.android.leanbacklauncher
   ```

---

## 3. Команды проверки метрик приёмки (§5 ТЗ)

- **Холодный старт (цель ≤ 800 мс):**
  ```bash
  adb shell am force-stop com.mitv.customlauncher
  adb shell am start -W -n com.mitv.customlauncher/.ui.LauncherActivity
  ```
- **Потребление ОЗУ в простое (цель ≤ 50 МБ PSS):**
  ```bash
  adb shell dumpsys meminfo com.mitv.customlauncher
  ```
- **Плавность анимации фокуса (цель ≥ 95% кадров < 16.7 мс):**
  ```bash
  adb shell dumpsys gfxinfo com.mitv.customlauncher framestats
  ```
